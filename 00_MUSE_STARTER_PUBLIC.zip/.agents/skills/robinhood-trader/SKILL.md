---
name: robinhood-trader
description: Orchestrate a cost-aware, tool-grounded Robinhood options trading workflow with persistent memory, deterministic risk gates, earnings/news/social checks, and explicit trade/pass decisions.
---

# Robinhood Trader Skill

## Every run

### A. Load policy/state
Read the files mandated by root `AGENTS.md`.

### B. Reconcile/manage open positions first
1. Pull live Robinhood account, positions, and open orders.
2. Reconcile with `state/POSITIONS.md`.
3. For each open option, review original thesis/invalidation, fresh quote/contract data, expiry/DTE, Greeks/IV, and current earnings/catalyst status.
4. Decide HOLD / REDUCE / EXIT / WAIT.
5. Perform any approved risk action before looking for new risk.

### C. Cheap opportunity gate
Run the deterministic scanner / Vibe screening workflow.

If zero qualified new candidates:
- do not launch broad deep research
- do not spawn sub-agents
- update only necessary state
- stop new-opportunity analysis

### D. Candidate escalation
For each qualified candidate:
1. gather compact Vibe research
2. check current news/catalysts
3. check earnings/event calendar
4. check social sentiment when relevant
5. inspect Robinhood option chain/liquidity
6. query UW when enabled and warranted
7. calculate portfolio/risk fit
8. spawn relevant sub-agents per `strategy/SUBAGENTS.md`
9. produce BUY / WAIT / PASS

### E. Pre-trade thesis
Before a BUY, write thesis, catalyst, direction, horizon, contract rationale, invalidation, exit logic, earnings/event plan, and risk amount.

### F. Final live verification
Follow `strategy/EXECUTION_RULES.md` exactly.

### G. Memory/journal
After material decisions, update position memory, decision/trade journals, and daily state.

## Unusual Whales trial mode

When `UW_TRIAL_MODE: true`, do not query UW until a pre-UW decision has been written. Then query UW and record the post-UW decision and what changed.

## Cost discipline

Expensive reasoning and sub-agents are an escalation privilege, not the default. Optimize risk-adjusted economic value per dollar of AI/data expense.
