param(
    [ValidateSet("monitor", "opportunities")]
    [string]$Cycle = "opportunities"
)
$ErrorActionPreference = "Stop"
$cryptoRoot = Split-Path -Parent $PSScriptRoot
$cryptoPython = Join-Path $cryptoRoot ".venv\Scripts\python.exe"
$cryptoRuntime = Join-Path $cryptoRoot "state\runtime\crypto"
New-Item -ItemType Directory -Force -Path $cryptoRuntime | Out-Null
$cryptoTopic = [Environment]::GetEnvironmentVariable("NTFY_TOPIC", "User")
if (-not [string]::IsNullOrWhiteSpace($cryptoTopic)) { $env:NTFY_TOPIC = $cryptoTopic }
$cryptoArguments = @("-m", "tools.crypto_cycle", "--project-root", $cryptoRoot, "--notifications")
if ($Cycle -eq "monitor") { $cryptoArguments += "--monitor-only" }
else { $cryptoArguments += "--execute-models" }
Set-Location -LiteralPath $cryptoRoot
$cryptoOutput = & $cryptoPython @cryptoArguments 2>&1
$cryptoCode = $LASTEXITCODE
$cryptoOutput | Set-Content -LiteralPath (Join-Path $cryptoRuntime "$Cycle.latest.json") -Encoding UTF8
exit $cryptoCode
