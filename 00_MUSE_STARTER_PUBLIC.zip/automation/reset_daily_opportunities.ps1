$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$budgetPath = Join-Path $projectRoot "state\runtime\model_budget.json"

$noLunaOptions = [bool](Select-String -LiteralPath (Join-Path $projectRoot "CONFIG.md") -Pattern '^OPTIONS_LUNA_VETO_ENABLED:\s*false\s*$' -Quiet)
if (-not $noLunaOptions -and (Test-Path -LiteralPath $budgetPath)) {
    $budget = Get-Content -LiteralPath $budgetPath -Raw | ConvertFrom-Json
    $today = (Get-Date).ToString("yyyy-MM-dd")
    if (
        $budget.date -eq $today -and
        [int]$budget.maximum_calls -gt 0 -and
        [int]$budget.calls_reserved -ge [int]$budget.maximum_calls
    ) {
        exit 0
    }
}

$taskName = "RobinhoodAgentic-Opportunities"
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop

if ($task.State -eq "Disabled") {
    Enable-ScheduledTask -TaskName $taskName -ErrorAction Stop | Out-Null
}
