param(
    [switch]$Remove
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$runner = Join-Path $PSScriptRoot "run_cycle.ps1"
$resetRunner = Join-Path $PSScriptRoot "reset_daily_opportunities.ps1"
$powershell = (Get-Command powershell.exe -ErrorAction Stop).Source
$userId = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$resetTaskName = "RobinhoodAgentic-DailyReset"

$specs = @(
    @{ Name = "RobinhoodAgentic-Positions"; Cycle = "positions"; Start = "09:30"; Minutes = 2; Hours = 6.5 },
    @{ Name = "RobinhoodAgentic-Opportunities"; Cycle = "opportunities"; Start = "09:30:15"; Minutes = 5; Hours = 6.5 }
)
$legacyTasks = @("RobinhoodAgentic-News")

foreach ($legacyTask in $legacyTasks) {
    Unregister-ScheduledTask -TaskName $legacyTask -Confirm:$false -ErrorAction SilentlyContinue
}

if ($Remove) {
    Unregister-ScheduledTask -TaskName $resetTaskName -Confirm:$false -ErrorAction SilentlyContinue
}

foreach ($spec in $specs) {
    if ($Remove) {
        Unregister-ScheduledTask -TaskName $spec.Name -Confirm:$false -ErrorAction SilentlyContinue
        continue
    }
    $actionArguments = "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$runner`" -Cycle $($spec.Cycle)"
    $start = [datetime]::Today.Add([timespan]::Parse($spec.Start))
    $durationMinutes = [math]::Round($spec.Hours * 60)
    $escapedUser = [Security.SecurityElement]::Escape($userId)
    $escapedPowerShell = [Security.SecurityElement]::Escape($powershell)
    $escapedArguments = [Security.SecurityElement]::Escape($actionArguments)
    $escapedRoot = [Security.SecurityElement]::Escape($projectRoot)
    $description = [Security.SecurityElement]::Escape("Robinhood Agentic configured $($spec.Cycle) cycle")
    $startBoundary = $start.ToString("yyyy-MM-ddTHH:mm:ss")
    $executionLimit = if ($spec.Cycle -eq "positions") { "PT8H" } else { "PT10M" }
    $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>$description</Description></RegistrationInfo>
  <Triggers>
    <CalendarTrigger>
      <Repetition>
        <Interval>PT$($spec.Minutes)M</Interval>
        <Duration>PT$($durationMinutes)M</Duration>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>$startBoundary</StartBoundary>
      <Enabled>true</Enabled>
      <ScheduleByWeek>
        <DaysOfWeek>
          <Monday /><Tuesday /><Wednesday /><Thursday /><Friday />
        </DaysOfWeek>
        <WeeksInterval>1</WeeksInterval>
      </ScheduleByWeek>
    </CalendarTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>$escapedUser</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>true</RunOnlyIfNetworkAvailable>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>true</WakeToRun>
    <ExecutionTimeLimit>$executionLimit</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$escapedPowerShell</Command>
      <Arguments>$escapedArguments</Arguments>
      <WorkingDirectory>$escapedRoot</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"@
    Register-ScheduledTask -TaskName $spec.Name -Xml $xml -Force | Out-Null
}

if (-not $Remove) {
    $resetArguments = "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$resetRunner`""
    $resetStart = [datetime]::Today.Add([timespan]::Parse("09:25"))
    if ($resetStart -le (Get-Date)) {
        $resetStart = $resetStart.AddDays(1)
    }
    $escapedUser = [Security.SecurityElement]::Escape($userId)
    $escapedPowerShell = [Security.SecurityElement]::Escape($powershell)
    $escapedArguments = [Security.SecurityElement]::Escape($resetArguments)
    $escapedRoot = [Security.SecurityElement]::Escape($projectRoot)
    $description = [Security.SecurityElement]::Escape(
        "Robinhood Agentic weekday opportunity-budget reset"
    )
    $startBoundary = $resetStart.ToString("yyyy-MM-ddTHH:mm:ss")
    $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>$description</Description></RegistrationInfo>
  <Triggers>
    <CalendarTrigger>
      <StartBoundary>$startBoundary</StartBoundary>
      <Enabled>true</Enabled>
      <ScheduleByWeek>
        <DaysOfWeek>
          <Monday /><Tuesday /><Wednesday /><Thursday /><Friday />
        </DaysOfWeek>
        <WeeksInterval>1</WeeksInterval>
      </ScheduleByWeek>
    </CalendarTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>$escapedUser</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>true</WakeToRun>
    <ExecutionTimeLimit>PT2M</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$escapedPowerShell</Command>
      <Arguments>$escapedArguments</Arguments>
      <WorkingDirectory>$escapedRoot</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"@
    Register-ScheduledTask -TaskName $resetTaskName -Xml $xml -Force | Out-Null
}

if (-not $Remove) {
    Get-ScheduledTask -TaskName "RobinhoodAgentic-*" | Select-Object TaskName, State
}
