param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("positions", "news", "opportunities")]
    [string]$Cycle
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$uv = (Get-Command uv.exe -ErrorAction Stop).Source
$ntfyTopic = [Environment]::GetEnvironmentVariable("NTFY_TOPIC", "User")
if (-not [string]::IsNullOrWhiteSpace($ntfyTopic)) {
    $env:NTFY_TOPIC = $ntfyTopic
}
$arguments = @(
    "--cache-dir", (Join-Path $projectRoot ".uv-cache"),
    "run", "python", "-m", "tools.scheduled_cycle", $Cycle,
    "--project-root", $projectRoot,
    "--execute-models",
    "--notifications"
)

Set-Location -LiteralPath $projectRoot
if ($Cycle -eq "positions") {
    $configPath = Join-Path $projectRoot "CONFIG.md"
    $paperEnabled = [bool](Select-String -LiteralPath $configPath -Pattern '^PAPER_TRADING_ENABLED:\s*true\s*$' -Quiet)
    $liveEnabled = [bool](Select-String -LiteralPath $configPath -Pattern '^LIVE_EXECUTION_ENABLED:\s*true\s*$' -Quiet)
    $fastEnabled = [bool](Select-String -LiteralPath $configPath -Pattern '^PAPER_FAST_MONITOR_ENABLED:\s*true\s*$' -Quiet)
    $liveFastEnabled = [bool](Select-String -LiteralPath $configPath -Pattern '^LIVE_FAST_MONITOR_ENABLED:\s*true\s*$' -Quiet)
    if ($liveEnabled -and -not $paperEnabled -and $liveFastEnabled) {
        & $uv --cache-dir (Join-Path $projectRoot ".uv-cache") run python -m tools.live_fast_monitor --project-root $projectRoot --execute --notifications
        exit $LASTEXITCODE
    }
    if ($paperEnabled -and -not $liveEnabled -and $fastEnabled) {
        & $uv --cache-dir (Join-Path $projectRoot ".uv-cache") run python -m tools.paper_fast_monitor --project-root $projectRoot --notifications
        exit $LASTEXITCODE
    }
}
& $uv @arguments
$cycleExitCode = $LASTEXITCODE

$jevResearchEnabled = [bool](Select-String -LiteralPath (Join-Path $projectRoot "CONFIG.md") -Pattern '^ENABLE_JEV:\s*true\s*$' -Quiet)
$noLunaOptions = [bool](Select-String -LiteralPath (Join-Path $projectRoot "CONFIG.md") -Pattern '^OPTIONS_LUNA_VETO_ENABLED:\s*false\s*$' -Quiet)
if ($Cycle -eq "opportunities" -and $cycleExitCode -eq 0 -and -not $jevResearchEnabled -and -not $noLunaOptions) {
    $budgetPath = Join-Path $projectRoot "state\runtime\model_budget.json"
    if (Test-Path -LiteralPath $budgetPath) {
        try {
            $budget = Get-Content -LiteralPath $budgetPath -Raw | ConvertFrom-Json
            $today = (Get-Date).ToString("yyyy-MM-dd")
            $calls = [int]$budget.calls_reserved
            $maximum = [int]$budget.maximum_calls
            if ($budget.date -eq $today -and $maximum -gt 0 -and $calls -ge $maximum) {
                $taskName = "RobinhoodAgentic-Opportunities"
                $task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
                if ($task.State -ne "Disabled") {
                    Disable-ScheduledTask -TaskName $taskName -ErrorAction Stop | Out-Null
                }
            }
        }
        catch {
            Write-Error "Could not disable the exhausted opportunity task: $($_.Exception.Message)"
            exit 2
        }
    }
}

exit $cycleExitCode
