param([switch]$Remove)
$ErrorActionPreference = "Stop"
$cryptoRoot = Split-Path -Parent $PSScriptRoot
$cryptoRunner = Join-Path $PSScriptRoot "run_crypto.ps1"
$cryptoShell = (Get-Command powershell.exe -ErrorAction Stop).Source
$cryptoUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$cryptoSpecs = @(
    @{ Name = "RobinhoodAgentic-CryptoMonitor"; Cycle = "monitor"; Minutes = 1; Limit = 1 },
    @{ Name = "RobinhoodAgentic-CryptoOpportunities"; Cycle = "opportunities"; Minutes = 5; Limit = 4 }
)
foreach ($cryptoSpec in $cryptoSpecs) {
    if ($Remove) {
        Unregister-ScheduledTask -TaskName $cryptoSpec.Name -Confirm:$false -ErrorAction SilentlyContinue
        continue
    }
    $cryptoAction = New-ScheduledTaskAction -Execute $cryptoShell -WorkingDirectory $cryptoRoot -Argument (
        "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$cryptoRunner`" -Cycle $($cryptoSpec.Cycle)"
    )
    # Daily cadence is visible in Task Scheduler; Python applies the actual NYSE calendar.
    # Weekday-only triggers cannot represent exchange holidays and early closes correctly.
    $cryptoTrigger = New-ScheduledTaskTrigger -Daily -At "00:00"
    $cryptoRepeat = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (
        New-TimeSpan -Minutes $cryptoSpec.Minutes
    ) -RepetitionDuration (New-TimeSpan -Days 1)
    $cryptoTrigger.Repetition = $cryptoRepeat.Repetition
    $cryptoTrigger.Repetition.StopAtDurationEnd = $false
    $cryptoPrincipal = New-ScheduledTaskPrincipal -UserId $cryptoUser -LogonType Interactive -RunLevel Limited
    $cryptoSettings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RunOnlyIfNetworkAvailable `
        -ExecutionTimeLimit (New-TimeSpan -Minutes $cryptoSpec.Limit)
    Register-ScheduledTask -TaskName $cryptoSpec.Name -Action $cryptoAction -Trigger $cryptoTrigger `
        -Principal $cryptoPrincipal -Settings $cryptoSettings -Description (
            "ETH/BTC paper $($cryptoSpec.Cycle): NYSE CLOSED only (holidays/early closes handled by Python). Flat during market hours: no data/model calls. Existing-position exits remain active. Awake/logged-in only; no real orders."
        ) -Force | Out-Null
}
if (-not $Remove) {
    Get-ScheduledTask -TaskName "RobinhoodAgentic-Crypto*" | Select-Object TaskName, State
}
