Make one spot paper decision for the exact candidate symbol (ETH-USD or BTC-USD) under the isolated policy. The completed 5M and 15M
continuation signal is an unvalidated experiment, not an established edge. Assess entry quality,
nearby invalidation, displayed liquidity, macro context, and realistic movement after costs.
Return BUY only for a supported opportunity. Do not force a trade merely because the market is open.
