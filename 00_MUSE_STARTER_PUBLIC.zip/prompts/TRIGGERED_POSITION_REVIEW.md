# Triggered Position Review

This is a cost-gated position-management wakeup. Read and follow `AGENTS.md`, including all
required strategy, risk, cost, execution, data, state, and skill files before using market tools.

The deterministic monitor result is appended below. Treat it as a trigger, not as execution truth.

1. Treat the supplied fresh Python-fetched Robinhood account, position, order, and quote snapshot as
   the current broker evidence; Robinhood MCP is intentionally unavailable in this model sandbox.
2. Reconcile that evidence against `state/POSITIONS.md` before considering any action.
3. Review every open option position before considering a new opportunity.
4. Validate event/earnings/news risk with the required tools when relevant.
   For Vibe market-data, technical, and stock-news calls, qualify bare US tickers with `.US` while
   keeping Robinhood symbols and contract IDs unchanged.
5. Re-run deterministic risk gates.
6. Return structured `HOLD`, `WAIT`, `EXIT`, `CANCEL_ENTRY`, or `NO_TRADE` JSON. In live mode, `HOLD`/`EXIT` must
   reference the supplied `position_id`; in paper mode use the supplied `paper_id`.
   `CANCEL_ENTRY` is valid only for an exact supplied pending live entry `order_id`; it creates an
   urgent manual-action alert and never invokes a broker cancellation tool. Leave `order_id` empty
   for every other action.
7. A live `EXIT` is only a recommendation. Python independently re-fetches the account, position,
   open orders, and live contract quote, repeats hard gates, runs Robinhood order review, and only
   then submits sell-to-close. Python also owns deterministic stop, target, and time exits.
8. You may not place, preview, cancel, or replace an order and may not edit project files or
   configuration. The scheduler owns execution, persistent state, and journal writes.

Fail closed on missing/stale data or tool failure. Do not search for a new trade during a
position-management trigger unless all existing-position duties are complete.
