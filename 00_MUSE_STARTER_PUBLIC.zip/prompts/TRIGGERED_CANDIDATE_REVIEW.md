# Triggered Candidate Final Review — Sol

Luna escalated one or more candidates from the model-free discovery/liquidity gate.

Read `AGENTS.md` and every required project file, then use the `robinhood-trader` skill. The source
event contains fresh read-only Robinhood account/position and qualified contract snapshots fetched
by Python; Robinhood MCP is intentionally disabled inside this model sandbox. Reconcile/manage
existing positions first. Inspect the supplied broad-news and capability-gated social evidence, then
complete Vibe technical/factor review, earnings/current news verification, contract selection, and
deterministic portfolio-risk checks.
For Vibe market-data, technical, and stock-news calls, qualify bare US tickers with `.US` (for
example, Robinhood `TLT` becomes Vibe `TLT.US`); keep Robinhood candidate symbols/IDs unchanged.
Treat an unavailable social backend as unavailable, never as
neutral sentiment. Determine observed social availability from
`market_intelligence.agent_reach.twitter_available` / `reddit_available` and successful labeled
entries in `market_intelligence.social.results`; the diagnostic `doctor_*` backend fields can be
null even when OpenCLI actually returned results.

Return a structured `BUY`, `HOLD`, `EXIT`, `CANCEL_ENTRY`, `WAIT`, `PASS`, or `NO_TRADE` decision. Manage any open
position before considering a new one. In live mode, use the supplied `position_id` for `EXIT` or
`HOLD`; in paper mode use `paper_id`. Leave the irrelevant position identifier empty. For `BUY`,
select exactly one `candidate_id` from the supplied fresh qualified set, choose `DAY` or `SWING`,
and provide a future ISO-8601 `hold_deadline` for a swing while leaving the position identifier
empty. The chosen style must appear in the
candidate's `entry_eligible_trade_styles`; after the day-entry cutoff, only a candidate explicitly
eligible for `SWING` may be bought. Re-check the supplied delta, gamma, theta, vega, IV, normalized
Greek metrics, DTE, spread, volume, and open interest as part of contract selection. For a live
`CANCEL_ENTRY`, the supplied `live_portfolio` must show an `ORDER_PENDING` entry, new material
evidence must invalidate or materially weaken its recorded thesis before fill, and `order_id` must
exactly match `live_portfolio.pending_entry.order_id`. This is an alert-only recommendation for the
user to cancel manually in Robinhood; do not call a cancellation tool. For every other action, use
an empty `order_id` and empty irrelevant IDs/deadline with `trade_style: NONE`. Always report the verified earnings/event window
in `earnings_event` and whether the intended hold crosses it in `holds_through_earnings`. The
discovery event can already contain UW data,
so do not falsely claim you formed a pre-query opinion after seeing it. Use the supplied UW
attribution record when present; otherwise set `pre_uw_action` to `UNAVAILABLE_BEFORE_QUERY`, state
the current action in `post_uw_action`, and explain that limitation in `what_uw_changed`.

`LIVE_EXECUTION_ENABLED` is authoritative. In paper mode, Python records a simulated ask fill and
manages it at the live bid. In live mode, this JSON is only a recommendation to the deterministic
executor: Python must independently refresh account, positions, orders, contract quote/Greeks, and
risk; run Robinhood's order review; and place only if no check blocks. Python owns the hard stop,
profit target, and time exit. You do not have a broker tool in this sandbox and may not place,
preview, modify, or cancel an order. Do not edit project files or configuration; return structured
JSON only.
