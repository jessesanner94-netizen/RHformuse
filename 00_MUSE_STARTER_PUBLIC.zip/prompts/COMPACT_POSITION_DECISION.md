# Compact Position Decision

Use only the supplied reconciled position/trigger packet. Do not call tools, browse, run commands,
or read files. Python independently enforces the hard stop, profit target, time exit, and fresh
Robinhood verification. Return `HOLD`, `EXIT`, `CANCEL_ENTRY`, or `PASS` as appropriate. Never delay
or loosen a deterministic hard exit. Return only schema-valid JSON.
