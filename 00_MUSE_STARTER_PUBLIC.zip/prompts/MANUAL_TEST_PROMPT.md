# Manual Test Prompt

Read `AGENTS.md` and the full required project policy, then run one complete trading-agent cycle in **dry-run mode**.

Do not place or cancel any live order even if `CONFIG.md` is accidentally enabled for live execution.

Requirements:
1. Reconcile Robinhood live positions/orders against project state.
2. Review open positions first.
3. Run the cheap candidate gate.
4. If candidates exist, use relevant Vibe/research/news/social/options/risk tools.
5. Use relevant sub-agents rather than skipping them.
6. Check earnings/event risk.
7. Produce proposed BUY / WAIT / PASS / HOLD / REDUCE / EXIT decisions.
8. For any proposed trade, run Robinhood pre-trade/order review but stop before placement.
9. Report missing configuration, tool connection, or ambiguous rules that must be fixed before live trading.
10. Update only dry-run-safe state/journal records.
