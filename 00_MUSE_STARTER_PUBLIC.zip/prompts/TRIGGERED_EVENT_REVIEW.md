# Triggered Material Event Review — Sol

This dry-run review was escalated by Luna after a model-free news change detector found new items.

Read `AGENTS.md` and all required project files, then use the `robinhood-trader` skill. Pull fresh
Robinhood truth, verify the material event with reliable current sources, reconcile every open
position, and produce a concise `HOLD`, `WAIT`, `EXIT`, `REDUCE`, or `NO TRADE` decision. Apply every
hard risk and event rule. `LIVE_EXECUTION_ENABLED` remains authoritative. Do not place, modify, or
cancel an order in this triggered review.
