# Scheduled / Automated Run Prompt

Use this exact project repository as the governing context.

First read the root `AGENTS.md` and every file it marks as required. Then execute `.agents/skills/robinhood-trader/SKILL.md`.

Mandatory behavior:
- actually call the relevant configured tools; do not substitute model memory for live market/account data
- reconcile and manage open positions before scanning for new positions
- run the cheap gate before expensive reasoning
- if there are no qualified new candidates and no open-position action is required, stop with a minimal status
- use sub-agents only as required by `strategy/SUBAGENTS.md`
- check earnings, current news, and relevant social sentiment for escalated candidates
- use Robinhood as the source of truth immediately before any order
- obey `LIVE_EXECUTION_ENABLED` and all hard risk settings
- update state/journal files after material decisions
- never trade to hit a revenue, API, subscription, or compute-cost target
