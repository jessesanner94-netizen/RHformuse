# Triggered News Triage — Luna

This is a bounded, ephemeral triage run caused by new model-free news hashes. It is not a
persistent watcher and it may not place, preview, modify, or cancel an order.

Read `AGENTS.md` and its required files. Use the `robinhood-trader` skill. Focus only on the new
items in the supplied event. Verify potentially material claims with current reliable sources;
social or an aggregation headline is not authority. Check whether the item changes an existing
position thesis, event risk, exit urgency, or the eligibility of a newly screened candidate.

End with exactly one compact JSON object and no Markdown fence:

{"material": false, "action": "IGNORE", "symbols": [], "candidate_ids": [], "reason": "..."}

Allowed actions are `IGNORE` and `ESCALATE_SOL`. Use `ESCALATE_SOL` when the event could materially
change a position or candidate decision, or when materiality remains uncertain after a reasonable
verification attempt. Do not recommend an order; Sol and deterministic risk gates own final review.
