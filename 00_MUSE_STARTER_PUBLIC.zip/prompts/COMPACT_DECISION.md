# Compact Options Decision

Use only the supplied deterministic decision packet and the compact agent policy already loaded.
Do not call tools, browse, run commands, or read files.

Return one structured decision. Prefer `BUY` or `PASS`. Use `WAIT` only for an otherwise qualified
setup requiring one exact near-term underlying-price trigger; populate exactly one of
`reconsider_above` or `reconsider_below`, plus `decision_valid_until`. For `PASS`, leave both
thresholds null and set a reasonable cache expiration. For `BUY`, leave both thresholds null.
For `BUY`, `WAIT`, or `PASS`, copy the supplied candidate's `candidate_id` exactly into the output.

The candidate has already passed Python's hard pre-model gate. Read
`python_gate.directional_alignment_score` as contract-direction adjusted: positive supports either
a call or a put. Do not misread a negative raw technical score as bearish evidence against a put.
Do not reject solely because optional uncalculated portfolio analytics are omitted, news/social is
neutral, or one lower-priority timeframe differs. `PASS` still requires a material weakness in the
remaining short-horizon setup; do not demand perfect unanimity.

For a `DAY` candidate, prioritize the supplied consecutive-bar intraday structure plus 5M and 15M
evidence. Treat 4H and 1D as context, not automatic vetoes. `python_gate.setup_mode` may be
`FLOW_LED_REVERSAL`: Python uses that only when strongly direction-supportive tagged option flow is
paired with non-opposing opening-range/intraday structure and every liquidity, Greek, event, and risk
gate has passed. This is a legitimate momentum/reversal setup, not an instruction to buy. Flow can
include hedges, spreads, rolls, opening trades, or closing trades, so require one additional concrete
strength in the packet; do not require every lagging trend indicator to have already turned.

Entry timing is separate from direction. Read `python_gate.countertrend_entry_timing.required`:
when true, Python requires supportive 5M AND 15M evidence and fresh completed-candle level
confirmation. An old session-wide sweep is not that confirmation. When false, assess continuation
from current intraday structure; do not impose the countertrend retest/rejection requirement.
Distance above the session low or below the session high is location, not a cap on remaining room.
New extremes are possible. Oversold/overbought RSI and proximity to an extreme alone do not prove
exhaustion. Assess momentum, opposing structure and invalidation together, without assuming either
continuation or reversal is guaranteed. Do not invent an unprovided support/resistance target.
For PASS, name the concrete packet evidence that materially weakens this setup; a missing optional
confirmation, routine theta cost, or extreme location alone is insufficient. Qualification is not
an automatic BUY: actual opposing intraday structure or another material weakness can justify PASS.

Robinhood's expiration-based `chance of profit` is intentionally omitted. Do not estimate, infer,
or use expiration chance-of-profit as a reason to reject a trade intended to close before
expiration. Evaluate whether the configured profit target is plausible within the planned holding
period using the supplied price structure, Greeks/IV, theta, liquidity/spread, technical evidence,
flow, catalysts, and risk state.

Python has already enforced the style-specific theta ceiling. Theta below that ceiling is a cost and
urgency factor, not by itself a reason to reject an otherwise strong day setup. Reject when decay plus
the remaining evidence makes the configured target implausible, and state that combined weakness.
Evaluate theta over the intended holding horizon. A daily sensitivity is neither the full cost of
a short intraday hold nor a guaranteed realized loss; do not invent precise linear decay estimates.

The output is a recommendation only. Python will independently refresh Robinhood state, contract
quotes/Greeks, risk, and order review before any live order.

When the packet specifies DAY-only options, use DAY for all entries and watches.
Judge direction and timing primarily from current5M/15M intraday evidence. Daily/4H
trend is context, not an automatic veto of opposite-direction day trades. Do not
require a swing thesis or overnight hold. Respect the supplied DAY exit deadline
and all Python/risk/event checks; PASS and WATCH remain valid decisions.
