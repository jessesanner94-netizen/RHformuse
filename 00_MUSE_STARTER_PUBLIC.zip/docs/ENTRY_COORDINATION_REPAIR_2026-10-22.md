# Entry review and position-monitor coordination — October 22, 2026

The user authorized fixing the local coordination problem after today's winning trade closed, while preserving the working live strategy. No missed-session or hypothetical-return analysis was performed.

## Finding and reproduction

At 09:51 and 09:56 ET, qualified SPY put attempts were blocked before submission by `live_pre_submit_state_expired_or_changed`. Immediately before each completed opportunity cycle, the resident monitor recorded `RuntimeLockUnavailable`. The entry process held the live ledger lock while awaiting Robinhood's read-only order review. A concurrent monitor could fetch its broker snapshot but could not obtain that ledger lock; it published an unhealthy heartbeat, which could block the entry's final monitor-health check. The recorded composite rejection alone cannot exclude another simultaneous freshness failure.

A synthetic integration test reproduced this mechanism with the original source: invoking the actual resident monitor during an entry review returned ATTENTION / RuntimeLockUnavailable, invalidated its heartbeat and blocked submission. No real broker, model or notification interface was used in this reproduction.

## Repair

Only `tools/live_trading.py::apply_live_decision` changed in production code. Entry processing now runs two bounded phases:

1. Acquire the existing ledger lock and run all existing ledger/exposure/risk/timing validations. Release the lock before awaiting the single, read-only Robinhood order review.
2. Reacquire the same lock, load the latest ledger and repeat those validations. Validate the cached review against the exact intended order and retain the existing final 20-second quote/snapshot freshness, configuration, session and resident-monitor checks. Persist the submission reference before calling placement, with the existing lock and uncertain-submission handling still in force.

The monitor can therefore reconcile or protect an existing position while an entry review is in flight. A new pending order, changed position, green lock or exhausted risk allowance still blocks that entry. Concurrent reviews cannot create duplicate orders. A failed monitor heartbeat is never treated as healthy merely because another process is busy. There is no retry, delayed-entry rule, price chasing, extra broker request or changed timeout.

The structural comparison verifies that all original locked validation statements are identical, and the submission block is identical except for receiving the already completed review. All other production functions, including order submission and exit management, are unchanged. CONFIG, strategy, prompts, broker transport, monitor, locks, quiet finish and alert grouping match their pre-repair hashes (31 protected files).

## Verification and installation

- Ten new offline regressions cover the original collision, changed green lock/order/risk/position state during review, overlapping entry reviews, stale inputs, genuine monitor failure, review cancellation and an existing position's stop proceeding during entry review. All order interfaces are synthetic.
- The selected combined suite passed: **135 tests in 52.75 seconds**. The isolated copy blocks network connections and DNS. An initial sandbox run stalled in Python's executor shutdown; the completed run used normal-host execution with the service's single-thread numerical-library settings and the same network-denying test fixture. No live settings were changed for testing.
- Scoped Ruff checks pass. A broader lint attempt encountered five unrelated import-order findings in research tests; those files were not modified.
- A direct read-only Robinhood snapshot at **10:47:27 ET** confirmed zero option positions and zero open option orders. The durable green lock and flat local ledger were checked again at installation.
- The tested source was atomically installed at **10:48:00 ET**. The current position-monitor process does not use the changed entry function; its management functions are identical. Each scheduled opportunity process imports the source afresh. No service restart, timer change, forced trading cycle, order review, live order, cancellation or production notification was performed by this maintenance run. Today's green lock remains in force.

Evidence and rollback source: `docs/coordination_repair_20261022/`. `RESULTS.json`, `repair.patch`, `structural_review.json`, `regression_final.log` and the read-only broker check record the exact scope. To roll back this repair, restore only `live_trading.before.py` to `tools/live_trading.py` during a verified flat maintenance window; do not restore historical ledgers, CONFIG, credentials or schedules.

The repair is verified with synthetic overlapping operations. A future naturally qualified live entry remains the production verification boundary; no trade was forced to demonstrate it. This repair does not guarantee elimination of unrelated broker/network timeouts or profitable entries.
