# Paper options quality gate and daily green lock — October 8, 2026

User-authorized prospective SPY/QQQ paper changes. Live remains disabled. No real
orders, task changes, historical ledger rewrites, or model smoke calls are required.

## Net reward-to-risk admission

`MIN_NET_REWARD_TO_RISK: 1.00` is an inclusive minimum. Python checks each
contract before technical research, JEV ranking, Luna review, and cached BUY reuse.
It checks again using the fresh fill ask in every paper ledger, including the DAY
control that bypasses Luna's veto. JEV still ranks only Python-qualified contracts;
Luna remains the final judgment for primary and the primary-style comparator.

For one contract, use the existing ledger's accounting:

- Premium = ask × 100, rounded to cents.
- Entry debit = premium + `paper_side_cost(config)`.
- Stop and target prices use the existing four-decimal premium triggers.
- Target/stop proceeds = trigger × 100, rounded to cents.
- Net target/stop P&L = proceeds − premium − entry side cost − exit side cost.
- Net reward = net target P&L; net risk = negative net stop P&L.
- Net ratio = net reward / net risk. Compare cent-dollar amounts using Decimal;
  do not round the ratio before admission.

The existing side cost is $0.05 fee + $1.00 slippage = $1.05. The $2.10 planning
buffer is not charged again. This changes eligibility, not fee assumptions or exits.
The 25% stop and 30% target remain unchanged. A $50 premium has $12.90 reward and
$14.60 risk and fails; an $84 premium has $23.10 reward and $23.10 risk and passes.

Reject nonpositive reward, nonpositive/invalid risk, and ratios below the minimum.
Missing, nonfinite, boolean, zero/negative threshold, or invalid cost settings fail
closed for new entries. These admission errors do not disable protective exits.
Rejection reason is `net_reward_to_risk_below_minimum` when that comparison fails.
Decision packets, Python rejection records, entry events and stored positions retain
`net_reward_risk`, including dollar reward/risk, ratio, threshold and cost components.
Existing cycle JSONL and JEV research rejection telemetry preserve this evidence.

This is a conservative P&L projection at the configured triggers, not an expected
return forecast or guaranteed stop fill. Existing assumed historical TP-limit fills
round the limit upward to a cent; the gate does not assume that extra upside or that
historical evidence will be available. A current bid crossing a trigger can give a
different fill. Neither exit policy is changed. The expired winner-continuation trial
does not tune these projections or enroll new comparator positions.

## Independent daily-green-lock paper comparator

`PAPER_DAILY_GREEN_LOCK_ENABLED: true` enables a separate primary-style ledger at
`state/daily_green_lock/`. It initializes prospectively from `PAPER_STARTING_CASH`
($369 currently), with no copied historical trades or balances. It cannot execute
broker orders and is disabled when live execution is enabled, even if its switch
remains true. Entry APIs also fence this ledger against future live settings.

The comparator uses the shared primary discovery/JEV/Luna decision stream, just as
the existing control shares that funnel. It accepts only fresh completed Luna BUYs;
PASS/WAIT/WATCH and cached decisions cannot open comparator positions. It shares the
post-decision quote but rechecks freshness, contract eligibility, cash, ticker exposure,
daily entry count, planned-loss budget and net reward-to-risk against its own ledger.
It adds no JEV/Luna calls and cannot influence primary selection or risk state.

This is a conditional forward comparison: when primary's discovery/account/exposure
gates suppress an opportunity, the comparator receives no independent selection.
Starting equity and later balances can differ. It does not measure independently
selected trading opportunities or a historical counterfactual. Source primary and
variant position IDs, statuses and skip reasons are linked in its own
`COMPARISONS.jsonl`, without changing the existing primary/control `PAIRS.jsonl`.

Immediately after any close is booked, including a software stop/target/time exit,
model close or authorized assumed paper TP fill, inspect this ledger's cumulative
`day.realized_pnl`. Each closed trade includes both modeled entry and exit costs.
The first strictly positive cent-dollar daily total latches `green_lock_active`.
Exactly zero, a profitable individual close that leaves the day negative, and
unrealized gains do not activate it. Opening costs are recognized in realized P&L
with the closed trade, using the existing accounting.

The lock prevents later entries, with reason `daily_green_lock_active`, even if a
later existing-position loss takes daily realized P&L negative. It never forces a
close or pauses existing exit monitoring. The admission check and close/activation
state changes use the same portfolio lock. Already-open positions retain normal
quote, hard-stop, target and calendar-aware deadline management.

The lock resets with the ledger's Eastern date rollover on the next cycle; holiday
and weekend entry gates still prevent entries until a valid trading session. No
reminder or reset task is added. The next valid trading day starts with realized
daily P&L zero, no lock, and a zero skipped-entry count.

`PORTFOLIO.json` and `SUMMARY.md` expose `lock_activated_at`,
`realized_pnl_at_activation`, daily realized P&L, active state and
`skipped_entry_count`. The count records BUY entry attempts blocked by the lock;
Luna PASS/WATCH, cache and other skips keep their own reasons. `EVENTS.jsonl` labels
entry, exit, skip and `DAILY_GREEN_LOCK_ACTIVATED` events with
`strategy_variant: daily_green_lock` and `mode: PAPER`. The activation timestamp is
the processing/booking time, including assumed historical TP fills; it is not
backdated. Completed new-cycle totals expose separate comparator entries/results
in the existing evaluation report. Primary/control account P&L and paired results
remain separately calculated.

## Files changed

- `CONFIG.md`
- `tools/paper_trading.py`, `tools/paper_runner.py`, `tools/paper_experiment.py`
- `tools/decision_context.py`, `tools/scheduled_cycle.py`, `tools/experiment_report.py`
- `tests/test_paper_quality_gates.py`, `tests/test_paper_repair_integration.py`
- `tests/fixtures/CONFIG.resolved-test-only.md`
- `tests/fixtures/CONFIG.small-account-proposal-test-only.md`
- `strategy/STRATEGY.md`, `strategy/RISK.md`, `strategy/EXECUTION_RULES.md`
- `strategy/COST_POLICY.md`, `state/DAILY_STATE.md`
- `state/daily_green_lock/README.md`, this document

Verification: **553 tests passed** (39.49 seconds); `ruff check tools tests` clean.
Results are also recorded in `state/DAILY_STATE.md`. Tests use temporary
ledgers and synthetic/stubbed market/model data. The complete suite requires an
unrestricted Windows asyncio loopback socket; sandbox runs stalled before coroutine
execution. No system or event-loop settings were changed to run it.
