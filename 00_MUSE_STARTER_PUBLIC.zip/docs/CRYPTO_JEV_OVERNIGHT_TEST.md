# Revised JEV comparison — September 21, 2026

The initial September 20 test used four samples by 02:05 ET: PASS, PASS, WATCH, PASS.
The watch invalidated. Luna saw JEV scores and cited its thresholds; these decisions
are not an independent test of the veto. No paper entries resulted.

The user authorized error diagnosis and a better comparison on September 21.
The existing enabled crypto tasks pick up this revision; no new Windows task is created.

## Fixed windows (Eastern time)

| Window | Maximum sampled reviews |
|---|---:|
| September 21, 06:30–09:30 | 2, one per coin |
| September 21, 16:00–20:00 | 1 |
| September 21, 20:00–September 22, 00:00 | 1 |
| September 22, 00:00–04:00 | 1 |
| September 22, 04:00–09:30 | 1 |

Overnight maximum is two per coin. Unused windows expire; no early borrowing or catch-up.
All reservations use the shared 20-call allowance and 30-minute crypto cooldown.
The fixed experiment ID is crypto-jev-blind-2026-09-21. The code expires it at
09:30 ET September 22 even if CRYPTO_JEV_OVERNIGHT_TEST remains true.

Only valid active JEV soft-score rejections may be sampled. Missing/error responses,
invalid scores, or excessive false-breakout risk still block. All Python risk,
price, macro, liquidity, trend, volume and final-fill gates remain binding.
The first eligible candidate in each available slot is selected. No trade is forced.

## Blind review and evidence

Within the test windows, Luna receives the market, technical, displayed-book, risk,
cost and macro evidence with no JEV scores, thresholds, verdict or sampling label.
This applies to normal JEV passes too. The corrected JEV question remains versioned
crypto-review-trial-v1 and reverts outside the dated windows. JEV evidence stays in
Python's separate audit records, not in the decision agent's input.

jev_trial_reserved records the slot and observation before model launch. Failures
consume a sample. luna_decision records independent BUY/PASS/WATCH; jev_trial_outcome
records the final result, including post-model Python blocks. Trial fills link to
paper exits via position ID. The existing trade notifications remain enabled.

Run `.venv/Scripts/python.exe -m tools.crypto_trial_report` for a read-only summary
with decisions, execution status and realized net P&L where a trade has closed.
No model or provider calls are made by the report. Four overnight samples cannot
establish profitability. A PASS followed by a rally is not a simulated winning trade.

## Error diagnosis

Live read-only reproduction found Coinbase BTC quotes 20–36 milliseconds ahead of
this PC's clock. The public adapter allowed up to five seconds of skew, while the
paper validator rejected any negative age. This reproduced the logged ValueError.
The router now waits for up to five seconds of bounded skew before strict validation;
it preserves exchange timestamps and never accepts future, stale or crossed quotes.
Six post-fix live quote checks passed. This identifies a real cause, not proof that
every historical ValueError had the same cause; old logs omitted that detail.

Cycle errors now log safe code locations and allowlisted error codes without raw
provider responses. Unpinned Robinhood network failures now permit the already
authorized public-price fallback; held positions remain pinned to their venue.
