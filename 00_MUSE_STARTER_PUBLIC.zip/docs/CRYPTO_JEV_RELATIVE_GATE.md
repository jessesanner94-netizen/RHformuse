# Crypto JEV above-average gate

Authorized September 22, 2026, for ETH/BTC spot paper only. Options keep ranking.
Python must qualify the setup first. Successful JEV setup_quality must strictly
exceed the arithmetic mean of prior successful Python-qualified observations for
the same coin, exact question versions and model. Current/future observations and
results not yet available at the comparison timestamp are excluded. All matching
prior observations count; repeated scans are observations, not independent trades.

The fixed 0.85 setup, 0.80 escalation and 0.25 false-breakout gates no longer decide
crypto admission in this mode. No extra margin is applied. An empty matching history
allows a valid evaluation to bootstrap to Luna; unavailable/invalid JEV or history
errors block. The crypto-review-trial-v1 question wording persists to avoid changing
the score population when the former dated trial expires. New model/question
versions start separate populations. The former dated sampling bypass is disabled.

Record current score, prior mean, sample count, model, versions and admission reason
in crypto events and linked JEV events. Original JEV evaluations remain intact for
audit. Luna does not receive JEV scores/verdict. Python gates, price freshness,
WATCH, 30-minute cooldown, shared 20-call limit and final fill checks still apply.
No real orders, scheduler changes, resets or forced model calls are part of this change.

This selects relatively higher JEV scores; it does not ensure future scores exceed
past averages or establish realized trade quality. All-history averages can adapt
slowly when regimes change; no rolling-window policy is silently substituted.

Validation:493 tests passed; full tools/tests Ruff clean. Enabled in CONFIG.md.
