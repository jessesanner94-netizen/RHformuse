# Resting order-book features

`tools.orderbook.collect_orderbooks()` makes one read-only, bounded call to Robinhood's
`get_equity_price_book` endpoint for one to four symbols. The MCP response boundary is:

```json
{
  "data": {
    "books": [{
      "symbol": "SPY",
      "updated_at": "2026-09-18T14:00:00Z",
      "asks": [{"price": "660.01", "quantity": 100}],
      "bids": [{"price": "660.00", "quantity": 120}]
    }],
    "errors": [{"symbol": "QQQ", "error": "..."}]
  }
}
```

The local Robinhood adapter returns the inner `{"books": ..., "errors": ...}` object.
These are displayed, resting orders. They are not executed trades, aggressor side, exchange-wide
depth, or a complete order lifecycle. Empty bid/ask arrays, such as a Sunday SPY or QQQ request,
produce `NO_DEPTH`; they do not produce a neutral or directional signal.

## Validation and retention

Each book requires a timezone-aware ISO timestamp, finite positive price and quantity, strictly
ascending asks, strictly descending bids, unique prices on each side, and an uncrossed spread. A
side is bounded to 1,000 levels. Books older than 30 seconds or more than five seconds in the future
are rejected. A timestamp at or behind the most recently stored snapshot for that symbol is rejected
as `DUPLICATE` or `OUT_OF_ORDER`. The SQLite store keeps raw valid price/quantity levels for a
rolling 60 minutes and discards older rows. A historical query fences both `updated_at` and
`observed_at` at its requested as-of time, so a later run cannot leak into an earlier summary.

For every valid book, `current`, `1m`, `5m`, `15m`, and `60m` summaries report sample count,
coverage, gaps, and freshness. `current` is `CURRENT_ONLY`; a one-sample historical window is
`INSUFFICIENT_HISTORY`, and under-80%-covered windows are `PARTIAL`. The top-level
`temporal_available` is false until at least one historical window has sufficient coverage.

## Features and limits

For a bid price `b`, ask price `a`, bid size `q_b`, and ask size `q_a`, spread is `a − b`, midpoint
is `(a + b) / 2`, and microprice is `(a*q_b + b*q_a) / (q_b + q_a)`. Each imbalance is
`(bid_depth − ask_depth) / (bid_depth + ask_depth)`: near uses the first three levels, cumulative
uses all displayed levels, and weighted uses each level's size divided by its distance from midpoint.
Depth velocity is `(current_depth − prior_depth) / elapsed_seconds`; spread delta is
`current_spread − prior_spread`.

The summary also tracks fixed `(side, price)` liquidity zones over each window, retaining at most
six zones ordered by their maximum displayed size and at most twelve latest appearance/disappearance
events. A zone reports first/last seen, initial/max/current size, persistence seconds, growth or
shrink, and relative side-depth share. This retains a shrinking former wall after another price
becomes the largest wall.

Appearance, disappearance, size changes, and quote migration have explicitly ambiguous causes:
they may result from placements, amendments, cancellation, hidden liquidity, or executions. The
test and rejection fields are observations of displayed-book changes only and are never proof of a
test, rejection, trade, or intent. Absorption and exhaustion always remain `UNAVAILABLE` because
this provider supplies no executed-trade prints.

A future provider supplying genuine trade prints must enter through a separate, typed provider
boundary. It must preserve print timestamp, price, size, venue, and any provider-supplied side;
side must remain unknown when the provider does not supply it. No resting-depth feature may be
silently relabeled as executed flow.

The collector does not poll, schedule itself, place orders, or invoke an order endpoint. Its default
provider call times out after ten seconds and returns `UNAVAILABLE` on timeout or provider failure.
