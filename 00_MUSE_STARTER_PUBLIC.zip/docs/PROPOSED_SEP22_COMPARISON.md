# Superseded by authorized options ranking — September 21, 2026

The user chose ongoing paper-options ranking instead of this bounded comparison.
See CONFIG.md `OPTIONS_JEV_RANKING_ONLY`. The proposal below is historical and was
not enabled. Crypto remains unchanged.

# Proposed September 22 paper comparison — pending user approval

Purpose: collect usable blind Luna reviews after two of September 21's three
options samples failed before model reasoning. This is not a profitability claim.

- SPY/QQQ options only; September 22, 2026, 09:50–15:30 America/New_York.
- At most three initial JEV soft-score rejection reviews: one each during
  09:50–11:45, 11:45–13:30, and 13:30–15:30; at most two initial samples per ETF.
- If a sampled review creates a valid WATCH, allow at most one additional blind
  Luna review for that exact watch after its fresh wake conditions are met.
  This continuation does not require JEV's setup/escalation soft scores to pass.
- Both initial reviews and continuations still require valid JEV responses,
  false-breakout risk <=0.25, fresh Python qualification, all existing risk and
  fill checks, and available shared 20-call budget. Maximum six trial calls total.
- Luna remains the final BUY/PASS/WATCH reviewer; paper execution only.
- Preserve JEV's numeric thresholds, log every gate and outcome, and expire
  this exception at 15:30 September 22. No automatic renewal.

The existing options trial expired September 21 at 15:30. Extending it or adding
watch continuations changes routing policy and requires approval under AGENTS.md
section 11. This proposal has not been enabled.
