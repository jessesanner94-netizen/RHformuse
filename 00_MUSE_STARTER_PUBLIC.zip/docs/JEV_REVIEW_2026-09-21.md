# JEV routing review — September 21, 2026

This is a read-only evidence review of the JEV SQLite store, the September 21
opportunity log, the crypto paper ledger, and the routing implementation. The
snapshot ended at 16:20 ET on September 21. It makes no profitability claim and
does not change a threshold, trial, configuration value, or live-execution setting.

## Current conclusion

Active paper JEV is an upstream veto of **Luna reviews**, not an entry engine. In
the available sample it allowed **0 of 182** successful JEV evaluations to take the
ordinary route to Luna. It therefore prevents every ordinary final review today;
it has not demonstrated that it prevents too many *trades*, because there are no
forward outcome labels for the rejected candidates and final Python/Luna/fill gates
would still apply after a JEV pass.

The active policy requires all three conditions:

| Condition | Active value |
| --- | ---: |
| `setup_quality` | at least 0.85 |
| `escalate_to_luna` | at least 0.80 |
| `false_breakout_risk` | at most 0.25 |

All 182 successful scores failed at least one condition. Most failed both the
setup and escalation conditions. This is a calibration observation, not evidence
that the thresholds should change.

## Evidence snapshot

`state/research/jev.sqlite3` contained 215 observations: 182 `OK`, 31
`NOT_EVALUATED_PYTHON_REJECTED`, and two `ERROR` (`invalid_response`). The successful
evaluations broke down as follows.

| Symbol | OK evaluations | Mean setup | Mean escalation | Mean false-breakout | Policy passes |
| --- | ---: | ---: | ---: | ---: | ---: |
| BTC-USD | 28 | 0.60 | 0.52 | 0.17 | 0 |
| ETH-USD | 52 | 0.70 | 0.49 | 0.18 | 0 |
| QQQ | 42 | 0.63 | 0.52 | 0.22 | 0 |
| SPY | 60 | 0.66 | 0.50 | 0.26 | 0 |
| Total | 182 | 0.65 | 0.50 | 0.21 | 0 |

The score distributions make false-breakout risk a secondary blocker. The observed
combined failure patterns were: BTC 27 setup+escalation and one setup-only; ETH 51
setup+escalation (one also false-breakout); QQQ 41 setup+escalation (one also
false-breakout); SPY 25 setup+escalation and 35 all three.

Successful JEV requests recorded 2,426,702 input tokens and 99,330 output tokens.
This is usage reported by JEV, not a price estimate. It yielded no ordinary
escalations, so its current compute efficiency should be reviewed before expanding
coverage.

## Bounded comparisons

The September 21 SPY/QQQ comparison reserved all three slots before its 15:30 ET
expiry. Two sampled Luna calls failed because the earlier WATCH transport schema was
rejected; neither produced a decision or a paper fill. The third returned `WATCH`.
The slots cannot be reused without new authorization.

The revised crypto blind comparison remains active until September 22 at 09:30 ET.
At the snapshot it had two reservations: ETH in the morning window received Luna
`BUY`, then exited at its two-hour deadline for net paper P&L of about -$0.06; BTC
in the early window received `PASS`. Three overnight windows remain. The prior
September 20 crypto comparison is excluded from causal interpretation because Luna
received JEV evidence.

The current JEV replay has no measured directional-outcome rows and no realized
outcomes connected to its routing events. It cannot calculate winner retention,
loser rejection, expectancy, or an actual saved-call counterfactual.

## Routing telemetry repair

Historical `candidate_suppressed` rows are intentionally untouched. Before this
review, `record_routing` compared an evaluation only with the final selected packet.
When every candidate had already been filtered, that packet was absent and the event
was recorded as `candidate_not_selected`, even when the route had an exact
`jev_escalation_filtered` or `jev_active_unavailable` reason.

New events now match `jev_evaluations[].candidate_id` with the existing
`suppressed_candidates[]` record and retain the exact reason. This is an attribution
repair only: it neither changes gating nor permits a model call or paper fill.

## Funnel terminology limitation

The apparent mismatch between the daily log's `python_evaluated` count and JEV
observations is definitional, not yet proven to be a counting defect.

`tools/scheduled_cycle.py` accumulates `evaluated_attempts` from each retry of
`build_decision_packet`; `tools/experiment_report.py` exposes that sum as
`python_evaluated`. `tools/decision_context.py` defines the count as candidates
examined by the Python packet builder. A JEV observation is created only after the
builder returns a selected candidate and `evaluate_candidate` runs. Separately,
Python rejections are written to the JEV store for evidence. Thus the two fields do
not describe the same stage and should not be divided into a conversion rate.

No counter or funnel behavior was changed in this review. A future reporting change
should define distinct immutable stages: Python examined, Python qualified, JEV
attempted, JEV valid, JEV policy pass, trial sampled, Luna reserved/completed, and
paper action.

## Recommendation requiring approval

Allow the already-authorized crypto windows to finish, then retain the current
thresholds until a prospective diagnostic has enough blinded observations and
forward labels. If the user wants to assess whether the veto is too strict, a new
bounded, explicitly authorized blind sidecar should collect valid soft-score
rejections without changing the active trade policy. A threshold change, a renewed
options comparison, or persistence of the crypto trial question beyond its stated
expiry are policy decisions and are outside this repair.
