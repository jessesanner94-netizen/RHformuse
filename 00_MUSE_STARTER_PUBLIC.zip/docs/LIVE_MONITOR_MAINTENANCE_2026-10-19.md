# Live monitor maintenance — October 19, 2026

User authorized quiet finished-day behavior, grouped transient failure notifications, and safe connection-overhead improvements. This changes operations, not trading signals, sizing, stops, targets, entry/exit order semantics, risk gates, or daily green-lock accounting. CONFIG and strategy/prompts remain unchanged.

## Quiet finished-day operation

The executing resident monitor can reduce broker reconciliation to once per 300 seconds only after a successful, fresh, complete broker snapshot and normal reconciliation establish all of:

- Today’s Eastern day, and either the enabled sticky green lock or the existing hard daily loss threshold. Loss mode additionally requires both broker daily loss and persisted realized daily loss at/beyond the smaller dollar/percentage limit; insufficient remaining planned entry budget alone does not qualify.
- Explicit empty broker option positions and all queried open-order states; empty reconciled local positions and pending orders; no blocking/attention action or unresolved submission.

Local ledger/config/date checks still run at the existing 10-second cadence. Quiet heartbeats explicitly set entry_safe=false, record the last real broker check and next reconciliation time, and label skipped broker checks. They never present a cached snapshot as fresh entry authorization. Quiet eligibility is cleared by a config/day/epoch change, nonempty/unreadable/invalid local state, failed broker reconciliation, or broker discrepancy. Ordinary polling then resumes. Existing positions, pending/ambiguous orders and protective exits do not enter quiet mode. A manual broker change while quiet can take up to the five-minute reconciliation interval to detect; externally placed positions retain existing ownership/reconciliation handling.

The process and systemd timers remain enabled; it exits through the existing market-calendar boundary. Each restart requires a fresh broker check before quiet mode can re-arm. No persisted quiet flag disables tomorrow’s trading. The five-minute opportunity task retains its own reconciliation and existing green-lock/risk checks, so total broker traffic also includes that process.

## Failure diagnostics and phone notices

Every monitor failure still writes a diagnostic record, now including safe exception type, failed high-level operation and conservative local exposure flag. No raw exception text, credentials or tokens are logged.

Snapshot/rate-limit failures are grouped with a ten-minute successful-phone-delivery cooldown. Three consecutive failures (or a continuously failing interval of at least 30 seconds) can escalate earlier, as can newly present/unknown exposure. Known/unknown exposure is local evidence, not proof of current broker flatness after a failed request. Rate-limit backoff uses the same exposure classification so it does not create a false severity increase.

Failed phone deliveries do not consume the successful-delivery cooldown; retry attempts are limited to once per 30 seconds. Alert delivery remains asynchronous. Order/fill/reconciliation messages are queued in order rather than discarded if another notification is in flight. Order-operation failures are not grouped as snapshot noise. Existing 429 Retry-After handling and all monitoring/order checks remain independent of alert suppression. Incident notification state is in memory and resets on service restart.

## Connection pool

Only the resident snapshot reader reuses its httpx TCP/TLS connection pool (30-second idle keepalive). Every snapshot still creates a new OAuth provider, reloads credential storage when required, selects the account afresh, initializes a fresh MCP session, fetches the same broker fields sequentially and applies the existing completeness/freshness checks. Reloading OAuth avoids retaining a rotated refresh token from the separate opportunities process. No market data, account selection or MCP session is cached across ticks.

The pool is scoped to one async run and closed on shutdown. Borrowing is rejected for non-snapshot actions. Review, placement and order-status interfaces keep their existing separate connections and no order retry is added. The eight-second monitor deadline, ten-second active interval and twenty-second freshness bounds remain unchanged. This is a bounded connection-overhead improvement; no claim of measured live latency improvement or elimination of provider timeouts is made before operation.

## Verification and deployment

Source changes: tools/live_fast_monitor.py, tools/robinhood_mcp.py. Focused regression additions: tests/test_live_fast_monitor.py, tests/test_robinhood_mcp.py. One independent Sol safety review informed the final changes. Test broker calls and notifications are synthetic; no test trade, production notification, paid model probe or manual bot launch occurred.

Test results are recorded below on completion. Protected policy/config/prompt and production options ledger/event hashes were captured before work and checked after implementation. Runtime service inspection confirmed the positions service inactive after normal close and existing timers next scheduled Tuesday October 20 at 09:30:00/09:30:15 Eastern. Changes load at the next normal launch; no scheduler change or service restart is required.

Final validation: **70 monitor/adapter tests passed in 23.53s**, plus **96 existing execution/risk/reconciliation/notification/portability tests passed in 39.68s**. Ruff tools/tests clean. The full historical run hit its 180-second bound after 352 passing case markers, with no reported failure; it is explicitly incomplete and is not claimed as a full-suite pass. Historical full-suite setup uses only an isolated source copy with production policy preserved except live=false/paper=true, synthetic dependencies, and DNS/socket guards. Initial setup attempts exposed an incorrect generic test profile and a missing research test module; both were corrected in the isolated copy. A no-network asyncio.to_thread probe also confirmed that sandbox execution stalls thread callbacks, so the isolated regression ran outside that sandbox. Production state/config were never used as writable test fixtures.

All 31 protected CONFIG/strategy/prompt/live ledger/event hashes match the pre-edit snapshot. Machine-readable evidence, source hashes and a reviewable source patch are saved beside this report. Final focused tests include the final malformed-day and rate-limit/exposure safeguards. No claim of observed market-hours latency or notification behavior is made before the next normal session.
