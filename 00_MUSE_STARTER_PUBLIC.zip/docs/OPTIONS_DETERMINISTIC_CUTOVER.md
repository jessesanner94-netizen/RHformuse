# Options deterministic cutover — October 9, 2026

Python qualifies SPY/QQQ direction, technical setup, contracts, events, timing,
net economics and risk. JEV ranks up to three qualified contracts; its scores
cannot veto direction or override a deterministic gate. The selected contract
becomes a short-lived deterministic BUY packet. Luna/Codex entry and qualitative
position calls, PASS/BUY caches, WATCH claims and Luna budgets are bypassed.
Invalid/unavailable JEV ranks fail closed; all lower shortlist candidates also
need valid ranking evidence. Exits use the unchanged deterministic rules.

Live execution remains **disabled**. Implementation and tests prepare the
live executor, but this work does not activate unattended real-money trading.
No broker order or test order is authorized by this document.

## Exact settings and accounting

- `MIN_NET_REWARD_TO_RISK: 1.00`, inclusive; unchanged 30% target / 25% stop.
- Existing modeled cost per side: $0.05 fee + $1.00 slippage = $1.05.
  Entry debit = premium + one side; exit net P&L = proceeds − premium − both
  sides. Reward is target net P&L, risk is negative stop net P&L. Reject reward
  ≤0, invalid/zero risk, or ratio below minimum. Never double-charge the $2.10
  planned-risk buffer. Paper uses cent accounting and four-decimal premium
  triggers; live admission uses the exact two-decimal submitted entry limit.
- $50 premium yields $12.90 reward / $14.60 risk, rejected despite a favorable
  gross target. $84 yields $23.10 / $23.10 = exactly 1.00, admitted if every other
  gate passes. Packets, rejections, events and positions retain dollar metrics.
- Daily loss limit: smaller of $45 and 12.5% of start-of-day equity. Existing
  prospective stop-risk reservation, cash, one-contract and three-entry caps
  remain. No stop/target tuning or size increase.
- `OPTIONS_DAILY_GREEN_LOCK_ENABLED: true`. Latch after the first completed exit
  leaves cumulative realized daily **net after modeled costs** strictly positive.
  No unrealized/zero trigger, force-close, profit quota or same-day unlock.
  Other existing positions keep their exits, so the final day can still be red.
  Next Eastern date resets day totals/latch/count; holidays/weekends still reject
  entries through normal session gates.
- Day state stores `green_lock_active`, `lock_activated_at`,
  `realized_pnl_at_activation`, `skipped_entry_count`. Rejected final entry attempts
  increment that count. Skipped discovery cycles have separate durable funnel
  reasons. Both use `daily_green_lock_active`.
- Live-ready state stores actual gross fill P&L separately from modeled net.
  Costs are captured at entry. If a lower actual buy fill shrinks exit payoffs
  below 1.00, log recomputed economics and ATTENTION; no forced exit is added.

## State independence

`OPTIONS_STRATEGY_EPOCH: python_jev_green_lock_20261009` resolves primary paths to
`state/options/python_jev_green_lock_20261009/paper/` and `/live/`. New paper cash
starts at the existing configured $369; it is not broker cash or a transfer.
Live state initializes from fresh broker equity only in a future live run and
must reconcile broker positions/orders. Neither mode copies historical results.
Epoch evaluation files use `/evaluation/`; cycle and fill telemetry carry epoch
labels. Each mode has independent day state and results.

Earlier `state/paper/`, `state/live/`, `state/paper_baseline/`, and
`state/daily_green_lock/` records remain historical and untouched. Future control
and comparator runs are disabled by their switches. Their October 8 implementation
and historical documentation remain for reproducibility. Crypto settings, ledgers
and scheduled tasks are unchanged. No scheduled task is created, started or
enabled as part of this delivery.

## Evidence and verification

Recomputed from the control ledger through October 8: fixed-record stop-after-green
replay retains $147.00 / $369 = **39.8374%**, keeping 20 trades and skipping 16.
This reproduces the user's 39.8% figure. Actual control P&L is $70.40 over 36
trades; the October 1 audit's earlier replay was $135.50 / $369 = 36.72%.
The current calculation and source hash are saved separately in
`docs/OPTIONS_GREEN_REPLAY_2026-10-09.json`. This replay skips recorded entries, retains recorded exits and
assumed paper target fills, and does not recompute cash-dependent selection.
It does not establish live returns or reproduce this new epoch's post-cost gate.

Fresh direct Robinhood read at 2026-10-09 08:24:38 ET: $385.40 equity/cash/buying
power, Level 3 options, no positions, no open option orders, reconciled.
This account check is not a fresh executable setup/quote/order-review preflight.
No actual JEV/Luna trading calls or broker orders were invoked for verification.
Test commands, final results, changed files and ledger hash checks follow below.

Full offline suite: **566 passed in 37.57s** with:

```powershell
.venv/Scripts/python.exe -m pytest -ra --basetemp C:/Users/jesse/.codex/visualizations/2026/10/08/01a11b51-47c1-7512-9af6-b9264040ce2d/options-cutover-tests-final -o cache_dir=.tmp/cutover-pytest-cache
```

After the final outstanding-position exit-cost reservation change and added
boundary test, the affected risk/config suite: **39 passed in 4.89s** with:

```powershell
.venv/Scripts/python.exe -m pytest tests/test_options_deterministic.py tests/test_live_trading.py tests/test_live_multi_position.py tests/test_config.py -ra --basetemp C:/Users/jesse/.codex/visualizations/2026/10/08/01a11b51-47c1-7512-9af6-b9264040ce2d/options-cutover-tests-risk-final-b -o cache_dir=.tmp/cutover-pytest-cache
.venv/Scripts/python.exe -m ruff check tools tests
```

Ruff reports `All checks passed!`. Both edited `.ps1` files pass PowerShell
`System.Management.Automation.Language.Parser.ParseFile` with zero errors.
Independent read-only code review found no outstanding defect. Test subprocesses
ran outside the Windows sandbox because it blocks asyncio's local socket setup;
temporary test state is outside OneDrive. Broker/model orders are always mocked.
Initial full regression failures were historical fixtures inheriting the new
production mode; fixtures now explicitly retain old Luna/control settings.

All **19** historical primary/control/green/live ledger, event and summary files
are SHA256-identical to the pre-edit snapshots. Existing options/reset scheduled
tasks were read-only checked enabled/Ready; both crypto tasks remain disabled.
Config validation: paper blockers `[]`, options blockers `[]`, JEV credential
available, live false. No task mutation, notification, real/test order, order review
or transfer. The initialized new paper epoch has $369 equity and zero trades.

## Complete delivery file list

Paths below are relative to
`C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic`.

- `CONFIG.md`
- `automation/run_cycle.ps1`
- `automation/reset_daily_opportunities.ps1`
- `tools/config.py`
- `tools/decision_context.py`
- `tools/experiment_report.py`
- `tools/jev_pipeline.py`
- `tools/live_trading.py`
- `tools/options_strategy.py` (new shared state/lock helper)
- `tools/paper_runner.py`
- `tools/paper_status.py`
- `tools/paper_trading.py`
- `tools/scheduled_cycle.py`
- `tests/test_config.py`
- `tests/test_options_deterministic.py` (new)
- `tests/test_paper_repair_integration.py`
- `strategy/STRATEGY.md`
- `strategy/RISK.md`
- `strategy/COST_POLICY.md`
- `strategy/EXECUTION_RULES.md`
- `state/DAILY_STATE.md`
- `state/POSITIONS.md`
- `journal/DECISIONS.md`
- `docs/OPTIONS_DETERMINISTIC_CUTOVER.md` (new delivery report)
- `docs/OPTIONS_GREEN_REPLAY_2026-10-09.json` (new read-only replay/source hash)
- `state/options/python_jev_green_lock_20261009/README.md` (new)
- `state/options/python_jev_green_lock_20261009/paper/PORTFOLIO.json` (initialized)
- `state/options/python_jev_green_lock_20261009/paper/EVENTS.jsonl` (initialization only)
- `state/options/python_jev_green_lock_20261009/paper/SUMMARY.md` (generated)
- `state/options/python_jev_green_lock_20261009/paper/PORTFOLIO.json.lock` (lock artifact)

Local engineering snapshots, read-only broker evidence/scripts, and test caches
are retained under `.tmp/options-cutover-20261009/` and
`.tmp/cutover-pytest-cache/`; Python/Ruff may refresh ignored bytecode/cache files.
No historical broker/paper portfolio was edited for verification.
