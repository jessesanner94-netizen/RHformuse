# Robinhood Agentic Options Strategy: System Guide

**What this describes:** the SPY/QQQ options decision and paper-accounting design in this repository, based on the configuration and source inspected on 2026-10-21. This is a system description, not a claim of profitability or a live trade recommendation. No credentials are included.

## 1. The short version

This is not one Pine Script entry rule. It is a multi-stage options workflow with a small technical direction model, a contract scanner, hard risk and event rules, a JEV ranking step, and a deterministic position manager.

For the current options route, Python determines whether a CALL or PUT setup is directionally eligible. It gathers a small set of liquid SPY/QQQ contracts that pass hard rules. JEV scores and ranks up to three of those Python-qualified candidates, and Python selects the highest-ranked contract. The current no-Luna route does not ask Luna/Codex to approve or veto that options entry. Python still performs the final checks and owns the simulated fill, risk limits, and exits.

[account details redacted]

## 2. Decision flow

```mermaid
flowchart TD
    A[Scheduled Python cycle] --> B[Read account, positions, orders, and ledgers]
    B --> C[Manage existing positions and apply entry locks]
    C --> D{Time, calendar, event, and risk gates pass?}
    D -- No --> X[No new entry; keep monitoring positions]
    D -- Yes --> E[Resolve SPY and QQQ option chains]
    E --> F[Cheap contract and Greek/liquidity scanner]
    F --> G[Rank contracts in Python; get completed-bar technical snapshot]
    G --> H{Direction, event, net economics, and risk qualify?}
    H -- No --> X
    H -- Yes --> I[Evaluate up to three Python-qualified candidates with JEV]
    I --> J{Valid JEV ranking data for the pool?}
    J -- No --> X
    J -- Yes --> K[Python chooses the top-ranked contract]
    K --> L[Fresh quote and final deterministic checks]
    L --> M{Selected mode}
    M -- Paper --> N[Simulated buy at ask; persist ledger]
    M -- Live, if enabled --> O[Broker review and order protocol]
    N --> P[Python monitor: stop, target, and session deadline]
    O --> P
```

The ordinary opportunity scan is configured for a five-minute cadence. Held-position protection is a separate resident Python loop configured for ten-second checks and a maximum 20-second quote age. That monitor does not call JEV or a language model. Software monitoring depends on the process, machine, network, and quote source staying available; it is not a broker-held stop.

## 3. What the strategy trades

The current options experiment is deliberately narrow:

- **Underlyings:** SPY and QQQ only.
- **Instrument:** one long call or one long put; no short options or multi-leg spreads.
- **Style:** DAY only. No new swing options positions and no 0DTE contracts.
- **Expiration:** normally 2–45 calendar days to expiration, with DAY-specific Greek checks.
- **Entry window:** no new entries during the first 20 minutes after the regular-session open or within 30 minutes of the scheduled close. For a normal session, the configured last entry time is 15:30 ET.
- **Exit deadline:** 15 minutes before the regular-session close (15:45 ET on a normal day), adjusted for holidays and early closes.
- **Scheduled events:** configured macro blackouts pause new entries around FOMC decisions and selected releases. Required earnings/event review must be available; intentional earnings holds are not allowed by the configured policy.

The hypothesis is intraday directional continuation/confluence. It uses completed 5-minute and 15-minute bars plus opening-range structure to determine whether a call or put direction is supported. Daily and 4-hour information can be shown as context, but the active DAY-only Python direction score is driven by 5-minute, 15-minute, and same-session structure. This is a rule-based technical filter, not a single named chart setup with a separately validated entry edge.

## 4. Scanner stages

### 4.1 Discovery: which contracts are considered

`scheduled_cycle.py` checks that the strategy is inside its entry window, that macro/event gates permit a new position, that no daily green lock is active, and that account/position state is usable. When `WATCHLIST_ONLY` is enabled, `watchlist_discovery.py` resolves the configured fixed list, currently SPY and QQQ. It does not use broad movers or paid options-flow discovery.

`news_option_discovery.py` requests a bounded set of option-chain data from the broker adapter. The current watchlist resolver asks for up to three permitted expirations and returns at most twelve diversified candidates. It collects contract identity, expiration, strike, call/put type, bid/ask, quote timestamp, option volume/open interest, underlying liquidity, and Greeks/IV. Missing, stale, malformed, crossed, or otherwise unusable data is rejected or treated as insufficient.

### 4.2 Cheap tradability gate

`cheap_scan.py` is a deterministic eligibility gate, not the directional signal. Among other checks, the configured values require:

| Check | Current configured rule |
|---|---:|
| Option quote spread | At most 10% of midpoint |
| Option volume | At least 100 |
| Option open interest | At least 500 |
| Underlying average dollar volume | At least $50 million |
| DAY DTE | At least 2 and no more than 45 |
| 0DTE | Disabled |
| Absolute delta | 0.20–0.80 |
| Theta as percent of option midpoint per day | At most 65% |
| Gamma change for a 1% underlying move | At most 0.35 delta units |
| Premium | Normally $50–$250, further reduced by risk budget and buying power |

Greeks are required and checked for plausible long-option signs. The cheap gate also rejects duplicate contract IDs and unresolved settings. Its `setup_qualified` input means only that the upstream resolver admitted the candidate to this tradability scan; it is not proof of a technical setup or an independent profitability signal.

After the hard checks, the bounded contract list is sorted in Python. The early ordering favors a tighter spread, delta nearer roughly 0.45, more option volume/open interest, a price move aligned with the call/put direction, and relative volume. Current paid UW-flow fields are normally absent because `UW_ENABLED` is false. This early ordering is only a way to choose which candidates to evaluate first; later direction and risk gates still apply.

### 4.3 Python direction and technical qualification

`vibe_snapshot_worker.py` fetches the requested history and emits compact indicator summaries; raw bars do not go to JEV. It uses consecutive completed bars for the intraday calculations. Each timeframe's trend score adds or subtracts one point for each available condition:

1. Latest close above/below the 20-bar SMA.
2. The 20-bar SMA above/below the 50-bar SMA.
3. MACD histogram positive/negative.
4. RSI at least 55 / at most 45 (neutral between those levels).
5. Three-bar return positive/negative.

A timeframe label is bullish at a score of +2 or higher, bearish at -2 or lower, and neutral otherwise. The DAY style score is `2 × 5M trend score + 1 × 15M trend score + 2 × opening-range structure score`. The opening-range structure score uses whether the range low/high held or was swept and reclaimed/rejected, the latest close relative to the opening-range midpoint, and the recent three-bar close comparison. The CALL/PUT direction is applied as a sign: positive alignment supports a call; negative alignment supports a put. The preferred DAY direction must be supported; opposing intraday direction is rejected in Python.

Python also requires usable account risk and required event/earnings status. It computes net reward/risk from the configured 30% option-premium target and 25% stop after modeled costs. It drops duplicate symbol/direction evidence groups, blocks new opportunity research for an underlying already held, and advances to another candidate when a deterministic gate fails. With `DAY_ONLY_OPTIONS: true`, the old extra daily-trend countertrend confirmation rule is not the active qualification rule.

Broad news is collected and compressed; social collection is disabled by current configuration. News/social labels do not independently create an options entry. Unusual Whales is disabled, so missing flow is not treated as confirmation. The current route does not activate the former flow-led reversal path.

## 5. JEV's actual role

JEV is a separate structured-evaluation service. Python constructs its input and its versioned questions, validates the response, stores the result, and applies the routing policy. JEV never places or manages orders.

For the current SPY/QQQ options ranking route:

1. Python supplies up to three candidates that already passed Python's direction, contract, event, and risk qualification.
2. JEV returns bounded 0–1 judgments for questions such as setup quality, entry timing, bullish/bearish continuation, momentum, volume confirmation, timeframe alignment, breakout/false-breakout risk, exhaustion, reversal risk, and market regime. Order-book questions can be added when a fresh usable book is present. A resting order book is not executed flow, and the code marks trade-print-dependent judgments unavailable when genuine prints are absent.
3. Python ranks candidates by the tuple `(setup_quality, entry_timing_quality, escalate_to_luna)`, in that priority order, and chooses at most one. The `escalate_to_luna` question name is historical; the current options route does not send that decision to Luna.
4. These values are model judgments, not calibrated win probabilities. Options mode has no minimum score, false-breakout ceiling, or directional-score veto. A low but valid score can still rank first.

**Does JEV assign a bullish/bearish rating for the day?** It asks separate bullish-continuation and bearish-continuation questions about the supplied candidate and horizon. It does not produce a single authoritative “bullish day / bearish day” rating that sets the options direction. Python chooses the supported CALL or PUT direction. The current options rank tuple does not use JEV's bullish/bearish answers.

**Can JEV stop an options trade?** A weak score cannot veto a candidate. However, in the current no-Luna ranking implementation, every candidate in the ranking pool must return valid JEV ranking fields. If JEV is disabled, times out, returns invalid data, or fails to provide a required score, the scheduler skips the options route rather than using Python-only fallback. This is an availability/data-integrity block, not a score threshold. It differs from a comment in `CONFIG.md` that describes Python-order fallback; the current code and October 9 strategy amendment fail closed here.

JEV also has a separate research role in the ETH/BTC crypto paper experiment: when the relevant paper mode is active, Python can compare that coin's setup-quality score with the mean of prior matching evaluations. That is a distinct crypto admission rule, not the SPY/QQQ options rank-only rule. Some historical winner-continuation code can log an optional JEV advisory for positions enrolled in its dated trial; it does not control exits. The current options exit path is deterministic.

## 6. Final risk, entry, and paper accounting

JEV selects a candidate; it does not make that candidate executable by itself. Python rechecks the chosen contract and account immediately before applying an entry. The paper path requires a fresh quote, current eligibility and timing, a matching candidate ID, current cash, and all risk/economics gates. The live adapter, if genuinely enabled and invoked, has additional broker snapshot, order-review, request identity, and order-state checks. The configuration conflict in section 12 must be resolved before assuming which route runs.

The main configured risk controls are:

- One contract per position and at most three new positions per Eastern day.
- No averaging down.
- Daily loss budget is the smaller of $45 or 12.5% of start-of-day equity.
- New premium must fit the remaining daily planned-loss budget after current day loss, existing position stop risk, and the $2.10 round-trip cost reserve.
- No separate aggregate-position-count or aggregate-premium cap is configured; buying power, single-position bounds, same-underlying exposure checks, and daily risk still constrain entries.
- Net target reward / net stopped-out loss must be at least 1.00 after the modeled costs. With the configured 30% target, 25% stop, and $1.05 cost estimate per side, a $50 option premium fails that ratio; about $84 is the first premium that meets it before other gates. The daily planned-loss budget may impose a lower maximum than $250.
- The first completed exit that makes realized daily net P&L strictly positive activates a sticky daily green lock for new entries in the primary ledger. It does not close existing positions; it resets on the next Eastern date.

Paper entries are recorded at the option ask; exits are recorded at the bid. The model charges $0.05 fee plus $1.00 slippage per contract per side, or $2.10 round-trip. These are experiment assumptions, not verified broker charges or guaranteed fills. When enabled, the paper take-profit trade-through assumption can mark an assumed limit fill from minute-bar evidence; reports should distinguish assumed from quote-observed fills.

## 7. Position management

The ordinary DAY position manager is Python-only:

- Stop trigger: option bid at or below 75% of entry premium (25% loss threshold).
- Profit target: option bid at or above 130% of entry premium (30% gain threshold), subject to paper fill modeling.
- Time exit: configured 15 minutes before the regular-session close.
- Fresh quote: paper fast monitor requires a quote no more than 20 seconds old; it checks on a configured ten-second loop.
- Other required exits: event/thesis or data-integrity actions when applicable. A stale or missing quote raises attention and does not manufacture an exit price.

These are software triggers. A stopped position can lose more than the nominal threshold if quotes, software, network, or execution are delayed, and a paper fill model cannot guarantee live execution at the displayed bid.

## 8. Python's responsibilities

Python is the system's deterministic controller and execution boundary. Its jobs include:

1. Load and validate configuration; fail closed when required settings or inputs are missing.
2. Obtain account, position, order, underlying, option-chain, quote, and Greek data from configured adapters; reconcile held positions before searching for new risk.
3. Apply session, holiday, macro, earnings, data-age, candidate-identity, held-symbol, and entry-capacity gates.
4. Discover a bounded SPY/QQQ option set and enforce hard liquidity, premium, spread, DTE, and Greek requirements.
5. Fetch and reduce market bars into deterministic timeframe and opening-range scores; determine whether CALL or PUT direction is supported.
6. Calculate net reward/risk, premium affordability, planned stop risk, daily loss, cash/buying-power usage, and entry limits.
7. Build the compact JEV packet, validate JEV responses, rank candidates, and persist research/selection telemetry.
8. Re-fetch final candidate data and re-run gates before a paper fill or any separately enabled live order path.
9. Maintain the paper portfolio, cost model, stop/target/time exits, realized P&L, daily green lock, and event logs.
10. Run a fast held-position monitor independently of opportunity scans and report errors/attention without inventing prices.

The configured Level 2 component summarizes displayed depth, imbalance, microprice, and walls. It does not prove buying/selling from executions, absorption, or exhaustion. Unusual Whales flow, Agent Reach social, broad movers, and model-driven entry discretion are disabled or inactive in the current options configuration.

## 9. What is and is not backtestable

The bar-based direction calculation is reproducible from point-in-time OHLCV data if the same completed-bar rules, time zone, session boundaries, missing-bar handling, and indicator formulas are retained. The deterministic risk and paper-exit logic can also be replayed.

[account details redacted]

For a portable strategy experiment, separate the layers:

1. **Signal variant:** the exact Python direction and entry qualification rules.
2. **Contract selector:** tradability and option structure constraints.
3. **JEV variant:** save its candidate scores as recorded inputs, or omit JEV for a fully deterministic baseline; do not silently replace its rankings with future data.
4. **Execution model:** ask-side entries, bid-side exits, fees, slippage, quote freshness, and the take-profit fill assumption.
5. **Risk/management:** size, stop, target, session deadline, daily loss, and green lock.

Only then compare variants on the same observations. A price-only Pine backtest can test an underlying signal proxy, but it will not reproduce option premium path, IV, Greeks, spread, contract selection, or the current JEV ranking.

## 10. Separate crypto experiment

ETH-USD and BTC-USD are a separate long-only spot paper experiment outside NYSE regular hours. They share a separate simulated ledger and use their own completed-bar continuation, volume, spread, fee/slippage, stop/target, daily-loss, time-stop, and JEV relative-score rules. They are not option candidates and do not share the SPY/QQQ option ledger. The crypto path is disabled by the current global `PAPER_TRADING_ENABLED: false` check in `crypto_cycle.py`, regardless of the separate crypto switch, until the mode is corrected.

## 11. Source map

- `CONFIG.md` — user-controlled switches, scanner thresholds, risk limits, session rules, cost assumptions, and JEV settings.
- `strategy/STRATEGY.md` — strategy policy and dated amendments; use the October 9 deterministic-options section over older Luna-based descriptions.
- `strategy/RISK.md`, `strategy/COST_POLICY.md`, `strategy/EXECUTION_RULES.md` — risk, accounting assumptions, and execution protocol.
- `tools/scheduled_cycle.py` — cycle sequencing, account/position priority, routing, JEV candidate selection, and paper/live dispatch.
- `tools/watchlist_discovery.py`, `tools/news_option_discovery.py`, `tools/cheap_scan.py`, `tools/option_style.py` — fixed-universe chain collection and contract eligibility.
- `tools/vibe_snapshot.py`, `tools/vibe_snapshot_worker.py`, `tools/decision_context.py` — technical calculations, direction gate, ranking order, compact evidence packet, and Python risk/event gates.
- `tools/jev_questions.py`, `tools/jev_features.py`, `tools/jev_pipeline.py`, `tools/jev_client.py`, `tools/jev_store.py` — JEV questions, feature reduction, validation, rate limits, persistence, and ranking evidence.
- `tools/portfolio_risk.py`, `tools/paper_runner.py`, `tools/paper_trading.py`, `tools/options_strategy.py` — final affordability, paper fills, exits, ledger identity, and daily green lock.
- `tools/paper_fast_monitor.py` — resident fast paper position monitor.
- `docs/OPTIONS_DETERMINISTIC_CUTOVER.md` — October 9 description of the no-Luna options route and the fail-closed JEV ranking requirement.
- `research/options_lab/README.md` — frozen baseline, snapshot replay, and data-coverage limitations.

## 12. Current configuration conflict

As read on 2026-10-21, the top-level values in `CONFIG.md` say:

```text
LIVE_EXECUTION_ENABLED: true
PAPER_TRADING_ENABLED: false
LIVE_NEW_ENTRIES_ENABLED: true
```

Nearby prose in `CONFIG.md`, `strategy/STRATEGY.md`, the October 9 cutover/readiness documents, and the recent experiment notes says the active strategy is paper-only and live execution is locked off. The existing October 19 options-lab note also records that `live=true` / `paper=false` conflicts with historical test assumptions. These statements do not agree. This guide does not change core policy or resolve the authorization state. Before reproducing or launching the strategy, explicitly reconcile the configuration and operating mode, then verify the selected runner and its order authority.

There is also a narrower JEV mismatch: some `CONFIG.md` prose says a failed ranking can fall back to Python order; the current `scheduled_cycle.py` deterministic ranking path skips when any member of its selection pool lacks valid ranking fields. Follow the implementation and October 9 cutover semantics unless that behavior is deliberately changed and reviewed.
