# Project audit — October 1, 2026

The best-supported next experiment is a synchronized paper comparison of Python entries and Luna-approved entries, with both arms blocking new entries after realized daily net profit first exceeds zero. Luna decides BUY, PASS or WATCH for the supplied option; it does not select the option contract. The daily-stop replay helps substantially; the current Luna-approved strategy still loses after that change. The simpler control plus the stop is promising retrospective evidence, not a validated profitable strategy.

This audit made no strategy, risk, configuration, scheduler, paper-portfolio or broker-order changes. New files contain the audit and its calculation. Audit findings are also recorded in the project journal and daily memory.

## Evidence and scope

Read all mandated policy/state files, prior options experiments, both paper ledgers, their events, evaluation pairs, dated run logs, research leaderboards/checkpoint, implementation paths and outstanding proposals. Parsed all 26 dated run-log files from August 24 through October 1: 1,375 opportunity records and 4,833 position records, with zero malformed JSON lines. This includes the earlier live phase; paper-performance comparisons use September 8 onward. Eight research SQLite databases returned `ok` from read-only `PRAGMA quick_check`.

The option sample is 19 primary trades on 12 entry dates and 26 control trades on 15 entry dates, across 16 logged paper-period sessions. Many trades share candidates and market conditions; 45 ledger trades are not 45 independent experiments. Major policy changes include September 5 accounting/risk repairs, September 16 cadence/assumed targets, September 20–22 JEV/routing/DAY-only changes, September 24 chain-pagination repair and winner trial, and September 28 model upgrade/rollback. These weeks are not one stable strategy sample.

The calculation is [audit_project_2026_10_01.py](../research/options/audit_project_2026_10_01.py); detailed results, daily tables and source hashes are in [PROJECT_AUDIT_2026-10-01.json](PROJECT_AUDIT_2026-10-01.json). Assertions reconcile entry/exit IDs, closed counts, net P&L and flat-ledger cash. The dated helper refuses portfolios updated after October 1 to protect this report from later data.

## Reconciled options results

| Metric | Luna primary | Python DAY control |
| --- | ---: | ---: |
| Closed trades | 19 | 26 |
| Net after estimated trading costs | −$141.90 | −$14.60 |
[account details redacted]
| Mean net per trade | −$7.47 | −$0.56 |
| Winners | 8 / 19 | 13 / 26 |
| Profit factor | 0.580 | 0.963 |
| Recorded maximum drawdown | $168.75 | $138.85 |
| Separately charged fee/slippage estimates | $39.90 | $54.60 |
| Net before those separate cost estimates | −$102.00 | +$40.00 |

Ask/bid spread remains in the last row. It is not a zero-friction performance forecast. Neither account has an open option position. AI/data expenses have not been recorded, so economic profit is unavailable. The primary is negative even before its separate modeled execution costs; the control's small gross gain is erased by those costs.

Primary average win is $24.53 versus average loss $30.74. At that observed payoff ratio, break-even requires approximately 55.62% winners, versus the observed 42.11%. The nominal 30% target/25% stop does not produce that nominal payoff ratio in the records: time exits, polling and costs matter. This arithmetic describes the sample, not future win probabilities.

## Stop after a profitable day

Replay entries and exits chronologically in Eastern time. Latch once retained, closed-trade daily P&L after recorded trading costs exceeds zero; block subsequent entries that date. Preserve exits of already-open positions and reset on the next date. The latch is based on when the exit was recorded, including delayed assumed target booking; it does not backdate available cash.

| Fixed-record replay | Actual net | Stop-after-green net | Improvement | Trades kept / skipped |
| --- | ---: | ---: | ---: | ---: |
| Luna primary | −$141.90 | −$35.20 | +$106.70 | 12 / 7 |
| Python control | −$14.60 | +$135.50 | +$150.10 | 15 / 11 |

Primary improves on four entry dates and worsens on none; control improves on six and worsens on one. The September 23 primary replay had been +$16.20. Four subsequent trades lost $51.40, taking the updated replay to −$35.20; none would have been skipped by this rule. For September 24 onward alone, control improves from −$71.90 to −$11.60 by skipping three entries. That extension is still negative.

The fixed-record replay does not resimulate changed cash, future risk capacity, candidate selection, model budgets or replacement trades. Its favorable control total also includes assumed target fills. It supports prioritizing a prospective paper test, not saying the future rule is certain to improve every session.

Options currently have no stop-after-green gate. `CRYPTO_STOP_AFTER_NET_GREEN` applies only to the separate crypto experiment. A proposed options gate should latch on realized net profit after costs, suppress new entries/re-entries/WATCH entry reviews, and retain protective monitoring of existing positions. Already-open positions can still make the final day red; blocking new entries alone does not guarantee a profitable closing balance.

## Does Luna add value?

There are 57 pair observations; 24 have completed control trades. They include 14 distinct primary executions and 24 distinct control executions, not 24 two-sided trades.

| Completed observation group | Rows | Primary net | Control net |
| --- | ---: | ---: | ---: |
| Both executed after BUY | 14 | −$52.40 | −$52.40 |
| Control-only after PASS | 5 | $0 | +$23.50 |
| Control-only after WATCH | 5 | $0 | −$5.50 |

The completed-row difference is −$18.00 for primary versus control. The broader ledger gap is $127.30, but different cash/risk/capacity and timing paths prevent attributing that entire gap to Luna. The current control is conditional on candidates that reach model review; it is not a comprehensive no-model scanner backtest. WATCH also has no clean synchronized wake-versus-immediate-entry outcome comparison.

Luna has not demonstrated incremental BUY/PASS/WATCH decision value here. A common-opportunity, common-quote comparison with synchronized risk/capacity is the next useful test. Keep a per-candidate outcome comparison separate from independently funded account paths. Run both arms with the same daily profit stop first; hold setup, contracts, costs and exits fixed. Existing model calls can support the comparison without adding a second decision model.

## Exits, contract selection and fill realism

Stop exits exceeded a 25%-of-premium plus $2.10 planned allowance by an aggregate $21.50 in primary and $26.00 in control. The September 25 SPY call paid $111, lost $42.10 net, and exceeded that $29.85 allowance by $12.25. This demonstrates polling/fill risk; it does not prove a specific missing poll caused that loss. Source code already describes stops as triggers, not guaranteed fills.

The predeclared 20% stop sensitivity was extended using fresh, timestamped monitor bids before each recorded exit. Assumed-target exits remain censored because ordering against an earlier hypothetical stop is unresolved. Current results:

| 20% stop sensitivity, uncensored trades only | Count | Recorded net | Alternative net | Difference |
| --- | ---: | ---: | ---: | ---: |
| Primary | 13 | −$298.30 | −$242.30 | +$56.00 |
| Control | 19 | −$210.90 | −$179.90 | +$31.00 |

Eight primary and nine control trades have an observed earlier trigger. The alternative can also hurt: the October 1 control time-exit loss of $6.10 becomes a $26.10 loss under the observed earlier 20% trigger. These sampled-quote subset results must not replace full-ledger P&L or be added to the daily-stop improvement; their interactions were not simulated. Missing between-poll quotes and censored winners remain material.

The original primary September 8–18 sensitivity reproduces at −$183.70 versus −$148.70. The old control report's −$63.00 alternative differs from current Python recomputation, which gives −$50.00 on that original ten-trade uncensored subset. An independent run of the legacy PowerShell helper reproduced primary's full −$242.30 alternative; its current control alternative was −$173.90 using September-only quote files, versus Python's −$179.90 including October 1. Quote scope and implementation differences remain to be reconciled. Preserve the historical report and resolve these discrepancies before promoting the exit rule.

All 45 option entries have absolute delta below 0.30: primary 0.2005–0.2616, control 0.2005–0.2915. All 318 retained prospective highest-affordable-delta audit rows also fall below 0.30, with maximum 0.28519. This is evidence about the recorded affordability/eligibility funnel, not every possible chain contract. Raising the delta floor to 0.30 would reject every recorded trade without supplying evidence about higher-delta profitability. Do not increase capital or loosen risk just to access those contracts.

At current flat equity, the next day's planned-loss rule implies premium ceilings about $105.15 primary and $168.80 control before ticks and other gates. Declining equity changes the available contract set. Keep this capacity effect visible in model attribution.

Near-entry spread proxies matched all 45 fills; the maximum is 1.94% of midpoint. A 5% spread cap would have changed zero recorded entries. These are near-entry proxies, not independently verified exact fill-quote tapes. Tightening that threshold is not an evidenced improvement for this sample.

Six primary assumed-target exits contribute +$156.40; seven control assumed exits contribute +$196.30. The remaining-trade subsets are −$298.30 and −$210.90, respectively. Those subset figures are not alternative conservative account returns: actual exits without assumed fills have not been reconstructed. OHLC trade-through is not an executable historical option bid/ask queue fill. Require separate observed-bid and assumed-target reporting and acquire appropriate option quote paths before validating new entry strategies.

The September 24 winner-continuation trial enrolled one trade that stopped for −$34.10 before a winner checkpoint. It provides no evidence about whether continuation improves winners. Its dated expiry is intentional; it should not be extended merely because a configuration date remains present.

Normal paper management stores free-text thesis/invalidation but evaluates premium stop, target and deadline. Its structural `THESIS_EXIT` path applies to an enrolled winner after the trial checkpoint; it does not generally enforce prose such as “lose VWAP” before that checkpoint. A future explicit setup should supply machine-readable underlying invalidation if that is intended as an exit rule. This is a prospective hypothesis, not an evidenced profit improvement or a reason to reinterpret past exits.

## JEV, operations and research backlog

JEV holds 444 observations; its separate research outcome table contains zero rows linking evaluations to subsequent market outcomes. Trade outcomes exist in the trading ledgers. This missing research linkage does not mean JEV is failing to run or blocking trades. Current SPY/QQQ options policy uses JEV for ranking eligible candidates, with no low-score admission veto and deterministic fallback if ranking is unavailable. Luna receives the chosen option and decides BUY, PASS or WATCH. Ranking scores are not calibrated profit probabilities. Attach available point-in-time labels to evaluated candidates, with model/question versions and decision-availability timestamps; report coverage explicitly. Underlying returns must remain distinct from option P&L. Eleven persisted option watches are terminal: nine invalidated and two expired. That alone does not establish WATCH profitability or failure.

October 2 clarification: the user reports approximately $0.15 of JEV usage and a $5 monthly free allowance. Billing was not independently verified in this audit. Missing local billing entries are a bookkeeping limitation, not evidence of a material JEV expense; JEV cost is not a current improvement priority.

The dated logs contain 83 final-decision invocations, 79 completed and four failed: two provider-schema failures and two model/auth compatibility failures. The paper-period funnel records 62 calls; the additional 21 logged final calls precede that funnel. Crypto's 17 recorded Luna decisions and manual smokes are separate. Logged final CLI tokens total 1,700,074 across the full dated-log scope; this is not a measured dollar charge. Fifteen outer cycle error records include historical OAuth, MCP/server and social timeout failures. No malformed logs or current failed regression checks were found. Historical failures should not be counted as deliberate model PASS decisions.

[account details redacted]

[account details redacted]

The TradingView structured research store contains 78 candidate records: 65 REJECTED, 11 SCREENING, one DEMO and one legacy PROVISIONAL; no validated winner. Saved Pine IDs extend to TVR-0081, so record count and script count are not interchangeable. Current priorities are TVR-0080, TVR-0064 and TVR-0068. TVR-0080 QQQ15 has +$247.66 on $10,000 over 36 ETF-share trades, but SPY15 loses, its ATR stop can widen, early-close behavior remains unexercised, and the latest slice has eleven trades. These are proxies, not profitable option backtests.

The paused research checkpoint proposes a bounded fixed/monotonic-risk and calendar-safety comparison. That is a risk/implementation test; the earlier frozen-bracket TVR-0072 failed transfer, so improvement is not assumed. Do not resume broad strategy searches or rescue rejected Ichimoku variants through more tuning. Repeated strategy selection on inspected history creates overfitting risk; frozen hypotheses and prospective validation should precede promotion. [Bailey et al., primary backtest-overfitting research](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf).

Outstanding live resting take-profit implementation requires reconciliation, idempotency, tick handling, restart recovery and explicit approval for cancel-and-exit behavior under the existing cancellation prohibition. It remains a live-readiness backlog item, not authority to enable live trading.

Documentation also needs consolidation: the generated evaluation summary still says primary includes SWING, although all recorded paper fills are DAY; DAILY_STATE's September 28 upgrade note omits the later model rollback recorded in DECISIONS; README/PLAN retain obsolete cadence, budget and phase descriptions. CONFIG and current code use gpt-5.6-luna, DAY-only options and the shared 20-call budget. The entire workspace is currently untracked in Git, so there is no commit history establishing exact past code versions. Preserve source/config hashes with future experiments.

## Prioritized next work — proposals only

1. **Daily stop plus model attribution:** freeze one prospective paper comparison with identical eligible opportunities, refreshed quotes, risk/capacity assumptions and daily net-green latches. Separate account returns from matched decision lift. Primary recommendation; core rule changes need user approval.
2. **Exit sensitivity:** test the predeclared 20% stop in a separate paper arm with complete bid observations, unchanged targets and realistic costs. Do not simultaneously tune multiple stop/target/trail values. Resolve the old control sensitivity discrepancy first.
3. **Measurement:** retain option quote paths, separate assumed fills, and link JEV rankings to subsequent outcomes so ranking quality can be evaluated. Record actual AI/data charges when material; the user's reported JEV usage does not make its cost a current concern.
4. **One explicit setup:** if further entry research is authorized, specify and freeze one VWAP failed-auction rule, finish monotonic-risk/close-calendar validation, then test affordable options separately. Preserve new dates as prospective evidence; avoid reopening the full indicator backlog.
5. **Operational memory:** reconcile stale crypto only before an explicitly authorized restart; align summary wording and current model notes; preserve reproducible versions. Keep live disabled while execution/fill validation is incomplete.

The audit establishes enough evidence to choose better experiments and identify avoidable losses. It does not establish enough stable, independent, executable option evidence to claim a profitable strategy.

Verification: 529 existing offline tests completed with exit 0; Ruff passes for tools, tests and the new audit helper. The helper reproduces ledger totals, chronological daily-stop replay and current matched-row totals. No new scheduled trading cycle, broker order, final-decision model call, notification or automation was launched.
