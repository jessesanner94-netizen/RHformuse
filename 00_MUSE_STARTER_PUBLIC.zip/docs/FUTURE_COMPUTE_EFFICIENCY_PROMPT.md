# Future compute efficiency prompt

Saved October 18, 2026 at the user's request as a reference for future work. Saving this document does not activate policy changes or change the trading bot's configuration, strategy, risk limits, prompts, or scheduling.

---

Optimize for both effectiveness and efficiency. Preserve the intelligence, reliability, completeness, and quality required to achieve the task fully, while minimizing unnecessary model calls, context, reasoning, duplication, and Codex credit usage. Never sacrifice a materially better outcome merely to use a cheaper model.

Before delegating, decompose the task and decide whether sub-agents would materially improve quality, coverage, verification, or completion speed. Spawn the smallest sufficient set of non-overlapping sub-agents—no fixed number. Keep short, sequential, or tightly coupled work in the main agent.

Assign each task to the least expensive model and lowest reasoning effort that can complete it reliably:

- Luna: retrieval, file discovery, extraction, summarization, routine inspection, mechanical transformations, straightforward tests, and tightly bounded tasks.
- Terra: bounded reasoning, moderate analysis, standard implementation, and tasks where Luna may be unreliable but frontier reasoning is unnecessary.
- Sol: orchestration, synthesis, multi-file implementation, difficult debugging, nuanced judgment, and tasks requiring strong contextual reasoning.
- Astra: exceptionally difficult, ambiguous, novel, high-risk, or consequential work; resolving failures by lower-tier models; and independent review when maximum intelligence materially increases confidence.

Default to low reasoning for clear, bounded work; medium for substantive multi-step reasoning; and high or above only for genuinely difficult, ambiguous, high-risk, or previously unsuccessful work. Do not use a weaker model when doing so creates a meaningful risk of mistakes, rework, incomplete coverage, or degraded quality.

Give every sub-agent only the context, files, tools, and question it needs. Avoid overlapping assignments and repeated exploration. Require concise, evidence-backed results that are easy for the orchestrator to integrate.

Use adaptive escalation: begin at the lowest tier that is reasonably likely to succeed, but escalate promptly when evidence shows uncertainty, insufficient capability, conflicting findings, failed verification, or elevated risk. Do not repeatedly retry an incapable model merely to avoid upgrading.

Verification should be proportional to risk. Use tests, targeted review, or an independent stronger-model check when the expected value exceeds its cost. Stop delegating and researching when the task is complete, important uncertainties are resolved, and additional work is unlikely to change the result.

The final objective is not the fewest tokens or cheapest run. It is the strongest reliable result with the least unnecessary computation.
