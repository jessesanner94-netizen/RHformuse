# Intraday-only options — September 22, 2026

User requested DAY-only SPY/QQQ options and intraday priority. DAY_ONLY_OPTIONS
controls the transition. Discovery selects nearest permitted expirations without
a reserved swing slot, style qualification exposes DAY only, and both calendar
admission and final paper fill reject SWING. Contracts may expire on a later day;
DAY refers to holding period, not zero-day expiration. Existing no-0DTE policy stays.

Technical admission keeps the 5M/15M direction score and other Python risk/data gates.
The separate broader-trend-triggered countertrend confirmation veto is disabled in
this mode. Daily/4H remain available to Luna as context. Opposing intraday direction
still rejects. JEV ranks qualified options and Luna decides BUY/PASS/WATCH.

Normal-session entry cutoff15:30ET and mandatory monitored exit15:45ET are unchanged;
early-close days use the exchange calendar. No new overnight options positions.
At implementation inspection, the primary paper ledger was flat; the independent
baseline held one QQQ DAY position, already using the existing same-day exit policy.
No ledger history or open-position thesis was rewritten.

Crypto keeps its separate outside-stock-hours spot paper experiment and relative
JEV gate. No task schedule, crypto rule, stop/target, daily loss budget or live lock
was changed. Existing scheduled cycles load configuration each run.

Enabled in CONFIG.md. Validation: 506 tests passed; full tools/tests Ruff clean.
