# Stop-after-positive-realized-P&L replay - September 23, 2026

[account details redacted]

Method: process entries and exits chronologically in America/New_York. Once retained closed-trade net P&L exceeds zero on a day, latch a block on later entries for that day. Retain exits for positions already entered. Reset each trading date. Use recorded trade net P&L, including recorded costs. Do not invent replacement trades, resize later trades, or change recorded fills.

| Date | Actual net | Replay net | Skipped entries |
|---|---:|---:|---:|
| 2026-09-08 | $-46.10 | $-46.10 | 0 |
| 2026-09-10 | $+9.90 | $+9.90 | 0 |
| 2026-09-11 | $-23.10 | $-23.10 | 0 |
| 2026-09-16 | $-10.20 | $+29.90 | 1 |
| 2026-09-17 | $-30.30 | $+29.90 | 2 |
| 2026-09-18 | $+19.70 | $+21.90 | 2 |
| 2026-09-22 | $-33.10 | $-33.10 | 0 |
| 2026-09-23 | $+22.70 | $+26.90 | 2 |

[account details redacted]

Before JEV (September 8-18): actual -$80.10, replay +$22.40. JEV period (September 22-23 recorded options trades): actual -$10.40, replay -$6.20. September 23 alone: +$22.70 versus +$26.90.

This is a fixed-record counterfactual, not a fresh strategy backtest. It includes existing simulated fills, including assumed-limit take profits. Changed capital, risk capacity, later selection, and market responses are not resimulated. Strategy changes across the period limit transferability. The post-JEV sample is four trades on two days. No trading settings changed.
