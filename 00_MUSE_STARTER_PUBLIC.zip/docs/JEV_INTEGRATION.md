# JEV integration — 2026-09-20

**Later same-day update:** the user approved active paper JEV filtering, options WATCH, a shared
20-call Luna allowance and an off-hours ETH spot paper experiment. These are now configured;
the shadow-only status below is the original delivery record. See `docs/ETH_PAPER.md` for current
behavior, validation and scheduling. Live execution remains disabled.

JEV is integrated as optional, instrumented shadow research. It does not currently filter Luna
or change orders. Live execution remains disabled; existing Python risk rules and Luna's
13-call daily ceiling remain authoritative. No scheduled task was created, enabled, or reconfigured.

## Architecture and operating mode

Previously: Python collection and hard gates → one compact Luna decision → Python execution gates.

Implemented: Python collection and hard gates → optional JEV scoring and rolling book context
→ optional JEV escalation policy → compact Luna decision → the same Python execution gates.
In the enabled shadow configuration, JEV runs concurrently; its scores stay out of Luna's packet
and cache signature. The cycle joins research after applying the downstream decision.
JEV transport, parsing, credential, or storage failure leaves the baseline route available.
The Level II read has a bounded timeout and returns unavailable/empty data explicitly.
In shadow mode it also runs in a background task, so the baseline route does not await depth.

After Luna's daily budget is consumed, Python/JEV research can continue on existing opportunity
invocations. No additional Luna call is allowed. Reservations use an OS lock and guarded writes;
malformed budget files fail closed. The Windows launcher source now honors this research exception.
This does not revive a task that was previously disabled; scheduler state was not changed.

## Files delivered

New modules: `tools/jev_client.py`, `jev_config.py`, `jev_credentials.py`, `jev_questions.py`,
`jev_features.py`, `jev_store.py`, `jev_pipeline.py`, `jev_replay.py`, `orderbook.py`,
`watch_state.py`, `watch_monitor.py`, and `runtime_lock.py`.

Integration changes: `tools/scheduled_cycle.py`, `tools/decision_context.py`,
`tools/robinhood_mcp.py`, `automation/run_cycle.ps1`, `CONFIG.md`, `strategy/COST_POLICY.md`,
`prompts/DECISION_AGENT_AGENTS.md`, and `.gitignore`.

New prompts: `prompts/COMPACT_WATCH_DECISION.md` and `prompts/watch_decision.schema.json`.
Documentation: this report, `docs/orderflow_features.md`, and `docs/jev_evaluation.md`.

Tests: `tests/test_jev_client.py`, `test_jev_questions.py`, `test_jev_features_store.py`,
`test_jev_pipeline.py`, `test_jev_replay.py`, `test_orderbook.py`, `test_watch_state.py`, and
`test_watch_monitor.py`, and `test_model_budget_concurrency.py`. Existing `test_config.py` was aligned with the approved
five-minute cadence; historical fixtures in `test_paper_repair_integration.py` explicitly disable
the unrelated economic calendar and optional research. Production macro gates remain intact.
`state/DAILY_STATE.md` records this engineering change, without asserting refreshed account state.

The repository was already entirely untracked, so no clean tracked baseline or trustworthy
Git diff existed. No unrelated files were committed and no handoff archive was edited.

## Configuration and credentials

Enabled: `ENABLE_JEV`, `JEV_SHADOW_MODE`, `ENABLE_LEVEL2`, `ENABLE_ORDERFLOW_FEATURES`,
`ENABLE_ORDERFLOW_JEV`. Disabled: `ENABLE_JEV_ESCALATION`, `ENABLE_MULTI_WATCH`,
`ENABLE_DYNAMIC_LUNA_ESCALATION`. `LIVE_EXECUTION_ENABLED` remains false.

Local guardrails: 6 attempted requests/minute, 1,000/day, 12-second per-request timeout,
2 retries, 0.5-second initial backoff, 64 KiB request and response bounds. These are local
assumptions, not provider quotas or a guaranteed dollar cap. Durable reservations conservatively
reserve all possible attempts before a call; unused retry reservations are not refunded.
429/529 responses use bounded backoff; authentication/schema errors do not retry.

`TYPESAFE_API_KEY` takes precedence, with `JEV_API_KEY` supported as an alias. Otherwise the
client uses the current Windows user's DPAPI-encrypted `state/runtime/jev_api_key.dpapi`.
The supplied key was saved for the actual Windows host identity and successfully authenticated.
An isolated sandbox identity may be unable to decrypt it; scheduled execution must use the same
Windows user. No plaintext key is stored in configuration, reports, or research evidence.

Official contract verified: TypeSafe `POST https://api.typesafe.ai/v1/systemone`, model
`jev-latest`, structured state plus typed questions. Responses record the actual model version.
One synthetic API smoke test returned `jev-1.13.0`, 300 input tokens and 21 output tokens.
It was a connectivity/contract check, not a trading accuracy test.

## Questions and feature semantics

`jev-market-v2` contains 15 questions: continuation in both directions, setup and timing quality,
momentum, volume, breakout and reversal risk, trend/range judgments, escalation, and regime.
`jev-book-v2` contains 13 book-only questions on pressure, imbalance, liquidity withdrawal,
support/resistance, breakouts, reversals, and directional confirmation. The source module contains
the exact frozen wording and criteria. Scores are uncalibrated model judgments, not measured win rates.
Absorption/exhaustion questions exist but are not submitted without genuine executed trade prints.

Features include numerical indicators and semantic labels. Missing ATR, VWAP, or depth remains
unavailable. VWAP distance in ATR units is `(underlying - session VWAP) / ATR`; labels are derived
[account details redacted]
included. A provider-neutral completed-minute callback validates timestamps, OHLCV and Python
qualification, includes the actual bar, deduplicates it, and never invokes Luna itself.
It is not wired to an invented one-minute feed; current scheduling remains five minutes.

Optional escalation defaults are setup >= .85, escalation >= .80, false-breakout risk <= .25.
Dynamic mode can raise setup to .90 for the last three Luna calls. These are unvalidated research
defaults and are disabled for routing. All prior hard gates still apply even if scores are high.

## Persistence, WATCH, and replay

New SQLite tables initialize on first use; existing paper/live ledgers are not
migrated. `state/research/jev.sqlite3` uses schema version 1 and stores timestamped feature/evaluation observations,
events, request reservations, deduplication claims, and per-observation/horizon outcomes.
Book history and WATCH state use separate research databases. Unknown JEV schema versions fail closed.
SQLite coordination is single-host; OneDrive is not a distributed database locking mechanism.
Runtime databases and DPAPI credentials are Git-ignored.

WATCH is implemented but disabled. It uses exact symbol/contract/direction/style identity,
thesis, bounded conditions, expiry of at most 60 minutes, and a maximum of three active/claimed
watches. Wake conditions are ANDed; invalidation conditions are ORed. Only typed scalar comparisons
are supported; no arbitrary expression evaluation. Fresh equity price and exact refreshed contract
eligibility are required. Already-satisfied handoffs are rejected to prevent repeated calls.
Transactional leases make a wake single-use; ambiguous interrupted leases require recovery instead
of automatically repeating a model call. Terminal identities are conservatively retained, which
can suppress later reconsideration of the same identity. Legacy WAIT cache behavior remains.

Research records Python rejections, JEV errors/scores/version/usage/latency, suppressed candidates,
actual Luna routing, and downstream results. Replay labels 1/5/15/30-minute underlying outcomes,
MFE/MAE and target/stop ambiguity from supplied timestamped prices. It does not invent option fills
or option P&L. Score availability is timestamped at actual response completion. Missing coverage
stays missing. Shadow rows describe the actual Python→Luna path, with separately labeled potential
policy suppressions; they cannot establish causal improvements from a JEV-filtered strategy.
See `docs/jev_evaluation.md` for commands, buckets, and attribution limitations.

## Data limitations and next validation

The Robinhood equity price-book endpoint was verified read-only for SPY/QQQ. Sunday responses
contained empty bid/ask arrays; these are NO_DEPTH, not fabricated books. No genuine executed-print
feed was verified. Snapshot changes cannot distinguish fills from cancellations or prove spoofing,
absorption, exhaustion, or hidden liquidity. Five-minute snapshots cannot resolve subminute behavior.
Rolling windows report observed coverage and gaps; a nominal 60-minute window does not imply
60 minutes of continuous depth. Formula definitions are in `docs/orderflow_features.md`.

Next validation: during a normal open market session, run the existing opportunity cycle in shadow,
verify host credential access, obtain at least 60 minutes of timestamped SPY/QQQ depth and eligible
candidate evidence, and inspect coverage, errors, latency, usage, and unchanged Luna routing. Then
attach actual timestamped future prices and replay the 1/5/15/30-minute labels. Compare held-out
sessions and call costs before considering escalation or WATCH activation. No follow-up was scheduled.

## Review and agent usage

Lead integrated the architecture and reconciled review findings. Independent review found and drove
fixes for stale WATCH equity/style gates, exact contract identity, already-triggered WATCH loops,
shadow latency, score-availability timestamps, look-ahead in replay extrema, duplicate routing
attribution, future book snapshots, and sparse-depth coverage. No evidence of trading alpha is claimed.

| Agent role | Model | Assigned work and result |
|---|---|---|
| Repository pipeline audit | Luna | Identified the compact routing hook and budget boundary |
| Data/storage audit | Terra | Found missing local Level II adapter and persistence constraints |
| Risk/WATCH design | Sol | Designed bounded watches; identified budget reset/concurrency risk |
| JEV client | Sol | Typed client, limits, questions, strict response tests |
| WATCH implementation | Sol | Transactional watch state, prompt/schema and tests |
| Order-book engine | Terra | Initial work interrupted by host restart |
| Budget hardening | Sol | OS lock and fail-closed budget reservations |
| Order-book completion | Terra | Collector, rolling metrics, zones, quality and tests |
| Research/replay | Terra | Point-in-time labels, attribution, immutable outcomes and docs |
| Validation completion | Sol | Question coverage, concurrent-budget tests and fixture repairs |
| Independent review | Sol | Read-only adversarial integration review and follow-up findings |

Final validation: `python -m pytest -ra` passed all **345 tests** in 18.92 seconds.
Scoped Ruff passed for all new integration modules, modified routing/budget/broker modules,
and associated tests. Whole-tree lint was not claimed clean: unrelated existing paper-trading
files have pre-existing lint findings. Tests use synthetic/stubbed market data and temporary
state; they do not establish live-market reliability or profitability.
