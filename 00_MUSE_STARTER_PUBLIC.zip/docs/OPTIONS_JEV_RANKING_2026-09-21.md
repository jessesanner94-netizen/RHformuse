# Paper options: JEV ranking instead of admission

Authorized September 21, 2026. `OPTIONS_JEV_RANKING_ONLY: true` applies only with
paper enabled and live execution disabled. Crypto policy is unchanged.

Python still determines qualification. JEV compares a bounded shortlist (up to
three eligible candidates) and prioritizes setup quality, entry timing, then its
escalation score. The first READY watch continuation takes priority. Existing valid BUY
cache reuse remains available. No numeric JEV score is a veto or a calibrated
probability of profit. If any selection-pool rank is unavailable, Python order is
the fallback. At most one candidate reaches Luna per scan; Luna retains the
BUY/PASS/WATCH decision without seeing JEV scores/verdict. Python risk, cache,
watch, shared daily budget, and final fill checks remain binding.

## Observed opportunities to rank

September 21 activity log snapshot: 78 options opportunity cycles. 64 cycles
reached JEV: 40 evaluated two Python-qualified candidates and 24 evaluated one.
Thus 62.5% of cycles reaching JEV had multiple candidates. The remaining 14 did
not reach JEV. Preliminary discovery reported three candidates in 17 cycles,
two in 37, one in 13, and none in 11. Preliminary discovery is not full technical
and risk qualification. Counts describe evaluations, not unique opportunities
or possible profitable trades; candidates can recur across five-minute scans.
Source: `state/logs/2026-09-21.jsonl`, `result.routing.jev_evaluations` and
`result.event.option_discovery.qualified_candidates`. Previous veto routing can
also affect how many candidates were inspected. This single day does not prove
future frequency or that ranking improves returns.


Final ranking verification: 485 tests passed in 28.76 seconds; full tools/tests
Ruff clean. Tests cover best-of-three selection below the former thresholds,
complete/partial JEV failure fallback, READY watch priority, budget-blocked claim
release, and all-cache-blocked suppression. These are mocked integration tests,
not a market-hours production fill. No trades or scheduled-task changes were made
for this ranking implementation. The existing options process reads current
configuration on its next scheduled run. Crypto routing remains unchanged.


## September 22: historical-average observation only

Each selected winner now records setup score, prior arithmetic mean, matching sample
count and above_average true/false/null in jev_ranking.historical_comparison and the
JEV SQLite options_winner_comparison event. Compare same ETF, CALL/PUT direction,
model and exact question versions; exclude current/future/unavailable-at-time results.
No history or unavailable scores are unknown, never counted as above average.
The population is prior Python-qualified scans, not only prior winners. Repeat scans
are not independent trades. selection_count and selection_kind distinguish one-candidate
selections and watch priority from competitive rankings. This telemetry never changes
routing or Luna inputs. No scheduled follow-up was created. Validation:38 focused tests
passed, including below-average winner still routed and missing scores logged unknown.
