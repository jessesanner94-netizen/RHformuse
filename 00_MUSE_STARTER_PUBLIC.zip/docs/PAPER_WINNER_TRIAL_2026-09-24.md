# September 24 paper winner-continuation trial

User authorized this one-session test on September 23. The primary paper ledger
was flat when setup began. Only newly opened primary DAY options on September 24
(America/New_York) enroll. Enrollment and management parameters persist with the
position; subsequent days' new trades return to fixed targets without a new task.

## Exit behavior

- The existing 30% premium target becomes a checkpoint at a fresh executable-side
  paper bid. Trial positions do not receive assumed historical TP-limit fills.
- Continue only with fresh completed 5-minute trend and current-session structure:
  neither opposes the original call/put direction, and at least one supports it.
  Both neutral, missing, or stale is not enough to extend. Fifteen-minute evidence
  is context. This rule checks directional continuation, not every possible
  condition in Luna's free-text thesis; original thesis/invalidation remain logged.
- After activation the trailing trigger is the maximum of the previous trigger,
  original stop, entry premium times 1.10, and observed bid high-water times 0.90.
  Example: $1.00 entry, $1.30 checkpoint -> at least $1.17 trailing trigger;
  a later $1.60 observed bid raises it to $1.44. The trigger never loosens.
- Exit on reversal, unavailable continuation after activation, trailing trigger,
  original hard stop, or the existing calendar-aware deadline. Stops are triggers,
  not guaranteed fills: paper sells use a fresh bid with existing cost estimates.
- End-of-day remains 15 minutes before the NYSE close (normally 15:45 ET).
  Two-minute monitoring still requires Windows awake, logged in, and connected.

## Order book and JEV

The collector requests compact Robinhood displayed-depth context alongside bounded
intraday data. Book imbalance is support/opposition context, never a standalone
exit or hold veto. There is no executed-trade feed: no claim of observed absorption,
seller exhaustion, or executions through bids is made.

After Python commits a supported checkpoint hold, JEV may assess continuation and
reversal evidence once per position. It uses the shared JEV request allowance,
a four-second timeout, no retries, and at most one assessment per monitoring cycle.
This opinion has **no routing or exit
authority**. An unfavorable score, exhausted budget, API failure, or timeout cannot
turn HOLD into EXIT or relax a protective exit. No extra Luna call is needed.
The research event lives in `state/research/jev.sqlite3`, event kind
`winner_checkpoint_advisory`, separate from entry-scoring history.

## Comparison and boundaries

The existing independent baseline ledger retains fixed targets. It is a control
with its own entries and cash, not a perfectly matched counterfactual for each
primary trade. Compare entry differences, observed bid paths, exit reasons, costs,
and realized P&L before drawing conclusions about winner management.

Crypto, live execution lock, Python entry gates, options JEV ranking, Luna entry
review, position sizing, daily entry/loss limits, and task cadence are unchanged.
This does not add stop-after-net-green for options.

## Validation

The intraday-only read-only SPY feed smoke succeeded on September 23 in 5.22 seconds,
returning fresh completed 5M/15M data. This verifies collection in the normal host
environment, not tomorrow's market outcome or guaranteed provider availability.
The complete collector was also tested read-only: after fixing request-start
versus receipt-time validation, Robinhood depth was OBSERVED and fresh intraday
data was available in 5.03 seconds. In that later sample both directional signals
were neutral, so continuation correctly returned UNAVAILABLE instead of forcing
a hold. No trade or model call was made by either diagnostic.

Full suite: 524 tests passed. After the final per-monitor advisory bound and
advancing-clock regression improvements, all 28 affected tests passed. Ruff is clean.
