# SPY/QQQ paper comparison — September 21, 2026

User approved correcting JEV inputs/questions, a bounded blind comparison, and better
broker diagnostics. No threshold reduction or live execution is authorized by this test.

JEV now sees the configured premium stop/target and software-management flag. The revised
questions distinguish this risk plan from a chart invalidation and ask whether evidence
merits final Luna review rather than requiring ambiguity. Version: options-review-v3.
These input/question repairs persist for SPY/QQQ paper evaluations.

The dated comparison samples up to three otherwise JEV-rejected, Python-qualified setups:
one during each Eastern window 11:00–12:30, 12:30–14:00, 14:00–15:30 on September 21.
At most two samples per ETF. No borrowing future slots, catch-up, or next-day renewal.
JEV must be active and successful with valid scores and acceptable false-breakout risk.
Error/shadow/missing-score outcomes cannot qualify. Existing caching, exposure checks,
shared 20-call allowance, and final paper execution checks remain binding.

Luna sees no JEV scores, verdict, sampling label, or prior WATCH prose during active trial
windows. Python still evaluates WATCH conditions independently. Both normal JEV passes
and sampled rejections receive blind review. Scores/observations and the sampled route
are retained separately in routing logs, never sent in the decision packet.

SQLite reservations under state/research/options_trial.sqlite3 enforce one sample per
window transactionally. Failures after reservation consume that sample. A race after the
global call reservation may conservatively consume a call allowance without model launch.
Preview and budget-rejected runs do not reserve a sample. Cached BUY cannot bypass a JEV
rejection via the trial without a fresh review.

Inspect state/logs/2026-09-21.jsonl: result.routing.options_jev_trial identifies sampled
reviews; routing.decision_verdict and result.paper_decision show Luna and execution outcomes.
JEV observations retain scores and question versions. Compare repeated observations carefully;
three reviews cannot establish win rate or profitability. Existing paper trade alerts apply.

Robinhood tool errors now expose only a fixed diagnostic category (rate limit, authentication,
timeout, server unavailable, invalid request, or unspecified), never raw provider error text.
Option-instrument discovery retries once only for recognized timeout/server error responses.
Authentication/rate-limit/unknown failures stop safely; no order endpoint is retried.
The original 10:31 error's detailed cause cannot be reconstructed from its old generic log.
