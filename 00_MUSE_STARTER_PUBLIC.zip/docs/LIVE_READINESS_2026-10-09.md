# Robinhood live preparation — October 9, 2026

Preparation is complete for review, **not certified for unattended real-money
trading**. Live execution remains false, paper remains true, and the new automatic
live-entry switch remains false. No real order, cancellation, broker order review,
account-setting change, scheduled-task change, or future launch was performed.

## Requirement audit

| Item | Evidence and result | Remaining boundary |
|---|---|---|
| Limit entry, fills, cancellation, reconciliation and duplicate prevention | Existing protocol/lifecycle tests plus new contradictory/partial/cancelled-fill, unknown-submission restart and late working-order tests; synthetic requests pass current broker schemas | Actual broker acceptance, fills, cancellation races and market-exit prices need an owner-approved real test |
| 10-second position protection | `tools/live_fast_monitor.py`; timing/overrun, timeout, freshness, concurrent poll, 429 and heartbeat/owner tests; default read-only broker smoke completed in 4.266s | Held-position execution latency and broker throttling need prospective observation; no resting stop or TP order |
| Operational recovery | Persisted OAuth-expiry/refresh/reconnect tests; noninteractive auth failure; durable ambiguous references; fill reconciliation once across restarts; prior-day fill timestamps; manual-cancel alert after deadline | Missing broker IDs, mismatched positions, malformed state and unsupported fractional fills require operator reconciliation |
[account details redacted]
| Activation approval package | Proposed staged activation and bounded test below | Explicit approval and real verification have not occurred |

## Preserved strategy and state

Python decides direction/eligibility; JEV ranks/selects fully qualified contracts.
No Sol, Luna or other judgment model is added. All normal deterministic gates
remain: SPY/QQQ DAY-only, one contract, no 0DTE, current DTE/Greeks/liquidity/event
and session rules, three entries/day, buying power and held-ticker checks, 25%
stop and 30% target, inclusive net reward/risk >= **1.00**, and the smaller of
$45 / 12.5% start-of-day equity daily-loss limit including outstanding stop risk.
The realized daily green lock stays sticky after first net positive closed-trade
P&L and never force-closes existing positions. Existing cost estimates remain
$1.05 per contract per side. No historical results were copied or overwritten.

The initial protected-file audit captured 113 files. Every existing paper/live
ledger and event file remained hash-identical. Only `CONFIG.md` and the launcher
source changed among that protected set, within authorized preparation scope.
Registered task actions/triggers/runtime limits compare unchanged. Positions
retains PT8H runtime and its two-minute restart trigger; that trigger is not the
future live quote cadence. Crypto tasks remain disabled; existing paper remains
on its separate 10-second loop. No executing live monitor was started.

## Monitor and recovery semantics

- Prepared settings: `LIVE_FAST_MONITOR_ENABLED: true`,
  `LIVE_OPEN_POSITION_POLL_SECONDS: 10`,
  `LIVE_POSITION_QUOTE_MAX_AGE_SECONDS: 20`,
  `LIVE_MONITOR_REQUEST_TIMEOUT_SECONDS: 8`.
  They have no order authority while `LIVE_EXECUTION_ENABLED: false`.
  The old `OPEN_POSITION_POLL_SECONDS: 120` is retained for legacy read-only
  adaptation; the prepared live launcher uses the dedicated 10-second settings.
- `LIVE_NEW_ENTRIES_ENABLED: false` lets a future explicitly approved executing
  monitor manage known positions while automatic entries are still prohibited.
  Opening this switch also requires a healthy executing heartbeat <=20s old,
  matching epoch and an OS-held resident owner lock. A stale, dead, read-only,
  pending-order or attention heartbeat cannot authorize an entry.
- The loop has no scanner/JEV/judgment-model dependency. The OS owner lock fences
  duplicate resident processes. The existing ledger lock also fences scheduled
  opportunity management, with bounded lock acquisition. Calls never overlap or
  catch up missed ticks. Slow polls exceed the target cadence and are logged.
  Multiple orders/read steps can make a complete poll take longer than 10s;
  the 8s timeout is per request, not a promise about total cycle duration.
- Quotes/snapshots must be <=20s old and no more than 2s future. Input age and
  config are checked again after review. A stale quote or unavailable broker data
  generates attention and blocks entries; it does not manufacture an exit price.
- A 429 waits at least 30s and honors longer Retry-After values. Monitoring opens
  a new read-only session on later ticks. It never retries an order submission.
  An outage, sleeping PC, lost process or unavailable API interrupts software
  stop protection. Entry fencing and notifications cannot remove existing exposure.
- The normal broker snapshot uses account, portfolio, positions and four open-order
  state reads, plus option quotes while held. That is up to eight tool reads per
  tick (roughly 48/minute at 10s). Current broker limits are not established; the
  loop backs off instead of claiming a guaranteed 10s service under throttling.
- Submission reference/request is saved before placement. Timeout, cancelled
  coroutine, process death or missing broker ID leaves a durable unresolved record.
  No blind reprice/resubmit or automatic cancellation occurs. Pending entries block
  later entries but not exits on other known contracts. Pending exits fence their
  own contract. Untracked positions/orders and quantity mismatches require attention.
- A one-contract order with cumulative execution quantity one is accounted even
  if the status is partial/cancelled. Explicit zero-fill/filled contradictions,
  unexpected/fractional quantities or unresolved fill price stay pending for manual
  reconciliation. With no quantity field, a filled status plus actual fill price
  retains the existing one-contract fallback; partial/cancelled price evidence
  without quantity cannot be discarded. Cancellation and fill evidence are separate.
- Broker execution timestamps (latest single-leg execution or filled_at), when
  available, determine the realized day. Prior-day fills recovered later update
  lifetime P&L without locking the new day. If timestamps are absent, existing
  reconciliation-time accounting is retained; that limitation is not hidden.
- A working entry past its hold deadline produces a manual-cancellation alert.
  It can still fill late until the owner cancels or the broker expires it; the
  project does not assume an unfilled limit is harmless or automatically cancelled.
- OAuth refresh remains encrypted and noninteractive. A missing/revoked refresh
  authorization fails with `robinhood_authorization_required`; only the explicit
  `python -m tools.robinhood_mcp auth` command may open a login browser.
- Material notifications run outside the protection path, using the existing
  channels; unchanged attention is coalesced within the process. No test push was
  sent. A failed notification is not a substitute for checking the heartbeat.

## Verification evidence

Broker account snapshot: **October 9 21:54:00 ET**. Independent reconciliation
and fresh tool schemas: **22:00:08 ET**, QUIET/RECONCILED, all four local
limit-entry/market-exit review/placement schema checks passed; zero broker reviews,
orders or cancellations. These times are Eastern, although artifacts use UTC.

Default read-only new-monitor smoke at **22:04:01 ET**: QUIET, 4.266s, execution
false, entry-safe false, zero models/orders/cancellations. This verifies connectivity
and the read-only fence, not execution. Production ledgers remained unchanged.

Full offline regression: **630 passed in 51.50s**. An additional assertion confirms
the new-entry switch still permits synthetic protective exits; the final focused
rerun passed **33 tests in 4.49s**. Ruff tools/tests and launcher PowerShell parser
passed. Windows sandbox asyncio initialization stalled; only our identified test
processes were stopped, and offline tests ran in isolated temporary directories
outside that restriction. No trading process was stopped.

Evidence folder: `.tmp/live-readiness-20261009/` contains the broker snapshot,
current schemas, read-only result, protected before/after hashes, task comparison,
JUnit test report and check script. Runtime read-only heartbeat is
`state/runtime/live_fast_monitor.json`. Tests: `tests/test_live_fast_monitor.py`,
existing `test_live_trading.py`, `test_live_multi_position.py`, `test_order_protocol.py`,
`test_robinhood_mcp.py`, and `test_options_deterministic.py`.

```powershell
.venv/Scripts/python.exe -m pytest tests -p no:cacheprovider --basetemp <isolated-temporary-directory> -o addopts= -q
.venv/Scripts/ruff.exe check tools tests
.venv/Scripts/python.exe -m tools.live_fast_monitor --once
```

The last command is read-only by default. Do not append `--execute` until execution
is explicitly approved. No command in this report is scheduled or automatically run.

## Proposed bounded real-order test — separate approval required

This is a plan for the account owner to execute through Robinhood, not authorization
for Codex to submit orders. Do not describe the security or test as safe.

1. During a regular session, at least 30 minutes before the DAY exit deadline,
   obtain a fresh fully Python-qualified, JEV-selected SPY/QQQ DAY contract. All
   ordinary gates must pass; no arbitrary security or forced trade. If nothing
   qualifies within this bound, skip the test.
2. Propose **one long contract, one entry and one closing order**, quantity one,
   GFD buy-to-open limit at a fresh ask between **$0.84 and $1.00**. Maximum
   premium is **$100**, maximum modeled entry debit **$101.05**. Verify actual
   review fees fit the approved debit cap before submission. At $1.00, modeled
   stopped loss is $27.10 and target reward $27.90; the stop is not a guaranteed
   loss cap. The entire debit can be at risk. Normal daily-loss budget must fit.
3. Keep automatic live entries disabled. The owner reviews the exact contract,
   bid/ask, limit, fees, size and test exit plan before submitting. Record the
   actual order ID; independently read order status and positions.
4. If unfilled after 60 seconds, the owner cancels and verifies terminal state
   AND cumulative fills before doing anything else. No replacement/chase.
   Ambiguous acceptance, partial/contradictory quantity, unexpected exposure,
   stale data or account mismatch aborts further entries and requires owner action.
5. If filled, the owner promptly closes the one-contract test through Robinhood,
   using the normal sell-to-close market intent after fresh review. If a normal
   stop/deadline triggers first, exit takes precedence. An immediate close may
   lose the spread and costs; it need not be profitable. Verify filled exit and a
   flat account/no open orders. A stuck exit requires the owner's direct attention,
   never a duplicate blind order.
6. Save actual orders, executions, times, costs and status transitions as clearly
   labeled verification evidence. Replay these broker-shaped responses offline.
   A prompt buy/sell test verifies the order lifecycle, **not** a live 25% software
   stop trigger or a broker-held stop. Those remain distinct verification claims.

## Proposed staged activation — not performed

After reviewing the real test and any remaining limitations, obtain explicit
approval for these exact changes. This report does not grant that approval.

1. Reconcile account/positions/open orders and all unresolved submissions. Preserve
   the existing epoch and old history; do not import paper profits into live state.
2. For an approved management-only startup, set `LIVE_EXECUTION_ENABLED: true`
   and `PAPER_TRADING_ENABLED: false`; keep `LIVE_NEW_ENTRIES_ENABLED: false`.
   Paper ledger history stays intact. The prepared live monitor is the execution
   path; any process/task start or account-state enrollment needs that approval.
3. Start the resident live positions monitor with `--execute --notifications`,
   verify its process/owner, fresh healthy heartbeat, quotes, pending-order handling
   and existing notification channel. Observe held-position cadence and throttling
   under a separately approved controlled/prospective run before claiming stop
   behavior is live-verified. No monitor health means no automatic entries.
4. Only after the required verification and approval, set
   `LIVE_NEW_ENTRIES_ENABLED: true` for normal Python/JEV entries. Risk, cost,
   realized-green lock, sizing, exits and session rules stay unchanged.
5. To halt new risk, set only `LIVE_NEW_ENTRIES_ENABLED: false`; leave an executing
   position monitor running while exposure/orders remain. Turning off the global
   live flag or killing the process also disables software exits; first reconcile
   and manage exposure with the owner. No automatic shutdown/restart is proposed.

No Monday activation, reminder, automation or scheduled task has been created.

## Files changed

- `tools/live_fast_monitor.py` (new resident monitor and entry-health gate)
- `tools/live_trading.py` (freshness, post-review checks, fill/restart accounting,
  bounded ledger lock, entry interlocks and manual-cancel attention)
- `tools/robinhood_mcp.py` (unattended auth fence and complete snapshot validation)
- `automation/run_cycle.ps1` (future live branch only; registered tasks unchanged)
- `CONFIG.md` (new monitor settings and locked new-entry switch; live remains false)
- `tests/test_live_fast_monitor.py` (new focused tests)
- `tests/test_options_deterministic.py` (synthetic healthy-monitor fixture and
  explicit entry switch for the existing isolated risk tests)
- `strategy/STRATEGY.md`, `strategy/RISK.md`, `strategy/EXECUTION_RULES.md`
  (authorized preparation semantics)
- `docs/LIVE_READINESS_2026-10-09.md`, `state/POSITIONS.md`,
  `state/DAILY_STATE.md`, `journal/DECISIONS.md` (readiness evidence/memory)

Only isolated test states, read-only runtime telemetry and readiness artifacts
were created. Broker execution, actual fills and protective order guarantees
remain outside the demonstrated evidence.
