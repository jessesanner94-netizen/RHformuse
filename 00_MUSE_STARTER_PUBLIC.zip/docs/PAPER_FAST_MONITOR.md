# Paper position checks every 10 seconds

User explicitly authorized the paper-only monitoring change on October 9, 2026.
Live remains disabled. No test entry, real order, or broker-native stop is created.

## Settings and execution

`PAPER_FAST_MONITOR_ENABLED: true` selects the resident paper monitor from the
existing `RobinhoodAgentic-Positions` launcher. Its target interval is
`PAPER_OPEN_POSITION_POLL_SECONDS: 10`; quote age must be no greater than
`PAPER_POSITION_QUOTE_MAX_AGE_SECONDS: 20`, with at most 2 seconds of future clock
skew. Primary exits in the ordinary paper cycle use the same freshness limit.
The old `OPEN_POSITION_POLL_SECONDS: 120` remains for the disabled live path.

The existing Windows position trigger still fires every two minutes with
`IgnoreNew`: this starts or recovers the resident loop, rather than determining
quote frequency. Its execution limit is eight hours so it can run through the
regular session; the NYSE calendar ends the loop at the actual close, including
early closes/holidays. The launcher is hidden and retains the existing ntfy and
desktop notification settings. A process-wide OS lock rejects duplicate monitors.
Opportunity discovery remains on its existing five-minute schedule. No other
task, crypto setting, historical account or live setting is changed.

Each tick rechecks mode/configuration and reads the current independent primary
ledger. While flat it neither calls Robinhood nor initializes/rewrites a paper
account. A newly committed entry is detected on the next tick, subject to process
health. While invested it requests quotes for held option IDs only, in the
adapter's existing batches. No account/underlying/research/JEV/Luna call is made.
The shared atomic paper-account lock prevents a second exit when the ordinary
opportunity cycle and fast monitor both observe the same trigger.

Stops, targets, calendar-aware deadlines, net-P&L fees/slippage, the daily loss
limit and sticky realized-green entry lock are preserved. Entry locks never
disable the loop's exits. The loop has no entry function or live execution
adapter, and stops on the next iteration if live is enabled or paper/fast mode
is disabled. Live's old executor and cadence are not upgraded by this change.

## Slow data and failures

Quote requests have an eight-second timeout target with no immediate retry. The
next scheduled tick attempts another read after an ordinary failure. Ticks do not
overlap or attempt bursts to catch up; response/cleanup/disk delays can overrun
the ten-second target. A 429 pauses requests for at least 30 seconds and honors
a longer numeric or HTTP-date `Retry-After`; nested transport errors are handled.
No verified numeric Robinhood MCP throughput limit is assumed.

Missing, invalid, crossed, stale or excessively future-dated quotes cannot create
an ordinary paper fill. Failures retain positions and generate durable attention
telemetry; material notifications use the existing delivery/deduplication system
in a background worker. They do not delay the next quote check.

Minute-bar historical TP evidence runs as one bounded background job per minute
(or changed held-contract set), using the existing assumed-fill policy. Fresh-bid
stops never wait for historical data. A qualified historical assumed TP closes at
the existing cent-ceiling limit when the evidence is consumed; a stop already
committed before late history arrives is not rewritten. Faster observation and
evidence timing can therefore change prospective paper outcomes. Old results
are untouched, and modeled fills still do not establish real execution.

PC sleep, lost connectivity, API throttling, slow teardown, crashes or missing
fresh quotes can interrupt protection. Ten seconds is an observation target,
not a guaranteed exit latency or fill price. Broker-held live stops remain a
separate unimplemented project feature.

## State and verification

`state/runtime/paper_fast_monitor.json` records the target/observed interval,
duration, quote timestamp, position count (null if unknown), warnings and events,
with zero model calls and real orders. Event/error records also append under
`state/runtime/paper_fast_monitor/YYYY-MM-DD.jsonl`. Paper account events and
daily-lock accounting continue in the epoch's existing ledger.

Offline full regression: **589 passed in 47.74 seconds**. Final targeted tests
after tightening the future-clock check and adding singleton coverage:
**101 passed in 10.84 seconds**. Ruff and both edited PowerShell scripts pass checks. Tests
cover flat/no-API behavior, paper-only fencing, 10-second detection, freshness,
stop/target/deadline exits, accounting/green-lock activation, duplicate exits and
processes, timeout, 429 backoff, slow/history throttling, and adapter request scope.
Broker calls and notification delivery in tests are mocked.

Deployment verified at 11:37:04 ET on October 9: existing position task Running,
QUIET with zero open paper positions, target 10s and observed interval 10.01s.
No warnings, trading-model calls, entries, real orders or notifications occurred
in the deployment check. All eight checked primary/historical/control/comparator
ledger/event files are hash-identical. The existing task's triggers, action and
principal are unchanged; its execution allowance changed from PT10M to PT8H.
Other options/reset/crypto tasks retain their existing states. Held-position
network latency has not yet been observed prospectively with this new monitor;
its exit/data behaviors were verified with synthetic quotes and failures.

Commands used (outside the Windows sandbox, because asyncio initialization needs
local socket access):

```powershell
.venv/Scripts/python.exe -m pytest -ra --basetemp C:/Users/jesse/.codex/visualizations/2026/10/08/01a11b51-47c1-7512-9af6-b9264040ce2d/fast-paper-monitor-20261009-full-a -o cache_dir=.tmp/fast-paper-monitor-20261009/pytest-cache
.venv/Scripts/python.exe -m pytest tests/test_paper_fast_monitor.py tests/test_paper_trading.py tests/test_paper_repair_integration.py tests/test_paper_quality_gates.py tests/test_options_deterministic.py -ra --basetemp C:/Users/jesse/.codex/visualizations/2026/10/08/01a11b51-47c1-7512-9af6-b9264040ce2d/fast-paper-monitor-20261009-final-a -o cache_dir=.tmp/fast-paper-monitor-20261009/pytest-cache
```

Changed implementation/configuration: `tools/paper_fast_monitor.py`,
`tools/paper_trading.py`, `tools/robinhood_mcp.py`, `tests/test_paper_fast_monitor.py`,
`automation/run_cycle.ps1`, `automation/install_tasks.ps1`, and `CONFIG.md`.
Documentation: this file, root/tools README, strategy STRATEGY/RISK/EXECUTION_RULES/
COST_POLICY, and current state/decision notes. Deployment evidence and original
position-task XML are saved in `.tmp/fast-paper-monitor-20261009/`.
