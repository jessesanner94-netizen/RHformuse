# ETH/BTC paper expansion — 2026-09-20

Options WATCH and active JEV filtering are enabled for paper trading. The shared Luna ceiling
is 20 calls per 09:30-to-09:30 Eastern daily window, and ETH-USD is the only added asset. Live execution remains
false. The ETH engine has no brokerage order adapter and cannot place real orders.

## BTC and material-trade notifications enabled

The user added BTC-USD and requested paper entry/exit alerts for both coins. Both existing
Windows crypto tasks now run the configured ETH-USD/BTC-USD universe. No extra tasks or
live order support were added. The shared crypto ledger remains $369 with one open position,
one active watch, $50 entry notional, $5 daily planned-loss ceiling and three total entries/day.
Model budget stays 20 calls shared with options. One 30-minute crypto model cooldown remains;
bar deduplication is per coin. Scan priority alternates while flat; an open position or watch
selects its own coin. Symbol identity is enforced in feeds, packets, decisions and accounting.

Entry and exit alerts use the existing Windows notification and user-configured ntfy phone
channel. Committed SQLite trade events are the delivery queue. Successful channels are recorded
and not repeated; failed channels retry on a later task invocation. A process crash between
external delivery and its local acknowledgement can still cause a duplicate. Scan rejections,
JEV filters, quotes and HOLD do not create trade alerts. The runner loads the existing user
NTFY_TOPIC without printing it. Notification failures never roll back a paper trade.

A clearly labeled test returned Windows SENT and ntfy HTTP 200; it did not insert a fake trade.
At the initial status check ETH had zero entries/exits, no open position/watch and $369 cash.
A live BTC snapshot returned OK using Binance.US research and Coinbase paper prices, exercising
fallback. All feeds remain public/read-only; no Coinbase/Binance account access is involved.

## Current restored multi-source paper pipeline

This supersedes the Robinhood-only block and historical Coinbase descriptions below.
The user approved external research and public paper-price fallback on 2026-09-20.

- Research: Coinbase ETH-USD completed candles and depth, then Binance.US ETHUSD as backup.
- Paper pricing: valid Robinhood v2 quote plus fresh estimated fee, then Coinbase, then Binance.US.
- Every packet records execution-price venue separately from candle and book venue.
- Open positions and watches remain pinned to their pricing source. No cross-venue exit is
  silently substituted if that source fails. Final entry rechecks reject a changed research
  venue or increased fee. The original source is retained throughout each default decision cycle.
- Depth time-series databases are separate per provider to avoid artificial book changes.
- Public Coinbase/Binance data requires no login, API key or access to the user's exchange account.
- Genuine zero-volume Binance bars stay zero; nothing fills in missing trades or missing bars.
  The live sample had 45 zero-volume bars out of 100, supporting Coinbase as primary.
- Robinhood fees use the greater of the fresh estimate and the configured 0.25% floor. Position
  fees persist and can increase on exit. Public-venue fees remain simulation assumptions. Neither
  best-price quotes nor the 0.01 ETH fee sample guarantee the execution price of a $50 live order.

Both Windows crypto tasks now have daily triggers, repeating every 1/5 minutes. The initial
trigger date is a start date, not a one-time expiration. Python checks the NYSE calendar before
any flat crypto data/model request: regular sessions are idle; weekends, holidays, pre-open and
post-close are eligible. It resumes exactly at scheduled close, including early closes. A pending
watch is cleared at open; a still-open paper position receives exit monitoring until flat.
Tasks remain enabled/Ready so the next off-hours window starts automatically. They may briefly
launch the calendar check during regular hours; they do not fetch data or call models while flat.

The live restored snapshot returned OK with 300 completed candles, valid depth and a Coinbase
paper quote after Robinhood quote validation failed. This removes the missing-input blocker;
JEV/Luna still require the normal Python/risk gates and the shared 20-call budget. Live trading
remains locked and no brokerage order adapter was added.

Sources: https://docs.binance.us/ and
https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles

## Historical Robinhood-only status (superseded)

The user switched crypto data to Robinhood on 2026-09-20. Scheduled runs now use
`tools/robinhood_crypto_data.py`, a signed GET-only adapter with fixed endpoint/host allowlists,
redirect rejection, bounded responses, and local Windows DPAPI credentials. No scheduled crypto
path fetches Coinbase data. Existing Coinbase observations remain historical evidence only.
The flat ledger's source changed with an audit event; its cash and history were preserved.

Authenticated Robinhood responses confirmed ETH-USD is API-tradable. The regular crypto account
ending 3280 is API-tradable; the Agentic-linked crypto account ending 9682 is not. This does not
change the read-only API key or authorize orders. Account funding is not needed for quote reads.

The documented API provides best bid/ask, products, accounts and quantity-specific estimates,
but no historical OHLCV or full Level II book. The adapter never substitutes an external exchange
or fabricates depth/volume. Missing candle evidence blocks entries before JEV/Luna. Python quote
monitoring continues when quotes validate. Provider timestamps are validated when present;
otherwise receipt time is explicitly labeled. Best quotes exclude size and fees.

The live sample at approximately 13:11 ET had bid 2641.51 > ask 2640.91; the existing uncrossed
quote rule rejected it. The 0.01 ETH estimate reported a 0.0095 fee ratio per side. The old 0.25%
paper cost assumption is therefore not suitable as a verified Robinhood fee. Before resuming
entries, the candle/depth limitations and fresh quantity-specific costs must be resolved; entry
requirements and cost policy were not silently loosened. No real orders were placed.

Official documentation: https://docs.robinhood.com/

### Finding and stopping the Windows tasks

Press Win+R, enter `taskschd.msc`, select **Task Scheduler Library** itself (root), and refresh.
Sort the middle pane by Name. These are scheduled tasks, not entries in Task Manager's Startup list.
All five were verified enabled, Ready, and not hidden on 2026-09-20:

- `RobinhoodAgentic-CryptoMonitor`: every minute.
- `RobinhoodAgentic-CryptoOpportunities`: every five minutes.
- `RobinhoodAgentic-Positions`: existing equity position schedule.
- `RobinhoodAgentic-Opportunities`: existing equity opportunity schedule.
- `RobinhoodAgentic-DailyReset`: existing equity reset schedule.

Right-click either crypto task and choose **Disable** to stop its future runs; disable both to
stop all crypto polling. No duplicate tasks were created. A Last Run Result of 1 on a crypto
run means data was unavailable, not that the task is disabled. Current crypto entries are blocked
by missing evidence; enabled scheduling does not imply a trade or a model call.

## Historical Coinbase test

At 12:04 ET on Sunday, September 20, Coinbase supplied fresh ETH quotes, completed candles and
displayed depth. Python's continuation/risk/calendar gates qualified the candidate. JEV returned
setup quality 0.65 versus the 0.85 threshold and escalation 0.49 versus 0.80, so it filtered the
[account details redacted]
The independent monitor also completed FLAT without a model call. We did not loosen thresholds
to force a demonstration trade. This verifies connectivity and filtering, not profitability.

## Pipeline and risk

During NYSE regular hours, the existing SPY/QQQ options strategy operates. Outside regular hours,
including weekends and holidays, ETH paper opportunities can qualify. The NYSE calendar handles
holidays and early closes; ETH holding deadlines are at most four hours and no later than the
next equity open. Existing positions are monitored regardless of model budget or entry session.

Public Coinbase Exchange data → completed 5M/15M Python gate → JEV → isolated Luna BUY/PASS/WATCH
→ fresh market/risk checks → simulated fills. The experimental long-continuation rule requires
both completed timeframe closes above their 20-bar SMA, positive three-bar returns, and completed
5M relative volume >=0.5. Quotes, spread, macro calendar and paper risk must also pass. This is an
unvalidated hypothesis. Missing crypto news/social is labeled unavailable, not neutral support.

[account details redacted]
three entries/day, 2.5% stop, 5% target, $5 prospective daily loss ceiling and local stop-after-net-green.
Estimated costs are 0.25% per side plus 5 bps adverse slippage; these are research assumptions,
not verified Robinhood fees. Option risk rules and ledger are unchanged. Independent paper
balances must not be added together as if both represent the same real capital.

After Luna BUY, Python refreshes the full snapshot and reruns completed-candle, quote, session,
macro, cash, spread, count and planned-loss gates. A price move over 0.25% or changed risk settings
cancels the simulated entry. SQLite transactions prevent duplicate buys. Entries use ask plus
slippage and exits bid minus slippage, charging fees on both sides. Gaps/outages/sleep cannot
produce guaranteed historical stop fills; the next fresh bid determines the simulated exit.

## Calls and WATCH

All equity/crypto decisions and qualitative position reviews share one locked 20/day counter.
The user subsequently chose a 09:30 Eastern reset every day, including weekends and holidays.
Overnight ETH can use remaining calls until that boundary; there is no midnight or close reset
and no pre-open seven-call restriction. ETH opens no new positions during regular hours.
The reset is computed when checking/reserving calls, without a separate scheduled write. Python
stops/targets/deadlines and monitoring need no Luna reservation. Subscription cost is never a quota.

ETH has one price WATCH: future trigger, invalidation, and <=60-minute expiry. The minute monitor
checks it, and the next five-minute opportunity run must requalify through Python/JEV before
calling Luna. Ordinary repeat decisions have a 30-minute cooldown; a qualified WATCH wake may
bypass it. Interrupted calls count and are not blindly retried. Options retain up to three watches.

The activation audit fixed real options WATCH bugs: absent provider display symbols and mismatched
model-selected style. Identity now uses stable instrument ID plus symbol/type/expiry/strike/style.
Active JEV filtering is paper-only and fails closed on unavailable, duplicate or unusable scores.
These flags do not authorize live trading/filtering/WATCH.

## Scheduling and commands

With explicit user approval, the following Windows tasks were created/enabled:

- `RobinhoodAgentic-CryptoMonitor`: every minute, Python only.
- `RobinhoodAgentic-CryptoOpportunities`: every five minutes, off-hours entries only.

The existing `RobinhoodAgentic-Positions`, `RobinhoodAgentic-Opportunities`, and
`RobinhoodAgentic-DailyReset` tasks were re-enabled for their existing market-hours paper schedule.
Crypto tasks run only with Windows awake, logged in and connected; they do not wake the computer.
They skip overlapping instances. The separate monitor keeps slow research/Luna off its critical path.

Scripts: `automation/run_crypto.ps1` and `automation/install_crypto_tasks.ps1`. Latest scheduled
results go under `state/runtime/crypto/`. Manual commands from the project root:

```powershell
.venv\Scripts\python.exe -m tools.crypto_cycle --project-root . --monitor-only
.venv\Scripts\python.exe -m tools.crypto_cycle --project-root . --execute-models
```

Without `--execute-models`, a qualified candidate returns PREVIEW; research and existing paper
exits still run. State uses `state/research/crypto_paper.sqlite3`, `crypto_book.sqlite3`, and the
existing `jev.sqlite3`. These are single-host databases, not distributed OneDrive coordination.

## Robinhood account check and source limits

The connector confirmed Agentic has a linked crypto account ending 9682. It does not expose
`is_api_tradable`. The requested `GET /api/v2/crypto/trading/accounts/` was NOT authenticated or
run: the user confirmed no separate Crypto Trading API key has been created. API tradability
remains unknown; the MCP account-eligibility field cannot substitute for that API field.

Official references: [Agentic state restrictions](https://robinhood.com/us/en/support/articles/agentic-trading-overview/),
[Crypto API credentials](https://robinhood.com/us/en/support/articles/crypto-api/),
[Coinbase ticker](https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-ticker),
[book](https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-book), and
[candles](https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles).

Coinbase's live candle endpoint returned 350 rows despite its documented maximum of 300. The
adapter accepts at most 500 within a byte bound, validates all rows/gaps, and retains the latest
300 completed bars, requiring at least 63. Depth is capped at 50 levels per side. Exchange-time
and receipt-time timestamps are distinguished. There is no executed tape or verified absorption.
These are Coinbase prices and simulated fills, never labeled Robinhood execution truth.

## Validation and changed files

Full regression: 395 tests passed in 25.18 seconds. Scoped Ruff and both PowerShell scripts' AST
parsing passed. Tests cover ledger/cost math, deterministic exits, concurrency, day rollover,
session boundaries, stale/gapped data, shared budgets, JEV failures/shadow semantics, WATCH,
and adverse changes between decision and fill. Independent Sol review checked activation and
crypto boundaries. Final task smoke results are in `state/DAILY_STATE.md`.

New modules: `tools/crypto_market_data.py`, `crypto_paper.py`, `crypto_strategy.py`, `crypto_cycle.py`.
New prompts: `prompts/CRYPTO_AGENT_AGENTS.md`, `CRYPTO_DECISION.md`, `crypto_decision.schema.json`.
New tests: `tests/test_crypto_market_data.py`, `test_crypto_budget.py`, `test_crypto_paper.py`,
`test_crypto_paper_audit.py`, `test_crypto_cycle.py`. New automation scripts are listed above.
Modified: `tools/codex_trigger.py`, `decision_context.py`, `jev_features.py`, `jev_pipeline.py`,
`scheduled_cycle.py`, `watch_state.py`, `watch_monitor.py`; related config/WATCH/JEV tests;
`CONFIG.md`, strategy policies, `state/DAILY_STATE.md`, and integration documentation.

Delegation: Terra implemented the public feed; Sol fixed/reviewed WATCH and paper-only JEV and
audited crypto; Sol implemented locked budget admission and independent ledger/strategy tests.
The lead integrated the engine, scheduling, real-data paper smoke and documentation. No real orders.
