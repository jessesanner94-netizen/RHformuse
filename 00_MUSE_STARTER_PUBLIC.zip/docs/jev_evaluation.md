# JEV offline evidence evaluation

`tools/jev_replay.py` reads the existing JEV SQLite `observations`, `events`, and `outcomes`
tables. It does not call a broker, market-data provider, model, or network service.

```powershell
.venv/Scripts/python.exe -m tools.jev_replay state/research/jev.sqlite3
.venv/Scripts/python.exe -m tools.jev_replay state/research/jev.sqlite3 --prices local-prices.json
.venv/Scripts/python.exe -m tools.jev_replay state/research/jev.sqlite3 --prices local-prices.json --write-outcomes
```

The local JSON file is either a list, or an object containing `prices`, of timestamped records:

```json
[
  {"symbol":"SPY","timestamp":"2026-09-18T15:00:00+00:00","close":100.0,"high":100.0,"low":100.0},
  {"symbol":"SPY","timestamp":"2026-09-18T15:01:00+00:00","close":100.4,"high":100.5,"low":100.1}
]
```

It attaches 1, 5, 15, and 30 minute outcomes only when it has an explicit timestamped price at or
before each boundary, no older than `--price-tolerance-seconds` (default 60), and no gap larger
than `--max-gap-minutes` (default two minutes). This accommodates observations that arrive seconds
after a completed price bar without using a future price. `entry_source_at`, `measured_at`, and
`endpoint_lag_seconds` make that bounded lag visible. A missing/stale/duplicate source, bad
direction, gap, or future horizon produces `UNAVAILABLE`; the tool never selects a later price to
fill a missing horizon. MFE and MAE use supplied high/low observations. Target/stop levels must be
supplied as `target_price` and `stop_price`; the outcome is direction-aware for calls and puts. A bar whose high/low crosses both target and stop is
`AMBIGUOUS`, never ordered by an invented intrabar path.

MFE, MAE, and target/stop detection exclude the source/as-of bar's high and low: its close may be
used as the entry price, but its intrabar range occurred before the decision point. When an OK JEV
evaluation records `available_at`, forward outcomes begin at the later response-completion time,
including in shadow mode. This prevents scoring a JEV judgment against movement that happened while
the service response was still unavailable. Older records without `available_at` fall back to their
observation timestamp and are labeled accordingly.

`--write-outcomes` appends only complete `MEASURED` outputs to the existing immutable outcome slot
for `(observation_id, horizon_minutes)`. It does not update observations, evaluations, or events.
An existing different outcome is reported as a conflict and left untouched. Unavailable snapshots
are deliberately not persisted, since a later local price file may establish coverage. The current
SQLite schema cannot prevent an unrelated direct SQLite writer from modifying rows; this tool's
own write path is append-only and conflict-refusing.

The report lists only routing groups evidenced by persisted events: `Python -> Luna`,
`Python -> JEV -> Luna`, and `Python -> book -> JEV -> Luna`. It does not synthesize a baseline
from a JEV observation. A `luna_routing` event with a JEV observation is treated as a recorded JEV
route; `jev-book-v2` identifies the book variant. Shadow and failed JEV evaluations are classified
as `Python -> Luna` because they cannot have affected routing. Explicit `path`/`pipeline` event fields,
when present, take precedence.

Call counts are actual only when the routing event records `luna_escalated` as a boolean.
Hypothetical saved calls are reported only when the event explicitly contains
`baseline_would_call: true` and records no actual call. Shadow-policy suppressions are reported
separately as potential suppressions, never as saved calls. This avoids treating a cache hit, rate
limit, or unknown routing status as a saved model call.

The baseline group's winner-retention and loser-rejection fields remain unavailable because its
JEV policy was not an active gate. Shadow policy results may be inspected as potential suppression
counts, but are not presented as active routing performance.

Winner retention and loser rejection use measured 30-minute *directional underlying* returns and
the persisted JEV escalation policy. They are research-label rates, not trade P&L or evidence of
an option strategy. Expectancy, profit factor, and max drawdown are reported only for explicitly
supplied `realized_pnl` (or `realized: {"pnl": ...}`) in a `realized_outcome`, `paper_exit`, or
`execution_result` event, or in an immutable outcome row. The tool never converts underlying
returns, MFE/MAE, target/stop hits, or direction labels into option P&L.
