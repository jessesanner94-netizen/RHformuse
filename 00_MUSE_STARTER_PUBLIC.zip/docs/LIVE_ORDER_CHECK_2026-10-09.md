# October 9 order and stop verification

The user requested a live test buy/sell to verify limit orders and stops. No
real-money order was submitted and live execution remains disabled. Verification
consisted of offline mocked tests and authenticated read-only broker inspection.

## Results

- 46 focused tests passed in 4.21 seconds across `test_live_trading.py`,
  `test_live_multi_position.py`, `test_order_protocol.py`, and `test_robinhood_mcp.py`.
  They cover review-before-submission, request validation, duplicate/ambiguous-order
  handling, fills, software stops, and separate exits for multiple positions.
- Robinhood snapshot at 2026-10-09 09:53:07 ET returned OK, zero positions and zero
  open option orders; project reconciliation succeeded with no adapter errors.
- Robinhood currently advertises `review_option_order` and `place_option_order`.
  Synthetic entry-limit and exit-market payloads passed local validation against
  the freshly fetched schemas for both tools. This establishes request shape only;
  no candidate-specific broker pre-trade review or order acceptance was tested.
- Broker tool documentation advertises single-leg `stop_market` and `stop_limit`
  orders, but the project's executor does not currently place either type.

## Current implementation

Entries are one-contract buy-to-open limit orders at the refreshed ask, GFD.
Exits are sell-to-close market orders, including stop, target and deadline exits.
`STOP_MANAGEMENT_MODE: SOFTWARE_POLLING` and `OPEN_POSITION_POLL_SECONDS: 120`
mean the configured 25% stop is a Python trigger, not a resting broker stop order.
An outage, sleep, stale quote or gap may delay the exit or produce a loss beyond
the trigger. No limit-sell or broker-native protective-stop lifecycle was verified.

Tests and schema checks do not establish real fills, execution prices, or broker
stop triggering. A real-money execution test must be submitted by the account owner
in Robinhood. No security was selected or described as safe.

## Reproducible evidence

Offline command (run outside the Windows sandbox to permit asyncio initialization):

```powershell
.venv/Scripts/python.exe -m pytest tests/test_live_trading.py tests/test_live_multi_position.py tests/test_order_protocol.py tests/test_robinhood_mcp.py -ra --basetemp C:/Users/jesse/.codex/visualizations/2026/10/08/01a11b51-47c1-7512-9af6-b9264040ce2d/live-order-checks-20261009-a -o cache_dir=.tmp/live-order-checks-20261009/pytest-cache
```

The read-only helper and saved broker evidence are in
`.tmp/live-order-checks-20261009/`: `read_only_check.py`,
`broker-tool-schemas.json`, and `read-only-result.json`. The helper only lists
tools and reads a snapshot; request validation is local against those schemas.
Broker reviews, placements and cancellations: zero. Configuration, strategy,
execution code, scheduled tasks and paper/live account ledgers were not changed.
