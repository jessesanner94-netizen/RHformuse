# Monday connection baseline restored — October 21, 2026

User explicitly requested restoring Monday October 19 connection handling, keeping quiet finish and improved diagnostics/grouped alerts, and preparing the existing live schedule for today over Ethernet. No strategy, CONFIG, sizing, stop/target, quote freshness, order semantics or risk settings changed.

The broker adapter is byte-identical to the pre-maintenance Monday Linux source (SHA256 584c11a6062b9f6001efa7258c12b88f4562483fc7d8134ee4854da6f19e17f3). The resident monitor again uses its default fresh snapshot reader. HTTP pooling and its helper/borrowed-client API were removed. Quiet finish and all incident/notification logic are unchanged. An independent read-only Sol review verified the exact scope.

Ethernet is connected and preferred by the default route (metric 100 vs Wi-Fi 600). An initial fresh broker snapshot took 4.465s and reported $457.95 equity, zero option positions and zero open option orders. Five subsequent read-only LiveMonitor polls, using the original eight-second request limit and ten-second spacing, all returned QUIET with no orders: 4.024s,3.379s,3.469s,3.427s,3.556s. No order review, entry, exit, trading-model call or production notification was triggered by these checks.

The isolated regression copy preserves production policy except live=false/paper=true, blocks DNS/socket networking, and uses synthetic broker/order/notification dependencies. All 163 selected monitor/adapter/execution/risk/reconciliation/notification/portability tests passed in 36.32s. Ruff tools/tests clean. Tests cover the fresh-client/session lifecycle and original CLI reader selection as well as the retained safeguards. CONFIG, strategy, prompts and live ledgers/events remained hash-identical through validation.

The prior pause marker has been restored after successful checks and explicit user authorization. Starting the existing system timers requires Linux administrator authentication; activation results are recorded below once verified. No new schedules or alternate bot owner are created. Windows is not started. No market-hours latency guarantee follows from these premarket checks; existing fail-closed heartbeat/quote/risk guards remain binding at entry and during normal operation.

Evidence, source snapshots/patch, hashes and test results: docs/transport_rollback_20261021/.

## Final schedule verification

At 2026-10-21T09:01:40.030705-04:00, after the user completed Linux administrator authentication, the timer-start command exited 0. Both original timers are active/enabled/waiting: positions starts October 21 at 09:30:00 EDT, opportunities at 09:30:15 EDT. Both services are inactive with MainPID=0 before open, so there is no manually started or duplicate owner. The restored launch gate is present. No manual trading run, test order, notification or new schedule was created. This supersedes the pending-authentication status above. Runtime evidence: state/runtime/USER_RESUME_2026-10-21.json.
