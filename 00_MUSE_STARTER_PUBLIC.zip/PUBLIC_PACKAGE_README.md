# Public research package

This package is intended for a public GitHub repository and for Muse research. It contains the bot code, strategy, TODO list, tests, anonymized trade-only records, research data, and selected historical market tapes. It excludes original private account state and raw journals. Account-identifying and balance fields were removed from structured files; some unreviewed files and databases were omitted. The detailed `PUBLIC_SANITIZATION_REPORT.json` lists exclusions and modified paths. No automated scan can guarantee detection of every personal detail.

`state/HISTORICAL_TRADES.csv` contains 112 ledger rows as of the snapshot; rows from different accounts and copied control snapshots may represent the same trade. Do not sum them as independent trades. Historical data is limited to what was saved locally and passed the privacy checks; raw account-state files and some opaque formats are intentionally absent. Redacted files are not byte-identical to originals.

The package is intended for offline research and paper testing, and `CONFIG.md` has live execution disabled. Installing dependencies requires an appropriate Python environment and potentially network access. Live broker credentials are excluded. Backtest results are not a live performance guarantee.
