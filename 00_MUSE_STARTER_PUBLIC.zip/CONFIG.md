# CONFIG.md — User-Controlled Settings



Small-account policy approved by the user on 2026-08-23. Fully unattended one-contract live

execution was approved by the user on 2026-08-24 and activated after the final smoke tests.

On 2026-08-27 the user approved multiple one-contract positions and an approximately $50 minimum.

Later on 2026-08-27, the user explicitly removed the open-position count and aggregate premium

caps. Keep three new positions per day, one contract each, $50–$250 per position, and fresh broker

buying-power checks. There is no separate combined-premium ceiling; all cash may be deployed.

On 2026-08-29 the user paused live execution and approved a paper-trading simplification limited

to SPY and QQQ while a single explicit entry setup and a replacement for Unusual Whales are tested.

On 2026-09-02 the user raised the paper-experiment per-contract ceiling from $150 to $250 so the

SPY/QQQ selector can consider stronger contracts that were previously unaffordable under the gate.

On 2026-09-05 the user approved repairing the discovery/decision handoff, affordable expiration

selection, paper accounting/calendar defects, forward comparison, and prospective stop-risk sizing.

The $250 premium ceiling is now further limited by the remaining daily planned-loss budget.



## Execution

LIVE_EXECUTION_ENABLED: false
PAPER_TRADING_ENABLED: false
LIVE_NEW_ENTRIES_ENABLED: true
LIVE_UNATTENDED_AUTHORIZED: true
LIVE_ORDER_CONFIRMATION_MODE: STANDING_UNATTENDED_AUTHORIZATION

AUTOMATIC_ORDER_CANCELLATION_ENABLED: false

STOP_MANAGEMENT_MODE: SOFTWARE_POLLING

PAPER_STARTING_CASH: 369

PAPER_FILL_POLICY: BUY_AT_ASK_SELL_AT_BID

PAPER_ASSUME_TP_TRADE_THROUGH: true

# October 9, 2026: active paper options strategy; live execution stays locked off.
# The same deterministic route and guards are implemented for offline live tests.
# Python's qualified direction and
# JEV's rank-selected contract proceed without a Luna/Codex veto. The primary
# ledger stops opening new positions after realized P&L first becomes positive.
OPTIONS_LUNA_VETO_ENABLED: false
PAPER_PRIMARY_DAILY_GREEN_LOCK_ENABLED: true
OPTIONS_DAILY_GREEN_LOCK_ENABLED: true
OPTIONS_STRATEGY_EPOCH: python_jev_green_lock_20261009

# Historical comparators are retained on disk but disabled so they cannot create
# duplicate paper positions while the deterministic primary is evaluated forward.
PAPER_BASELINE_ENABLED: false
PAPER_DAILY_GREEN_LOCK_ENABLED: false

# Net target profit / net stopped-out loss, after the shared modeled execution costs.
MIN_NET_REWARD_TO_RISK: 1.00

# One-session primary paper-options continuation trial, authorized September 23.
# Only new DAY entries on this Eastern date enroll; control ledger stays fixed-target.
PAPER_WINNER_TRIAL_DATE: 2026-09-24
PAPER_WINNER_TRAIL_GIVEBACK_PERCENT: 10
PAPER_WINNER_MIN_PROFIT_PERCENT: 10

PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS: 0.05

PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS: 1.00



## Account / portfolio risk

MAX_DAILY_LOSS_DOLLARS: 45

MAX_DAILY_LOSS_PERCENT: 12.5

ENTRY_EXIT_COST_BUFFER_DOLLARS: 2.10

MAX_OPEN_POSITIONS: UNLIMITED

MAX_CONTRACTS_PER_POSITION: 1

MAX_NEW_POSITIONS_PER_DAY: 3

MAX_PORTFOLIO_PREMIUM_AT_RISK: UNLIMITED

MIN_SINGLE_POSITION_PREMIUM_AT_RISK: 50

MAX_SINGLE_POSITION_PREMIUM_AT_RISK: 250

MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT: 100

NO_AVERAGING_DOWN: true



## Options

ALLOW_LONG_CALLS: true

ALLOW_LONG_PUTS: true

ALLOW_0DTE: false

MIN_DTE: 2

MIN_DAY_TRADE_DTE: 2

MIN_SWING_DTE: 7

MAX_DTE: 45

MAX_BID_ASK_SPREAD_PERCENT: 10

MIN_OPTION_VOLUME: 100

MIN_OPTION_OPEN_INTEREST: 500

MIN_UNDERLYING_LIQUIDITY: 50000000

GREEKS_REQUIRED: true

DAY_MIN_ABS_DELTA: 0.20

DAY_MAX_ABS_DELTA: 0.80

DAY_MAX_THETA_PERCENT_OF_PREMIUM: 65

DAY_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE: 0.35

SWING_MIN_ABS_DELTA: 0.25

SWING_MAX_ABS_DELTA: 0.75

SWING_MAX_THETA_PERCENT_OF_PREMIUM: 12

SWING_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE: 0.25



## Position management

STOP_LOSS_PERCENT: 25

TAKE_PROFIT_PERCENT: 30

TRAILING_EXIT_ENABLED: false

TRAILING_ACTIVATION_PERCENT: 25

TRAILING_GIVEBACK_PERCENT: 15

DAY_TRADE_EXIT_MINUTES_BEFORE_CLOSE: 15

REQUIRE_PROTECTIVE_STOP: true



## Earnings / events

EARNINGS_HOLD_ALLOWED: false

EARNINGS_RISK_MULTIPLIER: 0.5

REQUIRE_EXPLICIT_EARNINGS_HOLD_DECISION: true



## Compute / cost

DEEP_REASONING_ONLY_AFTER_GATE: true

SUBAGENTS_ON_ZERO_CANDIDATE_RUNS: false

MAX_SUBAGENTS_NORMAL_ESCALATION: 3

MAX_SUBAGENTS_HIGH_STAKES: 5



## Unusual Whales

UW_ENABLED: false

UW_TRIAL_MODE: false

UW_CURRENT_MONTHLY_COST: 0



## Universe

TRADE_US_EQUITY_OPTIONS: false

TRADE_ETF_OPTIONS: true

TRADE_STOCKS_DIRECTLY: false

WATCHLIST_ONLY: true

WATCHLIST_SYMBOLS: SPY,QQQ



## Automation

AUTOMATION_CADENCE: 5 minutes maximum

MARKET_HOURS_ONLY_FOR_NEW_ENTRIES: true

MINUTES_AFTER_OPEN_BEFORE_NEW_ENTRY: 20

MINUTES_BEFORE_CLOSE_NO_NEW_ENTRY: 10

DAY_TRADE_ENTRY_CUTOFF_MINUTES_BEFORE_CLOSE: 30

SWING_ENTRY_CUTOFF_MINUTES_BEFORE_CLOSE: 10

OPEN_POSITION_POLL_SECONDS: 120

# October 9: paper-only resident monitor; OPEN_POSITION_POLL_SECONDS retains live's old cadence.
PAPER_FAST_MONITOR_ENABLED: true
PAPER_OPEN_POSITION_POLL_SECONDS: 10
PAPER_POSITION_QUOTE_MAX_AGE_SECONDS: 20

# Live-position monitor prepared October 9; LIVE_EXECUTION_ENABLED .
# These flags do not start a process or authorize orders. Entries require its fresh
# executing heartbeat after a separately approved activation.
LIVE_FAST_MONITOR_ENABLED: true
LIVE_OPEN_POSITION_POLL_SECONDS: 10
LIVE_POSITION_QUOTE_MAX_AGE_SECONDS: 20
LIVE_MONITOR_REQUEST_TIMEOUT_SECONDS: 8

NEWS_POLL_SECONDS: 600

NEW_OPPORTUNITY_SCAN_MINUTES: 5

# Opportunity task fires 15 seconds after five-minute boundaries (approved 2026-09-16).

# This is a data-arrival allowance, not a guarantee of provider candle freshness.

BROAD_NEWS_ENABLED: true

AGENT_REACH_SOCIAL_ENABLED: false

NEWS_TRIAGE_MODEL: gpt-5.6-luna

NEWS_TRIAGE_REASONING_EFFORT: low

FINAL_DECISION_MODEL: gpt-5.6-luna

FINAL_DECISION_REASONING_EFFORT: high

MAX_MODEL_CALLS_PER_DAY: 20



The shared Luna allowance resets at 09:30 America/New_York every calendar day, including

weekends, using the local DST-aware clock. Overnight crypto uses the remaining calls until

09:30; there is no extra midnight or market-close reset. Paper profit/loss days remain separate.



## JEV research integration (2026-09-20)



ENABLE_JEV: true

JEV_SHADOW_MODE: false

ENABLE_JEV_ESCALATION: true

ENABLE_LEVEL2: true

ENABLE_ORDERFLOW_FEATURES: true

ENABLE_ORDERFLOW_JEV: true

ENABLE_MULTI_WATCH: false

ENABLE_DYNAMIC_LUNA_ESCALATION: false

JEV_MAX_CALLS_PER_MINUTE: 6

JEV_MAX_CALLS_PER_DAY: 1000

JEV_TIMEOUT_SECONDS: 12

JEV_MAX_RETRIES: 2

JEV_BACKOFF_SECONDS: 0.5

CRYPTO_JEV_OVERNIGHT_TEST: false

CRYPTO_JEV_ABOVE_AVERAGE: true

OPTIONS_JEV_BLIND_TEST: false

OPTIONS_JEV_RANKING_ONLY: true



Options ranking authorized September 21: for SPY/QQQ paper options, JEV ranks up to

three fully Python-qualified eligible candidates per scan and selects at most one for

Luna. The first READY watch takes priority; otherwise rank by setup quality, entry timing, then

escalation score. These are relative model judgments, not profit probabilities.

There is no JEV score threshold or false-breakout veto in this options mode. If JEV

is unavailable for any candidate in the selection pool, use deterministic Python order. A sole eligible candidate

can proceed regardless of JEV scores. Luna receives no JEV scores or verdict.

Python qualification, watch readiness, cache/held-ticker checks, the shared 20-call

budget, and all final paper-fill gates remain binding. Luna may BUY, PASS, or WATCH.

This supersedes the expired September 21 options sampling trial and the proposed

September 22 comparison. Crypto routing and live execution policy are unchanged.



Historical comparison (superseded by above-average routing on September 22):

06:30–09:30 Eastern September 21 permits two blind reviews, at most one per coin.

September 21 16:00 through September 22 09:30 permits four more, one in each window:

16:00–20:00, 20:00–00:00, 00:00–04:00, 04:00–09:30; at most two per coin overnight.

Unused slots do not accumulate. This is one bounded repeat, not an ongoing daily experiment.

Only ETH/BTC paper uses the revised final-review question within these dated windows.

Sampled soft-score rejections still require valid active JEV, its false-breakout ceiling,

all Python gates, the existing cooldown, and available shared 20-call budget. Luna receives

no JEV scores, veto, thresholds, or sampling labels during the comparison, including normal

JEV passes. Python logs those separately for analysis. Reservations persist before launch;

model failures consume their sample. Every fill rechecks risk; existing notifications apply.

The comparison and revised question expire September 22 at 09:30 Eastern automatically.



On 2026-09-20 the user approved JEV filtering and WATCH for paper trading. For crypto, active JEV must pass

before a paper candidate reaches Luna, except for the dated comparison above;

missing JEV fails closed. Options use the ranking-only override above. Python risk gates remain binding.

These switches do not authorize active JEV filtering or WATCH for live orders. Research continues

after the shared 20-call Luna ceiling. Existing option opportunity cadence remains five minutes.



## ETH/BTC spot paper experiment — user requested 2026-09-20



CRYPTO_PAPER_ENABLED: true

CRYPTO_SYMBOL: ETH-USD

CRYPTO_SYMBOLS: ETH-USD,BTC-USD

CRYPTO_DATA_VENUE: MULTISOURCE_PAPER

CRYPTO_PAPER_STARTING_CASH: 369

CRYPTO_MAX_POSITION_DOLLARS: 50

CRYPTO_STOP_LOSS_PERCENT: 2.5

CRYPTO_TAKE_PROFIT_PERCENT: 5

CRYPTO_MAX_DAILY_LOSS_DOLLARS: 5

CRYPTO_MAX_ENTRIES_PER_DAY: 3

CRYPTO_MAX_HOLD_MINUTES: 240

CRYPTO_MAX_SPREAD_PERCENT: 0.2

CRYPTO_PAPER_FEE_PERCENT_SIDE: 0.25

CRYPTO_PAPER_SLIPPAGE_BPS_SIDE: 5

CRYPTO_STOP_AFTER_NET_GREEN: true



BTC-USD was added at the user's request. ETH and BTC share ONE $369 crypto paper ledger,

one open position, one active watch, three total entries/day, the $5 daily loss budget,

and the global 20-call Luna allowance. The 30-minute model cooldown is shared across crypto;

completed-bar research deduplication is per symbol. A held position/watch takes priority;

otherwise first-scanned coin alternates between five-minute runs. Desktop and existing phone

alerts report committed paper entries/exits for both coins; quiet scans do not notify.



ETH and BTC are long-only spot, preferring Robinhood v2 quotes in a separate $369 paper ledger;

it is not Robinhood cash or a Robinhood fill. One position at a time, no averaging down,

shorting, leverage, or futures. The approved $50 notional, 2.5% stop, 5% target, $5 daily planned

loss cap, 0.25% per-side fee and 5 bps slippage are conservative experiment parameters, not

verified Robinhood fees or an established profitable strategy. Stop thresholds cannot guarantee

fill prices. New ETH entries occur only outside the NYSE regular session, with calendar-aware

deadlines. Crypto uses the remaining shared calls outside regular equity hours; the new 20-call

window begins at 09:30 Eastern daily. Independent Python monitoring

runs once per minute while Windows is awake, logged in, and connected, regardless of model budget.

ETH opportunities run every five minutes, with a 30-minute model cooldown unless a WATCH wakes.

The one ETH watch expires within 60 minutes and is monitored by Python. Options retain up to three.

Crypto's net-green stop affects only its own paper session. Paper ledgers are independent research

accounts and must not be added together or treated as shared live buying power.



On 2026-09-20 the user subsequently restored external research data and explicitly approved

Coinbase paper-price fallback when Robinhood is invalid/unavailable. Research uses Coinbase

completed ETH/USD candles/depth, then public Binance.US ETHUSD as backup. Pricing prefers

Robinhood, then Coinbase, then Binance.US; each source is labeled. Open positions and watches

stay pinned to their pricing venue. No Coinbase/Binance account credentials or orders are used.

External depth is never represented as Robinhood depth. Robinhood paper quotes require a fresh

fee estimate; the greater of its fee ratio and the configured research fee floor is charged.

Public-venue fees remain assumptions, not a forecast of Robinhood profitability. These are

top-of-book simulations with slippage, not size-adjusted executable fill guarantees.

Crypto is idle during NYSE regular hours while flat, including no data/JEV/Luna requests.

An existing position continues receiving exit monitoring through the opening boundary.



## Operating notes

Held tickers are excluded from new-opportunity model calls and new entries across their entire

options chain. Position monitoring and necessary exit/event reviews remain active.

Only `MAX_OPEN_POSITIONS` and `MAX_PORTFOLIO_PREMIUM_AT_RISK` accept explicit `UNLIMITED`.

Missing, zero, or invalid values still fail closed. The 100% single-position percentage ceiling

removes the old 41% restriction; the $250 dollar cap and available buying power still apply.

Unattended execution means automated Robinhood review before every entry/exit, no per-order human

prompt, no automatic cancellations/repricing, and deterministic two-minute software stop/target/time

management. The current 25% stop and 30% profit target remain unchanged.

Current mode is paper only. Python resolves only SPY and QQQ contracts, applies the existing hard

liquidity/Greek/risk/timing gates, supplies one compact candidate to Luna/high, and simulates an

ask fill only after Luna returns BUY. Unusual Whales is disabled; no substitute flow signal is

invented. Existing news/social inputs remain Python-compressed rather than exposing raw posts.



The planned-loss ceiling is the smaller of $45 and 12.5% of start-of-day equity. Deduct today's

equity loss and the additional loss to stops on open positions, including exit costs. New premium

times 25% plus ENTRY_EXIT_COST_BUFFER_DOLLARS must fit the remainder. Daily gains do not increase

this allowance. Cash must also cover premium plus estimated entry costs. At $369, flat and without

daily losses, the effective premium ceiling is $171.60 before option tick rounding.



Paper entries remain priced at ask and exits at bid. Separately charge estimated costs of $0.05

fees plus $1 slippage per contract per side. These are modeling assumptions, not broker fee quotes.

Their $2.10 round-trip reserve is included in sizing. Software stops and cost buffers are not

guaranteed loss caps. The separate DAY control has its own $369 paper ledger and follows the same

hard gates and costs; its entries are never counted as the primary account's trades.



## Scheduled macro-event protection (2026-09-16)



ECONOMIC_CALENDAR_ENABLED: true

FOMC_BLACKOUT_MINUTES_BEFORE: 30

FOMC_BLACKOUT_MINUTES_AFTER: 60

MACRO_BLACKOUT_MINUTES_BEFORE: 15

MACRO_BLACKOUT_MINUTES_AFTER: 30



New entries pause 13:30–15:00 ET on scheduled FOMC decision days, covering the

14:00 decision and 14:30 press conference. Other covered releases pause entries

15 minutes before through 30 minutes after. Position exits remain active.



## Crypto relative JEV gate -- authorized September 22, 2026



For ETH/BTC paper, replace the fixed setup/escalation/false-breakout JEV thresholds

with setup_quality strictly above the arithmetic mean of prior successful,

Python-qualified evaluations for the same coin, JEV model and exact question-version

set. Exclude the current evaluation and evidence unavailable at the comparison time.

No extra margin. Persist score, prior mean, sample count and admission reason.

Retain crypto-review-trial-v1 questions beyond the expired comparison so scores stay

comparable. With zero matching history, allow one valid evaluation to reach Luna

as bootstrap; later evaluations use the growing prior average. Invalid/unavailable

JEV or unreadable history still blocks. No minimum-history threshold is invented.

Luna receives no JEV score/verdict. The old dated sampling exception is disabled.

All Python gates, source/freshness checks, 30-minute cooldown, WATCH behavior, shared

20-call budget, and final paper risk checks remain. Options ranking is unchanged.

This rule supersedes the earlier crypto JEV admission and dated trial text above.



## Options intraday-only simplification — authorized September 22, 2026
DAY_ONLY_OPTIONS: true

All new SPY/QQQ option trades and watches must use DAY style. Swing
selection and entries are disabled. Day direction uses 5-minute/15-minute technical
structure; daily/4-hour trends remain context, without the separate countertrend
confirmation veto. Opposing intraday direction still fails Python qualification.
Nearest permitted expirations are searched without reserving a swing expiry slot;
DAY DTE/Greek/liquidity/risk settings stay binding (no 0DTE). New entries stop30minutes
before the NYSE close; positions exit15minutes before close using the existing
calendar-aware software monitor. For a normal session these are15:30 and15:45ET.
JEV options ranking, Luna review, stops/targets, daily loss limits and model budget
remain unchanged. Crypto keeps its separate outside-stock-hours spot paper policy.
Legacy SWING values above are inactive for new options trades; live remains disabled.
This section supersedes earlier mixed DAY/SWING options policy.
