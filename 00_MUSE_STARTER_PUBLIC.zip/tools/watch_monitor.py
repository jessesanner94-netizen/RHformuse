"""Refresh all bounded WATCH contracts without asking a model to monitor them."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from pathlib import Path

from tools.cheap_scan import scan_candidates
from tools.live_trading import _underlying_trade
from tools.news_option_discovery import build_news_candidates
from tools.robinhood_mcp import fetch_contract_research
from tools.watch_state import (
    MAX_FUTURE_SKEW,
    MAX_OBSERVATION_AGE,
    active_watches,
    invalidate_watch,
)


async def refresh_watches(
    config, *, project_root: Path, now: datetime | None = None, fetcher=None
) -> dict:
    current = now or datetime.now(UTC)
    path = project_root / "state/research/watches.sqlite3"
    try:
        watches = active_watches(path, now=current)
        identities = [row["identity"] for row in watches if row["status"] == "ACTIVE"]
        if not identities:
            return {"status": "QUIET", "qualified_candidates": []}
        requests = [
            {
                "chain_symbol": item["symbol"],
                "expiration_dates": item["expiration"],
                "strike_price": item["strike"],
                "type": item["option_type"].lower(),
            }
            for item in identities
        ]
        raw = await asyncio.wait_for((fetcher or fetch_contract_research)(requests), timeout=25)
        # A real fetch can return a venue trade newer than the cycle-start timestamp.
        # Resample wall time for standalone callers and allow the same bounded skew as
        # the persistent state machine when a deterministic cycle timestamp is supplied.
        if now is None:
            current = datetime.now(UTC)
        equity = {}
        for quote in raw.get("equity_quotes", []):
            body = quote.get("quote", quote)
            price, at = _underlying_trade(body)
            if at is not None:
                parsed = datetime.fromisoformat(at.replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    continue
                age = (current - parsed.astimezone(UTC)).total_seconds()
                if (
                    -MAX_FUTURE_SKEW.total_seconds()
                    <= age
                    <= MAX_OBSERVATION_AGE.total_seconds()
                ):
                    equity[str(body.get("symbol", "")).upper()] = (price, at)
                    body["last_trade_price"] = str(price)
                    body["venue_last_trade_time"] = at
        candidates = build_news_candidates(
            raw, now=current, config=config, discovery_source="LUNA_WATCH"
        )
        gate = scan_candidates(candidates, config)
        qualified = {item["candidate_id"] for item in gate["qualified"]}
        known = {item["candidate_id"]: item for item in candidates}
        accepted = []
        watch_results = []
        for row in watches:
            identity = row["identity"]
            candidate_id = identity["candidate_id"]
            if row["status"] != "ACTIVE":
                continue
            if candidate_id not in known:
                watch_results.append(
                    {
                        "watch_id": row["watch_id"],
                        "candidate_id": candidate_id,
                        "status": "UNAVAILABLE",
                        "reason": "exact_contract_or_quote_unavailable",
                    }
                )
                continue
            if candidate_id not in qualified:
                outcome = invalidate_watch(
                    path, watch_id=row["watch_id"], reason="fresh_contract_gate_failed", now=current
                )
                watch_results.append(
                    {
                        "watch_id": row["watch_id"],
                        "candidate_id": candidate_id,
                        "status": outcome["status"],
                        "reason": "fresh_contract_gate_failed",
                    }
                )
                continue
            candidate = known[candidate_id]
            if identity["symbol"] not in equity:
                watch_results.append(
                    {
                        "watch_id": row["watch_id"],
                        "candidate_id": candidate_id,
                        "status": "UNAVAILABLE",
                        "reason": "fresh_underlying_quote_unavailable",
                    }
                )
                continue
            price, at = equity[identity["symbol"]]
            candidate = {**candidate, "underlying_price": price, "underlying_quote_updated_at": at}
            identity_matches = all(
                str(candidate.get(key, "")).upper() == str(identity[key]).upper()
                for key in ("symbol", "option_type", "expiration")
            ) and float(candidate.get("strike", 0)) == float(identity["strike"])
            if not identity_matches:
                outcome = invalidate_watch(
                    path,
                    watch_id=row["watch_id"],
                    reason="refreshed_contract_identity_mismatch",
                    now=current,
                )
                watch_results.append(
                    {
                        "watch_id": row["watch_id"],
                        "candidate_id": candidate_id,
                        "status": outcome["status"],
                        "reason": "refreshed_contract_identity_mismatch",
                    }
                )
                continue
            if identity["trade_style"] not in candidate.get("eligible_trade_styles", []):
                outcome = invalidate_watch(
                    path,
                    watch_id=row["watch_id"],
                    reason="watch_style_no_longer_eligible",
                    now=current,
                )
                watch_results.append(
                    {
                        "watch_id": row["watch_id"],
                        "candidate_id": candidate_id,
                        "status": outcome["status"],
                        "reason": "watch_style_no_longer_eligible",
                    }
                )
                continue
            accepted.append(
                {**candidate, "watch_trade_style": identity["trade_style"], "watch_priority": True}
            )
            watch_results.append(
                {
                    "watch_id": row["watch_id"],
                    "candidate_id": candidate_id,
                    "status": "ROUTE_READY",
                }
            )
        return {
            "status": "OK",
            "qualified_candidates": accepted,
            "watch_results": watch_results,
        }
    except TimeoutError:
        return {
            "status": "UNAVAILABLE",
            "reason": "contract_refresh_timeout",
            "qualified_candidates": [],
            "watch_results": [],
        }
    except Exception:
        return {
            "status": "UNAVAILABLE",
            "reason": "contract_refresh_failed",
            "qualified_candidates": [],
            "watch_results": [],
        }
