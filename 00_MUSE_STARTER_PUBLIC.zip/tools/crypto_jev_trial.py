"""One-night, paper-only JEV routing comparison; no independent model budget."""

import json

from tools.crypto_paper import stamp
from tools.jev_features import number

TRIAL_ID = "crypto-jev-blind-2026-09-21"
START = stamp("2026-09-21T06:30:00-04:00")
END = stamp("2026-09-22T09:30:00-04:00")
SLOTS = (
    (START, stamp("2026-09-21T09:30:00-04:00"), "morning", 2),
    (stamp("2026-09-21T16:00:00-04:00"), stamp("2026-09-21T20:00:00-04:00"), "early", 1),
    (stamp("2026-09-21T20:00:00-04:00"), stamp("2026-09-22T00:00:00-04:00"), "late", 1),
    (stamp("2026-09-22T00:00:00-04:00"), stamp("2026-09-22T04:00:00-04:00"), "overnight", 1),
    (stamp("2026-09-22T04:00:00-04:00"), END, "preopen", 1),
)


def slot(now):
    return next((name for start, end, name, _ in SLOTS if start <= stamp(now) < end), None)


def active(config, now):
    return (
        config.get("CRYPTO_JEV_OVERNIGHT_TEST") is True
        and config.get("PAPER_TRADING_ENABLED") is True
        and config.get("LIVE_EXECUTION_ENABLED") is False
        and slot(now) is not None
    )


def sample_allowed(config, now, jev, store):
    """Called under the existing crypto opportunity lock; missing evidence fails closed."""
    if not active(config, now) or store.symbol not in {"ETH-USD", "BTC-USD"}:
        return False
    policy = jev.get("policy") or {}
    scores = jev.get("scores") or {}
    values = [
        number(scores.get(k)) for k in ("setup_quality", "escalate_to_luna", "false_breakout_risk")
    ]
    maximum = number(policy.get("thresholds", {}).get("JEV_MAX_FALSE_BREAKOUT"))
    if (
        jev.get("status") != "OK"
        or jev.get("routing_effect") is not True
        or policy.get("would_escalate") is not False
        or any(v is None or not 0 <= v <= 1 for v in values)
        or maximum is None
        or not 0 <= maximum <= 1
        or values[2] > maximum
    ):
        return False
    with store.connect() as db:
        rows = db.execute("SELECT body FROM events WHERE kind='jev_trial_reserved'").fetchall()
    used = [json.loads(row[0]) for row in rows]
    used = [row for row in used if row.get("trial_id") == TRIAL_ID]
    current_slot = slot(now)
    quota = next(cap for _, _, name, cap in SLOTS if name == current_slot)
    in_slot = [row for row in used if row.get("slot") == current_slot]
    session = [row for row in used if (row.get("slot") == "morning") == (current_slot == "morning")]
    per_coin = 1 if current_slot == "morning" else 2
    return (
        len(used) < 6
        and len(in_slot) < quota
        and sum(row.get("symbol") == store.symbol for row in session) < per_coin
    )
