"""Paper-only held-position monitor. No discovery, model calls or real order adapter."""

from __future__ import annotations

import argparse
import asyncio
import json
import time
from collections.abc import Awaitable, Callable, Mapping
from contextlib import suppress
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

from tools.config import ConfigError, TradingConfig, load_config
from tools.market_calendar import market_window
from tools.options_strategy import identify_state, ledger_directory
from tools.paper_runner import _persisted_continuation_evidence
from tools.paper_trading import load_paper_portfolio, manage_paper_positions
from tools.robinhood_mcp import fetch_paper_monitor_quotes, fetch_quote_refresh
from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock
from tools.state_manager import guarded_json_update
from tools.windows_notify import send_notification


def settings(config: TradingConfig) -> tuple[int, int]:
    values = [
        config.get("PAPER_OPEN_POSITION_POLL_SECONDS", 10),
        config.get("PAPER_POSITION_QUOTE_MAX_AGE_SECONDS", 20),
    ]
    if any(isinstance(v, bool) or not isinstance(v, int) or not 1 <= v <= 120 for v in values):
        raise ConfigError("invalid fast paper monitor interval/quote freshness setting")
    return values[0], values[1]


def retry_delay(exc: BaseException, now: datetime) -> float:
    """Honor a broker 429 Retry-After without hammering the API or retrying orders."""
    if isinstance(exc, BaseExceptionGroup):
        return max((retry_delay(e, now) for e in exc.exceptions), default=0)
    response = getattr(exc, "response", None)
    if getattr(response, "status_code", None) != 429:
        return 0
    raw = response.headers.get("Retry-After", "30")
    try:
        return max(30, float(raw))
    except ValueError:
        with suppress(TypeError, ValueError, OverflowError):
            return max(30, (parsedate_to_datetime(raw) - now).total_seconds())
    return 30


class PaperMonitor:
    def __init__(
        self,
        root: Path,
        *,
        quote_fetcher: Callable[..., Awaitable[dict[str, Any]]] = fetch_paper_monitor_quotes,
        history_fetcher: Callable[..., Awaitable[dict[str, Any]]] = fetch_quote_refresh,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
        monotonic: Callable[[], float] = time.monotonic,
    ):
        self.root, self.quotes, self.history = root, quote_fetcher, history_fetcher
        self.clock, self.monotonic = clock, monotonic
        self.history_task: asyncio.Task | None = None
        self.history_key: tuple | None = None
        self.history_cache: dict[str, Any] = {}
        self.retry_at = 0.0

    async def close(self):
        if self.history_task is not None:
            self.history_task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self.history_task
            self.history_task = None

    async def poll(self, config: TradingConfig) -> dict[str, Any]:
        # This fence is checked every iteration, including after a future config change.
        if (
            config.live_execution_enabled
            or not config.paper_trading_enabled
            or config.get("PAPER_FAST_MONITOR_ENABLED") is not True
        ):
            await self.close()
            return {"status": "BLOCKED", "reason": "fast_monitor_paper_only"}
        blockers = config.paper_blockers()
        if blockers:
            return {"status": "BLOCKED", "reasons": blockers}
        interval, max_age = settings(config)
        directory = ledger_directory(self.root, config, "paper")
        path = directory / "PORTFOLIO.json"
        now = self.clock()
        # Read-only while flat: no initialization, broker snapshot or ledger rewrite.
        state = load_paper_portfolio(
            path, starting_cash=float(config.get("PAPER_STARTING_CASH")), now=now
        )
        identify_state(state, config)
        positions = state["open_positions"]
        if not positions:
            await self.close()
            self.history_cache, self.history_key = {}, None
            return {"status": "QUIET", "open_positions": [], "paper_events": []}
        if self.monotonic() < self.retry_at:
            return {
                "status": "ATTENTION",
                "attention": [{"code": "PAPER_QUOTE_RATE_LIMIT"}],
                "open_positions": positions,
                "retry_in_seconds": round(self.retry_at - self.monotonic(), 2),
            }
        requests = [{"option_id": str(p["contract_identifier"])} for p in positions]
        # No automatic read retry: a failed quote gets another bounded attempt next tick.
        try:
            refresh = await asyncio.wait_for(self.quotes(requests), timeout=min(8, interval))
        except Exception as exc:
            delay = retry_delay(exc, self.clock())
            self.retry_at = self.monotonic() + delay
            return {
                "status": "ATTENTION",
                "open_positions": positions,
                "attention": [
                    {
                        "code": "PAPER_QUOTE_RATE_LIMIT" if delay else "PAPER_QUOTE_FETCH_FAILED",
                        "error_type": type(exc).__name__,
                    }
                ],
                "retry_in_seconds": delay,
            }
        now = self.clock()  # Freshness is measured after the network request completes.
        if not isinstance(refresh, Mapping) or refresh.get("status") != "OK":
            return {
                "status": "ATTENTION",
                "open_positions": positions,
                "attention": [{"code": "PAPER_QUOTE_FETCH_FAILED"}],
            }
        safe_quotes = []
        stale_contracts = set()
        for row in refresh.get("option_quotes", []):
            if not isinstance(row, Mapping):
                continue
            quote = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
            try:
                stamp = datetime.fromisoformat(
                    str(quote.get("updated_at", "")).replace("Z", "+00:00")
                )
                age = (now - stamp).total_seconds()
            except (TypeError, ValueError):
                stale_contracts.add(quote.get("instrument_id"))
                continue
            if -2 <= age <= max_age:
                safe_quotes.append(row)
            else:
                stale_contracts.add(quote.get("instrument_id"))
        refresh = {**refresh, "option_quotes": safe_quotes}
        if self.history_task is not None and self.history_task.done():
            try:
                history = self.history_task.result()
                cached = history.get("tp_history", {})
                self.history_cache = cached if isinstance(cached, dict) else {}
            except Exception as exc:
                self.retry_at = max(self.retry_at, self.monotonic() + retry_delay(exc, now))
                self.history_cache = {}
            self.history_task = None
        # Existing atomic ledger lock also protects against the ordinary opportunity monitor.
        result = manage_paper_positions(
            {
                **refresh,
                "tp_history": self.history_cache,
                "continuation_evidence": _persisted_continuation_evidence(positions),
            },
            config,
            portfolio_path=path,
            event_log_path=directory / "EVENTS.jsonl",
            now=now,
            maximum_quote_age_seconds=max_age,
        )
        remaining = result["open_positions"]
        stale_ids = {
            p["paper_id"] for p in positions if p["contract_identifier"] in stale_contracts
        }
        for attention in result.get("attention", []):
            if attention.get("paper_id") in stale_ids:
                attention["code"] = "PAPER_QUOTE_STALE"
        if not remaining:
            await self.close()
        elif config.get("PAPER_ASSUME_TP_TRADE_THROUGH") is True:
            # Historical TP evidence is collected once per completed minute in the background.
            # It can never delay a fresh-bid stop check; unchanged paper TP rules consume it.
            key = (
                str(directory),
                tuple(sorted(p["contract_identifier"] for p in remaining)),
                now.replace(second=0, microsecond=0),
            )
            if self.history_task is None and key != self.history_key:
                self.history_key = key
                history_requests = [
                    {"option_id": p["contract_identifier"], "tp_history_start": p["entry_at"]}
                    for p in remaining
                ]
                self.history_task = asyncio.create_task(
                    asyncio.wait_for(self.history(history_requests), timeout=8)
                )
        result["quote_snapshot_as_of"] = refresh.get("as_of")
        return result


def publish(
    root: Path,
    result: Mapping[str, Any],
    *,
    started: datetime,
    duration: float,
    interval: int,
    previous: datetime | None,
) -> dict[str, Any]:
    record = {
        "timestamp": datetime.now(UTC).isoformat(),
        "poll_started_at": started.isoformat(),
        "mode": "PAPER",
        "status": result.get("status"),
        "reason": result.get("reason"),
        "target_interval_seconds": interval,
        "duration_seconds": round(duration, 3),
        "observed_interval_seconds": round((started - previous).total_seconds(), 3)
        if previous
        else None,
        "open_position_count": len(result["open_positions"])
        if isinstance(result.get("open_positions"), list)
        else None,
        "quote_snapshot_as_of": result.get("quote_snapshot_as_of"),
        "attention": result.get("attention", []),
        "paper_events": result.get("paper_events", []),
        "retry_in_seconds": result.get("retry_in_seconds", 0),
        "models_invoked": 0,
        "orders_placed": 0,
        "orders_cancelled": 0,
    }
    guarded_json_update(root / "state/runtime/paper_fast_monitor.json", record, commit=True)
    if record["paper_events"] or record["attention"] or record["status"] == "BLOCKED":
        log = root / "state/runtime/paper_fast_monitor" / f"{started.date()}.jsonl"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, separators=(",", ":")) + "\n")
    return record


async def run(
    root: Path,
    *,
    once: bool = False,
    notifications: bool = False,
    monitor: PaperMonitor | None = None,
) -> dict[str, Any]:
    monitor = monitor or PaperMonitor(root)
    previous = None
    notification_jobs: set[asyncio.Task] = set()
    try:
        while True:
            started, tick = monitor.clock(), monitor.monotonic()
            interval = 10
            try:
                config = load_config(root / "CONFIG.md")
                interval, _ = settings(config)
                if not market_window(started)[0]:
                    return {"status": "SKIPPED", "reason": "outside_regular_session"}
                result = await monitor.poll(config)
            except Exception as exc:
                result = {
                    "status": "ATTENTION",
                    "attention": [
                        {"code": "PAPER_FAST_MONITOR_ERROR", "error_type": type(exc).__name__}
                    ],
                }
            record = publish(
                root,
                result,
                started=started,
                duration=monitor.monotonic() - tick,
                interval=interval,
                previous=previous,
            )
            # Notification delivery may take longer than a tick; keep it off the quote path.
            if (
                notifications
                and (result.get("paper_events") or result.get("attention"))
                and (result.get("paper_events") or not notification_jobs)
            ):
                job = asyncio.create_task(
                    asyncio.to_thread(
                        send_notification,
                        {"cycle": "positions", "paper": result},
                        project_root=root,
                        execute=True,
                    )
                )
                notification_jobs.add(job)
                job.add_done_callback(notification_jobs.discard)
            if once or result.get("status") == "BLOCKED":
                return record
            previous = started
            # Never overlap or catch up missed ticks. Slow calls are recorded, not hidden.
            await asyncio.sleep(max(0.1, interval - (monitor.monotonic() - tick)))
    finally:
        await monitor.close()
        if notification_jobs:
            await asyncio.gather(*notification_jobs, return_exceptions=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--notifications", action="store_true")
    args = parser.parse_args()
    root = args.project_root.resolve()
    try:
        with advisory_file_lock(root / "state/runtime/paper_fast_monitor.owner", timeout_seconds=0):
            result = asyncio.run(run(root, once=args.once, notifications=args.notifications))
    except RuntimeLockUnavailable:
        result = {"status": "SKIPPED", "reason": "paper_monitor_already_running"}
    print(json.dumps(result))
    return 1 if result.get("status") in {"ATTENTION", "BLOCKED"} else 0


if __name__ == "__main__":
    raise SystemExit(main())
