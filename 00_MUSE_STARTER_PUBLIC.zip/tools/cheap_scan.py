"""Configuration-driven first-stage option candidate gate.

This module intentionally does not assign discretionary signal weights. The repository policy says
those thresholds must be tested and approved, so an upstream deterministic research signal must
explicitly say that the setup passed before this gate checks freshness and tradability.
"""

from __future__ import annotations

import argparse
import json
import math
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tools.config import SCANNER_REQUIRED_FIELDS, TradingConfig, load_config
from tools.option_style import assess_option_styles

REQUIRED_CANDIDATE_FIELDS = (
    "candidate_id",
    "symbol",
    "option_type",
    "dte",
    "underlying_price",
    "bid",
    "ask",
    "option_volume",
    "option_open_interest",
    "underlying_avg_daily_dollar_volume",
    "quote_is_fresh",
    "setup_qualified",
    "implied_volatility",
    "delta",
    "gamma",
    "theta",
    "vega",
)

NUMERIC_CANDIDATE_FIELDS = (
    "dte",
    "underlying_price",
    "bid",
    "ask",
    "option_volume",
    "option_open_interest",
    "underlying_avg_daily_dollar_volume",
    "implied_volatility",
    "delta",
    "gamma",
    "theta",
    "vega",
)


@dataclass(frozen=True)
class GateResult:
    candidate_id: str
    symbol: str
    status: str
    reasons: tuple[str, ...]
    metrics: Mapping[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "symbol": self.symbol,
            "status": self.status,
            "reasons": list(self.reasons),
            "metrics": dict(self.metrics),
        }


def _number(candidate: Mapping[str, Any], field: str) -> float | None:
    value = candidate.get(field)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    return value if math.isfinite(value) else None


def evaluate_candidate(candidate: Mapping[str, Any], config: TradingConfig) -> GateResult:
    candidate_id = str(candidate.get("candidate_id") or "UNKNOWN")
    symbol = str(candidate.get("symbol") or "UNKNOWN").upper()
    missing_config = config.missing(SCANNER_REQUIRED_FIELDS)
    if missing_config:
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            tuple(f"unresolved_config:{name}" for name in missing_config),
            {},
        )

    missing = [name for name in REQUIRED_CANDIDATE_FIELDS if candidate.get(name) is None]
    if missing:
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            tuple(f"missing_candidate_field:{name}" for name in sorted(missing)),
            {},
        )
    if (
        not str(candidate.get("candidate_id", "")).strip()
        or not str(candidate.get("symbol", "")).strip()
    ):
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            ("blank_candidate_identity",),
            {},
        )

    invalid_numeric = [
        name for name in NUMERIC_CANDIDATE_FIELDS if _number(candidate, name) is None
    ]
    if invalid_numeric:
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            tuple(f"invalid_numeric_field:{name}" for name in sorted(invalid_numeric)),
            {},
        )

    dte = _number(candidate, "dte")
    underlying_price = _number(candidate, "underlying_price")
    bid = _number(candidate, "bid")
    ask = _number(candidate, "ask")
    volume = _number(candidate, "option_volume")
    open_interest = _number(candidate, "option_open_interest")
    liquidity = _number(candidate, "underlying_avg_daily_dollar_volume")
    assert None not in (dte, underlying_price, bid, ask, volume, open_interest, liquidity)

    if bid < 0 or ask <= 0 or ask < bid or underlying_price <= 0:
        return GateResult(candidate_id, symbol, "INSUFFICIENT_DATA", ("invalid_market_quote",), {})

    midpoint = (bid + ask) / 2
    if midpoint <= 0:
        return GateResult(
            candidate_id, symbol, "INSUFFICIENT_DATA", ("invalid_option_midpoint",), {}
        )
    spread_percent = ((ask - bid) / midpoint) * 100

    boolean_config = ("ALLOW_LONG_CALLS", "ALLOW_LONG_PUTS", "ALLOW_0DTE")
    if any(not isinstance(config.get(field), bool) for field in boolean_config):
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            ("invalid_boolean_scanner_config",),
            {},
        )
    numeric_config = (
        "MIN_DTE",
        "MAX_DTE",
        "MAX_BID_ASK_SPREAD_PERCENT",
        "MIN_OPTION_VOLUME",
        "MIN_OPTION_OPEN_INTEREST",
        "MIN_UNDERLYING_LIQUIDITY",
    )
    if any(isinstance(config.get(field), bool) for field in numeric_config):
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            ("invalid_numeric_scanner_config",),
            {},
        )
    try:
        thresholds = {field: float(config.get(field)) for field in numeric_config}
    except (TypeError, ValueError):
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            ("invalid_numeric_scanner_config",),
            {},
        )
    if any(not math.isfinite(value) for value in thresholds.values()):
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            ("non_finite_scanner_config",),
            {},
        )
    if (
        thresholds["MIN_DTE"] < 0
        or thresholds["MAX_DTE"] < thresholds["MIN_DTE"]
        or thresholds["MAX_BID_ASK_SPREAD_PERCENT"] <= 0
        or any(
            thresholds[field] < 0
            for field in (
                "MIN_OPTION_VOLUME",
                "MIN_OPTION_OPEN_INTEREST",
                "MIN_UNDERLYING_LIQUIDITY",
            )
        )
    ):
        return GateResult(
            candidate_id,
            symbol,
            "INSUFFICIENT_DATA",
            ("invalid_scanner_config_range",),
            {},
        )

    reasons: list[str] = []
    option_type = str(candidate["option_type"]).upper()
    if option_type not in {"CALL", "PUT"}:
        reasons.append("unsupported_option_type")
    elif option_type == "CALL" and config.get("ALLOW_LONG_CALLS") is not True:
        reasons.append("long_calls_disabled")
    elif option_type == "PUT" and config.get("ALLOW_LONG_PUTS") is not True:
        reasons.append("long_puts_disabled")

    if candidate["quote_is_fresh"] is not True:
        reasons.append("freshness_unverified")
    if candidate["setup_qualified"] is not True:
        reasons.append("upstream_setup_not_qualified")
    if dte == 0 and config.get("ALLOW_0DTE") is not True:
        reasons.append("zero_dte_disabled")
    if dte < thresholds["MIN_DTE"] or dte > thresholds["MAX_DTE"]:
        reasons.append("dte_out_of_range")
    if spread_percent > thresholds["MAX_BID_ASK_SPREAD_PERCENT"]:
        reasons.append("spread_too_wide")
    if volume < thresholds["MIN_OPTION_VOLUME"]:
        reasons.append("option_volume_too_low")
    if open_interest < thresholds["MIN_OPTION_OPEN_INTEREST"]:
        reasons.append("option_open_interest_too_low")
    if liquidity < thresholds["MIN_UNDERLYING_LIQUIDITY"]:
        reasons.append("underlying_liquidity_too_low")

    style = assess_option_styles(candidate, config)
    if not style["eligible_styles"]:
        reasons.append("no_trade_style_eligible")
        reasons.extend(str(reason) for reason in style["common_reasons"])
        for trade_style, style_reasons in style["style_reasons"].items():
            reasons.extend(f"{trade_style.lower()}:{reason}" for reason in style_reasons)

    metrics = {
        "dte": dte,
        "spread_percent": round(spread_percent, 4),
        "option_volume": volume,
        "option_open_interest": open_interest,
        "underlying_avg_daily_dollar_volume": liquidity,
        **style["metrics"],
    }
    return GateResult(
        candidate_id,
        symbol,
        "REJECTED" if reasons else "QUALIFIED",
        tuple(reasons),
        metrics,
    )


def scan_candidates(
    candidates: Iterable[Mapping[str, Any]], config: TradingConfig
) -> dict[str, Any]:
    candidate_list = list(candidates)
    candidate_ids = [
        str(candidate.get("candidate_id") or "UNKNOWN") for candidate in candidate_list
    ]
    duplicate_ids = {item for item in candidate_ids if candidate_ids.count(item) > 1}
    results = []
    for candidate in candidate_list:
        result = evaluate_candidate(candidate, config)
        if result.candidate_id in duplicate_ids:
            result = GateResult(
                result.candidate_id,
                result.symbol,
                "INSUFFICIENT_DATA",
                ("duplicate_candidate_id",),
                {},
            )
        results.append(result)
    qualified = [result.as_dict() for result in results if result.status == "QUALIFIED"]
    rejected = [result.as_dict() for result in results if result.status == "REJECTED"]
    insufficient = [result.as_dict() for result in results if result.status == "INSUFFICIENT_DATA"]
    overall_status = "QUALIFIED" if qualified else "ZERO_QUALIFIED"
    if insufficient and not qualified and not rejected:
        overall_status = "INSUFFICIENT_DATA"
    return {
        "status": overall_status,
        "counts": {
            "input": len(results),
            "qualified": len(qualified),
            "rejected": len(rejected),
            "insufficient_data": len(insufficient),
        },
        "duplicate_candidate_ids": sorted(duplicate_ids),
        "qualified": qualified,
        "rejected": rejected,
        "insufficient_data": insufficient,
    }


def _load_candidates(path: Path) -> list[Mapping[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    candidates = payload.get("candidates") if isinstance(payload, dict) else payload
    if not isinstance(candidates, list) or not all(isinstance(item, dict) for item in candidates):
        raise ValueError("input must be a JSON list or an object containing a candidates list")
    return candidates


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("CONFIG.md"))
    parser.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    result = scan_candidates(_load_candidates(args.input), load_config(args.config))
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
