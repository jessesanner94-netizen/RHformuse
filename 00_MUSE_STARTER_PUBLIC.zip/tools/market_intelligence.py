"""Model-free broad market news plus capability-gated Agent Reach social discovery."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from collections.abc import Callable, Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote_plus
from urllib.request import Request, urlopen
from xml.etree import ElementTree

from tools.config import TradingConfig, load_config
from tools.state_manager import guarded_json_update

NEWS_QUERIES = (
    ("market", '(NYSE OR Nasdaq OR "S&P 500" OR "Dow Jones") when:1h'),
    (
        "earnings",
        "(NYSE OR Nasdaq) (earnings OR guidance OR merger OR acquisition OR FDA OR SEC) when:1h",
    ),
    ("macro", '("Federal Reserve" OR "US inflation" OR "US jobs" OR Treasury) markets when:1h'),
)
SOCIAL_QUERY = "(SPY OR QQQ OR stocks) options earnings"
MAX_SEEN = 10000
MAX_NEW_ITEMS = 15
_SOCIAL_ITEM_ID = re.compile(r"(?m)^-\s+id:\s*['\"]?([^'\"\s]+)")


def fetch_google_news_query(
    label: str, query: str, *, timeout: float = 15.0
) -> list[dict[str, str]]:
    url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl=en-US&gl=US&ceid=US:en"
    request = Request(url, headers={"User-Agent": "Robinhood-Agentic-News-Monitor/0.2"})
    with urlopen(request, timeout=timeout) as response:
        raw = response.read()
    root = ElementTree.fromstring(raw)
    items: list[dict[str, str]] = []
    for node in root.findall("./channel/item")[:100]:
        title = (node.findtext("title") or "").strip()
        link = (node.findtext("link") or "").strip()
        published = (node.findtext("pubDate") or "").strip()
        source_node = node.find("source")
        source = (source_node.text or "").strip() if source_node is not None else ""
        if title and link:
            items.append(
                {
                    "channel": label,
                    "title": title,
                    "link": link,
                    "published": published,
                    "source": source,
                }
            )
    return items


def _digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _social_digest(results: list[dict[str, Any]]) -> str:
    """Hash stable post identities, excluding volatile view/like counters."""
    normalized: list[dict[str, Any]] = []
    for result in results:
        output = str(result.get("output", ""))
        item_ids = sorted(set(_SOCIAL_ITEM_ID.findall(output)))
        normalized.append(
            {
                "channel": result.get("channel"),
                "backend": result.get("backend"),
                "items": item_ids if item_ids else [_digest(output)],
            }
        )
    return _digest(normalized)


def _load_json(path: Path) -> Mapping[str, Any] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, Mapping) else None


def _balanced_new_items(
    unique: Mapping[str, dict[str, str]], previous_ids: set[str]
) -> list[dict[str, str]]:
    queues: dict[str, list[tuple[str, dict[str, str]]]] = {
        channel: [] for channel, _ in NEWS_QUERIES
    }
    for identifier, item in unique.items():
        if identifier not in previous_ids:
            queues.setdefault(item.get("channel", "market"), []).append((identifier, item))
    balanced: list[dict[str, str]] = []
    channel_order = ("earnings", "macro", "market")
    while len(balanced) < MAX_NEW_ITEMS and any(queues.values()):
        for channel in channel_order:
            queue = queues.get(channel, [])
            if queue and len(balanced) < MAX_NEW_ITEMS:
                identifier, item = queue.pop(0)
                balanced.append({"id": identifier, **item})
    return balanced


def collect_broad_news(
    *,
    state_path: Path,
    fetcher: Callable[[str, str], list[dict[str, str]]] = fetch_google_news_query,
    now: datetime | None = None,
    commit: bool = True,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    items: list[dict[str, str]] = []
    errors: list[dict[str, str]] = []
    for label, query in NEWS_QUERIES:
        try:
            items.extend(fetcher(label, query))
        except Exception as exc:
            errors.append({"channel": label, "error": f"{type(exc).__name__}: {exc}"})
    unique: dict[str, dict[str, str]] = {}
    for item in items:
        identifier = _digest(
            {
                "title": item.get("title", "").casefold(),
                "link": item.get("link", ""),
            }
        )
        unique.setdefault(identifier, item)
    prior = _load_json(state_path)
    previous_ids = set(prior.get("seen", [])) if prior else set()
    new_items = _balanced_new_items(unique, previous_ids)
    seen = list(dict.fromkeys([*unique.keys(), *previous_ids]))[:MAX_SEEN]
    write: dict[str, Any] | None = None
    if unique:
        write = guarded_json_update(
            state_path,
            {
                "updated_at": current.astimezone(UTC).isoformat(),
                "seen": seen,
            },
            commit=commit,
        )
        write.pop("payload", None)
    return {
        "status": "NEW_ITEMS" if new_items else "DEGRADED" if errors else "QUIET",
        "wake_luna": bool(new_items),
        "items_seen": len(unique),
        "new_items": new_items,
        "errors": errors,
        "persistent_write": write,
    }


def _doctor(
    *,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> dict[str, Any]:
    executable = shutil.which("agent-reach") or shutil.which("agent-reach.exe")
    if not executable:
        return {"status": "ERROR", "error": "agent_reach_not_found", "channels": {}}
    completed = runner(
        [executable, "doctor", "--json"],
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
        timeout=45,
    )
    if completed.returncode != 0:
        return {
            "status": "ERROR",
            "error": completed.stderr.strip() or "agent_reach_doctor_failed",
            "channels": {},
        }
    if not isinstance(completed.stdout, str):
        return {"status": "ERROR", "error": "agent_reach_doctor_no_output", "channels": {}}
    try:
        channels = json.loads(completed.stdout)
    except json.JSONDecodeError:
        return {"status": "ERROR", "error": "agent_reach_doctor_invalid_json", "channels": {}}
    opencli_connected = False
    opencli = shutil.which("opencli") or shutil.which("opencli.exe")
    if opencli:
        bridge = runner(
            [opencli, "doctor"],
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
            timeout=15,
        )
        bridge_output = f"{bridge.stdout}\n{bridge.stderr}".casefold()
        opencli_connected = bridge.returncode == 0 and "extension: connected" in bridge_output
    return {
        "status": "OK",
        "channels": channels,
        "opencli_connected": opencli_connected,
    }


def agent_reach_capabilities(
    *,
    cache_path: Path,
    now: datetime | None = None,
    max_age_seconds: int = 21600,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    commit: bool = True,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    cached = _load_json(cache_path)
    if cached:
        updated = cached.get("updated_at")
        try:
            parsed = datetime.fromisoformat(str(updated).replace("Z", "+00:00"))
        except ValueError:
            parsed = None
        age_seconds = (
            (current.astimezone(UTC) - parsed.astimezone(UTC)).total_seconds()
            if parsed is not None
            else None
        )
        if (
            age_seconds is not None
            and age_seconds <= max_age_seconds
            and "opencli_connected" in cached
        ):
            return {**dict(cached), "cached": True}
    result = _doctor(runner=runner)
    payload = {
        "updated_at": current.astimezone(UTC).isoformat(),
        **result,
    }
    if commit:
        write = guarded_json_update(cache_path, payload, commit=True)
        write.pop("payload", None)
        payload["persistent_write"] = write
    payload["cached"] = False
    return payload


def _run_social_command(
    command: list[str],
    *,
    channel: str,
    backend: str,
    runner: Callable[..., subprocess.CompletedProcess[str]],
    environ: Mapping[str, str],
) -> dict[str, Any]:
    completed = runner(
        command,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
        timeout=45,
        env=dict(environ),
    )
    return {
        "channel": channel,
        "backend": backend,
        "command": command[0],
        "status": "OK" if completed.returncode == 0 else "ERROR",
        "output": completed.stdout.strip()[:12000],
        "error": completed.stderr.strip()[:2000],
    }


def collect_agent_reach_social(
    capabilities: Mapping[str, Any],
    *,
    state_path: Path,
    enabled: bool,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    environ: Mapping[str, str] | None = None,
    now: datetime | None = None,
    commit: bool = True,
) -> dict[str, Any]:
    if not enabled:
        return {"status": "DISABLED", "wake_luna": False, "results": []}
    channels = capabilities.get("channels")
    if not isinstance(channels, Mapping):
        return {"status": "UNAVAILABLE", "wake_luna": False, "results": []}
    environment = os.environ if environ is None else environ
    results: list[dict[str, Any]] = []
    unavailable: list[str] = []
    opencli_connected = capabilities.get("opencli_connected") is True
    opencli_executable = shutil.which("opencli") or shutil.which("opencli.exe")
    twitter = channels.get("twitter") if isinstance(channels.get("twitter"), Mapping) else {}
    twitter_backend = twitter.get("active_backend")
    twitter_backends = twitter.get("backends") if isinstance(twitter.get("backends"), list) else []
    if (
        twitter_backend == "OpenCLI" or (opencli_connected and "OpenCLI" in twitter_backends)
    ) and opencli_executable:
        results.append(
            _run_social_command(
                [opencli_executable, "twitter", "search", SOCIAL_QUERY, "-f", "yaml"],
                channel="twitter",
                backend="OpenCLI",
                runner=runner,
                environ=environment,
            )
        )
    elif (
        twitter_backend == "twitter-cli"
        and (twitter_executable := shutil.which("twitter"))
        and environment.get("TWITTER_AUTH_TOKEN")
        and environment.get("TWITTER_CT0")
    ):
        results.append(
            _run_social_command(
                [twitter_executable, "search", SOCIAL_QUERY, "-n", "10"],
                channel="twitter",
                backend="twitter-cli",
                runner=runner,
                environ=environment,
            )
        )
    else:
        unavailable.append("twitter")
    reddit = channels.get("reddit") if isinstance(channels.get("reddit"), Mapping) else {}
    reddit_backend = reddit.get("active_backend")
    reddit_backends = reddit.get("backends") if isinstance(reddit.get("backends"), list) else []
    if (
        reddit_backend == "OpenCLI" or (opencli_connected and "OpenCLI" in reddit_backends)
    ) and opencli_executable:
        results.append(
            _run_social_command(
                [opencli_executable, "reddit", "search", SOCIAL_QUERY, "-f", "yaml"],
                channel="reddit",
                backend="OpenCLI",
                runner=runner,
                environ=environment,
            )
        )
    elif reddit_backend == "rdt-cli" and (rdt_executable := shutil.which("rdt")):
        results.append(
            _run_social_command(
                [rdt_executable, "search", SOCIAL_QUERY, "--limit", "10"],
                channel="reddit",
                backend="rdt-cli",
                runner=runner,
                environ=environment,
            )
        )
    else:
        unavailable.append("reddit")
    successful = [item for item in results if item["status"] == "OK" and item["output"]]
    digest = _social_digest(successful)
    prior = _load_json(state_path)
    previous_digest = prior.get("digest") if prior else None
    changed = bool(successful) and digest != previous_digest
    write: dict[str, Any] | None = None
    if successful:
        write = guarded_json_update(
            state_path,
            {
                "updated_at": (now or datetime.now(UTC)).astimezone(UTC).isoformat(),
                "digest": digest,
            },
            commit=commit,
        )
        write.pop("payload", None)
    return {
        "status": "NEW_ITEMS" if changed else "QUIET" if successful else "UNAVAILABLE",
        "wake_luna": changed,
        "results": successful,
        "unavailable_channels": unavailable,
        "errors": [item for item in results if item["status"] == "ERROR"],
        "persistent_write": write,
    }


def _successful_social_backend(social: Mapping[str, Any], channel: str) -> str | None:
    results = social.get("results")
    if not isinstance(results, list):
        return None
    for result in results:
        if (
            isinstance(result, Mapping)
            and result.get("channel") == channel
            and result.get("status") == "OK"
            and result.get("output")
        ):
            backend = result.get("backend")
            return str(backend) if backend else None
    return None


def collect_market_intelligence(
    config: TradingConfig,
    *,
    runtime_dir: Path,
    now: datetime | None = None,
    news_fetcher: Callable[[str, str], list[dict[str, str]]] = fetch_google_news_query,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    commit: bool = True,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    news = (
        collect_broad_news(
            state_path=runtime_dir / "broad_news_seen.json",
            fetcher=news_fetcher,
            now=current,
            commit=commit,
        )
        if config.get("BROAD_NEWS_ENABLED") is True
        else {"status": "DISABLED", "wake_luna": False, "new_items": []}
    )
    capabilities = agent_reach_capabilities(
        cache_path=runtime_dir / "agent_reach_status.json",
        now=current,
        runner=runner,
        commit=commit,
    )
    social = collect_agent_reach_social(
        capabilities,
        state_path=runtime_dir / "social_seen.json",
        enabled=config.get("AGENT_REACH_SOCIAL_ENABLED") is True,
        runner=runner,
        now=current,
        commit=commit,
    )
    twitter_backend = _successful_social_backend(social, "twitter")
    reddit_backend = _successful_social_backend(social, "reddit")
    capability_channels = capabilities.get("channels")
    doctor_twitter_backend = (
        capability_channels.get("twitter", {}).get("active_backend")
        if isinstance(capability_channels, Mapping)
        and isinstance(capability_channels.get("twitter"), Mapping)
        else None
    )
    doctor_reddit_backend = (
        capability_channels.get("reddit", {}).get("active_backend")
        if isinstance(capability_channels, Mapping)
        and isinstance(capability_channels.get("reddit"), Mapping)
        else None
    )
    return {
        "status": "CHANGED" if news.get("wake_luna") or social.get("wake_luna") else "QUIET",
        "wake_luna": news.get("wake_luna") is True or social.get("wake_luna") is True,
        "news": news,
        "social": social,
        "agent_reach": {
            "status": capabilities.get("status"),
            "cached": capabilities.get("cached"),
            "opencli_connected": capabilities.get("opencli_connected"),
            "twitter_available": twitter_backend is not None,
            "reddit_available": reddit_backend is not None,
            "twitter_backend": twitter_backend,
            "reddit_backend": reddit_backend,
            "doctor_twitter_backend": doctor_twitter_backend,
            "doctor_reddit_backend": doctor_reddit_backend,
        },
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--commit", action="store_true")
    args = parser.parse_args(argv)
    project_root = args.project_root.resolve()
    config = load_config(project_root / "CONFIG.md")
    result = collect_market_intelligence(
        config,
        runtime_dir=project_root / "state" / "runtime",
        commit=args.commit,
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result.get("status") != "ERROR" else 1


if __name__ == "__main__":
    raise SystemExit(main())
