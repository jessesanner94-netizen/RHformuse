"""Options strategy identity and realized-only daily entry lock, shared by both modes."""

import re
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.config import ConfigError, TradingConfig


def strategy_epoch(config: TradingConfig) -> str | None:
    epoch = config.get("OPTIONS_STRATEGY_EPOCH")
    if epoch is None:
        return None
    if not isinstance(epoch, str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,79}", epoch):
        raise ConfigError("invalid OPTIONS_STRATEGY_EPOCH")
    return epoch


def ledger_directory(root: Path, config: TradingConfig, mode: str) -> Path:
    if mode not in {"paper", "live"}:
        raise ValueError("invalid options ledger mode")
    epoch = strategy_epoch(config)
    return root / "state" / "options" / epoch / mode if epoch else root / "state" / mode


def prepare_day(state: dict[str, Any]) -> None:
    day = state["day"]
    day.setdefault("green_lock_active", False)
    day.setdefault("lock_activated_at", None)
    day.setdefault("realized_pnl_at_activation", None)
    day.setdefault("skipped_entry_count", 0)


def identify_state(state: dict[str, Any], config: TradingConfig) -> None:
    epoch = strategy_epoch(config)
    if epoch:
        if state.get("strategy_epoch") not in (None, epoch):
            raise ValueError("options strategy ledger identity mismatch")
        state["strategy_epoch"] = epoch
    if config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True:
        prepare_day(state)


def activate_green_lock(
    state: dict[str, Any], *, now: datetime, strategy_variant: str | None
) -> dict[str, Any] | None:
    if strategy_variant is None:
        return None
    prepare_day(state)
    day = state["day"]
    if day["green_lock_active"] is True or float(day["realized_pnl"]) <= 0:
        return None
    timestamp = now.astimezone(UTC).isoformat()
    day.update(
        green_lock_active=True,
        lock_activated_at=timestamp,
        realized_pnl_at_activation=day["realized_pnl"],
    )
    return {
        "event": "DAILY_GREEN_LOCK_ACTIVATED",
        "strategy_variant": strategy_variant,
        "timestamp": timestamp,
        "trading_day": day["date"],
        "daily_realized_pnl": day["realized_pnl"],
        "reason": "daily_green_lock_active",
    }


def entry_locked(portfolio: Mapping[str, Any]) -> bool:
    day = portfolio.get("day", {})
    return isinstance(day, Mapping) and day.get("green_lock_active") is True
