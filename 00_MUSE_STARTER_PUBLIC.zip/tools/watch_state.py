"""Persistent, model-free WATCH conditions for the paper decision loop.

This module has no broker, budget, or model dependency. Callers must complete
all normal eligibility and risk gates again before acting on a claimed wake.
"""

from __future__ import annotations

import json
import math
import re
import secrets
import sqlite3
from collections.abc import Mapping
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

MAX_ACTIVE_WATCHES = 3
MAX_CONDITIONS = 8
MAX_OBSERVATION_AGE = timedelta(minutes=3)
MAX_FUTURE_SKEW = timedelta(seconds=30)
_FIELD = re.compile(r"^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*){0,3}$")
_OPERATORS = {"eq", "ne", "gt", "gte", "lt", "lte"}
_ACTIVE = ("ACTIVE", "ESCALATING")


def _utc(value: datetime | str, name: str) -> datetime:
    try:
        parsed = (
            datetime.fromisoformat(value.replace("Z", "+00:00"))
            if isinstance(value, str)
            else value
        )
    except ValueError as exc:
        raise ValueError(f"{name} must be an ISO 8601 timestamp") from exc
    if not isinstance(parsed, datetime) or parsed.tzinfo is None:
        raise ValueError(f"{name} must have a UTC offset")
    return parsed.astimezone(UTC)


def _stamp(value: datetime) -> str:
    return value.astimezone(UTC).isoformat(timespec="microseconds")


def _scalar(value: Any) -> bool:
    return isinstance(value, (str, bool)) or (
        isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    )


def _identity(candidate: Mapping[str, Any]) -> dict[str, str]:
    identity = {
        "symbol": str(candidate.get("symbol") or "").upper().strip(),
        "candidate_id": str(candidate.get("candidate_id") or "").strip(),
        "option_type": str(candidate.get("option_type") or "").upper().strip(),
        "expiration": str(candidate.get("expiration") or "").strip(),
        "strike": str(
            candidate.get("strike") if candidate.get("strike") is not None else ""
        ).strip(),
        "trade_style": str(
            candidate.get("trade_style") or candidate.get("python_preferred_style") or ""
        )
        .upper()
        .strip(),
    }
    # Robinhood's stable instrument ID is candidate_id. The optional display
    # symbol is absent from real option instruments and is not part of identity.
    if not all(identity.values()):
        raise ValueError("exact candidate contract, direction, and trade style are required")
    if identity["option_type"] not in {"CALL", "PUT"} or identity["trade_style"] not in {
        "DAY",
        "SWING",
    }:
        raise ValueError("option_type or trade_style is invalid")
    strike = float(identity["strike"])
    if not math.isfinite(strike) or strike <= 0:
        raise ValueError("strike must be positive and finite")
    identity["strike"] = str(strike)
    return identity


def _condition(raw: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, Mapping) or set(raw) != {"field", "operator", "value"}:
        raise ValueError("condition requires only field, operator, and value")
    field, operator, value = raw["field"], raw["operator"], raw["value"]
    if not isinstance(field, str) or not _FIELD.fullmatch(field):
        raise ValueError("condition field must be a simple dotted observation path")
    if not isinstance(operator, str) or operator not in _OPERATORS or not _scalar(value):
        raise ValueError("condition operator or scalar value is invalid")
    if operator not in {"eq", "ne"} and (
        isinstance(value, bool) or not isinstance(value, (int, float))
    ):
        raise ValueError("ordered comparisons require a finite number")
    return {"field": field, "operator": operator, "value": value}


def _conditions(decision: Mapping[str, Any], now: datetime) -> dict[str, Any]:
    raw = decision.get("watch_conditions")
    if raw is None and str(decision.get("action") or "").upper() == "WAIT":
        raw = {
            "wake_all": [],
            "invalidate_any": [],
            "expires_at": decision.get("decision_valid_until"),
        }
    if not isinstance(raw, Mapping) or set(raw) != {"wake_all", "invalidate_any", "expires_at"}:
        raise ValueError("watch_conditions requires wake_all, invalidate_any, expires_at")
    wake_raw, invalid_raw = raw["wake_all"], raw["invalidate_any"]
    if not isinstance(wake_raw, list) or not isinstance(invalid_raw, list):
        raise ValueError("condition groups must be arrays")
    if len(wake_raw) + len(invalid_raw) > MAX_CONDITIONS:
        raise ValueError("too many watch conditions")
    wake = [_condition(row) for row in wake_raw]
    invalid = [_condition(row) for row in invalid_raw]
    if (
        decision.get("reconsider_above") is not None
        and decision.get("reconsider_below") is not None
    ):
        raise ValueError("only one legacy price trigger is allowed")
    for key, operator in (("reconsider_above", "gte"), ("reconsider_below", "lte")):
        price = decision.get(key)
        if price is not None:
            if (
                isinstance(price, bool)
                or not isinstance(price, (int, float))
                or not math.isfinite(price)
                or price <= 0
            ):
                raise ValueError(f"{key} must be a positive finite number")
            price_condition = {"field": "underlying_price", "operator": operator, "value": price}
            if price_condition not in wake:
                wake.append(price_condition)
    if not wake or len(wake) + len(invalid) > MAX_CONDITIONS:
        raise ValueError("WATCH needs 1 to 8 total conditions and at least one wake condition")
    expiration = _utc(raw["expires_at"], "expires_at")
    valid_until = _utc(str(decision.get("decision_valid_until") or ""), "decision_valid_until")
    if expiration <= now or expiration > valid_until:
        raise ValueError("watch expiration must be future and within decision validity")
    if expiration - now > timedelta(minutes=60):
        raise ValueError("watch expiration exceeds the 60-minute monitoring horizon")
    return {"wake_all": wake, "invalidate_any": invalid, "expires_at": _stamp(expiration)}


def _connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=10000")
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS watches (
          id INTEGER PRIMARY KEY, identity_json TEXT NOT NULL, decision_json TEXT NOT NULL,
          conditions_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL, last_observed_at TEXT, claim_token TEXT,
          claim_expires_at TEXT, terminal_reason TEXT);
        CREATE INDEX IF NOT EXISTS watches_status ON watches(status);
        CREATE TABLE IF NOT EXISTS watch_events (
          id INTEGER PRIMARY KEY, watch_id INTEGER NOT NULL, at TEXT NOT NULL,
          from_status TEXT, to_status TEXT NOT NULL, reason TEXT NOT NULL,
          details_json TEXT NOT NULL, FOREIGN KEY(watch_id) REFERENCES watches(id));
        CREATE TRIGGER IF NOT EXISTS watch_events_no_update
          BEFORE UPDATE ON watch_events
          BEGIN SELECT RAISE(ABORT, 'watch events are immutable'); END;
        CREATE TRIGGER IF NOT EXISTS watch_events_no_delete
          BEFORE DELETE ON watch_events
          BEGIN SELECT RAISE(ABORT, 'watch events are immutable'); END;
        """
    )
    return db


def _event(
    db: sqlite3.Connection,
    watch_id: int,
    at: str,
    old: str | None,
    new: str,
    reason: str,
    details: Mapping[str, Any] | None = None,
) -> None:
    db.execute(
        "INSERT INTO watch_events(watch_id, at, from_status, to_status, reason, details_json) "
        "VALUES(?,?,?,?,?,?)",
        (watch_id, at, old, new, reason, json.dumps(details or {}, sort_keys=True)),
    )


def _transition(
    db: sqlite3.Connection,
    row: sqlite3.Row,
    at: str,
    status: str,
    reason: str,
    *,
    token: str | None = None,
    claim_expires_at: str | None = None,
) -> None:
    if status == "RECOVERY_REQUIRED":
        token = row["claim_token"]
    db.execute(
        "UPDATE watches SET status=?, updated_at=?, claim_token=?, claim_expires_at=?, "
        "terminal_reason=? WHERE id=?",
        (status, at, token, claim_expires_at, reason if status not in _ACTIVE else None, row["id"]),
    )
    _event(db, row["id"], at, row["status"], status, reason)


def _expire(db: sqlite3.Connection, now: datetime) -> None:
    at = _stamp(now)
    for row in db.execute(
        "SELECT * FROM watches WHERE status IN ('ACTIVE','ESCALATING')"
    ).fetchall():
        expiration = json.loads(row["conditions_json"])["expires_at"]
        if row["status"] == "ACTIVE" and at >= expiration:
            _transition(db, row, at, "EXPIRED", "watch_expired")
        elif (
            row["status"] == "ESCALATING"
            and row["claim_expires_at"]
            and at >= row["claim_expires_at"]
        ):
            _transition(
                db, row, at, "RECOVERY_REQUIRED", "claim_lease_expired_model_call_uncertain"
            )


def save_watch(
    db_path: Path,
    *,
    candidate: Mapping[str, Any],
    decision: Mapping[str, Any],
    now: datetime | None = None,
) -> dict[str, Any]:
    """Persist one validated WATCH/WAIT; returns SAVED, REPLACED, or CAP_REACHED."""

    current = _utc(now or datetime.now(UTC), "now")
    action = str(decision.get("action") or "").upper()
    if action not in {"WATCH", "WAIT"}:
        raise ValueError("save_watch requires a WATCH or WAIT decision")
    identity = _identity(candidate)
    if str(decision.get("candidate_id") or "") != identity["candidate_id"]:
        raise ValueError("decision candidate_id does not match contract")
    conditions = _conditions(decision, current)
    at = _stamp(current)
    identity_json = json.dumps(identity, sort_keys=True, separators=(",", ":"))
    with _connect(Path(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        _expire(db, current)
        rows = db.execute(
            "SELECT * FROM watches WHERE status IN ('ACTIVE','ESCALATING')"
        ).fetchall()
        uncertain = db.execute(
            "SELECT id FROM watches WHERE identity_json=? AND status='RECOVERY_REQUIRED' "
            "ORDER BY id DESC LIMIT 1",
            (identity_json,),
        ).fetchone()
        if uncertain:
            return {"status": "RECOVERY_REQUIRED", "watch_id": uncertain["id"]}
        same = next((row for row in rows if row["identity_json"] == identity_json), None)
        if same and same["status"] == "ESCALATING":
            return {"status": "ALREADY_CLAIMED", "watch_id": same["id"]}
        if len(rows) >= MAX_ACTIVE_WATCHES and same is None:
            return {"status": "CAP_REACHED", "active_count": len(rows)}
        if same:
            _transition(db, same, at, "REPLACED", "new_watch_for_same_contract")
        cursor = db.execute(
            "INSERT INTO watches(identity_json,decision_json,conditions_json,status,"
            "created_at,updated_at) "
            "VALUES(?,?,?,?,?,?)",
            (
                identity_json,
                json.dumps(dict(decision), sort_keys=True),
                json.dumps(conditions, sort_keys=True),
                "ACTIVE",
                at,
                at,
            ),
        )
        watch_id = int(cursor.lastrowid)
        _event(db, watch_id, at, None, "ACTIVE", "watch_saved", {"identity": identity})
        return {
            "status": "REPLACED" if same else "SAVED",
            "watch_id": watch_id,
            "active_count": len(rows) + (0 if same else 1),
        }


_MISSING = object()


def _lookup(observations: Mapping[str, Any], field: str) -> Any:
    value: Any = observations
    for part in field.split("."):
        if not isinstance(value, Mapping) or part not in value:
            return _MISSING
        value = value[part]
    return value


def _matches(observations: Mapping[str, Any], condition: Mapping[str, Any]) -> bool:
    actual = _lookup(observations, condition["field"])
    expected = condition["value"]
    if actual is _MISSING or not _scalar(actual):
        return False
    if type(expected) is bool:
        if type(actual) is not bool:
            return False
    elif isinstance(expected, str):
        if not isinstance(actual, str):
            return False
    elif isinstance(actual, bool) or not isinstance(actual, (int, float)):
        return False
    op = condition["operator"]
    if op == "eq":
        return actual == expected
    if op == "ne":
        return actual != expected
    if not isinstance(actual, (int, float)) or isinstance(actual, bool):
        return False
    return {
        "gt": actual > expected,
        "gte": actual >= expected,
        "lt": actual < expected,
        "lte": actual <= expected,
    }[op]


def bound_watch_expiration(decision: Mapping[str, Any], *, now: datetime,
                           deadline: datetime) -> dict[str, Any]:
    """Shorten a watch lease without changing its thesis, triggers, or trade deadline."""
    result = dict(decision)
    raw = decision.get("watch_conditions")
    if not isinstance(raw, Mapping):
        raise ValueError("watch_conditions requires wake_all, invalidate_any, expires_at")
    expiry = _utc(raw.get("expires_at"), "expires_at")
    validity = _utc(decision.get("decision_valid_until"), "decision_valid_until")
    limit = min(_utc(deadline, "deadline"), _utc(now, "now") + timedelta(minutes=60))
    result["watch_conditions"] = {**raw, "expires_at": _stamp(min(expiry, validity, limit))}
    return result


def validate_handoff(
    decision: Mapping[str, Any], observations: Mapping[str, Any], *, now: datetime | None = None
) -> None:
    """A new model watch must wait for a measurable change, not an already-true condition."""
    conditions = _conditions(decision, _utc(now or datetime.now(UTC), "now"))
    for condition in [*conditions["wake_all"], *conditions["invalidate_any"]]:
        value = _lookup(observations, condition["field"])
        if value is _MISSING or not _scalar(value):
            raise ValueError("watch field is absent from current observations")
    if all(_matches(observations, condition) for condition in conditions["wake_all"]):
        raise ValueError("watch wake is already satisfied")
    if any(_matches(observations, condition) for condition in conditions["invalidate_any"]):
        raise ValueError("watch is already invalidated")


def evaluate_watch(
    db_path: Path,
    *,
    candidate: Mapping[str, Any],
    observations: Mapping[str, Any],
    observed_at: datetime | str,
    now: datetime | None = None,
    lease_seconds: int = 300,
) -> dict[str, Any]:
    """Atomically evaluate and claim one exact contract. Reserve model budget only after READY."""

    current = _utc(now or datetime.now(UTC), "now")
    if not isinstance(observations, Mapping) or not 1 <= lease_seconds <= 3600:
        raise ValueError("observations or lease_seconds invalid")
    identity_json = json.dumps(_identity(candidate), sort_keys=True, separators=(",", ":"))
    at = _stamp(current)
    with _connect(Path(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        _expire(db, current)
        row = db.execute(
            "SELECT * FROM watches WHERE identity_json=? ORDER BY id DESC LIMIT 1", (identity_json,)
        ).fetchone()
        if row is None:
            return {"status": "NO_WATCH"}
        if row["status"] in {"EXPIRED", "INVALIDATED", "REPLACED"}:
            return {
                "status": "NO_WATCH",
                "watch_id": row["id"],
                "terminal": True,
                "prior_status": row["status"],
            }
        if row["status"] != "ACTIVE":
            return {"status": row["status"], "watch_id": row["id"]}
        observed = _utc(observed_at, "observed_at")
        if observed > current + MAX_FUTURE_SKEW:
            return {"status": "REJECTED", "reason": "future_observation"}
        if current - observed > MAX_OBSERVATION_AGE:
            return {"status": "REJECTED", "reason": "stale_observation"}
        observed_stamp = _stamp(observed)
        if row["last_observed_at"] and observed_stamp <= row["last_observed_at"]:
            return {
                "status": "REJECTED",
                "reason": "out_of_order_observation",
                "watch_id": row["id"],
            }
        db.execute(
            "UPDATE watches SET last_observed_at=?, updated_at=? WHERE id=?",
            (observed_stamp, at, row["id"]),
        )
        conditions = json.loads(row["conditions_json"])
        if any(_matches(observations, condition) for condition in conditions["invalidate_any"]):
            _transition(db, row, at, "INVALIDATED", "invalidation_condition_met")
            return {"status": "INVALIDATED", "watch_id": row["id"]}
        if not all(_matches(observations, condition) for condition in conditions["wake_all"]):
            return {"status": "WAITING", "watch_id": row["id"]}
        token = secrets.token_urlsafe(32)
        claim_expires = _stamp(current + timedelta(seconds=lease_seconds))
        _transition(
            db,
            row,
            at,
            "ESCALATING",
            "wake_conditions_met",
            token=token,
            claim_expires_at=claim_expires,
        )
        return {
            "status": "READY",
            "watch_id": row["id"],
            "claim_token": token,
            "claim_expires_at": claim_expires,
            "decision": json.loads(row["decision_json"]),
        }


def resolve_watch(
    db_path: Path, *, watch_id: int, claim_token: str, outcome: str, now: datetime | None = None
) -> dict[str, Any]:
    """Finish a claimed wake after the caller's model/budget path completes."""

    if outcome not in {"BUY", "PASS", "WATCH", "WAIT", "ERROR", "BUDGET_EXHAUSTED"}:
        raise ValueError("invalid outcome")
    current = _utc(now or datetime.now(UTC), "now")
    with _connect(Path(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        _expire(db, current)
        row = db.execute("SELECT * FROM watches WHERE id=?", (watch_id,)).fetchone()
        if (
            row is None
            or row["status"] not in {"ESCALATING", "RECOVERY_REQUIRED"}
            or row["claim_token"] != claim_token
        ):
            return {"status": "NOT_CLAIMED"}
        _transition(db, row, _stamp(current), "RESOLVED", f"model_outcome_{outcome.lower()}")
        return {"status": "RESOLVED", "watch_id": watch_id}


def release_watch(
    db_path: Path,
    *,
    watch_id: int,
    claim_token: str,
    model_call_started: bool,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Release only a claim whose model call definitely never started."""

    if model_call_started:
        raise ValueError("cannot release a claim after a model call may have started")
    current = _utc(now or datetime.now(UTC), "now")
    with _connect(Path(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        _expire(db, current)
        row = db.execute("SELECT * FROM watches WHERE id=?", (watch_id,)).fetchone()
        if row is None or row["status"] != "ESCALATING" or row["claim_token"] != claim_token:
            return {"status": "NOT_CLAIMED"}
        _transition(db, row, _stamp(current), "ACTIVE", "released_before_model_call")
        return {"status": "RELEASED", "watch_id": watch_id}


def watch_events(db_path: Path, *, watch_id: int) -> list[dict[str, Any]]:
    """Read the append-only transition history for an audit or offline test."""

    with _connect(Path(db_path)) as db:
        return [
            dict(row)
            for row in db.execute(
                "SELECT * FROM watch_events WHERE watch_id=? ORDER BY id", (watch_id,)
            )
        ]


def active_watches(db_path: Path, *, now: datetime | None = None) -> list[dict[str, Any]]:
    """Maintain expirations/leases and list active watches for a model-free cycle."""

    current = _utc(now or datetime.now(UTC), "now")
    with _connect(Path(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        _expire(db, current)
        rows = db.execute(
            "SELECT id,identity_json,conditions_json,status,created_at,last_observed_at "
            "FROM watches WHERE status IN ('ACTIVE','ESCALATING') ORDER BY id"
        ).fetchall()
        return [
            {
                "watch_id": row["id"],
                "identity": json.loads(row["identity_json"]),
                "watch_conditions": json.loads(row["conditions_json"]),
                "status": row["status"],
                "created_at": row["created_at"],
                "last_observed_at": row["last_observed_at"],
            }
            for row in rows
        ]


def invalidate_watch(
    db_path: Path, *, watch_id: int, reason: str, now: datetime | None = None
) -> dict[str, Any]:
    """Silently invalidate an ACTIVE thesis when fresh deterministic gates reject it."""
    current = _utc(now or datetime.now(UTC), "now")
    with _connect(Path(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        _expire(db, current)
        row = db.execute("SELECT * FROM watches WHERE id=?", (watch_id,)).fetchone()
        if row is None or row["status"] != "ACTIVE":
            return {"status": "NOT_ACTIVE"}
        _transition(db, row, _stamp(current), "INVALIDATED", reason[:100])
        return {"status": "INVALIDATED", "watch_id": watch_id}
