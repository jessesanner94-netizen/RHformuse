"""Review-first unattended long-option execution with deterministic software exits."""

from __future__ import annotations

import asyncio
import json
import math
import os
import tempfile
import uuid
from collections.abc import Awaitable, Callable, Iterator, Mapping
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.cheap_scan import evaluate_candidate as evaluate_contract
from tools.config import TradingConfig, load_config
from tools.market_calendar import day_deadline, entry_allowed
from tools.option_style import annotate_option_styles, assess_option_styles
from tools.options_strategy import (
    activate_green_lock,
    identify_state,
    ledger_directory,
    strategy_epoch,
)
from tools.order_protocol import (
    exception_summary,
    placement_arguments,
    rejected_before_submission,
)
from tools.paper_trading import net_reward_risk, paper_side_cost
from tools.portfolio_risk import evaluate_risk
from tools.position_exposure import held_option_symbols, normalized_symbol
from tools.robinhood_mcp import (
    fetch_option_order_status,
    fetch_quote_refresh,
    fetch_snapshot,
    place_live_option_order,
    review_live_option_order,
)
from tools.runtime_lock import advisory_file_lock
from tools.state_manager import guarded_json_update

EASTERN = ZoneInfo("America/New_York")
SCHEMA_VERSION = 1
TERMINAL_FAILURE_STATES = {"rejected", "cancelled", "failed", "voided", "expired"}
OPEN_ORDER_STATES = {"queued", "confirmed", "partially_filled", "pending_cancelled"}

SnapshotFetcher = Callable[[], Awaitable[dict[str, Any]]]
QuoteFetcher = Callable[[list[Mapping[str, str]]], Awaitable[dict[str, Any]]]
OrderCaller = Callable[[Mapping[str, Any]], Awaitable[dict[str, Any]]]
OrderStatusFetcher = Callable[[str], Awaitable[dict[str, Any]]]


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _fresh(value: Any, *, now: datetime, maximum_age_seconds: int = 240) -> bool:
    parsed = _timestamp(value)
    if parsed is None:
        return False
    age = (now.astimezone(UTC) - parsed).total_seconds()
    return -2 <= age <= maximum_age_seconds


@contextmanager
def _exclusive_lock(target: Path) -> Iterator[None]:
    with advisory_file_lock(target, timeout_seconds=0.25):
        yield


def _atomic_text_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _append_jsonl(path: Path, record: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.parent.parent.parent.name == "options":
        record = {**record, "strategy_epoch": path.parent.parent.name, "mode": "LIVE"}
    serialized = json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n"
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(serialized)
        handle.flush()
        os.fsync(handle.fileno())


def _append_markdown(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write("\n" + text.rstrip() + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _default_state(*, account_value: float, now: datetime) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "mode": "LIVE_UNATTENDED",
        "day": {
            "date": now.astimezone(EASTERN).date().isoformat(),
            "start_equity": round(account_value, 2),
            "realized_pnl": 0.0,
            "new_positions": 0,
        },
        "realized_pnl": 0.0,
        "pending_orders": [],
        "positions": [],
        "recent_closed_positions": [],
        "updated_at": now.astimezone(UTC).isoformat(),
    }


def _load_state(
    path: Path, *, account_value: float, now: datetime, config: TradingConfig | None = None
) -> dict[str, Any]:
    if not path.exists():
        state = _default_state(account_value=account_value, now=now)
        if config is not None:
            identify_state(state, config)
        return state
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping) or payload.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("live state schema is invalid")
    state = dict(payload)
    if "positions" not in state:
        legacy_position = state.get("position")
        if legacy_position is not None and not isinstance(legacy_position, Mapping):
            raise ValueError("invalid legacy position record")
        state["positions"] = [dict(legacy_position)] if isinstance(legacy_position, Mapping) else []
    if not isinstance(state["positions"], list) or any(
        not isinstance(position, Mapping)
        or not position.get("position_id")
        or not position.get("contract_identifier")
        or (_number(position.get("quantity")) or 0) <= 0
        for position in state["positions"]
    ):
        raise ValueError("invalid live position records")
    if len({position["contract_identifier"] for position in state["positions"]}) != len(
        state["positions"]
    ):
        raise ValueError("duplicate live position contracts")
    state.pop("position", None)
    if "pending_orders" not in state:
        legacy_pending = state.get("pending_order")
        if legacy_pending is not None and not isinstance(legacy_pending, Mapping):
            raise ValueError("invalid legacy pending order record")
        state["pending_orders"] = (
            [dict(legacy_pending)] if isinstance(legacy_pending, Mapping) else []
        )
    if not isinstance(state["pending_orders"], list):
        raise ValueError("invalid pending order records")
    state.pop("pending_order", None)
    for pending in state["pending_orders"]:
        if not isinstance(pending, dict):
            raise ValueError("invalid pending order record")
        if pending.get("purpose") == "EXIT" and len(state["positions"]) == 1:
            context = pending.setdefault("context", {})
            context.setdefault("position_id", state["positions"][0].get("position_id"))
    day = state.get("day")
    local_date = now.astimezone(EASTERN).date().isoformat()
    if not isinstance(day, Mapping) or day.get("date") != local_date:
        state["day"] = {
            "date": local_date,
            "start_equity": round(account_value, 2),
            "realized_pnl": 0.0,
            "new_positions": 0,
        }
    if config is not None:
        identify_state(state, config)
    return state


def _save_state(path: Path, state: dict[str, Any]) -> dict[str, Any]:
    write = guarded_json_update(path, state, commit=True)
    write.pop("payload", None)
    _atomic_text_write(path.with_name("SUMMARY.md"), _render_summary(state))
    return write


def _render_summary(state: Mapping[str, Any]) -> str:
    positions = _state_positions(state)
    pending_orders = _state_pending_orders(state)
    lines = [
        "# Live Trading Summary",
        "",
        f"- Updated: {state.get('updated_at')}",
        f"- Mode: {state.get('mode')}",
        f"- Realized P&L: ${float(state.get('realized_pnl', 0)):.2f}",
        f"- Pending orders: {len(pending_orders)}",
        f"- Open positions: {len(positions)}",
        f"- Strategy epoch: {state.get('strategy_epoch', 'legacy')}",
        f"- Realized daily net P&L: ${float(state['day'].get('realized_pnl', 0)):.2f}",
        f"- Green lock active: {state['day'].get('green_lock_active', False)}",
        f"- Lock activated at: {state['day'].get('lock_activated_at')}",
        f"- Realized P&L at activation: {state['day'].get('realized_pnl_at_activation')}",
        f"- Skipped entries: {state['day'].get('skipped_entry_count', 0)}",
    ]
    for position in positions:
        lines.extend(
            [
                "",
                f"## {position.get('symbol')} {position.get('expiration')} "
                f"{position.get('strike')} {position.get('option_type')}",
                "",
                f"- Contract: {position.get('contract_identifier')}",
                f"- Entry fill: ${float(position.get('entry_price', 0)):.2f}",
                f"- Last bid: ${float(position.get('last_bid', 0)):.2f}",
                f"- Stop: ${float(position.get('stop_price', 0)):.2f}",
                f"- Target: ${float(position.get('take_profit_price', 0)):.2f}",
                f"- Style: {position.get('trade_style')}",
                f"- Thesis: {position.get('thesis')}",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def _state_positions(state: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = state.get("positions")
    if isinstance(rows, list):
        return [dict(row) for row in rows if isinstance(row, Mapping)]
    legacy = state.get("position")
    return [dict(legacy)] if isinstance(legacy, Mapping) else []


def _state_pending_orders(state: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = state.get("pending_orders")
    if isinstance(rows, list):
        return [dict(row) for row in rows if isinstance(row, Mapping)]
    legacy = state.get("pending_order")
    return [dict(legacy)] if isinstance(legacy, Mapping) else []


def _order_contracts(order: Mapping[str, Any]) -> set[str]:
    request = order.get("request") if isinstance(order.get("request"), Mapping) else order
    return {
        str(leg.get("option_id") or leg.get("option", "")).rstrip("/").split("/")[-1]
        for leg in request.get("legs", [])
        if isinstance(leg, Mapping) and (leg.get("option_id") or leg.get("option"))
    }


def _unwrap(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    value: Any = payload.get("result", payload)
    if isinstance(value, Mapping) and isinstance(value.get("data"), Mapping):
        value = value["data"]
    return value if isinstance(value, Mapping) else {}


def _find_value(payload: Any, fields: set[str]) -> Any:
    if isinstance(payload, Mapping):
        for key, value in payload.items():
            if str(key) in fields and value is not None and value != "":
                return value
        for value in payload.values():
            found = _find_value(value, fields)
            if found is not None and found != "":
                return found
    elif isinstance(payload, list):
        for value in payload:
            found = _find_value(value, fields)
            if found is not None and found != "":
                return found
    return None


def _order_id(payload: Mapping[str, Any]) -> str | None:
    data = _unwrap(payload)
    order = data.get("order") if isinstance(data.get("order"), Mapping) else data
    value = order.get("id") or order.get("order_id")
    return str(value) if value is not None and value != "" else None


def _order_rows(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    data = _unwrap(payload)
    rows = data.get("orders")
    if isinstance(rows, list):
        return [row for row in rows if isinstance(row, Mapping)]
    return [data] if data.get("state") else []


def _order_fill_price(order: Mapping[str, Any]) -> float | None:
    # A limit is not an execution. The broker reports actual fills on the single option leg.
    legs = order.get("legs")
    executions = order.get("executions")
    if isinstance(legs, list) and len(legs) == 1 and isinstance(legs[0], Mapping):
        executions = legs[0].get("executions") or executions
    if isinstance(executions, list):
        weighted = 0.0
        quantity = 0.0
        for execution in executions:
            if not isinstance(execution, Mapping):
                continue
            price = _number(execution.get("price"))
            count = _number(execution.get("quantity"))
            if price is not None and price >= 0 and count is not None and count > 0:
                weighted += price * count
                quantity += count
        if quantity > 0:
            return weighted / quantity
    premium = _number(order.get("processed_premium"))
    filled = _number(order.get("processed_quantity"))
    multiplier = _number(order.get("trade_value_multiplier"))
    if (
        premium is not None
        and premium >= 0
        and filled
        and filled > 0
        and multiplier
        and multiplier > 0
    ):
        return premium / (filled * multiplier)
    for field in (
        "average_price",
        "average_fill_price",
        "processed_price",
    ):
        value = _number(order.get(field))
        if value is not None and value > 0:
            return value
    return None


def _order_fill_quantity(order: Mapping[str, Any]) -> float | None:
    """Cumulative executed contracts, never the requested order quantity."""
    legs = order.get("legs")
    executions = order.get("executions")
    if isinstance(legs, list) and len(legs) == 1 and isinstance(legs[0], Mapping):
        executions = legs[0].get("executions") or executions
    if isinstance(executions, list) and executions:
        counts = [
            _number(e.get("quantity")) if isinstance(e, Mapping) else None for e in executions
        ]
        if any(q is None or q <= 0 for q in counts):
            return None
        return sum(counts)
    for field in ("processed_quantity", "filled_quantity", "cumulative_quantity"):
        if field in order:
            return _number(order[field])
    return None


def _order_fill_time(order: Mapping[str, Any], fallback: datetime) -> datetime:
    legs = order.get("legs")
    executions = order.get("executions")
    if isinstance(legs, list) and len(legs) == 1 and isinstance(legs[0], Mapping):
        executions = legs[0].get("executions") or executions
    times = [_timestamp(e.get("timestamp")) for e in (executions or []) if isinstance(e, Mapping)]
    valid = [t for t in times if t is not None]
    return max(valid) if valid else (_timestamp(order.get("filled_at")) or fallback)


def _review_assessment(payload: Mapping[str, Any]) -> dict[str, Any]:
    if payload.get("status") != "REVIEWED":
        return {"allowed": False, "reasons": ["review_call_failed"], "checks": []}
    data = _unwrap(payload)
    checks = data.get("order_checks")
    if checks is None and isinstance(data.get("review"), Mapping):
        checks = data["review"].get("order_checks")
    if isinstance(checks, Mapping):
        if checks:
            return {
                "allowed": False,
                "reasons": [str(checks.get("alertType") or "robinhood_review_alert_present")],
                "checks": dict(checks),
            }
        return {"allowed": True, "reasons": [], "checks": {}}
    if not isinstance(checks, list):
        return {"allowed": False, "reasons": ["review_order_checks_missing"], "checks": []}
    reasons: list[str] = []
    for check in checks:
        if not isinstance(check, Mapping):
            reasons.append("malformed_review_check")
            continue
        severity = str(check.get("severity") or check.get("level") or "").lower()
        status = str(check.get("status") or check.get("result") or "").lower()
        blocking = check.get("blocking") is True
        if blocking or severity in {"error", "critical", "blocking"}:
            reasons.append(str(check.get("code") or check.get("detail") or "blocking_alert"))
        elif status in {"failed", "rejected", "blocked", "error"}:
            reasons.append(str(check.get("code") or check.get("detail") or "failed_check"))
    return {"allowed": not reasons, "reasons": reasons, "checks": checks}


def _review_matches_request(
    review: Mapping[str, Any], request: Mapping[str, Any]
) -> tuple[bool, list[str]]:
    data = _unwrap(review)
    reasons: list[str] = []
    for field in ("type", "time_in_force", "market_hours"):
        if str(data.get(field, "")) != str(request.get(field, "")):
            reasons.append(f"review_{field}_mismatch")
    for field in ("quantity", "price", "stop_price"):
        expected = request.get(field)
        if expected is None:
            if data.get(field) not in (None, ""):
                reasons.append(f"review_{field}_unexpected")
            continue
        actual_number = _number(data.get(field))
        expected_number = _number(expected)
        if actual_number is None or expected_number is None or actual_number != expected_number:
            reasons.append(f"review_{field}_mismatch")
    expected_legs = request.get("legs")
    reviewed_legs = data.get("legs")
    if not isinstance(expected_legs, list) or not isinstance(reviewed_legs, list):
        reasons.append("review_legs_missing")
    elif len(expected_legs) != len(reviewed_legs):
        reasons.append("review_leg_count_mismatch")
    else:
        leg_fields = ("option_id", "side", "position_effect", "ratio_quantity")
        for expected, reviewed in zip(expected_legs, reviewed_legs, strict=True):
            if not isinstance(expected, Mapping) or not isinstance(reviewed, Mapping):
                reasons.append("review_leg_malformed")
                continue
            for field in leg_fields:
                expected_value = expected.get(field, 1 if field == "ratio_quantity" else None)
                reviewed_value = reviewed.get(field, 1 if field == "ratio_quantity" else None)
                if str(expected_value) != str(reviewed_value):
                    reasons.append(f"review_leg_{field}_mismatch")
    collateral = data.get("collateral")
    if isinstance(collateral, Mapping):
        cash = collateral.get("cash")
        if isinstance(cash, Mapping) and cash.get("infinite") is True:
            reasons.append("review_unlimited_cash_collateral")
        equities = collateral.get("equities")
        if isinstance(equities, list) and equities:
            reasons.append("review_equity_collateral_present")
    return not reasons, reasons


def _portfolio_metrics(
    snapshot: Mapping[str, Any], state: Mapping[str, Any]
) -> dict[str, float | int]:
    portfolio = snapshot.get("portfolio")
    if not isinstance(portfolio, Mapping):
        raise ValueError("Robinhood portfolio data is missing")
    account_value = _number(portfolio.get("total_value"))
    buying = portfolio.get("buying_power")
    buying_power = _number(buying.get("buying_power") if isinstance(buying, Mapping) else buying)
    day = state.get("day") if isinstance(state.get("day"), Mapping) else {}
    positions = _state_positions(state)
    if account_value is None or buying_power is None:
        raise ValueError("Robinhood account value or buying power is invalid")
    entry_cost = sum(
        float(position.get("entry_price", 0)) * int(position.get("quantity", 1)) * 100
        for position in positions
    )
    return {
        "account_value": account_value,
        "account_value_start_of_day": float(day.get("start_equity", account_value)),
        "buying_power": buying_power,
        "daily_pnl": account_value - float(day.get("start_equity", account_value)),
        "open_stop_risk": sum(
            max(
                0.0,
                (float(item.get("last_bid", item["entry_price"])) - float(item["stop_price"]))
                * int(item.get("quantity", 1))
                * 100,
            )
            + float(item.get("exit_cost_estimate", 0))
            for item in positions
        ),
        "open_premium_at_risk": entry_cost,
        "open_position_count": len(positions),
        "new_positions_today": int(day.get("new_positions", 0)),
    }


def _quote_map(payload: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for row in payload.get("option_quotes", []):
        if not isinstance(row, Mapping):
            continue
        body = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        contract_id = body.get("instrument_id") or body.get("option_id")
        if isinstance(contract_id, str):
            result[contract_id] = body
    return result


def _underlying_quote(payload: Mapping[str, Any], symbol: str) -> Mapping[str, Any] | None:
    for row in payload.get("equity_quotes", []):
        if not isinstance(row, Mapping):
            continue
        body = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        if str(body.get("symbol", "")).upper() == symbol.upper():
            return body
    return None


def _underlying_trade(quote: Mapping[str, Any]) -> tuple[float | None, str | None]:
    """Return Robinhood's newest priced equity trade and its matching venue timestamp."""

    candidates: list[tuple[datetime, float, str]] = []
    fallback_timestamp = quote.get("updated_at")
    for price_field, timestamp_field in (
        ("last_trade_price", "venue_last_trade_time"),
        ("last_non_reg_trade_price", "venue_last_non_reg_trade_time"),
    ):
        price = _number(quote.get(price_field))
        raw_timestamp = quote.get(timestamp_field) or fallback_timestamp
        parsed = _timestamp(raw_timestamp)
        if price is not None and price > 0 and parsed is not None:
            candidates.append((parsed, price, str(raw_timestamp)))
    if not candidates:
        return None, None
    _, price, raw_timestamp = max(candidates, key=lambda item: item[0])
    return price, raw_timestamp


def _position_map(snapshot: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for row in snapshot.get("positions", []):
        if not isinstance(row, Mapping):
            continue
        contract_id = row.get("option_id") or row.get("instrument_id")
        quantity = _number(row.get("quantity"))
        if isinstance(contract_id, str) and quantity is not None and quantity > 0:
            result[contract_id] = row
    return result


def _decision_json(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    candidates = [text]
    if "{" in text and "}" in text:
        candidates.append(text[text.find("{") : text.rfind("}") + 1])
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, Mapping):
            return dict(parsed)
    return None


def _qualified_candidates(event: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    discovery = event.get("option_discovery")
    if isinstance(discovery, Mapping) and isinstance(discovery.get("qualified_candidates"), list):
        return [item for item in discovery["qualified_candidates"] if isinstance(item, Mapping)]
    return []


def _entry_time_allowed(now: datetime, config: TradingConfig, style: str) -> bool:
    return entry_allowed(now, config, style)


def _day_deadline(now: datetime, config: TradingConfig) -> str:
    return day_deadline(now, int(config.get("DAY_TRADE_EXIT_MINUTES_BEFORE_CLOSE")))


def _save_positions_memory(
    project_root: Path, positions: list[Mapping[str, Any]], now: datetime
) -> None:
    lines = [
        "# Open Position Memory",
        "",
        "This file is the persistent explanation of every open position.",
        "",
        "## Current reconciliation",
        "",
        f"- Last reconciled: {now.astimezone(EASTERN).isoformat(timespec='minutes')}",
        "- Robinhood Agentic account: "
        + (
            f"{len(positions)} managed live option position(s)."
            if positions
            else "no open option position."
        ),
        "",
    ]
    for position in positions:
        lines.extend(
            [
                f"### {position.get('symbol')} {position.get('expiration')} "
                f"{position.get('strike')} {position.get('option_type')}",
                "",
                f"- Robinhood contract identifier: {position.get('contract_identifier')}",
                f"- Quantity: {position.get('quantity')}",
                f"- Entry date/time: {position.get('entry_at')}",
                f"- Entry fill: {position.get('entry_price')}",
                "- Current status: OPEN",
                f"- Underlying at entry: {position.get('entry_underlying')}",
                f"- Premium at risk: {position.get('entry_cost')}",
                f"- Intended holding period: {position.get('hold_deadline')}",
                f"- Trade style: {position.get('trade_style')}",
                f"- High-water option mark: {position.get('high_water_bid')}",
                f"- Thesis: {position.get('thesis')}",
                f"- Catalyst(s): {position.get('reason')}",
                "- Technical/factor evidence: Recorded in scheduled decision log",
                "- Options-flow evidence: Recorded in scheduled decision log",
                "- News/social evidence: Recorded in scheduled decision log",
                "- Contract-selection rationale: Passed fresh liquidity, Greek, DTE, "
                "and risk gates",
                f"- Invalidation: {position.get('invalidation')}",
                f"- Profit-taking / exit logic: Software stop {position.get('stop_price')}; "
                f"target {position.get('take_profit_price')}",
                f"- Time stop: {position.get('hold_deadline')}",
                "- Protective order ID: SOFTWARE_MANAGED",
                "- Protective order state: NOT REQUIRED",
                f"- Earnings date/time: {position.get('earnings_event')}",
                "- Earnings decision: NOT APPLICABLE",
                "- Earnings risk notes: Earnings holds disabled",
                f"- Last reviewed: {now.astimezone(UTC).isoformat()}",
                "- Current thesis status: INTACT",
                "- Next required action: Python polls bid every two minutes",
                "",
            ]
        )
    _atomic_text_write(project_root / "state" / "POSITIONS.md", "\n".join(lines))


def _update_daily_state(
    project_root: Path,
    state: Mapping[str, Any],
    snapshot: Mapping[str, Any],
) -> None:
    path = project_root / "state" / "DAILY_STATE.md"
    if not path.exists():
        return
    portfolio = snapshot.get("portfolio") if isinstance(snapshot.get("portfolio"), Mapping) else {}
    buying = portfolio.get("buying_power")
    buying_power = _number(buying.get("buying_power") if isinstance(buying, Mapping) else buying)
    account_value = _number(portfolio.get("total_value"))
    day = state.get("day") if isinstance(state.get("day"), Mapping) else {}
    positions = _state_positions(state)
    unrealized = sum(
        (float(position.get("last_bid", 0)) - float(position.get("entry_price", 0)))
        * int(position.get("quantity", 1))
        * 100
        for position in positions
    )
    open_risk = sum(float(position.get("entry_cost", 0)) for position in positions)
    values = {
        "- Robinhood account value:": f"${float(account_value or 0):.2f} (Agentic account)",
        "- Buying power:": f"${float(buying_power or 0):.2f}",
        "- Realized P&L today:": f"${float(day.get('realized_pnl', 0)):.2f}",
        "- Unrealized P&L:": f"${unrealized:.2f}",
        "- Open premium at risk:": f"${open_risk:.2f}",
        "- Open positions:": str(len(positions)),
        "- Trades today:": str(int(day.get("new_positions", 0))),
        "- New-risk status:": "LIVE UNATTENDED — hard deterministic gates active",
    }
    updated: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        replacement = next(
            (value for prefix, value in values.items() if line.startswith(prefix)),
            None,
        )
        if replacement is None:
            updated.append(line)
            continue
        prefix = next(prefix for prefix in values if line.startswith(prefix))
        updated.append(f"{prefix} {replacement}")
    _atomic_text_write(path, "\n".join(updated).rstrip() + "\n")


def _record_live_decision(
    project_root: Path,
    *,
    decision: Mapping[str, Any],
    result: Mapping[str, Any],
    now: datetime,
) -> None:
    subject = (
        decision.get("candidate_id") or decision.get("position_id") or decision.get("order_id")
    )
    _append_markdown(
        project_root / "journal" / "DECISIONS.md",
        "\n".join(
            [
                f"### LIVE-{now.strftime('%Y%m%dT%H%M%S')}-{decision.get('action')}",
                "",
                f"- Timestamp: {now.astimezone(UTC).isoformat()}",
                f"- Symbol/contract/order: {subject}",
                f"- Final decision: {decision.get('action')}",
                f"- Why: {decision.get('reason')}",
                f"- Thesis: {decision.get('thesis')}",
                f"- Invalidation: {decision.get('invalidation')}",
                f"- Execution result: {result.get('status')}",
                "- Risk boundary: One contract; Robinhood review; no automatic cancellation; "
                "software-managed stop/target/time exit.",
            ]
        ),
    )


def _record_trade_event(
    project_root: Path,
    *,
    event: str,
    position: Mapping[str, Any],
    now: datetime,
) -> None:
    is_exit = event == "LIVE_EXIT_FILLED"
    exit_price = "$" + format(float(position.get("exit_price", 0)), ".4f") if is_exit else ""
    realized_pnl = "$" + format(float(position.get("realized_pnl", 0)), ".2f") if is_exit else ""
    _append_markdown(
        project_root / "journal" / "TRADES.md",
        "\n".join(
            [
                f"### {position.get('position_id')}-{event}",
                "",
                f"- Open date/time: {position.get('entry_at')}",
                f"- Close date/time: {position.get('exit_at') if is_exit else ''}",
                f"- Symbol: {position.get('symbol')}",
                f"- Contract: {position.get('contract_identifier')}",
                f"- Direction: Long {position.get('option_type')}",
                f"- Quantity: {position.get('quantity')}",
                f"- Entry: ${float(position.get('entry_price', 0)):.4f}",
                f"- Exit: {exit_price}",
                f"- Realized P&L: {realized_pnl}",
                f"- Original thesis: {position.get('thesis')}",
                f"- Exit reason: {position.get('exit_reason') if is_exit else ''}",
                "- Risk-engine decision: ALLOWED; event recorded "
                f"{now.astimezone(UTC).isoformat()}",
            ]
        ),
    )


def _entry_order_request(candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "legs": [
            {
                "option_id": str(candidate["candidate_id"]),
                "side": "buy",
                "position_effect": "open",
                "ratio_quantity": 1,
            }
        ],
        "type": "limit",
        "quantity": "1",
        "price": f"{float(candidate['ask']):.2f}",
        "time_in_force": "gfd",
        "market_hours": "regular_hours",
        "chain_symbol": str(candidate["symbol"]),
        "underlying_type": "equity",
    }


def _exit_order_request(position: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "legs": [
            {
                "option_id": str(position["contract_identifier"]),
                "side": "sell",
                "position_effect": "close",
                "ratio_quantity": 1,
            }
        ],
        "type": "market",
        "quantity": str(int(position.get("quantity", 1))),
        "time_in_force": "gfd",
        "market_hours": "regular_hours",
        "chain_symbol": str(position["symbol"]),
        "underlying_type": "equity",
    }


async def _review_and_submit(
    request: Mapping[str, Any],
    *,
    state: dict[str, Any],
    state_path: Path,
    purpose: str,
    context: Mapping[str, Any],
    now: datetime,
    reviewer: OrderCaller,
    placer: OrderCaller,
    pre_submit_check: Callable[[], bool] | None = None,
) -> dict[str, Any]:
    executable_request = placement_arguments(request)
    review = await reviewer(request)
    assessment = _review_assessment(review)
    matches, match_reasons = _review_matches_request(review, request)
    if not matches:
        assessment = {
            **assessment,
            "allowed": False,
            "reasons": [*assessment["reasons"], *match_reasons],
        }
    if not assessment["allowed"]:
        return {
            "status": "BLOCKED",
            "reason": "robinhood_order_review_blocked",
            "purpose": purpose,
            "order_type": request.get("type"),
            "contract_identifier": (request.get("legs") or [{}])[0].get("option_id"),
            "symbol": request.get("chain_symbol"),
            "review": assessment,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    if pre_submit_check is not None and not pre_submit_check():
        return {
            "status": "BLOCKED",
            "reason": "live_pre_submit_state_expired_or_changed",
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    ref_id = str(uuid.uuid4())
    pending = {
        "purpose": purpose,
        "status": "SUBMITTING",
        "ref_id": ref_id,
        "order_id": None,
        "request": executable_request,
        "review_request": dict(request),
        "review": assessment,
        "context": dict(context),
        "created_at": now.astimezone(UTC).isoformat(),
    }
    state["pending_orders"] = [*_state_pending_orders(state), pending]
    state["updated_at"] = now.astimezone(UTC).isoformat()
    _save_state(state_path, state)
    try:
        placement = await placer({**executable_request, "ref_id": ref_id})
    except asyncio.CancelledError:
        pending["status"] = "SUBMISSION_UNKNOWN"
        pending["last_error"] = "submission_cancelled_outcome_unknown"
        _save_state(state_path, state)
        raise
    except Exception as exc:
        details = exception_summary(exc)
        if rejected_before_submission(exc):
            _archive_rejected_submission(state_path, state, pending, details, now)
            return {
                "status": "BLOCKED",
                "reason": "order_request_rejected_before_submission",
                "error": details,
                "submission_state": "NOT_SUBMITTED",
                "orders_placed": 0,
                "orders_cancelled": 0,
            }
        pending["status"] = "SUBMISSION_UNKNOWN"
        pending["last_error"] = details
        _save_state(state_path, state)
        return {
            "status": "ATTENTION",
            "reason": "order_submission_outcome_unknown",
            "error": details,
            "submission_state": "UNKNOWN",
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    pending["order_id"] = _order_id(placement)
    if not pending["order_id"]:
        pending["status"] = "SUBMISSION_UNKNOWN"
        pending["placement"] = placement
        _save_state(state_path, state)
        return {
            "status": "ATTENTION",
            "reason": "order_submission_missing_broker_id",
            "submission_state": "UNKNOWN",
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    pending["status"] = "SUBMITTED"
    pending["placement"] = placement
    state["updated_at"] = datetime.now(UTC).isoformat()
    write = _save_state(state_path, state)
    return {
        "status": "SUBMITTED",
        "purpose": purpose,
        "order_id": pending["order_id"],
        "review": assessment,
        "placement": placement,
        "persistent_write": write,
        "orders_placed": 1,
        "orders_cancelled": 0,
    }


def _archive_rejected_submission(
    state_path: Path,
    state: dict[str, Any],
    pending: Mapping[str, Any],
    details: str,
    now: datetime,
) -> None:
    """Archive a definite pre-submission rejection, never an ambiguous failure."""
    record = {
        **pending,
        "status": "REJECTED_BEFORE_SUBMISSION",
        "last_error": details,
        "resolved_at": now.astimezone(UTC).isoformat(),
    }
    state["pending_orders"] = [
        row for row in _state_pending_orders(state) if row.get("ref_id") != pending.get("ref_id")
    ]
    state["rejected_submissions"] = [*state.get("rejected_submissions", []), record][-20:]
    state["updated_at"] = now.astimezone(UTC).isoformat()
    _save_state(state_path, state)
    _append_jsonl(
        state_path.with_name("EVENTS.jsonl"),
        {"event": "LIVE_ORDER_NOT_SUBMITTED", "timestamp": now.isoformat(), "record": record},
    )


async def _apply_model_exit(
    decision: Mapping[str, Any],
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime,
    snapshot_fetcher: SnapshotFetcher,
    reviewer: OrderCaller,
    placer: OrderCaller,
) -> dict[str, Any]:
    snapshot = await snapshot_fetcher()
    if snapshot.get("status") != "OK" or not _fresh(snapshot.get("as_of"), now=now):
        return {
            "status": "BLOCKED",
            "reason": "model_exit_snapshot_invalid_or_stale",
            "orders_placed": 0,
        }
    portfolio = snapshot.get("portfolio") if isinstance(snapshot.get("portfolio"), Mapping) else {}
    account_value = _number(portfolio.get("total_value"))
    if account_value is None or account_value <= 0:
        return {
            "status": "BLOCKED",
            "reason": "model_exit_account_value_invalid",
            "orders_placed": 0,
        }
    state_path = ledger_directory(project_root, config, "live") / "STATE.json"
    events_path = ledger_directory(project_root, config, "live") / "EVENTS.jsonl"
    with _exclusive_lock(state_path):
        state = _load_state(state_path, account_value=account_value, now=now)
        positions = _state_positions(state)
        requested_position_id = str(decision.get("position_id", ""))
        position = next(
            (
                item
                for item in positions
                if str(item.get("position_id", "")) == requested_position_id
            ),
            None,
        )
        if position is None or any(
            str(position.get("contract_identifier", "")) in _order_contracts(pending)
            for pending in _state_pending_orders(state)
        ):
            return {
                "status": "BLOCKED",
                "reason": "model_exit_local_position_or_order_invalid",
                "orders_placed": 0,
            }
        contract_id = str(position.get("contract_identifier", ""))
        broker_positions = _position_map(snapshot)
        quote = _quote_map(snapshot).get(contract_id)
        bid = _number(quote.get("bid_price")) if quote else None
        if (
            contract_id not in broker_positions
            or any(
                not _order_contracts(order) or contract_id in _order_contracts(order)
                for order in snapshot.get("open_option_orders", [])
                if isinstance(order, Mapping)
            )
            or quote is None
            or bid is None
            or bid <= 0
            or not _fresh(quote.get("updated_at"), now=now)
        ):
            return {
                "status": "BLOCKED",
                "reason": "model_exit_broker_reconciliation_or_quote_failed",
                "orders_placed": 0,
            }
        result = await _review_and_submit(
            _exit_order_request(position),
            state=state,
            state_path=state_path,
            purpose="EXIT",
            context={
                "exit_reason": f"MODEL_EXIT: {decision.get('reason')}",
                "position_id": position.get("position_id"),
            },
            now=now,
            reviewer=reviewer,
            placer=placer,
        )
        _append_jsonl(
            events_path,
            {
                "event": "LIVE_MODEL_EXIT_REVIEW_OR_SUBMISSION",
                "timestamp": now.astimezone(UTC).isoformat(),
                "result": result,
            },
        )
        _record_live_decision(
            project_root,
            decision=decision,
            result=result,
            now=now,
        )
        result["decision"] = dict(decision)
        result["wake_codex"] = result.get("status") == "BLOCKED"
        return result


async def apply_live_decision(
    routing: Mapping[str, Any],
    event: Mapping[str, Any],
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime | None = None,
    snapshot_fetcher: SnapshotFetcher = fetch_snapshot,
    quote_fetcher: QuoteFetcher = fetch_quote_refresh,
    reviewer: OrderCaller = review_live_option_order,
    placer: OrderCaller = place_live_option_order,
) -> dict[str, Any]:
    """Apply the completed model BUY/EXIT or surface a manual cancellation recommendation."""

    current = now or datetime.now(UTC)
    blockers = config.live_blockers()
    if blockers:
        return {
            "status": "BLOCKED",
            "reason": "live_configuration_blocked",
            "blockers": blockers,
            "orders_placed": 0,
        }
    route = routing.get("decision") or routing.get("sol")
    if not isinstance(route, Mapping) or route.get("status") != "COMPLETED":
        return {"status": "SKIPPED", "reason": "no_completed_model_decision", "orders_placed": 0}
    decision = _decision_json(route.get("output"))
    if decision is None:
        return {"status": "BLOCKED", "reason": "model_decision_not_json", "orders_placed": 0}
    if config.get("OPTIONS_LUNA_VETO_ENABLED", True) is False:
        from tools.live_fast_monitor import entry_monitor_ready

        if config.get("LIVE_NEW_ENTRIES_ENABLED") is not True:
            return {"status": "BLOCKED", "reason": "live_new_entries_locked", "orders_placed": 0}
        if not entry_monitor_ready(project_root, config, current):
            return {
                "status": "BLOCKED",
                "reason": "live_position_monitor_not_ready",
                "orders_placed": 0,
            }
        if config.options_blockers():
            return {
                "status": "BLOCKED",
                "reason": "deterministic_options_configuration_blocked",
                "blockers": config.options_blockers(),
                "orders_placed": 0,
            }
        packet = routing.get("decision_packet") or {}
        if (
            route.get("model_bypassed") is not True
            or decision.get("action") != "BUY"
            or packet.get("python_gate", {}).get("status") != "QUALIFIED"
            or not _fresh(packet.get("as_of"), now=current)
        ):
            return {
                "status": "BLOCKED",
                "reason": "deterministic_entry_packet_invalid",
                "orders_placed": 0,
            }
    if decision.get("action") == "CANCEL_ENTRY":
        state_path = ledger_directory(project_root, config, "live") / "STATE.json"
        try:
            with _exclusive_lock(state_path):
                state = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return {
                "status": "BLOCKED",
                "reason": "manual_cancel_live_state_unavailable",
                "orders_placed": 0,
                "orders_cancelled": 0,
            }
        requested_order_id = str(decision.get("order_id", ""))
        pending = next(
            (
                item
                for item in _state_pending_orders(state)
                if str(item.get("order_id", "")) == requested_order_id
            ),
            None,
        )
        if (
            pending is None
            or pending.get("purpose") != "ENTRY"
            or not requested_order_id
            or requested_order_id != str(pending.get("order_id", ""))
        ):
            return {
                "status": "BLOCKED",
                "reason": "manual_cancel_pending_entry_mismatch",
                "orders_placed": 0,
                "orders_cancelled": 0,
            }
        context = pending.get("context") if isinstance(pending.get("context"), Mapping) else {}
        candidate = (
            context.get("candidate") if isinstance(context.get("candidate"), Mapping) else {}
        )
        result = {
            "status": "ATTENTION",
            "manual_action": "CANCEL_ORDER",
            "order_id": requested_order_id,
            "symbol": candidate.get("symbol"),
            "reason": decision.get("reason") or "pending entry thesis materially weakened",
            "decision": decision,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
        _record_live_decision(project_root, decision=decision, result=result, now=current)
        return result
    if decision.get("action") == "EXIT":
        return await _apply_model_exit(
            decision,
            config,
            project_root=project_root,
            now=current,
            snapshot_fetcher=snapshot_fetcher,
            reviewer=reviewer,
            placer=placer,
        )
    if decision.get("action") != "BUY":
        return {
            "status": "RECORDED_NO_ENTRY",
            "reason": f"model_action_{decision.get('action')}",
            "decision": decision,
            "orders_placed": 0,
        }
    candidate_id = str(decision.get("candidate_id", ""))
    candidate = next(
        (
            item
            for item in _qualified_candidates(event)
            if str(item.get("candidate_id", "")) == candidate_id
        ),
        None,
    )
    if candidate is None:
        return {"status": "BLOCKED", "reason": "candidate_not_qualified", "orders_placed": 0}
    style = str(decision.get("trade_style", "")).upper()
    if style not in {"DAY", "SWING"} or not _entry_time_allowed(current, config, style):
        return {
            "status": "BLOCKED",
            "reason": "trade_style_or_entry_time_invalid",
            "orders_placed": 0,
        }
    symbol = str(candidate.get("symbol", ""))
    try:
        refresh = await quote_fetcher([{"option_id": candidate_id, "symbol": symbol}])
    except Exception as exc:  # fail closed while preserving a safe operational diagnosis
        return {
            "status": "BLOCKED",
            "reason": "fresh_entry_quote_refresh_error",
            "blockers": [f"quote_refresh_exception:{type(exc).__name__}"],
            "candidate_id": candidate_id,
            "symbol": symbol,
            "option_symbol": candidate.get("option_symbol"),
            "orders_placed": 0,
        }
    quote = _quote_map(refresh).get(candidate_id)
    current = now or datetime.now(UTC)
    underlying_quote = _underlying_quote(refresh, symbol)
    underlying_price, underlying_updated_at = (
        _underlying_trade(underlying_quote) if underlying_quote is not None else (None, None)
    )
    refresh_blockers: list[str] = []
    if refresh.get("status") != "OK":
        refresh_blockers.append("quote_refresh_status_not_ok")
    if not _fresh(refresh.get("as_of"), now=current):
        refresh_blockers.append("quote_refresh_snapshot_stale")
    if quote is None:
        refresh_blockers.append("option_quote_missing")
    if underlying_quote is None:
        refresh_blockers.append("underlying_quote_missing")
    if underlying_price is None:
        refresh_blockers.append("underlying_trade_price_missing")
    if underlying_updated_at is None:
        refresh_blockers.append("underlying_trade_timestamp_missing")
    elif not _fresh(underlying_updated_at, now=current):
        refresh_blockers.append("underlying_trade_timestamp_stale")
    if refresh_blockers:
        return {
            "status": "BLOCKED",
            "reason": "fresh_entry_option_or_underlying_quote_missing",
            "blockers": refresh_blockers,
            "candidate_id": candidate_id,
            "symbol": symbol,
            "option_symbol": candidate.get("option_symbol"),
            "quote_refresh_as_of": refresh.get("as_of"),
            "orders_placed": 0,
        }
    refreshed = annotate_option_styles(
        {
            **candidate,
            "underlying_price": underlying_price,
            "underlying_quote_updated_at": underlying_updated_at,
            "bid": _number(quote.get("bid_price")),
            "ask": _number(quote.get("ask_price")),
            "quote_updated_at": quote.get("updated_at"),
            "quote_is_fresh": _fresh(quote.get("updated_at"), now=current, maximum_age_seconds=20),
            "option_volume": _number(quote.get("volume")),
            "option_open_interest": _number(quote.get("open_interest")),
            "implied_volatility": _number(quote.get("implied_volatility")),
            "delta": _number(quote.get("delta")),
            "gamma": _number(quote.get("gamma")),
            "theta": _number(quote.get("theta")),
            "vega": _number(quote.get("vega")),
            "rho": _number(quote.get("rho")),
        },
        config,
    )
    bid = _number(refreshed.get("bid"))
    ask = _number(refreshed.get("ask"))
    style_assessment = assess_option_styles(refreshed, config)
    if (
        bid is None
        or ask is None
        or ask <= 0
        or ask < bid
        or refreshed.get("quote_is_fresh") is not True
        or style not in style_assessment["eligible_styles"]
    ):
        return {"status": "BLOCKED", "reason": "fresh_contract_gate_failed", "orders_placed": 0}
    if config.get("OPTIONS_LUNA_VETO_ENABLED", True) is False:
        fresh_gate = evaluate_contract(refreshed, config)
        if fresh_gate.status != "QUALIFIED":
            return {
                "status": "BLOCKED",
                "reason": "fresh_contract_gate_failed",
                "gate": fresh_gate.as_dict(),
                "orders_placed": 0,
            }
        config_path = project_root / "CONFIG.md"
        if config_path.exists() and load_config(config_path).values != config.values:
            return {
                "status": "BLOCKED",
                "reason": "configuration_changed_before_live_entry",
                "orders_placed": 0,
            }
    reward_risk = net_reward_risk(
        {**refreshed, "ask": float(_entry_order_request(refreshed)["price"])}, config
    )
    if reward_risk["status"] != "QUALIFIED":
        result = {
            "status": "BLOCKED",
            "reason": reward_risk["reasons"][0],
            "net_reward_risk": reward_risk,
            "orders_placed": 0,
        }
        _append_jsonl(
            ledger_directory(project_root, config, "live") / "EVENTS.jsonl",
            {
                "event": "LIVE_ENTRY_REJECTED",
                "timestamp": current.isoformat(),
                "candidate_id": candidate_id,
                **result,
            },
        )
        return result
    snapshot = await snapshot_fetcher()
    current = now or datetime.now(UTC)
    if not _fresh(quote.get("updated_at"), now=current) or not _entry_time_allowed(
        current, config, style
    ):
        return {"status": "BLOCKED", "reason": "entry_quote_or_time_expired", "orders_placed": 0}
    if (
        snapshot.get("status") != "OK"
        or not _fresh(snapshot.get("as_of"), now=current)
        or snapshot.get("open_option_orders")
    ):
        return {"status": "BLOCKED", "reason": "broker_not_flat", "orders_placed": 0}
    state_path = ledger_directory(project_root, config, "live") / "STATE.json"
    events_path = ledger_directory(project_root, config, "live") / "EVENTS.jsonl"
    metrics_seed = _portfolio_metrics(
        snapshot,
        _load_state(
            state_path,
            account_value=float(_number(snapshot.get("portfolio", {}).get("total_value")) or 0),
            now=current,
            config=config,
        ),
    )
    reviewed_order = None

    async def completed_review(request):
        return reviewed_order

    # Broker review is read-only and must not hold the shared ledger lock: the
    # resident monitor needs that lock to reconcile and publish healthy checks.
    # Validate once before review, then reload/recheck every ledger/risk gate
    # under the lock before persisting and submitting the reviewed order.
    for phase in ("review", "submit"):
        with _exclusive_lock(state_path):
            state = _load_state(
                state_path,
                account_value=float(metrics_seed["account_value"]),
                now=current,
                config=config,
            )
            positions = _state_positions(state)
            broker_positions = _position_map(snapshot)
            if (
                config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
                and state["day"].get("green_lock_active") is True
            ):
                state["day"]["skipped_entry_count"] += 1
                state["updated_at"] = current.isoformat()
                _save_state(state_path, state)
                result = {
                    "status": "BLOCKED", "reason": "daily_green_lock_active", "orders_placed": 0
                }
                _append_jsonl(
                    events_path,
                    {
                        "event": "LIVE_ENTRY_SKIPPED",
                        "timestamp": current.isoformat(),
                        "strategy_epoch": state.get("strategy_epoch"),
                        "candidate_id": candidate_id,
                        "day": dict(state["day"]),
                        **result,
                    },
                )
                return result
            local_contracts = {
                str(position.get("contract_identifier", "")) for position in positions
            }
            if _state_pending_orders(state):
                return {
                    "status": "BLOCKED",
                    "reason": "local_live_order_pending",
                    "orders_placed": 0,
                }
            if set(broker_positions) != local_contracts:
                return {
                    "status": "BLOCKED",
                    "reason": "broker_local_position_mismatch",
                    "orders_placed": 0,
                }
            if any(
                _number(broker_positions[position["contract_identifier"]].get("quantity"))
                != _number(position.get("quantity"))
                for position in positions
            ):
                return {
                    "status": "BLOCKED",
                    "reason": "broker_local_position_quantity_mismatch",
                    "orders_placed": 0,
                }
            if candidate_id in local_contracts:
                return {
                    "status": "BLOCKED",
                    "reason": "duplicate_contract_position",
                    "orders_placed": 0,
                }
            try:
                held_symbols = held_option_symbols(positions)
                duplicate_symbol = normalized_symbol(refreshed.get("symbol")) in held_symbols
            except ValueError as exc:
                return {"status": "BLOCKED", "reason": str(exc), "orders_placed": 0}
            if duplicate_symbol:
                return {
                    "status": "BLOCKED",
                    "reason": "underlying_already_held",
                    "symbol": refreshed.get("symbol"),
                    "orders_placed": 0,
                }
            holds = decision.get("holds_through_earnings")
            if not isinstance(holds, bool):
                return {
                    "status": "BLOCKED",
                    "reason": "earnings_assessment_missing",
                    "orders_placed": 0,
                }
            risk = evaluate_risk(
                _portfolio_metrics(snapshot, state),
                {
                    "symbol": refreshed.get("symbol"),
                    "premium_at_risk": ask * 100,
                    "quantity": 1,
                    "holds_through_earnings": holds,
                    "earnings_decision": "HOLD THROUGH EARNINGS" if holds else "DO NOT HOLD",
                    "is_averaging_down": False,
                    "protective_stop_planned": True,
                },
                config,
            )
            if risk.status != "ALLOWED":
                return {
                    "status": "BLOCKED",
                    "reason": "live_risk_gate_blocked",
                    "risk": risk.as_dict(),
                    "orders_placed": 0,
                }
            hold_deadline = (
                _day_deadline(current, config)
                if style == "DAY"
                else str(decision.get("hold_deadline", ""))
            )
            if style == "SWING" and (
                _timestamp(hold_deadline) or current
            ) <= current.astimezone(UTC):
                return {"status": "BLOCKED", "reason": "swing_deadline_invalid", "orders_placed": 0}
            if config.get("OPTIONS_LUNA_VETO_ENABLED", True) is False:
                submit_time = now or datetime.now(UTC)
                if not _fresh(
                    routing["decision_packet"].get("as_of"), now=submit_time
                ) or not _entry_time_allowed(submit_time, config, style):
                    return {
                        "status": "BLOCKED",
                        "reason": "deterministic_entry_packet_expired",
                        "orders_placed": 0,
                    }
            context = {
                "candidate": refreshed,
                "decision": decision,
                "hold_deadline": hold_deadline,
                "risk": risk.as_dict(),
                "net_reward_risk": reward_risk,
                **(
                    {
                        "entry_cost_estimate": paper_side_cost(config),
                        "exit_cost_estimate": paper_side_cost(config),
                        "strategy_epoch": strategy_epoch(config),
                    }
                    if config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
                    else {}
                ),
            }
            if phase == "submit":
                result = await _review_and_submit(
                    _entry_order_request(refreshed),
                    state=state,
                    state_path=state_path,
                    purpose="ENTRY",
                    context=context,
                    now=current,
                    reviewer=completed_review,
                    placer=placer,
                    pre_submit_check=lambda: (
                        _fresh(
                            quote.get("updated_at"),
                            now=now or datetime.now(UTC),
                            maximum_age_seconds=20,
                        )
                        and _fresh(
                            underlying_updated_at,
                            now=now or datetime.now(UTC),
                            maximum_age_seconds=20,
                        )
                        and _fresh(
                            snapshot.get("as_of"),
                            now=now or datetime.now(UTC),
                            maximum_age_seconds=20,
                        )
                        and _entry_time_allowed(now or datetime.now(UTC), config, style)
                        and (
                            not (project_root / "CONFIG.md").exists()
                            or load_config(project_root / "CONFIG.md").values == config.values
                        )
                        and (
                            config.get("OPTIONS_LUNA_VETO_ENABLED", True) is not False
                            or entry_monitor_ready(project_root, config, now or datetime.now(UTC))
                        )
                    ),
                )
                _append_jsonl(
                    events_path,
                    {
                        "event": "LIVE_ENTRY_REVIEW_OR_SUBMISSION",
                        "timestamp": current.astimezone(UTC).isoformat(),
                        "result": result,
                    },
                )
                result["decision"] = decision
                result["risk"] = risk.as_dict()
                result["net_reward_risk"] = reward_risk
                _record_live_decision(
                    project_root,
                    decision=decision,
                    result=result,
                    now=current,
                )
                return result
        reviewed_order = await reviewer(_entry_order_request(refreshed))
        current = now or datetime.now(UTC)


def _open_order_state(order_status: Mapping[str, Any]) -> tuple[str | None, float | None]:
    rows = _order_rows(order_status)
    if not rows:
        return None, None
    state = str(rows[0].get("state", "")).lower() or None
    return state, _order_fill_price(rows[0])


def _build_live_position(
    pending: Mapping[str, Any], *, fill_price: float, now: datetime, config: TradingConfig
) -> dict[str, Any]:
    context = pending.get("context") if isinstance(pending.get("context"), Mapping) else {}
    candidate = context.get("candidate") if isinstance(context.get("candidate"), Mapping) else {}
    decision = context.get("decision") if isinstance(context.get("decision"), Mapping) else {}
    return {
        "position_id": (
            f"live-{now.strftime('%Y%m%dT%H%M%S')}-{str(candidate.get('candidate_id'))[:8]}"
        ),
        "contract_identifier": str(candidate.get("candidate_id")),
        "symbol": str(candidate.get("symbol", "")).upper(),
        "option_symbol": candidate.get("option_symbol"),
        "expiration": candidate.get("expiration"),
        "strike": candidate.get("strike"),
        "option_type": candidate.get("option_type"),
        "quantity": 1,
        "entry_order_id": pending.get("order_id"),
        "entry_at": now.astimezone(UTC).isoformat(),
        "entry_price": round(fill_price, 4),
        "entry_cost": round(fill_price * 100, 2),
        **{
            key: context[key]
            for key in (
                "entry_cost_estimate",
                "exit_cost_estimate",
                "strategy_epoch",
                "net_reward_risk",
            )
            if key in context
        },
        "entry_underlying": candidate.get("underlying_price"),
        "last_bid": round(fill_price, 4),
        "high_water_bid": round(fill_price, 4),
        "stop_price": round(fill_price * (1 - float(config.get("STOP_LOSS_PERCENT")) / 100), 4),
        "take_profit_price": round(
            fill_price * (1 + float(config.get("TAKE_PROFIT_PERCENT")) / 100), 4
        ),
        "trade_style": decision.get("trade_style"),
        "hold_deadline": context.get("hold_deadline"),
        "thesis": decision.get("thesis"),
        "invalidation": decision.get("invalidation"),
        "reason": decision.get("reason"),
        "earnings_event": decision.get("earnings_event"),
        "entry_greeks": candidate.get("greek_metrics"),
        "status": "OPEN",
    }


def _exit_trigger(position: Mapping[str, Any], *, bid: float, now: datetime) -> str | None:
    if bid <= float(position["stop_price"]):
        return "STOP_LOSS"
    if bid >= float(position["take_profit_price"]):
        return "TAKE_PROFIT"
    deadline = _timestamp(position.get("hold_deadline"))
    if deadline is None:
        return "INVALID_HOLD_DEADLINE"
    if now.astimezone(UTC) >= deadline:
        return "DAY_TRADE_TIME_EXIT" if position.get("trade_style") == "DAY" else "SWING_TIME_EXIT"
    return None


async def monitor_live_portfolio(
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime | None = None,
    snapshot_fetcher: SnapshotFetcher = fetch_snapshot,
    reviewer: OrderCaller = review_live_option_order,
    placer: OrderCaller = place_live_option_order,
    order_status_fetcher: OrderStatusFetcher = fetch_option_order_status,
    quote_max_age_seconds: int = 20,
    snapshot_max_age_seconds: int = 20,
    retry_snapshot: bool = True,
) -> dict[str, Any]:
    """Reconcile fills and submit deterministic exits; never cancel or replace an order."""

    current = now or datetime.now(UTC)
    blockers = config.live_blockers()
    if blockers:
        return {
            "status": "DISABLED" if not config.live_execution_enabled else "ATTENTION",
            "reason": "live_configuration_blocked",
            "blockers": blockers,
            "wake_codex": config.live_execution_enabled,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    try:
        snapshot = await snapshot_fetcher()
    except Exception as first_error:
        if snapshot_fetcher is fetch_snapshot or not retry_snapshot:
            # The production reader already performs its bounded transport retry.
            raise
        # Opening a fresh read-only MCP session is safe and absorbs isolated stream shutdowns.
        try:
            snapshot = await snapshot_fetcher()
        except Exception as retry_error:
            raise RuntimeError(
                "live_snapshot_fetch_failed_after_retry: "
                f"first={type(first_error).__name__}; retry={type(retry_error).__name__}"
            ) from retry_error
    current = now or datetime.now(UTC)
    if snapshot.get("status") != "OK" or not _fresh(
        snapshot.get("as_of"), now=current, maximum_age_seconds=snapshot_max_age_seconds
    ):
        return {
            "status": "ATTENTION",
            "reason": "live_snapshot_invalid_or_stale",
            "wake_codex": True,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    account_value = _number(snapshot.get("portfolio", {}).get("total_value"))
    if account_value is None or account_value <= 0:
        return {
            "status": "ATTENTION",
            "reason": "live_account_value_invalid",
            "wake_codex": True,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    state_path = ledger_directory(project_root, config, "live") / "STATE.json"
    events_path = ledger_directory(project_root, config, "live") / "EVENTS.jsonl"
    with _exclusive_lock(state_path):
        state = _load_state(state_path, account_value=account_value, now=current, config=config)
        activities: list[dict[str, Any]] = []
        just_opened: set[str] = set()
        just_closed: set[str] = set()
        pending_orders = _state_pending_orders(state)
        state["pending_orders"] = pending_orders

        # Working entries must never prevent risk exits on other contracts.
        for pending in list(pending_orders):
            if not pending.get("order_id"):
                # Missing ID does not prove rejection. Never blindly replay an old order after
                # a payload fix. Preserve the original ref_id until its outcome is reconciled.
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "submission_outcome_unknown_reconciliation_required",
                        "error": pending.get("last_error"),
                        "ref_id": pending.get("ref_id"),
                        "submission_state": "UNKNOWN",
                        "orders_placed": 0,
                    }
                )
                continue
            try:
                status_payload = await order_status_fetcher(str(pending["order_id"]))
                order_state, fill_price = _open_order_state(status_payload)
            except Exception as exc:
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": f"pending_order_status_failed: {exception_summary(exc)}",
                        "order_id": pending.get("order_id"),
                        "orders_placed": 0,
                    }
                )
                continue
            rows = _order_rows(status_payload)
            executed = _order_fill_quantity(rows[0]) if rows else None
            requested = _number(pending.get("request", {}).get("quantity", 1))
            # Single-leg, one-contract orders cannot have a valid fractional option fill.
            # A terminal cancellation can still have executed exposure: never discard it.
            if requested != 1 or (
                executed is not None
                and (
                    executed < 0
                    or executed not in {0, requested}
                    or (order_state == "filled" and executed != requested)
                )
            ):
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "unexpected_partial_fill_quantity",
                        "order_id": pending.get("order_id"),
                        "orders_placed": 0,
                    }
                )
                continue
            if executed == requested and executed and fill_price is not None:
                order_state = "filled"
            if order_state == "partially_filled" or (
                order_state in TERMINAL_FAILURE_STATES
                and executed != 0
            ):
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "partial_fill_reconciliation_required",
                        "order_id": pending.get("order_id"),
                        "orders_placed": 0,
                    }
                )
                continue
            context = pending.get("context") if isinstance(pending.get("context"), Mapping) else {}
            if order_state in OPEN_ORDER_STATES:
                candidate = context.get("candidate") or {}
                decision = context.get("decision") or {}
                deadline = _timestamp(context.get("hold_deadline"))
                if (
                    pending.get("purpose") == "ENTRY"
                    and deadline is not None
                    and current >= deadline
                ):
                    activities.append(
                        {
                            "status": "ATTENTION",
                            "manual_action": "CANCEL_ORDER",
                            "reason": "pending_day_entry_past_deadline_manual_cancel_required",
                            "order_id": pending.get("order_id"),
                            "symbol": candidate.get("symbol"),
                            "orders_placed": 0,
                        }
                    )
                    continue
                activities.append(
                    {
                        "status": "ORDER_PENDING",
                        "purpose": pending.get("purpose"),
                        "order_id": pending.get("order_id"),
                        "pending_entry": {
                            "order_id": pending.get("order_id"),
                            "symbol": candidate.get("symbol"),
                            "candidate_id": candidate.get("candidate_id"),
                            "submitted_at": pending.get("created_at"),
                            "thesis": decision.get("thesis"),
                            "invalidation": decision.get("invalidation"),
                            "reason": decision.get("reason"),
                        }
                        if pending.get("purpose") == "ENTRY"
                        else None,
                        "orders_placed": 0,
                    }
                )
                continue
            if order_state in TERMINAL_FAILURE_STATES:
                pending_orders.remove(pending)
                _save_state(state_path, state)
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": f"order_{order_state}",
                        "order_id": pending.get("order_id"),
                        "orders_placed": 0,
                    }
                )
                continue
            if order_state != "filled" or fill_price is None:
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "order_status_or_fill_price_unresolved",
                        "order_state": order_state,
                        "orders_placed": 0,
                    }
                )
                continue

            lock_event = None
            fill_time = _order_fill_time(rows[0], current)
            fill_today = fill_time.astimezone(EASTERN).date().isoformat() == state["day"]["date"]
            positions = _state_positions(state)
            if pending.get("purpose") == "ENTRY":
                position = _build_live_position(
                    pending, fill_price=fill_price, now=fill_time, config=config
                )
                position["fill_net_reward_risk"] = net_reward_risk(
                    {**context.get("candidate", {}), "ask": fill_price}, config
                )
                contract_id = str(position["contract_identifier"])
                if any(str(item.get("contract_identifier")) == contract_id for item in positions):
                    activities.append(
                        {
                            "status": "ATTENTION",
                            "reason": "duplicate_filled_entry_contract",
                            "orders_placed": 0,
                        }
                    )
                    continue
                positions.append(position)
                state["positions"] = positions
                just_opened.add(contract_id)
                day = dict(state["day"])
                day["new_positions"] = int(day.get("new_positions", 0)) + int(fill_today)
                state["day"] = day
                event = {
                    "event": "LIVE_ENTRY_FILLED",
                    "timestamp": fill_time.astimezone(UTC).isoformat(),
                    "reconciled_at": current.isoformat(),
                    "symbol": position["symbol"],
                    "fill_price": fill_price,
                    "order_id": position["entry_order_id"],
                    "trade_style": position.get("trade_style"),
                    "hold_deadline": position.get("hold_deadline"),
                    "net_reward_risk": position["fill_net_reward_risk"],
                    "strategy_epoch": position.get("strategy_epoch"),
                }
                activity = {"status": "ENTRY_FILLED", "position": position, "event": event}
                if position["fill_net_reward_risk"]["status"] != "QUALIFIED":
                    activity.update(
                        status="ATTENTION", reason="fill_net_reward_to_risk_below_minimum"
                    )
            elif pending.get("purpose") == "EXIT":
                position_id = str(context.get("position_id", ""))
                position = next(
                    (item for item in positions if str(item.get("position_id", "")) == position_id),
                    None,
                )
                if position is None:
                    activities.append(
                        {
                            "status": "ATTENTION",
                            "reason": "filled_exit_position_not_found",
                            "orders_placed": 0,
                        }
                    )
                    continue
                realized = round(
                    (fill_price - float(position["entry_price"])) * int(position["quantity"]) * 100,
                    2,
                )
                gross_realized = realized
                realized = round(
                    realized
                    - float(position.get("entry_cost_estimate", 0))
                    - float(position.get("exit_cost_estimate", 0)),
                    2,
                )
                closed = {
                    **position,
                    "status": "CLOSED",
                    "exit_price": fill_price,
                    "exit_at": fill_time.astimezone(UTC).isoformat(),
                    "exit_reason": context.get("exit_reason"),
                    "realized_pnl": realized,
                    "gross_realized_pnl": gross_realized,
                }
                state["recent_closed_positions"] = [
                    *state.get("recent_closed_positions", [])[-49:],
                    closed,
                ]
                state["realized_pnl"] = round(float(state.get("realized_pnl", 0)) + realized, 2)
                day = dict(state["day"])
                if fill_today:
                    day["realized_pnl"] = round(float(day.get("realized_pnl", 0)) + realized, 2)
                state["day"] = day
                lock_event = (
                    activate_green_lock(
                        state,
                        now=current,
                        strategy_variant=(strategy_epoch(config) or "python_jev_green_lock")
                        if config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
                        else None,
                    )
                    if fill_today
                    else None
                )
                state["positions"] = [
                    item for item in positions if str(item.get("position_id", "")) != position_id
                ]
                just_closed.add(str(position["contract_identifier"]))
                event = {
                    "event": "LIVE_EXIT_FILLED",
                    **{
                        key: closed.get(key)
                        for key in ("expiration", "strike", "option_type", "quantity")
                    },
                    "timestamp": current.astimezone(UTC).isoformat(),
                    "symbol": closed["symbol"],
                    "fill_price": fill_price,
                    "realized_pnl": realized,
                    "gross_realized_pnl": gross_realized,
                    "strategy_epoch": closed.get("strategy_epoch"),
                    "exit_reason": closed.get("exit_reason"),
                    "filled_at": fill_time.isoformat(),
                    "late_reconciliation": not fill_today,
                }
                position = closed
                activity = {"status": "EXIT_FILLED", "closed_position": closed, "event": event}
            else:
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "unknown_pending_order_purpose",
                        "orders_placed": 0,
                    }
                )
                continue
            pending_orders.remove(pending)
            state["updated_at"] = current.astimezone(UTC).isoformat()
            _save_state(state_path, state)
            if lock_event is not None:
                _append_jsonl(events_path, lock_event)
            _append_jsonl(events_path, event)
            _record_trade_event(project_root, event=event["event"], position=position, now=current)
            activities.append({**activity, "order_id": pending.get("order_id"), "orders_placed": 0})

        positions = _state_positions(state)
        broker_positions = _position_map(snapshot)
        local_contracts = {str(item.get("contract_identifier", "")) for item in positions}
        unknown_contracts = set(broker_positions) - local_contracts - just_closed
        pending_ids = {
            str(item.get("order_id"))
            for item in _state_pending_orders(state)
            if item.get("order_id")
        }
        # The snapshot predates fill reconciliation, so orders just resolved above are also known.
        resolved_ids = {str(item.get("order_id")) for item in activities if item.get("order_id")}
        resolved_ids.update(
            str(item.get("event", {}).get("order_id"))
            for item in activities
            if item.get("event", {}).get("order_id")
        )
        untracked_orders = [
            item
            for item in snapshot.get("open_option_orders", [])
            if isinstance(item, Mapping)
            and str(item.get("id", "")) not in pending_ids | resolved_ids
        ]
        if unknown_contracts or untracked_orders:
            activities.append(
                {
                    "status": "ATTENTION",
                    "reason": "untracked_broker_position_or_order",
                    "orders_placed": 0,
                }
            )

        quote_by_contract = _quote_map(snapshot)
        updated_positions: list[dict[str, Any]] = []
        for tracked in positions:
            position = dict(tracked)
            updated_positions.append(position)
            contract_id = str(position.get("contract_identifier", ""))
            broker = broker_positions.get(contract_id)
            if broker is None:
                if contract_id not in just_opened:
                    activities.append(
                        {
                            "status": "ATTENTION",
                            "reason": "tracked_live_position_missing_at_broker",
                            "contract_identifier": contract_id,
                            "orders_placed": 0,
                        }
                    )
                continue
            if _number(broker.get("quantity")) != int(position.get("quantity", 1)):
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "tracked_live_position_quantity_mismatch",
                        "contract_identifier": contract_id,
                        "orders_placed": 0,
                    }
                )
                continue
            quote = quote_by_contract.get(contract_id)
            bid = _number(quote.get("bid_price")) if quote else None
            if (
                quote is None
                or bid is None
                or bid < 0
                or not _fresh(
                    quote.get("updated_at"),
                    now=now or datetime.now(UTC),
                    maximum_age_seconds=quote_max_age_seconds,
                )
            ):
                if contract_id not in just_opened:
                    activities.append(
                        {
                            "status": "ATTENTION",
                            "reason": "live_position_quote_invalid_or_stale",
                            "contract_identifier": contract_id,
                            "orders_placed": 0,
                        }
                    )
                continue
            position["last_bid"] = round(bid, 4)
            position["high_water_bid"] = round(max(float(position["high_water_bid"]), bid), 4)
            exit_reason = _exit_trigger(position, bid=bid, now=current)
            if exit_reason is None or any(
                contract_id in _order_contracts(order) for order in _state_pending_orders(state)
            ):
                continue
            if any(
                not _order_contracts(order) or contract_id in _order_contracts(order)
                for order in untracked_orders
            ):
                activities.append(
                    {
                        "status": "ATTENTION",
                        "reason": "untracked_order_conflicts_with_exit",
                        "contract_identifier": contract_id,
                        "orders_placed": 0,
                    }
                )
                continue
            try:
                result = await _review_and_submit(
                    _exit_order_request(position),
                    state=state,
                    state_path=state_path,
                    purpose="EXIT",
                    context={"exit_reason": exit_reason, "position_id": position["position_id"]},
                    now=current,
                    reviewer=reviewer,
                    placer=placer,
                    pre_submit_check=lambda quote=quote: (
                        _fresh(
                            snapshot.get("as_of"),
                            now=now or datetime.now(UTC),
                            maximum_age_seconds=snapshot_max_age_seconds,
                        )
                        and _fresh(
                            quote.get("updated_at"),
                            now=now or datetime.now(UTC),
                            maximum_age_seconds=quote_max_age_seconds,
                        )
                        and (
                            not (project_root / "CONFIG.md").exists()
                            or load_config(project_root / "CONFIG.md").values == config.values
                        )
                    ),
                )
                result["exit_reason"] = exit_reason
                result["symbol"] = position.get("symbol")
                _append_jsonl(
                    events_path,
                    {
                        "event": "LIVE_EXIT_REVIEW_OR_SUBMISSION",
                        "timestamp": current.astimezone(UTC).isoformat(),
                        "position_id": position["position_id"],
                        "result": result,
                    },
                )
            except Exception as exc:
                result = {
                    "status": "ATTENTION",
                    "reason": f"live_exit_submission_uncertain:{type(exc).__name__}",
                    "contract_identifier": contract_id,
                    "orders_placed": 0,
                }
            activities.append(result)

        state["positions"] = updated_positions
        state["updated_at"] = current.astimezone(UTC).isoformat()
        write = _save_state(state_path, state)
        _save_positions_memory(project_root, updated_positions, current)
        _update_daily_state(project_root, state, snapshot)
        priority = {
            "SUBMITTED": 0,
            "ORDER_RESUBMITTED_IDEMPOTENTLY": 1,
            "ATTENTION": 2,
            "BLOCKED": 2,
            "ENTRY_FILLED": 3,
            "EXIT_FILLED": 3,
            "ORDER_PENDING": 4,
        }
        primary = (
            min(activities, key=lambda item: priority.get(item["status"], 9))
            if activities
            else {
                "status": "MONITORED" if updated_positions else "QUIET",
            }
        )
        return {
            **primary,
            "positions": updated_positions,
            "portfolio": _portfolio_metrics(snapshot, state),
            "day": dict(state["day"]),
            "strategy_epoch": state.get("strategy_epoch"),
            "position_actions": activities,
            "pending_order_count": len(_state_pending_orders(state)),
            "persistent_write": write,
            "wake_codex": any(item["status"] in {"ATTENTION", "BLOCKED"} for item in activities),
            "orders_placed": sum(int(item.get("orders_placed", 0)) for item in activities),
            "orders_cancelled": 0,
        }
