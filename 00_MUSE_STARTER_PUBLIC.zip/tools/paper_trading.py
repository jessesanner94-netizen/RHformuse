"""Deterministic shadow options ledger using conservative ask-entry/bid-exit fills."""

from __future__ import annotations

import json
import math
import os
import tempfile
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from datetime import UTC, date, datetime, timedelta
from decimal import ROUND_CEILING, Decimal
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.config import TradingConfig
from tools.market_calendar import day_deadline, entry_allowed
from tools.option_style import assess_option_styles
from tools.options_strategy import activate_green_lock, identify_state, prepare_day
from tools.portfolio_risk import evaluate_risk
from tools.state_manager import guarded_json_update

EASTERN = ZoneInfo("America/New_York")
SCHEMA_VERSION = 1
GREEN_LOCK_VARIANT = "daily_green_lock"
PRIMARY_GREEN_LOCK_VARIANT = "primary_deterministic_no_luna_green_lock"


def paper_side_cost(config: TradingConfig) -> float:
    amounts = [
        config.get(name, 0)
        for name in (
            "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS",
            "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS",
        )
    ]
    if any(
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value < 0
        for value in amounts
    ):
        raise ValueError("invalid paper execution cost estimate")
    return round(sum(amounts), 2)


def net_reward_risk(candidate: Mapping[str, Any], config: TradingConfig) -> dict[str, Any]:
    """Plan one contract at configured triggers with the ledger's costs/accounting.

    These are P&Ls at configured premium triggers, not guaranteed executable exits.
    Optional historical TP fills ceil the limit to a cent; do not assume that extra
    upside in this conservative trigger-based gate.
    The planning risk buffer is not charged again: paper_side_cost is the fee model.
    """
    fields = ("ask", "STOP_LOSS_PERCENT", "TAKE_PROFIT_PERCENT", "MIN_NET_REWARD_TO_RISK")
    values = [candidate.get("ask"), *(config.get(field) for field in fields[1:])]
    if any(
        isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value)
        for value in values
    ):
        return {"status": "REJECTED", "reasons": ["net_reward_to_risk_invalid_inputs"]}
    ask, stop, target, minimum = (float(value) for value in values)
    if ask <= 0 or not 0 <= stop <= 100 or target < 0 or minimum <= 0:
        return {"status": "REJECTED", "reasons": ["net_reward_to_risk_invalid_inputs"]}
    if any(
        config.get(field) is None
        for field in (
            "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS",
            "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS",
        )
    ):
        return {"status": "REJECTED", "reasons": ["net_reward_to_risk_invalid_costs"]}
    try:
        side_cost = paper_side_cost(config)
        if not math.isfinite(side_cost):
            return {"status": "REJECTED", "reasons": ["net_reward_to_risk_invalid_costs"]}
        premium = round(ask * 100, 2)
        stop_price = round(ask * (1 - stop / 100), 4)
        target_price = round(ask * (1 + target / 100), 4)
        # Match _book_close's cent-rounded proceeds and net P&L.
        target_pnl = round(round(target_price * 100, 2) - premium - 2 * side_cost, 2)
        stop_pnl = round(round(stop_price * 100, 2) - premium - 2 * side_cost, 2)
        reward, risk = target_pnl, -stop_pnl
        if not all(math.isfinite(value) for value in (premium, target_pnl, stop_pnl)):
            return {"status": "REJECTED", "reasons": ["net_reward_to_risk_invalid_inputs"]}
        ratio = float(Decimal(str(reward)) / Decimal(str(risk))) if risk > 0 else None
        metrics = {
            "expected_entry_debit_dollars": round(premium + side_cost, 2),
            "entry_cost_dollars": side_cost,
            "exit_cost_dollars": side_cost,
            "take_profit_price": target_price,
            "stop_price": stop_price,
            "net_take_profit_pnl_dollars": target_pnl,
            "net_stop_loss_pnl_dollars": stop_pnl,
            "net_reward_dollars": reward,
            "net_risk_dollars": risk,
            "net_reward_to_risk": ratio,
            "minimum_net_reward_to_risk": minimum,
        }
    except (ValueError, OverflowError):
        return {"status": "REJECTED", "reasons": ["net_reward_to_risk_invalid_costs"]}
    reasons = []
    if reward <= 0 or not math.isfinite(reward):
        reasons.append("net_reward_not_positive")
    if risk <= 0 or not math.isfinite(risk):
        reasons.append("net_risk_invalid_or_zero")
    elif Decimal(str(reward)) < Decimal(str(risk)) * Decimal(str(minimum)):
        reasons.append("net_reward_to_risk_below_minimum")
    return {"status": "REJECTED" if reasons else "QUALIFIED", "reasons": reasons, **metrics}


def _variant_path(path: Path) -> bool:
    return path.parent.name == GREEN_LOCK_VARIANT


def _prepare_variant(state: dict[str, Any], *, portfolio_path: Path) -> None:
    if not _variant_path(portfolio_path):
        return
    if state.get("strategy_variant") not in (None, GREEN_LOCK_VARIANT):
        raise ValueError("paper variant ledger identity mismatch")
    state["strategy_variant"] = GREEN_LOCK_VARIANT
    day = state["day"]
    day.setdefault("green_lock_active", False)
    day.setdefault("lock_activated_at", None)
    day.setdefault("realized_pnl_at_activation", None)
    day.setdefault("skipped_entry_count", 0)


def _green_lock_strategy(config: TradingConfig, portfolio_path: Path) -> str | None:
    if _variant_path(portfolio_path):
        return GREEN_LOCK_VARIANT
    if portfolio_path.parent.name == "paper" and (
        config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
        or config.get("PAPER_PRIMARY_DAILY_GREEN_LOCK_ENABLED", False) is True
    ):
        return PRIMARY_GREEN_LOCK_VARIANT
    return None


def _prepare_green_lock_day(state: dict[str, Any]) -> None:
    prepare_day(state)


def _activate_green_lock(
    state: dict[str, Any], *, now: datetime, strategy_variant: str | None
) -> dict[str, Any] | None:
    return activate_green_lock(state, now=now, strategy_variant=strategy_variant)


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _quote_is_fresh(
    value: Any,
    *,
    now: datetime,
    maximum_age_seconds: int = 240,
    future_tolerance_seconds: int = 30,
) -> bool:
    parsed = _timestamp(value)
    if parsed is None:
        return False
    age = (now.astimezone(UTC) - parsed).total_seconds()
    return -future_tolerance_seconds <= age <= maximum_age_seconds


@contextmanager
def _exclusive_lock(target: Path) -> Iterator[None]:
    lock_path = target.with_suffix(target.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:  # pragma: no cover - Windows is the production platform
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:  # pragma: no cover
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _default_portfolio(starting_cash: float, *, now: datetime) -> dict[str, Any]:
    local_date = now.astimezone(EASTERN).date().isoformat()
    return {
        "schema_version": SCHEMA_VERSION,
        "mode": "PAPER",
        "fill_policy": "BUY_AT_ASK_SELL_AT_BID",
        "starting_cash": round(starting_cash, 2),
        "cash": round(starting_cash, 2),
        "equity": round(starting_cash, 2),
        "realized_pnl": 0.0,
        "unrealized_pnl": 0.0,
        "day": {
            "date": local_date,
            "start_equity": round(starting_cash, 2),
            "realized_pnl": 0.0,
            "new_positions": 0,
        },
        "open_positions": [],
        "recent_closed_positions": [],
        "closed_trade_count": 0,
        "updated_at": now.astimezone(UTC).isoformat(),
    }


def load_paper_portfolio(
    path: Path, *, starting_cash: float, now: datetime | None = None
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    if not path.exists():
        state = _default_portfolio(starting_cash, now=current)
        _prepare_variant(state, portfolio_path=path)
        return state
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping) or payload.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("paper portfolio schema is invalid")
    state = dict(payload)
    if not isinstance(state.get("open_positions"), list):
        raise ValueError("paper open positions are invalid")
    if not isinstance(state.get("recent_closed_positions"), list):
        raise ValueError("paper recent closed positions are invalid")
    _roll_day(state, now=current)
    _prepare_variant(state, portfolio_path=path)
    return state


def ensure_paper_portfolio(
    config: TradingConfig,
    *,
    portfolio_path: Path,
    event_log_path: Path,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    with _exclusive_lock(portfolio_path):
        existed = portfolio_path.exists()
        old_day = None
        if existed:
            old_day = (
                json.loads(portfolio_path.read_text(encoding="utf-8")).get("day", {}).get("date")
            )
        state = load_paper_portfolio(
            portfolio_path,
            starting_cash=float(config.get("PAPER_STARTING_CASH")),
            now=current,
        )
        _prepare_variant(state, portfolio_path=portfolio_path)
        if portfolio_path.parent.name == "paper":
            identify_state(state, config)
            if _green_lock_strategy(config, portfolio_path):
                prepare_day(state)
        if not math.isclose(
            float(state.get("starting_cash", 0)),
            float(config.get("PAPER_STARTING_CASH")),
            abs_tol=0.01,
        ):
            raise ValueError("paper starting cash differs from the persisted ledger")
        if not existed or old_day != state["day"]["date"]:
            state["updated_at"] = current.astimezone(UTC).isoformat()
            _save_state(portfolio_path, state)
        if not existed:
            _append_event(
                event_log_path,
                {
                    "event": "PAPER_ACCOUNT_INITIALIZED",
                    "timestamp": current.astimezone(UTC).isoformat(),
                    "starting_cash": state["starting_cash"],
                    "fill_policy": state["fill_policy"],
                    **(
                        {"strategy_variant": GREEN_LOCK_VARIANT}
                        if _variant_path(portfolio_path)
                        else {}
                    ),
                },
            )
        return state


def _roll_day(state: dict[str, Any], *, now: datetime) -> None:
    local_date = now.astimezone(EASTERN).date().isoformat()
    day = state.get("day")
    if not isinstance(day, Mapping) or day.get("date") != local_date:
        state["day"] = {
            "date": local_date,
            "start_equity": round(float(state.get("equity", state.get("cash", 0))), 2),
            "realized_pnl": 0.0,
            "new_positions": 0,
        }


def _append_event(path: Path, event: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if _variant_path(path):
        event = {**event, "strategy_variant": GREEN_LOCK_VARIANT, "mode": "PAPER"}
    elif path.parent.parent.parent.name == "options":
        event = {**event, "strategy_epoch": path.parent.parent.name, "mode": "PAPER"}
    serialized = json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n"
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(serialized)
        handle.flush()
        os.fsync(handle.fileno())


def _atomic_text_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _render_summary(state: Mapping[str, Any]) -> str:
    lines = [
        "# Daily Green Lock — Paper Trading Summary"
        if state.get("strategy_variant") == GREEN_LOCK_VARIANT
        else "# Paper Trading Summary",
        "",
        f"- Updated: {state.get('updated_at')}",
        f"- Starting cash: ${float(state.get('starting_cash', 0)):.2f}",
        f"- Cash: ${float(state.get('cash', 0)):.2f}",
        f"- Equity: ${float(state.get('equity', 0)):.2f}",
        f"- Realized P&L: ${float(state.get('realized_pnl', 0)):.2f}",
        f"- Unrealized P&L: ${float(state.get('unrealized_pnl', 0)):.2f}",
        f"- Daily P&L (change in equity): ${paper_account_metrics(state)['daily_pnl']:.2f}",
        f"- Estimated execution costs: ${float(state.get('estimated_execution_costs', 0)):.2f}",
        f"- Open positions: {len(state.get('open_positions', []))}",
        f"- Closed trades: {int(state.get('closed_trade_count', 0))}",
        "",
        "## Open positions",
        "",
    ]
    open_positions = state.get("open_positions", [])
    if not open_positions:
        lines.append("None.")
    for position in open_positions:
        lines.extend(
            [
                f"### {position.get('symbol')} {position.get('expiration')} "
                f"{position.get('strike')} {position.get('option_type')}",
                "",
                f"- Paper ID: {position.get('paper_id')}",
                f"- Quantity: {position.get('quantity')}",
                f"- Entry ask: ${float(position.get('entry_price', 0)):.2f}",
                f"- Last bid: ${float(position.get('last_bid', 0)):.2f}",
                f"- Unrealized P&L: ${float(position.get('unrealized_pnl', 0)):.2f}",
                f"- Stop: ${float(position.get('stop_price', 0)):.2f}",
                f"- Target: ${float(position.get('take_profit_price', 0)):.2f}",
                f"- Style: {position.get('trade_style')}",
                f"- Thesis: {position.get('thesis')}",
                f"- Invalidation: {position.get('invalidation')}",
                "",
            ]
        )
    if "green_lock_active" in state["day"]:
        day = state["day"]
        lines.extend(
            [
                "## Daily green lock (paper only)",
                "",
                f"- Trading day: {day['date']}",
                f"- Realized daily net P&L: ${float(day['realized_pnl']):.2f}",
                f"- Lock active: {day.get('green_lock_active')}",
                f"- Activated at: {day.get('lock_activated_at')}",
                f"- Realized P&L at activation: {day.get('realized_pnl_at_activation')}",
                f"- Skipped entries: {day.get('skipped_entry_count', 0)}",
                "",
            ]
        )
    lines.extend(["## Recent closed positions", ""])
    recent = state.get("recent_closed_positions", [])
    if not recent:
        lines.append("None.")
    for position in recent[-10:][::-1]:
        lines.append(
            f"- {position.get('symbol')} {position.get('option_type')} — "
            f"{position.get('exit_reason')} — ${float(position.get('realized_pnl', 0)):.2f}"
        )
    return "\n".join(lines).rstrip() + "\n"


def _save_state(portfolio_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    write_result = guarded_json_update(portfolio_path, state, commit=True)
    write_result.pop("payload", None)
    _atomic_text_write(portfolio_path.with_name("SUMMARY.md"), _render_summary(state))
    return write_result


def paper_account_metrics(state: Mapping[str, Any]) -> dict[str, float | int]:
    day = state.get("day") if isinstance(state.get("day"), Mapping) else {}
    open_positions = state.get("open_positions", [])
    open_risk = sum(float(item.get("entry_cost", 0)) for item in open_positions)
    return {
        "account_value": float(state.get("equity", 0)),
        "account_value_start_of_day": float(day.get("start_equity", 0)),
        "buying_power": float(state.get("cash", 0)),
        "daily_pnl": round(float(state["equity"]) - float(day["start_equity"]), 2),
        "open_stop_risk": sum(
            max(
                0,
                (float(item["last_bid"]) - float(item["stop_price"]))
                * int(item.get("quantity", 1))
                * 100,
            )
            + float(item.get("exit_cost_estimate", 0))
            for item in open_positions
        ),
        "open_premium_at_risk": open_risk,
        "open_position_count": len(open_positions),
        "new_positions_today": int(day.get("new_positions", 0)),
    }


def _day_deadline(now: datetime, minutes_before_close: int) -> str:
    return day_deadline(now, minutes_before_close)


def _new_entry_time_allowed(now: datetime, config: TradingConfig, *, trade_style: str) -> bool:
    return entry_allowed(now, config, trade_style)


def _valid_swing_deadline(value: Any, *, now: datetime, expiration: str) -> str | None:
    parsed = _timestamp(value)
    if parsed is None or parsed <= now.astimezone(UTC):
        return None
    try:
        expiry = date.fromisoformat(expiration)
    except ValueError:
        return None
    if parsed.astimezone(EASTERN).date() > expiry:
        return None
    return parsed.isoformat()


def _winner_trial_settings(
    config: TradingConfig, *, portfolio_path: Path, now: datetime, trade_style: str
) -> dict[str, Any] | None:
    """Return the bounded primary-ledger trial settings for a newly opened position."""

    if (
        trade_style != "DAY"
        or now.astimezone(EASTERN).date().isoformat()
        != str(config.get("PAPER_WINNER_TRIAL_DATE") or "")
        or any(
            part.lower() in {"paper_baseline", GREEN_LOCK_VARIANT} for part in portfolio_path.parts
        )
    ):
        return None
    giveback = _number(config.get("PAPER_WINNER_TRAIL_GIVEBACK_PERCENT"))
    minimum_profit = _number(config.get("PAPER_WINNER_MIN_PROFIT_PERCENT"))
    if giveback is None or not 0 < giveback < 100 or minimum_profit is None or minimum_profit < 0:
        return None
    return {
        "enabled": True,
        "checkpoint_reached": False,
        "giveback_percent": giveback,
        "min_profit_percent": minimum_profit,
    }


def open_paper_position(
    decision: Mapping[str, Any],
    candidate: Mapping[str, Any],
    config: TradingConfig,
    *,
    portfolio_path: Path,
    event_log_path: Path,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    if _variant_path(portfolio_path) and config.live_execution_enabled:
        return {"status": "BLOCKED", "reasons": ["daily_green_lock_paper_only"], "opened": False}
    if config.paper_blockers():
        return {"status": "BLOCKED", "reasons": config.paper_blockers(), "opened": False}
    if decision.get("action") != "BUY":
        return {"status": "SKIPPED", "reason": "decision_is_not_buy", "opened": False}
    if decision.get("candidate_id") != candidate.get("candidate_id"):
        return {"status": "BLOCKED", "reasons": ["candidate_id_mismatch"], "opened": False}
    ask = _number(candidate.get("ask"))
    bid = _number(candidate.get("bid"))
    if (
        ask is None
        or bid is None
        or ask <= 0
        or bid < 0
        or ask < bid
        or candidate.get("quote_is_fresh") is not True
    ):
        return {"status": "BLOCKED", "reasons": ["invalid_or_stale_fill_quote"], "opened": False}
    if (ask - bid) / ((ask + bid) / 2) * 100 > float(config.get("MAX_BID_ASK_SPREAD_PERCENT")):
        return {"status": "BLOCKED", "reasons": ["fill_spread_too_wide"], "opened": False}
    style = str(decision.get("trade_style", "")).upper()
    if config.get("DAY_ONLY_OPTIONS") is True and style != "DAY":
        return {"status": "BLOCKED", "reasons": ["day_only_options"], "opened": False}
    if style not in {"DAY", "SWING"}:
        return {"status": "BLOCKED", "reasons": ["invalid_trade_style"], "opened": False}
    if not _new_entry_time_allowed(current, config, trade_style=style):
        return {
            "status": "BLOCKED",
            "reasons": [f"{style.lower()}_entry_window_closed"],
            "opened": False,
        }
    style_assessment = assess_option_styles(candidate, config)
    if style not in style_assessment["eligible_styles"]:
        reasons = [*style_assessment["common_reasons"], *style_assessment["style_reasons"][style]]
        return {
            "status": "BLOCKED",
            "reasons": [f"trade_style_not_eligible:{style.lower()}", *reasons],
            "greek_metrics": style_assessment["metrics"],
            "opened": False,
        }
    entry_styles = candidate.get("entry_eligible_trade_styles")
    if isinstance(entry_styles, list) and style not in {str(item).upper() for item in entry_styles}:
        return {
            "status": "BLOCKED",
            "reasons": [f"trade_style_not_entry_eligible:{style.lower()}"],
            "opened": False,
        }
    holds_through_earnings = decision.get("holds_through_earnings")
    if not isinstance(holds_through_earnings, bool):
        return {
            "status": "BLOCKED",
            "reasons": ["earnings_hold_assessment_missing"],
            "opened": False,
        }
    expiration = str(candidate.get("expiration", ""))
    if style == "DAY":
        deadline = _day_deadline(current, int(config.get("DAY_TRADE_EXIT_MINUTES_BEFORE_CLOSE")))
    else:
        deadline = _valid_swing_deadline(
            decision.get("hold_deadline"), now=current, expiration=expiration
        )
        if deadline is None:
            return {
                "status": "BLOCKED",
                "reasons": ["invalid_swing_hold_deadline"],
                "opened": False,
            }

    starting_cash = float(config.get("PAPER_STARTING_CASH"))
    with _exclusive_lock(portfolio_path):
        state = load_paper_portfolio(portfolio_path, starting_cash=starting_cash, now=current)
        if portfolio_path.parent.name == "paper":
            identify_state(state, config)
        green_lock_strategy = _green_lock_strategy(config, portfolio_path)
        if green_lock_strategy is not None:
            _prepare_green_lock_day(state)
        if green_lock_strategy is not None and state["day"].get("green_lock_active") is True:
            return _record_variant_skip_locked(
                state,
                {"status": "BLOCKED", "reasons": ["daily_green_lock_active"], "opened": False},
                candidate_id=candidate.get("candidate_id"),
                portfolio_path=portfolio_path,
                event_log_path=event_log_path,
                now=current,
                strategy_variant=green_lock_strategy,
            )
        if portfolio_path.parent.name == "paper" and config.options_blockers():
            return {"status": "BLOCKED", "reasons": config.options_blockers(), "opened": False}
        reward_risk = net_reward_risk(candidate, config)
        if reward_risk["status"] != "QUALIFIED":
            event = {
                "event": "PAPER_ENTRY_REJECTED",
                "timestamp": current.isoformat(),
                "candidate_id": candidate.get("candidate_id"),
                **reward_risk,
            }
            _append_event(event_log_path, event)
            return {
                "status": "BLOCKED",
                "reasons": reward_risk["reasons"],
                "net_reward_risk": reward_risk,
                "opened": False,
            }
        if any(
            str(item.get("symbol", "")).upper() == str(candidate.get("symbol", "")).upper()
            for item in state["open_positions"]
        ):
            return {"status": "BLOCKED", "reasons": ["underlying_already_held"], "opened": False}
        premium = round(ask * 100, 2)
        risk = evaluate_risk(
            paper_account_metrics(state),
            {
                "symbol": candidate.get("symbol"),
                "premium_at_risk": premium,
                "quantity": 1,
                "holds_through_earnings": holds_through_earnings,
                "is_averaging_down": False,
                "protective_stop_planned": True,
            },
            config,
        )
        if risk.status != "ALLOWED":
            return {
                "status": "BLOCKED",
                "reasons": list(risk.reasons),
                "risk": risk.as_dict(),
                "opened": False,
            }
        timestamp = current.astimezone(UTC).isoformat()
        contract_id = str(candidate["candidate_id"])
        paper_id = f"paper-{current.strftime('%Y%m%dT%H%M%S')}-{contract_id[:8]}"
        position = {
            "paper_id": paper_id,
            "contract_identifier": contract_id,
            "symbol": str(candidate.get("symbol", "")).upper(),
            "option_symbol": candidate.get("option_symbol"),
            "expiration": expiration,
            "strike": float(candidate.get("strike")),
            "option_type": str(candidate.get("option_type", "")).upper(),
            "quantity": 1,
            "entry_at": timestamp,
            "entry_price": round(ask, 4),
            "entry_cost": premium,
            "entry_cost_estimate": paper_side_cost(config),
            "exit_cost_estimate": paper_side_cost(config),
            "entry_underlying": candidate.get("underlying_price"),
            "last_bid": round(bid, 4),
            "last_ask": round(ask, 4),
            "last_mark": round((bid + ask) / 2, 4),
            "last_quote_at": candidate.get("quote_updated_at") or timestamp,
            "high_water_bid": round(bid, 4),
            "stop_price": round(ask * (1 - float(config.get("STOP_LOSS_PERCENT")) / 100), 4),
            "take_profit_price": round(
                ask * (1 + float(config.get("TAKE_PROFIT_PERCENT")) / 100), 4
            ),
            "trade_style": style,
            "hold_deadline": deadline,
            "thesis": str(decision.get("thesis", "")).strip(),
            "invalidation": str(decision.get("invalidation", "")).strip(),
            "decision_reason": str(decision.get("reason", "")).strip(),
            "earnings_event": str(decision.get("earnings_event", "")).strip(),
            "holds_through_earnings": holds_through_earnings,
            "confidence": decision.get("confidence"),
            "entry_greeks": {
                "implied_volatility": candidate.get("implied_volatility"),
                "delta": candidate.get("delta"),
                "gamma": candidate.get("gamma"),
                "theta": candidate.get("theta"),
                "vega": candidate.get("vega"),
                "rho": candidate.get("rho"),
                **style_assessment["metrics"],
            },
            "unrealized_pnl": round((bid - ask) * 100, 2),
            "status": "OPEN",
            "net_reward_risk": reward_risk,
            **({"strategy_variant": GREEN_LOCK_VARIANT} if _variant_path(portfolio_path) else {}),
        }
        winner_settings = _winner_trial_settings(
            config, portfolio_path=portfolio_path, now=current, trade_style=style
        )
        if winner_settings is not None:
            position["winner_management"] = {
                **winner_settings,
                "original_stop_price": position["stop_price"],
                "trailing_floor": position["stop_price"],
            }
        state["cash"] = round(float(state["cash"]) - premium - position["entry_cost_estimate"], 2)
        state["estimated_execution_costs"] = round(
            float(state.get("estimated_execution_costs", 0)) + position["entry_cost_estimate"], 2
        )
        state["open_positions"].append(position)
        state["day"]["new_positions"] = int(state["day"]["new_positions"]) + 1
        _revalue(state)
        state["updated_at"] = timestamp
        write = _save_state(portfolio_path, state)
        event = {
            "event": "PAPER_ENTRY",
            "timestamp": timestamp,
            "paper_id": paper_id,
            "symbol": position["symbol"],
            "contract_identifier": contract_id,
            "fill_side": "BUY_AT_ASK",
            "fill_price": round(ask, 4),
            "quantity": 1,
            "expiration": position["expiration"],
            "strike": position["strike"],
            "option_type": position["option_type"],
            "trade_style": position["trade_style"],
            "hold_deadline": position["hold_deadline"],
            "cash_after": state["cash"],
            "equity_after": state["equity"],
            "decision": dict(decision),
            "net_reward_risk": reward_risk,
            **(
                {"winner_management": dict(position["winner_management"])}
                if winner_settings is not None
                else {}
            ),
        }
        _append_event(event_log_path, event)
        return {
            "status": "OPENED",
            "opened": True,
            "position": position,
            "risk": risk.as_dict(),
            "net_reward_risk": reward_risk,
            "portfolio": paper_summary(state),
            "persistent_write": write,
            "event": event,
        }


def _revalue(state: dict[str, Any]) -> None:
    open_positions = state.get("open_positions", [])
    market_value = 0.0
    unrealized = 0.0
    for position in open_positions:
        value = float(position.get("last_bid", 0)) * int(position.get("quantity", 1)) * 100
        pnl = (
            value
            - float(position.get("entry_cost", 0))
            - float(position.get("entry_cost_estimate", 0))
        )
        position["unrealized_pnl"] = round(pnl, 2)
        market_value += value
        unrealized += pnl
    state["unrealized_pnl"] = round(unrealized, 2)
    state["equity"] = round(float(state.get("cash", 0)) + market_value, 2)
    peak = max(float(state.get("peak_equity", state.get("starting_cash", 0))), state["equity"])
    state["peak_equity"] = peak
    state["max_drawdown_dollars"] = max(
        float(state.get("max_drawdown_dollars", 0)), round(peak - state["equity"], 2)
    )


def _book_close(state: dict[str, Any], position: Mapping[str, Any], proceeds: float) -> float:
    exit_cost = float(position.get("exit_cost_estimate", 0))
    realized = round(
        proceeds
        - float(position["entry_cost"])
        - float(position.get("entry_cost_estimate", 0))
        - exit_cost,
        2,
    )
    state["cash"] = round(float(state["cash"]) + proceeds - exit_cost, 2)
    state["realized_pnl"] = round(float(state["realized_pnl"]) + realized, 2)
    state["day"]["realized_pnl"] = round(float(state["day"]["realized_pnl"]) + realized, 2)
    state["estimated_execution_costs"] = round(
        float(state.get("estimated_execution_costs", 0)) + exit_cost, 2
    )
    state["winning_trades"] = int(state.get("winning_trades", 0)) + int(realized > 0)
    state["gross_wins"] = round(float(state.get("gross_wins", 0)) + max(realized, 0), 2)
    state["gross_losses"] = round(float(state.get("gross_losses", 0)) + max(-realized, 0), 2)
    return realized


def _record_variant_skip_locked(
    state: dict[str, Any],
    result: Mapping[str, Any],
    *,
    candidate_id: Any,
    portfolio_path: Path,
    event_log_path: Path,
    now: datetime,
    strategy_variant: str,
) -> dict[str, Any]:
    reasons = list(result.get("reasons", []))
    reason = (
        "daily_green_lock_active"
        if "daily_green_lock_active" in reasons
        else str(result.get("reason") or (reasons[0] if reasons else result.get("status")))
    )
    if reason == "daily_green_lock_active":
        state["day"]["skipped_entry_count"] += 1
    state["updated_at"] = now.astimezone(UTC).isoformat()
    _save_state(portfolio_path, state)
    event = {
        "event": "PAPER_ENTRY_SKIPPED",
        "timestamp": state["updated_at"],
        "candidate_id": candidate_id,
        "reason": reason,
        "reasons": reasons,
        "trading_day": state["day"]["date"],
        "daily_realized_pnl": state["day"]["realized_pnl"],
        "skipped_entry_count": state["day"]["skipped_entry_count"],
        "strategy_variant": strategy_variant,
    }
    _append_event(event_log_path, event)
    return {**result, "skip_recorded": True, "event": event, "portfolio": paper_summary(state)}


def record_variant_skip(
    result: Mapping[str, Any],
    config: TradingConfig,
    *,
    candidate_id: Any,
    portfolio_path: Path,
    event_log_path: Path,
    now: datetime,
) -> dict[str, Any]:
    """Persist a comparator skip separately from primary and control accounting."""
    if not _variant_path(portfolio_path):
        raise ValueError("variant skip requires isolated daily_green_lock ledger")
    with _exclusive_lock(portfolio_path):
        state = load_paper_portfolio(
            portfolio_path, starting_cash=float(config.get("PAPER_STARTING_CASH")), now=now
        )
        return _record_variant_skip_locked(
            state,
            result,
            candidate_id=candidate_id,
            portfolio_path=portfolio_path,
            event_log_path=event_log_path,
            now=now,
            strategy_variant=GREEN_LOCK_VARIANT,
        )


def _quote_map(refresh: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for row in refresh.get("option_quotes", []):
        if not isinstance(row, Mapping):
            continue
        body = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        contract_id = body.get("instrument_id")
        if isinstance(contract_id, str):
            result[contract_id] = body
    return result


def _winner_management(position: Mapping[str, Any]) -> dict[str, Any] | None:
    value = position.get("winner_management")
    return value if isinstance(value, dict) and value.get("enabled") is True else None


def _continuation_status(
    refresh: Mapping[str, Any],
    position: Mapping[str, Any],
    management: dict[str, Any],
    *,
    now: datetime,
) -> str:
    evidence_by_symbol = refresh.get("continuation_evidence")
    raw = (
        evidence_by_symbol.get(str(position.get("symbol", "")).upper())
        if isinstance(evidence_by_symbol, Mapping)
        else None
    )
    snapshot = dict(raw) if isinstance(raw, Mapping) else {"status": "UNAVAILABLE"}
    snapshot["checked_at"] = now.astimezone(UTC).isoformat()
    evidence_at = _timestamp(snapshot.get("as_of"))
    age = (now.astimezone(UTC) - evidence_at).total_seconds() if evidence_at is not None else None
    status = str(snapshot.get("status") or "UNAVAILABLE").upper()
    matching_direction = (
        str(snapshot.get("option_type") or "").upper()
        == str(position.get("option_type") or "").upper()
    )
    fresh = age is not None and 0 <= age <= 120
    snapshot["fresh"] = fresh
    snapshot["matching_option_type"] = matching_direction
    management["last_evidence"] = snapshot
    if not fresh or not matching_direction:
        return "UNAVAILABLE"
    return status if status in {"INTACT", "BROKEN"} else "UNAVAILABLE"


def _winner_trailing_floor(position: Mapping[str, Any], management: Mapping[str, Any]) -> float:
    original_stop = float(management.get("original_stop_price", position["stop_price"]))
    minimum_profit = float(position["entry_price"]) * (
        1 + float(management["min_profit_percent"]) / 100
    )
    giveback_floor = float(position["high_water_bid"]) * (
        1 - float(management["giveback_percent"]) / 100
    )
    prior_floor = float(management.get("trailing_floor", original_stop))
    return round(max(original_stop, minimum_profit, giveback_floor, prior_floor), 4)


def manage_paper_positions(
    quote_refresh: Mapping[str, Any],
    config: TradingConfig,
    *,
    portfolio_path: Path,
    event_log_path: Path,
    now: datetime | None = None,
    maximum_quote_age_seconds: int | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    fast_primary = (
        config.get("PAPER_FAST_MONITOR_ENABLED") is True and portfolio_path.parent.name == "paper"
    )
    if maximum_quote_age_seconds is None:
        maximum_quote_age_seconds = (
            config.get("PAPER_POSITION_QUOTE_MAX_AGE_SECONDS", 20) if fast_primary else 240
        )
    if (
        isinstance(maximum_quote_age_seconds, bool)
        or not isinstance(maximum_quote_age_seconds, int)
        or maximum_quote_age_seconds <= 0
        or (fast_primary and maximum_quote_age_seconds > 120)
    ):
        raise ValueError("invalid paper exit quote freshness limit")
    starting_cash = float(config.get("PAPER_STARTING_CASH"))
    with _exclusive_lock(portfolio_path):
        state = load_paper_portfolio(portfolio_path, starting_cash=starting_cash, now=current)
        quotes = _quote_map(quote_refresh)
        events: list[dict[str, Any]] = []
        attention: list[dict[str, Any]] = []
        remaining: list[dict[str, Any]] = []
        for position in state["open_positions"]:
            contract_id = str(position.get("contract_identifier", ""))
            winner = _winner_management(position)
            history = quote_refresh.get("tp_history", {}).get(contract_id, {})
            evidence = position.setdefault("take_profit_evidence", {})
            evidence["history_status"] = history.get("status", "UNAVAILABLE")
            evidence["checked_at"] = current.astimezone(UTC).isoformat()
            evidence["fill_confirmed"] = False
            entry_at = _timestamp(position.get("entry_at"))
            assumed_tp = False
            limit_price = float(
                Decimal(str(position["take_profit_price"])).quantize(
                    Decimal("0.01"), rounding=ROUND_CEILING
                )
            )
            deadline = _timestamp(position.get("hold_deadline"))
            stop_seen = False
            for series in history.get("results", []) or []:
                if not isinstance(series, Mapping) or series.get("instrument_id") != contract_id:
                    continue
                for bar in sorted(
                    (b for b in series.get("bars", []) or [] if isinstance(b, Mapping)),
                    key=lambda b: str(b.get("begins_at", "")),
                ):
                    if not isinstance(bar, Mapping) or bar.get("interpolated") is True:
                        continue
                    bar_at = _timestamp(bar.get("begins_at"))
                    high = _number(bar.get("high_price"))
                    low = _number(bar.get("low_price"))
                    if (
                        winner is None
                        and config.get("PAPER_ASSUME_TP_TRADE_THROUGH") is True
                        and history.get("status") == "OK"
                        and series.get("interval") == "minute"
                        and entry_at is not None
                        and bar_at is not None
                        and deadline is not None
                        and entry_at <= bar_at
                        and bar_at + timedelta(minutes=1) <= min(current.astimezone(UTC), deadline)
                        and high is not None
                        and low is not None
                        and 0 <= low <= high
                    ):
                        stop_seen = stop_seen or low <= float(position["stop_price"])
                        if high > limit_price and not stop_seen:
                            assumed_tp = True
                            evidence["assumed_fill_bar"] = bar["begins_at"]
                            evidence["assumed_limit_price"] = limit_price
                            break
                    if (
                        entry_at is not None
                        and bar_at is not None
                        and entry_at <= bar_at <= current.astimezone(UTC)
                        and high is not None
                        and high >= float(position["take_profit_price"])
                    ):
                        evidence.setdefault("first_possible_touch_bar", bar["begins_at"])
                        evidence["highest_trade_bar_price"] = max(
                            high, evidence.get("highest_trade_bar_price", 0)
                        )
                        evidence["assessment"] = "POSSIBLE_LIMIT_FILL_NOT_CONFIRMED"
            quote = quotes.get(contract_id)
            if quote is None and not assumed_tp:
                attention.append({"code": "PAPER_QUOTE_MISSING", "paper_id": position["paper_id"]})
                remaining.append(position)
                continue
            quote = quote or {}
            bid = _number(quote.get("bid_price"))
            ask = _number(quote.get("ask_price"))
            updated_at = quote.get("updated_at")
            if not assumed_tp and (
                bid is None
                or ask is None
                or bid < 0
                or ask < bid
                or not _quote_is_fresh(
                    updated_at,
                    now=current,
                    maximum_age_seconds=maximum_quote_age_seconds,
                    future_tolerance_seconds=2 if fast_primary else 30,
                )
            ):
                attention.append({"code": "PAPER_QUOTE_STALE", "paper_id": position["paper_id"]})
                remaining.append(position)
                continue
            if not assumed_tp:
                position["last_bid"] = round(bid, 4)
                position["last_ask"] = round(ask, 4)
                position["last_mark"] = round((bid + ask) / 2, 4)
                position["last_quote_at"] = updated_at
                position["high_water_bid"] = round(
                    max(float(position.get("high_water_bid", 0)), bid), 4
                )
            exit_reason: str | None = None
            if assumed_tp:
                bid = limit_price
                exit_reason = "ASSUMED_LIMIT_TAKE_PROFIT"
                evidence["assessment"] = "ASSUMED_LIMIT_FILL"
            elif bid <= float(position["stop_price"]):
                exit_reason = "STOP_LOSS"
            else:
                deadline = _timestamp(position.get("hold_deadline"))
                if deadline is None:
                    attention.append(
                        {"code": "PAPER_HOLD_DEADLINE_INVALID", "paper_id": position["paper_id"]}
                    )
                    remaining.append(position)
                    continue
                if winner is not None and current.astimezone(UTC) >= deadline:
                    exit_reason = (
                        "DAY_TRADE_TIME_EXIT"
                        if position.get("trade_style") == "DAY"
                        else "SWING_HOLD_DEADLINE"
                    )
                elif winner is None and bid >= float(position["take_profit_price"]):
                    exit_reason = "TAKE_PROFIT"
                elif winner is not None and (
                    winner.get("checkpoint_reached") is True
                    or bid >= float(position["take_profit_price"])
                ):
                    if winner.get("checkpoint_reached") is not True:
                        winner["checkpoint_reached"] = True
                        winner["checkpoint_at"] = current.astimezone(UTC).isoformat()
                        winner["checkpoint_bid"] = round(bid, 4)
                    winner["high_water_bid"] = position["high_water_bid"]
                    winner["trailing_floor"] = _winner_trailing_floor(position, winner)
                    continuation = _continuation_status(
                        quote_refresh, position, winner, now=current
                    )
                    if continuation == "BROKEN":
                        exit_reason = "THESIS_EXIT"
                    elif continuation != "INTACT":
                        exit_reason = "CONTINUATION_UNAVAILABLE"
                    elif bid <= float(winner["trailing_floor"]):
                        exit_reason = "TRAILING_PROFIT"
                elif current.astimezone(UTC) >= deadline:
                    exit_reason = (
                        "DAY_TRADE_TIME_EXIT"
                        if position.get("trade_style") == "DAY"
                        else "SWING_HOLD_DEADLINE"
                    )
            if exit_reason is None:
                remaining.append(position)
                continue
            proceeds = round(bid * int(position.get("quantity", 1)) * 100, 2)
            realized = _book_close(state, position, proceeds)
            activation = _activate_green_lock(
                state,
                now=current,
                strategy_variant=_green_lock_strategy(config, portfolio_path),
            )
            if activation is not None:
                _append_event(event_log_path, activation)
            closed = {
                **position,
                "status": "CLOSED",
                "exit_at": current.astimezone(UTC).isoformat(),
                "exit_price": round(bid, 4),
                "exit_proceeds": proceeds,
                "exit_reason": exit_reason,
                "fill_assumed": assumed_tp,
                "realized_pnl": realized,
                "return_percent": round(
                    (bid - float(position["entry_price"])) / float(position["entry_price"]) * 100,
                    2,
                ),
            }
            state["recent_closed_positions"].append(closed)
            state["recent_closed_positions"] = state["recent_closed_positions"][-50:]
            state["closed_trade_count"] = int(state["closed_trade_count"]) + 1
            event = {
                "event": "PAPER_EXIT",
                **{
                    key: closed.get(key)
                    for key in ("expiration", "strike", "option_type", "quantity")
                },
                "timestamp": closed["exit_at"],
                "paper_id": closed["paper_id"],
                "symbol": closed["symbol"],
                "fill_side": "ASSUMED_RESTING_LIMIT" if assumed_tp else "SELL_AT_BID",
                "fill_assumed": assumed_tp,
                "take_profit_evidence": dict(evidence),
                **(
                    {"winner_management": dict(position["winner_management"])}
                    if winner is not None
                    else {}
                ),
                "fill_price": closed["exit_price"],
                "exit_reason": exit_reason,
                "realized_pnl": realized,
                "return_percent": closed["return_percent"],
            }
            events.append(event)
            _append_event(event_log_path, event)
        state["open_positions"] = remaining
        _revalue(state)
        state["updated_at"] = current.astimezone(UTC).isoformat()
        write = _save_state(portfolio_path, state)
        return {
            "status": "EXITED" if events else "ATTENTION" if attention else "MONITORED",
            "paper_events": events,
            "attention": attention,
            "open_positions": state["open_positions"],
            "portfolio": paper_summary(state),
            "persistent_write": write,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }


def close_paper_position(
    paper_id: str,
    *,
    bid: float,
    quote_updated_at: str,
    reason: str,
    config: TradingConfig,
    portfolio_path: Path,
    event_log_path: Path,
    now: datetime | None = None,
    assumed_fill_evidence: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    assumed = assumed_fill_evidence is not None
    if assumed and (
        reason != "USER_APPROVED_ASSUMED_TAKE_PROFIT"
        or config.get("PAPER_TRADING_ENABLED") is not True
        or assumed_fill_evidence.get("user_approved") is not True
    ):
        return {"status": "BLOCKED", "reasons": ["assumed_fill_not_authorized"], "closed": False}
    if (
        not math.isfinite(bid)
        or bid < 0
        or (not assumed and not _quote_is_fresh(quote_updated_at, now=current))
    ):
        return {"status": "BLOCKED", "reasons": ["invalid_or_stale_exit_quote"], "closed": False}
    with _exclusive_lock(portfolio_path):
        state = load_paper_portfolio(
            portfolio_path,
            starting_cash=float(config.get("PAPER_STARTING_CASH")),
            now=current,
        )
        position = next(
            (item for item in state["open_positions"] if item.get("paper_id") == paper_id), None
        )
        if position is None:
            return {"status": "BLOCKED", "reasons": ["paper_position_not_found"], "closed": False}
        proceeds = round(bid * int(position.get("quantity", 1)) * 100, 2)
        realized = _book_close(state, position, proceeds)
        activation = _activate_green_lock(
            state,
            now=current,
            strategy_variant=_green_lock_strategy(config, portfolio_path),
        )
        if activation is not None:
            _append_event(event_log_path, activation)
        closed = {
            **position,
            "status": "CLOSED",
            "exit_at": current.astimezone(UTC).isoformat(),
            "exit_price": round(bid, 4),
            "exit_proceeds": proceeds,
            "exit_reason": reason,
            "realized_pnl": realized,
            "return_percent": round(
                (bid - float(position["entry_price"])) / float(position["entry_price"]) * 100,
                2,
            ),
        }
        if assumed:
            closed["fill_assumption"] = dict(assumed_fill_evidence)
            closed["fill_confirmed"] = False
        state["open_positions"] = [
            item for item in state["open_positions"] if item.get("paper_id") != paper_id
        ]
        state["recent_closed_positions"].append(closed)
        state["recent_closed_positions"] = state["recent_closed_positions"][-50:]
        state["closed_trade_count"] = int(state["closed_trade_count"]) + 1
        _revalue(state)
        state["updated_at"] = current.astimezone(UTC).isoformat()
        write = _save_state(portfolio_path, state)
        event = {
            "event": "PAPER_EXIT",
            **{key: closed.get(key) for key in ("expiration", "strike", "option_type", "quantity")},
            "timestamp": closed["exit_at"],
            "paper_id": paper_id,
            "symbol": closed["symbol"],
            "fill_side": "ASSUMED_RESTING_LIMIT" if assumed else "SELL_AT_BID",
            "fill_price": closed["exit_price"],
            "exit_reason": reason,
            "realized_pnl": realized,
            "return_percent": closed["return_percent"],
        }
        if assumed:
            event["fill_assumption"] = dict(assumed_fill_evidence)
            event["fill_confirmed"] = False
        _append_event(event_log_path, event)
        return {
            "status": "CLOSED",
            "closed": True,
            "position": closed,
            "event": event,
            "portfolio": paper_summary(state),
            "persistent_write": write,
        }


def paper_summary(state: Mapping[str, Any]) -> dict[str, Any]:
    return {
        **({"strategy_epoch": state["strategy_epoch"]} if state.get("strategy_epoch") else {}),
        **(
            {"strategy_variant": GREEN_LOCK_VARIANT, "mode": "PAPER"}
            if state.get("strategy_variant") == GREEN_LOCK_VARIANT
            else {}
        ),
        "daily_pnl": paper_account_metrics(state)["daily_pnl"],
        "open_stop_risk": paper_account_metrics(state)["open_stop_risk"],
        "estimated_execution_costs": round(float(state.get("estimated_execution_costs", 0)), 2),
        "max_drawdown_dollars": state.get("max_drawdown_dollars", 0),
        "winning_trades": state.get("winning_trades", 0),
        "gross_wins": state.get("gross_wins", 0),
        "gross_losses": state.get("gross_losses", 0),
        "starting_cash": round(float(state.get("starting_cash", 0)), 2),
        "cash": round(float(state.get("cash", 0)), 2),
        "equity": round(float(state.get("equity", 0)), 2),
        "realized_pnl": round(float(state.get("realized_pnl", 0)), 2),
        "unrealized_pnl": round(float(state.get("unrealized_pnl", 0)), 2),
        "total_return_percent": round(
            (float(state.get("equity", 0)) - float(state.get("starting_cash", 0)))
            / float(state.get("starting_cash", 1))
            * 100,
            2,
        ),
        "open_positions": len(state.get("open_positions", [])),
        "closed_trades": int(state.get("closed_trade_count", 0)),
        "day": dict(state.get("day", {})),
    }
