"""Bounded public Coinbase Exchange market-data snapshot for ETH-USD.

This module deliberately exposes no account, authentication, order, scheduler, or
WebSocket functionality.  It makes at most three public HTTPS GET requests for one
fixed product and returns a compact, normalized research snapshot.

Coinbase Exchange documents these endpoints and response shapes at:
https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-ticker
https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-book
https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles
"""

from __future__ import annotations

import asyncio
import inspect
import json
import math
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from tools.crypto_symbols import validate_symbol

VENUE = "COINBASE_EXCHANGE"
SYMBOL = "ETH-USD"
_HOST = "https://api.exchange.coinbase.com"
_TIMEOUT_SECONDS = 10.0
_MAX_RESPONSE_BYTES = 1_000_000
_MAX_REQUESTS = 3
_MAX_LEVELS_PER_SIDE = 50
_CANDLE_SECONDS = 300
_MAX_RAW_CANDLE_ROWS = 500
_MAX_RETAINED_CANDLES = 300
# 63 five-minute bars provide 20 completed, aligned fifteen-minute groups plus
# the leading bars needed to establish the first group boundary.
_MIN_COMPLETED_CANDLES = 63
_MAX_QUOTE_AGE = timedelta(seconds=60)
_MAX_FUTURE_SKEW = timedelta(seconds=5)

Transport = Callable[[str], Awaitable[Any] | Any]


class CryptoMarketDataValidationError(ValueError):
    """A public exchange response is not safe to use for paper research."""


def _utc(value: datetime | None) -> datetime:
    current = value or datetime.now(UTC)
    if current.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    return current.astimezone(UTC)


def _iso(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _timestamp(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise CryptoMarketDataValidationError(f"{field} must be an ISO-8601 timestamp")
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise CryptoMarketDataValidationError(f"{field} must be an ISO-8601 timestamp") from exc
    if result.tzinfo is None:
        raise CryptoMarketDataValidationError(f"{field} must include an offset")
    return result.astimezone(UTC)


def _positive_number(value: Any, field: str) -> float:
    if isinstance(value, bool):
        raise CryptoMarketDataValidationError(f"{field} must be a positive finite number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise CryptoMarketDataValidationError(f"{field} must be a positive finite number") from exc
    if not math.isfinite(result) or result <= 0:
        raise CryptoMarketDataValidationError(f"{field} must be a positive finite number")
    return result


def _price(value: Any, field: str) -> str:
    _positive_number(value, field)
    # Prices stay strings to avoid adding binary rounding to an exchange quote.
    return value.strip() if isinstance(value, str) else str(value)


def _unavailable(current: datetime, reason: str, symbol=SYMBOL) -> dict[str, Any]:
    return {
        "status": "UNAVAILABLE",
        "venue": VENUE,
        "symbol": symbol,
        "as_of": _iso(current),
        "reason": reason,
        "quality": {"status": "UNAVAILABLE", "reason": reason},
    }


def _default_transport(url: str) -> Any:
    request = Request(
        url, headers={"Accept": "application/json", "User-Agent": "Robinhood-Agentic/1.0"}
    )
    try:
        with urlopen(request, timeout=_TIMEOUT_SECONDS) as response:  # nosec B310: fixed HTTPS host
            length = response.headers.get("Content-Length")
            if length is not None and int(length) > _MAX_RESPONSE_BYTES:
                raise CryptoMarketDataValidationError("response_too_large")
            raw = response.read(_MAX_RESPONSE_BYTES + 1)
    except (HTTPError, URLError, TimeoutError) as exc:
        raise ConnectionError("public_exchange_request_failed") from exc
    if len(raw) > _MAX_RESPONSE_BYTES:
        raise CryptoMarketDataValidationError("response_too_large")
    try:
        return json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CryptoMarketDataValidationError("invalid_json") from exc


async def _fetch(transport: Transport, url: str) -> Any:
    if inspect.iscoroutinefunction(transport):
        return await asyncio.wait_for(transport(url), timeout=_TIMEOUT_SECONDS)
    result = await asyncio.wait_for(asyncio.to_thread(transport, url), timeout=_TIMEOUT_SECONDS)
    if inspect.isawaitable(result):
        return await asyncio.wait_for(result, timeout=_TIMEOUT_SECONDS)
    return result


def _quote(payload: Any, *, now: datetime) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise CryptoMarketDataValidationError("ticker must be an object")
    updated_at = _timestamp(payload.get("time"), "ticker.time")
    if updated_at > now + _MAX_FUTURE_SKEW:
        raise CryptoMarketDataValidationError("quote_timestamp_in_future")
    age = now - updated_at
    if age > _MAX_QUOTE_AGE:
        raise CryptoMarketDataValidationError("stale_quote")
    bid = _positive_number(payload.get("bid"), "ticker.bid")
    ask = _positive_number(payload.get("ask"), "ticker.ask")
    price = _positive_number(payload.get("price"), "ticker.price")
    if bid >= ask:
        raise CryptoMarketDataValidationError("crossed_or_locked_quote")
    return {
        "bid": bid,
        "ask": ask,
        "price": price,
        "updated_at": _iso(updated_at),
        "age_seconds": max(0.0, age.total_seconds()),
    }


def _book_levels(value: Any, *, side: str) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        raise CryptoMarketDataValidationError(f"book.{side} must be a list")
    result: list[dict[str, Any]] = []
    previous: float | None = None
    for index, row in enumerate(value[:_MAX_LEVELS_PER_SIDE]):
        if not isinstance(row, list) or len(row) < 2:
            raise CryptoMarketDataValidationError(f"book.{side}[{index}] must be a level")
        price = _price(row[0], f"book.{side}[{index}].price")
        quantity = _positive_number(row[1], f"book.{side}[{index}].quantity")
        numeric_price = float(price)
        if previous is not None:
            out_of_order = (side == "bids" and numeric_price >= previous) or (
                side == "asks" and numeric_price <= previous
            )
            if out_of_order:
                raise CryptoMarketDataValidationError(f"book.{side} levels are out of order")
        previous = numeric_price
        result.append({"price": price, "quantity": quantity})
    if not result:
        raise CryptoMarketDataValidationError(f"book.{side} is empty")
    return result


def _book(payload: Any, *, receipt_time: datetime, symbol=SYMBOL) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise CryptoMarketDataValidationError("book must be an object")
    bids = _book_levels(payload.get("bids"), side="bids")
    asks = _book_levels(payload.get("asks"), side="asks")
    if float(bids[0]["price"]) >= float(asks[0]["price"]):
        raise CryptoMarketDataValidationError("crossed_or_locked_book")
    source = "receipt_time"
    updated_at = receipt_time
    if payload.get("time") is not None:
        updated_at = _timestamp(payload.get("time"), "book.time")
        if updated_at > receipt_time + _MAX_FUTURE_SKEW:
            raise CryptoMarketDataValidationError("book_timestamp_in_future")
        source = "exchange_time"
    return {
        "symbol": symbol,
        "updated_at": _iso(updated_at),
        "timestamp_source": source,
        "bids": bids,
        "asks": asks,
    }


def _candles(payload: Any, *, now: datetime, allow_zero_volume=False) -> list[dict[str, Any]]:
    if not isinstance(payload, list) or len(payload) > _MAX_RAW_CANDLE_ROWS:
        raise CryptoMarketDataValidationError("candles must contain at most 500 rows")
    parsed: list[tuple[datetime, dict[str, Any]]] = []
    for index, row in enumerate(payload):
        if not isinstance(row, list) or len(row) < 6:
            raise CryptoMarketDataValidationError(f"candles[{index}] must contain six values")
        try:
            start = datetime.fromtimestamp(_positive_number(row[0], f"candles[{index}].time"), UTC)
        except (OverflowError, OSError, ValueError) as exc:
            raise CryptoMarketDataValidationError(f"candles[{index}].time is invalid") from exc
        if start > now:
            raise CryptoMarketDataValidationError("future_candle")
        end = start + timedelta(seconds=_CANDLE_SECONDS)
        low = _positive_number(row[1], f"candles[{index}].low")
        high = _positive_number(row[2], f"candles[{index}].high")
        opening = _positive_number(row[3], f"candles[{index}].open")
        close = _positive_number(row[4], f"candles[{index}].close")
        volume = float(row[5])
        if (
            isinstance(row[5], bool)
            or not math.isfinite(volume)
            or volume < 0
            or (volume == 0 and not allow_zero_volume)
        ):
            raise CryptoMarketDataValidationError("invalid_candle_volume")
        if low > high or not low <= opening <= high or not low <= close <= high:
            raise CryptoMarketDataValidationError(f"candles[{index}] has inconsistent OHLC")
        parsed.append(
            (
                start,
                {
                    "starts_at": _iso(start),
                    "ends_at": _iso(end),
                    "open": opening,
                    "high": high,
                    "low": low,
                    "close": close,
                    "volume": volume,
                },
            )
        )
    parsed.sort(key=lambda item: item[0])
    for (prior, _), (current, _) in zip(parsed, parsed[1:], strict=False):
        if current - prior != timedelta(seconds=_CANDLE_SECONDS):
            raise CryptoMarketDataValidationError("candle_gap_or_duplicate")
    completed = [row for start, row in parsed if start + timedelta(seconds=_CANDLE_SECONDS) <= now]
    if len(completed) < _MIN_COMPLETED_CANDLES:
        raise CryptoMarketDataValidationError("insufficient_completed_candles")
    # Coinbase currently returns 350 rows for an unspecified range despite its
    # documented 300-candle maximum.  The public adapter accepts a bounded 500
    # rows but intentionally exposes at most the latest 300 completed bars.
    return completed[-_MAX_RETAINED_CANDLES:]


async def fetch_quote(
    now: datetime | None = None, transport: Transport | None = None, symbol=SYMBOL
) -> dict[str, float | str]:
    """Fetch and validate only the current public ETH-USD ticker quote.

    This makes exactly one unauthenticated GET request.  It raises a deliberately
    generic ``ValueError`` on any provider, freshness, or shape failure so callers
    do not treat a partial quote as usable market data.
    """
    symbol = validate_symbol(symbol)
    fetcher = transport or _default_transport
    try:
        raw = await _fetch(fetcher, f"{_HOST}/products/{symbol}/ticker")
        # Receipt time must be sampled after the request, unless a deterministic
        # clock was supplied by the caller.
        quote = _quote(raw, now=_utc(now))
    except Exception as exc:
        raise ValueError("quote_unavailable") from exc
    return {**{key: quote[key] for key in ("bid", "ask", "price", "updated_at")}, "symbol": symbol}


async def fetch_snapshot(
    now: datetime | None = None, transport: Transport | None = None, symbol=SYMBOL
) -> dict[str, Any]:
    """Fetch one bounded, public ETH-USD snapshot.  It never polls or trades.

    ``transport`` receives only one of the three fixed public URLs and may be sync
    or async; it exists for deterministic tests.  Any provider, timeout, or parsing
    failure returns ``UNAVAILABLE`` rather than a partial snapshot.
    """
    symbol = validate_symbol(symbol)
    fetcher = transport or _default_transport
    urls = (
        f"{_HOST}/products/{symbol}/ticker",
        f"{_HOST}/products/{symbol}/book?level=2",
        f"{_HOST}/products/{symbol}/candles?granularity=300",
    )
    assert len(urls) == _MAX_REQUESTS
    try:
        ticker_raw, book_raw, candles_raw = await asyncio.gather(
            *(_fetch(fetcher, url) for url in urls)
        )
        # This is the actual post-request receipt time in production; callers can
        # inject ``now`` solely to make validation deterministic in tests/replay.
        current = _utc(now)
        quote = _quote(ticker_raw, now=current)
        book = _book(book_raw, receipt_time=current, symbol=symbol)
        candles = _candles(candles_raw, now=current)
    except (CryptoMarketDataValidationError, TimeoutError) as exc:
        return _unavailable(_utc(now), str(exc), symbol)
    except Exception as exc:
        return _unavailable(_utc(now), f"provider_error:{type(exc).__name__}", symbol)
    quote["symbol"] = symbol
    quote_age = quote.pop("age_seconds")
    return {
        "status": "OK",
        "venue": VENUE,
        "symbol": symbol,
        "as_of": _iso(current),
        "quote": quote,
        "candles_5m": candles,
        "book": book,
        "quality": {
            "status": "OK",
            "request_count": _MAX_REQUESTS,
            "quote_age_seconds": quote_age,
            "completed_candle_count": len(candles),
            "candle_interval_seconds": _CANDLE_SECONDS,
            "book_levels_per_side": {"bids": len(book["bids"]), "asks": len(book["asks"])},
        },
    }
