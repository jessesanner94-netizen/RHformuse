"""Deterministic portfolio and option-premium risk checks.

Hard limits come exclusively from CONFIG.md. Historical CVaR analytics use skfolio when a return
matrix is supplied; a missing matrix is reported rather than replaced with fabricated market data.
"""

from __future__ import annotations

import argparse
import json
import math
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tools.config import RISK_REQUIRED_FIELDS, TradingConfig, load_config

ACCOUNT_REQUIRED_FIELDS = (
    "account_value",
    "account_value_start_of_day",
    "buying_power",
    "daily_pnl",
    "open_premium_at_risk",
    "open_position_count",
    "new_positions_today",
)

CANDIDATE_REQUIRED_FIELDS = (
    "symbol",
    "premium_at_risk",
    "quantity",
    "holds_through_earnings",
    "is_averaging_down",
    "protective_stop_planned",
)


@dataclass(frozen=True)
class RiskDecision:
    status: str
    reasons: tuple[str, ...]
    metrics: Mapping[str, Any]
    analytics: Mapping[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "reasons": list(self.reasons),
            "metrics": dict(self.metrics),
            "analytics": dict(self.analytics),
        }


def _finite_number(payload: Mapping[str, Any], field: str) -> float | None:
    value = payload.get(field)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    if value != value or value in (float("inf"), float("-inf")):
        return None
    return value


def planned_entry_budget(account: Mapping[str, Any], config: TradingConfig) -> dict[str, float]:
    """Budget additional loss to software stops, without treating stops as guarantees."""

    def number(value: Any) -> float:
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
        ):
            raise ValueError("invalid planned-risk input")
        return float(value)

    stop = number(config.get("STOP_LOSS_PERCENT")) / 100
    buffer = number(config.get("ENTRY_EXIT_COST_BUFFER_DOLLARS"))
    start = number(account.get("account_value_start_of_day"))
    daily_pnl = number(account.get("daily_pnl"))
    buying_power = number(account.get("buying_power"))
    open_premium = number(account.get("open_premium_at_risk"))
    open_stop_risk = number(account.get("open_stop_risk", open_premium * stop))
    limit = min(
        number(config.get("MAX_DAILY_LOSS_DOLLARS")),
        start * number(config.get("MAX_DAILY_LOSS_PERCENT")) / 100,
    )
    if not 0 < stop <= 1 or buffer < 0 or start <= 0 or limit <= 0 or open_stop_risk < 0:
        raise ValueError("invalid planned-risk configuration")
    remaining = max(0.0, limit - max(-daily_pnl, 0.0) - open_stop_risk)
    risk_cap = max(0.0, (remaining - buffer) / stop)
    ceiling = max(
        0.0,
        min(
            risk_cap,
            buying_power - buffer / 2,
            number(config.get("MAX_SINGLE_POSITION_PREMIUM_AT_RISK")),
            number(account.get("account_value"))
            * number(config.get("MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT"))
            / 100,
        ),
    )
    return {
        "daily_loss_budget": round(limit, 2),
        "open_stop_risk": round(open_stop_risk, 2),
        "remaining_planned_loss_budget": round(remaining, 2),
        "entry_exit_cost_buffer": buffer,
        "premium_ceiling": math.floor(ceiling * 100 + 1e-8) / 100,
        "stop_fraction": stop,
    }


def _historical_analytics(payload: Mapping[str, Any] | None) -> dict[str, Any]:
    if not payload:
        return {
            "status": "INSUFFICIENT_DATA",
            "reason": "historical_returns_not_supplied",
        }
    returns = payload.get("asset_returns")
    weights = payload.get("weights")
    confidence_level = payload.get("confidence_level", 0.95)
    if not isinstance(returns, list) or not returns or not isinstance(weights, list):
        return {
            "status": "INSUFFICIENT_DATA",
            "reason": "invalid_historical_returns_payload",
        }
    try:
        import numpy as np
        import skfolio
        from skfolio.measures import cvar

        return_matrix = np.asarray(returns, dtype=float)
        weight_vector = np.asarray(weights, dtype=float)
        if return_matrix.ndim != 2 or weight_vector.ndim != 1:
            raise ValueError("returns must be a matrix and weights must be a vector")
        if return_matrix.shape[1] != weight_vector.shape[0]:
            raise ValueError("return columns must match the number of weights")
        if return_matrix.shape[0] < 2:
            raise ValueError("at least two return observations are required")
        if not np.isclose(weight_vector.sum(), 1.0):
            raise ValueError("weights must sum to 1")
        portfolio_returns = return_matrix @ weight_vector
        correlation = np.corrcoef(return_matrix, rowvar=False)
        max_abs_correlation = 0.0
        if correlation.ndim == 2 and correlation.shape[0] > 1:
            mask = ~np.eye(correlation.shape[0], dtype=bool)
            finite_values = np.abs(correlation[mask][np.isfinite(correlation[mask])])
            if finite_values.size:
                max_abs_correlation = float(finite_values.max())
        return {
            "status": "CALCULATED",
            "engine": f"skfolio {skfolio.__version__}",
            "observations": int(return_matrix.shape[0]),
            "assets": int(return_matrix.shape[1]),
            "confidence_level": float(confidence_level),
            "historical_cvar": float(cvar(portfolio_returns, beta=float(confidence_level))),
            "max_absolute_pairwise_correlation": max_abs_correlation,
        }
    except (ImportError, TypeError, ValueError) as exc:
        return {"status": "INSUFFICIENT_DATA", "reason": f"analytics_error:{exc}"}


def evaluate_risk(
    account: Mapping[str, Any],
    candidate: Mapping[str, Any],
    config: TradingConfig,
    *,
    historical: Mapping[str, Any] | None = None,
) -> RiskDecision:
    missing_config = config.missing(RISK_REQUIRED_FIELDS)
    if missing_config:
        return RiskDecision(
            "INSUFFICIENT_DATA",
            tuple(f"unresolved_config:{name}" for name in missing_config),
            {},
            _historical_analytics(historical),
        )

    missing_account = [field for field in ACCOUNT_REQUIRED_FIELDS if account.get(field) is None]
    missing_candidate = [
        field for field in CANDIDATE_REQUIRED_FIELDS if candidate.get(field) is None
    ]
    if missing_account or missing_candidate:
        reasons = [f"missing_account_field:{field}" for field in sorted(missing_account)]
        reasons.extend(f"missing_candidate_field:{field}" for field in sorted(missing_candidate))
        return RiskDecision(
            "INSUFFICIENT_DATA", tuple(reasons), {}, _historical_analytics(historical)
        )

    invalid_account = [
        field for field in ACCOUNT_REQUIRED_FIELDS if _finite_number(account, field) is None
    ]
    premium = _finite_number(candidate, "premium_at_risk")
    quantity = _finite_number(candidate, "quantity")
    if invalid_account or premium is None or quantity is None:
        reasons = [f"invalid_account_field:{field}" for field in sorted(invalid_account)]
        if premium is None:
            reasons.append("invalid_candidate_field:premium_at_risk")
        if quantity is None:
            reasons.append("invalid_candidate_field:quantity")
        return RiskDecision(
            "INSUFFICIENT_DATA", tuple(reasons), {}, _historical_analytics(historical)
        )

    account_value = float(account["account_value"])
    start_value = float(account["account_value_start_of_day"])
    buying_power = float(account["buying_power"])
    daily_pnl = float(account["daily_pnl"])
    open_risk = float(account["open_premium_at_risk"])
    open_count_value = float(account["open_position_count"])
    new_positions_today_value = float(account["new_positions_today"])
    premium = float(premium)
    quantity = float(quantity)

    invalid_values: list[str] = []
    if account_value <= 0:
        invalid_values.append("account_value_must_be_positive")
    if start_value <= 0:
        invalid_values.append("account_value_start_of_day_must_be_positive")
    if (
        buying_power < 0
        or open_risk < 0
        or open_count_value < 0
        or not open_count_value.is_integer()
        or new_positions_today_value < 0
        or not new_positions_today_value.is_integer()
        or premium <= 0
        or quantity <= 0
        or not quantity.is_integer()
    ):
        invalid_values.append("risk_inputs_out_of_range")
    if invalid_values:
        return RiskDecision(
            "INSUFFICIENT_DATA",
            tuple(invalid_values),
            {},
            _historical_analytics(historical),
        )
    if not isinstance(candidate.get("holds_through_earnings"), bool):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("invalid_candidate_field:holds_through_earnings",),
            {},
            _historical_analytics(historical),
        )
    if not isinstance(candidate.get("is_averaging_down"), bool) or not isinstance(
        candidate.get("protective_stop_planned"), bool
    ):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("invalid_candidate_boolean_risk_field",),
            {},
            _historical_analytics(historical),
        )

    numeric_config_fields = (
        "MAX_DAILY_LOSS_DOLLARS",
        "MAX_DAILY_LOSS_PERCENT",
        "MAX_OPEN_POSITIONS",
        "MAX_CONTRACTS_PER_POSITION",
        "MAX_NEW_POSITIONS_PER_DAY",
        "MAX_PORTFOLIO_PREMIUM_AT_RISK",
        "MIN_SINGLE_POSITION_PREMIUM_AT_RISK",
        "MAX_SINGLE_POSITION_PREMIUM_AT_RISK",
        "MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT",
        "EARNINGS_RISK_MULTIPLIER",
    )
    boolean_config_fields = (
        "EARNINGS_HOLD_ALLOWED",
        "REQUIRE_EXPLICIT_EARNINGS_HOLD_DECISION",
        "NO_AVERAGING_DOWN",
        "REQUIRE_PROTECTIVE_STOP",
    )
    if any(isinstance(config.get(field), bool) for field in numeric_config_fields) or any(
        not isinstance(config.get(field), bool) for field in boolean_config_fields
    ):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("invalid_risk_config_type",),
            {},
            _historical_analytics(historical),
        )
    try:
        max_loss_dollars = float(config.get("MAX_DAILY_LOSS_DOLLARS"))
        max_loss_percent = float(config.get("MAX_DAILY_LOSS_PERCENT"))
        max_positions_raw = config.risk_limit("MAX_OPEN_POSITIONS")
        max_contracts_raw = float(config.get("MAX_CONTRACTS_PER_POSITION"))
        max_new_positions_raw = float(config.get("MAX_NEW_POSITIONS_PER_DAY"))
        portfolio_cap = config.risk_limit("MAX_PORTFOLIO_PREMIUM_AT_RISK")
        single_floor = float(config.get("MIN_SINGLE_POSITION_PREMIUM_AT_RISK"))
        single_cap = float(config.get("MAX_SINGLE_POSITION_PREMIUM_AT_RISK"))
        single_percent = float(config.get("MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT"))
        earnings_multiplier = float(config.get("EARNINGS_RISK_MULTIPLIER"))
    except (OverflowError, TypeError, ValueError):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("invalid_numeric_risk_config",),
            {},
            _historical_analytics(historical),
        )

    risk_config_values = (
        max_loss_dollars,
        max_loss_percent,
        max_positions_raw,
        max_contracts_raw,
        max_new_positions_raw,
        portfolio_cap,
        single_floor,
        single_cap,
        single_percent,
        earnings_multiplier,
    )
    if not all(math.isfinite(value) for value in risk_config_values if value is not None):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("non_finite_risk_config",),
            {},
            _historical_analytics(historical),
        )
    if not all(
        value.is_integer()
        for value in (max_positions_raw, max_contracts_raw, max_new_positions_raw)
        if value is not None
    ):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("position_and_trade_limits_must_be_integers",),
            {},
            _historical_analytics(historical),
        )
    max_positions = int(max_positions_raw) if max_positions_raw is not None else None
    max_contracts = int(max_contracts_raw)
    max_new_positions = int(max_new_positions_raw)
    open_count = int(open_count_value)
    new_positions_today = int(new_positions_today_value)
    if (
        min(
            value
            for value in (
                max_loss_dollars,
                max_loss_percent,
                max_positions,
                max_contracts,
                max_new_positions,
                portfolio_cap,
                single_floor,
                single_cap,
            )
            if value is not None
        )
        <= 0
    ):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("non_positive_risk_config",),
            {},
            _historical_analytics(historical),
        )
    if not 0 < single_percent <= 100 or not 0 < earnings_multiplier <= 1:
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("invalid_percentage_or_multiplier_config",),
            {},
            _historical_analytics(historical),
        )

    reasons: list[str] = []
    try:
        planned_budget = planned_entry_budget(account, config)
    except (ValueError, TypeError, KeyError):
        return RiskDecision(
            "INSUFFICIENT_DATA",
            ("invalid_planned_daily_risk_budget",),
            {},
            _historical_analytics(historical),
        )
    planned_loss = (
        premium * planned_budget["stop_fraction"] + planned_budget["entry_exit_cost_buffer"]
    )
    if planned_loss > planned_budget["remaining_planned_loss_budget"] + 1e-8:
        reasons.append("planned_stop_loss_exceeds_remaining_daily_budget")
    if premium + planned_budget["entry_exit_cost_buffer"] / 2 > buying_power + 1e-8:
        reasons.append("insufficient_buying_power_with_costs")
    loss_dollars = max(-daily_pnl, 0.0)
    loss_percent = (loss_dollars / start_value) * 100
    if loss_dollars >= max_loss_dollars:
        reasons.append("daily_loss_dollar_limit_reached")
    if loss_percent >= max_loss_percent:
        reasons.append("daily_loss_percent_limit_reached")
    if max_positions is not None and open_count + 1 > max_positions:
        reasons.append("max_open_positions_exceeded")
    if quantity > max_contracts:
        reasons.append("max_contracts_per_position_exceeded")
    if new_positions_today + 1 > max_new_positions:
        reasons.append("max_new_positions_per_day_exceeded")
    if premium > buying_power:
        reasons.append("insufficient_buying_power")
    if config.get("NO_AVERAGING_DOWN") is True and candidate.get("is_averaging_down") is True:
        reasons.append("averaging_down_prohibited")
    if (
        config.get("REQUIRE_PROTECTIVE_STOP") is True
        and candidate.get("protective_stop_planned") is not True
    ):
        reasons.append("protective_stop_required")

    holds_through_earnings = candidate.get("holds_through_earnings") is True
    adjusted_single_cap = min(single_cap, account_value * single_percent / 100)
    if holds_through_earnings:
        if config.get("EARNINGS_HOLD_ALLOWED") is not True:
            reasons.append("earnings_holds_disabled")
        if (
            config.get("REQUIRE_EXPLICIT_EARNINGS_HOLD_DECISION") is True
            and candidate.get("earnings_decision") != "HOLD THROUGH EARNINGS"
        ):
            reasons.append("explicit_earnings_hold_decision_missing")
        adjusted_single_cap *= earnings_multiplier

    prospective_risk = open_risk + premium
    if premium < single_floor:
        reasons.append("single_position_premium_minimum_not_met")
    if premium > adjusted_single_cap:
        reasons.append("single_position_premium_limit_exceeded")
    if portfolio_cap is not None and prospective_risk > portfolio_cap:
        reasons.append("portfolio_premium_limit_exceeded")

    metrics = {
        **planned_budget,
        "candidate_planned_stop_loss": round(planned_loss, 2),
        "daily_loss_dollars": round(loss_dollars, 2),
        "daily_loss_percent": round(loss_percent, 4),
        "candidate_premium_at_risk": round(premium, 2),
        "minimum_single_position_premium": round(single_floor, 2),
        "effective_single_position_cap": round(adjusted_single_cap, 2),
        "prospective_portfolio_premium_at_risk": round(prospective_risk, 2),
        "prospective_open_positions": open_count + 1,
        "candidate_contract_quantity": int(quantity),
        "prospective_new_positions_today": new_positions_today + 1,
    }
    return RiskDecision(
        "BLOCKED" if reasons else "ALLOWED",
        tuple(reasons),
        metrics,
        _historical_analytics(historical),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("CONFIG.md"))
    parser.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    result = evaluate_risk(
        payload.get("account", {}),
        payload.get("candidate", {}),
        load_config(args.config),
        historical=payload.get("historical"),
    )
    print(json.dumps(result.as_dict(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
