"""Opt-in JEV settings for the TypeSafe evaluation API.

These are local cost and transport guardrails, not provider-published limits.
Missing feature switches are deliberately disabled. The API key is never stored here.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

_SWITCHES = {
    "enabled": ("ENABLE_JEV", False),
    "shadow_mode": ("JEV_SHADOW_MODE", True),
    "escalation_enabled": ("ENABLE_JEV_ESCALATION", False),
    "level2_enabled": ("ENABLE_LEVEL2", False),
    "orderflow_features_enabled": ("ENABLE_ORDERFLOW_FEATURES", False),
    "orderflow_jev_enabled": ("ENABLE_ORDERFLOW_JEV", False),
    "multi_watch_enabled": ("ENABLE_MULTI_WATCH", False),
    "dynamic_luna_escalation_enabled": ("ENABLE_DYNAMIC_LUNA_ESCALATION", False),
}


@dataclass(frozen=True)
class JevConfig:
    enabled: bool = False
    shadow_mode: bool = True
    escalation_enabled: bool = False
    level2_enabled: bool = False
    orderflow_features_enabled: bool = False
    orderflow_jev_enabled: bool = False
    multi_watch_enabled: bool = False
    dynamic_luna_escalation_enabled: bool = False
    # Explicit, conservative client defaults; no assertion about TypeSafe's quotas.
    max_calls_per_minute: int = 6
    max_calls_per_day: int = 1_000
    timeout_seconds: float = 12.0
    max_retries: int = 2
    backoff_seconds: float = 0.5
    max_request_bytes: int = 65_536
    max_response_bytes: int = 65_536

    @classmethod
    def from_config(cls, config: Any) -> JevConfig:
        """Read a TradingConfig or mapping; reject malformed explicit values."""
        if isinstance(config, Mapping):
            source = config
        elif isinstance(getattr(config, "values", None), Mapping):
            source = config.values
        else:
            raise TypeError("JEV settings require TradingConfig or a mapping")

        values: dict[str, Any] = {}
        for field, (name, default) in _SWITCHES.items():
            value = source.get(name, default)
            if not isinstance(value, bool):
                raise ValueError(f"{name} must be true or false")
            values[field] = value

        for field, name, default, minimum, maximum in (
            ("max_calls_per_minute", "JEV_MAX_CALLS_PER_MINUTE", 6, 1, 60),
            ("max_calls_per_day", "JEV_MAX_CALLS_PER_DAY", 1_000, 1, 10_000),
            ("max_retries", "JEV_MAX_RETRIES", 2, 0, 5),
            ("max_request_bytes", "JEV_MAX_REQUEST_BYTES", 65_536, 1_024, 1_048_576),
            ("max_response_bytes", "JEV_MAX_RESPONSE_BYTES", 65_536, 1_024, 1_048_576),
        ):
            value = source.get(name, default)
            if (
                isinstance(value, bool)
                or not isinstance(value, int)
                or not minimum <= value <= maximum
            ):
                raise ValueError(f"{name} must be an integer from {minimum} to {maximum}")
            values[field] = value

        for field, name, default, minimum, maximum in (
            ("timeout_seconds", "JEV_TIMEOUT_SECONDS", 12.0, 0.1, 60.0),
            ("backoff_seconds", "JEV_BACKOFF_SECONDS", 0.5, 0.0, 10.0),
        ):
            value = source.get(name, default)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or not minimum <= value <= maximum
            ):
                raise ValueError(f"{name} must be a finite number from {minimum} to {maximum}")
            values[field] = float(value)
        return cls(**values)
