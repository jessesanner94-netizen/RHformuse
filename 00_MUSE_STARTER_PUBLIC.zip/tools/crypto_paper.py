"""Independent ETH spot simulation: no brokerage/order interface exists in this module."""

from __future__ import annotations

import json
import math
import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from tools.crypto_symbols import validate_symbol

ET = ZoneInfo("America/New_York")


def stamp(value):
    parsed = (
        datetime.fromisoformat(value.replace("Z", "+00:00")) if isinstance(value, str) else value
    )
    if not isinstance(parsed, datetime) or parsed.tzinfo is None:
        raise ValueError("timezone required")
    return parsed.astimezone(UTC)


def amount(value, *, zero=False):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError("finite numerical amount required")
    value = float(value)
    if not math.isfinite(value) or value < 0 or (not zero and value == 0):
        raise ValueError("invalid amount")
    return value


def settings(config):
    names = {
        "cash": "CRYPTO_PAPER_STARTING_CASH",
        "notional": "CRYPTO_MAX_POSITION_DOLLARS",
        "stop": "CRYPTO_STOP_LOSS_PERCENT",
        "target": "CRYPTO_TAKE_PROFIT_PERCENT",
        "daily_loss": "CRYPTO_MAX_DAILY_LOSS_DOLLARS",
        "entries": "CRYPTO_MAX_ENTRIES_PER_DAY",
        "hold_minutes": "CRYPTO_MAX_HOLD_MINUTES",
        "spread": "CRYPTO_MAX_SPREAD_PERCENT",
    }
    values = {key: amount(config.get(name)) for key, name in names.items()}
    values["fee"] = amount(config.get("CRYPTO_PAPER_FEE_PERCENT_SIDE"), zero=True) / 100
    values["slippage"] = amount(config.get("CRYPTO_PAPER_SLIPPAGE_BPS_SIDE"), zero=True) / 10000
    if not (
        values["stop"] < 100
        and values["target"] < 100
        and values["fee"] < 1
        and values["slippage"] < 1
        and values["entries"].is_integer()
        and values["hold_minutes"] <= 1440
        and values["notional"] <= values["cash"]
    ):
        raise ValueError("invalid crypto paper settings")
    return values


def valid_quote(quote, now):
    bid, ask = amount(quote["bid"]), amount(quote["ask"])
    age = (stamp(now) - stamp(quote["updated_at"])).total_seconds()
    if bid > ask or not 0 <= age <= 60:
        raise ValueError("stale or crossed crypto quote")
    return bid, ask


class CryptoPaperStore:
    def __init__(self, path: Path, config):
        self.path = path
        self.config = config
        self.symbol = validate_symbol(config.get("CRYPTO_SYMBOL", "ETH-USD"))
        self.limits = settings(config)
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, 1):
                raise ValueError("unknown crypto schema")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS account (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT);
                CREATE TABLE IF NOT EXISTS events
                    (id INTEGER PRIMARY KEY, at TEXT NOT NULL,
                     kind TEXT NOT NULL, body TEXT NOT NULL);
                PRAGMA user_version=1;
            """)
            initial = {
                "mode": "PAPER_ONLY",
                "venue": config.get("CRYPTO_DATA_VENUE") or "COINBASE_EXCHANGE",
                "cash": self.limits["cash"],
                "position": None,
                "day": None,
                "watch": None,
                "last_model_at": None,
                "last_research_bar": None,
                "last_equity": self.limits["cash"],
            }
            db.execute("INSERT OR IGNORE INTO account VALUES (1,?)", (json.dumps(initial),))

    def connect(self):
        return sqlite3.connect(self.path, timeout=5)

    def read(self):
        with self.connect() as db:
            return json.loads(db.execute("SELECT body FROM account WHERE id=1").fetchone()[0])

    def event(self, kind, payload, now):
        with self.connect() as db:
            self._event(db, kind, payload, now)

    def _event(self, db, kind, payload, now):
        payload = {"symbol": self.symbol, **payload}
        db.execute(
            "INSERT INTO events(at,kind,body) VALUES (?,?,?)",
            (stamp(now).isoformat(), kind, json.dumps(payload, allow_nan=False)),
        )

    def _save(self, db, state):
        db.execute("UPDATE account SET body=? WHERE id=1", (json.dumps(state, allow_nan=False),))

    def _equity(self, state, bid):
        p = state["position"]
        return state["cash"] + (
            p["quantity"]
            * bid
            * (1 - self.limits["slippage"])
            * (1 - p.get("fee_ratio", self.limits["fee"]))
            if p
            else 0
        )

    def _day(self, state, now, bid):
        day = stamp(now).astimezone(ET).date().isoformat()
        if not state["day"] or state["day"]["date"] != day:
            # Last persisted equity prevents the first fresh quote from erasing an overnight gap.
            state["day"] = {
                "date": day,
                "start_equity": state["last_equity"],
                "entries": 0,
                "realized": 0.0,
                "net_green": False,
            }
        state["last_equity"] = self._equity(state, bid)

    def monitor(self, quote, now):
        bid, _ = valid_quote(quote, now)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            state = json.loads(db.execute("SELECT body FROM account WHERE id=1").fetchone()[0])
            p = state["position"]
            if quote.get("symbol", self.symbol) != self.symbol or (
                p and p["symbol"] != self.symbol
            ):
                raise ValueError("position_quote_symbol_mismatch")
            if p and quote.get("venue") and p.get("venue") != quote["venue"]:
                raise ValueError("position_quote_venue_mismatch")
            if p:
                p["fee_ratio"] = max(p.get("fee_ratio", self.limits["fee"]), self.quote_fee(quote))
            self._day(state, now, bid)
            result = {"status": "FLAT" if p is None else "HOLD", "model_required": False}
            watch = state["watch"]
            if watch and p is None:
                if stamp(now) >= stamp(watch["expires_at"]) or bid <= watch["invalidate_below"]:
                    state["watch"] = None
                    result["watch_status"] = "INVALIDATED_OR_EXPIRED"
                    self._event(db, "watch_invalidated", {"watch": watch}, now)
                else:
                    result["watch_status"] = (
                        "TRIGGERED_PENDING_OPPORTUNITY_RECHECK"
                        if bid >= watch["price_above"]
                        else "WAITING"
                    )
            if p:
                reason = (
                    "STOP"
                    if bid <= p["stop"]
                    else "TARGET"
                    if bid >= p["target"]
                    else "DEADLINE"
                    if stamp(now) >= stamp(p["deadline"])
                    else None
                )
                if reason:
                    fill = bid * (1 - self.limits["slippage"])
                    gross = p["quantity"] * fill
                    fee = gross * p["fee_ratio"]
                    net = gross - fee
                    pnl = net - p["total_entry_cost"]
                    state["cash"] += net
                    state["position"] = None
                    state["watch"] = None
                    state["day"]["realized"] += pnl
                    state["last_equity"] = state["cash"]
                    state["day"]["net_green"] = state["cash"] > state["day"]["start_equity"]
                    result = {
                        "status": "PAPER_EXIT",
                        "reason": reason,
                        "fill": fill,
                        "fee": fee,
                        "net_pnl": pnl,
                        "position_id": p["id"],
                        "symbol": p["symbol"],
                        "venue": p["venue"],
                        "quantity": p["quantity"],
                        "model_required": False,
                    }
                    self._event(db, "paper_exit", result, now)
            self._save(db, state)
            return {**result, "equity": state["last_equity"], "cash": state["cash"]}

    def quote_fee(self, quote):
        fee = amount(quote.get("fee_ratio", self.limits["fee"]), zero=True)
        if fee >= 1:
            raise ValueError("invalid_fee_ratio")
        if quote.get("venue") == "ROBINHOOD_CRYPTO_V2" and "fee_ratio" not in quote:
            raise ValueError("robinhood_fee_required")
        return max(fee, self.limits["fee"])

    def entry_check(self, state, quote, now):
        if quote.get("symbol", self.symbol) != self.symbol:
            raise ValueError("entry_quote_symbol_mismatch")
        bid, ask = valid_quote(quote, now)
        if not state["position"] or state["position"]["symbol"] == self.symbol:
            self._day(state, now, bid)
        reason = None
        if state["position"]:
            reason = "position_already_open"
        elif state["day"]["entries"] >= self.limits["entries"]:
            reason = "daily_entry_limit"
        elif self.config.get("CRYPTO_STOP_AFTER_NET_GREEN") is True and state["day"]["net_green"]:
            reason = "crypto_day_net_green"
        elif (ask - bid) / ((ask + bid) / 2) * 100 > self.limits["spread"]:
            reason = "spread_limit"
        price = ask * (1 + self.limits["slippage"])
        notional = self.limits["notional"]
        fee = self.quote_fee(quote)
        total = notional * (1 + fee)
        loss_used = max(0, state["day"]["start_equity"] - state["last_equity"])
        planned_loss = notional * (
            self.limits["stop"] / 100 + 2 * fee + 2 * self.limits["slippage"]
        )
        if state["cash"] < total:
            reason = "insufficient_paper_cash"
        if loss_used + planned_loss > self.limits["daily_loss"]:
            reason = "daily_planned_loss_limit"
        return {
            "allowed": reason is None,
            "reason": reason,
            "fill": price,
            "notional": notional,
            "total": total,
            "planned_loss": planned_loss,
            "fee_ratio": fee,
            "remaining_loss": self.limits["daily_loss"] - loss_used,
        }

    def buy(self, quote, decision, now, *, deadline):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            state = json.loads(db.execute("SELECT body FROM account WHERE id=1").fetchone()[0])
            check = self.entry_check(state, quote, now)
            if not check["allowed"]:
                return {"status": "BLOCKED", "reason": check["reason"]}
            if decision.get("action") != "BUY" or decision.get("symbol") != self.symbol:
                raise ValueError("exact spot BUY required")
            end = min(stamp(deadline), stamp(now) + timedelta(minutes=self.limits["hold_minutes"]))
            if end <= stamp(now):
                return {"status": "BLOCKED", "reason": "holding_window_closed"}
            p = {
                "id": stamp(now).isoformat(),
                "symbol": self.symbol,
                "asset_type": "SPOT_LONG",
                "quantity": check["notional"] / check["fill"],
                "entry": check["fill"],
                "total_entry_cost": check["total"],
                "stop": check["fill"] * (1 - self.limits["stop"] / 100),
                "target": check["fill"] * (1 + self.limits["target"] / 100),
                "deadline": end.isoformat(),
                "thesis": decision["thesis"],
                "invalidation": decision["invalidation"],
                "venue": quote.get("venue")
                or self.config.get("CRYPTO_DATA_VENUE")
                or "COINBASE_EXCHANGE",
                "fee_ratio": check["fee_ratio"],
            }
            state["cash"] -= check["total"]
            state["position"] = p
            state["watch"] = None
            state["day"]["entries"] += 1
            state["last_equity"] = self._equity(state, quote["bid"])
            self._save(db, state)
            self._event(db, "paper_entry", p, now)
            return {"status": "PAPER_BUY", "position": p}

    def update(self, changes):
        allowed = {"watch", "last_model_at", "last_research_bar", "last_research_bars"}
        if set(changes) - allowed:
            raise ValueError("invalid state patch")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            state = json.loads(db.execute("SELECT body FROM account WHERE id=1").fetchone()[0])
            state.update(changes)
            self._save(db, state)
