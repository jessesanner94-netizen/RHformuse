"""Versioned, standalone JEV evaluation questions.

Noul values are uncalibrated model judgments about the supplied evidence. They are
not empirical win probabilities or permission to bypass trading risk gates.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

QUESTION_VERSION = "jev-market-v2"
BOOK_QUESTION_VERSION = "jev-book-v2"


def _noul(question: str, yes: str, no: str) -> dict[str, Any]:
    return {
        "type": "noul",
        "instructions": question,
        "criteria": {"true": yes, "false": no},
    }


_MARKET_QUESTIONS: dict[str, dict[str, Any]] = {
    "bullish_continuation": _noul(
        "Does the supplied evidence support upward continuation over the stated trade horizon?",
        "Upward continuation is supported by current evidence.",
        "Upward continuation lacks support or evidence is insufficient.",
    ),
    "bearish_continuation": _noul(
        "Does the supplied evidence support downward continuation over the stated trade horizon?",
        "Downward continuation is supported by current evidence.",
        "Downward continuation lacks support or evidence is insufficient.",
    ),
    "setup_quality": _noul(
        "Does this candidate have a coherent setup and a defined invalidation level?",
        "The setup and invalidation are clear.",
        "The setup or invalidation is unclear or unsupported.",
    ),
    "entry_timing_quality": _noul(
        "Does the evidence support entry at this candidate's stated time and price?",
        "Current entry timing is supported.",
        "Current entry timing is unsupported or evidence is stale.",
    ),
    "momentum_quality": _noul(
        "Does recent momentum support the candidate's direction over its trade horizon?",
        "Recent momentum supports the candidate direction.",
        "Recent momentum does not support the candidate direction.",
    ),
    "volume_confirmation": _noul(
        "Does underlying volume confirm the candidate's stated directional move?",
        "Underlying volume confirms the stated direction.",
        "Volume does not confirm the stated direction or is missing.",
    ),
    "multi_timeframe_alignment": _noul(
        "Do price trends across the supplied timeframes align with the candidate's direction?",
        "The relevant timeframes align with the candidate.",
        "The relevant timeframes conflict or are insufficient.",
    ),
    "breakout_quality": _noul(
        "Is the candidate's claimed breakout confirmed by a fresh completed bar beyond its level?",
        "A claimed breakout has fresh completed-bar confirmation.",
        "A claimed breakout is unconfirmed, stale, or absent.",
    ),
    "false_breakout_risk": _noul(
        "Does supplied price and volume evidence show material false-breakout risk?",
        "Material false-breakout evidence is present.",
        "Material false-breakout evidence is absent or no breakout is claimed.",
    ),
    "exhaustion_risk": _noul(
        "Does supplied evidence show exhaustion of the candidate's directional move?",
        "Material directional exhaustion evidence is present.",
        "Material directional exhaustion evidence is absent.",
    ),
    "reversal_risk": _noul(
        "Does supplied evidence show material reversal risk against the candidate's direction?",
        "Material adverse reversal evidence is present.",
        "Material adverse reversal evidence is absent.",
    ),
    "trend_quality": _noul(
        "Is the trend in the candidate's direction sustained and orderly over its horizon?",
        "The directional trend is sustained and orderly.",
        "The directional trend is weak, erratic, or unsupported.",
    ),
    "unusual_opportunity": _noul(
        "Does this candidate show an exceptional opportunity in its stated market context?",
        "An exceptional opportunity is supported by supplied evidence.",
        "No exceptional opportunity is established.",
    ),
    "market_regime": {
        "type": "choice",
        "instructions": "Which regime best fits the supplied price and trade horizon?",
        "criteria": {
            "uptrend": "Sustained upward price trend.",
            "downtrend": "Sustained downward price trend.",
            "range": "Mostly bounded sideways price action.",
            "volatile_chop": "Large erratic swings without a sustained direction.",
            "uncertain": "Evidence is missing, stale, or inconclusive.",
        },
    },
    "escalate_to_luna": _noul(
        "Does this candidate show a material ambiguity warranting a separate Luna review?",
        "A specific material ambiguity or exceptional situation warrants review.",
        "No special review need is established by supplied evidence.",
    ),
}

_BOOK_QUESTIONS: dict[str, dict[str, Any]] = {
    "bullish_orderflow_pressure": _noul(
        "Does the supplied order-book sequence show sustained pressure favoring an upward move?",
        "Sustained upward pressure is evidenced by changes in the book.",
        "Upward pressure is absent or insufficiently evidenced.",
    ),
    "bearish_orderflow_pressure": _noul(
        "Does the supplied order-book sequence show sustained pressure favoring a downward move?",
        "Sustained downward pressure is evidenced by changes in the book.",
        "Downward pressure is absent or insufficiently evidenced.",
    ),
    "bid_pressure": _noul(
        "Does the supplied order-book sequence show persistent bid-side pressure?",
        "Persistent bid-side pressure is evidenced.",
        "Bid-side pressure is absent or insufficiently evidenced.",
    ),
    "ask_pressure": _noul(
        "Does the supplied order-book sequence show persistent ask-side pressure?",
        "Persistent ask-side pressure is evidenced.",
        "Ask-side pressure is absent or insufficiently evidenced.",
    ),
    "depth_imbalance": _noul(
        "Does the supplied order-book depth show a persistent, material size imbalance?",
        "A persistent, material size imbalance is evidenced.",
        "No persistent material imbalance is established.",
    ),
    "liquidity_withdrawal_risk": _noul(
        "Does the supplied order-book sequence show materially worsening liquidity?",
        "Available liquidity materially worsens.",
        "Material liquidity withdrawal is not established.",
    ),
    "bid_support_quality": _noul(
        "Do persistent bid levels in the supplied book provide credible near-term price support?",
        "Bid support is persistent across the supplied snapshots.",
        "Bid support is fleeting, absent, or insufficiently evidenced.",
    ),
    "ask_resistance_quality": _noul(
        "Do persistent ask levels in the supplied book provide credible near-term resistance?",
        "Ask resistance is persistent across the supplied snapshots.",
        "Ask resistance is fleeting, absent, or insufficiently evidenced.",
    ),
    "upside_breakout_likelihood": _noul(
        "Does the supplied book support an upside break through nearby ask resistance?",
        "Nearby ask resistance appears vulnerable to an upside break.",
        "An upside break is unsupported or evidence is insufficient.",
    ),
    "downside_breakdown_likelihood": _noul(
        "Does the supplied book support a downside break through nearby bid support?",
        "Nearby bid support appears vulnerable to a downside break.",
        "A downside break is unsupported or evidence is insufficient.",
    ),
    "book_false_breakout_risk": _noul(
        "Does the supplied book show a material risk that a nearby price break will fail?",
        "Book changes support material false-breakout risk.",
        "Material false-breakout risk is not established by the book.",
    ),
    "near_term_reversal_risk": _noul(
        "Does the supplied book show material risk of a near-term price reversal?",
        "Book changes support material near-term reversal risk.",
        "Material near-term reversal risk is not established by the book.",
    ),
    "orderflow_confirmation": _noul(
        "Does the supplied book confirm the candidate's stated price direction?",
        "Book pressure confirms the candidate direction.",
        "Book pressure conflicts with the direction or evidence is insufficient.",
    ),
}

_BOOK_TRADE_PRINT_QUESTIONS: dict[str, dict[str, Any]] = {
    "absorption_likelihood": _noul(
        "Do supplied trade prints and book changes show likely absorption at a price level?",
        "Repeated executed trades meet replenishing resting liquidity at a level.",
        "Absorption is not established by the supplied prints and book.",
    ),
    "exhaustion_likelihood": _noul(
        "Do supplied trade prints and book changes show likely exhaustion of the current move?",
        "Executed trade activity weakens while the current move loses support.",
        "Exhaustion is not established by the supplied prints and book.",
    ),
}

MARKET_QUESTION_IDS = tuple(_MARKET_QUESTIONS)
BOOK_QUESTION_IDS = tuple(_BOOK_QUESTIONS)
BOOK_TRADE_PRINT_QUESTION_IDS = tuple(_BOOK_TRADE_PRINT_QUESTIONS)


def market_questions(
    *, crypto_review_trial: bool = False, options_review: bool = False
) -> dict[str, dict[str, Any]]:
    """Fresh mutable copy; question IDs and wording are frozen for this version."""
    questions = deepcopy(_MARKET_QUESTIONS)
    if options_review:
        questions["setup_quality"] = _noul(
            "Does this option candidate have a coherent directional setup and supported entry "
            "evidence? Assess the supplied hard_exit_policy as the defined premium risk limit; "
            "do not confuse a premium stop with a chart-based thesis invalidation. "
            "Assess missing chart invalidation separately without assuming no risk plan exists.",
            "The supplied evidence supports a coherent setup with defined risk limits.",
            "The setup is incoherent, unsupported or its risk limits are missing.",
        )
        questions["escalate_to_luna"] = _noul(
            "Does this Python-qualified option setup warrant Luna's final BUY/PASS/WATCH "
            "review given the supplied evidence, trade style and costs? "
            "A clear supported setup can warrant review; ambiguity is not required.",
            "The supplied evidence merits a final trading decision from Luna.",
            "The setup is too weak or unsupported to merit final review.",
        )
    if crypto_review_trial:
        questions["escalate_to_luna"] = _noul(
            "Does this Python-qualified long-only spot crypto setup warrant Luna's final "
            "BUY/PASS/WATCH review given the supplied evidence and holding horizon? "
            "A clear supported setup can warrant review; ambiguity is not required.",
            "The supplied setup evidence merits a final trading decision from Luna.",
            "The setup is too weak or unsupported to merit final review.",
        )
    return questions


def book_questions(*, include_trade_prints: bool = False) -> dict[str, dict[str, Any]]:
    """Order-book batch; print-dependent judgments require actual trade prints."""
    questions = deepcopy(_BOOK_QUESTIONS)
    if include_trade_prints:
        questions.update(deepcopy(_BOOK_TRADE_PRINT_QUESTIONS))
    return questions
