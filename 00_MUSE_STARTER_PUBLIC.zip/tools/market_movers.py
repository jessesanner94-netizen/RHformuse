"""Resolve Robinhood's broad Daily Movers list into style-eligible option contracts."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.config import TradingConfig
from tools.news_option_discovery import run_symbol_option_discovery
from tools.robinhood_mcp import fetch_market_movers
from tools.state_manager import guarded_json_update


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _rows(payload: Mapping[str, Any], key: str) -> list[Mapping[str, Any]]:
    value = payload.get(key)
    if isinstance(value, Mapping):
        value = value.get("items") or value.get("results")
    return [item for item in value if isinstance(item, Mapping)] if isinstance(value, list) else []


def _body(row: Mapping[str, Any], wrapper: str) -> Mapping[str, Any]:
    value = row.get(wrapper)
    return value if isinstance(value, Mapping) else row


def select_market_movers(
    payload: Mapping[str, Any],
    config: TradingConfig,
    *,
    per_direction: int = 3,
    maximum: int = 6,
) -> list[dict[str, Any]]:
    """Select liquid gainers and losers before any option-chain work or model use."""

    listed_symbols = {
        str(row.get("symbol", "")).strip().upper()
        for row in _rows(payload, "items")
        if str(row.get("symbol", "")).strip()
    }
    quotes: dict[str, Mapping[str, Any]] = {}
    for row in _rows(payload, "equity_quotes"):
        quote = _body(row, "quote")
        symbol = str(quote.get("symbol", "")).strip().upper()
        if symbol:
            quotes[symbol] = quote
    fundamentals: dict[str, Mapping[str, Any]] = {}
    for row in _rows(payload, "equity_fundamentals"):
        body = _body(row, "fundamentals")
        symbol = str(body.get("symbol", "")).strip().upper()
        if symbol:
            fundamentals[symbol] = body

    minimum_liquidity = float(config.get("MIN_UNDERLYING_LIQUIDITY"))
    candidates: list[dict[str, Any]] = []
    for symbol in sorted(listed_symbols | quotes.keys()):
        quote = quotes.get(symbol, {})
        fundamental = fundamentals.get(symbol, {})
        last = _number(quote.get("last_trade_price") or quote.get("last_non_reg_trade_price"))
        previous = _number(
            quote.get("adjusted_previous_close")
            or quote.get("previous_close")
            or fundamental.get("previous_close")
        )
        average_volume = _number(
            fundamental.get("average_volume_30_days")
            or fundamental.get("average_volume")
            or fundamental.get("average_volume_2_weeks")
        )
        if last is None or previous is None or previous <= 0 or average_volume is None:
            continue
        liquidity = last * average_volume
        if liquidity < minimum_liquidity:
            continue
        current_volume = _number(
            quote.get("volume") or fundamental.get("volume") or fundamental.get("current_volume")
        )
        candidates.append(
            {
                "symbol": symbol,
                "last_price": round(last, 6),
                "previous_close": round(previous, 6),
                "change_percent": round((last - previous) / previous * 100, 4),
                "average_volume": round(average_volume, 2),
                "current_volume": current_volume,
                "relative_volume": (
                    round(current_volume / average_volume, 4)
                    if current_volume is not None and average_volume > 0
                    else None
                ),
                "underlying_avg_daily_dollar_volume": round(liquidity, 2),
            }
        )

    gainers = sorted(
        (item for item in candidates if item["change_percent"] >= 0),
        key=lambda item: (item["change_percent"], item.get("relative_volume") or 0),
        reverse=True,
    )[:per_direction]
    losers = sorted(
        (item for item in candidates if item["change_percent"] < 0),
        key=lambda item: (item["change_percent"], -(item.get("relative_volume") or 0)),
    )[:per_direction]
    selected = [*gainers, *losers]
    if len(selected) < maximum:
        selected_symbols = {item["symbol"] for item in selected}
        remainder = sorted(
            (item for item in candidates if item["symbol"] not in selected_symbols),
            key=lambda item: (abs(item["change_percent"]), item.get("relative_volume") or 0),
            reverse=True,
        )
        selected.extend(remainder[: maximum - len(selected)])
    return selected[:maximum]


def _signature(candidates: list[Mapping[str, Any]]) -> str:
    compact = [
        {
            "id": item.get("candidate_id"),
            "styles": item.get("eligible_trade_styles", []),
        }
        for item in candidates
    ]
    return hashlib.sha256(json.dumps(compact, sort_keys=True).encode()).hexdigest()


async def run_market_mover_discovery(
    config: TradingConfig,
    *,
    state_path: Path,
    now: datetime | None = None,
    commit: bool = True,
    mover_fetcher: Callable[[], Awaitable[dict[str, Any]]] = fetch_market_movers,
    option_resolver: Callable[..., Awaitable[dict[str, Any]]] = run_symbol_option_discovery,
) -> dict[str, Any]:
    """Run the first-stage broad mover feed, then the shared option/Greek gate."""

    current = now or datetime.now(UTC)
    snapshot = await mover_fetcher()
    movers = select_market_movers(snapshot, config)
    context = {item["symbol"]: item for item in movers}
    contracts = await option_resolver(
        [item["symbol"] for item in movers],
        config,
        discovery_source="ROBINHOOD_DAILY_MOVERS",
        max_symbols=6,
        max_expirations=3,
        max_candidates=12,
        symbol_context=context,
        now=current,
    )
    qualified = [
        item for item in contracts.get("qualified_candidates", []) if isinstance(item, Mapping)
    ]
    signature = _signature(qualified)
    prior_signature: str | None = None
    if state_path.exists():
        try:
            prior = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(prior, Mapping):
                prior_signature = str(prior.get("signature") or "") or None
        except (OSError, json.JSONDecodeError):
            prior_signature = None
    changed = bool(qualified) and signature != prior_signature
    write = guarded_json_update(
        state_path,
        {
            "updated_at": current.astimezone(UTC).isoformat(),
            "signature": signature,
            "candidate_ids": [item.get("candidate_id") for item in qualified],
            "mover_symbols": [item["symbol"] for item in movers],
        },
        commit=commit,
    )
    return {
        "status": "QUALIFIED_CHANGED"
        if changed
        else "UNCHANGED"
        if qualified
        else "ZERO_QUALIFIED",
        "wake_luna": changed,
        "movers": movers,
        "movers_considered": len(movers),
        "contract_discovery": contracts,
        "qualified_candidates": qualified,
        "signature": signature,
        "snapshot_as_of": snapshot.get("as_of"),
        "persistent_write": write,
        "orders_placed": 0,
        "orders_cancelled": 0,
    }
