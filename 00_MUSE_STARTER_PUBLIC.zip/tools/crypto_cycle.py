"""Run ETH/BTC spot PAPER cycles. This module has no broker order adapter."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from tools.codex_trigger import run_trigger
from tools.config import TradingConfig, load_config
from tools.crypto_jev_trial import TRIAL_ID, active, sample_allowed, slot
from tools.crypto_paper import CryptoPaperStore, amount, stamp, valid_quote
from tools.crypto_strategy import build_packet, crypto_window
from tools.crypto_symbols import configured_symbols, validate_symbol
from tools.decision_context import model_call_budget_status, reserve_model_call
from tools.economic_calendar import economic_context
from tools.jev_pipeline import evaluate_candidate, record_routing
from tools.jev_store import JevStore
from tools.orderbook import collect_orderbooks
from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock


def parse_decision(output, quote, now, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    decision = json.loads(output)
    if not isinstance(decision, dict) or set(decision) != {
        "action",
        "symbol",
        "thesis",
        "invalidation",
        "reason",
        "watch",
    }:
        raise ValueError("invalid decision fields")
    if decision["action"] not in {"BUY", "PASS", "WATCH"} or decision["symbol"] != symbol:
        raise ValueError("invalid action or symbol")
    for key, limit in (("thesis", 700), ("invalidation", 400), ("reason", 700)):
        if not isinstance(decision[key], str) or not 1 <= len(decision[key].strip()) <= limit:
            raise ValueError("invalid decision explanation")
    watch = decision["watch"]
    if decision["action"] == "WATCH":
        if not isinstance(watch, dict) or set(watch) != {
            "price_above",
            "invalidate_below",
            "expires_at",
        }:
            raise ValueError("invalid watch")
        bid, ask = valid_quote(quote, now)
        if amount(watch["price_above"]) <= ask or amount(watch["invalidate_below"]) >= bid:
            raise ValueError("watch must wait for future price change")
        if not timedelta(0) < stamp(watch["expires_at"]) - stamp(now) <= timedelta(minutes=60):
            raise ValueError("invalid watch expiry")
    elif watch is not None:
        raise ValueError("watch only valid for WATCH action")
    return decision


async def run_cycle(
    project_root,
    *,
    execute_models=False,
    monitor_only=False,
    now=None,
    fetcher=None,
    quote_fetcher=None,
    evaluator=None,
    model=None,
    calendar=None,
    symbol=None,
):
    """One bounded invocation. The monitor task never invokes JEV or Luna."""
    from tools.crypto_data_router import fetch_quote, fetch_snapshot

    root = Path(project_root)
    config = load_config(root / "CONFIG.md")
    symbol = symbol or config.get("CRYPTO_SYMBOL")
    if symbol not in configured_symbols(config):
        # Discovery changes cannot abandon an existing paper position.
        held = CryptoPaperStore(root / "state/research/crypto_paper.sqlite3", config).read()[
            "position"
        ]
        if not held or held["symbol"] != symbol:
            return {"status": "BLOCKED", "reason": "unsupported_crypto_symbol", "orders_placed": 0}
        validate_symbol(symbol)
        monitor_only = True
    config = TradingConfig({**config.values, "CRYPTO_SYMBOL": symbol}, config.source)
    current = stamp(now or datetime.now(UTC))
    if config.get("CRYPTO_PAPER_ENABLED") is not True or not config.paper_trading_enabled:
        return {"status": "DISABLED", "orders_placed": 0}
    if config.live_execution_enabled:
        return {
            "status": "BLOCKED",
            "reason": "crypto_implementation_is_paper_only",
            "orders_placed": 0,
        }
    store = CryptoPaperStore(root / "state/research/crypto_paper.sqlite3", config)
    selected_source = None

    async def pinned_quote(now=None):
        state = store.read()
        source = (state.get("position") or state.get("watch") or {}).get("venue") or selected_source
        return await fetch_quote(now=now, venue=source, symbol=symbol)

    async def pinned_snapshot(now=None):
        nonlocal selected_source
        state = store.read()
        source = (state.get("position") or state.get("watch") or {}).get("venue") or selected_source
        snapshot = await fetch_snapshot(now=now, venue=source, symbol=symbol)
        if snapshot.get("status") == "OK":
            selected_source = snapshot["quote"]["venue"]
        return snapshot

    quote_fetcher = quote_fetcher or pinned_quote
    result = {
        "mode": "PAPER_ONLY",
        "symbol": symbol,
        "orders_placed": 0,
        "as_of": current.isoformat(),
        "monitor_only": monitor_only,
    }
    try:
        existing = store.read()
        owner = existing["position"] or existing["watch"]
        if owner and owner.get("symbol", "ETH-USD") != symbol:
            return {
                **result,
                "status": "SKIPPED",
                "reason": "other_crypto_position_or_watch_active",
            }
        if not crypto_window(current)["entry_allowed"] and not existing["position"]:
            if existing["watch"]:
                store.update({"watch": None})
            return {**result, "status": "SKIPPED", "reason": "equity_session_crypto_idle"}
        # Manage an existing position without fetching research or spending model calls.
        if existing["position"]:
            monitor_only = True
        if monitor_only:
            # Flat quote observations also support future one-minute replay labels.
            quote = await quote_fetcher(now=now)
            current = stamp(now or datetime.now(UTC))
            result["monitor"] = store.monitor(quote, current)
            result["status"] = result["monitor"]["status"]
            store.event(
                "quote_observation",
                {"quote": quote, "venue": quote.get("venue", "UNKNOWN")},
                current,
            )
            return result
        with advisory_file_lock(root / "state/runtime/crypto_opportunity", timeout_seconds=0.1):
            outcome = await _opportunity(
                root,
                config,
                store,
                result,
                execute_models,
                now,
                fetcher or pinned_snapshot,
                quote_fetcher or fetch_quote,
                evaluator or evaluate_candidate,
                model or run_trigger,
                calendar or economic_context,
            )
            if outcome.get("jev_trial"):
                store.event(
                    "jev_trial_outcome",
                    {
                        **outcome["jev_trial"],
                        "status": outcome.get("status"),
                        "reason": outcome.get("reason"),
                        "decision": outcome.get("decision"),
                        "paper": outcome.get("paper"),
                    },
                    stamp(now or datetime.now(UTC)),
                )
            return outcome
    except RuntimeLockUnavailable:
        return {**result, "status": "SKIPPED", "reason": "crypto_cycle_already_running"}
    except Exception as exc:
        import traceback

        # Code locations are useful diagnostics without logging provider bodies or secrets.
        frames = traceback.extract_tb(exc.__traceback__)
        error = {
            **result,
            "status": "UNAVAILABLE",
            "reason": type(exc).__name__,
            "error_location": [f"{Path(f.filename).name}:{f.name}:{f.lineno}" for f in frames[-4:]],
            "error_code": str(exc)
            if str(exc)
            in {
                "stale or crossed crypto quote",
                "quote_unavailable",
                "position_quote_symbol_mismatch",
                "position_quote_venue_mismatch",
                "invalid_fee_ratio",
                "robinhood_fee_required",
            }
            else "unclassified",
        }
        store.event("cycle_unavailable", error, current)
        return error


async def _opportunity(
    root,
    config,
    store,
    result,
    execute_models,
    fixed_now,
    fetcher,
    quote_fetcher,
    evaluator,
    model,
    calendar,
):
    current = stamp(fixed_now or datetime.now(UTC))
    window = crypto_window(current)
    if not window["entry_allowed"]:
        return {**result, "status": "SKIPPED", "reason": "equity_session_monitor_remains_active"}
    snapshot = await fetcher(now=fixed_now)
    current = stamp(fixed_now or datetime.now(UTC))
    if snapshot.get("status") != "OK":
        # Quotes remain useful for exits even when required entry evidence is absent.
        if snapshot.get("quote"):
            result["monitor"] = store.monitor(snapshot["quote"], current)
            store.event(
                "quote_observation",
                {"quote": snapshot["quote"], "venue": snapshot.get("venue")},
                current,
            )
        store.event(
            "data_unavailable",
            {"status": snapshot.get("status"), "reason": snapshot.get("reason")},
            current,
        )
        return {
            **result,
            "status": "UNAVAILABLE",
            "reason": snapshot.get("reason", "market_data_unavailable"),
        }
    quote = snapshot["quote"]
    result["monitor"] = store.monitor(quote, current)
    store.event(
        "market_observation",
        {"quote": quote, "venue": snapshot.get("venue"), "latest_bar": snapshot["candles_5m"][-1]},
        current,
    )
    state = store.read()
    risk = store.entry_check(state, quote, current)
    if state["position"]:
        return {**result, "status": "HOLD", "reason": "position_monitoring_no_model_required"}
    macro = await asyncio.to_thread(calendar, current, config, project_root=root)
    packet = build_packet(snapshot, config, state, risk, macro, current)
    result["python_gate"] = packet["python_gate"]
    if packet["python_gate"]["status"] != "QUALIFIED":
        if state["watch"]:
            store.update({"watch": None})
            store.event("watch_invalidated", packet["python_gate"], current)
        store.event("python_rejected", packet["python_gate"], current)
        return {**result, "status": "PYTHON_REJECTED"}
    bar = packet["technical"]["timeframes"]["5M"]["last_bar_at"]
    watch = state["watch"]
    wake = False
    if watch:
        if (
            stamp(current) >= stamp(watch["expires_at"])
            or quote["bid"] <= watch["invalidate_below"]
        ):
            store.update({"watch": None})
            store.event("watch_invalidated", {"watch": watch}, current)
        elif quote["bid"] < watch["price_above"]:
            return {**result, "status": "WATCHING", "watch": watch}
        else:
            wake = True
    symbol = store.symbol
    bars = state.get("last_research_bars", {})
    if (
        bars.get(symbol, state["last_research_bar"] if symbol == "ETH-USD" else None) == bar
        and not wake
    ):
        return {**result, "status": "SKIPPED", "reason": "completed_bar_already_processed"}
    store.update({"last_research_bars": {**bars, symbol: bar}})
    book_venue = snapshot.get("book_venue", snapshot.get("venue", "UNKNOWN"))
    if book_venue not in {"COINBASE_EXCHANGE", "BINANCE_US", "ROBINHOOD_CRYPTO_V2", "UNKNOWN"}:
        return {**result, "status": "BLOCKED", "reason": "unsupported_book_venue"}
    books = await collect_orderbooks(
        [symbol],
        root / f"state/research/crypto_book_{book_venue}.sqlite3",
        now=current,
        fetcher=lambda _: {"books": [snapshot["book"]]},
    )
    book = books.get("summaries", {}).get(symbol)
    if book:
        book = {
            **book,
            "venue": snapshot.get("book_venue", snapshot.get("venue", "UNKNOWN")),
            "timestamp_source": snapshot["book"].get("timestamp_source", "receipt_time"),
            "not_robinhood_depth": snapshot.get("book_venue", snapshot.get("venue"))
            != "ROBINHOOD_CRYPTO_V2",
        }
    budget_path = root / "state/runtime/model_budget.json"
    maximum = config.get("MAX_MODEL_CALLS_PER_DAY")
    budget = model_call_budget_status(budget_path, maximum_calls=maximum, now=current)
    jev = await asyncio.to_thread(
        evaluator,
        packet,
        config,
        project_root=root,
        now=current,
        book_summary=book,
        calls_remaining=budget.get("calls_remaining", 0),
    )
    relative = (
        config.get("CRYPTO_JEV_ABOVE_AVERAGE") is True
        and config.get("PAPER_TRADING_ENABLED") is True
        and config.get("LIVE_EXECUTION_ENABLED") is False
    )
    if relative:
        from tools.jev_relative import relative_setup_policy

        comparison = relative_setup_policy(
            root / "state/research/jev.sqlite3", jev, symbol=symbol, now=current
        )
        jev = {**jev, "policy": comparison}
        store.event("jev_relative_comparison", comparison, current)
        if jev.get("observation_id"):
            JevStore(root / "state/research/jev.sqlite3").event(
                jev["observation_id"], "relative_setup_comparison", comparison, current
            )
    result["jev"] = {key: jev.get(key) for key in ("status", "scores", "policy", "observation_id")}
    sampled = False
    if (
        jev.get("status") != "OK"
        or jev.get("routing_effect") is not True
        or jev.get("policy", {}).get("would_escalate") is not True
    ):
        store.event("jev_filtered", result["jev"], current)
        sampled = not relative and sample_allowed(config, current, jev, store)
        if not sampled:
            return {**result, "status": "JEV_FILTERED"}
    if (
        not wake
        and state["last_model_at"]
        and (current - stamp(state["last_model_at"])).total_seconds() < 1800
    ):
        return {**result, "status": "SKIPPED", "reason": "unchanged_candidate_model_cooldown"}
    # Blind both trial routes: the reviewer must not infer quality from JEV's verdict.
    if not relative and not active(config, current):
        packet["jev_context"] = {key: jev.get(key) for key in ("scores", "policy", "score_delta")}
    if book:
        packet["orderbook"] = {
            key: book.get(key)
            for key in ("status", "features", "temporal_available", "venue", "timestamp_source")
        }
    packet["prior_watch"] = watch if wake else None
    trial = (
        {
            "trial_id": TRIAL_ID,
            "observation_id": jev.get("observation_id"),
            "route": "sampled_jev_rejection",
            "slot": slot(current),
            "jev": result["jev"],
        }
        if sampled
        else None
    )
    if not execute_models:
        return {**result, "status": "PREVIEW", "reason": "model_execution_not_requested"}
    # Re-evaluate time and the shared daily budget after research.
    current = stamp(fixed_now or datetime.now(UTC))
    window = crypto_window(current)
    if not window["entry_allowed"]:
        return {**result, "status": "SKIPPED", "reason": "equity_session_started"}
    if sampled and not sample_allowed(config, current, jev, store):
        return {**result, "status": "JEV_FILTERED", "reason": "trial_expired_or_full"}
    reservation = reserve_model_call(
        budget_path,
        maximum_calls=maximum,
        now=current,
        packet_signature=hashlib.sha256(json.dumps(packet, sort_keys=True).encode()).hexdigest(),
        admission_limit=window["admission_limit"],
    )
    result["model_budget"] = reservation
    if reservation.get("status") != "RESERVED":
        return {**result, "status": "BUDGET_BLOCKED"}
    if sampled:
        store.event("jev_trial_reserved", trial, current)
        result["jev_trial"] = trial
    # Persist consumption before launching. A crash may lose a decision, never repeat it blindly.
    store.update({"last_model_at": current.isoformat(), "watch": None})
    decision_result = await asyncio.to_thread(
        model,
        {"wake_decision": True, "decision_packet": packet},
        project_root=root,
        execute=True,
        wake_key="wake_decision",
        model=str(config.get("FINAL_DECISION_MODEL")),
        reasoning_effort=str(config.get("FINAL_DECISION_REASONING_EFFORT")),
        sandbox="read-only",
        isolated_agent=True,
        isolated_policy_name="CRYPTO_AGENT_AGENTS.md",
        prompt_name="CRYPTO_DECISION.md",
        output_schema_name="crypto_decision.schema.json",
    )
    result["model"] = {
        key: decision_result.get(key) for key in ("status", "model", "reported_tokens", "reason")
    }
    routing = {"decision_packet": packet, "jev_evaluations": [jev], "decision": decision_result}
    if decision_result.get("status") != "COMPLETED":
        record_routing(root, routing, now=current)
        store.event("model_error", result["model"], current)
        return {**result, "status": "MODEL_ERROR"}
    current = stamp(fixed_now or datetime.now(UTC))
    # Never fill from the pre-model price. Even WATCH must refer to current observable prices.
    fresh_quote = await quote_fetcher(now=fixed_now)
    current = stamp(fixed_now or datetime.now(UTC))
    if fresh_quote.get("venue") != quote.get("venue"):
        return {**result, "status": "BLOCKED", "reason": "paper_price_source_changed_after_model"}
    decision = parse_decision(decision_result.get("output", ""), fresh_quote, current, symbol)
    routing["decision_verdict"] = decision
    record_routing(root, routing, now=current)
    store.event(
        "luna_decision",
        {
            "decision": decision,
            "usage": result["model"],
            "jev_observation_id": jev.get("observation_id"),
            "jev_trial": trial,
        },
        current,
    )
    result["decision"] = decision
    if decision["action"] == "WATCH":
        store.update(
            {"watch": {**decision["watch"], "venue": quote.get("venue"), "symbol": symbol}}
        )
        return {**result, "status": "WATCHING"}
    if decision["action"] == "PASS":
        return {**result, "status": "PASS"}
    latest_config = load_config(root / "CONFIG.md")
    if symbol not in configured_symbols(latest_config):
        return {**result, "status": "BLOCKED", "reason": "symbol_disabled_after_model"}
    latest_config = TradingConfig(
        {**latest_config.values, "CRYPTO_SYMBOL": symbol}, latest_config.source
    )
    if (
        latest_config.live_execution_enabled
        or not latest_config.paper_trading_enabled
        or latest_config.get("CRYPTO_PAPER_ENABLED") is not True
    ):
        return {**result, "status": "BLOCKED", "reason": "mode_changed_before_fill"}
    refreshed = await fetcher(now=fixed_now)
    current = stamp(fixed_now or datetime.now(UTC))
    if refreshed.get("status") != "OK":
        return {**result, "status": "BLOCKED", "reason": "final_market_refresh_unavailable"}
    fresh_quote = refreshed["quote"]
    if store.quote_fee(fresh_quote) > store.quote_fee(quote):
        return {**result, "status": "BLOCKED", "reason": "fees_increased_after_model"}
    if fresh_quote.get("venue") != quote.get("venue") or refreshed.get(
        "research_venue"
    ) != snapshot.get("research_venue"):
        return {**result, "status": "BLOCKED", "reason": "market_source_changed_after_model"}
    fresh_macro = await asyncio.to_thread(calendar, current, latest_config, project_root=root)
    current = stamp(fixed_now or datetime.now(UTC))
    window = crypto_window(current)
    # Limit fills to the candidate's stated risk policy, using fresh configuration and quote.
    store = CryptoPaperStore(store.path, latest_config)
    state = store.read()
    fresh_risk = store.entry_check(state, fresh_quote, current)
    final_packet = build_packet(refreshed, latest_config, state, fresh_risk, fresh_macro, current)
    if final_packet["python_gate"]["status"] != "QUALIFIED":
        return {
            **result,
            "status": "BLOCKED",
            "reason": "final_python_gate_failed",
            "final_gate": final_packet["python_gate"],
        }
    if abs(fresh_quote["ask"] / quote["ask"] - 1) * 100 > 0.25:
        return {**result, "status": "BLOCKED", "reason": "price_moved_after_model"}
    risk_keys = (
        "CRYPTO_MAX_POSITION_DOLLARS",
        "CRYPTO_STOP_LOSS_PERCENT",
        "CRYPTO_TAKE_PROFIT_PERCENT",
        "CRYPTO_MAX_HOLD_MINUTES",
        "CRYPTO_PAPER_FEE_PERCENT_SIDE",
        "CRYPTO_PAPER_SLIPPAGE_BPS_SIDE",
        "CRYPTO_MAX_DAILY_LOSS_DOLLARS",
        "CRYPTO_MAX_ENTRIES_PER_DAY",
        "CRYPTO_MAX_SPREAD_PERCENT",
        "CRYPTO_STOP_AFTER_NET_GREEN",
        "CRYPTO_PAPER_STARTING_CASH",
        "CRYPTO_SYMBOL",
        "ENABLE_JEV",
        "JEV_SHADOW_MODE",
        "ENABLE_JEV_ESCALATION",
        "CRYPTO_JEV_OVERNIGHT_TEST",
    )
    if any(config.get(key) != latest_config.get(key) for key in risk_keys):
        return {**result, "status": "BLOCKED", "reason": "risk_policy_changed_after_model"}
    trade = store.buy(fresh_quote, decision, current, deadline=window["deadline"])
    if sampled:
        store.event("jev_trial_execution", {**trial, "paper": trade}, current)
    if jev.get("observation_id"):
        JevStore(root / "state/research/jev.sqlite3").event(
            jev["observation_id"], "execution_result", {"paper": trade}, current
        )
    return {**result, "status": trade["status"], "paper": trade}


async def run_universe(project_root, *, execute_models=False, monitor_only=False, now=None):
    root = Path(project_root)
    config = load_config(root / "CONFIG.md")
    symbols = list(configured_symbols(config))
    store = CryptoPaperStore(root / "state/research/crypto_paper.sqlite3", config)
    state = store.read()
    owner = state["position"] or state["watch"]
    if owner:
        # Manage the held asset even if it was removed from the discovery list.
        held = validate_symbol(owner.get("symbol", "ETH-USD"))
        if held not in symbols and not state["position"]:
            store.update({"watch": None})
            return {"status": "SKIPPED", "reason": "disabled_symbol_watch_cleared"}
        symbols = [held]
    elif int(stamp(now or datetime.now(UTC)).timestamp()) // 300 % 2:
        symbols.reverse()
    results = []
    for symbol in symbols:
        results.append(
            await run_cycle(
                root,
                execute_models=execute_models,
                monitor_only=monitor_only,
                now=now,
                symbol=symbol,
            )
        )
    return {
        "status": "UNAVAILABLE"
        if any(r["status"] in {"UNAVAILABLE", "MODEL_ERROR", "ERROR"} for r in results)
        else "COMPLETED",
        "mode": "PAPER_ONLY",
        "orders_placed": 0,
        "results": results,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--execute-models", action="store_true")
    parser.add_argument("--monitor-only", action="store_true")
    parser.add_argument("--notifications", action="store_true")
    parser.add_argument("--symbol", choices=("ETH-USD", "BTC-USD"))
    args = parser.parse_args(argv)
    result = asyncio.run(
        (run_cycle if args.symbol else run_universe)(
            args.project_root,
            execute_models=args.execute_models,
            monitor_only=args.monitor_only,
            **({"symbol": args.symbol} if args.symbol else {}),
        )
    )
    if args.notifications:
        from tools.crypto_notifications import drain_notifications

        try:
            result["notifications"] = drain_notifications(args.project_root)
        except Exception as exc:
            result["notifications"] = {"status": "ERROR", "reason": type(exc).__name__}
    print(json.dumps(result, indent=2, sort_keys=True))
    notifications = result.get("notifications", {})
    notification_failed = notifications.get("status") == "ERROR" or any(
        channel.get("status") == "ERROR"
        for event in notifications.get("events", [])
        for channel in event.get("channels", {}).values()
    )
    return int(
        result.get("status") in {"UNAVAILABLE", "MODEL_ERROR", "ERROR"} or notification_failed
    )


if __name__ == "__main__":
    raise SystemExit(main())
