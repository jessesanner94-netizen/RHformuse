"""Resolve Luna-escalated news symbols into live, liquidity-gated Robinhood contracts."""

from __future__ import annotations

import math
import re
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from tools.cheap_scan import scan_candidates
from tools.config import TradingConfig
from tools.option_style import annotate_option_styles
from tools.robinhood_mcp import fetch_symbol_contract_research

SYMBOL = re.compile(r"^[A-Z][A-Z0-9.-]{0,5}$")
EASTERN = ZoneInfo("America/New_York")


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _fresh(value: Any, *, now: datetime, maximum_age_seconds: int = 180) -> bool:
    if not isinstance(value, str):
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    age = (now.astimezone(UTC) - parsed.astimezone(UTC)).total_seconds()
    return -30 <= age <= maximum_age_seconds


def _rows(payload: Mapping[str, Any], key: str) -> list[Mapping[str, Any]]:
    value = payload.get(key)
    return [item for item in value if isinstance(item, Mapping)] if isinstance(value, list) else []


def build_news_candidates(
    research: Mapping[str, Any],
    *,
    now: datetime,
    config: TradingConfig,
    discovery_source: str = "NEWS_AFTER_LUNA",
    symbol_context: Mapping[str, Mapping[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    quotes: dict[str, Mapping[str, Any]] = {}
    for row in _rows(research, "option_quotes"):
        quote = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        contract_id = quote.get("instrument_id")
        if isinstance(contract_id, str):
            quotes[contract_id] = quote
    prices: dict[str, float] = {}
    for row in _rows(research, "equity_quotes"):
        quote = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        symbol = str(quote.get("symbol", "")).upper()
        price = _number(quote.get("last_trade_price") or quote.get("last_non_reg_trade_price"))
        if symbol and price is not None:
            prices[symbol] = price
    liquidity: dict[str, float] = {}
    average_volume: dict[str, float] = {}
    for row in _rows(research, "equity_fundamentals"):
        symbol = str(row.get("symbol", "")).upper()
        volume = _number(
            row.get("average_volume_30_days")
            or row.get("average_volume")
            or row.get("average_volume_2_weeks")
        )
        if symbol in prices and volume is not None:
            liquidity[symbol] = prices[symbol] * volume
            average_volume[symbol] = volume
    candidates: list[dict[str, Any]] = []
    for instrument in _rows(research, "instruments"):
        contract_id = str(instrument.get("id") or instrument.get("instrument_id") or "")
        symbol = str(instrument.get("chain_symbol", "")).upper()
        expiration = str(instrument.get("expiration_date", ""))
        strike = _number(instrument.get("strike_price"))
        option_type = str(instrument.get("type", "")).upper()
        quote = quotes.get(contract_id)
        try:
            dte = (datetime.fromisoformat(expiration).date() - now.astimezone(EASTERN).date()).days
        except ValueError:
            dte = None
        if (
            not contract_id
            or symbol not in prices
            or quote is None
            or strike is None
            or dte is None
        ):
            continue
        candidates.append(
            annotate_option_styles(
                {
                    "candidate_id": contract_id,
                    "symbol": symbol,
                    "option_symbol": instrument.get("symbol"),
                    "expiration": expiration,
                    "strike": strike,
                    "option_type": option_type,
                    "dte": dte,
                    "underlying_price": prices[symbol],
                    "bid": _number(quote.get("bid_price")),
                    "ask": _number(quote.get("ask_price")),
                    "option_volume": _number(quote.get("volume")),
                    "option_open_interest": _number(quote.get("open_interest")),
                    "underlying_avg_daily_dollar_volume": liquidity.get(symbol),
                    "underlying_average_volume_30d": average_volume.get(symbol),
                    "quote_is_fresh": _fresh(quote.get("updated_at"), now=now),
                    "quote_updated_at": quote.get("updated_at"),
                    "setup_qualified": True,
                    "discovery_source": discovery_source,
                    "discovery_context": dict((symbol_context or {}).get(symbol, {})),
                    "implied_volatility": _number(quote.get("implied_volatility")),
                    "delta": _number(quote.get("delta")),
                    "gamma": _number(quote.get("gamma")),
                    "theta": _number(quote.get("theta")),
                    "vega": _number(quote.get("vega")),
                    "rho": _number(quote.get("rho")),
                    "break_even_price": _number(quote.get("break_even_price")),
                    "chance_of_profit_long": _number(quote.get("chance_of_profit_long")),
                },
                config,
            )
        )
    return candidates


def _day_delta_audit(qualified: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Retain one compact highest-delta DAY quote per symbol/type before diversification."""

    groups: dict[tuple[str, str], dict[str, Any]] = {}
    for item in qualified:
        if "DAY" not in item.get("eligible_trade_styles", []):
            continue
        key = (str(item["symbol"]), str(item["option_type"]))
        abs_delta = abs(float(item["delta"]))
        row = groups.get(key)
        if row is None:
            row = {
                "symbol": key[0],
                "option_type": key[1],
                "eligible_count": 0,
                "max_abs_delta": -1.0,
            }
            groups[key] = row
        row["eligible_count"] += 1
        if abs_delta > row["max_abs_delta"]:
            row["max_abs_delta"] = abs_delta
            row["highest_delta_quote"] = {
                field: item.get(field)
                for field in (
                    "candidate_id",
                    "option_symbol",
                    "expiration",
                    "strike",
                    "dte",
                    "bid",
                    "ask",
                    "delta",
                    "option_volume",
                    "option_open_interest",
                    "quote_updated_at",
                )
            }
    return [groups[key] for key in sorted(groups)]


async def run_symbol_option_discovery(
    symbols: list[str],
    config: TradingConfig,
    *,
    discovery_source: str,
    max_symbols: int = 3,
    max_expirations: int = 2,
    max_candidates: int = 12,
    premium_ceiling: float | None = None,
    symbol_context: Mapping[str, Mapping[str, Any]] | None = None,
    now: datetime | None = None,
    research_fetcher: Callable[
        [list[Mapping[str, str]]], Awaitable[dict[str, Any]]
    ] = fetch_symbol_contract_research,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    clean_symbols = list(
        dict.fromkeys(
            symbol.strip().upper()
            for symbol in symbols
            if isinstance(symbol, str) and SYMBOL.fullmatch(symbol.strip().upper())
        )
    )[:max_symbols]
    if not clean_symbols:
        return {
            "status": "SKIPPED",
            "reason": "no_valid_symbols",
            "qualified_candidates": [],
        }
    local_date = current.astimezone(EASTERN).date()
    minimum = local_date + timedelta(days=int(config.get("MIN_DTE")))
    maximum = local_date + timedelta(days=int(config.get("MAX_DTE")))
    research = await research_fetcher(
        [
            {
                "symbol": symbol,
                "min_expiration": minimum.isoformat(),
                "max_expiration": maximum.isoformat(),
                "max_expirations": str(max_expirations),
                **({} if config.get("DAY_ONLY_OPTIONS") is True else {
                    "min_swing_expiration": (
                        local_date + timedelta(days=int(config.get("MIN_SWING_DTE")))
                    ).isoformat(),
                }),
            }
            for symbol in clean_symbols
        ]
    )
    candidates = build_news_candidates(
        research,
        now=now or datetime.now(UTC),
        config=config,
        discovery_source=discovery_source,
        symbol_context=symbol_context,
    )
    gate = scan_candidates(candidates, config)
    qualified_ids = {item["candidate_id"] for item in gate["qualified"]}
    premium_floor = float(config.get("MIN_SINGLE_POSITION_PREMIUM_AT_RISK"))
    premium_limit = float(config.get("MAX_SINGLE_POSITION_PREMIUM_AT_RISK"))
    if premium_ceiling is not None:
        if not math.isfinite(premium_ceiling) or premium_ceiling < 0:
            raise ValueError("invalid discovery premium ceiling")
        premium_limit = min(premium_limit, premium_ceiling)
    qualified = [
        item
        for item in candidates
        if item["candidate_id"] in qualified_ids
        and item.get("ask") is not None
        and premium_floor <= float(item["ask"]) * 100 <= premium_limit
    ]

    def rank(item: Mapping[str, Any]) -> tuple[float, float, float, float]:
        bid = float(item["bid"])
        ask = float(item["ask"])
        midpoint = (bid + ask) / 2
        spread = (ask - bid) / midpoint if midpoint > 0 else math.inf
        abs_delta = abs(float(item["delta"]))
        return (
            spread,
            abs(abs_delta - 0.5),
            float(item["greek_metrics"]["theta_percent_of_premium_per_day"]),
            -float(item["option_open_interest"]),
        )

    qualified.sort(key=rank)
    day_delta_audit = _day_delta_audit(qualified)
    diversified: list[dict[str, Any]] = []
    groups: set[tuple[str, str, tuple[str, ...]]] = set()
    for item in qualified:
        symbol = str(item["symbol"])
        key = (symbol, str(item["option_type"]), tuple(item["eligible_trade_styles"]))
        if key in groups:
            continue
        diversified.append(item)
        groups.add(key)
        if len(diversified) >= max_candidates:
            break
    return {
        "status": "QUALIFIED" if qualified else "ZERO_QUALIFIED",
        "symbols": clean_symbols,
        "contracts_resolved": len(candidates),
        "gate": gate,
        "qualified_candidates": diversified,
        "day_delta_audit": day_delta_audit,
        "premium_limit": premium_limit,
        "funnel": {
            "contracts_resolved": len(candidates),
            "tradability_passed": len(qualified_ids),
            "premium_passed": len(qualified),
            "premium_rejected": len(qualified_ids) - len(qualified),
            "shortlisted": len(diversified),
        },
        "snapshot_as_of": research.get("as_of"),
        "chain_pagination": research.get("chain_pagination", []),
        "orders_placed": 0,
        "orders_cancelled": 0,
    }


async def run_news_option_discovery(
    symbols: list[str],
    config: TradingConfig,
    *,
    now: datetime | None = None,
    research_fetcher: Callable[
        [list[Mapping[str, str]]], Awaitable[dict[str, Any]]
    ] = fetch_symbol_contract_research,
) -> dict[str, Any]:
    """Resolve Luna-discovered news symbols through the shared symbol-chain gate."""

    return await run_symbol_option_discovery(
        symbols,
        config,
        discovery_source="NEWS_AFTER_LUNA",
        max_symbols=3,
        max_expirations=2,
        max_candidates=12,
        now=now,
        research_fetcher=research_fetcher,
    )
