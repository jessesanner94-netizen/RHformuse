"""Dated, bounded paper comparison; all ordinary Python and model-budget gates apply."""

import sqlite3
from datetime import UTC, datetime

from tools.jev_features import number

TRIAL_ID = "options-blind-2026-09-21"
WINDOWS = [("11:00", "12:30"), ("12:30", "14:00"), ("14:00", "15:30")]


def slot(now=None):
    current = now or datetime.now(UTC)
    for index, (start, end) in enumerate(WINDOWS):
        if (
            datetime.fromisoformat(f"2026-09-21T{start}:00-04:00")
            <= current
            < datetime.fromisoformat(f"2026-09-21T{end}:00-04:00")
        ):
            return index
    return None


def active(config, now=None):
    return (
        config.get("OPTIONS_JEV_BLIND_TEST") is True
        and config.get("PAPER_TRADING_ENABLED") is True
        and config.get("LIVE_EXECUTION_ENABLED") is False
        and slot(now) is not None
    )


def sample(config, packet, jev, root, now=None, *, reserve=False):
    candidate = packet.get("candidate", {})
    symbol = candidate.get("symbol")
    scores = jev.get("scores") or {}
    policy = jev.get("policy") or {}
    values = [
        number(scores.get(k)) for k in ("setup_quality", "escalate_to_luna", "false_breakout_risk")
    ]
    maximum = number((policy.get("thresholds") or {}).get("JEV_MAX_FALSE_BREAKOUT"))
    if (
        not active(config, now)
        or symbol not in {"SPY", "QQQ"}
        or candidate.get("option_type") not in {"CALL", "PUT"}
        or packet.get("python_gate", {}).get("status") != "QUALIFIED"
        or jev.get("status") != "OK"
        or jev.get("routing_effect") is not True
        or policy.get("would_escalate") is not False
        or any(v is None or not 0 <= v <= 1 for v in values)
        or maximum is None
        or not 0 <= maximum <= 1
        or values[2] > maximum
    ):
        return False
    path = root / "state/research/options_trial.sqlite3"
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, timeout=5) as db:
        db.execute(
            "CREATE TABLE IF NOT EXISTS reservations "
            "(trial TEXT, slot INTEGER, symbol TEXT, observation TEXT, at TEXT, "
            "PRIMARY KEY(trial,slot))"
        )
        db.execute("BEGIN IMMEDIATE")
        rows = db.execute(
            "SELECT slot,symbol FROM reservations WHERE trial=?", (TRIAL_ID,)
        ).fetchall()
        if any(s == slot(now) for s, _ in rows) or sum(s == symbol for _, s in rows) >= 2:
            return False
        if reserve:
            db.execute(
                "INSERT INTO reservations VALUES (?,?,?,?,?)",
                (
                    TRIAL_ID,
                    slot(now),
                    symbol,
                    jev.get("observation_id"),
                    (now or datetime.now(UTC)).isoformat(),
                ),
            )
        return True
