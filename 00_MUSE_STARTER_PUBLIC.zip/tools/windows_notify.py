"""Send bounded Windows and phone notifications for material outcomes only."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from collections.abc import Callable, Mapping
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib import error, request

NTFY_ENDPOINT = "https://ntfy.sh"
NTFY_TOPIC_PATTERN = re.compile(r"[-_A-Za-z0-9]{20,64}")
OPENING_MARKET_ALERT = "OPTION_MARKET_INVALID_TIME_MARKET_OPEN"


def _review_alert(live: Mapping[str, Any]) -> tuple[str, Mapping[str, Any]]:
    review = live.get("review")
    checks = review.get("checks") if isinstance(review, Mapping) else None
    if not isinstance(checks, Mapping):
        return "", {}
    details = checks.get("details")
    return str(checks.get("alertType") or ""), details if isinstance(details, Mapping) else {}


def _opening_window_end(result: Mapping[str, Any], *, now: datetime) -> datetime | None:
    """Only coalesce this known temporary broker block, never actual exit/fill errors."""
    for key in ("live", "live_decision"):
        live = result.get(key)
        if not isinstance(live, Mapping) or live.get("reason") != "robinhood_order_review_blocked":
            continue
        code, details = _review_alert(live)
        if code != OPENING_MARKET_ALERT:
            continue
        try:
            until = datetime.fromisoformat(str(details.get("regularTradingMarketOpen", "")))
            if until.tzinfo is not None and 0 < (until - now).total_seconds() <= 3600:
                return until
        except (TypeError, ValueError):
            pass
    return None


def _summary(value: Any, *, limit: int = 450) -> str:
    text = " ".join(str(value or "").split())
    return text[: limit - 1] + "…" if len(text) > limit else text


def _decision_and_candidate(
    result: Mapping[str, Any],
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    routing = result.get("routing") if isinstance(result.get("routing"), Mapping) else {}
    decision = (
        routing.get("decision_verdict")
        if isinstance(routing.get("decision_verdict"), Mapping)
        else {}
    )
    if not decision:
        route = routing.get("decision") if isinstance(routing.get("decision"), Mapping) else {}
        output = route.get("output")
        if isinstance(output, str):
            try:
                parsed = json.loads(output)
            except json.JSONDecodeError:
                parsed = None
            if isinstance(parsed, Mapping):
                decision = parsed
    packet = (
        routing.get("decision_packet")
        if isinstance(routing.get("decision_packet"), Mapping)
        else {}
    )
    candidate = packet.get("candidate") if isinstance(packet.get("candidate"), Mapping) else {}
    return decision, candidate


def _contract_label(candidate: Mapping[str, Any]) -> str:
    symbol = str(candidate.get("symbol") or "").upper()
    option_type = str(candidate.get("option_type") or "").upper()
    expiration = str(candidate.get("expiration") or "")
    with suppress(TypeError, ValueError):
        year, month, day = expiration.split("-")
        expiration = f"{int(month)}/{int(day)}/{str(year)[-2:]}"
    strike = candidate.get("strike")
    try:
        strike_text = f"${float(strike):g}"
    except (TypeError, ValueError):
        strike_text = ""
    parts = [part for part in (symbol, expiration, strike_text, option_type) if part]
    label = " ".join(parts) or "candidate unavailable"
    ask = candidate.get("ask")
    with suppress(TypeError, ValueError):
        label += f" @ ${float(ask):.2f}"
    return label


def _exit_detail(event: Mapping[str, Any]) -> str:
    contract = _contract_label({**event, "ask": event.get("fill_price")})
    quantity = event.get("quantity")
    size = f"{quantity}x " if quantity is not None else ""
    detail = f"{event.get('event')}: {size}{contract}"
    with suppress(TypeError, ValueError):
        proceeds = float(event.get("fill_price")) * float(quantity) * 100
        detail += f"; gross proceeds ${proceeds:.2f}"
    try:
        detail += f"; P&L ${float(event.get('realized_pnl')):+.2f}"
    except (TypeError, ValueError):
        detail += "; P&L unavailable"
    if event.get("exit_reason"):
        detail += f"; {event['exit_reason']}"
    return detail


def notification_payload(result: Mapping[str, Any]) -> tuple[str, str] | None:
    crypto = result.get("crypto_event")
    if isinstance(crypto, Mapping):
        kind, event = crypto.get("kind"), crypto.get("body", {})
        symbol = event.get("symbol")
        if symbol not in {"ETH-USD", "BTC-USD"} or kind not in {"paper_entry", "paper_exit"}:
            return None
        action = "BUY" if kind == "paper_entry" else "EXIT"
        price = event.get("entry") if action == "BUY" else event.get("fill")
        message = (
            f"SIMULATED {action} {symbol}; {event.get('quantity')} coins at ${float(price):,.2f}"
        )
        if action == "EXIT":
            message += f"; net P&L ${float(event['net_pnl']):+.2f}; {event.get('reason')}"
        message += f"; price source {event.get('venue')}; no real order."
        return f"Crypto PAPER — {symbol} {action}", _summary(message)
    cycle = str(result.get("cycle", "scheduled")).title()
    if result.get("status") == "ERROR":
        detail = str(result.get("error") or result.get("reason") or "Scheduled cycle failed")
        if "timeoutexpired" in detail.lower() and "reddit" in detail.lower():
            return f"Robinhood Agentic — {cycle} Error", (
                "Reddit search timed out. This scan could not finish; "
                "the next scheduled run will try again. Details saved in local logs."
            )
        return f"Robinhood Agentic — {cycle} Error", _summary(
            detail
        )
    for key in ("live", "live_decision"):
        live = result.get(key)
        if not isinstance(live, Mapping):
            continue
        if live.get("manual_action") == "CANCEL_ORDER":
            order_id = live.get("order_id") or "unknown"
            symbol = f"{live.get('symbol')} " if live.get("symbol") else ""
            reason = live.get("reason") or "The working order should be reviewed"
            return "Robinhood — CANCEL ORDER", _summary(
                f"Manual action required in the Robinhood app. {symbol}order {order_id}. "
                f"Reason: {reason}"
            )
        event = live.get("event")
        if isinstance(event, Mapping) and event.get("event") in {
            "LIVE_ENTRY_FILLED",
            "LIVE_EXIT_FILLED",
        }:
            detail = f"{event.get('event')}: {event.get('symbol')} at ${event.get('fill_price')}"
            if event.get("event") == "LIVE_ENTRY_FILLED":
                style = str(event.get("trade_style") or "").upper()
                if style in {"DAY", "SWING"}:
                    detail += f"; {style}"
            if event.get("event") == "LIVE_EXIT_FILLED":
                detail = _exit_detail(event)
            return f"Robinhood Live — {cycle}", _summary(detail)
        if live.get("status") == "SUBMITTED":
            decision, candidate = _decision_and_candidate(result)
            style = str(decision.get("trade_style") or "").upper()
            style_text = f"; {style}" if style in {"DAY", "SWING"} else ""
            return f"Robinhood Live — {cycle}", _summary(
                f"{live.get('purpose')} order submitted — {_contract_label(candidate)}"
                f"{style_text}; order {live.get('order_id')}"
            )
        if live.get("status") in {"ATTENTION", "BLOCKED"}:
            if live.get("submission_state") == "UNKNOWN":
                return f"Robinhood Live — {cycle} Attention", _summary(
                    "Order status is uncertain. New entries are blocked to prevent a duplicate. "
                    + str(
                        live.get("error") or live.get("reason") or "Broker reconciliation required"
                    )
                )
            if live.get("reason") == "robinhood_order_review_blocked":
                code, details = _review_alert(live)
                symbol = str(live.get("symbol") or "Option")
                action = (
                    "Exit" if live.get("exit_reason") or live.get("purpose") == "EXIT" else "Order"
                )
                reason = str(live.get("exit_reason") or "")
                if code == OPENING_MARKET_ALERT:
                    return "Robinhood Live — Market-order timing", _summary(
                        f"NO ORDER — {symbol} {action.lower()} blocked "
                        f"({reason or 'broker review'}). "
                        f"Robinhood reports market orders available from "
                        f"{details.get('regularTradingMarketOpen', 'unknown time')}. "
                        f"Existing monitoring continues; no fill is guaranteed. "
                        f"Broker: {code}."
                    )
                review = live.get("review", {})
                cause = code or ", ".join(str(item) for item in review.get("reasons", []))
                return f"Robinhood Live — {cycle} Attention", _summary(
                    f"NO ORDER — {symbol} {action.lower()} blocked. "
                    f"Broker: {cause or 'review failed'}. "
                    f"Details: {json.dumps(details, separators=(',', ':'))}. "
                    f"Checks: {json.dumps(review.get('checks'), separators=(',', ':'))}"
                )
            decision, candidate = _decision_and_candidate(result)
            if key == "live_decision" and decision.get("action") == "BUY":
                blockers = live.get("blockers") if isinstance(live.get("blockers"), list) else []
                blocker_text = f" ({', '.join(str(item) for item in blockers)})" if blockers else ""
                cause = live.get("error") or live.get("reason") or "pre-order check failed"
                return f"Robinhood Live — {cycle} Attention", _summary(
                    f"NO ORDER — {_contract_label(candidate)}. BUY blocked before submission: "
                    f"{cause}{blocker_text}. "
                    f"Orders placed: {live.get('orders_placed', 0)}."
                )
            return f"Robinhood Live — {cycle} Attention", _summary(
                live.get("reason") or "Live execution needs attention"
            )
    paper = result.get("paper")
    if isinstance(paper, Mapping):
        paper_events = paper.get("paper_events")
        if isinstance(paper_events, list) and paper_events:
            event = paper_events[-1]
            if isinstance(event, Mapping):
                if event.get("event") == "PAPER_EXIT":
                    return f"Robinhood Paper — {cycle}", _summary(_exit_detail(event))
                return f"Robinhood Paper — {cycle}", _summary(
                    f"{event.get('event')}: {event.get('symbol')} "
                    f"{event.get('exit_reason', '')} P&L ${event.get('realized_pnl', 0)}"
                )
        attention = paper.get("attention")
        if paper.get("status") == "ATTENTION" and isinstance(attention, list):
            codes = [
                str(item.get("code"))
                for item in attention
                if isinstance(item, Mapping) and item.get("code")
            ]
            return f"Robinhood Paper — {cycle}", _summary(
                "Paper position data attention: " + ", ".join(codes)
            )
    paper_decision = result.get("paper_decision")
    if isinstance(paper_decision, Mapping):
        if paper_decision.get("status") == "BLOCKED":
            _, candidate = _decision_and_candidate(result)
            reasons = paper_decision.get("reasons") or [
                paper_decision.get("reason") or "final paper checks failed"
            ]
            return f"Robinhood Paper — {cycle} Attention", _summary(
                f"NO PAPER TRADE — {_contract_label(candidate)}. "
                f"Entry/exit blocked: {', '.join(str(reason) for reason in reasons)}"
            )
        event = paper_decision.get("event")
        if isinstance(event, Mapping) and event.get("event") in {
            "PAPER_ENTRY",
            "PAPER_EXIT",
        }:
            detail = f"{event.get('event')}: {event.get('symbol')} at ${event.get('fill_price')}"
            if event.get("event") == "PAPER_ENTRY":
                contract = _contract_label({**event, "ask": event.get("fill_price")})
                quantity = event.get("quantity")
                size = f"{quantity}x " if quantity is not None else ""
                detail = f"PAPER_ENTRY: {size}{contract}"
                style = str(event.get("trade_style") or "").upper()
                if style in {"DAY", "SWING"}:
                    detail += f"; {style}"
                with suppress(TypeError, ValueError):
                    premium = float(event.get("fill_price")) * float(quantity) * 100
                    detail += f"; premium ${premium:.2f}"
            if event.get("event") == "PAPER_EXIT":
                detail = _exit_detail(event)
            return f"Robinhood Paper — {cycle}", _summary(detail)
    monitor = result.get("monitor") or result.get("position_preflight")
    if isinstance(monitor, Mapping) and monitor.get("wake_codex") is True:
        codes = [
            item.get("code")
            for item in monitor.get("triggers", [])
            if isinstance(item, Mapping) and item.get("code")
        ]
        return f"Robinhood Agentic — {cycle}", _summary("Position attention: " + ", ".join(codes))
    routing = result.get("routing")
    if not isinstance(routing, Mapping):
        return None
    luna = routing.get("luna")
    sol = routing.get("sol")
    decision = routing.get("decision")
    if isinstance(decision, Mapping) and decision.get("status") in {
        "COMPLETED",
        "ERROR",
    }:
        verdict, candidate = _decision_and_candidate(result)
        if decision.get("status") == "ERROR":
            reason = decision.get("reason")
            if reason == "invalid_json_schema" or "invalid_json_schema" in str(
                decision.get("error", "")
            ):
                detail = "Luna could not run: the API rejected its response schema."
            elif reason == "codex_decision_timeout":
                detail = "Luna timed out before returning a valid decision."
            else:
                detail = (
                    "Luna failed before returning a valid decision; details saved in local logs."
                )
            return f"Robinhood Agentic — {cycle} Error", _summary(
                f"NO ORDER — {_contract_label(candidate)}. {detail}"
            )
        action = str(verdict.get("action") or "").upper()
        if action == "WATCH":
            saved = routing.get("watch_saved") or {}
            if saved.get("status") not in {"SAVED", "REPLACED"}:
                detail = saved.get("reason") or (
                    "The proposed watch failed validation or capacity checks"
                )
                return f"Robinhood Agentic — {cycle} Attention", _summary(
                    f"WATCH NOT SAVED — {_contract_label(candidate)}. "
                    f"{detail}; "
                    "no active monitoring was created."
                )
        if action:
            reason = verdict.get("reason") or "No reason supplied."
            return f"Robinhood Agentic — {cycle}", _summary(
                f"{action} — {_contract_label(candidate)}. {reason}"
            )
        detail = "NO ORDER — model returned no recognizable decision; details saved in local logs."
        return f"Robinhood Agentic — {cycle}", _summary(detail)
    if isinstance(luna, Mapping) and luna.get("status") == "ERROR":
        return f"Robinhood Agentic — {cycle}", _summary(
            "Luna route error: " + str(luna.get("reason") or luna.get("error"))
        )
    if isinstance(sol, Mapping) and sol.get("status") in {"COMPLETED", "ERROR"}:
        detail = sol.get("output") or sol.get("error") or sol.get("reason") or sol.get("status")
        return f"Robinhood Agentic — {cycle}", _summary(detail)
    return None


def send_ntfy_notification(
    title: str,
    message: str,
    *,
    topic: str | None = None,
    opener: Callable[..., Any] = request.urlopen,
) -> dict[str, Any]:
    """Publish one material alert to a free hosted ntfy topic.

    The topic is intentionally read from the environment and never returned or logged because an
    anonymous ntfy topic acts as its access secret.
    """

    resolved_topic = str(topic if topic is not None else os.environ.get("NTFY_TOPIC", "")).strip()
    if not resolved_topic:
        return {"status": "SKIPPED", "reason": "ntfy_topic_not_configured"}
    if NTFY_TOPIC_PATTERN.fullmatch(resolved_topic) is None:
        return {"status": "ERROR", "reason": "ntfy_topic_invalid"}
    is_warning = any(
        token in f"{title} {message}".upper()
        for token in ("CANCEL", "ERROR", "ATTENTION", "BLOCKED")
    )
    body = json.dumps(
        {
            "topic": resolved_topic,
            "title": _summary(title, limit=120),
            "message": _summary(message),
            # User disabled urgent/high-priority phone alerts, including errors and cancellations.
            "priority": 3,
            "tags": ["warning"] if is_warning else ["chart_with_upwards_trend"],
        }
    ).encode("utf-8")
    notification_request = request.Request(
        NTFY_ENDPOINT,
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with opener(notification_request, timeout=10) as response:
            status_code = int(getattr(response, "status", 200))
    except error.HTTPError as exc:
        return {"status": "ERROR", "reason": "ntfy_http_error", "http_status": exc.code}
    except (OSError, error.URLError) as exc:
        return {
            "status": "ERROR",
            "reason": "ntfy_connection_error",
            "error": _summary(type(exc).__name__, limit=80),
        }
    if not 200 <= status_code < 300:
        return {"status": "ERROR", "reason": "ntfy_http_error", "http_status": status_code}
    return {"status": "SENT", "http_status": status_code}


def _send_windows_notification(
    title: str,
    message: str,
    *,
    project_root: Path,
    runner: Callable[..., subprocess.CompletedProcess[str]],
) -> dict[str, Any]:
    if os.name != "nt":
        return {"status": "SKIPPED", "reason": "windows_toast_unavailable"}
    script = project_root / "automation" / "show_notification.ps1"
    if not script.exists():
        return {"status": "ERROR", "reason": "notification_script_missing"}
    completed = runner(
        [
            "powershell.exe",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script),
            "-Title",
            title,
            "-Message",
            message,
        ],
        text=True,
        capture_output=True,
        check=False,
        timeout=15,
    )
    return {
        "status": "SENT" if completed.returncode == 0 else "ERROR",
        "exit_code": completed.returncode,
        "error": completed.stderr.strip(),
    }


def send_notification(
    result: Mapping[str, Any],
    *,
    project_root: Path,
    execute: bool = False,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    ntfy_sender: Callable[[str, str], dict[str, Any]] = send_ntfy_notification,
    now: datetime | None = None,
) -> dict[str, Any]:
    payload = notification_payload(result)
    if payload is None:
        return {"status": "SKIPPED", "reason": "no_material_user_alert"}
    title, message = payload
    if not execute:
        return {"status": "PREVIEW", "title": title, "message": message}

    def deliver() -> dict[str, Any]:
        channels = {
            "windows": _send_windows_notification(
                title,
                message,
                project_root=project_root,
                runner=runner,
            ),
            "ntfy": ntfy_sender(title, message),
        }
        sent = any(channel.get("status") == "SENT" for channel in channels.values())
        return {
            "status": "SENT" if sent else "ERROR",
            "title": title,
            "message": message,
            "channels": channels,
        }

    current = now or datetime.now(UTC)
    until = _opening_window_end(result, now=current)
    if until is None or title != "Robinhood Live — Market-order timing":
        return deliver()
    # Shared between the existing positions/opportunities processes. This schedules nothing and
    # never suppresses broker polling, review, submissions, fills, or post-window errors.
    from tools.live_trading import _exclusive_lock
    from tools.state_manager import guarded_json_update

    path = project_root / "state" / "runtime" / "opening_review_notifications.json"
    contract_id = next(
        (
            str(live.get("contract_identifier") or "")
            for key in ("live", "live_decision")
            if isinstance(live := result.get(key), Mapping)
            and live.get("reason") == "robinhood_order_review_blocked"
            and _review_alert(live)[0] == OPENING_MARKET_ALERT
        ),
        "",
    )
    fingerprint = hashlib.sha256(f"{contract_id}\n{title}\n{message}".encode()).hexdigest()
    outcome = None
    try:
        with _exclusive_lock(path):
            seen = {}
            if path.exists():
                with suppress(ValueError, OSError):
                    loaded = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(loaded, dict) and loaded.get("until") == until.isoformat():
                        seen = loaded.get("sent", {})
            if not isinstance(seen, dict):
                seen = {}
            if fingerprint in seen:
                return {
                    "status": "SKIPPED",
                    "reason": "opening_review_already_notified",
                    "broker_window_end": until.isoformat(),
                }
            outcome = deliver()
            # A failed phone delivery must not be hidden just because the desktop toast succeeded.
            phone = outcome["channels"]["ntfy"]
            if phone.get("status") == "SENT" or (
                phone.get("status") == "SKIPPED" and outcome["status"] == "SENT"
            ):
                seen[fingerprint] = current.isoformat()
                guarded_json_update(path, {"until": until.isoformat(), "sent": seen}, commit=True)
            return outcome
    except OSError:
        # Notification-cache failure must not hide a trading alert.
        return outcome if outcome is not None else deliver()
