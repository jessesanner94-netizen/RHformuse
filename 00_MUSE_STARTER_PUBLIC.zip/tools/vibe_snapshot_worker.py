"""Produce a compact multi-timeframe Vibe/Yahoo snapshot.

This worker is launched with Vibe-Trading's own Python environment so the scheduled controller does
not need to install or import Vibe's large analytics dependency tree. Raw bars never leave this
process; only deterministic indicator summaries are printed.
"""

from __future__ import annotations

import argparse
import json
import math
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _frame(value: Any):
    import pandas as pd

    if isinstance(value, pd.DataFrame):
        frame = value.copy()
    elif isinstance(value, list):
        frame = pd.DataFrame(value)
    elif isinstance(value, dict) and isinstance(value.get("data"), list):
        frame = pd.DataFrame(value["data"])
    else:
        try:
            frame = pd.DataFrame(value)
        except (TypeError, ValueError):
            return None
    if frame.empty:
        return None
    lower = {str(column).lower(): column for column in frame.columns}
    close_key = next((lower[key] for key in ("close", "adj_close") if key in lower), None)
    if close_key is None:
        return None
    frame["_close"] = pd.to_numeric(frame[close_key], errors="coerce")
    volume_key = lower.get("volume")
    frame["_volume"] = (
        pd.to_numeric(frame[volume_key], errors="coerce") if volume_key is not None else 0.0
    )
    for source, target in (("open", "_open"), ("high", "_high"), ("low", "_low")):
        source_key = lower.get(source)
        frame[target] = (
            pd.to_numeric(frame[source_key], errors="coerce")
            if source_key is not None
            else frame["_close"]
        )
    timestamp_key = next(
        (lower[key] for key in ("trade_date", "datetime", "timestamp", "date") if key in lower),
        None,
    )
    if timestamp_key is not None:
        frame["_timestamp"] = pd.to_datetime(frame[timestamp_key], errors="coerce", utc=True)
        frame = frame.dropna(subset=["_timestamp"]).sort_values("_timestamp")
    frame = frame.dropna(subset=["_close"])
    return frame if not frame.empty else None


def _rsi(close, period: int = 14) -> float | None:
    if len(close) < period + 1:
        return None
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period).mean().iloc[-1]
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period).mean().iloc[-1]
    if avg_loss == 0:
        return 100.0
    return float(100 - 100 / (1 + avg_gain / avg_loss))


def _summary(raw: Any, *, max_bars: int | None = None) -> dict[str, Any]:
    frame = _frame(raw)
    if frame is None:
        return {"status": "UNAVAILABLE"}
    if max_bars is not None and max_bars > 0:
        frame = frame.tail(max_bars)
    close = frame["_close"].astype(float)
    volume = frame["_volume"].astype(float)
    latest = float(close.iloc[-1])
    sma20 = float(close.tail(20).mean()) if len(close) >= 20 else None
    sma50 = float(close.tail(50).mean()) if len(close) >= 50 else None
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    macd_signal = macd.ewm(span=9, adjust=False).mean()
    macd_hist = float((macd - macd_signal).iloc[-1]) if len(close) >= 35 else None
    volume_ratio = None
    if len(volume) >= 20 and float(volume.tail(20).iloc[:-1].mean()) > 0:
        volume_ratio = float(volume.iloc[-1] / volume.tail(20).iloc[:-1].mean())

    def change(bars: int) -> float | None:
        if len(close) <= bars or float(close.iloc[-bars - 1]) == 0:
            return None
        return float((latest / float(close.iloc[-bars - 1]) - 1) * 100)

    score = 0
    if sma20 is not None:
        score += 1 if latest > sma20 else -1
    if sma20 is not None and sma50 is not None:
        score += 1 if sma20 > sma50 else -1
    if macd_hist is not None:
        score += 1 if macd_hist > 0 else -1
    rsi = _rsi(close)
    if rsi is not None:
        score += 1 if rsi >= 55 else -1 if rsi <= 45 else 0
    short_change = change(3)
    if short_change is not None:
        score += 1 if short_change > 0 else -1 if short_change < 0 else 0
    label = "BULLISH" if score >= 2 else "BEARISH" if score <= -2 else "NEUTRAL"
    return {
        "status": "OK",
        "bars": int(len(close)),
        "latest_close": round(latest, 4),
        "change_1_bar_percent": round(change(1), 4) if change(1) is not None else None,
        "change_3_bar_percent": round(short_change, 4) if short_change is not None else None,
        "change_10_bar_percent": round(change(10), 4) if change(10) is not None else None,
        "sma_20": round(sma20, 4) if sma20 is not None else None,
        "sma_50": round(sma50, 4) if sma50 is not None else None,
        "rsi_14": round(rsi, 2) if rsi is not None else None,
        "macd_histogram": round(macd_hist, 5) if macd_hist is not None else None,
        "relative_volume_20": round(volume_ratio, 3) if volume_ratio is not None else None,
        "trend_score": score,
        "trend": label,
    }


def _entry_timing(session, *, now: datetime) -> dict[str, Any]:
    """Use only closed regular-session bars; historical sweeps are not fresh triggers."""

    closed = session[session["_timestamp"] + timedelta(minutes=5) <= now].copy()
    if len(closed) < 4:
        return {"status": "UNAVAILABLE", "reason": "not_enough_completed_bars"}
    last = closed.iloc[-1]
    bar_end = last["_timestamp"] + timedelta(minutes=5)
    age = (now - bar_end).total_seconds()
    same_day = (
        bar_end.tz_convert("America/New_York").date()
        == now.astimezone(ZoneInfo("America/New_York")).date()
    )
    opening = closed[closed["_eastern"].dt.time < datetime.strptime("09:45", "%H:%M").time()]
    if len(opening) != 3:
        return {"status": "UNAVAILABLE", "reason": "opening_range_incomplete"}
    volume = closed["_volume"]
    vwap = None
    if volume.notna().all() and (volume >= 0).all() and volume.sum() > 0:
        typical = (closed["_high"] + closed["_low"] + closed["_close"]) / 3
        vwap = _finite((typical * volume).sum() / volume.sum())
    close = float(last["_close"])
    open_price = float(last["_open"])
    high = float(last["_high"])
    low = float(last["_low"])
    session_high = float(closed["_high"].max())
    session_low = float(closed["_low"].min())
    # A same-candle test and directional close, not "crossed at some time today".
    bearish_levels = {"OPENING_RANGE_HIGH": float(opening["_high"].max())}
    bullish_levels = {"OPENING_RANGE_LOW": float(opening["_low"].min())}
    if vwap is not None:
        bearish_levels["SESSION_VWAP"] = vwap
        bullish_levels["SESSION_VWAP"] = vwap
    bearish = [
        name
        for name, level in bearish_levels.items()
        if high >= level > close and close < open_price
    ]
    bullish = [
        name
        for name, level in bullish_levels.items()
        if low <= level < close and close > open_price
    ]
    return {
        "status": "OK" if same_day and 0 <= age <= 600 else "STALE",
        "completed_bar_at": bar_end.isoformat(),
        "completed_bar_age_seconds": round(age, 1),
        "latest_completed_close": round(close, 4),
        "session_vwap": round(vwap, 4) if vwap is not None else None,
        "vwap_distance_percent": round((close / vwap - 1) * 100, 4) if vwap else None,
        "session_high": round(session_high, 4),
        "session_low": round(session_low, 4),
        "distance_from_session_high_percent": round((close / session_high - 1) * 100, 4),
        "distance_from_session_low_percent": round((close / session_low - 1) * 100, 4),
        "bullish_confirmation_levels": bullish,
        "bearish_confirmation_levels": bearish,
    }


def _intraday_structure(raw: Any, *, now: datetime | None = None) -> dict[str, Any]:
    """Describe today's opening-range/reversal structure from consecutive five-minute bars."""

    frame = _frame(raw)
    if frame is None or "_timestamp" not in frame:
        return {"status": "UNAVAILABLE"}
    local = frame.assign(_eastern=frame["_timestamp"].dt.tz_convert("America/New_York"))
    local = local[
        (local["_eastern"].dt.time >= datetime.strptime("09:30", "%H:%M").time())
        & (local["_eastern"].dt.time < datetime.strptime("16:00", "%H:%M").time())
    ]
    if local.empty:
        return {"status": "UNAVAILABLE"}
    latest_date = local["_eastern"].dt.date.iloc[-1]
    session = local[local["_eastern"].dt.date == latest_date]
    opening = session[session["_eastern"].dt.time < datetime.strptime("09:45", "%H:%M").time()]
    if len(opening) < 3 or len(session) < 4:
        return {"status": "UNAVAILABLE", "reason": "opening_range_incomplete"}

    after_opening = session.iloc[len(opening) :]
    opening_high = float(opening["_high"].max())
    opening_low = float(opening["_low"].min())
    latest = float(session["_close"].iloc[-1])
    opening_midpoint = (opening_high + opening_low) / 2
    tolerance = max(latest * 0.0005, 0.01)
    post_low = float(after_opening["_low"].min()) if not after_opening.empty else opening_low
    post_high = float(after_opening["_high"].max()) if not after_opening.empty else opening_high
    swept_low = post_low < opening_low - tolerance
    swept_high = post_high > opening_high + tolerance
    reclaimed_low = swept_low and latest > opening_low
    rejected_high = swept_high and latest < opening_high
    held_low = post_low >= opening_low - tolerance
    held_high = post_high <= opening_high + tolerance

    bullish_points = int(held_low) + 2 * int(reclaimed_low) + int(latest >= opening_midpoint)
    bearish_points = int(held_high) + 2 * int(rejected_high) + int(latest < opening_midpoint)
    if len(session) >= 4:
        prior = float(session["_close"].iloc[-4])
        bullish_points += int(latest > prior)
        bearish_points += int(latest < prior)
    bias_score = bullish_points - bearish_points
    bias = "BULLISH" if bias_score >= 2 else "BEARISH" if bias_score <= -2 else "NEUTRAL"
    range_width = opening_high - opening_low
    range_position = (latest - opening_low) / range_width if range_width > 0 else None
    return {
        "status": "OK",
        "session_date": latest_date.isoformat(),
        "bars": int(len(session)),
        "opening_range_high": round(opening_high, 4),
        "opening_range_low": round(opening_low, 4),
        "opening_range_midpoint": round(opening_midpoint, 4),
        "latest_close": round(latest, 4),
        "opening_range_position": round(range_position, 3) if range_position is not None else None,
        "held_opening_range_low": held_low,
        "held_opening_range_high": held_high,
        "swept_and_reclaimed_opening_range_low": reclaimed_low,
        "swept_and_rejected_opening_range_high": rejected_high,
        "bias_score": bias_score,
        "bias": bias,
        "entry_timing": _entry_timing(session, now=now or datetime.now(UTC)),
    }


_NON_EARNING_INSTRUMENT_TYPES = frozenset({"ETF", "ETN", "INDEX", "MUTUALFUND"})


def _news_and_earnings(
    symbol: str,
) -> tuple[list[dict[str, str]], dict[str, Any], str]:
    headlines: list[dict[str, str]] = []
    earnings: dict[str, Any] = {"status": "UNAVAILABLE", "next_date": None}
    instrument_type = "UNKNOWN"
    try:
        import yfinance as yf

        ticker = yf.Ticker(symbol)
    except Exception as exc:
        earnings["error"] = type(exc).__name__
        return headlines, earnings, instrument_type
    try:
        metadata = ticker.get_history_metadata()
        if isinstance(metadata, dict):
            instrument_type = str(metadata.get("instrumentType") or "UNKNOWN").upper()
    except Exception as exc:
        earnings["instrument_type_error"] = type(exc).__name__
    if instrument_type in _NON_EARNING_INSTRUMENT_TYPES:
        earnings = {"status": "NOT_APPLICABLE", "next_date": None}
    try:
        for row in (ticker.news or [])[:8]:
            content = row.get("content") if isinstance(row, dict) else None
            body = content if isinstance(content, dict) else row if isinstance(row, dict) else {}
            title = str(body.get("title") or "").strip()
            provider = body.get("provider")
            source = (
                str(provider.get("displayName") or "").strip()
                if isinstance(provider, dict)
                else str(body.get("publisher") or "").strip()
            )
            published = str(body.get("pubDate") or body.get("providerPublishTime") or "")
            if title:
                headlines.append(
                    {"title": title[:220], "source": source[:80], "published": published[:40]}
                )
    except Exception:
        pass
    if instrument_type in _NON_EARNING_INSTRUMENT_TYPES:
        return headlines, earnings, instrument_type
    try:
        calendar = ticker.calendar
        raw_date = None
        if isinstance(calendar, dict):
            raw_date = calendar.get("Earnings Date") or calendar.get("EarningsDate")
        elif calendar is not None and hasattr(calendar, "loc"):
            for key in ("Earnings Date", "EarningsDate"):
                if key in calendar.index:
                    raw_date = calendar.loc[key]
                    break
        if isinstance(raw_date, (list, tuple)) and raw_date:
            raw_date = raw_date[0]
        if hasattr(raw_date, "iloc") and len(raw_date):
            raw_date = raw_date.iloc[0]
        if raw_date is not None:
            parsed = str(raw_date)
            earnings = {"status": "AVAILABLE", "next_date": parsed[:32]}
    except Exception as exc:
        earnings["error"] = type(exc).__name__
    return headlines, earnings, instrument_type


def build_snapshot(symbol: str, *, intraday_only: bool = False) -> dict[str, Any]:
    from src.market_data import fetch_market_data

    normalized = symbol.strip().upper()
    code = normalized if normalized.endswith(".US") else f"{normalized}.US"
    # Yahoo treats end_date as exclusive; tomorrow includes the current session.
    end = datetime.now(UTC).date() + timedelta(days=1)
    specs = {
        "1D": (end - timedelta(days=420), "1D", 260),
        "4H": (end - timedelta(days=120), "4H", 220),
        "15M": (end - timedelta(days=30), "15m", 220),
        "5M": (end - timedelta(days=10), "5m", 220),
    }
    if intraday_only:
        specs = {label: spec for label, spec in specs.items() if label in {"5M", "15M"}}
    frames: dict[str, Any] = {}
    raw_frames: dict[str, Any] = {}
    errors: list[dict[str, str]] = []
    for label, (start, interval, rows) in specs.items():
        try:
            payload = fetch_market_data(
                codes=[code],
                start_date=start.isoformat(),
                end_date=end.isoformat(),
                source="auto",
                interval=interval,
                max_rows=0,
            )
            raw = payload.get(code)
            if intraday_only:
                # Continuation decisions use completed candles, never the developing bar.
                frame = _frame(raw)
                minutes = 5 if label == "5M" else 15
                if frame is None or "_timestamp" not in frame:
                    raw = None
                else:
                    raw = frame[
                        frame["_timestamp"] + timedelta(minutes=minutes) <= datetime.now(UTC)
                    ]
            raw_frames[label] = raw
            # Vibe's positive max_rows policy evenly downsamples oversized intraday payloads. That
            # destroys bar adjacency while retaining the requested interval label. Fetch all raw
            # rows and then keep the newest consecutive window locally.
            frames[label] = _summary(raw, max_bars=rows)
        except Exception as exc:
            frames[label] = {"status": "UNAVAILABLE"}
            errors.append({"timeframe": label, "error": type(exc).__name__})
    intraday_structure = _intraday_structure(raw_frames.get("5M"))
    structure_score = int(intraday_structure.get("bias_score", 0))
    day_score = (
        sum(
            int(frames.get(label, {}).get("trend_score", 0)) * weight
            for label, weight in (("5M", 2), ("15M", 1))
        )
        + structure_score * 2
    )
    swing_score = sum(
        int(frames.get(label, {}).get("trend_score", 0)) * weight
        for label, weight in (("4H", 2), ("1D", 2), ("15M", 1))
    )
    if intraday_only:
        headlines, earnings, instrument_type = [], {"status": "NOT_REQUESTED"}, "UNKNOWN"
    else:
        headlines, earnings, instrument_type = _news_and_earnings(normalized.removesuffix(".US"))
    return {
        "status": "OK"
        if any(item.get("status") == "OK" for item in frames.values())
        else "UNAVAILABLE",
        "symbol": normalized.removesuffix(".US"),
        "as_of": datetime.now(UTC).isoformat(),
        "timeframes": frames,
        "style_scores": {"DAY": day_score, "SWING": swing_score},
        "intraday_structure": intraday_structure,
        "instrument_type": instrument_type,
        "headlines": headlines,
        "earnings": earnings,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--intraday-only", action="store_true")
    args = parser.parse_args()
    try:
        result = build_snapshot(args.symbol, intraday_only=args.intraday_only)
    except Exception as exc:
        result = {"status": "ERROR", "error": f"{type(exc).__name__}: {exc}"}
    print(json.dumps(result, separators=(",", ":"), ensure_ascii=False))
    return 0 if result.get("status") != "ERROR" else 1


if __name__ == "__main__":
    raise SystemExit(main())
