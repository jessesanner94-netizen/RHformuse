"""Public ETH/USD research fallback; no accounts, credentials or order operations."""

import asyncio

from tools.crypto_market_data import _book, _candles, _default_transport, _fetch, _iso, _utc
from tools.crypto_symbols import validate_symbol

VENUE = "BINANCE_US"
DEPTH = "https://api.binance.us/api/v3/depth?symbol=ETHUSD&limit=50"
KLINES = "https://api.binance.us/api/v3/klines?symbol=ETHUSD&interval=5m&limit=300"


async def fetch_quote(now=None, transport=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    depth_url = DEPTH.replace("ETHUSD", symbol.replace("-", ""))
    depth = await _fetch(transport or _default_transport, depth_url)
    current = _utc(now)
    book = _book(depth, receipt_time=current, symbol=symbol)
    bid, ask = float(book["bids"][0]["price"]), float(book["asks"][0]["price"])
    return {
        "symbol": symbol,
        "bid": bid,
        "ask": ask,
        "price": (bid + ask) / 2,
        "updated_at": _iso(current),
        "timestamp_source": "receipt_time",
        "venue": VENUE,
    }


async def fetch_snapshot(now=None, transport=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    urls = tuple(url.replace("ETHUSD", symbol.replace("-", "")) for url in (DEPTH, KLINES))
    try:
        depth, rows = await asyncio.gather(
            *(_fetch(transport or _default_transport, url) for url in urls)
        )
        current = _utc(now)
        book = _book(depth, receipt_time=current, symbol=symbol)
        if not isinstance(rows, list) or len(rows) > 300:
            raise ValueError("invalid_klines")
        normalized = []
        for row in rows:
            if len(row) != 12 or row[6] != row[0] + 299999:
                raise ValueError("invalid_kline_interval")
            normalized.append([row[0] / 1000, row[3], row[2], row[1], row[4], row[5]])
        candles = _candles(normalized, now=current, allow_zero_volume=True)
        bid, ask = float(book["bids"][0]["price"]), float(book["asks"][0]["price"])
        return {
            "status": "OK",
            "symbol": symbol,
            "venue": VENUE,
            "quote": {
                "symbol": symbol,
                "bid": bid,
                "ask": ask,
                "price": (bid + ask) / 2,
                "updated_at": _iso(current),
                "timestamp_source": "receipt_time",
                "venue": VENUE,
            },
            "book": book,
            "candles_5m": candles,
        }
    except Exception as exc:
        return {"status": "UNAVAILABLE", "venue": VENUE, "reason": type(exc).__name__}
