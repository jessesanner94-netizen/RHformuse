"""Build the small, tool-grounded packet consumed by the isolated Luna decision agent."""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import re
from collections.abc import Callable, Mapping
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.config import TradingConfig
from tools.economic_calendar import economic_context
from tools.paper_trading import net_reward_risk
from tools.portfolio_risk import evaluate_risk
from tools.position_exposure import normalized_symbol, opportunity_held_symbols
from tools.state_manager import guarded_json_update
from tools.unusual_whales import UnusualWhalesClient
from tools.vibe_snapshot import fetch_vibe_snapshot

EASTERN = ZoneInfo("America/New_York")
MAX_PACKET_CANDIDATES = 1
MAX_PRE_MODEL_CANDIDATES = 4
MAX_CATALYSTS = 3
MAX_PACKET_CHARACTERS = 18_000

_BULLISH = {
    "approval": 2,
    "approved": 2,
    "beat": 2,
    "beats": 2,
    "breakout": 2,
    "bullish": 2,
    "buyback": 2,
    "contract": 1,
    "growth": 1,
    "partnership": 1,
    "raises guidance": 3,
    "record revenue": 2,
    "rally": 1,
    "surge": 1,
    "upgrade": 2,
}
_BEARISH = {
    "bankruptcy": -4,
    "bearish": -2,
    "cuts guidance": -3,
    "dilution": -3,
    "downgrade": -2,
    "falls": -1,
    "fraud": -4,
    "investigation": -2,
    "lawsuit": -2,
    "layoffs": -1,
    "miss": -2,
    "misses": -2,
    "non-compliance": -3,
    "offering": -2,
    "plunge": -2,
    "probe": -2,
}


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _score_text(text: str) -> int:
    normalized = re.sub(r"\s+", " ", text.casefold())
    return sum(
        weight for phrase, weight in (*_BULLISH.items(), *_BEARISH.items()) if phrase in normalized
    )


def _relative_direction(label: Any, desired: str) -> str:
    normalized = str(label or "").upper()
    if "BULLISH" in normalized:
        observed = "BULLISH"
    elif "BEARISH" in normalized:
        observed = "BEARISH"
    else:
        return "NEUTRAL"
    return "SUPPORTING" if observed == desired else "OPPOSING"


def _pass_recheck_state(
    packet: Mapping[str, Any] | None,
    candidate: Mapping[str, Any],
) -> dict[str, Any]:
    """Reduce Python-observed evidence to material reasons to reconsider a cached PASS."""

    packet = packet if isinstance(packet, Mapping) else {}
    option_type = str(candidate.get("option_type") or "").upper()
    desired = "BEARISH" if option_type == "PUT" else "BULLISH"
    technical = packet.get("technical") if isinstance(packet.get("technical"), Mapping) else {}
    timeframes = (
        technical.get("timeframes") if isinstance(technical.get("timeframes"), Mapping) else {}
    )
    trading_policy = (
        packet.get("trading_policy") if isinstance(packet.get("trading_policy"), Mapping) else {}
    )
    day_only_options = trading_policy.get("day_only_options") is True
    intraday = (
        technical.get("intraday_structure")
        if isinstance(technical.get("intraday_structure"), Mapping)
        else {}
    )
    aligned = 0
    opposed = 0
    relevant_timeframes = (
        (timeframes.get(name, {}) for name in ("5M", "15M"))
        if day_only_options
        else timeframes.values()
    )
    for values in relevant_timeframes:
        if not isinstance(values, Mapping):
            continue
        trend = str(values.get("trend") or "").upper()
        if trend == desired:
            aligned += 1
        elif trend in {"BULLISH", "BEARISH"}:
            opposed += 1

    uw = packet.get("unusual_whales") if isinstance(packet.get("unusual_whales"), Mapping) else {}
    news = packet.get("news") if isinstance(packet.get("news"), Mapping) else {}
    social = packet.get("social") if isinstance(packet.get("social"), Mapping) else {}
    risk = packet.get("risk") if isinstance(packet.get("risk"), Mapping) else {}
    earnings = (
        packet.get("earnings_event") if isinstance(packet.get("earnings_event"), Mapping) else {}
    )
    entry_windows = (
        packet.get("entry_windows") if isinstance(packet.get("entry_windows"), Mapping) else {}
    )
    eligible_styles = candidate.get("entry_eligible_trade_styles")
    if not isinstance(eligible_styles, list):
        eligible_styles = candidate.get("eligible_styles")
    if not isinstance(eligible_styles, list):
        eligible_styles = []

    return {
        "desired_direction": desired,
        **({"day_only_options": True} if day_only_options else {}),
        "macro_events": packet.get("economic_calendar", {}).get("events", []),
        "technical_supports_direction": aligned >= 2 and aligned > opposed,
        "intraday_direction": _relative_direction(intraday.get("bias"), desired),
        "uw_direction": _relative_direction(uw.get("label"), desired),
        "uw_supports_contract_direction": uw.get("supports_contract_direction") is True,
        "news_direction": _relative_direction(news.get("label"), desired),
        "social_direction": _relative_direction(social.get("label"), desired),
        "risk_status": str(risk.get("status") or ""),
        "earnings_status": str(earnings.get("status") or ""),
        "earnings_date": earnings.get("next_date"),
        "eligible_styles": sorted(str(item) for item in eligible_styles),
        "entry_windows": {str(key): value is True for key, value in sorted(entry_windows.items())},
    }


def _sentiment_label(score: int) -> str:
    if score >= 5:
        return "STRONG_BULLISH"
    if score >= 1:
        return "BULLISH"
    if score <= -5:
        return "STRONG_BEARISH"
    if score <= -1:
        return "BEARISH"
    return "NEUTRAL"


def summarize_headlines(items: list[Mapping[str, Any]], symbol: str) -> dict[str, Any]:
    relevant: list[dict[str, str]] = []
    score = 0
    normalized_symbol = symbol.upper()
    for item in items:
        title = str(item.get("title") or "").strip()
        if not title:
            continue
        channel = str(item.get("channel") or "").lower()
        if normalized_symbol not in title.upper() and channel != "macro" and len(relevant) >= 1:
            continue
        item_score = _score_text(title)
        score += item_score
        relevant.append(
            {
                "title": title[:180],
                "source": str(item.get("source") or "")[:60],
                "published": str(item.get("published") or "")[:40],
            }
        )
        if len(relevant) >= MAX_CATALYSTS:
            break
    return {
        "label": _sentiment_label(score),
        "score": score,
        "evidence_count": len(relevant),
        "catalysts": relevant,
    }


def summarize_social(intelligence: Mapping[str, Any], symbol: str) -> dict[str, Any]:
    social = intelligence.get("social") if isinstance(intelligence.get("social"), Mapping) else {}
    results = social.get("results") if isinstance(social.get("results"), list) else []
    score = 0
    matched = 0
    symbol_pattern = re.compile(rf"(?<![A-Z0-9])\$?{re.escape(symbol.upper())}(?![A-Z0-9])", re.I)
    channels: list[str] = []
    for result in results:
        if not isinstance(result, Mapping):
            continue
        output = str(result.get("output") or "")
        snippets = [line.strip() for line in output.splitlines() if symbol_pattern.search(line)]
        for snippet in snippets[:10]:
            score += _score_text(snippet)
            matched += 1
        channel = str(result.get("channel") or "")
        if channel:
            channels.append(channel)
    return {
        "label": _sentiment_label(score),
        "score": score,
        "matched_items": matched,
        "channels_checked": sorted(set(channels)),
        "confidence": "LOW" if matched < 2 else "MEDIUM" if matched < 6 else "HIGH",
    }


def _rows(value: Any) -> list[Mapping[str, Any]]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, Mapping)]
    if isinstance(value, Mapping):
        for key in ("data", "results", "items"):
            nested = value.get(key)
            if isinstance(nested, list):
                return [row for row in nested if isinstance(row, Mapping)]
    return []


def _field_total(rows: list[Mapping[str, Any]], names: tuple[str, ...]) -> float:
    total = 0.0
    for row in rows:
        for name in names:
            value = _number(row.get(name))
            if value is not None:
                total += value
                break
    return total


def fetch_uw_summary(
    symbol: str,
    option_type: str,
    *,
    client_factory: Callable[[], UnusualWhalesClient] = UnusualWhalesClient,
) -> dict[str, Any]:
    try:
        client = client_factory()
        volume_result = client.options_volume(symbol)
        flow_result = client.ticker_flow(symbol)
        volume_rows = _rows(volume_result.payload)
        flow_rows = _rows(flow_result.payload)
    except Exception as exc:
        return {"status": "UNAVAILABLE", "reason": type(exc).__name__}
    call_volume = _field_total(volume_rows, ("call_volume", "calls_volume", "call_vol"))
    put_volume = _field_total(volume_rows, ("put_volume", "puts_volume", "put_vol"))
    call_premium = 0.0
    put_premium = 0.0
    bullish_premium = 0.0
    bearish_premium = 0.0
    neutral_premium = 0.0
    ask_premium = 0.0
    bid_premium = 0.0
    for row in flow_rows:
        premium = _number(row.get("premium") or row.get("total_premium")) or 0.0
        kind = str(row.get("option_type") or row.get("put_call") or row.get("type") or "").upper()
        if "CALL" in kind:
            call_premium += premium
        elif "PUT" in kind:
            put_premium += premium
        raw_tags = row.get("tags")
        tags = (
            {str(tag).casefold() for tag in raw_tags if str(tag).strip()}
            if isinstance(raw_tags, (list, tuple, set))
            else set()
        )
        if "bullish" in tags:
            bullish_premium += premium
        elif "bearish" in tags:
            bearish_premium += premium
        else:
            neutral_premium += premium
        if "ask_side" in tags:
            ask_premium += premium
        elif "bid_side" in tags:
            bid_premium += premium
    directional = bullish_premium - bearish_premium
    tagged_total = bullish_premium + bearish_premium
    directional_ratio = directional / tagged_total if tagged_total > 0 else 0.0
    if directional_ratio >= 0.20:
        label = "STRONG_BULLISH"
    elif directional_ratio >= 0.05:
        label = "BULLISH"
    elif directional_ratio <= -0.20:
        label = "STRONG_BEARISH"
    elif directional_ratio <= -0.05:
        label = "BEARISH"
    else:
        label = "NEUTRAL"
    supports_contract = (option_type.upper() == "CALL" and directional_ratio >= 0.05) or (
        option_type.upper() == "PUT" and directional_ratio <= -0.05
    )
    return {
        "status": "OK",
        "label": label,
        "supports_contract_direction": supports_contract,
        "call_volume": round(call_volume, 2),
        "put_volume": round(put_volume, 2),
        "call_premium": round(call_premium, 2),
        "put_premium": round(put_premium, 2),
        "bullish_premium": round(bullish_premium, 2),
        "bearish_premium": round(bearish_premium, 2),
        "neutral_premium": round(neutral_premium, 2),
        "directional_imbalance_percent": round(directional_ratio * 100, 2),
        "ask_side_premium": round(ask_premium, 2),
        "bid_side_premium": round(bid_premium, 2),
        "flow_records": len(flow_rows),
    }


def _candidate_score(candidate: Mapping[str, Any]) -> float:
    bid = _number(candidate.get("bid")) or 0.0
    ask = _number(candidate.get("ask")) or 0.0
    midpoint = (bid + ask) / 2
    spread = (ask - bid) / midpoint * 100 if midpoint > 0 else 100.0
    delta = abs(_number(candidate.get("delta")) or 0.0)
    volume = _number(candidate.get("option_volume")) or 0.0
    oi = _number(candidate.get("option_open_interest")) or 0.0
    context = (
        candidate.get("discovery_context")
        if isinstance(candidate.get("discovery_context"), Mapping)
        else {}
    )
    change = _number(context.get("change_percent")) or 0.0
    relative_volume = _number(context.get("relative_volume")) or 0.0
    direction = 1 if str(candidate.get("option_type", "")).upper() == "CALL" else -1
    directional_move = direction * change
    uw_discovery = (
        candidate.get("uw_discovery") if isinstance(candidate.get("uw_discovery"), Mapping) else {}
    )
    flow_premium = _number(uw_discovery.get("premium")) or 0.0
    sweep_volume = _number(uw_discovery.get("sweep_volume")) or 0.0
    ask_volume = _number(uw_discovery.get("ask_side_volume")) or 0.0
    bid_volume = _number(uw_discovery.get("bid_side_volume")) or 0.0
    side_total = ask_volume + bid_volume
    ask_imbalance = (ask_volume - bid_volume) / side_total if side_total > 0 else 0.0
    flow_activity = (
        max(0.0, min(4.0, math.log10(max(flow_premium, 1.0)) - 3.0))
        + min(3.0, math.log10(sweep_volume + 1.0))
        + max(-2.0, min(2.0, ask_imbalance * 2.0))
    )
    return (
        max(0.0, 10.0 - spread)
        + max(0.0, 4.0 - abs(delta - 0.45) * 10)
        + min(4.0, math.log10(max(volume, 1)))
        + min(4.0, math.log10(max(oi, 1)))
        + max(-4.0, min(4.0, directional_move))
        + min(3.0, relative_volume)
        + flow_activity
        + (2.0 if "SWING" in candidate.get("entry_eligible_trade_styles", []) else 0.0)
    )


def _compact_candidate(candidate: Mapping[str, Any], preferred_style: str) -> dict[str, Any]:
    bid = _number(candidate.get("bid"))
    ask = _number(candidate.get("ask"))
    midpoint = ((bid or 0) + (ask or 0)) / 2
    spread = ((ask or 0) - (bid or 0)) / midpoint * 100 if midpoint > 0 else None
    return {
        "candidate_id": str(candidate.get("candidate_id") or ""),
        "symbol": str(candidate.get("symbol") or ""),
        "option_symbol": str(candidate.get("option_symbol") or ""),
        "option_type": str(candidate.get("option_type") or ""),
        "expiration": str(candidate.get("expiration") or ""),
        "dte": candidate.get("dte"),
        "strike": candidate.get("strike"),
        "underlying_price": candidate.get("underlying_price"),
        "underlying_liquidity": {
            "average_volume_30d": candidate.get("underlying_average_volume_30d"),
            "average_daily_dollar_volume": candidate.get("underlying_avg_daily_dollar_volume"),
            "session_volume": dict(candidate.get("discovery_context", {})).get("current_volume"),
            "relative_volume": dict(candidate.get("discovery_context", {})).get("relative_volume"),
        },
        "bid": bid,
        "ask": ask,
        "premium_dollars": round((ask or 0) * 100, 2),
        "spread_percent": round(spread, 3) if spread is not None else None,
        "volume": candidate.get("option_volume"),
        "open_interest": candidate.get("option_open_interest"),
        "quote_updated_at": candidate.get("quote_updated_at"),
        "quote_is_fresh": candidate.get("quote_is_fresh"),
        "eligible_styles": list(candidate.get("entry_eligible_trade_styles", [])),
        "python_preferred_style": preferred_style,
        "greeks": {
            "delta": candidate.get("delta"),
            "gamma": candidate.get("gamma"),
            "theta": candidate.get("theta"),
            "vega": candidate.get("vega"),
            "rho": candidate.get("rho"),
            "implied_volatility": candidate.get("implied_volatility"),
            **dict(candidate.get("greek_metrics", {})),
        },
        "break_even_price": candidate.get("break_even_price"),
        "discovery_source": candidate.get("discovery_source"),
        "discovery_context": dict(candidate.get("discovery_context", {})),
    }


def _account_from_event(event: Mapping[str, Any], *, live_required: bool) -> dict[str, Any]:
    if not live_required:
        paper = (
            event.get("paper_portfolio")
            if isinstance(event.get("paper_portfolio"), Mapping)
            else {}
        )
        summary = paper.get("portfolio") if isinstance(paper.get("portfolio"), Mapping) else {}
        day = summary.get("day") if isinstance(summary.get("day"), Mapping) else {}
        return {
            "account_value": summary.get("equity"),
            "account_value_start_of_day": day.get("start_equity"),
            "buying_power": summary.get("cash"),
            "daily_pnl": float(summary.get("equity", 0)) - float(day.get("start_equity", 0)),
            "open_stop_risk": summary.get("open_stop_risk", 0)
            if not paper.get("open_positions")
            else sum(
                max(
                    0,
                    (float(item["last_bid"]) - float(item["stop_price"]))
                    * int(item.get("quantity", 1))
                    * 100,
                )
                + float(item.get("exit_cost_estimate", 0))
                for item in paper.get("open_positions", [])
            ),
            "open_premium_at_risk": sum(
                float(item.get("entry_cost", 0))
                for item in paper.get("open_positions", [])
                if isinstance(item, Mapping)
            ),
            "open_position_count": summary.get("open_positions"),
            "new_positions_today": day.get("new_positions"),
            "broker_status": "PAPER",
        }
    live = event.get("live_portfolio") if isinstance(event.get("live_portfolio"), Mapping) else {}
    portfolio = live.get("portfolio") if isinstance(live.get("portfolio"), Mapping) else {}
    return {
        "account_value": portfolio.get("account_value"),
        "account_value_start_of_day": portfolio.get("account_value_start_of_day"),
        "buying_power": portfolio.get("buying_power"),
        "daily_pnl": portfolio.get("daily_pnl"),
        **(
            {"open_stop_risk": portfolio["open_stop_risk"]} if "open_stop_risk" in portfolio else {}
        ),
        "open_premium_at_risk": portfolio.get("open_premium_at_risk"),
        "open_position_count": portfolio.get("open_position_count"),
        "new_positions_today": portfolio.get("new_positions_today"),
        "broker_status": live.get("status"),
    }


def _risk_packet(
    account: Mapping[str, Any], candidate: Mapping[str, Any], config: TradingConfig
) -> dict[str, Any]:
    ask = _number(candidate.get("ask")) or 0.0
    risk = evaluate_risk(
        account,
        {
            "symbol": candidate.get("symbol"),
            "premium_at_risk": ask * 100,
            "quantity": 1,
            "holds_through_earnings": False,
            "is_averaging_down": False,
            "protective_stop_planned": True,
        },
        config,
    )
    return risk.as_dict()


def _preferred_style(candidate: Mapping[str, Any], technical: Mapping[str, Any]) -> str:
    styles = list(candidate.get("entry_eligible_trade_styles", []))
    if len(styles) == 1:
        return str(styles[0])
    direction = 1 if str(candidate.get("option_type", "")).upper() == "CALL" else -1
    scores = (
        technical.get("style_scores") if isinstance(technical.get("style_scores"), Mapping) else {}
    )
    ranked = sorted(
        ((direction * int(scores.get(style, 0)), style) for style in styles),
        reverse=True,
    )
    return ranked[0][1] if ranked else "NONE"


def _compact_risk(risk: Mapping[str, Any]) -> dict[str, Any]:
    """Keep hard risk truth while hiding non-blocking unavailable portfolio analytics."""

    compact = {
        "status": risk.get("status"),
        "reasons": list(risk.get("reasons", [])),
        "metrics": dict(risk.get("metrics", {})),
    }
    analytics = risk.get("analytics") if isinstance(risk.get("analytics"), Mapping) else {}
    if analytics.get("status") == "CALCULATED":
        compact["analytics"] = dict(analytics)
    return compact


def _earnings_packet(candidate: Mapping[str, Any], technical: Mapping[str, Any]) -> dict[str, Any]:
    """Prefer the technical worker, then reuse a known UW discovery calendar date."""

    earnings = (
        dict(technical.get("earnings"))
        if isinstance(technical.get("earnings"), Mapping)
        else {"status": "UNAVAILABLE", "next_date": None}
    )
    if str(earnings.get("status") or "") in {"AVAILABLE", "NOT_APPLICABLE"}:
        return earnings
    uw_discovery = (
        candidate.get("uw_discovery") if isinstance(candidate.get("uw_discovery"), Mapping) else {}
    )
    next_date = uw_discovery.get("next_earnings_date")
    if next_date:
        return {
            "status": "AVAILABLE",
            "next_date": str(next_date)[:32],
            "source": "UW_DISCOVERY",
        }
    return earnings


def _countertrend_timing_gate(
    candidate: Mapping[str, Any], technical: Mapping[str, Any], *, style: str, now: datetime
) -> dict[str, Any]:
    """Countertrend DAY entries need both intraday frames plus a fresh level test."""

    if style != "DAY":
        return {"required": False, "reasons": []}
    frames = technical.get("timeframes", {})
    daily = frames.get("1D", {})
    direction = 1 if str(candidate.get("option_type", "")).upper() == "CALL" else -1
    desired = "BULLISH" if direction > 0 else "BEARISH"
    opposed = "BEARISH" if direction > 0 else "BULLISH"
    if daily.get("status") != "OK" or daily.get("trend") not in {"BULLISH", "BEARISH", "NEUTRAL"}:
        return {"required": True, "reasons": ["day_entry_daily_context_missing"]}
    day_change = _number(daily.get("change_1_bar_percent"))
    countertrend = daily.get("trend") == opposed or (
        day_change is not None and direction * day_change < 0
    )
    if not countertrend:
        return {"required": False, "reasons": []}
    reasons = []
    if any(
        frames.get(tf, {}).get("status") != "OK" or frames.get(tf, {}).get("trend") != desired
        for tf in ("5M", "15M")
    ):
        reasons.append("countertrend_day_requires_5m_15m_confirmation")
    timing = technical.get("intraday_structure", {}).get("entry_timing", {})
    try:
        bar_end = datetime.fromisoformat(str(timing.get("completed_bar_at", "")))
        fresh = (
            bar_end.tzinfo is not None
            and 0 <= (now - bar_end).total_seconds() <= 600
            and bar_end.astimezone(EASTERN).date() == now.astimezone(EASTERN).date()
        )
    except (ValueError, TypeError):
        fresh = False
    levels = timing.get(
        "bullish_confirmation_levels" if direction > 0 else "bearish_confirmation_levels", []
    )
    valid_levels = {"SESSION_VWAP", "OPENING_RANGE_LOW" if direction > 0 else "OPENING_RANGE_HIGH"}
    confirmed = isinstance(levels, list) and any(level in valid_levels for level in levels)
    if timing.get("status") != "OK" or not fresh or not confirmed:
        reasons.append("countertrend_day_requires_fresh_level_confirmation")
    return {
        "required": True,
        "reasons": reasons,
        "confirmation_bar_at": timing.get("completed_bar_at"),
    }


def _pre_model_gate(
    candidate: Mapping[str, Any],
    technical: Mapping[str, Any],
    uw: Mapping[str, Any],
    risk: Mapping[str, Any],
    earnings: Mapping[str, Any],
    *,
    preferred_style: str,
    now: datetime | None = None,
    day_only_options: bool = False,
) -> dict[str, Any]:
    """Reject deterministic directional conflicts before spending a Luna call."""

    option_type = str(candidate.get("option_type") or "").upper()
    direction_multiplier = 1 if option_type == "CALL" else -1 if option_type == "PUT" else 0
    style_scores = (
        technical.get("style_scores") if isinstance(technical.get("style_scores"), Mapping) else {}
    )
    raw_style_score = int(style_scores.get(preferred_style, 0))
    directional_score = direction_multiplier * raw_style_score
    intraday = (
        technical.get("intraday_structure")
        if isinstance(technical.get("intraday_structure"), Mapping)
        else {}
    )
    structure_score = int(intraday.get("bias_score", 0))
    directional_structure_score = direction_multiplier * structure_score
    desired_label = "STRONG_BULLISH" if direction_multiplier > 0 else "STRONG_BEARISH"
    strong_supportive_flow = (
        uw.get("status") == "OK"
        and uw.get("supports_contract_direction") is True
        and str(uw.get("label") or "").upper() == desired_label
    )
    flow_led_reversal = (
        preferred_style == "DAY"
        and strong_supportive_flow
        and intraday.get("status") == "OK"
        and directional_structure_score >= 0
    )
    reasons: list[str] = []
    if preferred_style == "NONE" or (directional_score <= 0 and not flow_led_reversal):
        reasons.append("preferred_style_technical_direction_not_supportive")
    if uw.get("status") == "OK" and uw.get("supports_contract_direction") is not True:
        reasons.append("available_uw_flow_opposes_contract_direction")
    if risk.get("status") != "ALLOWED":
        reasons.append("deterministic_risk_not_allowed")
    if str(earnings.get("status") or "") not in {"AVAILABLE", "NOT_APPLICABLE"}:
        reasons.append("required_earnings_event_review_unavailable")
    entry_timing = (
        {
            "required": False,
            "reasons": [],
            "policy": "intraday_day_only",
        }
        if day_only_options
        else _countertrend_timing_gate(
            candidate, technical, style=preferred_style, now=now or datetime.now(UTC)
        )
    )
    reasons.extend(entry_timing["reasons"])
    return {
        "status": "QUALIFIED" if not reasons else "REJECTED",
        "reasons": reasons,
        "option_direction": "BULLISH" if direction_multiplier > 0 else "BEARISH",
        "preferred_style": preferred_style,
        "raw_style_score": raw_style_score,
        "directional_alignment_score": directional_score,
        "technical_direction_supported": directional_score > 0,
        "intraday_directional_structure_score": directional_structure_score,
        "strong_supportive_flow": strong_supportive_flow,
        "setup_mode": "FLOW_LED_REVERSAL" if flow_led_reversal else "TECHNICAL_CONFLUENCE",
        "uw_status": uw.get("status"),
        "uw_direction_supported": (
            uw.get("supports_contract_direction") is True if uw.get("status") == "OK" else None
        ),
        "risk_status": risk.get("status"),
        "earnings_status": earnings.get("status"),
        "countertrend_entry_timing": entry_timing,
    }


async def build_decision_packet(
    event: Mapping[str, Any],
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime | None = None,
    excluded_candidate_ids: set[str] | None = None,
    technical_fetcher: Callable[..., dict[str, Any]] = fetch_vibe_snapshot,
    uw_fetcher: Callable[[str, str], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    macro = economic_context(current, config, project_root=project_root)
    if not macro["entry_allowed"]:
        return {"status": "INSUFFICIENT_DATA" if macro["status"] != "OK" else "NO_CANDIDATE",
                "reason": macro["reason"], "economic_calendar": macro, "packet": None,
                "selected_candidates": [], "candidates_evaluated": 0}
    option_discovery = (
        event.get("option_discovery") if isinstance(event.get("option_discovery"), Mapping) else {}
    )
    excluded = excluded_candidate_ids or set()
    try:
        held_symbols = opportunity_held_symbols(event, live_required=config.live_execution_enabled)
    except ValueError as exc:
        return {
            "status": "INSUFFICIENT_DATA",
            "reason": str(exc),
            "packet": None,
            "selected_candidates": [],
            "candidates_evaluated": 0,
        }
    candidates = [
        item
        for item in option_discovery.get("qualified_candidates", [])
        if isinstance(item, Mapping) and str(item.get("candidate_id") or "") not in excluded
    ]
    if not candidates:
        return {"status": "NO_CANDIDATE", "packet": None, "selected_candidates": []}
    candidates.sort(key=lambda item: (
        config.get("ENABLE_MULTI_WATCH") is True and item.get("watch_priority") is True,
        _candidate_score(item),
    ), reverse=True)
    intelligence = (
        event.get("market_intelligence")
        if isinstance(event.get("market_intelligence"), Mapping)
        else {}
    )
    broad_news = intelligence.get("news") if isinstance(intelligence.get("news"), Mapping) else {}
    broad_items = (
        broad_news.get("new_items") if isinstance(broad_news.get("new_items"), list) else []
    )
    resolved_uw_fetcher = uw_fetcher or (
        lambda symbol, option_type: fetch_uw_summary(symbol, option_type)
    )
    account = _account_from_event(event, live_required=config.live_execution_enabled)
    day_only_options = config.get("DAY_ONLY_OPTIONS") is True
    python_rejections: list[dict[str, Any]] = []
    evidence_keys: set[tuple[str, str]] = set()
    technical_cache: dict[str, dict[str, Any]] = {}
    evaluated = 0
    for candidate in candidates:
        try:
            candidate_symbol = normalized_symbol(candidate.get("symbol"))
            exclusion_reason = (
                "underlying_already_held" if candidate_symbol in held_symbols else None
            )
        except ValueError:
            exclusion_reason = "candidate_symbol_missing"
        if exclusion_reason:
            python_rejections.append(
                {
                    "candidate_id": candidate.get("candidate_id"),
                    "symbol": candidate.get("symbol"),
                    "option_type": candidate.get("option_type"),
                    "gate": {"status": "REJECTED", "reasons": [exclusion_reason]},
                }
            )
            continue
        reward_risk = net_reward_risk(candidate, config)
        if reward_risk is not None and reward_risk["status"] != "QUALIFIED":
            python_rejections.append({
                "candidate_id": candidate.get("candidate_id"), "symbol": candidate.get("symbol"),
                "option_type": candidate.get("option_type"), "gate": reward_risk,
            })
            continue
        evidence_key = (
            str(candidate.get("symbol") or "").upper(),
            str(candidate.get("option_type") or "").upper(),
        )
        if evidence_key in evidence_keys:
            continue
        evidence_keys.add(evidence_key)
        evaluated += 1
        if evaluated > MAX_PRE_MODEL_CANDIDATES:
            break

        symbol = str(candidate.get("symbol") or "")
        option_type = str(candidate.get("option_type") or "")
        if symbol not in technical_cache:
            technical_cache[symbol] = await asyncio.to_thread(
                technical_fetcher, symbol, project_root=project_root
            )
        technical = technical_cache[symbol]
        current = now or datetime.now(UTC)
        preferred_style = _preferred_style(candidate, technical)
        if config.get("ENABLE_MULTI_WATCH") is True and candidate.get("watch_trade_style") in (
            candidate.get("entry_eligible_trade_styles", [])
        ):
            preferred_style = candidate["watch_trade_style"]
        if day_only_options:
            preferred_style = (
                "DAY"
                if "DAY" in candidate.get("entry_eligible_trade_styles", [])
                else "NONE"
            )
        risk_full = _risk_packet(account, candidate, config)
        earnings = _earnings_packet(candidate, technical)
        if risk_full.get("status") != "ALLOWED" or str(earnings.get("status") or "") not in {
            "AVAILABLE",
            "NOT_APPLICABLE",
        }:
            provisional_gate = _pre_model_gate(
                candidate,
                technical,
                {"status": "SKIPPED"},
                risk_full,
                earnings,
                preferred_style=preferred_style,
                now=current,
                day_only_options=day_only_options,
            )
            python_rejections.append(
                {
                    "candidate_id": candidate.get("candidate_id"),
                    "symbol": symbol,
                    "option_type": option_type,
                    "gate": provisional_gate,
                }
            )
            continue

        uw = (
            await asyncio.to_thread(resolved_uw_fetcher, symbol, option_type)
            if config.get("UW_ENABLED") is True
            else {"status": "DISABLED", "reason": "uw_disabled"}
        )
        gate = _pre_model_gate(
            candidate,
            technical,
            uw,
            risk_full,
            earnings,
            preferred_style=preferred_style,
            now=current,
            day_only_options=day_only_options,
        )
        if gate["status"] != "QUALIFIED":
            python_rejections.append(
                {
                    "candidate_id": candidate.get("candidate_id"),
                    "symbol": symbol,
                    "option_type": option_type,
                    "gate": gate,
                }
            )
            continue

        worker_headlines = (
            technical.get("headlines") if isinstance(technical.get("headlines"), list) else []
        )
        news = summarize_headlines([*worker_headlines, *broad_items], symbol)
        social = summarize_social(intelligence, symbol)
        compact_candidate = _compact_candidate(candidate, preferred_style)
        compact_candidate["underlying_instrument_type"] = str(
            technical.get("instrument_type") or "UNKNOWN"
        )
        risk = _compact_risk(risk_full)
        packet = {
            "schema_version": 1,
            "as_of": current.astimezone(UTC).isoformat(),
            "mode": "LIVE" if config.live_execution_enabled else "PAPER",
            "objective": "Choose BUY or PASS; WAIT only for one exact near-term trigger.",
            "trading_policy": {
                "day_only_options": day_only_options,
                "technical_horizon": "INTRADAY" if day_only_options else preferred_style,
            },
            "account": account,
            "position_memory": {
                "status": "FLAT" if int(account.get("open_position_count") or 0) == 0 else "OPEN",
                "current": [
                    {
                        **{
                            key: position.get(key)
                            for key in (
                                "position_id",
                                "symbol",
                                "contract_identifier",
                                "quantity",
                                "entry_price",
                                "last_bid",
                                "trade_style",
                                "hold_deadline",
                            )
                        },
                        "thesis": str(position.get("thesis", ""))[:160],
                        "invalidation": str(position.get("invalidation", ""))[:120],
                    }
                    for position in event.get("live_portfolio", {}).get("positions", [])
                    if isinstance(position, Mapping)
                ]
                if isinstance(event.get("live_portfolio"), Mapping)
                else [],
            },
            "candidate": compact_candidate,
            "python_gate": gate,
            "technical": {
                "status": technical.get("status"),
                "timeframes": technical.get("timeframes", {}),
                "style_scores": technical.get("style_scores", {}),
                "preferred_style": preferred_style,
                "intraday_structure": technical.get("intraday_structure", {}),
            },
            "news": news,
            "social": social,
            "unusual_whales": uw,
            "earnings_event": earnings,
            "economic_calendar": macro,
            "risk": risk,
            **({"net_reward_risk": reward_risk} if reward_risk is not None else {}),
            "entry_windows": dict(event.get("entry_windows", {})),
            "hard_exit_policy": {
                "stop_loss_percent": config.get("STOP_LOSS_PERCENT"),
                "take_profit_percent": config.get("TAKE_PROFIT_PERCENT"),
                "software_managed": config.get("STOP_MANAGEMENT_MODE") == "SOFTWARE_POLLING",
            },
        }
        serialized = json.dumps(packet, separators=(",", ":"), sort_keys=True)
        if len(serialized) > MAX_PACKET_CHARACTERS:
            packet["technical"]["timeframes"] = {
                key: {
                    "status": value.get("status"),
                    "trend": value.get("trend"),
                    "trend_score": value.get("trend_score"),
                    "rsi_14": value.get("rsi_14"),
                    "relative_volume_20": value.get("relative_volume_20"),
                }
                for key, value in packet["technical"]["timeframes"].items()
                if isinstance(value, Mapping)
            }
            serialized = json.dumps(packet, separators=(",", ":"), sort_keys=True)
        packet["packet_characters"] = len(serialized)
        packet["packet_estimated_tokens"] = math.ceil(len(serialized) / 4)
        technical_state = {
            timeframe: {
                "status": values.get("status"),
                "trend": values.get("trend"),
            }
            for timeframe, values in packet["technical"]["timeframes"].items()
            if isinstance(values, Mapping)
        }
        signature_fields = {
            "macro_events": macro.get("events", []),
            "candidate": compact_candidate["candidate_id"],
            "eligible_styles": compact_candidate["eligible_styles"],
            "preferred_style": preferred_style,
            "day_only_options": day_only_options,
            "technical": {
                "timeframes": technical_state,
                "intraday_structure": {
                    "status": packet["technical"]["intraday_structure"].get("status"),
                    "bias": packet["technical"]["intraday_structure"].get("bias"),
                },
            },
            "news": {
                "label": news["label"],
                "catalysts": [item.get("title") for item in news["catalysts"]],
            },
            "social": social["label"],
            "uw": {
                "status": uw.get("status"),
                "label": uw.get("label"),
                "supports_contract_direction": uw.get("supports_contract_direction"),
            },
            "risk": risk.get("status"),
            "countertrend_entry_timing": gate["countertrend_entry_timing"],
            **({"net_reward_risk": reward_risk} if reward_risk is not None else {}),
        }
        signature = hashlib.sha256(
            json.dumps(signature_fields, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        packet["packet_signature"] = signature
        return {
            "status": "READY",
            "packet": packet,
            "selected_candidates": [dict(candidate)][:MAX_PACKET_CANDIDATES],
            "packet_signature": signature,
            "python_rejections": python_rejections,
            "candidates_evaluated": evaluated,
        }

    return {
        "status": "NO_ALIGNED_CANDIDATE",
        "packet": None,
        "selected_candidates": [],
        "python_rejections": python_rejections,
        "candidates_evaluated": evaluated,
    }


def _valid_model_budget_state(loaded: Any) -> bool:
    if not isinstance(loaded, Mapping):
        return False
    day = loaded.get("date")
    if not isinstance(day, str):
        return False
    try:
        if datetime.strptime(day, "%Y-%m-%d").date().isoformat() != day:
            return False
    except ValueError:
        return False
    for field in ("calls_reserved", "maximum_calls"):
        value = loaded.get(field)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return False
    return loaded["maximum_calls"] > 0 and loaded["calls_reserved"] <= loaded["maximum_calls"]


def _read_model_budget_state(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return {}
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    return dict(loaded) if _valid_model_budget_state(loaded) else None


def model_budget_day(current: datetime) -> str:
    """Daily 09:30 Eastern boundary, including weekends and DST transitions."""
    local = current.astimezone(EASTERN)
    day = local.date()
    if (local.hour, local.minute) < (9, 30):
        day -= timedelta(days=1)
    return day.isoformat()


def reserve_model_call(
    path: Path,
    *,
    maximum_calls: int,
    now: datetime | None = None,
    packet_signature: str,
    admission_limit: int | None = None,
) -> dict[str, Any]:
    from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock

    current = now or datetime.now(UTC)
    local_date = model_budget_day(current)
    if isinstance(maximum_calls, bool) or not isinstance(maximum_calls, int) or maximum_calls <= 0:
        return {"status": "BLOCKED", "reason": "invalid_model_call_limit"}
    if admission_limit is not None and (
        isinstance(admission_limit, bool)
        or not isinstance(admission_limit, int)
        or not 0 < admission_limit <= maximum_calls
    ):
        return {"status": "BLOCKED", "reason": "invalid_model_call_admission_limit"}
    try:
        with advisory_file_lock(path):
            payload = _read_model_budget_state(path)
            if payload is None:
                return {
                    "status": "BLOCKED",
                    "reason": "model_budget_state_unreadable",
                    "maximum_calls": maximum_calls,
                }
            calls = payload["calls_reserved"] if payload.get("date") == local_date else 0
            if calls >= maximum_calls:
                return {
                    "status": "BLOCKED",
                    "reason": "daily_model_call_budget_reached",
                    "calls_reserved": calls,
                    "maximum_calls": maximum_calls,
                }
            if admission_limit is not None and calls >= admission_limit:
                return {
                    "status": "BLOCKED",
                    "reason": "session_model_call_reserve",
                    "calls_reserved": calls,
                    "maximum_calls": maximum_calls,
                }
            updated = {
                "date": local_date,
                "calls_reserved": calls + 1,
                "maximum_calls": maximum_calls,
                "last_reserved_at": current.astimezone(UTC).isoformat(),
                "last_packet_signature": packet_signature,
            }
            try:
                write = guarded_json_update(path, updated, commit=True)
            except OSError:
                return {"status": "BLOCKED", "reason": "model_budget_write_failed"}
            write.pop("payload", None)
            if write.get("status") != "UPDATED" or write.get("written") is not True:
                return {
                    "status": "BLOCKED",
                    "reason": "model_budget_write_failed",
                    "persistent_write": write,
                }
            return {"status": "RESERVED", **updated, "persistent_write": write}
    except RuntimeLockUnavailable:
        return {"status": "BLOCKED", "reason": "model_budget_lock_unavailable"}


def model_call_budget_status(
    path: Path,
    *,
    maximum_calls: int,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Inspect today's model budget without reserving a call or changing state."""

    current = now or datetime.now(UTC)
    local_date = model_budget_day(current)
    if isinstance(maximum_calls, bool) or not isinstance(maximum_calls, int) or maximum_calls <= 0:
        return {"status": "UNAVAILABLE", "reason": "invalid_model_call_limit"}
    loaded = _read_model_budget_state(path)
    if loaded is None:
        return {
            "status": "UNAVAILABLE",
            "reason": "model_budget_state_unreadable",
            "date": local_date,
            "maximum_calls": maximum_calls,
        }
    calls = loaded["calls_reserved"] if loaded.get("date") == local_date else 0
    remaining = max(0, maximum_calls - calls)
    return {
        "status": "EXHAUSTED" if remaining == 0 else "AVAILABLE",
        "reason": "daily_model_call_budget_reached" if remaining == 0 else None,
        "date": local_date,
        "calls_reserved": calls,
        "maximum_calls": maximum_calls,
        "calls_remaining": remaining,
    }


def cache_decision(
    path: Path,
    decision: Mapping[str, Any],
    *,
    packet_signature: str,
    candidate: Mapping[str, Any],
    packet: Mapping[str, Any] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    payload = {
        "updated_at": current.astimezone(UTC).isoformat(),
        "packet_signature": packet_signature,
        "candidate_id": candidate.get("candidate_id"),
        "symbol": candidate.get("symbol"),
        "option_type": candidate.get("option_type"),
        "underlying_price": candidate.get("underlying_price"),
        "decision": dict(decision),
    }
    if str(decision.get("action") or "").upper() in {"PASS", "NO_TRADE"}:
        payload["pass_recheck_state"] = _pass_recheck_state(packet, candidate)
    entries: dict[str, Any] = {}
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, Mapping) and isinstance(loaded.get("entries"), Mapping):
                entries = {
                    str(key): dict(value)
                    for key, value in loaded["entries"].items()
                    if isinstance(value, Mapping)
                }
            elif isinstance(loaded, Mapping) and loaded.get("candidate_id"):
                entries[str(loaded["candidate_id"])] = dict(loaded)
        except (OSError, json.JSONDecodeError):
            entries = {}
    candidate_id = str(candidate.get("candidate_id") or "")
    entries[candidate_id] = payload
    document = {
        "updated_at": current.astimezone(UTC).isoformat(),
        "latest_candidate_id": candidate_id,
        "entries": entries,
    }
    write = guarded_json_update(path, document, commit=True)
    write.pop("payload", None)
    return {"status": "CACHED", "persistent_write": write, **payload}


def cached_decision_blocks(
    path: Path,
    *,
    packet_signature: str,
    candidate: Mapping[str, Any],
    packet: Mapping[str, Any] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    if not path.exists():
        return {"blocked": False, "reason": "no_cache"}
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"blocked": False, "reason": "invalid_cache"}
    candidate_id = str(candidate.get("candidate_id") or "")
    if isinstance(loaded, Mapping) and isinstance(loaded.get("entries"), Mapping):
        cached = loaded["entries"].get(candidate_id)
    else:
        cached = loaded
    if not isinstance(cached, Mapping) or str(cached.get("candidate_id") or "") != candidate_id:
        return {"blocked": False, "reason": "different_candidate"}
    decision = cached.get("decision") if isinstance(cached.get("decision"), Mapping) else {}
    action = str(decision.get("action") or "")
    current = now or datetime.now(UTC)
    raw_until = str(decision.get("decision_valid_until") or "")
    try:
        valid_until = datetime.fromisoformat(raw_until.replace("Z", "+00:00"))
    except ValueError:
        valid_until = current + timedelta(minutes=30)
    if valid_until.tzinfo is None:
        valid_until = valid_until.replace(tzinfo=UTC)
    if current.astimezone(UTC) >= valid_until.astimezone(UTC):
        return {"blocked": False, "reason": "cache_expired"}
    if action in {"PASS", "NO_TRADE"}:
        cached_state = cached.get("pass_recheck_state")
        if isinstance(cached_state, Mapping):
            cached_state = {"macro_events": [], **cached_state}
        current_state = _pass_recheck_state(packet, candidate)
        if isinstance(cached_state, Mapping) and dict(cached_state) == current_state:
            return {
                "blocked": True,
                "reason": "material_pass_state_unchanged",
                "decision": decision,
            }
        if cached.get("packet_signature") == packet_signature:
            return {"blocked": True, "reason": "unchanged_pass_cached", "decision": decision}
        if isinstance(cached_state, Mapping):
            return {
                "blocked": False,
                "reason": "material_pass_state_changed",
                "decision": decision,
            }
    if action == "BUY" and cached.get("packet_signature") == packet_signature:
        return {"blocked": True, "reason": "valid_buy_cached", "decision": decision}
    if action != "WAIT":
        return {"blocked": False, "reason": "cache_not_wait"}
    price = _number(candidate.get("underlying_price"))
    above = _number(decision.get("reconsider_above"))
    below = _number(decision.get("reconsider_below"))
    crossed = price is not None and (
        (above is not None and price >= above) or (below is not None and price <= below)
    )
    return {
        "blocked": not crossed,
        "reason": "wait_threshold_not_crossed" if not crossed else "wait_threshold_crossed",
        "decision": decision,
    }
