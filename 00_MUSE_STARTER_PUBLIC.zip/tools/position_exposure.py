"""Ticker-wide exclusion for new entries; never used to suppress position management."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def normalized_symbol(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("position_or_candidate_symbol_missing")
    return value.strip().upper()


def held_option_symbols(positions: Any) -> set[str]:
    """Accept only an explicitly supplied list of currently open option positions."""
    if not isinstance(positions, list):
        raise ValueError("open_position_list_missing")
    symbols: set[str] = set()
    for position in positions:
        if not isinstance(position, Mapping):
            raise ValueError("invalid_open_position")
        symbols.add(normalized_symbol(position.get("symbol") or position.get("chain_symbol")))
    return symbols


def opportunity_held_symbols(event: Mapping[str, Any], *, live_required: bool) -> set[str]:
    if not live_required:
        paper = event.get("paper_portfolio")
        if not isinstance(paper, Mapping):
            raise ValueError("paper_position_state_missing")
        summary = paper.get("portfolio")
        count = summary.get("open_positions") if isinstance(summary, Mapping) else None
        positions = paper.get("open_positions")
        if positions is None and count == 0:
            positions = []
        symbols = held_option_symbols(positions)
        if (
            isinstance(count, bool)
            or not isinstance(count, (int, float))
            or count != len(positions)
        ):
            raise ValueError("open_position_count_mismatch")
        return symbols
    live = event.get("live_portfolio")
    if not isinstance(live, Mapping):
        if live_required:
            raise ValueError("live_position_state_missing")
        return set()
    portfolio = live.get("portfolio")
    count = portfolio.get("open_position_count") if isinstance(portfolio, Mapping) else None
    positions = live.get("positions")
    if positions is None and count == 0:
        positions = []
    symbols = held_option_symbols(positions)
    if isinstance(count, bool) or not isinstance(count, (int, float)) or count != len(positions):
        raise ValueError("open_position_count_mismatch")
    return symbols
