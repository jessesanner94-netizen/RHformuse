"""Append complete scheduled-cycle and agent activity records for later review."""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

EASTERN = ZoneInfo("America/New_York")


def _activity_summary(cycle: str, result: Mapping[str, Any]) -> str:
    routing = result.get("routing") if isinstance(result.get("routing"), Mapping) else {}
    decision = routing.get("decision") if isinstance(routing.get("decision"), Mapping) else {}
    luna = routing.get("luna") if isinstance(routing.get("luna"), Mapping) else {}
    sol = routing.get("sol") if isinstance(routing.get("sol"), Mapping) else {}
    paper = result.get("paper") if isinstance(result.get("paper"), Mapping) else {}
    paper_decision = (
        result.get("paper_decision") if isinstance(result.get("paper_decision"), Mapping) else {}
    )
    parts = [f"cycle={cycle}"]
    if decision:
        parts.append(f"decision={decision.get('status')}")
    if luna:
        parts.append(f"luna={luna.get('status')}")
    if sol:
        parts.append(f"sol={sol.get('status')}")
    if paper:
        parts.append(f"paper={paper.get('status')}")
    if paper_decision:
        parts.append(f"paper_decision={paper_decision.get('status')}")
    if result.get("status"):
        parts.append(f"status={result.get('status')}")
    return ", ".join(parts)


def append_cycle_log(
    project_root: Path,
    cycle: str,
    result: Mapping[str, Any],
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    local_date = current.astimezone(EASTERN).date().isoformat()
    directory = project_root / "state" / "logs"
    directory.mkdir(parents=True, exist_ok=True)
    jsonl_path = directory / f"{local_date}.jsonl"
    record = {
        "timestamp": current.astimezone(UTC).isoformat(),
        "cycle": cycle,
        "result": result,
    }
    serialized = json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n"
    with jsonl_path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(serialized)
        handle.flush()
        os.fsync(handle.fileno())
    activity_path = directory / "ACTIVITY.md"
    activity_line = (
        f"- {current.astimezone(EASTERN).isoformat(timespec='seconds')} — "
        f"{_activity_summary(cycle, result)}\n"
    )
    with activity_path.open("a", encoding="utf-8", newline="\n") as handle:
        if activity_path.stat().st_size == 0:
            handle.write("# Scheduled Agent Activity\n\n")
        handle.write(activity_line)
        handle.flush()
        os.fsync(handle.fileno())
    return {
        "status": "APPENDED",
        "jsonl": str(jsonl_path),
        "activity": str(activity_path),
        "bytes": len(serialized.encode("utf-8")),
    }
