"""Offline, point-in-time outcome attachment and evidence-only JEV reporting.

This module deliberately knows nothing about brokers, prices APIs, or model clients.  It reads
the append-only JEV SQLite evidence store and, optionally, a local JSON price file.  Forward
underlying returns are *research labels*, never option fills or simulated option P&L.
"""

from __future__ import annotations

import argparse
import json
import math
import sqlite3
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

HORIZONS = (1, 5, 15, 30)
NEW_YORK = ZoneInfo("America/New_York")
PATHS = ("python_luna", "python_jev_luna", "python_book_jev_luna")
REALIZED_EVENT_KINDS = frozenset({"execution_result", "paper_exit", "realized_outcome"})


def _json(value: str, default: Any) -> Any:
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def _time(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if result.tzinfo is None:
        return None
    return result.astimezone(UTC)


def _iso(value: datetime) -> str:
    return value.astimezone(UTC).isoformat()


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _mapping_value(mapping: Mapping[str, Any], *names: str) -> Any:
    for name in names:
        if name in mapping:
            return mapping[name]
    return None


def _candidate(features: Mapping[str, Any]) -> Mapping[str, Any]:
    value = features.get("candidate")
    return value if isinstance(value, Mapping) else {}


def _direction(features: Mapping[str, Any]) -> str | None:
    candidate = _candidate(features)
    raw = _mapping_value(candidate, "direction", "option_type", "contract_type", "side")
    if raw is None:
        raw = _mapping_value(features, "direction", "option_type", "contract_type", "side")
    text = str(raw).upper() if raw is not None else ""
    if text in {"CALL", "LONG_CALL", "BUY_CALL", "BULLISH", "UP"}:
        return "CALL"
    if text in {"PUT", "LONG_PUT", "BUY_PUT", "BEARISH", "DOWN"}:
        return "PUT"
    return None


def _levels(features: Mapping[str, Any]) -> tuple[float | None, float | None]:
    candidate = _candidate(features)
    exits = candidate.get("exit_levels")
    if not isinstance(exits, Mapping):
        exits = features.get("exit_levels")
    if not isinstance(exits, Mapping):
        exits = {}
    target = _number(_mapping_value(candidate, "target_price", "target"))
    stop = _number(_mapping_value(candidate, "stop_price", "stop"))
    return (
        target if target is not None else _number(_mapping_value(exits, "target_price", "target")),
        stop if stop is not None else _number(_mapping_value(exits, "stop_price", "stop")),
    )


def _symbol(features: Mapping[str, Any]) -> str:
    return str(_candidate(features).get("symbol") or features.get("symbol") or "").upper()


def _row_symbol(row: Mapping[str, Any]) -> str:
    return str(row.get("symbol") or row.get("ticker") or "").upper()


def _price_time(row: Mapping[str, Any]) -> datetime | None:
    return _time(_mapping_value(row, "timestamp", "as_of", "at", "ends_at"))


def _price_row(row: Mapping[str, Any]) -> dict[str, Any] | None:
    at = _price_time(row)
    close = _number(_mapping_value(row, "close", "price", "last"))
    if at is None or close is None or close <= 0:
        return None
    high = _number(row.get("high"))
    low = _number(row.get("low"))
    if high is None:
        high = close
    if low is None:
        low = close
    if high < low or high <= 0 or low <= 0:
        return None
    return {"at": at, "close": close, "high": high, "low": low, "symbol": _row_symbol(row)}


def load_prices(path: Path) -> dict[str, list[dict[str, Any]]]:
    """Load local point/bar observations; invalid rows are ignored, never repaired."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    rows: Any = raw.get("prices", raw) if isinstance(raw, Mapping) else raw
    if not isinstance(rows, list):
        raise ValueError("prices_json_must_be_a_list_or_object_with_prices")
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for raw_row in rows:
        if not isinstance(raw_row, Mapping):
            continue
        row = _price_row(raw_row)
        if row is not None and row["symbol"]:
            result[row["symbol"]].append(row)
    for symbol in result:
        result[symbol].sort(key=lambda item: item["at"])
    return dict(result)


def _latest_at_or_before(
    rows: Sequence[Mapping[str, Any]], moment: datetime, tolerance: timedelta
) -> Mapping[str, Any] | None:
    """Use only a price already known at ``moment``, bounded against stale snapshots."""
    eligible = [row for row in rows if row["at"] <= moment]
    if not eligible:
        return None
    latest_at = max(row["at"] for row in eligible)
    found = [row for row in eligible if row["at"] == latest_at]
    # Two local records at the selected timestamp make the price unknowable to this tool.
    if len(found) != 1 or moment - latest_at > tolerance:
        return None
    return found[0]


def _normalised_prices(
    prices: Mapping[str, Sequence[Mapping[str, Any]]],
) -> dict[str, list[Mapping[str, Any]]]:
    """Accept loaded rows and the same raw row shape for programmatic callers."""
    result: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for expected_symbol, rows in prices.items():
        for raw in rows:
            row = raw if "at" in raw else _price_row(raw)
            if row is not None:
                result[str(expected_symbol).upper()].append(row)
    for symbol in result:
        result[symbol].sort(key=lambda item: item["at"])
    return dict(result)


def _continuous(rows: Sequence[Mapping[str, Any]], start: datetime, end: datetime,
                max_gap: timedelta) -> list[Mapping[str, Any]] | None:
    relevant = [row for row in rows if start <= row["at"] <= end]
    if not relevant or relevant[0]["at"] != start or relevant[-1]["at"] != end:
        return None
    if any(later["at"] - earlier["at"] > max_gap
           for earlier, later in zip(relevant, relevant[1:], strict=False)):
        return None
    return relevant


def _directional_percent(price: float, entry: float, direction: str) -> float:
    raw = (price / entry - 1.0) * 100.0
    return raw if direction == "CALL" else -raw


def _target_stop(
    rows: Iterable[Mapping[str, Any]], *, entry: float, direction: str,
    target: float | None, stop: float | None,
) -> dict[str, Any]:
    if target is None or stop is None:
        return {"status": "UNAVAILABLE", "reason": "target_or_stop_missing"}
    valid = ((direction == "CALL" and target > entry > stop)
             or (direction == "PUT" and target < entry < stop))
    if not valid:
        return {"status": "UNAVAILABLE", "reason": "invalid_directional_levels"}
    for row in rows:
        if direction == "CALL":
            target_hit, stop_hit = row["high"] >= target, row["low"] <= stop
        else:
            target_hit, stop_hit = row["low"] <= target, row["high"] >= stop
        if target_hit and stop_hit:
            return {"status": "AMBIGUOUS", "at": _iso(row["at"]),
                    "reason": "target_and_stop_crossed_same_bar"}
        if target_hit:
            return {"status": "TARGET_FIRST", "at": _iso(row["at"])}
        if stop_hit:
            return {"status": "STOP_FIRST", "at": _iso(row["at"])}
    return {"status": "NEITHER"}


def measure_forward(
    features: Mapping[str, Any], as_of: datetime, prices: Mapping[str, Sequence[Mapping[str, Any]]],
    *, max_gap_minutes: int = 2, price_tolerance_seconds: int = 60,
    now: datetime | None = None,
) -> dict[int, dict[str, Any]]:
    """Measure windows using only bounded, timestamped prices at or before each boundary."""
    if max_gap_minutes < 1 or price_tolerance_seconds < 0:
        raise ValueError("invalid_coverage_tolerance")
    symbol, direction = _symbol(features), _direction(features)
    prices = _normalised_prices(prices)
    rows = prices.get(symbol, [])
    tolerance = timedelta(seconds=price_tolerance_seconds)
    current = (now or datetime.now(UTC)).astimezone(UTC)
    start = _latest_at_or_before(rows, as_of, tolerance)
    if not symbol or not rows:
        reason = "symbol_or_prices_unavailable"
    elif start is None:
        reason = "as_of_price_unavailable_or_stale"
    elif direction is None:
        reason = "direction_unavailable"
    else:
        reason = ""
    result: dict[int, dict[str, Any]] = {}
    for horizon in HORIZONS:
        endpoint = as_of + timedelta(minutes=horizon)
        if endpoint > current:
            result[horizon] = {"status": "UNAVAILABLE", "reason": "future_horizon",
                               "expected_at": _iso(endpoint)}
            continue
        if reason:
            result[horizon] = {"status": "UNAVAILABLE", "reason": reason}
            continue
        endpoint_row = _latest_at_or_before(rows, endpoint, tolerance)
        if endpoint_row is None:
            result[horizon] = {"status": "UNAVAILABLE", "reason": "horizon_or_coverage_missing",
                               "expected_at": _iso(endpoint)}
            continue
        assert start is not None
        max_gap = timedelta(minutes=max_gap_minutes)
        window = _continuous(rows, start["at"], endpoint_row["at"], max_gap)
        if window is None:
            result[horizon] = {"status": "UNAVAILABLE", "reason": "horizon_or_coverage_missing",
                               "expected_at": _iso(endpoint)}
            continue
        assert direction is not None
        # The source price is known at the anchor; its bar high/low is not future evidence.
        forward_rows = [row for row in window if row["at"] > as_of]
        if not forward_rows:
            result[horizon] = {"status": "UNAVAILABLE", "reason": "forward_coverage_missing",
                               "expected_at": _iso(endpoint)}
            continue
        highs = max(row["high"] for row in forward_rows)
        lows = min(row["low"] for row in forward_rows)
        highs, lows = max(start["close"], highs), min(start["close"], lows)
        favorable, adverse = (highs, lows) if direction == "CALL" else (lows, highs)
        target, stop = _levels(features)
        result[horizon] = {
            "status": "MEASURED",
            "symbol": symbol,
            "direction": direction,
            "observed_as_of": _iso(as_of),
            "entry_source_at": _iso(start["at"]),
            "entry_price": start["close"],
            "requested_horizon_minutes": horizon,
            "measured_at": _iso(endpoint_row["at"]),
            "endpoint_lag_seconds": (endpoint - endpoint_row["at"]).total_seconds(),
            "close_price": endpoint_row["close"],
            "underlying_directional_return_pct": round(
                _directional_percent(endpoint_row["close"], start["close"], direction), 8
            ),
            "mfe_underlying_pct": round(
                _directional_percent(favorable, start["close"], direction), 8
            ),
            "mae_underlying_pct": round(
                _directional_percent(adverse, start["close"], direction), 8
            ),
            "coverage": {"max_gap_minutes": max_gap_minutes, "observations": len(window)},
            "target_stop": _target_stop(forward_rows, entry=start["close"], direction=direction,
                                         target=target, stop=stop),
        }
    return result


def read_evidence(db_path: Path) -> list[dict[str, Any]]:
    with sqlite3.connect(db_path) as db:
        db.row_factory = sqlite3.Row
        observations = db.execute(
            "SELECT observation_id, as_of, candidate_id, symbol, features_json, evaluation_json, "
            "python_pass, shadow FROM observations ORDER BY as_of, observation_id"
        ).fetchall()
        events = db.execute(
            "SELECT event_id, observation_id, as_of, kind, payload_json FROM events "
            "ORDER BY event_id"
        ).fetchall()
        stored = db.execute(
            "SELECT observation_id, horizon_minutes, measured_at, payload_json FROM outcomes"
        ).fetchall()
    by_observation: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in events:
        by_observation[str(row["observation_id"])].append({
            "event_id": row["event_id"], "as_of": row["as_of"], "kind": row["kind"],
            "payload": _json(row["payload_json"], {}),
        })
    outcomes: dict[str, dict[int, dict[str, Any]]] = defaultdict(dict)
    for row in stored:
        outcomes[str(row["observation_id"])][int(row["horizon_minutes"])] = {
            "measured_at": row["measured_at"], "payload": _json(row["payload_json"], {}),
        }
    result = []
    for row in observations:
        as_of = _time(row["as_of"])
        if as_of is None:
            continue
        identifier = str(row["observation_id"])
        result.append({
            "observation_id": identifier, "as_of": as_of, "candidate_id": row["candidate_id"],
            "symbol": row["symbol"], "features": _json(row["features_json"], {}),
            "evaluation": _json(row["evaluation_json"], {}),
            "python_pass": bool(row["python_pass"]), "shadow": bool(row["shadow"]),
            "events": by_observation[identifier], "outcomes": outcomes[identifier],
        })
    return result


def _path(record: Mapping[str, Any], event: Mapping[str, Any]) -> str | None:
    # One observation can carry several immutable events. Only this event records the actual
    # decision route; execution/diagnostic events must not duplicate its outcome label or P&L.
    if event.get("kind") != "luna_routing":
        return None
    payload = event.get("payload")
    payload = payload if isinstance(payload, Mapping) else {}
    explicit = str(payload.get("path") or payload.get("pipeline") or "").lower().replace("-", "_")
    aliases = {
        "python_to_luna": "python_luna", "python_luna": "python_luna",
        "python_to_jev_to_luna": "python_jev_luna", "python_jev_luna": "python_jev_luna",
        "python_to_book_to_jev_to_luna": "python_book_jev_luna",
        "python_book_jev_luna": "python_book_jev_luna",
    }
    if record.get("shadow") is True:
        return "python_luna"
    evaluation = record.get("evaluation", {})
    if not isinstance(evaluation, Mapping) or evaluation.get("status") != "OK":
        return "python_luna"
    if explicit in aliases:
        return aliases[explicit]
    # A persisted JEV routing event is actual evidence of the JEV path.  Book use is captured
    # by the version recorded with that immutable observation; no market data is inferred here.
    versions = evaluation.get("question_versions", [])
    return "python_book_jev_luna" if "jev-book-v2" in versions else "python_jev_luna"


def _routing_events(record: Mapping[str, Any]) -> list[dict[str, Any]]:
    return [event for event in record.get("events", []) if _path(record, event) in PATHS]


def _score_bucket(record: Mapping[str, Any]) -> str:
    scores = record.get("evaluation", {}).get("scores", {})
    value = _number(scores.get("setup_quality")) if isinstance(scores, Mapping) else None
    if value is None:
        return "unavailable"
    if value < 0.5:
        return "below_0.50"
    if value < 0.6:
        return "[0.50,0.60)"
    if value < 0.7:
        return "[0.60,0.70)"
    if value < 0.8:
        return "[0.70,0.80)"
    if value < 0.9:
        return "[0.80,0.90)"
    if value <= 1:
        return "[0.90,1.00]"
    return "out_of_range"


def _regime(record: Mapping[str, Any]) -> str:
    answers = record.get("evaluation", {}).get("answers", {})
    answer = answers.get("market_regime") if isinstance(answers, Mapping) else None
    choice = answer.get("choice") if isinstance(answer, Mapping) else None
    if choice not in (None, ""):
        return str(choice)
    return "unavailable"


def _time_bucket(at: datetime) -> str:
    local = at.astimezone(NEW_YORK)
    start = local.replace(minute=(local.minute // 30) * 30, second=0, microsecond=0)
    end = start + timedelta(minutes=30)
    return f"{start:%H:%M}-{end:%H:%M} ET"


def _forward_label(record: Mapping[str, Any]) -> str | None:
    outcome = record.get("outcomes", {}).get(30, {}).get("payload", {})
    if not isinstance(outcome, Mapping) or outcome.get("status") != "MEASURED":
        return None
    value = _number(outcome.get("underlying_directional_return_pct"))
    if value is None or value == 0:
        return None
    return "winner" if value > 0 else "loser"


def _outcome_anchor(record: Mapping[str, Any]) -> tuple[datetime, datetime | None]:
    """Scores cannot be labelled with movement that occurred before their response arrived."""
    observed = record["as_of"]
    evaluation = record.get("evaluation", {})
    available = _time(evaluation.get("available_at")) if isinstance(evaluation, Mapping) else None
    if available is not None and available > observed and evaluation.get("status") == "OK":
        return available, available
    return observed, None


def _realized_pnl(value: Any) -> float | None:
    if not isinstance(value, Mapping):
        return None
    direct = _number(value.get("realized_pnl"))
    nested = value.get("realized")
    if direct is not None:
        return direct
    if isinstance(nested, Mapping):
        return _number(_mapping_value(nested, "pnl", "realized_pnl"))
    return None


def _realized_records(records: Sequence[Mapping[str, Any]]) -> list[tuple[datetime, float]]:
    chosen: dict[str, tuple[datetime, float]] = {}
    for record in records:
        for event in record.get("events", []):
            if event.get("kind") not in REALIZED_EVENT_KINDS:
                continue
            pnl = _realized_pnl(event.get("payload"))
            at = _time(event.get("as_of"))
            if pnl is not None and at is not None:
                chosen[str(record["observation_id"])] = (at, pnl)
        for outcome in record.get("outcomes", {}).values():
            pnl = _realized_pnl(outcome.get("payload"))
            at = _time(outcome.get("measured_at"))
            if pnl is not None and at is not None:
                chosen.setdefault(str(record["observation_id"]), (at, pnl))
    return sorted(chosen.values(), key=lambda item: item[0])


def _pnl_metrics(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    values = [pnl for _, pnl in _realized_records(records)]
    if not values:
        return {"status": "UNAVAILABLE", "reason": "no_supplied_realized_outcomes"}
    wins = sum(value for value in values if value > 0)
    losses = -sum(value for value in values if value < 0)
    equity, peak, max_drawdown = 0.0, 0.0, 0.0
    for value in values:
        equity += value
        peak = max(peak, equity)
        max_drawdown = max(max_drawdown, peak - equity)
    return {
        "status": "SUPPLIED_REALIZED_OUTCOMES_ONLY", "count": len(values),
        "expectancy": round(sum(values) / len(values), 8),
        "profit_factor": round(wins / losses, 8) if losses else None,
        "max_drawdown": round(max_drawdown, 8),
        "limitations": (
            "realized-only sequence; not mark-to-market and not option P&L inferred from prices"
        ),
    }


def report(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    groups: dict[str, list[tuple[Mapping[str, Any], Mapping[str, Any]]]] = defaultdict(list)
    for record in records:
        for event in _routing_events(record):
            groups[_path(record, event) or "unknown"].append((record, event))
    comparison: dict[str, Any] = {}
    for path, routed in sorted(groups.items()):
        calls = [event.get("payload", {}).get("luna_escalated") for _, event in routed]
        exact_calls = [value for value in calls if isinstance(value, bool)]
        saved = [event for _, event in routed if isinstance(event.get("payload"), Mapping)
                 and event["payload"].get("baseline_would_call") is True
                 and event["payload"].get("luna_escalated") is False]
        gate_pairs = []
        for record, _event in routed:
            if path == "python_luna":
                continue
            policy = record.get("evaluation", {}).get("policy", {})
            escalates = policy.get("would_escalate") if isinstance(policy, Mapping) else None
            label = _forward_label(record)
            if isinstance(escalates, bool) and label is not None:
                gate_pairs.append((escalates, label))
        winners = sum(label == "winner" for _, label in gate_pairs)
        losers = sum(label == "loser" for _, label in gate_pairs)
        retained_winners = sum(
            escalates for escalates, label in gate_pairs if label == "winner"
        )
        rejected_losers = sum(
            not escalates for escalates, label in gate_pairs if label == "loser"
        )
        shadow_suppressions = sum(
            record.get("shadow") is True
            and isinstance(record.get("evaluation", {}).get("policy"), Mapping)
            and record["evaluation"]["policy"].get("would_escalate") is False
            for record, _ in routed
        )
        comparison[path] = {
            "routing_events": len(routed),
            "calls_actually_consumed": sum(value is True for value in exact_calls)
            if exact_calls else None,
            "call_status_records": len(exact_calls),
            "hypothetical_calls_saved": len(saved) if any(
                isinstance(event.get("payload"), Mapping)
                and "baseline_would_call" in event["payload"] for _, event in routed
            ) else None,
            "hypothetical_saved_definition": "explicit baseline_would_call=true and actual no call",
            "potential_shadow_policy_suppressions": shadow_suppressions,
            "potential_shadow_policy_note": (
                "shadow policy counterfactual only; excluded from saved-call and active-route "
                "claims"
            ),
            "score_buckets": dict(Counter(_score_bucket(record) for record, _ in routed)),
            "regimes": dict(Counter(_regime(record) for record, _ in routed)),
            "time_of_day": dict(Counter(_time_bucket(record["as_of"]) for record, _ in routed)),
            "winner_retention": (
                round(retained_winners / winners, 8) if winners else None
            ),
            "loser_rejection": (
                round(rejected_losers / losers, 8) if losers else None
            ),
            "directional_label_coverage": len(gate_pairs),
            "directional_label_note": (
                "30-minute underlying direction only; not option P&L. "
                "Baseline rows do not use JEV policy as an active gate."
            ),
            "realized_metrics": _pnl_metrics([record for record, _ in routed]),
        }
    return {
        "status": "EVIDENCE_ONLY",
        "observations": len(records),
        "observed_groups": comparison,
        "not_reported_groups": [path for path in PATHS if path not in comparison],
        "limitations": [
            ("Only persisted routing events form comparison groups; "
             "absent paths are not synthesized."),
            ("Forward labels begin at evaluation.available_at when an OK JEV score records it; "
             "they are not option P&L."),
            "Expectancy, profit factor, and drawdown require explicitly supplied realized P&L.",
        ],
    }


def attach_outcomes(
    records: Sequence[Mapping[str, Any]], prices: Mapping[str, Sequence[Mapping[str, Any]]],
    *, max_gap_minutes: int = 2, price_tolerance_seconds: int = 60,
    now: datetime | None = None,
) -> dict[str, dict[int, dict[str, Any]]]:
    return {
        str(record["observation_id"]): _attach_record(
            record, prices, max_gap_minutes=max_gap_minutes,
            price_tolerance_seconds=price_tolerance_seconds, now=now,
        )
        for record in records
    }


def _attach_record(
    record: Mapping[str, Any], prices: Mapping[str, Sequence[Mapping[str, Any]]], *,
    max_gap_minutes: int, price_tolerance_seconds: int, now: datetime | None,
) -> dict[int, dict[str, Any]]:
    anchor, available_at = _outcome_anchor(record)
    attached = measure_forward(
        record["features"], anchor, prices, max_gap_minutes=max_gap_minutes,
        price_tolerance_seconds=price_tolerance_seconds, now=now,
    )
    for payload in attached.values():
        payload["observation_as_of"] = _iso(record["as_of"])
        payload["outcome_anchor_at"] = _iso(anchor)
        if available_at is not None:
            payload["evaluation_available_at"] = _iso(available_at)
    return attached


def write_completed_outcomes(
    db_path: Path, attached: Mapping[str, Mapping[int, Mapping[str, Any]]]
) -> dict[str, int]:
    """Append final measured/ambiguous evidence; never replace an existing outcome."""
    written = identical = conflicts = skipped = 0
    with sqlite3.connect(db_path) as db:
        db.execute("BEGIN IMMEDIATE")
        for observation_id, horizons in attached.items():
            for horizon, payload in horizons.items():
                status = payload.get("status")
                # An unavailable local snapshot can become available later, so do not freeze it.
                if status not in {"MEASURED"}:
                    skipped += 1
                    continue
                measured_at = payload.get("measured_at")
                if not isinstance(measured_at, str):
                    skipped += 1
                    continue
                encoded = json.dumps(
                    payload, sort_keys=True, separators=(",", ":"), allow_nan=False
                )
                old = db.execute(
                    "SELECT measured_at,payload_json FROM outcomes "
                    "WHERE observation_id=? AND horizon_minutes=?",
                    (observation_id, horizon),
                ).fetchone()
                if old is None:
                    db.execute("INSERT INTO outcomes VALUES (?,?,?,?)",
                               (observation_id, horizon, measured_at, encoded))
                    written += 1
                elif old[0] == measured_at and old[1] == encoded:
                    identical += 1
                else:
                    conflicts += 1
    return {"written": written, "identical": identical, "conflicts": conflicts, "skipped": skipped}


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Offline point-in-time JEV replay and evidence report"
    )
    parser.add_argument("db", type=Path, help="existing JEV SQLite database")
    parser.add_argument("--prices", type=Path, help="local JSON timestamped underlying prices")
    parser.add_argument("--max-gap-minutes", type=int, default=2)
    parser.add_argument("--price-tolerance-seconds", type=int, default=60)
    parser.add_argument("--write-outcomes", action="store_true",
                        help="append only completed measured outcomes; never updates observations")
    parser.add_argument("--output", type=Path, help="optional local JSON report path")
    args = parser.parse_args(argv)
    records = read_evidence(args.db)
    result: dict[str, Any] = {"report": report(records)}
    if args.prices is not None:
        attached = attach_outcomes(
            records, load_prices(args.prices), max_gap_minutes=args.max_gap_minutes
            , price_tolerance_seconds=args.price_tolerance_seconds
        )
        result["attached_outcomes"] = attached
        if args.write_outcomes:
            result["outcome_write"] = write_completed_outcomes(args.db, attached)
            records = read_evidence(args.db)
            result["report"] = report(records)
    elif args.write_outcomes:
        parser.error("--write-outcomes requires --prices")
    rendered = json.dumps(result, indent=2, sort_keys=True, default=str) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
