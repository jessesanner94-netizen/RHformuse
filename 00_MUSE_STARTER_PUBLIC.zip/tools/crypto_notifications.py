"""Durable per-channel delivery of committed crypto paper entry/exit events."""

import json
import sqlite3
import subprocess
from pathlib import Path

from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock
from tools.windows_notify import (
    _send_windows_notification,
    notification_payload,
    send_ntfy_notification,
)


def _deliver(channel, title, message, root):
    if channel == "windows":
        return _send_windows_notification(title, message, project_root=root, runner=subprocess.run)
    return send_ntfy_notification(title, message)


def drain_notifications(project_root, *, sender=None):
    root = Path(project_root)
    path = root / "state/research/crypto_paper.sqlite3"
    if not path.exists():
        return {"status": "SKIPPED", "reason": "no_ledger"}
    sender = sender or _deliver
    try:
        with (
            advisory_file_lock(root / "state/runtime/crypto_notifications", timeout_seconds=0.1),
            sqlite3.connect(path, timeout=5) as db,
        ):
            db.execute(
                "CREATE TABLE IF NOT EXISTS notification_delivery "
                "(event_id INTEGER PRIMARY KEY, channels TEXT NOT NULL, "
                "complete INTEGER NOT NULL)"
            )
            rows = db.execute(
                "SELECT e.id,e.kind,e.body,d.channels FROM events e "
                "LEFT JOIN notification_delivery d ON d.event_id=e.id "
                "WHERE e.kind IN ('paper_entry','paper_exit') AND COALESCE(d.complete,0)=0 "
                "ORDER BY e.id LIMIT 3"
            ).fetchall()
            db.commit()
            delivered = []
            for event_id, kind, body, previous in rows:
                payload = notification_payload(
                    {"crypto_event": {"kind": kind, "body": json.loads(body)}}
                )
                if payload is None:
                    continue
                channels = json.loads(previous) if previous else {}
                for channel in ("windows", "ntfy"):
                    if channels.get(channel, {}).get("status") == "SENT":
                        continue
                    try:
                        channels[channel] = sender(channel, *payload, root)
                    except Exception as exc:
                        channels[channel] = {"status": "ERROR", "reason": type(exc).__name__}
                    complete = all(
                        channels.get(c, {}).get("status") in {"SENT", "SKIPPED"}
                        for c in ("windows", "ntfy")
                    )
                    db.execute(
                        "INSERT OR REPLACE INTO notification_delivery VALUES (?,?,?)",
                        (event_id, json.dumps(channels), int(complete)),
                    )
                    db.commit()
                delivered.append({"event_id": event_id, "channels": channels})
            return {"status": "CHECKED", "events": delivered}
    except RuntimeLockUnavailable:
        return {"status": "SKIPPED", "reason": "notification_delivery_in_progress"}
