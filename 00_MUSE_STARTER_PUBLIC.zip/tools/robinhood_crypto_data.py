"""Read-only Robinhood v2 ETH feed. No order endpoints or external fallback."""

from __future__ import annotations

import asyncio
import base64
import json
import os
import time
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from tools.crypto_paper import valid_quote
from tools.crypto_symbols import validate_symbol

VENUE = "ROBINHOOD_CRYPTO_V2"
QUOTE_PATH = "/api/v2/crypto/marketdata/best_bid_ask/?symbol=ETH-USD"
ALLOWED_PATHS = frozenset(
    {
        QUOTE_PATH,
        "/api/v2/crypto/trading/accounts/",
        "/api/v2/crypto/trading/trading_pairs/?symbol=ETH-USD",
        "/api/v2/crypto/trading/estimated_price/?symbol=ETH-USD&side=both&quantity=0.01",
    }
)


ALLOWED_PATHS = ALLOWED_PATHS | frozenset(
    path.replace("ETH-USD", "BTC-USD") for path in ALLOWED_PATHS
)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def read_endpoint(path):
    """Fixed GET allowlist; credentials stay in memory, errors never include bodies."""
    if path not in ALLOWED_PATHS:
        raise ValueError("unsupported_read_endpoint")
    try:
        import win32crypt

        folder = Path(os.environ["LOCALAPPDATA"]) / "RobinhoodCryptoAPI"
        key = (
            win32crypt.CryptUnprotectData(
                (folder / "api_key.dpapi").read_bytes(), None, None, None, 0
            )[1]
            .decode()
            .strip()
        )
        seed = win32crypt.CryptUnprotectData(
            (folder / "ed25519_seed.dpapi").read_bytes(), None, None, None, 0
        )[1]
        timestamp = str(int(time.time()))
        signature = base64.b64encode(
            Ed25519PrivateKey.from_private_bytes(seed).sign(f"{key}{timestamp}{path}GET".encode())
        ).decode()
        request = urllib.request.Request(
            "https://trading.robinhood.com" + path,
            method="GET",
            headers={
                "x-api-key": key,
                "x-timestamp": timestamp,
                "x-signature": signature,
                "Accept": "application/json",
            },
        )
        with urllib.request.build_opener(NoRedirect()).open(request, timeout=10) as response:
            body = response.read(1_000_001)
        if len(body) > 1_000_000:
            raise ValueError("oversize_response")
        return json.loads(body)
    except Exception:
        raise ValueError("robinhood_read_unavailable") from None


async def fetch_quote(now=None, reader=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    raw = await asyncio.to_thread(reader or read_endpoint, QUOTE_PATH.replace("ETH-USD", symbol))
    current = now or datetime.now(UTC)
    rows = raw.get("results", [])
    if len(rows) != 1 or rows[0].get("symbol") != symbol:
        raise ValueError("invalid_robinhood_quote")
    if any(isinstance(rows[0].get(key), bool) for key in ("bid", "ask")):
        raise ValueError("invalid_robinhood_quote")
    quote = {
        "symbol": symbol,
        "bid": float(rows[0]["bid"]),
        "ask": float(rows[0]["ask"]),
        "updated_at": rows[0].get("timestamp") or current.isoformat(),
        "timestamp_source": "provider" if rows[0].get("timestamp") else "receipt_time",
        "venue": VENUE,
        "excludes_fees_and_size": True,
    }
    bid, ask = valid_quote(quote, current)
    quote["price"] = (bid + ask) / 2
    return quote


async def fetch_snapshot(now=None, reader=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    try:
        quote = await fetch_quote(now=now, reader=reader, symbol=symbol)
    except (ValueError, KeyError, TypeError):
        return {
            "status": "UNAVAILABLE",
            "venue": VENUE,
            "reason": "robinhood_quote_invalid_or_unavailable",
        }
    return {
        "status": "UNAVAILABLE",
        "symbol": symbol,
        "venue": VENUE,
        "quote": quote,
        "candles_5m": [],
        "book": None,
        "reason": "robinhood_candles_volume_and_full_depth_not_exposed",
        "capabilities": {"best_bid_ask": True, "full_orderbook": False, "historical_ohlcv": False},
    }
