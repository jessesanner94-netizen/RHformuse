"""Reconcile broker snapshots with Markdown memory and perform guarded atomic JSON updates."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

HEADING = re.compile(r"^###\s+(.+?)\s*$")
FIELD = re.compile(r"^-\s+([^:]+):\s*(.*?)\s*$")


@dataclass(frozen=True)
class ProjectPosition:
    heading: str
    contract_identifier: str
    quantity: float
    fields: Mapping[str, str]


def parse_positions_markdown(text: str) -> list[ProjectPosition]:
    sections: list[tuple[str, dict[str, str]]] = []
    heading: str | None = None
    fields: dict[str, str] = {}
    for line in text.splitlines():
        heading_match = HEADING.match(line)
        if heading_match:
            if heading is not None:
                sections.append((heading, fields))
            heading = heading_match.group(1)
            fields = {}
            continue
        field_match = FIELD.match(line)
        if heading is not None and field_match:
            fields[field_match.group(1).strip().lower()] = field_match.group(2).strip()
    if heading is not None:
        sections.append((heading, fields))

    positions: list[ProjectPosition] = []
    for section_heading, section_fields in sections:
        if "[SYMBOL]" in section_heading:
            continue
        contract_id = section_fields.get("robinhood contract identifier", "").strip()
        quantity_raw = section_fields.get("quantity", "").strip()
        if not contract_id and not quantity_raw:
            continue
        if not contract_id:
            raise ValueError(f"position {section_heading!r} has no Robinhood contract identifier")
        try:
            quantity = float(quantity_raw)
        except ValueError as exc:
            raise ValueError(f"position {section_heading!r} has invalid quantity") from exc
        if quantity <= 0:
            raise ValueError(f"position {section_heading!r} quantity must be positive")
        positions.append(ProjectPosition(section_heading, contract_id, quantity, section_fields))
    return positions


def load_project_positions(path: str | Path) -> list[ProjectPosition]:
    return parse_positions_markdown(Path(path).read_text(encoding="utf-8"))


def _broker_position(position: Mapping[str, Any]) -> tuple[str, float] | None:
    if not isinstance(position, Mapping):
        return None
    contract_id = position.get("contract_identifier")
    quantity = position.get("quantity")
    if not isinstance(contract_id, str) or not contract_id.strip():
        return None
    if isinstance(quantity, bool) or not isinstance(quantity, (int, float)) or quantity <= 0:
        return None
    return contract_id.strip(), float(quantity)


def reconcile_positions(
    project_positions: Iterable[ProjectPosition], broker_snapshot: Mapping[str, Any]
) -> dict[str, Any]:
    if broker_snapshot.get("snapshot_is_fresh") is not True:
        return {
            "status": "INSUFFICIENT_DATA",
            "reasons": ["broker_snapshot_freshness_unverified"],
            "matched": [],
            "missing_in_project": [],
            "missing_at_broker": [],
            "quantity_mismatches": [],
        }
    raw_broker_positions = broker_snapshot.get("positions")
    raw_open_orders = broker_snapshot.get("open_orders")
    if not isinstance(raw_broker_positions, list) or not isinstance(raw_open_orders, list):
        return {
            "status": "INSUFFICIENT_DATA",
            "reasons": ["broker_positions_or_orders_missing"],
            "matched": [],
            "missing_in_project": [],
            "missing_at_broker": [],
            "quantity_mismatches": [],
        }

    project_list = list(project_positions)
    project_ids = [position.contract_identifier for position in project_list]
    duplicate_project = sorted({item for item in project_ids if project_ids.count(item) > 1})
    broker_pairs = [_broker_position(item) for item in raw_broker_positions]
    if any(item is None for item in broker_pairs):
        return {
            "status": "INSUFFICIENT_DATA",
            "reasons": ["invalid_broker_position"],
            "matched": [],
            "missing_in_project": [],
            "missing_at_broker": [],
            "quantity_mismatches": [],
        }
    broker_map = dict(item for item in broker_pairs if item is not None)
    broker_ids = [item[0] for item in broker_pairs if item is not None]
    duplicate_broker = sorted({item for item in broker_ids if broker_ids.count(item) > 1})
    project_map = {position.contract_identifier: position.quantity for position in project_list}

    missing_in_project = sorted(set(broker_map) - set(project_map))
    missing_at_broker = sorted(set(project_map) - set(broker_map))
    matched = sorted(set(project_map) & set(broker_map))
    quantity_mismatches = [
        {
            "contract_identifier": contract_id,
            "project_quantity": project_map[contract_id],
            "broker_quantity": broker_map[contract_id],
        }
        for contract_id in matched
        if project_map[contract_id] != broker_map[contract_id]
    ]
    invalid_open_orders = [
        order
        for order in raw_open_orders
        if not isinstance(order, Mapping)
        or not isinstance(order.get("contract_identifier"), str)
        or not order.get("contract_identifier", "").strip()
    ]
    unknown_open_orders = sorted(
        {
            str(order.get("contract_identifier"))
            for order in raw_open_orders
            if isinstance(order, Mapping)
            and order.get("contract_identifier")
            and order.get("contract_identifier") not in project_map
        }
    )
    reasons: list[str] = []
    if duplicate_project:
        reasons.append("duplicate_project_contracts")
    if duplicate_broker:
        reasons.append("duplicate_broker_contracts")
    if missing_in_project:
        reasons.append("broker_position_missing_from_project_memory")
    if missing_at_broker:
        reasons.append("project_position_missing_at_broker")
    if quantity_mismatches:
        reasons.append("position_quantity_mismatch")
    if invalid_open_orders:
        reasons.append("invalid_open_order")
    if unknown_open_orders:
        reasons.append("open_order_missing_from_project_memory")
    return {
        "status": "MISMATCH" if reasons else "RECONCILED",
        "reasons": reasons,
        "matched": matched,
        "missing_in_project": missing_in_project,
        "missing_at_broker": missing_at_broker,
        "quantity_mismatches": quantity_mismatches,
        "duplicate_project_contracts": duplicate_project,
        "duplicate_broker_contracts": duplicate_broker,
        "unknown_open_order_contracts": unknown_open_orders,
        "invalid_open_order_count": len(invalid_open_orders),
    }


def file_sha256(path: str | Path) -> str | None:
    target = Path(path)
    if not target.exists():
        return None
    return hashlib.sha256(target.read_bytes()).hexdigest()


def guarded_json_update(
    path: str | Path,
    payload: Mapping[str, Any],
    *,
    commit: bool = False,
    expected_sha256: str | None = None,
) -> dict[str, Any]:
    target = Path(path)
    current_hash = file_sha256(target)
    result = {
        "mode": "COMMIT" if commit else "DRY_RUN",
        "target": str(target),
        "current_sha256": current_hash,
        "written": False,
        "payload": payload,
    }
    if expected_sha256 is not None and expected_sha256 != current_hash:
        result["status"] = "CONFLICT"
        result["reason"] = "expected hash does not match current file"
        return result
    if not commit:
        result["status"] = "PREVIEW"
        return result

    target.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    descriptor, temp_name = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=target.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, target)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    result["status"] = "UPDATED"
    result["written"] = True
    result["new_sha256"] = file_sha256(target)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    reconcile_parser = subparsers.add_parser("reconcile")
    reconcile_parser.add_argument("--positions", type=Path, default=Path("state/POSITIONS.md"))
    reconcile_parser.add_argument("--broker", type=Path, required=True)

    snapshot_parser = subparsers.add_parser("snapshot")
    snapshot_parser.add_argument("--target", type=Path, default=Path("state/runtime_state.json"))
    snapshot_parser.add_argument("--input", type=Path, required=True)
    snapshot_parser.add_argument("--expected-sha256")
    snapshot_parser.add_argument("--commit", action="store_true")

    args = parser.parse_args()
    if args.command == "reconcile":
        payload = json.loads(args.broker.read_text(encoding="utf-8"))
        result = reconcile_positions(load_project_positions(args.positions), payload)
    else:
        snapshot_payload = json.loads(args.input.read_text(encoding="utf-8"))
        result = guarded_json_update(
            args.target,
            snapshot_payload,
            commit=args.commit,
            expected_sha256=args.expected_sha256,
        )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
