"""Daily candidate funnel and forward paper comparison, with explicit cost coverage."""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Mapping
from datetime import datetime
from pathlib import Path
from typing import Any

from tools.config import TradingConfig
from tools.cost_tracker import read_ledger, summarize
from tools.options_strategy import ledger_directory, strategy_epoch
from tools.paper_trading import _atomic_text_write, _exclusive_lock, paper_summary
from tools.state_manager import guarded_json_update


def _ledger_summary(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"status": "NOT_STARTED"}
    state = json.loads(path.read_text(encoding="utf-8"))
    result = paper_summary(state)
    trades = int(result["closed_trades"])
    result["win_rate"] = result["winning_trades"] / trades if trades else None
    result["net_expectancy_per_trade"] = result["realized_pnl"] / trades if trades else None
    result["profit_factor"] = (
        result["gross_wins"] / result["gross_losses"] if result["gross_losses"] else None
    )
    result["status"] = "FORWARD_PAPER_ONLY"
    return result


def _paired_outcomes(root: Path) -> dict[str, Any]:
    pairs = read_ledger(root / "state/evaluation/PAIRS.jsonl")
    exits = {}
    for name in ("paper", "paper_baseline"):
        exits[name] = {
            row["paper_id"]: row["realized_pnl"]
            for row in read_ledger(root / "state" / name / "EVENTS.jsonl")
            if row.get("event") == "PAPER_EXIT"
        }
    matched = []
    for pair in pairs:
        baseline_id, primary_id = pair.get("baseline_paper_id"), pair.get("primary_paper_id")
        if baseline_id not in exits["paper_baseline"]:
            continue
        if pair["model_action"] == "BUY" and primary_id not in exits["paper"]:
            continue
        matched.append(
            (float(exits["paper"].get(primary_id, 0)), float(exits["paper_baseline"][baseline_id]))
        )
    primary_pnl, baseline_pnl = (sum(item[i] for item in matched) for i in (0, 1))
    return {
        "completed_pairs": len(matched),
        "total_pairs": len(pairs),
        "model_net_pnl": round(primary_pnl, 2),
        "control_net_pnl": round(baseline_pnl, 2),
        "model_minus_control": round(primary_pnl - baseline_pnl, 2),
    }


def record_cycle_metrics(
    root: Path,
    cycle: str,
    result: Mapping[str, Any],
    *,
    now: datetime,
    config: TradingConfig | None = None,
):
    event = result.get("event") or {}
    discovery = event.get("option_discovery") or {}
    contracts = discovery.get("contract_discovery") or {}
    route = result.get("routing") or {}
    decision = route.get("decision") or {}
    reasons: Counter[str] = Counter()
    for rejection in contracts.get("gate", {}).get("rejected", []):
        reasons.update(rejection.get("reasons", []))
    for rejection in route.get("python_rejections", []):
        reasons.update(rejection.get("gate", {}).get("reasons", []))
    for suppressed in route.get("suppressed_candidates", []):
        reasons.update([suppressed["reason"]])
    base = contracts.get("funnel") or {}
    reasons["premium_outside_budget"] += int(base.get("premium_rejected", 0))
    paper_decision = result.get("paper_decision") or {}
    reasons.update("paper_fill:" + reason for reason in paper_decision.get("reasons", []))
    if discovery.get("reason"):
        reasons.update(["discovery:" + str(discovery["reason"])])
    if paper_decision.get("reason") and paper_decision.get("status") == "RECORDED_NO_ENTRY":
        reasons.update([str(paper_decision["reason"])])
    if decision.get("status") in {"ERROR", "BUDGET_BLOCKED", "SLEEPING"}:
        reasons.update(["decision:" + str(decision.get("reason") or decision["status"])])
    reasons = +reasons
    funnel = {
        **base,
        "entry_time_passed": len(discovery.get("qualified_candidates", [])),
        "python_evaluated": int(route.get("candidates_evaluated", 0)),
        "packet_ready": int(route.get("packet_status") == "READY"),
        "model_calls": int(decision.get("codex_invoked") is True),
        "paper_entries": int(result.get("paper_decision", {}).get("opened") is True),
        "baseline_entries": int(result.get("baseline_decision", {}).get("opened") is True),
        "daily_green_lock_entries": int(
            result.get("daily_green_lock_decision", {}).get("opened") is True
        ),
        "rejections": dict(reasons),
        "last_status": str(route.get("packet_status") or result.get("status") or "MONITORED"),
    }
    epoch = strategy_epoch(config) if config is not None else None
    directory = (
        root / "state/options" / epoch / "evaluation" if epoch else root / "state/evaluation"
    )
    path = directory / "METRICS.json"
    with _exclusive_lock(path):
        metrics = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"days": {}}
        from zoneinfo import ZoneInfo

        day = now.astimezone(ZoneInfo("America/New_York")).date().isoformat()
        totals = metrics["days"].setdefault(day, {"rejections": {}})
        totals[f"{cycle}_cycles"] = int(totals.get(f"{cycle}_cycles", 0)) + 1
        for key, value in funnel.items():
            if isinstance(value, int):
                totals[key] = int(totals.get(key, 0)) + value
        totals["rejections"] = dict(Counter(totals["rejections"]) + reasons)
        if cycle == "opportunities":
            totals["last_opportunity_status"] = "/".join(
                [
                    funnel["last_status"],
                    str(decision.get("status", "NONE")),
                    str(paper_decision.get("status", "NONE")),
                ]
            )
        metrics["updated_at"] = now.isoformat()
        primary_dir = (
            ledger_directory(root, config, "paper") if config is not None else root / "state/paper"
        )
        metrics["strategy_epoch"] = epoch
        metrics["primary"] = _ledger_summary(primary_dir / "PORTFOLIO.json")
        metrics["day_control"] = _ledger_summary(root / "state/paper_baseline/PORTFOLIO.json")
        metrics["daily_green_lock"] = _ledger_summary(
            root / "state/daily_green_lock/PORTFOLIO.json"
        )
        metrics["matched_day_comparison"] = (
            _paired_outcomes(root) if not epoch else {"status": "HISTORICAL_COMPARATORS_DISABLED"}
        )
        costs_path = directory / "COSTS.jsonl"
        if costs_path.exists():
            metrics["recorded_costs"] = summarize(
                read_ledger(costs_path),
                realized_net_trading_pnl=metrics["primary"].get("realized_pnl", 0),
            )
            metrics["cost_coverage"] = "RECORDED_COSTS_ONLY"
        else:
            metrics["recorded_costs"] = None
            metrics["cost_coverage"] = "AI_DATA_COSTS_NOT_RECORDED"
        guarded_json_update(path, metrics, commit=True)
        lines = [
            "# Paper Experiment",
            "",
            f"Updated: {now.isoformat()}",
            "",
            "Forward observations only. No profitability claim or trade quota.",
            "",
            "## Today's opportunity funnel",
            "",
        ]
        lines += [f"- {key}: {value}" for key, value in totals.items() if key != "rejections"]
        lines += ["", "## Rejection reasons (may overlap)", ""]
        lines += [
            f"- {key}: {value}"
            for key, value in sorted(totals["rejections"].items(), key=lambda item: -item[1])
        ]
        lines += [
            "",
            "## Forward results",
            "",
            "| Ledger | Closed | Net realized (estimated costs) | Equity | Max drawdown |",
            "| --- | ---: | ---: | ---: | ---: |",
        ]
        for name in ("primary",) if epoch else ("primary", "day_control", "daily_green_lock"):
            item = metrics[name]
            lines.append(
                f"| {name} | {item.get('closed_trades', 0)} | "
                f"{item.get('realized_pnl', 'N/A')} | {item.get('equity', 'N/A')} | "
                f"{item.get('max_drawdown_dollars', 'N/A')} |"
            )
        lines += [
            "",
            "Matched completed DAY pairs (after estimated execution costs, before AI/data costs): "
            + json.dumps(metrics["matched_day_comparison"], sort_keys=True),
            "",
            "The DAY control shares the model-reviewed candidate and quote, but buys without "
            "Luna's veto. It has an independent cash/risk ledger. Primary results also include "
            "SWING trades; restrict conclusions to matched DAY observations. Cached decisions "
            "and unreviewed candidates create no control entry.",
            "",
            "Prices use ask entries/bid exits. Configured fee/slippage assumptions are estimates. "
            "AI/data cost coverage: " + metrics["cost_coverage"] + ".",
        ]
        if epoch:
            lines = lines[:-6] + [
                "",
                f"Strategy epoch: {epoch}. Historical comparators are disabled.",
                "Python qualification and JEV ranking; no Luna entry/position judgment.",
                "Costs are modeled assumptions. AI/data coverage: "
                + metrics["cost_coverage"]
                + ".",
            ]
        if metrics["recorded_costs"] is not None:
            lines.append(
                "Economic profit after recorded AI/data costs: $"
                + metrics["recorded_costs"]["economic_profit"]
            )
        _atomic_text_write(directory / "SUMMARY.md", "\n".join(lines) + "\n")
    return funnel
