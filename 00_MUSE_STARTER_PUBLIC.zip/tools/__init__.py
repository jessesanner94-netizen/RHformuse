"""Deterministic, fail-closed utilities for the trading-agent workflow."""
