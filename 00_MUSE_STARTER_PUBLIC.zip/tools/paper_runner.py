"""Connect fresh Robinhood quotes and structured Sol decisions to the paper ledger."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.cheap_scan import evaluate_candidate
from tools.config import TradingConfig, load_config
from tools.option_style import annotate_option_styles
from tools.options_strategy import ledger_directory
from tools.paper_trading import (
    close_paper_position,
    ensure_paper_portfolio,
    manage_paper_positions,
    open_paper_position,
    paper_summary,
)
from tools.robinhood_mcp import fetch_quote_refresh
from tools.winner_evidence import (
    OrderbookCollector,
    TechnicalFetcher,
    collect_winner_evidence,
)


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _model_json(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    candidates = [text]
    if "{" in text and "}" in text:
        candidates.append(text[text.find("{") : text.rfind("}") + 1])
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, Mapping):
            return dict(parsed)
    return None


def _paths(
    project_root: Path, ledger_name: str = "paper", config: TradingConfig | None = None
) -> tuple[Path, Path]:
    if ledger_name not in {"paper", "paper_baseline", "daily_green_lock"}:
        raise ValueError("unsupported paper ledger")
    paper = (
        ledger_directory(project_root, config, "paper")
        if ledger_name == "paper" and config is not None
        else project_root / "state" / ledger_name
    )
    return paper / "PORTFOLIO.json", paper / "EVENTS.jsonl"


def _timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(UTC)


def _initial_requires_management(
    positions: list[Mapping[str, Any]], refresh: Mapping[str, Any], *, now: datetime
) -> bool:
    """Do not defer a potentially protective action for slow advisory evidence."""

    quotes = _refresh_map(refresh)
    for position in positions:
        deadline = _timestamp(position.get("hold_deadline"))
        if deadline is None or now.astimezone(UTC) >= deadline:
            return True
        quote = quotes.get(str(position.get("contract_identifier") or ""))
        bid = _number(quote.get("bid_price")) if isinstance(quote, Mapping) else None
        ask = _number(quote.get("ask_price")) if isinstance(quote, Mapping) else None
        if (
            quote is None
            or bid is None
            or ask is None
            or bid < 0
            or ask < bid
            or not _fresh(quote.get("updated_at"), now=now, maximum_age_seconds=240)
        ):
            return True
        stop = _number(position.get("stop_price"))
        management = position.get("winner_management")
        trailing_floor = (
            _number(management.get("trailing_floor"))
            if isinstance(management, Mapping) and management.get("enabled") is True
            else None
        )
        if stop is None or bid <= stop or (trailing_floor is not None and bid <= trailing_floor):
            return True
    return False


def _persisted_continuation_evidence(positions: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Let an already fresh checkpoint record survive an unrelated urgent exit."""

    evidence: dict[str, Any] = {}
    for position in positions:
        management = position.get("winner_management")
        value = management.get("last_evidence") if isinstance(management, Mapping) else None
        symbol = str(position.get("symbol") or "").strip().upper()
        if symbol and isinstance(value, Mapping):
            evidence[symbol] = dict(value)
    return evidence


def _monitor_quote_requests(positions: list[Mapping[str, Any]]) -> list[dict[str, str]]:
    """Winner-trial positions cannot use assumed target fills, so skip their history call."""

    requests: list[dict[str, str]] = []
    for position in positions:
        request: dict[str, str] = {
            "option_id": str(position.get("contract_identifier", "")),
            "symbol": str(position.get("symbol", "")),
        }
        management = position.get("winner_management")
        if not (isinstance(management, Mapping) and management.get("enabled") is True):
            request["tp_history_start"] = str(position.get("entry_at") or "")
        requests.append(request)
    return requests


def _with_continuation_evidence(
    refresh: Mapping[str, Any], evidence: Mapping[str, Any]
) -> dict[str, Any]:
    result = dict(refresh)
    if evidence:
        result["continuation_evidence"] = dict(evidence)
    return result


def _merge_monitor_results(first: Mapping[str, Any], second: Mapping[str, Any]) -> dict[str, Any]:
    """Preserve actions committed before the final fresh-quote pass."""

    result = dict(second)
    events = [*first.get("paper_events", []), *second.get("paper_events", [])]
    attention = [*first.get("attention", []), *second.get("attention", [])]
    result["paper_events"] = events
    result["attention"] = attention
    if events:
        result["status"] = "EXITED"
    elif attention:
        result["status"] = "ATTENTION"
    return result


async def _record_winner_advisories(
    result: dict[str, Any],
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime,
    ledger_name: str,
) -> None:
    """Run optional JEV research only after paper exit state is durably handled."""

    if ledger_name != "paper":
        return
    try:
        from tools.winner_advisory import record_checkpoint_advisories

        result["jev_winner_advisories"] = await asyncio.wait_for(
            asyncio.to_thread(
                record_checkpoint_advisories,
                result,
                config,
                project_root=project_root,
                now=now,
            ),
            timeout=5,
        )
    except Exception:
        result["jev_winner_advisories"] = [
            {"status": "UNAVAILABLE", "routing_effect": False, "exit_authority": False}
        ]


async def monitor_paper_portfolio(
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime | None = None,
    quote_fetcher: Callable[..., Awaitable[dict[str, Any]]] | None = None,
    technical_fetcher: TechnicalFetcher | None = None,
    orderbook_collector: OrderbookCollector | None = None,
    ledger_name: str = "paper",
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    blockers = config.paper_blockers()
    if ledger_name == "daily_green_lock" and config.live_execution_enabled:
        blockers.append("daily_green_lock_paper_only")
    if blockers:
        return {
            "status": "BLOCKED",
            "reasons": blockers,
            "paper_events": [],
            "attention": [],
            "open_positions": [],
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    portfolio_path, event_path = _paths(project_root, ledger_name, config)
    state = ensure_paper_portfolio(
        config,
        portfolio_path=portfolio_path,
        event_log_path=event_path,
        now=current,
    )
    requests = _monitor_quote_requests(state["open_positions"])
    if not requests:
        return {
            "status": "QUIET",
            "paper_events": [],
            "attention": [],
            "open_positions": [],
            "portfolio": paper_summary(state),
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    initial_refresh = await (quote_fetcher or fetch_quote_refresh)(requests)
    current = now or datetime.now(UTC)
    first_result: dict[str, Any] | None = None
    positions = [item for item in state["open_positions"] if isinstance(item, Mapping)]
    if _initial_requires_management(positions, initial_refresh, now=current):
        first_result = manage_paper_positions(
            _with_continuation_evidence(
                initial_refresh, _persisted_continuation_evidence(positions)
            ),
            config,
            portfolio_path=portfolio_path,
            event_log_path=event_path,
            now=current,
        )
        positions = [
            item for item in first_result.get("open_positions", []) if isinstance(item, Mapping)
        ]
        if not positions:
            first_result["quote_snapshot_as_of"] = initial_refresh.get("as_of")
            await _record_winner_advisories(
                first_result,
                config,
                project_root=project_root,
                now=current,
                ledger_name=ledger_name,
            )
            return first_result
    evidence_kwargs: dict[str, Any] = {}
    if technical_fetcher is not None:
        evidence_kwargs["technical_fetcher"] = technical_fetcher
    if orderbook_collector is not None:
        evidence_kwargs["orderbook_collector"] = orderbook_collector
    evidence_kwargs["collect_orderbook"] = config.get("ENABLE_LEVEL2") is True
    evidence = await collect_winner_evidence(
        positions,
        _refresh_map(initial_refresh),
        project_root=project_root,
        now=now,
        **evidence_kwargs,
    )
    if evidence:
        requests = _monitor_quote_requests(positions)
        refresh = await (quote_fetcher or fetch_quote_refresh)(requests)
        current = now or datetime.now(UTC)
        result = manage_paper_positions(
            _with_continuation_evidence(refresh, evidence),
            config,
            portfolio_path=portfolio_path,
            event_log_path=event_path,
            now=current,
        )
        if first_result is not None:
            result = _merge_monitor_results(first_result, result)
        result["quote_snapshot_as_of"] = refresh.get("as_of")
    elif first_result is not None:
        result = first_result
        result["quote_snapshot_as_of"] = initial_refresh.get("as_of")
    else:
        result = manage_paper_positions(
            initial_refresh,
            config,
            portfolio_path=portfolio_path,
            event_log_path=event_path,
            now=current,
        )
        result["quote_snapshot_as_of"] = initial_refresh.get("as_of")
    await _record_winner_advisories(
        result,
        config,
        project_root=project_root,
        now=current,
        ledger_name=ledger_name,
    )
    return result


def _qualified_candidates(event: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    discovery = event.get("option_discovery")
    if isinstance(discovery, Mapping) and isinstance(discovery.get("qualified_candidates"), list):
        return [item for item in discovery["qualified_candidates"] if isinstance(item, Mapping)]
    if isinstance(event.get("qualified_candidates"), list):
        return [item for item in event["qualified_candidates"] if isinstance(item, Mapping)]
    return []


def _refresh_map(refresh: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for row in refresh.get("option_quotes", []):
        if not isinstance(row, Mapping):
            continue
        quote = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        contract_id = quote.get("instrument_id")
        if isinstance(contract_id, str):
            result[contract_id] = quote
    return result


async def apply_paper_decision(
    routing: Mapping[str, Any],
    event: Mapping[str, Any],
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime | None = None,
    quote_fetcher: Callable[..., Awaitable[dict[str, Any]]] | None = None,
    ledger_name: str = "paper",
) -> dict[str, Any]:
    if ledger_name == "daily_green_lock" and config.live_execution_enabled:
        return {"status": "BLOCKED", "reasons": ["daily_green_lock_paper_only"], "opened": False}
    route = routing.get("decision") or routing.get("sol")
    if not isinstance(route, Mapping) or route.get("status") != "COMPLETED":
        return {"status": "SKIPPED", "reason": "no_completed_model_decision", "opened": False}
    decision = _model_json(route.get("output"))
    if decision is None:
        return {"status": "BLOCKED", "reasons": ["model_decision_not_json"], "opened": False}
    if decision.get("action") == "EXIT":
        portfolio_path, event_path = _paths(project_root, ledger_name, config)
        state = ensure_paper_portfolio(
            config,
            portfolio_path=portfolio_path,
            event_log_path=event_path,
            now=now,
        )
        paper_id = str(decision.get("paper_id", ""))
        position = next(
            (item for item in state["open_positions"] if item.get("paper_id") == paper_id), None
        )
        if position is None:
            return {
                "status": "BLOCKED",
                "reasons": ["exit_paper_position_not_found"],
                "decision": decision,
                "opened": False,
            }
        current = now or datetime.now(UTC)
        refresh = await (quote_fetcher or fetch_quote_refresh)(
            [
                {
                    "option_id": str(position["contract_identifier"]),
                    "symbol": str(position["symbol"]),
                }
            ]
        )
        quote = _refresh_map(refresh).get(str(position["contract_identifier"]))
        current = now or datetime.now(UTC)
        bid = _number(quote.get("bid_price")) if quote is not None else None
        if quote is None or bid is None:
            return {
                "status": "BLOCKED",
                "reasons": ["fresh_paper_exit_quote_missing"],
                "decision": decision,
                "opened": False,
            }
        result = close_paper_position(
            paper_id,
            bid=bid,
            quote_updated_at=str(quote.get("updated_at", "")),
            reason=f"MODEL_EXIT: {decision.get('reason')}",
            config=config,
            portfolio_path=portfolio_path,
            event_log_path=event_path,
            now=current,
        )
        result["decision"] = decision
        result["opened"] = False
        return result
    if decision.get("action") != "BUY":
        return {
            "status": "RECORDED_NO_ENTRY",
            "reason": f"model_action_{decision.get('action')}",
            "decision": decision,
            "opened": False,
        }
    candidate_id = decision.get("candidate_id")
    candidates = _qualified_candidates(event)
    candidate = next(
        (item for item in candidates if item.get("candidate_id") == candidate_id), None
    )
    if candidate is None:
        return {
            "status": "BLOCKED",
            "reasons": ["buy_candidate_not_in_qualified_set"],
            "decision": decision,
            "opened": False,
        }
    current = now or datetime.now(UTC)
    refresh = await (quote_fetcher or fetch_quote_refresh)(
        [
            {
                "option_id": str(candidate_id),
                "symbol": str(candidate.get("symbol", "")),
            }
        ]
    )
    quote = _refresh_map(refresh).get(str(candidate_id))
    current = now or datetime.now(UTC)
    # Model latency must not carry an expired decision or superseded settings
    # into a paper fill. Existing position exits remain independent of this gate.
    valid_until = decision.get("decision_valid_until")
    if valid_until is not None:
        try:
            expiration = datetime.fromisoformat(str(valid_until).replace("Z", "+00:00"))
            valid = expiration.tzinfo is not None and current < expiration
        except (TypeError, ValueError):
            valid = False
        if not valid:
            return {
                "status": "BLOCKED",
                "reasons": ["paper_decision_expired_or_invalid"],
                "opened": False,
            }
    config_path = project_root / "CONFIG.md"
    if config_path.exists():
        try:
            latest_config = load_config(config_path)
        except (OSError, ValueError):
            latest_config = None
        if latest_config is None or latest_config.values != config.values:
            return {
                "status": "BLOCKED",
                "reasons": ["configuration_changed_before_paper_fill"],
                "opened": False,
            }
    if quote is None:
        return {
            "status": "BLOCKED",
            "reasons": ["fresh_paper_fill_quote_missing"],
            "decision": decision,
            "opened": False,
        }
    refreshed_candidate = annotate_option_styles(
        {
            **candidate,
            "bid": _number(quote.get("bid_price")),
            "ask": _number(quote.get("ask_price")),
            "quote_updated_at": quote.get("updated_at"),
            "quote_is_fresh": _fresh(quote.get("updated_at"), now=current),
            "option_volume": _number(quote.get("volume")),
            "option_open_interest": _number(quote.get("open_interest")),
            "implied_volatility": _number(quote.get("implied_volatility")),
            "delta": _number(quote.get("delta")),
            "gamma": _number(quote.get("gamma")),
            "theta": _number(quote.get("theta")),
            "vega": _number(quote.get("vega")),
            "rho": _number(quote.get("rho")),
            "break_even_price": _number(quote.get("break_even_price")),
            "chance_of_profit_long": _number(quote.get("chance_of_profit_long")),
        },
        config,
    )
    portfolio_path, event_path = _paths(project_root, ledger_name, config)
    gate = evaluate_candidate(refreshed_candidate, config)
    if gate.status != "QUALIFIED":
        return {"status": "BLOCKED", "reasons": list(gate.reasons), "opened": False}
    result = open_paper_position(
        decision,
        refreshed_candidate,
        config,
        portfolio_path=portfolio_path,
        event_log_path=event_path,
        now=current,
    )
    result["decision"] = decision
    result["fill_quote_snapshot_as_of"] = refresh.get("as_of")
    return result


def _fresh(value: Any, *, now: datetime, maximum_age_seconds: int = 180) -> bool:
    if not isinstance(value, str):
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    age = (now.astimezone(UTC) - parsed.astimezone(UTC)).total_seconds()
    return -30 <= age <= maximum_age_seconds
