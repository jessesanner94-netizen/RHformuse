"""Read-only Unusual Whales REST client for deterministic research and dry runs.

The API key is read from ``UW_API_KEY`` and is never accepted as a CLI argument,
included in URLs, or emitted in results. Only explicitly allowlisted GET endpoints
can be called.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE_URL = "https://api.unusualwhales.com"
API_KEY_ENV = "UW_API_KEY"
CLIENT_API_ID = "100001"
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
TICKER = re.compile(r"^[A-Z][A-Z0-9.-]{0,14}$")
ALLOWED_ENDPOINTS = (
    re.compile(r"^/api/option-trades/flow-alerts$"),
    re.compile(r"^/api/screener/option-contracts$"),
    re.compile(r"^/api/market/market-tide$"),
    re.compile(r"^/api/stock/[A-Z][A-Z0-9.-]{0,14}/flow-recent$"),
    re.compile(r"^/api/stock/[A-Z][A-Z0-9.-]{0,14}/spot-exposures/strike$"),
    re.compile(r"^/api/stock/[A-Z][A-Z0-9.-]{0,14}/options-volume$"),
    re.compile(r"^/api/stock/[A-Z][A-Z0-9.-]{0,14}/option-contracts$"),
    re.compile(r"^/api/darkpool/[A-Z][A-Z0-9.-]{0,14}$"),
)


class UnusualWhalesError(RuntimeError):
    """Base error for Unusual Whales client failures."""


class UnusualWhalesConfigurationError(UnusualWhalesError):
    """Raised when safe client configuration is missing or invalid."""


class UnusualWhalesAPIError(UnusualWhalesError):
    """Raised when the remote API does not return a usable response."""


@dataclass(frozen=True)
class UnusualWhalesResult:
    endpoint: str
    status_code: int
    payload: Any
    rate_limit_remaining: str | None = None
    rate_limit_reset: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "endpoint": self.endpoint,
            "status_code": self.status_code,
            "rate_limit_remaining": self.rate_limit_remaining,
            "rate_limit_reset": self.rate_limit_reset,
            "payload": self.payload,
        }


def configuration_status(environ: Mapping[str, str] | None = None) -> dict[str, Any]:
    """Report secret availability without revealing its value."""

    source = os.environ if environ is None else environ
    return {
        "base_url": BASE_URL,
        "api_key_environment_variable": API_KEY_ENV,
        "api_key_configured": bool(source.get(API_KEY_ENV, "").strip()),
        "mode": "READ_ONLY",
        "live_request_performed": False,
    }


def _safe_ticker(value: str) -> str:
    ticker = value.strip().upper()
    if not TICKER.fullmatch(ticker):
        raise ValueError(f"invalid ticker: {value!r}")
    return ticker


def _safe_limit(value: int, *, maximum: int = 500) -> int:
    if isinstance(value, bool) or not 1 <= value <= maximum:
        raise ValueError(f"limit must be between 1 and {maximum}")
    return value


def _normalized_params(params: Mapping[str, Any] | None) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in (params or {}).items():
        if value is None:
            continue
        if isinstance(value, bool):
            normalized[key] = "true" if value else "false"
        elif isinstance(value, (list, tuple)):
            normalized[key] = [
                "true"
                if isinstance(item, bool) and item
                else "false"
                if isinstance(item, bool)
                else item
                for item in value
            ]
        else:
            normalized[key] = value
    return normalized


class UnusualWhalesClient:
    """Small GET-only client with endpoint whitelisting and bounded retries."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        timeout: float = 20.0,
        max_retries: int = 2,
        opener: Callable[..., Any] = urlopen,
        sleeper: Callable[[float], None] = time.sleep,
    ) -> None:
        key = (api_key if api_key is not None else os.environ.get(API_KEY_ENV, "")).strip()
        if not key:
            raise UnusualWhalesConfigurationError(
                f"{API_KEY_ENV} is not configured; do not pass API keys on the command line"
            )
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        if max_retries < 0 or max_retries > 5:
            raise ValueError("max_retries must be between 0 and 5")
        self._api_key = key
        self.timeout = timeout
        self.max_retries = max_retries
        self._opener = opener
        self._sleeper = sleeper

    def _get(self, endpoint: str, params: Mapping[str, Any] | None = None) -> UnusualWhalesResult:
        if not any(pattern.fullmatch(endpoint) for pattern in ALLOWED_ENDPOINTS):
            raise UnusualWhalesConfigurationError(f"endpoint is not allowlisted: {endpoint}")
        query = urlencode(_normalized_params(params), doseq=True)
        url = f"{BASE_URL}{endpoint}" + (f"?{query}" if query else "")
        request = Request(
            url,
            method="GET",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Accept": "application/json",
                "UW-CLIENT-API-ID": CLIENT_API_ID,
            },
        )
        for attempt in range(self.max_retries + 1):
            try:
                with self._opener(request, timeout=self.timeout) as response:
                    raw = response.read().decode("utf-8")
                    payload = json.loads(raw) if raw else {}
                    headers = response.headers
                    return UnusualWhalesResult(
                        endpoint=endpoint,
                        status_code=int(getattr(response, "status", 200)),
                        payload=payload,
                        rate_limit_remaining=headers.get("X-RateLimit-Remaining"),
                        rate_limit_reset=headers.get("X-RateLimit-Reset"),
                    )
            except HTTPError as exc:
                if exc.code in RETRYABLE_STATUS_CODES and attempt < self.max_retries:
                    retry_after = exc.headers.get("Retry-After") if exc.headers else None
                    delay = float(retry_after) if retry_after else float(2**attempt)
                    self._sleeper(min(delay, 30.0))
                    continue
                raise UnusualWhalesAPIError(
                    f"Unusual Whales returned HTTP {exc.code} for {endpoint}"
                ) from exc
            except URLError as exc:
                if attempt < self.max_retries:
                    self._sleeper(float(2**attempt))
                    continue
                raise UnusualWhalesAPIError(
                    f"Unusual Whales request failed for {endpoint}: {exc.reason}"
                ) from exc
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise UnusualWhalesAPIError(
                    f"Unusual Whales returned invalid JSON for {endpoint}"
                ) from exc
        raise AssertionError("retry loop ended unexpectedly")

    def market_tide(self, *, interval_5m: bool = False) -> UnusualWhalesResult:
        return self._get("/api/market/market-tide", {"interval_5m": interval_5m})

    def flow_alerts(
        self,
        *,
        ticker: str | None = None,
        limit: int = 25,
        min_premium: int | None = None,
        is_call: bool | None = None,
        is_put: bool | None = None,
        is_otm: bool | None = None,
        size_greater_oi: bool | None = None,
    ) -> UnusualWhalesResult:
        if is_call is True and is_put is True:
            raise ValueError("is_call and is_put cannot both be true")
        return self._get(
            "/api/option-trades/flow-alerts",
            {
                "ticker_symbol": _safe_ticker(ticker) if ticker else None,
                "limit": _safe_limit(limit),
                "min_premium": min_premium,
                "is_call": is_call,
                "is_put": is_put,
                "is_otm": is_otm,
                "size_greater_oi": size_greater_oi,
            },
        )

    def option_screener(
        self,
        *,
        option_type: str,
        limit: int = 50,
        min_premium: int | None = None,
        is_otm: bool | None = None,
        min_volume_oi_ratio: float | None = None,
    ) -> UnusualWhalesResult:
        normalized_type = option_type.strip().title()
        if normalized_type not in {"Calls", "Puts"}:
            raise ValueError("option_type must be Calls or Puts")
        return self._get(
            "/api/screener/option-contracts",
            {
                "type": normalized_type,
                "limit": _safe_limit(limit),
                "min_premium": min_premium,
                "is_otm": is_otm,
                "min_volume_oi_ratio": min_volume_oi_ratio,
            },
        )

    def ticker_flow(self, ticker: str) -> UnusualWhalesResult:
        return self._get(f"/api/stock/{_safe_ticker(ticker)}/flow-recent")

    def spot_gex_by_strike(self, ticker: str) -> UnusualWhalesResult:
        return self._get(f"/api/stock/{_safe_ticker(ticker)}/spot-exposures/strike")

    def dark_pool(self, ticker: str) -> UnusualWhalesResult:
        return self._get(f"/api/darkpool/{_safe_ticker(ticker)}")

    def options_volume(self, ticker: str) -> UnusualWhalesResult:
        return self._get(f"/api/stock/{_safe_ticker(ticker)}/options-volume")

    def option_contracts(self, ticker: str) -> UnusualWhalesResult:
        return self._get(f"/api/stock/{_safe_ticker(ticker)}/option-contracts")


def _result_for_args(args: argparse.Namespace) -> dict[str, Any]:
    if args.command == "status":
        return configuration_status()
    client = UnusualWhalesClient()
    if args.command == "market-tide":
        result = client.market_tide(interval_5m=args.interval_5m)
    elif args.command == "flow-alerts":
        result = client.flow_alerts(
            ticker=args.ticker,
            limit=args.limit,
            min_premium=args.min_premium,
            is_call=True if args.calls else None,
            is_put=True if args.puts else None,
            is_otm=True if args.otm else None,
            size_greater_oi=True if args.size_greater_oi else None,
        )
    elif args.command == "screener":
        result = client.option_screener(
            option_type=args.option_type,
            limit=args.limit,
            min_premium=args.min_premium,
            is_otm=True if args.otm else None,
            min_volume_oi_ratio=args.min_volume_oi_ratio,
        )
    else:
        method = {
            "ticker-flow": client.ticker_flow,
            "gex": client.spot_gex_by_strike,
            "darkpool": client.dark_pool,
            "options-volume": client.options_volume,
            "option-contracts": client.option_contracts,
        }[args.command]
        result = method(args.ticker)
    return result.as_dict()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("status", help="Check whether UW_API_KEY is configured")

    tide = subparsers.add_parser("market-tide")
    tide.add_argument("--interval-5m", action="store_true")

    alerts = subparsers.add_parser("flow-alerts")
    alerts.add_argument("--ticker")
    alerts.add_argument("--limit", type=int, default=25)
    alerts.add_argument("--min-premium", type=int)
    direction = alerts.add_mutually_exclusive_group()
    direction.add_argument("--calls", action="store_true")
    direction.add_argument("--puts", action="store_true")
    alerts.add_argument("--otm", action="store_true")
    alerts.add_argument("--size-greater-oi", action="store_true")

    screener = subparsers.add_parser("screener")
    screener.add_argument("--option-type", choices=("Calls", "Puts"), required=True)
    screener.add_argument("--limit", type=int, default=50)
    screener.add_argument("--min-premium", type=int)
    screener.add_argument("--otm", action="store_true")
    screener.add_argument("--min-volume-oi-ratio", type=float)

    for name in ("ticker-flow", "gex", "darkpool", "options-volume", "option-contracts"):
        command = subparsers.add_parser(name)
        command.add_argument("ticker")

    args = parser.parse_args()
    print(json.dumps(_result_for_args(args), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
