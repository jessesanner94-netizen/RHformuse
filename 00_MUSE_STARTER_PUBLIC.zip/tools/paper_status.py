"""Initialize and print the persistent paper-trading account summary."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path

from tools.config import load_config
from tools.options_strategy import ledger_directory
from tools.paper_trading import ensure_paper_portfolio, paper_summary


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    args = parser.parse_args(argv)
    project_root = args.project_root.resolve()
    config = load_config(project_root / "CONFIG.md")
    blockers = config.paper_blockers()
    if blockers:
        result = {"status": "BLOCKED", "reasons": blockers}
    else:
        paper_dir = ledger_directory(project_root, config, "paper")
        state = ensure_paper_portfolio(
            config,
            portfolio_path=paper_dir / "PORTFOLIO.json",
            event_log_path=paper_dir / "EVENTS.jsonl",
            now=datetime.now(UTC),
        )
        result = {
            "status": "READY",
            "summary": paper_summary(state),
            "summary_path": str(paper_dir / "SUMMARY.md"),
            "event_log_path": str(paper_dir / "EVENTS.jsonl"),
        }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "READY" else 1


if __name__ == "__main__":
    raise SystemExit(main())
