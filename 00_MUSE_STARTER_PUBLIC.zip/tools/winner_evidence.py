"""Collect bounded, model-free continuation evidence for paper option winners.

This module is deliberately advisory-only.  It does not evaluate JEV, submit
orders, or interpret the free-text thesis recorded when a position was opened.
"""

from __future__ import annotations

import asyncio
import math
from collections.abc import Awaitable, Callable, Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.orderbook import collect_orderbooks
from tools.vibe_snapshot import fetch_vibe_snapshot

EASTERN = ZoneInfo("America/New_York")
TECHNICAL_TIMEOUT_SECONDS = 12.0
OVERALL_TIMEOUT_SECONDS = 15.0

TechnicalFetcher = Callable[..., Mapping[str, Any]]
OrderbookCollector = Callable[..., Awaitable[Mapping[str, Any]]]


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        result = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if result.tzinfo is None:
        return None
    return result.astimezone(UTC)


def _status(value: Any) -> str:
    return str(value or "UNAVAILABLE").strip().upper()


def _direction(value: Any) -> str | None:
    result = _status(value)
    return result if result in {"BULLISH", "BEARISH", "NEUTRAL"} else None


def _expected_direction(option_type: Any) -> str | None:
    kind = _status(option_type)
    return {"CALL": "BULLISH", "PUT": "BEARISH"}.get(kind)


def _quote_bid(
    position: Mapping[str, Any], quotes: Mapping[str, Mapping[str, Any]]
) -> float | None:
    quote = quotes.get(str(position.get("contract_identifier") or ""))
    return _number(quote.get("bid_price")) if isinstance(quote, Mapping) else None


def _eligible_positions(
    positions: Sequence[Mapping[str, Any]], quotes: Mapping[str, Mapping[str, Any]]
) -> dict[str, Mapping[str, Any]]:
    """Select only enabled winners at target or after the persistent checkpoint."""

    selected: dict[str, Mapping[str, Any]] = {}
    for position in positions:
        management = position.get("winner_management")
        if not isinstance(management, Mapping) or management.get("enabled") is not True:
            continue
        symbol = str(position.get("symbol") or "").strip().upper()
        if not symbol or symbol in selected:
            continue
        checkpoint = management.get("checkpoint_reached") is True
        target = _number(position.get("take_profit_price"))
        bid = _quote_bid(position, quotes)
        if checkpoint or (target is not None and bid is not None and bid >= target):
            selected[symbol] = position
    return selected


def _structured_invalidation(position: Mapping[str, Any]) -> dict[str, float] | None:
    """Copy an explicitly stored numeric invalidation; never parse decision prose."""

    for field in ("invalidation_price", "entry_invalidation_price", "invalidation_level"):
        value = _number(position.get(field))
        if value is not None:
            return {"field": field, "value": value}
    return None


def _thesis_context(position: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "original_thesis": position.get("thesis"),
        "original_invalidation": position.get("invalidation"),
        "structured_numeric_invalidation": _structured_invalidation(position),
        "interpretation": "free_text_preserved_not_semantically_verified",
    }


def _unavailable(
    position: Mapping[str, Any],
    *,
    now: datetime,
    reason: str,
    technical: Mapping[str, Any] | None = None,
    orderbook: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    option_type = _status(position.get("option_type")).lower()
    return {
        "status": "UNAVAILABLE",
        "as_of": now.astimezone(UTC).isoformat(),
        "option_type": option_type if option_type in {"call", "put"} else "",
        "reasons": [reason],
        "evidence": {
            "method": "entry_aligned_intraday_continuation_proxy",
            "technical": dict(technical or {}),
            "orderbook": dict(orderbook or _orderbook_unavailable("not_collected")),
            "thesis_context": _thesis_context(position),
        },
    }


def _compact_timeframe(frame: Any) -> dict[str, Any]:
    value = frame if isinstance(frame, Mapping) else {}
    return {
        "status": _status(value.get("status")),
        "trend": _direction(value.get("trend")),
        "trend_score": _number(value.get("trend_score")),
        "change_3_bar_percent": _number(value.get("change_3_bar_percent")),
    }


def _compact_structure(structure: Any) -> dict[str, Any]:
    value = structure if isinstance(structure, Mapping) else {}
    timing = value.get("entry_timing") if isinstance(value.get("entry_timing"), Mapping) else {}
    return {
        "status": _status(value.get("status")),
        "bias": _direction(value.get("bias")),
        "bias_score": _number(value.get("bias_score")),
        "session_date": value.get("session_date"),
        "entry_timing": {
            "status": _status(timing.get("status")),
            "completed_bar_at": timing.get("completed_bar_at"),
            "completed_bar_age_seconds": _number(timing.get("completed_bar_age_seconds")),
        },
    }


def _orderbook_unavailable(reason: str) -> dict[str, Any]:
    return {
        "status": "UNAVAILABLE",
        "reason": reason,
        "kind": "resting_displayed_depth_only",
        "executed_trade_prints": {"status": "UNAVAILABLE"},
        "absorption": {"status": "NOT_ASSERTED", "reason": "resting_depth_is_not_execution"},
        "exit_authority": "none",
    }


def _orderbook_context(summary: Any) -> dict[str, Any]:
    if not isinstance(summary, Mapping) or _status(summary.get("status")) != "OK":
        return _orderbook_unavailable(
            str(summary.get("reason") or summary.get("status") or "missing_summary")
            if isinstance(summary, Mapping)
            else "missing_summary"
        )
    features = summary.get("features") if isinstance(summary.get("features"), Mapping) else {}
    imbalance = _number(features.get("near_imbalance"))
    direction = "NEUTRAL"
    if imbalance is not None:
        direction = "BULLISH" if imbalance > 0 else "BEARISH" if imbalance < 0 else "NEUTRAL"
    return {
        "status": "OBSERVED",
        "updated_at": summary.get("updated_at"),
        "kind": "resting_displayed_depth_only",
        "direction_context": direction,
        "near_imbalance": imbalance,
        "best_bid": features.get("best_bid"),
        "best_ask": features.get("best_ask"),
        "microprice": _number(features.get("microprice")),
        "mid": _number(features.get("mid")),
        "executed_trade_prints": {
            "status": "UNAVAILABLE",
            "reason": "provider_has_resting_depth_only",
        },
        "absorption": {"status": "NOT_ASSERTED", "reason": "resting_depth_is_not_execution"},
        "exit_authority": "none",
    }


def _evaluate_snapshot(
    position: Mapping[str, Any], snapshot: Any, *, now: datetime, orderbook: Mapping[str, Any]
) -> dict[str, Any]:
    if not isinstance(snapshot, Mapping):
        return _unavailable(
            position, now=now, reason="technical_snapshot_invalid", orderbook=orderbook
        )
    symbol = str(position.get("symbol") or "").strip().upper()
    snapshot_symbol = str(snapshot.get("symbol") or "").strip().upper()
    snapshot_at = _timestamp(snapshot.get("as_of"))
    snapshot_age = (now.astimezone(UTC) - snapshot_at).total_seconds() if snapshot_at else None
    frames = snapshot.get("timeframes") if isinstance(snapshot.get("timeframes"), Mapping) else {}
    five = _compact_timeframe(frames.get("5M"))
    fifteen = _compact_timeframe(frames.get("15M"))
    structure = _compact_structure(snapshot.get("intraday_structure"))
    technical = {
        "source": "vibe_intraday_snapshot",
        "snapshot_status": _status(snapshot.get("status")),
        "snapshot_symbol": snapshot_symbol,
        "snapshot_as_of": snapshot.get("as_of"),
        "snapshot_age_seconds": round(snapshot_age, 3) if snapshot_age is not None else None,
        "five_minute": five,
        "fifteen_minute_supporting_only": fifteen,
        "current_session_structure": structure,
    }
    expected = _expected_direction(position.get("option_type"))
    if expected is None:
        return _unavailable(
            position,
            now=now,
            reason="option_type_unrecognized",
            technical=technical,
            orderbook=orderbook,
        )
    if _status(snapshot.get("status")) != "OK":
        return _unavailable(
            position,
            now=now,
            reason="technical_snapshot_unavailable",
            technical=technical,
            orderbook=orderbook,
        )
    if snapshot_symbol != symbol:
        return _unavailable(
            position,
            now=now,
            reason="technical_symbol_mismatch",
            technical=technical,
            orderbook=orderbook,
        )
    if snapshot_age is None or not 0 <= snapshot_age <= 120:
        return _unavailable(
            position,
            now=now,
            reason="technical_snapshot_stale",
            technical=technical,
            orderbook=orderbook,
        )
    timing = structure["entry_timing"]
    current_session = now.astimezone(EASTERN).date().isoformat()
    completed_bar_at = _timestamp(timing.get("completed_bar_at"))
    completed_bar_age = (
        (now.astimezone(UTC) - completed_bar_at).total_seconds()
        if completed_bar_at is not None
        else None
    )
    if five["status"] != "OK" or five["trend"] is None:
        return _unavailable(
            position,
            now=now,
            reason="five_minute_direction_unavailable",
            technical=technical,
            orderbook=orderbook,
        )
    if (
        structure["status"] != "OK"
        or structure["bias"] is None
        or timing["status"] != "OK"
        or structure["session_date"] != current_session
        or completed_bar_age is None
        or not 0 <= completed_bar_age <= 600
    ):
        return _unavailable(
            position,
            now=now,
            reason="current_session_structure_unavailable",
            technical=technical,
            orderbook=orderbook,
        )
    five_direction, structure_direction = five["trend"], structure["bias"]
    opposite = "BEARISH" if expected == "BULLISH" else "BULLISH"
    reasons: list[str] = []
    if five_direction == opposite:
        reasons.append("five_minute_direction_opposes_option")
    if structure_direction == opposite:
        reasons.append("current_session_structure_opposes_option")
    if reasons:
        status = "BROKEN"
    elif five_direction == expected or structure_direction == expected:
        status = "INTACT"
        if five_direction == expected:
            reasons.append("five_minute_direction_aligned")
        if structure_direction == expected:
            reasons.append("current_session_structure_aligned")
        if fifteen["trend"] == expected:
            reasons.append("fifteen_minute_supporting")
        elif fifteen["trend"] == opposite:
            reasons.append("fifteen_minute_opposing_nonveto")
        else:
            reasons.append("fifteen_minute_unavailable_or_neutral_nonveto")
    else:
        return _unavailable(
            position,
            now=now,
            reason="intraday_directions_neutral",
            technical=technical,
            orderbook=orderbook,
        )
    option_type = _status(position.get("option_type")).lower()
    return {
        "status": status,
        "as_of": now.astimezone(UTC).isoformat(),
        "option_type": option_type,
        "reasons": reasons,
        "evidence": {
            "method": "entry_aligned_intraday_continuation_proxy",
            "technical": technical,
            "orderbook": dict(orderbook),
            "thesis_context": _thesis_context(position),
        },
    }


async def _fetch_technical(
    symbol: str, *, project_root: Path, technical_fetcher: TechnicalFetcher
) -> Mapping[str, Any] | None:
    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(
                technical_fetcher,
                symbol,
                project_root=project_root,
                timeout=TECHNICAL_TIMEOUT_SECONDS,
                intraday_only=True,
            ),
            timeout=TECHNICAL_TIMEOUT_SECONDS + 1,
        )
    except (TimeoutError, Exception):
        return None
    return result if isinstance(result, Mapping) else None


async def collect_winner_evidence(
    positions: Sequence[Mapping[str, Any]],
    initial_quotes: Mapping[str, Mapping[str, Any]],
    *,
    project_root: Path,
    now: datetime | None = None,
    technical_fetcher: TechnicalFetcher = fetch_vibe_snapshot,
    orderbook_collector: OrderbookCollector = collect_orderbooks,
    collect_orderbook: bool = True,
) -> dict[str, dict[str, Any]]:
    """Return compact continuation evidence keyed by normalized underlying symbol.

    Collection is limited to persisted winner-trial positions at their target or
    an already active checkpoint.  Technical and displayed-depth calls run in
    parallel and are bounded together; unavailable supporting data never gains
    exit authority on its own.
    """

    selected = _eligible_positions(positions, initial_quotes)
    if not selected:
        return {}
    symbols = list(selected)
    technical_tasks = {
        symbol: asyncio.create_task(
            _fetch_technical(symbol, project_root=project_root, technical_fetcher=technical_fetcher)
        )
        for symbol in symbols
    }

    async def no_books() -> Mapping[str, Any]:
        return {}

    books_task = asyncio.create_task(
        orderbook_collector(
            symbols,
            project_root / "state" / "research" / "orderbook.sqlite3",
            now=now,
        )
        if collect_orderbook
        else no_books()
    )
    all_tasks = [*technical_tasks.values(), books_task]
    try:
        await asyncio.wait_for(
            asyncio.gather(*all_tasks, return_exceptions=True), OVERALL_TIMEOUT_SECONDS
        )
    except TimeoutError:
        for task in all_tasks:
            task.cancel()
        await asyncio.gather(*all_tasks, return_exceptions=True)
    try:
        books_result = (
            books_task.result() if books_task.done() and not books_task.cancelled() else {}
        )
    except Exception:
        books_result = {}
    summaries = (
        books_result.get("summaries", {})
        if isinstance(books_result, Mapping) and isinstance(books_result.get("summaries"), Mapping)
        else {}
    )
    # The provider timestamps are checked at the completed collection time.  A
    # caller-supplied ``now`` remains deterministic for replay/tests.
    evaluation_now = (now or datetime.now(UTC)).astimezone(UTC)
    evidence: dict[str, dict[str, Any]] = {}
    for symbol, position in selected.items():
        task = technical_tasks[symbol]
        snapshot = task.result() if task.done() and not task.cancelled() else None
        book = _orderbook_context(summaries.get(symbol))
        evidence[symbol] = _evaluate_snapshot(
            position, snapshot, now=evaluation_now, orderbook=book
        )
    return evidence
