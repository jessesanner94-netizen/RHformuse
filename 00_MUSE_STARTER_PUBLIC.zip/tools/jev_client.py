"""Bounded TypeSafe JEV HTTP client with strict response validation.

All failures return a sanitized result. The caller must still enforce durable call
budgets and trading gates; this client only limits requests within its own lifetime.
"""

from __future__ import annotations

import json
import math
import os
import re
import time
from collections.abc import Callable, Mapping
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

from tools.jev_config import JevConfig

JEV_ENDPOINT = "https://api.typesafe.ai/v1/systemone"
JEV_MODEL = "jev-latest"
_QUESTION_ID = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
_RETRYABLE_STATUS = {429, 529}


class JevTransport(Protocol):
    def __call__(
        self,
        url: str,
        headers: Mapping[str, str],
        body: bytes,
        timeout_seconds: float,
        max_response_bytes: int,
    ) -> tuple[int, bytes]: ...


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(
        self, request: Request, fp: Any, code: int, msg: str, headers: Any, newurl: str
    ) -> None:
        return None


def _read_bounded(response: Any, maximum: int) -> bytes:
    return response.read(maximum + 1)


def _default_transport(
    url: str,
    headers: Mapping[str, str],
    body: bytes,
    timeout_seconds: float,
    max_response_bytes: int,
) -> tuple[int, bytes]:
    # The endpoint is fixed. Redirects are rejected so credentials cannot leave it.
    request = Request(url, data=body, headers=dict(headers), method="POST")
    opener = build_opener(_NoRedirect())
    try:
        with opener.open(request, timeout=timeout_seconds) as response:
            return int(response.status), _read_bounded(response, max_response_bytes)
    except HTTPError as exc:
        with exc:
            return int(exc.code), _read_bounded(exc, max_response_bytes)


def _environment_key() -> str | None:
    return os.environ.get("TYPESAFE_API_KEY") or os.environ.get("JEV_API_KEY")


def _unit_number(value: Any) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and math.isfinite(value)
        and 0 <= value <= 1
    )


def _validate_question_map(questions: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(questions, Mapping) or not 1 <= len(questions) <= 64:
        raise ValueError("invalid_questions")
    clean: dict[str, dict[str, Any]] = {}
    for question_id, raw in questions.items():
        if not isinstance(question_id, str) or not _QUESTION_ID.fullmatch(question_id):
            raise ValueError("invalid_questions")
        if not isinstance(raw, Mapping):
            raise ValueError("invalid_questions")
        kind = raw.get("type")
        instruction = raw.get("instructions")
        if not isinstance(instruction, str) or not instruction.strip():
            raise ValueError("invalid_questions")
        if kind == "noul":
            if set(raw) not in ({"type", "instructions"}, {"type", "instructions", "criteria"}):
                raise ValueError("invalid_questions")
            criteria = raw.get("criteria")
            if criteria is not None and (
                not isinstance(criteria, Mapping)
                or set(criteria) != {"true", "false"}
                or any(
                    not isinstance(value, str) or not value.strip() for value in criteria.values()
                )
            ):
                raise ValueError("invalid_questions")
        elif kind == "choice":
            criteria = raw.get("criteria")
            if (
                set(raw) != {"type", "instructions", "criteria"}
                or not isinstance(criteria, Mapping)
                or not 2 <= len(criteria) <= 255
                or any(
                    not isinstance(key, str)
                    or not key
                    or not isinstance(value, str)
                    or not value.strip()
                    for key, value in criteria.items()
                )
            ):
                raise ValueError("invalid_questions")
        else:
            raise ValueError("invalid_questions")
        clean[question_id] = dict(raw)
    return clean


def _validate_response(
    payload: Any, questions: Mapping[str, Mapping[str, Any]]
) -> tuple[str, dict[str, dict[str, Any]], dict[str, int]]:
    if not isinstance(payload, dict) or set(payload) != {"model", "answers", "usage"}:
        raise ValueError("invalid_response")
    model = payload["model"]
    answers = payload["answers"]
    usage = payload["usage"]
    if not isinstance(model, str) or not _MODEL_ID.fullmatch(model):
        raise ValueError("invalid_response")
    if not isinstance(answers, dict) or set(answers) != set(questions):
        raise ValueError("invalid_response")
    if not isinstance(usage, dict) or set(usage) != {"input_tokens", "output_tokens"}:
        raise ValueError("invalid_response")
    if any(
        isinstance(value, bool) or not isinstance(value, int) or value < 0
        for value in usage.values()
    ):
        raise ValueError("invalid_response")

    clean: dict[str, dict[str, Any]] = {}
    for question_id, question in questions.items():
        answer = answers[question_id]
        if not isinstance(answer, dict) or answer.get("type") != question["type"]:
            raise ValueError("invalid_response")
        if question["type"] == "noul":
            if set(answer) != {"type", "noul"} or not _unit_number(answer["noul"]):
                raise ValueError("invalid_response")
        else:
            if set(answer) != {"type", "choice", "probabilities", "confidence"}:
                raise ValueError("invalid_response")
            options = set(question["criteria"])
            probabilities = answer["probabilities"]
            if (
                not isinstance(answer["choice"], str)
                or answer["choice"] not in options
                or not isinstance(probabilities, dict)
                or set(probabilities) != options
                or any(not _unit_number(value) for value in probabilities.values())
                or not math.isclose(sum(probabilities.values()), 1.0, rel_tol=0, abs_tol=1e-6)
                or not _unit_number(answer["confidence"])
            ):
                raise ValueError("invalid_response")
            # The API defines choice as the highest-probability option.
            if probabilities[answer["choice"]] < max(probabilities.values()):
                raise ValueError("invalid_response")
        clean[question_id] = answer.copy()
    return model, clean, usage.copy()


@dataclass(frozen=True)
class JevResult:
    status: str
    error_code: str | None = None
    model: str | None = None
    answers: dict[str, dict[str, Any]] = field(default_factory=dict)
    usage: dict[str, int] = field(default_factory=dict)
    attempts: int = 0
    latency_ms: float = 0.0
    request_bytes: int = 0
    response_bytes: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Safe for telemetry; excludes state, question text, key, and error body."""
        return asdict(self)


class JevClient:
    def __init__(
        self,
        config: JevConfig,
        *,
        transport: JevTransport | None = None,
        api_key_provider: Callable[[], str | None] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self.config = config
        self._transport = transport or _default_transport
        self._api_key_provider = api_key_provider or _environment_key
        self._sleep = sleep
        self._monotonic = monotonic
        self._minute_attempts: list[float] = []
        self._day = datetime.now(UTC).date()
        self._day_attempts = 0

    def _has_rate_slot(self) -> bool:
        now = self._monotonic()
        day = datetime.now(UTC).date()
        if day != self._day:
            self._day = day
            self._day_attempts = 0
        self._minute_attempts = [t for t in self._minute_attempts if now - t < 60]
        if (
            len(self._minute_attempts) >= self.config.max_calls_per_minute
            or self._day_attempts >= self.config.max_calls_per_day
        ):
            return False
        self._minute_attempts.append(now)
        self._day_attempts += 1
        return True

    def evaluate(
        self, state: str | dict[str, Any] | list[Any], questions: Mapping[str, Any]
    ) -> JevResult:
        """Evaluate one batch; never places trades or executes model-driven actions."""
        started = self._monotonic()
        attempts = 0
        total_sent = 0
        total_received = 0

        def failed(code: str, status: str = "ERROR") -> JevResult:
            return JevResult(
                status=status,
                error_code=code,
                attempts=attempts,
                latency_ms=max(0.0, (self._monotonic() - started) * 1_000),
                request_bytes=total_sent,
                response_bytes=total_received,
            )

        if not self.config.enabled:
            return failed("jev_disabled", "DISABLED")
        if not isinstance(state, (str, dict, list)):
            return failed("invalid_state")
        try:
            validated_questions = _validate_question_map(questions)
            body = json.dumps(
                {"state": state, "model": JEV_MODEL, "questions": validated_questions},
                allow_nan=False,
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8")
        except (TypeError, ValueError, OverflowError):
            return failed("invalid_request")
        if len(body) > self.config.max_request_bytes:
            return failed("request_too_large")
        try:
            key = self._api_key_provider()
        except Exception:
            return failed("credential_unavailable")
        if (
            not isinstance(key, str)
            or not key
            or any(ord(char) < 33 or ord(char) > 126 for char in key)
        ):
            return failed("credential_unavailable")
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

        for retry in range(self.config.max_retries + 1):
            if not self._has_rate_slot():
                return failed("client_rate_limit")
            attempts += 1
            total_sent += len(body)
            try:
                status, response = self._transport(
                    JEV_ENDPOINT,
                    headers,
                    body,
                    self.config.timeout_seconds,
                    self.config.max_response_bytes,
                )
            except (TimeoutError, ConnectionError, OSError, URLError):
                if retry < self.config.max_retries:
                    self._sleep(self.config.backoff_seconds * 2**retry)
                    continue
                return failed("transport_error")
            except Exception:
                return failed("transport_error")
            if (
                isinstance(status, bool)
                or not isinstance(status, int)
                or not isinstance(response, bytes)
            ):
                return failed("invalid_transport_response")
            total_received += len(response)
            if len(response) > self.config.max_response_bytes:
                return failed("response_too_large")
            if status != 200:
                if (
                    status in _RETRYABLE_STATUS or 500 <= status <= 599
                ) and retry < self.config.max_retries:
                    self._sleep(self.config.backoff_seconds * 2**retry)
                    continue
                return failed(f"http_{status}" if 100 <= status <= 599 else "invalid_http_status")
            try:
                decoded = json.loads(response)
                model, answers, usage = _validate_response(decoded, validated_questions)
            except (UnicodeError, json.JSONDecodeError, ValueError, TypeError):
                return failed("invalid_response")
            return JevResult(
                status="OK",
                model=model,
                answers=answers,
                usage=usage,
                attempts=attempts,
                latency_ms=max(0.0, (self._monotonic() - started) * 1_000),
                request_bytes=total_sent,
                response_bytes=total_received,
            )
        return failed("transport_error")
