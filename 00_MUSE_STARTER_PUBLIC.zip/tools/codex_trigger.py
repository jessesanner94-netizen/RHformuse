"""Invoke one Codex review only when deterministic monitor output requests it."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import tempfile
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

MODEL = "gpt-5.6-sol"
REASONING_EFFORT = "xhigh"


def build_command(
    codex_executable: str,
    project_root: Path,
    *,
    model: str = MODEL,
    reasoning_effort: str = REASONING_EFFORT,
    sandbox: str = "workspace-write",
    output_schema: Path | None = None,
    command_workdir: Path | None = None,
) -> list[str]:
    command = [
        codex_executable,
        "exec",
        "--ephemeral",
        "--model",
        model,
        "--config",
        f'model_reasoning_effort="{reasoning_effort}"',
        "--config",
        "mcp_servers.robinhood.enabled=false",
    ]
    if sandbox == "read-only":
        command.extend(["--sandbox", sandbox])
    else:
        # --approve-for-me already selects the workspace-write sandbox and cannot be
        # combined with the explicit --sandbox flag.
        command.append("--approve-for-me")
    if command_workdir is not None:
        command.append("--skip-git-repo-check")
    command.extend(["--cd", str((command_workdir or project_root).resolve())])
    if output_schema is not None:
        command.extend(["--output-schema", str(output_schema.resolve())])
    command.append("-")
    return command


def run_trigger(
    monitor_result: Mapping[str, Any],
    *,
    project_root: Path,
    execute: bool = False,
    wake_key: str = "wake_codex",
    model: str = MODEL,
    reasoning_effort: str = REASONING_EFFORT,
    prompt_name: str = "TRIGGERED_POSITION_REVIEW.md",
    sandbox: str = "workspace-write",
    output_schema_name: str | None = None,
    isolated_agent: bool = False,
    isolated_policy_name: str = "DECISION_AGENT_AGENTS.md",
    timeout_seconds: float = 180,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> dict[str, Any]:
    if monitor_result.get(wake_key) is not True:
        return {
            "status": "SKIPPED",
            "reason": "monitor_returned_no_trigger",
            "codex_invoked": False,
            "model": None,
        }

    if not execute:
        return {
            "status": "PREVIEW",
            "reason": "trigger_present_but_execute_not_requested",
            "codex_invoked": False,
            "model": model,
            "reasoning_effort": reasoning_effort,
            "triggers": monitor_result.get("triggers", []),
        }

    codex_executable = shutil.which("codex.cmd") or shutil.which("codex")
    if not codex_executable:
        return {
            "status": "ERROR",
            "reason": "codex_cli_not_found",
            "codex_invoked": False,
            "model": model,
        }

    instructions_path = project_root / "prompts" / prompt_name
    if not instructions_path.exists():
        return {
            "status": "ERROR",
            "reason": "trigger_prompt_not_found",
            "codex_invoked": False,
            "model": model,
        }
    output_schema = (
        project_root / "prompts" / output_schema_name if output_schema_name is not None else None
    )
    # API structured outputs exclude conditional allOf/if/then/else. Keep the
    # stricter original schema for local validation of the returned decision.
    if output_schema_name == "watch_decision.schema.json":
        output_schema = project_root / "prompts/watch_decision.transport.schema.json"
    if output_schema is not None and not output_schema.exists():
        return {
            "status": "ERROR",
            "reason": "output_schema_not_found",
            "codex_invoked": False,
            "model": model,
        }
    command_workdir: Path | None = None
    if isolated_agent:
        if isolated_policy_name not in {"DECISION_AGENT_AGENTS.md", "CRYPTO_AGENT_AGENTS.md"}:
            raise ValueError("unknown isolated decision policy")
        compact_policy = project_root / "prompts" / isolated_policy_name
        if not compact_policy.exists():
            return {
                "status": "ERROR",
                "reason": "compact_agent_policy_not_found",
                "codex_invoked": False,
                "model": model,
            }
        suffix = "Crypto" if isolated_policy_name == "CRYPTO_AGENT_AGENTS.md" else ""
        command_workdir = Path(tempfile.gettempdir()) / ("RobinhoodAgenticDecision" + suffix)
        command_workdir.mkdir(parents=True, exist_ok=True)
        (command_workdir / "AGENTS.md").write_text(
            compact_policy.read_text(encoding="utf-8"), encoding="utf-8"
        )
    prompt = (
        instructions_path.read_text(encoding="utf-8")
        + "\n\n## Deterministic monitor result\n\n```json\n"
        + json.dumps(monitor_result, indent=2, sort_keys=True)
        + "\n```\n"
    )
    try:
        completed = runner(
            build_command(
                codex_executable,
                project_root,
                model=model,
                reasoning_effort=reasoning_effort,
                sandbox=sandbox,
                output_schema=output_schema,
                command_workdir=command_workdir,
            ),
            input=prompt,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "status": "ERROR",
            "reason": "codex_decision_timeout",
            "codex_invoked": True,
            "model": model,
            "reasoning_effort": reasoning_effort,
            "timeout_seconds": timeout_seconds,
            "error": str(exc)[-1000:],
        }
    stderr = completed.stderr.strip()
    failure_reason = (
        ("invalid_json_schema" if "invalid_json_schema" in stderr else "codex_cli_failed")
        if completed.returncode
        else None
    )
    if completed.returncode == 0 and output_schema_name == "watch_decision.schema.json":
        from jsonschema import Draft202012Validator, FormatChecker, ValidationError

        local_schema = json.loads(
            (project_root / "prompts/watch_decision.schema.json").read_text(encoding="utf-8")
        )
        try:
            Draft202012Validator(local_schema, format_checker=FormatChecker()).validate(
                json.loads(completed.stdout)
            )
        except (ValueError, ValidationError):
            failure_reason = "invalid_model_output"
    token_match = __import__("re").search(r"tokens used\s+([0-9,]+)", stderr)
    return {
        "status": "ERROR" if failure_reason else "COMPLETED",
        "codex_invoked": True,
        "model": model,
        "reasoning_effort": reasoning_effort,
        "exit_code": completed.returncode,
        "reason": failure_reason,
        "output": completed.stdout.strip(),
        "error": stderr[-12_000:] if completed.returncode else stderr[-2_000:],
        "reported_tokens": int(token_match.group(1).replace(",", "")) if token_match else None,
        "prompt_characters": len(prompt),
        "isolated_agent": isolated_agent,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        payload = {}
    result = run_trigger(payload, project_root=args.project_root, execute=args.execute)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] != "ERROR" else 1


if __name__ == "__main__":
    raise SystemExit(main())
