"""Explicit USD spot universe; never infer pairs or substitute USDT."""

SUPPORTED = ("ETH-USD", "BTC-USD")


def validate_symbol(symbol):
    if symbol not in SUPPORTED:
        raise ValueError("unsupported_crypto_symbol")
    return symbol


def configured_symbols(config):
    raw = config.get("CRYPTO_SYMBOLS", config.get("CRYPTO_SYMBOL", ""))
    symbols = tuple(str(raw).split(","))
    if not symbols or len(set(symbols)) != len(symbols):
        raise ValueError("invalid_crypto_universe")
    return tuple(validate_symbol(s.strip()) for s in symbols)
