"""Parse the user-controlled Markdown configuration without silently applying defaults."""

from __future__ import annotations

import math
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CONFIG_LINE = re.compile(r"^\s*([A-Z][A-Z0-9_]*)\s*:\s*(.*?)\s*$")
OPTIONAL_RISK_LIMITS = frozenset({"MAX_OPEN_POSITIONS", "MAX_PORTFOLIO_PREMIUM_AT_RISK"})
WATCHLIST_SYMBOL = re.compile(r"^[A-Z][A-Z0-9.-]{0,5}$")

SCANNER_REQUIRED_FIELDS = (
    "ALLOW_LONG_CALLS",
    "ALLOW_LONG_PUTS",
    "ALLOW_0DTE",
    "MIN_DTE",
    "MIN_DAY_TRADE_DTE",
    "MIN_SWING_DTE",
    "MAX_DTE",
    "MAX_BID_ASK_SPREAD_PERCENT",
    "MIN_OPTION_VOLUME",
    "MIN_OPTION_OPEN_INTEREST",
    "MIN_UNDERLYING_LIQUIDITY",
    "GREEKS_REQUIRED",
    "DAY_MIN_ABS_DELTA",
    "DAY_MAX_ABS_DELTA",
    "DAY_MAX_THETA_PERCENT_OF_PREMIUM",
    "DAY_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE",
    "SWING_MIN_ABS_DELTA",
    "SWING_MAX_ABS_DELTA",
    "SWING_MAX_THETA_PERCENT_OF_PREMIUM",
    "SWING_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE",
)

RISK_REQUIRED_FIELDS = (
    "STOP_LOSS_PERCENT",
    "ENTRY_EXIT_COST_BUFFER_DOLLARS",
    "MAX_DAILY_LOSS_DOLLARS",
    "MAX_DAILY_LOSS_PERCENT",
    "MAX_OPEN_POSITIONS",
    "MAX_CONTRACTS_PER_POSITION",
    "MAX_NEW_POSITIONS_PER_DAY",
    "MAX_PORTFOLIO_PREMIUM_AT_RISK",
    "MIN_SINGLE_POSITION_PREMIUM_AT_RISK",
    "MAX_SINGLE_POSITION_PREMIUM_AT_RISK",
    "MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT",
    "NO_AVERAGING_DOWN",
    "EARNINGS_HOLD_ALLOWED",
    "EARNINGS_RISK_MULTIPLIER",
    "REQUIRE_EXPLICIT_EARNINGS_HOLD_DECISION",
    "REQUIRE_PROTECTIVE_STOP",
)

POSITION_MANAGEMENT_REQUIRED_FIELDS = (
    "STOP_LOSS_PERCENT",
    "TAKE_PROFIT_PERCENT",
    "TRAILING_EXIT_ENABLED",
    "TRAILING_ACTIVATION_PERCENT",
    "TRAILING_GIVEBACK_PERCENT",
    "DAY_TRADE_EXIT_MINUTES_BEFORE_CLOSE",
    "REQUIRE_PROTECTIVE_STOP",
)

PAPER_REQUIRED_FIELDS = (
    "PAPER_BASELINE_ENABLED",
    "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS",
    "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS",
    "PAPER_TRADING_ENABLED",
    "PAPER_STARTING_CASH",
    "PAPER_FILL_POLICY",
)

LIVE_ORDER_REQUIRED_FIELDS = (
    "LIVE_UNATTENDED_AUTHORIZED",
    "LIVE_ORDER_CONFIRMATION_MODE",
    "AUTOMATIC_ORDER_CANCELLATION_ENABLED",
    "STOP_MANAGEMENT_MODE",
)

AUTOMATION_REQUIRED_FIELDS = (
    "MARKET_HOURS_ONLY_FOR_NEW_ENTRIES",
    "MINUTES_AFTER_OPEN_BEFORE_NEW_ENTRY",
    "MINUTES_BEFORE_CLOSE_NO_NEW_ENTRY",
    "DAY_TRADE_ENTRY_CUTOFF_MINUTES_BEFORE_CLOSE",
    "SWING_ENTRY_CUTOFF_MINUTES_BEFORE_CLOSE",
    "OPEN_POSITION_POLL_SECONDS",
    "NEWS_POLL_SECONDS",
    "NEW_OPPORTUNITY_SCAN_MINUTES",
    "BROAD_NEWS_ENABLED",
    "AGENT_REACH_SOCIAL_ENABLED",
    "NEWS_TRIAGE_MODEL",
    "NEWS_TRIAGE_REASONING_EFFORT",
    "FINAL_DECISION_MODEL",
    "FINAL_DECISION_REASONING_EFFORT",
    "MAX_MODEL_CALLS_PER_DAY",
)

LIVE_REQUIRED_FIELDS = tuple(
    dict.fromkeys(
        (
            *SCANNER_REQUIRED_FIELDS,
            *RISK_REQUIRED_FIELDS,
            *POSITION_MANAGEMENT_REQUIRED_FIELDS,
            *PAPER_REQUIRED_FIELDS,
            *LIVE_ORDER_REQUIRED_FIELDS,
            *AUTOMATION_REQUIRED_FIELDS,
        )
    )
)


class ConfigError(ValueError):
    """Raised when the configuration file is malformed."""


def _parse_scalar(raw: str) -> Any:
    value = raw.strip()
    if not value or value.upper() == "TODO":
        return None
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if (value.startswith('"') and value.endswith('"')) or (
        value.startswith("'") and value.endswith("'")
    ):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        return value


@dataclass(frozen=True)
class TradingConfig:
    """Configuration values plus helpers that preserve unresolved settings."""

    values: Mapping[str, Any]
    source: Path | None = None

    def get(self, name: str, default: Any = None) -> Any:
        return self.values.get(name, default)

    def missing(self, fields: Iterable[str]) -> list[str]:
        return sorted(name for name in fields if self.values.get(name) is None)

    def risk_limit(self, name: str) -> float | None:
        """Only the two optional caps accept UNLIMITED; missing/invalid always fails closed."""
        value = self.get(name)
        if name in OPTIONAL_RISK_LIMITS and value == "UNLIMITED":
            return None
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ConfigError(f"invalid risk limit: {name}")
        limit = float(value)
        if not math.isfinite(limit) or limit <= 0:
            raise ConfigError(f"invalid risk limit: {name}")
        if name == "MAX_OPEN_POSITIONS" and not limit.is_integer():
            raise ConfigError(f"position limit must be an integer: {name}")
        return limit

    @property
    def live_execution_enabled(self) -> bool:
        return self.values.get("LIVE_EXECUTION_ENABLED") is True

    def live_blockers(self) -> list[str]:
        blockers = self.missing(LIVE_REQUIRED_FIELDS)
        for name in OPTIONAL_RISK_LIMITS:
            try:
                self.risk_limit(name)
            except (ConfigError, OverflowError):
                blockers.append(name)
        if not self.live_execution_enabled:
            blockers.append("LIVE_EXECUTION_ENABLED")
        if self.get("LIVE_UNATTENDED_AUTHORIZED") is not True:
            blockers.append("LIVE_UNATTENDED_AUTHORIZED")
        if self.get("LIVE_ORDER_CONFIRMATION_MODE") != "STANDING_UNATTENDED_AUTHORIZATION":
            blockers.append("LIVE_ORDER_CONFIRMATION_MODE")
        if self.get("AUTOMATIC_ORDER_CANCELLATION_ENABLED") is not False:
            blockers.append("AUTOMATIC_ORDER_CANCELLATION_ENABLED")
        if self.get("STOP_MANAGEMENT_MODE") != "SOFTWARE_POLLING":
            blockers.append("STOP_MANAGEMENT_MODE")
        if self.live_execution_enabled and self.paper_trading_enabled:
            blockers.append("PAPER_TRADING_ENABLED")
        return sorted(set(blockers))

    @property
    def paper_trading_enabled(self) -> bool:
        return self.values.get("PAPER_TRADING_ENABLED") is True

    def paper_blockers(self) -> list[str]:
        blockers = self.missing(PAPER_REQUIRED_FIELDS)
        if not self.paper_trading_enabled:
            blockers.append("PAPER_TRADING_ENABLED")
        if self.get("PAPER_FILL_POLICY") != "BUY_AT_ASK_SELL_AT_BID":
            blockers.append("PAPER_FILL_POLICY")
        if not isinstance(self.get("PAPER_BASELINE_ENABLED"), bool):
            blockers.append("PAPER_BASELINE_ENABLED")
        cost_names = (
            "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS",
            "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS",
        )
        costs = [self.get(name) for name in cost_names]
        for name, value in zip(cost_names, costs, strict=True):
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or value < 0
            ):
                blockers.append(name)
        if not any(name in blockers for name in cost_names):
            buffer = self.get("ENTRY_EXIT_COST_BUFFER_DOLLARS")
            if (
                isinstance(buffer, bool)
                or not isinstance(buffer, (int, float))
                or not math.isfinite(buffer)
                or buffer < 2 * sum(costs)
            ):
                blockers.append("ENTRY_EXIT_COST_BUFFER_DOLLARS")
        starting_cash = self.get("PAPER_STARTING_CASH")
        if (
            isinstance(starting_cash, bool)
            or not isinstance(starting_cash, (int, float))
            or starting_cash <= 0
        ):
            blockers.append("PAPER_STARTING_CASH")
        return sorted(set(blockers))

    def options_blockers(self) -> list[str]:
        """The explicit no-Luna route cannot silently fall back to a weaker path."""
        blockers = []
        if not isinstance(self.get("OPTIONS_LUNA_VETO_ENABLED", True), bool):
            blockers.append("OPTIONS_LUNA_VETO_ENABLED")
        if self.get("OPTIONS_LUNA_VETO_ENABLED", True) is False:
            for name in ("OPTIONS_JEV_RANKING_ONLY", "ENABLE_JEV"):
                if self.get(name) is not True:
                    blockers.append(name)
            if self.get("JEV_SHADOW_MODE") is not False:
                blockers.append("JEV_SHADOW_MODE")
            if self.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is not True:
                blockers.append("OPTIONS_DAILY_GREEN_LOCK_ENABLED")
        threshold = self.get("MIN_NET_REWARD_TO_RISK")
        if (
            isinstance(threshold, bool)
            or not isinstance(threshold, (int, float))
            or not math.isfinite(threshold)
            or threshold <= 0
        ):
            blockers.append("MIN_NET_REWARD_TO_RISK")
        from tools.options_strategy import strategy_epoch

        try:
            strategy_epoch(self)
        except ConfigError:
            blockers.append("OPTIONS_STRATEGY_EPOCH")
        return blockers

    def watchlist_symbols(self) -> tuple[str, ...]:
        """Return an explicitly configured, normalized watchlist or fail closed."""

        if self.get("WATCHLIST_ONLY") is not True:
            return ()
        raw = self.get("WATCHLIST_SYMBOLS")
        if not isinstance(raw, str):
            raise ConfigError("WATCHLIST_SYMBOLS is required when WATCHLIST_ONLY is true")
        symbols = tuple(
            dict.fromkeys(item.strip().upper() for item in raw.split(",") if item.strip())
        )
        if not symbols or any(WATCHLIST_SYMBOL.fullmatch(symbol) is None for symbol in symbols):
            raise ConfigError("WATCHLIST_SYMBOLS contains an invalid symbol")
        return symbols

    def monitor_policy(self) -> dict[str, Any]:
        missing = self.missing(POSITION_MANAGEMENT_REQUIRED_FIELDS)
        if missing:
            raise ConfigError(f"position-management settings unresolved: {', '.join(missing)}")
        return {
            "stop_loss_percent": self.get("STOP_LOSS_PERCENT"),
            "take_profit_percent": self.get("TAKE_PROFIT_PERCENT"),
            "trailing_enabled": self.get("TRAILING_EXIT_ENABLED"),
            "trailing_activation_percent": self.get("TRAILING_ACTIVATION_PERCENT"),
            "trailing_giveback_percent": self.get("TRAILING_GIVEBACK_PERCENT"),
            "day_trade_exit_minutes_before_close": self.get("DAY_TRADE_EXIT_MINUTES_BEFORE_CLOSE"),
            "require_protective_order": self.get("REQUIRE_PROTECTIVE_STOP") is True
            and self.get("STOP_MANAGEMENT_MODE") == "BROKER_ORDER",
        }


def parse_config_text(text: str, *, source: Path | None = None) -> TradingConfig:
    values: dict[str, Any] = {}
    for line_number, line in enumerate(text.splitlines(), start=1):
        match = CONFIG_LINE.match(line)
        if not match:
            continue
        name, raw_value = match.groups()
        if name in values:
            raise ConfigError(f"duplicate setting {name!r} on line {line_number}")
        values[name] = _parse_scalar(raw_value)
    if "LIVE_EXECUTION_ENABLED" not in values:
        raise ConfigError("LIVE_EXECUTION_ENABLED is missing")
    return TradingConfig(values=values, source=source)


def load_config(path: str | Path) -> TradingConfig:
    config_path = Path(path)
    return parse_config_text(config_path.read_text(encoding="utf-8"), source=config_path)
