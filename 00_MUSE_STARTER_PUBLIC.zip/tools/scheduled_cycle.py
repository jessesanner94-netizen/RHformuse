"""Run one bounded configured scheduler cycle and invoke models only on changed events."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from functools import partial
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.codex_trigger import run_trigger
from tools.config import TradingConfig, load_config
from tools.decision_context import (
    MAX_PACKET_CHARACTERS,
    build_decision_packet,
    cache_decision,
    cached_decision_blocks,
    model_call_budget_status,
    reserve_model_call,
)
from tools.economic_calendar import economic_context
from tools.event_log import append_cycle_log
from tools.experiment_report import record_cycle_metrics
from tools.jev_config import JevConfig
from tools.jev_pipeline import (
    evaluate_candidate,
    record_execution,
    record_rejections,
    record_routing,
    research_enabled,
)
from tools.live_monitor import run_live_monitor
from tools.live_trading import apply_live_decision, monitor_live_portfolio
from tools.market_calendar import entry_allowed
from tools.market_calendar import market_window as session_window
from tools.market_intelligence import collect_market_intelligence
from tools.market_movers import run_market_mover_discovery
from tools.news_option_discovery import run_news_option_discovery
from tools.option_discovery import run_option_discovery
from tools.options_strategy import entry_locked, strategy_epoch
from tools.paper_experiment import (
    apply_comparison_decisions,
    green_lock_enabled,
    monitor_baseline,
    monitor_green_lock,
)
from tools.paper_experiment import enabled as baseline_enabled
from tools.paper_runner import apply_paper_decision, monitor_paper_portfolio
from tools.portfolio_risk import evaluate_risk, planned_entry_budget
from tools.position_exposure import normalized_symbol, opportunity_held_symbols
from tools.state_manager import guarded_json_update
from tools.watch_state import (
    active_watches,
    evaluate_watch,
    invalidate_watch,
    release_watch,
    resolve_watch,
    save_watch,
    validate_handoff,
)
from tools.watchlist_discovery import run_watchlist_option_discovery
from tools.windows_notify import send_notification

EASTERN = ZoneInfo("America/New_York")
CYCLES = {"positions", "news", "opportunities"}
SCHEDULED_MODEL_SANDBOX = "workspace-write"
COMPACT_MODEL_SANDBOX = "read-only"


def event_account(live: Mapping[str, Any], paper: Mapping[str, Any], config: TradingConfig):
    from tools.decision_context import _account_from_event

    return _account_from_event(
        {"live_portfolio": live, "paper_portfolio": paper},
        live_required=config.live_execution_enabled,
    )


def _discovery_premium_ceiling(account: Mapping[str, Any], config: TradingConfig) -> float:
    try:
        return planned_entry_budget(account, config)["premium_ceiling"]
    except (ValueError, TypeError, KeyError):
        return 0.0


def _paper_entry_capacity_reached(paper: Mapping[str, Any], config: TradingConfig) -> bool:
    account = event_account({}, paper, config)
    return _live_entry_capacity_reached({"portfolio": account, "pending_order_count": 0}, config)


def _live_entry_capacity_reached(live: Mapping[str, Any], config: TradingConfig) -> bool:
    """Check if even the cheapest permitted entry fits; never authorize an actual contract here."""
    pending = live.get("pending_order_count")
    if isinstance(pending, bool) or not isinstance(pending, int) or pending != 0:
        return True
    portfolio = live.get("portfolio")
    if not isinstance(portfolio, Mapping):
        return True
    minimum_entry = {
        "symbol": "CAPACITY_CHECK_ONLY",
        "premium_at_risk": config.get("MIN_SINGLE_POSITION_PREMIUM_AT_RISK"),
        "quantity": 1,
        "holds_through_earnings": False,
        "is_averaging_down": False,
        "protective_stop_planned": True,
    }
    return evaluate_risk(portfolio, minimum_entry, config).status != "ALLOWED"


def market_window(
    cycle: str, config: TradingConfig, *, now: datetime | None = None
) -> tuple[bool, str]:
    return session_window(now or datetime.now(UTC))


def _active_paper_jev_required(config: TradingConfig) -> bool:
    return (
        config.paper_trading_enabled
        and not config.live_execution_enabled
        and config.get("ENABLE_JEV") is True
        and config.get("JEV_SHADOW_MODE") is False
        and config.get("ENABLE_JEV_ESCALATION") is True
    )


def new_entry_window(
    config: TradingConfig,
    *,
    now: datetime | None = None,
    trade_style: str | None = None,
) -> bool:
    default_style = "DAY" if config.get("DAY_ONLY_OPTIONS") is True else "SWING"
    return entry_allowed(
        now or datetime.now(UTC), config, str(trade_style or default_style).upper()
    )


def _merge_option_discoveries(
    uw: Mapping[str, Any],
    movers: Mapping[str, Any],
    *,
    config: TradingConfig,
    now: datetime | None,
) -> dict[str, Any]:
    """Merge broad sources while removing contracts that cannot be entered at this time."""

    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    for source in (movers, uw):
        source_candidates = source.get("qualified_candidates", [])
        if not isinstance(source_candidates, list):
            continue
        for raw in source_candidates:
            if not isinstance(raw, Mapping):
                continue
            candidate_id = str(raw.get("candidate_id", ""))
            if not candidate_id or candidate_id in seen:
                continue
            available_styles = [
                str(style).upper()
                for style in raw.get("eligible_trade_styles", [])
                if str(style).upper() in {"DAY", "SWING"}
                and new_entry_window(config, now=now, trade_style=str(style))
            ]
            if not available_styles:
                continue
            candidate = dict(raw)
            candidate["entry_eligible_trade_styles"] = available_styles
            candidates.append(candidate)
            seen.add(candidate_id)
    changed = uw.get("wake_luna") is True or movers.get("wake_luna") is True
    return {
        "status": "ZERO_QUALIFIED"
        if not candidates
        else ("QUALIFIED_CHANGED" if changed else "UNCHANGED"),
        "wake_luna": changed and bool(candidates),
        "qualified_candidates": candidates,
        "sources": {
            "robinhood_daily_movers": dict(movers),
            "unusual_whales_high_options_volume": dict(uw),
        },
        "orders_placed": 0,
        "orders_cancelled": 0,
    }


def _model_json(output: Any) -> dict[str, Any] | None:
    if not isinstance(output, str):
        return None
    text = output.strip()
    candidates = [text]
    if "{" in text and "}" in text:
        candidates.append(text[text.find("{") : text.rfind("}") + 1])
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, Mapping):
            return dict(parsed)
    return None


def _save_result(project_root: Path, cycle: str, result: Mapping[str, Any]) -> dict[str, Any]:
    target = project_root / "state" / "runtime" / f"latest_{cycle}.json"
    write_result = guarded_json_update(target, result, commit=True)
    write_result.pop("payload", None)
    return write_result


async def _route_luna_then_sol(
    event: Mapping[str, Any],
    *,
    config: TradingConfig,
    project_root: Path,
    execute_models: bool,
    luna_prompt: str,
    sol_prompt: str,
    sol_output_schema_name: str | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    luna = run_trigger(
        event,
        project_root=project_root,
        execute=execute_models,
        wake_key="wake_luna",
        model=str(config.get("NEWS_TRIAGE_MODEL")),
        reasoning_effort=str(config.get("NEWS_TRIAGE_REASONING_EFFORT")),
        prompt_name=luna_prompt,
        sandbox=SCHEDULED_MODEL_SANDBOX,
        output_schema_name="triage.schema.json",
    )
    result: dict[str, Any] = {"luna": luna, "sol": None}
    if luna.get("status") != "COMPLETED":
        return result
    verdict = _model_json(luna.get("output"))
    result["luna_verdict"] = verdict
    escalate = verdict is None or verdict.get("action") == "ESCALATE_SOL"
    if not escalate:
        return result
    decision_event = dict(event)
    symbols = verdict.get("symbols", []) if verdict is not None else []
    existing = _qualified_candidates_from_event(event)
    existing_symbols = {
        str(item.get("symbol", "")).upper() for item in existing if isinstance(item, Mapping)
    }
    missing_symbols = [
        str(symbol).upper()
        for symbol in symbols
        if isinstance(symbol, str) and str(symbol).upper() not in existing_symbols
    ]
    if missing_symbols:
        news_contracts = await run_news_option_discovery(
            missing_symbols,
            config,
            now=now,
        )
        result["news_contract_discovery"] = news_contracts
        option_event = (
            dict(event.get("option_discovery"))
            if isinstance(event.get("option_discovery"), Mapping)
            else {}
        )
        news_candidates = news_contracts.get("qualified_candidates", [])
        merged = [*existing]
        if isinstance(news_candidates, list):
            merged.extend(item for item in news_candidates if isinstance(item, Mapping))
        option_event["qualified_candidates"] = merged
        decision_event["option_discovery"] = option_event
        decision_event["news_contract_discovery"] = news_contracts
    result["decision_event"] = decision_event
    sol_event = {
        "wake_codex": True,
        "triggers": [
            {"code": "LUNA_MATERIAL_EVENT" if verdict is not None else "LUNA_OUTPUT_UNPARSEABLE"}
        ],
        "source_event": decision_event,
        "luna_verdict": verdict,
    }
    result["sol"] = run_trigger(
        sol_event,
        project_root=project_root,
        execute=execute_models,
        model=str(config.get("FINAL_DECISION_MODEL")),
        reasoning_effort=str(config.get("FINAL_DECISION_REASONING_EFFORT")),
        prompt_name=sol_prompt,
        sandbox=SCHEDULED_MODEL_SANDBOX,
        output_schema_name=sol_output_schema_name,
    )
    return result


async def _route_compact_decision(
    event: Mapping[str, Any],
    *,
    config: TradingConfig,
    project_root: Path,
    execute_models: bool,
    now: datetime | None = None,
    defer_shadow: bool = False,
) -> dict[str, Any]:
    result = await _route_compact_decision_impl(
        event,
        config=config,
        project_root=project_root,
        execute_models=execute_models,
        now=now,
    )
    if not defer_shadow:
        await _finish_jev_research(result, project_root=project_root, now=now)
    if research_enabled(config):
        record_rejections(project_root, result.get("python_rejections", []), now=now)
    if (
        _options_luna_veto_enabled(config)
        and config.get("ENABLE_MULTI_WATCH") is True
        and not config.live_execution_enabled
    ):
        path = project_root / "state/research/watches.sqlite3"
        rejected = {str(item.get("candidate_id")) for item in result.get("python_rejections", [])}
        for watch in active_watches(path, now=now):
            if watch["identity"]["candidate_id"] in rejected:
                invalidate_watch(
                    path, watch_id=watch["watch_id"], reason="fresh_python_gate_failed", now=now
                )
    return result


async def _shadow_evaluate(evaluate, book_task, symbol):
    if book_task is not None:
        try:
            books = await book_task
            evaluate.keywords["book_summary"] = books.get("summaries", {}).get(symbol)
        except Exception:
            pass
    return await asyncio.get_running_loop().run_in_executor(None, evaluate)


async def _finish_jev_research(result: dict, *, project_root: Path, now: datetime | None) -> None:
    for pending in result.pop("_jev_pending", []):
        try:
            result["jev_evaluations"].append(await pending)
        except Exception:
            result["jev_evaluations"].append({"status": "UNAVAILABLE", "routing_effect": False})
    record_routing(project_root, result, now=now)


def _handoff_diagnostics(event: Mapping[str, Any], result: Mapping[str, Any]) -> dict:
    """Distinguish preliminary tradability from final Python/model admission."""
    discovery = event.get("option_discovery") or {}
    ids = {
        str(c["candidate_id"])
        for c in discovery.get("qualified_candidates", [])
        if c.get("candidate_id")
    }
    rejected = {
        str(r["candidate_id"]) for r in result.get("python_rejections", []) if r.get("candidate_id")
    }
    suppressed = {
        str(r["candidate_id"])
        for r in result.get("suppressed_candidates", [])
        if r.get("candidate_id")
    }
    reviewed = {
        str(r["candidate_id"]) for r in result.get("jev_evaluations", []) if r.get("candidate_id")
    }
    selected = ((result.get("decision_packet") or {}).get("candidate") or {}).get("candidate_id")
    accounted = rejected | suppressed | reviewed | ({str(selected)} if selected else set())
    reasons: dict[str, int] = {}
    for row in result.get("python_rejections", []):
        for reason in row.get("gate", {}).get("reasons", []):
            reasons[reason] = reasons.get(reason, 0) + 1
    for row in result.get("suppressed_candidates", []):
        reason = str(row.get("reason") or "unspecified_suppression")
        reasons[reason] = reasons.get(reason, 0) + 1
    return {
        "discovery_qualification_scope": "preliminary_contract_checks_only",
        "discovery_candidate_count": len(ids),
        "python_rejected_count": len(ids & rejected),
        "routing_suppressed_count": len(ids & suppressed),
        "jev_evaluated_count": len(ids & reviewed),
        "selected_candidate_id": selected,
        "not_evaluated_or_unexplained_ids": sorted(ids - accounted),
        "block_reasons": reasons,
    }


def _options_jev_ranking_only(config: TradingConfig) -> bool:
    return config.get("OPTIONS_JEV_RANKING_ONLY") is True and (
        config.paper_trading_enabled or config.live_execution_enabled
    )


def _options_luna_veto_enabled(config: TradingConfig) -> bool:
    """Keep legacy model routing unless the explicit deterministic mode is enabled."""

    return config.get("OPTIONS_LUNA_VETO_ENABLED", True) is True


def _deterministic_option_decision(
    candidate: Mapping[str, Any], packet: Mapping[str, Any]
) -> dict[str, Any]:
    """Convert a fully qualified Python/JEV candidate into the executable decision shape.

    This is deliberately narrow: it neither reinterprets direction nor relaxes any
    Python, JEV-selection, event, economics, or final-refresh gate.
    """

    style = str(candidate.get("python_preferred_style") or "DAY").upper()
    earnings = packet.get("earnings_event", {})
    return {
        "action": "BUY",
        "candidate_id": candidate.get("candidate_id"),
        "trade_style": style,
        "hold_deadline": None,
        "thesis": "Deterministic Python-qualified and JEV-ranked option setup.",
        "invalidation": "Configured option premium stop, target, and session deadline.",
        "reason": "DETERMINISTIC_PYTHON_JEV_NO_LUNA_VETO",
        "confidence": None,
        "earnings_event": json.dumps(earnings, sort_keys=True),
        "holds_through_earnings": False,
    }


def _jev_rank(result: Mapping[str, Any]) -> tuple[float, float, float] | None:
    if result.get("status") != "OK":
        return None
    scores = result.get("scores")
    if not isinstance(scores, Mapping):
        return None
    values = []
    for name in ("setup_quality", "entry_timing_quality", "escalate_to_luna"):
        value = scores.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        number = float(value)
        if not math.isfinite(number) or not 0 <= number <= 1:
            return None
        values.append(number)
    return tuple(values)


async def _route_compact_decision_impl(
    event: Mapping[str, Any],
    *,
    config: TradingConfig,
    project_root: Path,
    execute_models: bool,
    now: datetime | None = None,
    packet_builder=None,
    jev_evaluator=None,
    candidate_priority=None,
) -> dict[str, Any]:
    """Build one small Python-grounded packet and make at most one Luna decision."""

    build_packet = packet_builder or build_decision_packet
    evaluate_jev = jev_evaluator or evaluate_candidate
    cache_path = project_root / "state" / "runtime" / "decision_cache.json"
    excluded_candidate_ids: set[str] = set()
    suppressed_candidates: list[dict[str, Any]] = []
    collected_rejections: dict[str, Any] = {}
    evaluated_attempts = 0
    jev_evaluations: list[dict[str, Any]] = []
    pending_evaluations: list[Any] = []
    jev_result: dict[str, Any] = {}
    jev_suppression_reason: str | None = None
    from tools.options_jev_trial import TRIAL_ID, active, sample, slot

    sampled = False
    watch_claim: dict[str, Any] = {}
    model_veto_enabled = _options_luna_veto_enabled(config)
    if config.options_blockers():
        return {
            "decision": {
                "status": "SKIPPED",
                "reason": "deterministic_options_configuration_blocked",
                "codex_invoked": False,
            },
            "blockers": config.options_blockers(),
            "decision_packet": None,
        }
    multi_watch = (
        model_veto_enabled
        and config.get("ENABLE_MULTI_WATCH") is True
        and not config.live_execution_enabled
    )
    ranking_only = _options_jev_ranking_only(config)
    ranking_summary: dict[str, Any] | None = None
    watch_path = project_root / "state" / "research" / "watches.sqlite3"
    if multi_watch:
        active_watches(watch_path, now=now)
    built: dict[str, Any] = {}
    cache_gate: dict[str, Any] = {"blocked": False, "reason": "not_checked"}
    ranked_candidates: list[dict[str, Any]] = []
    if ranking_only:
        try:
            held_symbols = opportunity_held_symbols(
                event, live_required=config.live_execution_enabled
            )
            exposure_error = None
        except ValueError as exc:
            held_symbols = set()
            exposure_error = str(exc)
        for order in range(3):
            candidate_built = await build_packet(
                event,
                config,
                project_root=project_root,
                now=now,
                excluded_candidate_ids=excluded_candidate_ids,
            )
            built = candidate_built
            evaluated_attempts += int(candidate_built.get("candidates_evaluated", 0))
            for rejection in candidate_built.get("python_rejections", []):
                collected_rejections[str(rejection.get("candidate_id"))] = rejection
            selected_for_gate = candidate_built.get("selected_candidates")
            if (
                candidate_built.get("status") != "READY"
                or not isinstance(selected_for_gate, list)
                or not selected_for_gate
            ):
                break
            gate_candidate = selected_for_gate[0]
            candidate_id = str(gate_candidate.get("candidate_id") or "")
            excluded_candidate_ids.add(candidate_id)
            if exposure_error or normalized_symbol(gate_candidate.get("symbol")) in held_symbols:
                suppressed_candidates.append(
                    {
                        "candidate_id": candidate_id,
                        "reason": exposure_error or "underlying_already_held",
                    }
                )
                continue

            compact_candidate = candidate_built["packet"]["candidate"]
            observations = {
                "underlying_price": compact_candidate.get("underlying_price"),
                "spread_percent": compact_candidate.get("spread_percent"),
                "python_qualified": True,
            }
            candidate_built["packet"]["watch_observations"] = observations
            candidate_watch: dict[str, Any] = {}
            if multi_watch and execute_models:
                try:
                    candidate_watch = evaluate_watch(
                        watch_path,
                        candidate={
                            **compact_candidate,
                            "trade_style": gate_candidate.get("watch_trade_style")
                            or compact_candidate.get("python_preferred_style"),
                        },
                        observations=observations,
                        observed_at=gate_candidate.get("underlying_quote_updated_at") or "",
                        now=now,
                    )
                except Exception:
                    candidate_watch = {"status": "UNAVAILABLE"}
                if candidate_watch.get("status") == "READY":
                    prior = candidate_watch.get("decision", {})
                    candidate_built["packet"]["previous_watch_thesis"] = {
                        "thesis": str(prior.get("thesis", ""))[:500],
                        "reason": str(prior.get("reason", ""))[:250],
                        "watch_conditions": prior.get("watch_conditions"),
                    }
                elif candidate_watch.get("status") not in {"NO_WATCH", "RESOLVED"}:
                    suppressed_candidates.append(
                        {
                            "candidate_id": candidate_id,
                            "reason": "watch_" + str(candidate_watch.get("status")).lower(),
                        }
                    )
                    continue

            candidate_cache = {"blocked": False, "reason": "watch_wake_claimed"}
            if model_veto_enabled and candidate_watch.get("status") != "READY":
                candidate_cache = cached_decision_blocks(
                    cache_path,
                    packet_signature=str(candidate_built.get("packet_signature") or ""),
                    candidate=gate_candidate,
                    packet=candidate_built.get("packet")
                    if isinstance(candidate_built.get("packet"), Mapping)
                    else None,
                    now=now,
                )
                if candidate_cache.get("blocked") is True and not (
                    candidate_cache.get("reason") == "valid_buy_cached"
                    and isinstance(candidate_cache.get("decision"), Mapping)
                ):
                    suppressed_candidates.append(
                        {
                            "candidate_id": candidate_id,
                            "symbol": gate_candidate.get("symbol"),
                            "reason": candidate_cache.get("reason"),
                        }
                    )
                    continue

            candidate_jev: dict[str, Any] = {}
            if research_enabled(config) and candidate_cache.get("blocked") is not True:
                remaining = (
                    model_call_budget_status(
                        project_root / "state" / "runtime" / "model_budget.json",
                        maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
                        now=now,
                    ).get("calls_remaining", 0)
                    if model_veto_enabled
                    else 0
                )
                books = event.get("orderbooks", {}).get("summaries", {})
                try:
                    candidate_jev = await asyncio.to_thread(
                        partial(
                            evaluate_jev,
                            json.loads(json.dumps(candidate_built["packet"])),
                            config,
                            project_root=project_root,
                            now=now,
                            calls_remaining=remaining,
                            book_summary=books.get(str(gate_candidate.get("symbol"))),
                        )
                    )
                except Exception:
                    candidate_jev = {
                        "status": "UNAVAILABLE",
                        "error_code": "jev_research_failure",
                        "routing_effect": False,
                    }
                jev_evaluations.append(candidate_jev)
            ranked_candidates.append(
                {
                    "order": order,
                    "built": candidate_built,
                    "candidate": gate_candidate,
                    "watch": candidate_watch,
                    "cache": candidate_cache,
                    "jev": candidate_jev,
                    "rank": _jev_rank(candidate_jev),
                }
            )
            if candidate_watch.get("status") == "READY":
                break

        if ranked_candidates:
            ready = [item for item in ranked_candidates if item["watch"].get("status") == "READY"]
            cached = [
                item
                for item in ranked_candidates
                if item["cache"].get("reason") == "valid_buy_cached"
            ]
            pool = ready or cached or ranked_candidates
            scored = [item for item in pool if item["rank"] is not None]
            # Live-ready deterministic selection requires successful JEV evidence;
            # there is no Python-only substitution when any ranking call fails.
            if not model_veto_enabled and len(scored) != len(pool):
                return {
                    "decision": {
                        "status": "SKIPPED",
                        "reason": "jev_ranking_unavailable",
                        "codex_invoked": False,
                    },
                    "decision_packet": None,
                    "jev_evaluations": jev_evaluations,
                    "python_rejections": list(collected_rejections.values()),
                    "suppressed_candidates": suppressed_candidates,
                }
            priority_values = {}
            if candidate_priority is not None:
                try:
                    for item in pool:
                        priority = candidate_priority(item["candidate"])
                        if isinstance(priority, bool) or not isinstance(priority, int):
                            raise ValueError("candidate priority must be an integer")
                        priority_values[str(item["candidate"].get("candidate_id"))] = priority
                except Exception:
                    return {
                        "decision": {
                            "status": "SKIPPED",
                            "codex_invoked": False,
                            "reason": "candidate_priority_unavailable",
                        },
                        "decision_packet": None,
                        "jev_evaluations": jev_evaluations,
                        "python_rejections": list(collected_rejections.values()),
                        "suppressed_candidates": suppressed_candidates,
                    }
            chosen = (
                max(
                    scored,
                    key=lambda item: (
                        priority_values.get(str(item["candidate"].get("candidate_id")), 0),
                        *item["rank"],
                        -item["order"],
                    ),
                )
                if len(scored) == len(pool)
                else min(pool, key=lambda item: item["order"])
            )
            for item in ranked_candidates:
                claim = item["watch"]
                if item is not chosen and claim.get("status") == "READY":
                    release_watch(
                        watch_path,
                        watch_id=claim["watch_id"],
                        claim_token=claim["claim_token"],
                        model_call_started=False,
                        now=now,
                    )
                if item is not chosen:
                    suppressed_candidates.append(
                        {
                            "candidate_id": item["candidate"].get("candidate_id"),
                            "reason": "candidate_priority_then_jev_ranked_lower"
                            if candidate_priority is not None
                            else "jev_ranked_lower",
                            "selected_candidate_id": chosen["candidate"].get("candidate_id"),
                        }
                    )
            built = chosen["built"]
            watch_claim = chosen["watch"]
            cache_gate = chosen["cache"]
            jev_result = chosen["jev"]
            ranking_summary = {
                "mode": "RANKING_ONLY",
                "candidate_ids": [
                    item["candidate"].get("candidate_id") for item in ranked_candidates
                ],
                "selected_candidate_id": chosen["candidate"].get("candidate_id"),
                "selected_watch_ready": watch_claim.get("status") == "READY",
                "valid_score_count": len([item for item in ranked_candidates if item["rank"]]),
                "fallback_used": len(scored) != len(pool),
            }
            if candidate_priority is not None:
                ranking_summary.update(
                    mode="CANDIDATE_PRIORITY_THEN_JEV", candidate_priority=priority_values
                )
        else:
            built = {"status": "NO_CANDIDATE", "packet": None, "selected_candidates": []}
    for _ in range(0 if ranking_only else 3):
        built = await build_packet(
            event,
            config,
            project_root=project_root,
            now=now,
            excluded_candidate_ids=excluded_candidate_ids,
        )
        evaluated_attempts += int(built.get("candidates_evaluated", 0))
        for rejection in built.get("python_rejections", []):
            collected_rejections[str(rejection.get("candidate_id"))] = rejection
        selected_for_gate = built.get("selected_candidates")
        if (
            built.get("status") != "READY"
            or not isinstance(selected_for_gate, list)
            or not selected_for_gate
        ):
            break
        gate_candidate = selected_for_gate[0]
        sampled = False
        jev_result = {}
        if research_enabled(config):
            remaining = model_call_budget_status(
                project_root / "state" / "runtime" / "model_budget.json",
                maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
                now=now,
            ).get("calls_remaining", 0)
            books = event.get("orderbooks", {}).get("summaries", {})
            evaluate = partial(
                evaluate_jev,
                json.loads(json.dumps(built["packet"])),
                config,
                project_root=project_root,
                now=now,
                calls_remaining=remaining,
                book_summary=books.get(str(gate_candidate.get("symbol"))),
            )
            if JevConfig.from_config(config).shadow_mode:
                pending_evaluations.append(
                    asyncio.create_task(
                        _shadow_evaluate(
                            evaluate,
                            event.get("_orderbook_pending"),
                            str(gate_candidate.get("symbol")),
                        )
                    )
                )
            else:
                jev_result = await asyncio.to_thread(evaluate)
                jev_evaluations.append(jev_result)
        if multi_watch:
            compact_candidate = built["packet"]["candidate"]
            observations = {
                "underlying_price": compact_candidate.get("underlying_price"),
                "spread_percent": compact_candidate.get("spread_percent"),
                "python_qualified": True,
            }
            if jev_result.get("routing_effect") is True:
                observations["jev"] = jev_result.get("scores", {})
            built["packet"]["watch_observations"] = observations
            if execute_models:
                try:
                    watch_claim = evaluate_watch(
                        watch_path,
                        candidate={
                            **compact_candidate,
                            "trade_style": gate_candidate.get("watch_trade_style")
                            or compact_candidate.get("python_preferred_style"),
                        },
                        observations=observations,
                        observed_at=gate_candidate.get("underlying_quote_updated_at") or "",
                        now=now,
                    )
                except Exception:
                    watch_claim = {"status": "UNAVAILABLE"}
                if watch_claim.get("status") == "READY":
                    prior = watch_claim.get("decision", {})
                    built["packet"]["previous_watch_thesis"] = {
                        "thesis": str(prior.get("thesis", ""))[:500],
                        "reason": str(prior.get("reason", ""))[:250],
                        "watch_conditions": prior.get("watch_conditions"),
                    }
                    cache_gate = {"blocked": False, "reason": "watch_wake_claimed"}
                if watch_claim.get("status") not in {"NO_WATCH", "RESOLVED", "READY"}:
                    candidate_id = str(gate_candidate.get("candidate_id") or "")
                    cache_gate = {
                        "blocked": True,
                        "reason": "watch_" + str(watch_claim.get("status")).lower(),
                    }
                    suppressed_candidates.append(
                        {"candidate_id": candidate_id, "reason": cache_gate["reason"]}
                    )
                    excluded_candidate_ids.add(candidate_id)
                    continue
        if _active_paper_jev_required(config):
            policy = jev_result.get("policy")
            qualified_jev = (
                jev_result.get("status") == "OK"
                and jev_result.get("routing_effect") is True
                and isinstance(policy, Mapping)
                and policy.get("would_escalate") is True
            )
            if not qualified_jev:
                sampled = sample(config, built["packet"], jev_result, project_root, now)
            if not qualified_jev and not sampled:
                jev_suppression_reason = (
                    "jev_escalation_filtered"
                    if jev_result.get("status") == "OK"
                    and jev_result.get("routing_effect") is True
                    and isinstance(policy, Mapping)
                    and policy.get("would_escalate") is False
                    else "jev_active_unavailable"
                )
                if watch_claim.get("status") == "READY":
                    release_watch(
                        watch_path,
                        watch_id=watch_claim["watch_id"],
                        claim_token=watch_claim["claim_token"],
                        model_call_started=False,
                        now=now,
                    )
                candidate_id = str(gate_candidate.get("candidate_id") or "")
                suppressed_candidates.append(
                    {
                        "candidate_id": candidate_id,
                        "reason": jev_suppression_reason,
                        "watch_status": watch_claim.get("status"),
                    }
                )
                excluded_candidate_ids.add(candidate_id)
                cache_gate = {"blocked": True, "reason": jev_suppression_reason}
                continue
        if watch_claim.get("status") == "READY":
            cache_gate = {"blocked": False, "reason": "watch_wake_claimed"}
            break
        cache_gate = cached_decision_blocks(
            cache_path,
            packet_signature=str(built.get("packet_signature") or ""),
            candidate=gate_candidate,
            packet=built.get("packet") if isinstance(built.get("packet"), Mapping) else None,
            now=now,
        )
        if cache_gate.get("blocked") is True and str(cache_gate.get("reason")) in {
            "material_pass_state_unchanged",
            "unchanged_pass_cached",
        }:
            candidate_id = str(gate_candidate.get("candidate_id") or "")
            suppressed_candidates.append(
                {
                    "candidate_id": candidate_id,
                    "symbol": gate_candidate.get("symbol"),
                    "reason": cache_gate.get("reason"),
                }
            )
            excluded_candidate_ids.add(candidate_id)
            continue
        break
    result: dict[str, Any] = {
        "decision": None,
        "decision_packet": built.get("packet"),
        "packet_status": built.get("status"),
        "python_rejections": list(collected_rejections.values()),
        "candidates_evaluated": evaluated_attempts,
        "suppressed_candidates": suppressed_candidates,
        "jev_evaluations": jev_evaluations,
        "_jev_pending": pending_evaluations,
        "watch": {key: value for key, value in watch_claim.items() if key != "claim_token"},
    }
    result["handoff_diagnostics"] = _handoff_diagnostics(event, result)
    if ranking_summary is not None:
        result["jev_ranking"] = ranking_summary
    selected = built.get("selected_candidates")
    if built.get("status") != "READY" or not isinstance(selected, list) or not selected:
        result["decision"] = {
            "status": "SKIPPED",
            "reason": jev_suppression_reason
            or (
                "candidates_rejected_or_suppressed"
                if collected_rejections or suppressed_candidates
                else "compact_packet_not_ready"
            ),
            "codex_invoked": False,
        }
        return result
    candidate = selected[0]
    try:
        held_symbols = opportunity_held_symbols(event, live_required=config.live_execution_enabled)
        held_candidate = normalized_symbol(candidate.get("symbol")) in held_symbols
        exposure_block = "underlying_already_held" if held_candidate else None
    except ValueError as exc:
        exposure_block = str(exc)
    if exposure_block:
        if watch_claim.get("status") == "READY":
            release_watch(
                watch_path,
                watch_id=watch_claim["watch_id"],
                claim_token=watch_claim["claim_token"],
                model_call_started=False,
                now=now,
            )
        # Final fence before cached BUY reuse or a model-budget reservation.
        result["decision_packet"] = None
        result["decision"] = {
            "status": "SKIPPED",
            "reason": exposure_block,
            "codex_invoked": False,
        }
        return result
    if not model_veto_enabled:
        result["cache_gate"] = {"blocked": False, "reason": "luna_veto_disabled"}
        if not execute_models:
            result["decision"] = {
                "status": "PREVIEW",
                "reason": "deterministic_candidate_ready_but_execute_not_requested",
                "codex_invoked": False,
                "model_bypassed": True,
            }
            return result
        deterministic = _deterministic_option_decision(candidate, built["packet"])
        deterministic["decision_valid_until"] = (
            (now or datetime.now(UTC)) + timedelta(seconds=240)
        ).isoformat()
        result["decision_verdict"] = deterministic
        result["decision"] = {
            "status": "COMPLETED",
            "reason": "python_jev_no_luna_veto",
            "output": json.dumps(deterministic, separators=(",", ":")),
            "codex_invoked": False,
            "model_bypassed": True,
        }
        return result
    packet_signature = str(built.get("packet_signature") or "")
    result["cache_gate"] = cache_gate
    if cache_gate.get("blocked") is True:
        cached = cache_gate.get("decision")
        if (
            not sampled
            and cache_gate.get("reason") == "valid_buy_cached"
            and isinstance(cached, Mapping)
        ):
            cached_decision = dict(cached)
            result["decision_verdict"] = cached_decision
            result["decision"] = {
                "status": "COMPLETED",
                "reason": "valid_buy_cached",
                "output": json.dumps(cached_decision, separators=(",", ":")),
                "codex_invoked": False,
                "cached": True,
            }
            return result
        result["decision"] = {
            "status": "SKIPPED",
            "reason": str(cache_gate.get("reason")),
            "codex_invoked": False,
            "cached_decision": cache_gate.get("decision"),
        }
        return result
    if not execute_models:
        result["decision"] = {
            "status": "PREVIEW",
            "reason": "compact_packet_ready_but_execute_not_requested",
            "codex_invoked": False,
            "model": str(config.get("FINAL_DECISION_MODEL")),
        }
        return result
    if multi_watch:
        built["packet"]["watch_limits"] = {
            "maximum_duration_minutes": 60,
            "latest_expires_at": ((now or datetime.now(UTC)) + timedelta(minutes=60)).isoformat(),
        }
    if ranking_only:
        built["packet"].pop("jev_context", None)
        built["packet"].get("watch_observations", {}).pop("jev", None)
    elif active(config, now):
        built["packet"].pop("jev_context", None)
        built["packet"].pop("previous_watch_thesis", None)
        built["packet"].get("watch_observations", {}).pop("jev", None)
    elif jev_result.get("routing_effect") is True:
        # Shadow scores never enter the model packet or its legacy cache signature.
        built["packet"]["jev_context"] = {
            key: jev_result.get(key)
            for key in (
                "scores",
                "question_versions",
                "recent_scores",
                "score_delta",
                "policy",
                "orderbook_context",
            )
        }
        built["packet"]["jev_context"]["interpretation"] = "uncalibrated_model_scores"
        built["packet"]["jev_context"]["calls_remaining"] = model_call_budget_status(
            project_root / "state/runtime/model_budget.json",
            maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
            now=now,
        ).get("calls_remaining", 0)
        if len(json.dumps(built["packet"])) > MAX_PACKET_CHARACTERS:
            built["packet"]["jev_context"].pop("orderbook_context", None)
            built["packet"]["jev_context"]["recent_scores"] = []
    if len(json.dumps(built["packet"])) > MAX_PACKET_CHARACTERS:
        if watch_claim.get("status") == "READY":
            release_watch(
                watch_path,
                watch_id=watch_claim["watch_id"],
                claim_token=watch_claim["claim_token"],
                model_call_started=False,
                now=now,
            )
        result["decision"] = {
            "status": "SKIPPED",
            "reason": "optional_context_packet_limit",
            "codex_invoked": False,
        }
        return result
    budget = reserve_model_call(
        project_root / "state" / "runtime" / "model_budget.json",
        maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
        now=now,
        packet_signature=packet_signature,
    )
    result["model_budget"] = budget
    if budget.get("status") != "RESERVED":
        if watch_claim.get("status") == "READY":
            release_watch(
                watch_path,
                watch_id=watch_claim["watch_id"],
                claim_token=watch_claim["claim_token"],
                model_call_started=False,
                now=now,
            )
        result["decision"] = {
            "status": "BUDGET_BLOCKED",
            "reason": budget.get("reason"),
            "codex_invoked": False,
        }
        return result
    if sampled:
        if not sample(config, built["packet"], jev_result, project_root, now, reserve=True):
            if watch_claim.get("status") == "READY":
                release_watch(
                    watch_path,
                    watch_id=watch_claim["watch_id"],
                    claim_token=watch_claim["claim_token"],
                    model_call_started=False,
                    now=now,
                )
            result["decision"] = {
                "status": "SKIPPED",
                "reason": "trial_slot_unavailable",
                "codex_invoked": False,
            }
            return result
        result["options_jev_trial"] = {
            "trial_id": TRIAL_ID,
            "slot": slot(now),
            "observation_id": jev_result.get("observation_id"),
        }
    decision_event = {
        "wake_decision": True,
        "decision_packet": built["packet"],
    }
    decision = run_trigger(
        decision_event,
        project_root=project_root,
        execute=True,
        wake_key="wake_decision",
        model=str(config.get("FINAL_DECISION_MODEL")),
        reasoning_effort=str(config.get("FINAL_DECISION_REASONING_EFFORT")),
        prompt_name="COMPACT_WATCH_DECISION.md" if multi_watch else "COMPACT_DECISION.md",
        sandbox=COMPACT_MODEL_SANDBOX,
        output_schema_name=(
            "watch_decision.schema.json"
            if multi_watch
            else "trade_decision.schema.json"
            if config.live_execution_enabled
            else "paper_decision.schema.json"
        ),
        isolated_agent=True,
    )
    result["decision"] = decision
    parsed = _model_json(decision.get("output")) if decision.get("status") == "COMPLETED" else None
    if watch_claim.get("status") == "READY":
        action = str((parsed or {}).get("action") or "ERROR")
        resolve_watch(
            watch_path,
            watch_id=watch_claim["watch_id"],
            claim_token=watch_claim["claim_token"],
            now=now,
            outcome=action if action in {"BUY", "PASS", "WATCH", "WAIT"} else "ERROR",
        )
    if decision.get("status") == "COMPLETED":
        parsed = _model_json(decision.get("output"))
        if parsed is not None:
            if (
                str(parsed.get("action", "")).upper() in {"PASS", "WAIT", "NO_TRADE"}
                and not str(parsed.get("candidate_id", "")).strip()
            ):
                parsed["candidate_id"] = candidate.get("candidate_id")
            result["decision_verdict"] = parsed
            if multi_watch and parsed.get("action") == "WATCH":
                try:
                    compact = built["packet"]["candidate"]
                    if parsed.get("trade_style") not in compact.get("eligible_styles", []):
                        raise ValueError("watch style ineligible")
                    from tools.watch_state import bound_watch_expiration

                    proposed_expiry = (parsed.get("watch_conditions") or {}).get("expires_at")
                    parsed = bound_watch_expiration(
                        parsed,
                        now=now or datetime.now(UTC),
                        deadline=datetime.fromisoformat(
                            built["packet"]["watch_limits"]["latest_expires_at"]
                        ),
                    )
                    result["decision_verdict"] = parsed
                    result["watch_expiration_adjustment"] = {
                        "proposed": proposed_expiry,
                        "effective": parsed["watch_conditions"]["expires_at"],
                    }
                    validate_handoff(parsed, built["packet"]["watch_observations"], now=now)
                    result["watch_saved"] = save_watch(
                        watch_path,
                        candidate={**compact, "trade_style": parsed["trade_style"]},
                        decision=parsed,
                        now=now,
                    )
                except ValueError as exc:
                    result["watch_saved"] = {"status": "REJECTED", "reason": str(exc)[:160]}
                except Exception:
                    result["watch_saved"] = {"status": "REJECTED", "reason": "watch_storage_error"}
                if result["watch_saved"].get("status") not in {"SAVED", "REPLACED"}:
                    cache_decision(
                        cache_path,
                        {**parsed, "action": "PASS"},
                        packet_signature=packet_signature,
                        candidate=candidate,
                        packet=built["packet"],
                        now=now,
                    )
                return result
            result["decision_cache"] = cache_decision(
                cache_path,
                parsed,
                packet_signature=packet_signature,
                candidate=candidate,
                packet=built.get("packet") if isinstance(built.get("packet"), Mapping) else None,
                now=now,
            )
    return result


def _route_compact_position(
    live_monitor: Mapping[str, Any],
    *,
    config: TradingConfig,
    project_root: Path,
    execute_models: bool,
    now: datetime | None,
) -> dict[str, Any]:
    if not _options_luna_veto_enabled(config):
        return {
            "status": "SKIPPED",
            "reason": "deterministic_position_monitor_no_luna",
            "codex_invoked": False,
            "model_bypassed": True,
        }
    current = now or datetime.now(UTC)
    trigger_codes = {
        str(item.get("code"))
        for item in live_monitor.get("triggers", [])
        if isinstance(item, Mapping) and item.get("code")
    }
    qualitative_codes = {"THESIS_INVALIDATED", "EVENT_RISK_CHANGED"}
    if live_monitor.get("wake_codex") is True and not (trigger_codes & qualitative_codes):
        return {
            "status": "SKIPPED",
            "reason": "deterministic_or_operational_position_attention_no_model",
            "codex_invoked": False,
        }
    compact_position_event = {
        "wake_decision": live_monitor.get("wake_codex") is True,
        "decision_packet": {
            "as_of": current.astimezone(UTC).isoformat(),
            "mode": "LIVE" if config.live_execution_enabled else "PAPER",
            "position_monitor": live_monitor,
            "hard_exit_policy": config.monitor_policy(),
        },
    }
    if compact_position_event["wake_decision"] and execute_models:
        packet_signature = hashlib.sha256(
            json.dumps(compact_position_event, sort_keys=True, default=str).encode()
        ).hexdigest()
        budget = reserve_model_call(
            project_root / "state" / "runtime" / "model_budget.json",
            maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
            now=current,
            packet_signature=packet_signature,
        )
        if budget.get("status") != "RESERVED":
            return {
                "status": "BUDGET_BLOCKED",
                "reason": budget.get("reason"),
                "codex_invoked": False,
                "model_budget": budget,
            }
    return run_trigger(
        compact_position_event,
        project_root=project_root,
        execute=execute_models,
        wake_key="wake_decision",
        model=str(config.get("FINAL_DECISION_MODEL")),
        reasoning_effort=str(config.get("FINAL_DECISION_REASONING_EFFORT")),
        prompt_name="COMPACT_POSITION_DECISION.md",
        sandbox=COMPACT_MODEL_SANDBOX,
        output_schema_name=(
            "trade_decision.schema.json"
            if config.live_execution_enabled
            else "paper_decision.schema.json"
        ),
        isolated_agent=True,
    )


def _qualified_candidates_from_event(event: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    option_event = event.get("option_discovery")
    if not isinstance(option_event, Mapping):
        return []
    candidates = option_event.get("qualified_candidates")
    if not isinstance(candidates, list):
        return []
    return [item for item in candidates if isinstance(item, Mapping)]


def _finalize(
    result: dict[str, Any],
    *,
    cycle: str,
    config: TradingConfig,
    project_root: Path,
    notifications: bool,
    now: datetime | None,
) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    result["run_at"] = current.astimezone(UTC).isoformat()
    result["strategy_epoch"] = strategy_epoch(config)
    result["dry_run"] = not config.live_execution_enabled
    result["paper_trading_enabled"] = config.paper_trading_enabled
    result["live_execution_enabled"] = config.live_execution_enabled
    live = result.get("live") if isinstance(result.get("live"), Mapping) else {}
    live_decision = (
        result.get("live_decision") if isinstance(result.get("live_decision"), Mapping) else {}
    )
    result["orders_placed"] = int(live.get("orders_placed", 0)) + int(
        live_decision.get("orders_placed", 0)
    )
    result["orders_cancelled"] = 0
    record_execution(project_root, result, now=current)
    result["funnel"] = record_cycle_metrics(project_root, cycle, result, now=current, config=config)
    result["notification"] = send_notification(
        result, project_root=project_root, execute=notifications
    )
    result["runtime_write"] = _save_result(project_root, cycle, result)
    result["event_log"] = append_cycle_log(project_root, cycle, result, now=current)
    return result


async def run_cycle(
    cycle: str,
    *,
    project_root: Path,
    execute_models: bool = False,
    notifications: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    config = load_config(project_root / "CONFIG.md")
    in_window, reason = market_window(cycle, config, now=now)
    if not in_window:
        return {
            "cycle": cycle,
            "status": "SKIPPED",
            "reason": reason,
            "models_invoked": 0,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }

    runtime = project_root / "state" / "runtime"
    if config.live_execution_enabled:
        live = await monitor_live_portfolio(config, project_root=project_root, now=now)
        live_monitor = {
            **live,
            "wake_codex": live.get("wake_codex") is True,
            "triggers": live.get("triggers", []),
        }
        paper = {"status": "DISABLED", "orders_placed": 0, "orders_cancelled": 0}
    else:
        live = {"status": "DISABLED", "orders_placed": 0, "orders_cancelled": 0}
        live_monitor = await run_live_monitor(project_root)
        paper = await monitor_paper_portfolio(config, project_root=project_root, now=now)
    baseline = await monitor_baseline(config, project_root=project_root, now=now)
    green_lock = await monitor_green_lock(config, project_root=project_root, now=now)
    if cycle == "positions":
        routing = {
            "decision": _route_compact_position(
                live_monitor,
                config=config,
                project_root=project_root,
                execute_models=execute_models,
                now=now,
            )
        }
        live_decision = (
            await apply_live_decision(
                routing,
                {"live_position_preflight": live_monitor},
                config,
                project_root=project_root,
                now=now,
            )
            if config.live_execution_enabled
            else {"status": "DISABLED", "orders_placed": 0}
        )
        result: dict[str, Any] = {
            "cycle": cycle,
            "monitor": live_monitor,
            "live": live,
            "live_decision": live_decision,
            "paper": paper,
            "baseline": baseline,
            "daily_green_lock": green_lock,
            "routing": routing,
        }
        return _finalize(
            result,
            cycle=cycle,
            config=config,
            project_root=project_root,
            notifications=notifications,
            now=now,
        )

    primary_portfolio = paper.get("portfolio") or {}
    if entry_locked(live if config.live_execution_enabled else primary_portfolio):
        return _finalize(
            {
                "cycle": cycle,
                "status": "SKIPPED",
                "reason": "daily_green_lock_active",
                "monitor": live_monitor,
                "live": live,
                "paper": paper,
                "baseline": baseline,
                "daily_green_lock": green_lock,
                "event": {
                    "option_discovery": {
                        "status": "SKIPPED",
                        "reason": "daily_green_lock_active",
                        "qualified_candidates": [],
                    }
                },
                "routing": {
                    "decision": {
                        "status": "SKIPPED",
                        "reason": "daily_green_lock_active",
                        "codex_invoked": False,
                    }
                },
                "paper_decision": {
                    "status": "SKIPPED",
                    "reason": "daily_green_lock_active",
                    "opened": False,
                },
                "live_decision": {
                    "status": "SKIPPED",
                    "reason": "daily_green_lock_active",
                    "orders_placed": 0,
                },
            },
            cycle=cycle,
            config=config,
            project_root=project_root,
            notifications=notifications,
            now=now,
        )

    model_budget = (
        model_call_budget_status(
            runtime / "model_budget.json",
            maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
            now=now,
        )
        if _options_luna_veto_enabled(config)
        else {"status": "NOT_USED"}
    )
    if (
        execute_models
        and model_budget.get("status") == "EXHAUSTED"
        and live_monitor.get("wake_codex") is not True
        and not research_enabled(config)
    ):
        result = {
            "cycle": cycle,
            "status": "SLEEPING",
            "reason": "daily_model_call_budget_reached",
            "models_invoked": 0,
            "monitor": live_monitor,
            "live": live,
            "live_decision": {
                "status": "SKIPPED",
                "reason": "daily_model_call_budget_reached",
                "orders_placed": 0,
            },
            "paper": paper,
            "daily_green_lock": green_lock,
            "event": {
                "status": "SLEEPING",
                "reason": "daily_model_call_budget_reached",
                "wake_luna": False,
            },
            "routing": {
                "model_budget": model_budget,
                "decision": {
                    "status": "SLEEPING",
                    "reason": "daily_model_call_budget_reached",
                    "codex_invoked": False,
                },
            },
            "paper_decision": {
                "status": "SKIPPED",
                "reason": "daily_model_call_budget_reached",
                "opened": False,
            },
        }
        return _finalize(
            result,
            cycle=cycle,
            config=config,
            project_root=project_root,
            notifications=notifications,
            now=now,
        )

    orderbooks: dict[str, Any] = {"status": "DISABLED", "summaries": {}}
    book_task = None
    if config.get("ENABLE_LEVEL2") is True:
        try:
            from tools.orderbook import collect_orderbooks

            JevConfig.from_config(config)  # Validate optional settings without changing hard gates.
            book_task = asyncio.create_task(
                asyncio.wait_for(
                    collect_orderbooks(
                        list(config.watchlist_symbols())[:4],
                        project_root / "state" / "research" / "orderbook.sqlite3",
                        now=now,
                    ),
                    timeout=20,
                )
            )
            if not JevConfig.from_config(config).shadow_mode:
                orderbooks = await book_task
                book_task = None
        except Exception:
            orderbooks = {"status": "UNAVAILABLE", "summaries": {}}
    intelligence = collect_market_intelligence(
        config,
        runtime_dir=runtime,
        now=now,
        commit=True,
    )
    paper_portfolio = paper.get("portfolio") if isinstance(paper.get("portfolio"), Mapping) else {}
    paper_day = (
        paper_portfolio.get("day") if isinstance(paper_portfolio.get("day"), Mapping) else {}
    )
    live_entry_capacity_reached = config.live_execution_enabled and _live_entry_capacity_reached(
        live, config
    )
    macro = economic_context(now or datetime.now(UTC), config, project_root=project_root)
    block_discovery = (
        entry_locked(live if config.live_execution_enabled else paper_portfolio)
        or not macro["entry_allowed"]
        or not new_entry_window(config, now=now)
        or live_monitor.get("wake_codex") is True
        or paper.get("status") == "ATTENTION"
        or (
            config.live_execution_enabled
            and live.get("status") not in {"QUIET", "MONITORED", "EXIT_FILLED"}
        )
        or live_entry_capacity_reached
        or (not config.live_execution_enabled and _paper_entry_capacity_reached(paper, config))
        or int(paper_day.get("new_positions", 0)) >= int(config.get("MAX_NEW_POSITIONS_PER_DAY"))
    )
    if cycle == "news" or block_discovery:
        if cycle == "news":
            skip_reason = "news_only_cycle"
        elif entry_locked(live if config.live_execution_enabled else paper_portfolio):
            skip_reason = "daily_green_lock_active"
        elif not macro["entry_allowed"]:
            skip_reason = macro["reason"]
        elif not new_entry_window(config, now=now):
            skip_reason = "new_entry_window_closed"
        else:
            skip_reason = "position_or_daily_risk_gate"
        option_event: dict[str, Any] = {
            "status": "SKIPPED",
            "reason": skip_reason,
            "wake_luna": False,
            "qualified_candidates": [],
        }
    elif config.get("WATCHLIST_ONLY") is True:
        option_event = await run_watchlist_option_discovery(
            config,
            state_path=runtime / "watchlist_candidate_seen.json",
            now=now,
            commit=True,
            premium_ceiling=_discovery_premium_ceiling(event_account(live, paper, config), config),
        )
        # Watchlist contracts require the same time-aware normalization as broad sources.
        normalized = _merge_option_discoveries({}, option_event, config=config, now=now)
        option_event = {
            **option_event,
            **{key: normalized[key] for key in ("status", "wake_luna", "qualified_candidates")},
        }
    else:
        mover_discovery = await run_market_mover_discovery(
            config,
            state_path=runtime / "mover_candidate_seen.json",
            now=now,
            commit=True,
        )
        uw_discovery = (
            await run_option_discovery(
                config,
                state_path=runtime / "candidate_seen.json",
                now=now,
                commit=True,
            )
            if config.get("UW_ENABLED") is True
            else {
                "status": "DISABLED",
                "reason": "uw_disabled",
                "wake_luna": False,
                "qualified_candidates": [],
            }
        )
        option_event = _merge_option_discoveries(
            uw_discovery,
            mover_discovery,
            config=config,
            now=now,
        )
    if (
        _options_luna_veto_enabled(config)
        and config.get("ENABLE_MULTI_WATCH") is True
        and not config.live_execution_enabled
        and cycle != "news"
        and not block_discovery
    ):
        from tools.watch_monitor import refresh_watches

        watched = await refresh_watches(config, project_root=project_root, now=now)
        merged = _merge_option_discoveries(option_event, watched, config=config, now=now)
        option_event = {
            **option_event,
            **merged,
            "watch_refresh_status": watched["status"],
            "watch_refresh": {
                key: watched[key] for key in ("status", "reason", "watch_results") if key in watched
            },
        }
    event = {
        "status": (
            "CHANGED" if intelligence.get("wake_luna") or option_event.get("wake_luna") else "QUIET"
        ),
        "wake_luna": intelligence.get("wake_luna") is True or option_event.get("wake_luna") is True,
        "market_intelligence": intelligence,
        "orderbooks": orderbooks,
        "_orderbook_pending": book_task,
        "economic_calendar": macro,
        "option_discovery": option_event,
        "paper_portfolio": paper,
        "daily_green_lock_portfolio": green_lock,
        "live_portfolio": live,
        "live_position_preflight": live_monitor,
        "entry_windows": {
            "DAY": new_entry_window(config, now=now, trade_style="DAY"),
            "SWING": new_entry_window(config, now=now, trade_style="SWING"),
        },
    }
    if live_monitor.get("wake_codex") is True:
        routing = {
            "decision": _route_compact_position(
                live_monitor,
                config=config,
                project_root=project_root,
                execute_models=execute_models,
                now=now,
            ),
        }
    else:
        routing = await _route_compact_decision(
            event,
            config=config,
            project_root=project_root,
            execute_models=execute_models,
            now=now,
            defer_shadow=True,
        )
    decision_event = routing.pop("decision_event", event)
    if config.live_execution_enabled:
        live_decision = await apply_live_decision(
            routing,
            decision_event,
            config,
            project_root=project_root,
            now=now,
        )
        paper_decision = {"status": "DISABLED", "opened": False}
    else:
        live_decision = {"status": "DISABLED", "orders_placed": 0}
        if baseline_enabled(config) or green_lock_enabled(config):
            comparisons = await apply_comparison_decisions(
                routing, decision_event, config, project_root=project_root, now=now
            )
            paper_decision, baseline_decision, green_lock_decision = comparisons
        else:
            paper_decision = await apply_paper_decision(
                routing, decision_event, config, project_root=project_root, now=now
            )
            baseline_decision = {"status": "DISABLED"}
            green_lock_decision = {"status": "DISABLED", "opened": False}
    event.pop("_orderbook_pending", None)
    decision_event.pop("_orderbook_pending", None)
    if book_task is not None:
        try:
            event["orderbooks"] = await book_task
        except Exception:
            event["orderbooks"] = {"status": "UNAVAILABLE", "summaries": {}}
    await _finish_jev_research(routing, project_root=project_root, now=now)
    result = {
        "cycle": cycle,
        "monitor": live_monitor,
        "live": live,
        "live_decision": live_decision,
        "paper": paper,
        "event": decision_event,
        "routing": routing,
        "paper_decision": paper_decision,
        "baseline": baseline,
        "daily_green_lock": green_lock,
        "daily_green_lock_decision": green_lock_decision
        if not config.live_execution_enabled
        else {"status": "DISABLED", "opened": False},
        "baseline_decision": baseline_decision
        if not config.live_execution_enabled
        else {"status": "DISABLED"},
    }
    return _finalize(
        result,
        cycle=cycle,
        config=config,
        project_root=project_root,
        notifications=notifications,
        now=now,
    )


def _exception_summary(exc: BaseException, *, depth: int = 0) -> str:
    """Preserve bounded nested causes from ExceptionGroup-style transport failures."""

    message = str(exc).strip()
    summary = f"{type(exc).__name__}: {message}" if message else type(exc).__name__
    children = getattr(exc, "exceptions", ())
    if depth >= 2 or not isinstance(children, tuple) or not children:
        return summary[:1000]
    nested = " | ".join(
        _exception_summary(child, depth=depth + 1)
        for child in children[:3]
        if isinstance(child, BaseException)
    )
    return f"{summary} -> {nested}"[:1000] if nested else summary[:1000]


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cycle", choices=sorted(CYCLES))
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--execute-models", action="store_true")
    parser.add_argument("--notifications", action="store_true")
    parser.add_argument("--ignore-market-window", action="store_true")
    args = parser.parse_args(argv)
    now = None
    if args.ignore_market_window:
        local = datetime.now(EASTERN)
        now = local.replace(hour=12, minute=0, second=0, microsecond=0)
        while now.weekday() >= 5:
            now -= timedelta(days=1)
    try:
        result = asyncio.run(
            run_cycle(
                args.cycle,
                project_root=args.project_root.resolve(),
                execute_models=args.execute_models,
                notifications=args.notifications,
                now=now,
            )
        )
    except Exception as exc:
        result = {
            "cycle": args.cycle,
            "status": "ERROR",
            "error": _exception_summary(exc),
            "models_invoked": 0,
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
        if args.notifications:
            result["notification"] = send_notification(
                result,
                project_root=args.project_root.resolve(),
                execute=True,
            )
        try:
            result["event_log"] = append_cycle_log(
                args.project_root.resolve(),
                args.cycle,
                result,
            )
        except Exception as log_exc:
            result["event_log_error"] = _exception_summary(log_exc)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 1 if result.get("status") == "ERROR" else 0


if __name__ == "__main__":
    raise SystemExit(main())
