"""Explicit, unvalidated spot-paper continuation experiment, separate from option rules."""

from datetime import timedelta
from statistics import mean

from tools.crypto_paper import amount, stamp, valid_quote
from tools.market_calendar import EASTERN, session_hours


def crypto_window(now):
    now = stamp(now)
    hours = session_hours(now.astimezone(EASTERN).date())
    if hours and hours[0] <= now < hours[1]:
        return {"entry_allowed": False, "reason": "equity_session", "admission_limit": None}
    deadline = now + timedelta(hours=4)
    if hours and now < hours[0]:
        deadline = min(deadline, hours[0])
    # Bound overnight holds at the next actual equity open, including holidays and early closes.
    for offset in range(1, 5):
        future = session_hours(now.astimezone(EASTERN).date() + timedelta(days=offset))
        if future:
            deadline = min(deadline, future[0])
            break
    return {
        "entry_allowed": True,
        "reason": "outside_equity_session",
        "admission_limit": None,
        "deadline": deadline.isoformat(),
    }


def technical(snapshot, now):
    rows = snapshot["candles_5m"]
    if len(rows) < 63:
        raise ValueError("insufficient consecutive 5m history")
    previous = None
    for row in rows:
        start, end = stamp(row["starts_at"]), stamp(row["ends_at"])
        if end - start != timedelta(minutes=5) or end > stamp(now):
            raise ValueError("unclosed or incorrect candle")
        if previous is not None and start != previous:
            raise ValueError("candle gap")
        previous = end
        for key in ("open", "high", "low", "close", "volume"):
            amount(row[key], zero=key == "volume")
    if not 0 <= (stamp(now) - previous).total_seconds() <= 330:
        raise ValueError("stale completed candles")
    groups = {}
    for row in rows:
        bucket = int(stamp(row["starts_at"]).timestamp()) // 900
        groups.setdefault(bucket, []).append(row)
    fifteen = []
    for bucket, group in sorted(groups.items()):
        if len(group) == 3 and int(stamp(group[0]["starts_at"]).timestamp()) == bucket * 900:
            fifteen.append({"close": group[-1]["close"], "ends_at": group[-1]["ends_at"]})
    if len(fifteen) < 20:
        raise ValueError("insufficient complete 15m history")
    frames = {}
    for name, bars in (("5M", rows), ("15M", fifteen)):
        closes = [row["close"] for row in bars]
        sma = mean(closes[-20:])
        change = (closes[-1] / closes[-4] - 1) * 100
        frames[name] = {
            "status": "OK",
            "latest_close": closes[-1],
            "sma_20": sma,
            "change_3_bar_percent": change,
            "bars_count": len(bars),
            "last_bar_at": bars[-1]["ends_at"],
            "trend": "BULLISH" if closes[-1] > sma and change > 0 else "NOT_BULLISH",
        }
    atr = mean(
        max(
            row["high"] - row["low"],
            abs(row["high"] - prior["close"]),
            abs(row["low"] - prior["close"]),
        )
        for prior, row in zip(rows[-15:-1], rows[-14:], strict=True)
    )
    frames["5M"]["atr_14"] = atr
    volume_mean = mean(row["volume"] for row in rows[-21:-1])
    frames["5M"]["relative_volume_20"] = rows[-1]["volume"] / volume_mean if volume_mean else 0
    return {
        "timeframes": frames,
        "setup": "5M_AND_15M_SMA20_POSITIVE_3BAR_CONTINUATION",
        "setup_status": "UNVALIDATED_PAPER_EXPERIMENT",
    }


def build_packet(snapshot, config, state, risk, macro, now):
    bid, ask = valid_quote(snapshot["quote"], now)
    tech = technical(snapshot, now)
    tech["data_venue"] = snapshot.get("research_venue", snapshot.get("venue"))
    window = crypto_window(now)
    reasons = []
    symbol = config.get("CRYPTO_SYMBOL", "ETH-USD")
    if snapshot.get("status") != "OK" or snapshot.get("symbol") != symbol:
        reasons.append("invalid_crypto_snapshot")
    if not window["entry_allowed"]:
        reasons.append("equity_session")
    if not risk["allowed"]:
        reasons.append(risk["reason"])
    if macro.get("entry_allowed") is not True:
        reasons.append("economic_calendar_block")
    if any(frame["trend"] != "BULLISH" for frame in tech["timeframes"].values()):
        reasons.append("long_continuation_not_aligned")
    if tech["timeframes"]["5M"]["relative_volume_20"] < 0.5:
        reasons.append("low_completed_bar_volume")
    midpoint = (bid + ask) / 2
    candidate = {
        "candidate_id": f"{symbol}:SPOT_LONG",
        "symbol": symbol,
        "asset_type": "SPOT_LONG",
        "direction": "LONG",
        "venue": snapshot.get("venue", "UNKNOWN"),
        "underlying_price": midpoint,
        "bid": bid,
        "ask": ask,
        "spread_percent": (ask - bid) / midpoint * 100,
        "quote_updated_at": snapshot["quote"]["updated_at"],
        "quote_is_fresh": True,
        "python_preferred_style": "CRYPTO_INTRADAY",
        "hold_minutes": config.get("CRYPTO_MAX_HOLD_MINUTES"),
        "invalidation_price": risk["fill"] * (1 - config.get("CRYPTO_STOP_LOSS_PERCENT") / 100),
        "target_price": risk["fill"] * (1 + config.get("CRYPTO_TAKE_PROFIT_PERCENT") / 100),
    }
    return {
        "as_of": stamp(now).isoformat(),
        "mode": "PAPER_ONLY",
        "candidate": candidate,
        "technical": tech,
        "python_gate": {"status": "REJECTED" if reasons else "QUALIFIED", "reasons": reasons},
        "economic_calendar": macro,
        "risk": risk,
        "session": window,
        "execution": {
            "venue": str(snapshot.get("venue", "UNKNOWN")) + "_PAPER_SIMULATION",
            "broker_order": False,
            "fee_percent_side": risk.get(
                "fee_ratio", config.get("CRYPTO_PAPER_FEE_PERCENT_SIDE") / 100
            )
            * 100,
            "external_research_venue": snapshot.get("research_venue"),
            "depth_is_execution_venue": snapshot.get("book_venue", snapshot.get("venue"))
            == snapshot.get("venue"),
            "slippage_bps_side": config.get("CRYPTO_PAPER_SLIPPAGE_BPS_SIDE"),
        },
        "news": {"label": "UNAVAILABLE_CRYPTO_SPECIFIC_FEED"},
        "social": {"label": "UNAVAILABLE"},
        "earnings": "NOT_APPLICABLE_SPOT_ASSET",
        "account": {"cash": state["cash"], "equity": state["last_equity"]},
    }
