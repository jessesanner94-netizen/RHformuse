"""Launch the compact Vibe snapshot worker without exposing raw bars to a model."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any


def fetch_vibe_snapshot(
    symbol: str, *, project_root: Path, timeout: float = 120, intraday_only: bool = False
) -> dict[str, Any]:
    python = (
        project_root / ".vibe-venv" / "Scripts" / "python.exe"
        if os.name == "nt"
        else project_root / ".vibe-venv" / "bin" / "python"
    )
    worker = project_root / "tools" / "vibe_snapshot_worker.py"
    if not python.exists() or not worker.exists():
        return {"status": "UNAVAILABLE", "reason": "vibe_worker_runtime_missing"}
    command = [str(python), str(worker), "--symbol", symbol]
    if intraday_only:
        command.append("--intraday-only")
    completed = subprocess.run(
        command,
        cwd=project_root,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
        timeout=timeout,
    )
    if completed.returncode != 0:
        return {
            "status": "ERROR",
            "reason": "vibe_worker_failed",
            "error": completed.stderr.strip()[-500:],
        }
    try:
        result = json.loads(completed.stdout.strip().splitlines()[-1])
    except json.JSONDecodeError:
        return {"status": "ERROR", "reason": "vibe_worker_invalid_json"}
    return (
        result
        if isinstance(result, dict)
        else {"status": "ERROR", "reason": "vibe_worker_invalid_payload"}
    )
