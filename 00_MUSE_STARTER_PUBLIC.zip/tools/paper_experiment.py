"""Paired forward paper control; never has broker order authority.

The DAY control buys the same Python-qualified, model-reviewed contract irrespective
of BUY/PASS/WAIT/WATCH. Both ledgers share the post-decision quote, costs and hard exits.
It is conditional on the main discovery funnel, not an independent strategy backtest.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.config import TradingConfig
from tools.paper_runner import apply_paper_decision, monitor_paper_portfolio
from tools.paper_trading import (
    GREEN_LOCK_VARIANT,
    _append_event,
    _exclusive_lock,
    load_paper_portfolio,
    record_variant_skip,
)
from tools.robinhood_mcp import fetch_quote_refresh


def enabled(config: TradingConfig) -> bool:
    return (
        config.paper_trading_enabled
        and not config.live_execution_enabled
        and config.get("PAPER_BASELINE_ENABLED") is True
    )


def green_lock_enabled(config: TradingConfig) -> bool:
    return (
        config.paper_trading_enabled and not config.live_execution_enabled
        and config.get("PAPER_DAILY_GREEN_LOCK_ENABLED") is True
    )


async def monitor_green_lock(config: TradingConfig, *, project_root: Path, now: datetime | None):
    if not green_lock_enabled(config):
        return {"status": "DISABLED"}
    try:
        return await monitor_paper_portfolio(
            config, project_root=project_root, now=now, ledger_name=GREEN_LOCK_VARIANT
        )
    except Exception as exc:
        return {"status": "ATTENTION", "error": f"{type(exc).__name__}: {exc}"[:500]}


async def apply_green_lock_decision(
    routing: Mapping[str, Any], event: Mapping[str, Any], config: TradingConfig, *,
    project_root: Path, now: datetime | None, quote_fetcher=None,
) -> dict[str, Any]:
    """Primary-style, fresh Luna decisions only, conditional on the shared funnel."""
    if not green_lock_enabled(config):
        return {"status": "DISABLED", "opened": False}
    current = now or datetime.now(UTC)
    directory = project_root / "state" / GREEN_LOCK_VARIANT
    portfolio, events = directory / "PORTFOLIO.json", directory / "EVENTS.jsonl"
    packet = routing.get("decision_packet") or {}
    route = routing.get("decision") or {}
    candidate = packet.get("candidate") or {}

    def skip(result):
        return record_variant_skip(
            result, config, candidate_id=candidate.get("candidate_id"),
            portfolio_path=portfolio, event_log_path=events, now=now or datetime.now(UTC),
        )

    try:
        if (
            route.get("status") != "COMPLETED" or route.get("cached") is True
            or packet.get("python_gate", {}).get("status") != "QUALIFIED"
        ):
            return skip({"status": "SKIPPED", "reason": "no_new_model_reviewed_candidate",
                         "opened": False})
        verdict = json.loads(route.get("output", ""))
        if verdict.get("action") != "BUY":
            return skip({"status": "RECORDED_NO_ENTRY", "reason":
                         f"model_action_{verdict.get('action')}", "opened": False})
        monitor = event.get("daily_green_lock_portfolio")
        if isinstance(monitor, Mapping) and monitor.get("status") not in {
            "QUIET", "MONITORED", "EXITED"
        }:
            return skip({"status": "BLOCKED", "reasons": ["daily_green_lock_monitor_not_ready"],
                         "opened": False})
        state = load_paper_portfolio(
            portfolio, starting_cash=float(config.get("PAPER_STARTING_CASH")), now=current
        )
        if state["day"].get("green_lock_active") is True:
            return skip({"status": "BLOCKED", "reasons": ["daily_green_lock_active"],
                         "opened": False})
        result = await apply_paper_decision(
            routing, event, config, project_root=project_root, now=now,
            quote_fetcher=quote_fetcher, ledger_name=GREEN_LOCK_VARIANT,
        )
        if result.get("opened") is not True and not result.get("skip_recorded"):
            return skip(result)
        return result
    except Exception as exc:
        return {"status": "ATTENTION", "error": f"{type(exc).__name__}: {exc}"[:500],
                "opened": False}


async def apply_comparison_decisions(
    routing: Mapping[str, Any], event: Mapping[str, Any], config: TradingConfig, *,
    project_root: Path, now: datetime | None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    quotes: dict[str, Any] = {}

    async def shared_refresh(requests):
        key = json.dumps(requests, sort_keys=True)
        if key not in quotes:
            quotes[key] = await fetch_quote_refresh(requests)
        return quotes[key]

    primary, baseline = await apply_paired_decisions(
        routing, event, config, project_root=project_root, now=now, quote_fetcher=shared_refresh
    )
    variant = await apply_green_lock_decision(
        routing, event, config, project_root=project_root, now=now, quote_fetcher=shared_refresh
    )
    route = routing.get("decision") or {}
    packet = routing.get("decision_packet") or {}
    if green_lock_enabled(config) and route.get("status") == "COMPLETED":
        comparison_path = project_root / "state" / GREEN_LOCK_VARIANT / "COMPARISONS.jsonl"
        try:
            with _exclusive_lock(comparison_path):
                _append_event(comparison_path, {
                    "event": "PAPER_COMPARISON",
                    "timestamp": (now or datetime.now(UTC)).isoformat(),
                    "candidate_id": packet.get("candidate", {}).get("candidate_id"),
                    "cached": route.get("cached") is True,
                    "primary_paper_id": primary.get("position", {}).get("paper_id"),
                    "variant_paper_id": variant.get("position", {}).get("paper_id"),
                    "primary_status": primary.get("status"),
                    "variant_status": variant.get("status"),
                    "variant_skip_reason": variant.get("event", {}).get("reason"),
                    "net_reward_risk": packet.get("net_reward_risk"),
                })
        except Exception as exc:
            variant["comparison_log_error"] = f"{type(exc).__name__}: {exc}"[:500]
    return primary, baseline, variant


async def monitor_baseline(config: TradingConfig, *, project_root: Path, now: datetime | None):
    if not enabled(config):
        return {"status": "DISABLED"}
    try:
        return await monitor_paper_portfolio(
            config, project_root=project_root, now=now, ledger_name="paper_baseline"
        )
    except Exception as exc:
        return {"status": "ATTENTION", "error": f"{type(exc).__name__}: {exc}"[:500]}


async def apply_paired_decisions(
    routing: Mapping[str, Any],
    event: Mapping[str, Any],
    config: TradingConfig,
    *,
    project_root: Path,
    now: datetime | None,
    quote_fetcher=None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    quotes: dict[str, Any] = {}

    async def shared_refresh(requests):
        key = json.dumps(requests, sort_keys=True)
        if key not in quotes:
            quotes[key] = await (quote_fetcher or fetch_quote_refresh)(requests)
        return quotes[key]

    primary = await apply_paper_decision(
        routing, event, config, project_root=project_root, now=now, quote_fetcher=shared_refresh
    )
    if not enabled(config):
        return primary, {"status": "DISABLED"}
    packet = routing.get("decision_packet") or {}
    route = routing.get("decision") or {}
    candidate = packet.get("candidate") or {}
    if (
        route.get("status") != "COMPLETED"
        or route.get("cached") is True
        or packet.get("python_gate", {}).get("status") != "QUALIFIED"
        or candidate.get("python_preferred_style") != "DAY"
    ):
        return primary, {"status": "SKIPPED", "reason": "no_new_model_reviewed_day_candidate"}
    try:
        verdict = json.loads(route.get("output", ""))
        if verdict.get("action") not in {"BUY", "PASS", "WAIT", "WATCH"}:
            return primary, {"status": "SKIPPED", "reason": "no_entry_verdict"}
        if verdict.get("action") == "BUY" and verdict.get("trade_style") != "DAY":
            return primary, {"status": "SKIPPED", "reason": "model_chose_swing_horizon"}
        decision = {
            "action": "BUY",
            "candidate_id": candidate.get("candidate_id"),
            "trade_style": "DAY",
            "hold_deadline": None,
            "thesis": "Forward control: Python-qualified DAY candidate before Luna's veto.",
            "invalidation": "Same configured premium stop and regular-session time exit.",
            "reason": "DETERMINISTIC_DAY_CONTROL",
            "confidence": None,
            "earnings_event": json.dumps(packet.get("earnings_event", {})),
            "holds_through_earnings": False,
        }
        result = await apply_paper_decision(
            {"decision": {"status": "COMPLETED", "output": json.dumps(decision)}},
            event,
            config,
            project_root=project_root,
            now=now,
            quote_fetcher=shared_refresh,
            ledger_name="paper_baseline",
        )
        result["paired_model_action"] = verdict["action"]
        pairs = project_root / "state/evaluation/PAIRS.jsonl"
        with _exclusive_lock(pairs):
            _append_event(
                pairs,
                {
                    "timestamp": packet.get("as_of"),
                    "candidate_id": candidate.get("candidate_id"),
                    "model_action": verdict["action"],
                    "primary_paper_id": primary.get("position", {}).get("paper_id"),
                    "baseline_paper_id": result.get("position", {}).get("paper_id"),
                    "primary_status": primary.get("status"),
                    "baseline_status": result.get("status"),
                    "quote_as_of": result.get("fill_quote_snapshot_as_of"),
                },
            )
        return primary, result
    except Exception as exc:
        return primary, {"status": "ATTENTION", "error": f"{type(exc).__name__}: {exc}"[:500]}
