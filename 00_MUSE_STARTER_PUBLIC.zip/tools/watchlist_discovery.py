"""Resolve the configured fixed watchlist without broad mover or paid-flow discovery."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.config import TradingConfig
from tools.news_option_discovery import run_symbol_option_discovery
from tools.state_manager import guarded_json_update


def _signature(candidates: list[Mapping[str, Any]]) -> str:
    compact = [
        {"id": item.get("candidate_id"), "styles": item.get("eligible_trade_styles", [])}
        for item in candidates
    ]
    return hashlib.sha256(json.dumps(compact, sort_keys=True).encode("utf-8")).hexdigest()


async def run_watchlist_option_discovery(
    config: TradingConfig,
    *,
    state_path: Path,
    now: datetime | None = None,
    commit: bool = True,
    premium_ceiling: float | None = None,
    option_resolver: Callable[..., Awaitable[dict[str, Any]]] = run_symbol_option_discovery,
) -> dict[str, Any]:
    """Resolve exactly WATCHLIST_SYMBOLS and persist only a compact change signature."""

    current = now or datetime.now(UTC)
    symbols = list(config.watchlist_symbols())
    contracts = await option_resolver(
        symbols,
        config,
        discovery_source="CONFIGURED_WATCHLIST",
        max_symbols=len(symbols),
        max_expirations=3,
        max_candidates=12,
        now=current,
        premium_ceiling=premium_ceiling,
    )
    qualified = [
        dict(item)
        for item in contracts.get("qualified_candidates", [])
        if isinstance(item, Mapping) and str(item.get("symbol", "")).upper() in symbols
    ]
    signature = _signature(qualified)
    prior_signature: str | None = None
    if state_path.exists():
        try:
            prior = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(prior, Mapping):
                prior_signature = str(prior.get("signature") or "") or None
        except (OSError, json.JSONDecodeError):
            prior_signature = None
    changed = bool(qualified) and signature != prior_signature
    write = guarded_json_update(
        state_path,
        {
            "updated_at": current.astimezone(UTC).isoformat(),
            "symbols": symbols,
            "signature": signature,
            "candidate_ids": [item.get("candidate_id") for item in qualified],
        },
        commit=commit,
    )
    return {
        "status": (
            "QUALIFIED_CHANGED" if changed else "UNCHANGED" if qualified else "ZERO_QUALIFIED"
        ),
        "wake_luna": changed,
        "symbols": symbols,
        "contract_discovery": contracts,
        "qualified_candidates": qualified,
        "signature": signature,
        "persistent_write": write,
        "orders_placed": 0,
        "orders_cancelled": 0,
    }
