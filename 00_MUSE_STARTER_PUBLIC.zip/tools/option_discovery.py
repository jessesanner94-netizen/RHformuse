"""Run a model-free UW discovery pass and verify candidates with fresh Robinhood quotes."""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.cheap_scan import scan_candidates
from tools.config import TradingConfig
from tools.option_style import annotate_option_styles
from tools.robinhood_mcp import fetch_contract_research
from tools.state_manager import guarded_json_update
from tools.unusual_whales import UnusualWhalesClient

EASTERN = ZoneInfo("America/New_York")


def _append_attribution(path: Path, record: Mapping[str, Any], *, commit: bool) -> None:
    if not commit:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _rows(result_payload: Any) -> list[Mapping[str, Any]]:
    payload = result_payload.payload if hasattr(result_payload, "payload") else result_payload
    if isinstance(payload, Mapping) and isinstance(payload.get("data"), list):
        return [item for item in payload["data"] if isinstance(item, Mapping)]
    return []


def _dte(expiry: Any, *, today: date) -> int | None:
    if not isinstance(expiry, str):
        return None
    try:
        return (date.fromisoformat(expiry) - today).days
    except ValueError:
        return None


def select_uw_discoveries(
    rows: list[Mapping[str, Any]],
    *,
    config: TradingConfig,
    today: date,
    limit: int = 24,
    max_contracts_per_symbol: int = 2,
) -> list[dict[str, Any]]:
    """Apply only approved DTE/direction/size bounds before live quote resolution."""

    selected: list[dict[str, Any]] = []
    rough_price_ceiling = float(config.get("MAX_SINGLE_POSITION_PREMIUM_AT_RISK")) / 50
    for row in rows:
        dte = _dte(row.get("expiry"), today=today)
        option_type = str(row.get("option_type", "")).lower()
        close = _number(row.get("close"))
        strike = _number(row.get("strike"))
        symbol = str(row.get("ticker_symbol", "")).strip().upper()
        if (
            dte is None
            or dte < int(config.get("MIN_DTE"))
            or dte > int(config.get("MAX_DTE"))
            or option_type not in {"call", "put"}
            or (option_type == "call" and config.get("ALLOW_LONG_CALLS") is not True)
            or (option_type == "put" and config.get("ALLOW_LONG_PUTS") is not True)
            or close is None
            or close <= 0
            or close > rough_price_ceiling
            or strike is None
            or not symbol
        ):
            continue
        selected.append(
            {
                "symbol": symbol,
                "expiry": str(row["expiry"]),
                "strike": strike,
                "option_type": option_type,
                "dte": dte,
                "uw": dict(row),
            }
        )
    selected.sort(
        key=lambda item: (
            _number(item["uw"].get("ticker_vol")) or 0,
            _number(item["uw"].get("volume")) or 0,
            _number(item["uw"].get("sweep_volume")) or 0,
        ),
        reverse=True,
    )
    unique: dict[tuple[str, str, float, str], dict[str, Any]] = {}
    for item in selected:
        key = (item["symbol"], item["expiry"], item["strike"], item["option_type"])
        unique.setdefault(key, item)
    diversified: list[dict[str, Any]] = []
    symbol_counts: dict[str, int] = {}
    for item in unique.values():
        symbol = item["symbol"]
        if symbol_counts.get(symbol, 0) >= max_contracts_per_symbol:
            continue
        diversified.append(item)
        symbol_counts[symbol] = symbol_counts.get(symbol, 0) + 1
        if len(diversified) >= limit:
            break
    return diversified


def _instrument_key(row: Mapping[str, Any]) -> tuple[str, str, float, str] | None:
    strike = _number(row.get("strike_price"))
    if strike is None:
        return None
    return (
        str(row.get("chain_symbol", "")).upper(),
        str(row.get("expiration_date", "")),
        strike,
        str(row.get("type", "")).lower(),
    )


def _quote_maps(
    research: Mapping[str, Any],
) -> tuple[dict[str, Mapping[str, Any]], dict[str, float]]:
    option_quotes: dict[str, Mapping[str, Any]] = {}
    for row in research.get("option_quotes", []):
        if not isinstance(row, Mapping):
            continue
        body = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        contract_id = body.get("instrument_id")
        if isinstance(contract_id, str):
            option_quotes[contract_id] = body
    underlying: dict[str, float] = {}
    for row in research.get("equity_quotes", []):
        if not isinstance(row, Mapping):
            continue
        body = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        symbol = str(body.get("symbol", "")).upper()
        price = _number(body.get("last_trade_price") or body.get("last_non_reg_trade_price"))
        if symbol and price is not None:
            underlying[symbol] = price
    return option_quotes, underlying


def _liquidity_map(research: Mapping[str, Any], prices: Mapping[str, float]) -> dict[str, float]:
    liquidity: dict[str, float] = {}
    for row in research.get("equity_fundamentals", []):
        if not isinstance(row, Mapping):
            continue
        symbol = str(row.get("symbol", "")).upper()
        average_volume = _number(
            row.get("average_volume_30_days")
            or row.get("average_volume")
            or row.get("average_volume_2_weeks")
        )
        price = prices.get(symbol)
        if symbol and average_volume is not None and price is not None:
            liquidity[symbol] = average_volume * price
    return liquidity


def _fresh_quote(quote: Mapping[str, Any], *, now: datetime, maximum_age: int = 180) -> bool:
    raw = quote.get("updated_at")
    if not isinstance(raw, str):
        return False
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    age = (now.astimezone(UTC) - parsed.astimezone(UTC)).total_seconds()
    return -30 <= age <= maximum_age


def build_candidates(
    discoveries: list[dict[str, Any]],
    research: Mapping[str, Any],
    *,
    now: datetime,
    config: TradingConfig,
) -> list[dict[str, Any]]:
    instruments = {
        key: row
        for row in research.get("instruments", [])
        if isinstance(row, Mapping) and (key := _instrument_key(row)) is not None
    }
    quotes, underlying = _quote_maps(research)
    liquidity = _liquidity_map(research, underlying)
    candidates: list[dict[str, Any]] = []
    for discovery in discoveries:
        key = (
            discovery["symbol"],
            discovery["expiry"],
            discovery["strike"],
            discovery["option_type"],
        )
        instrument = instruments.get(key)
        if instrument is None:
            continue
        contract_id = str(instrument.get("id") or instrument.get("instrument_id") or "")
        quote = quotes.get(contract_id)
        if not contract_id or quote is None:
            continue
        candidates.append(
            annotate_option_styles(
                {
                    "candidate_id": contract_id,
                    "symbol": discovery["symbol"],
                    "option_symbol": discovery["uw"].get("option_symbol"),
                    "expiration": discovery["expiry"],
                    "strike": discovery["strike"],
                    "option_type": discovery["option_type"].upper(),
                    "dte": discovery["dte"],
                    "underlying_price": underlying.get(discovery["symbol"]),
                    "bid": _number(quote.get("bid_price")),
                    "ask": _number(quote.get("ask_price")),
                    "option_volume": _number(quote.get("volume")),
                    "option_open_interest": _number(quote.get("open_interest")),
                    "underlying_avg_daily_dollar_volume": liquidity.get(discovery["symbol"]),
                    "quote_is_fresh": _fresh_quote(quote, now=now),
                    "quote_updated_at": quote.get("updated_at"),
                    "setup_qualified": True,
                    "discovery_source": "UW_HIGH_OPTIONS_VOLUME",
                    "implied_volatility": _number(quote.get("implied_volatility")),
                    "delta": _number(quote.get("delta")),
                    "gamma": _number(quote.get("gamma")),
                    "theta": _number(quote.get("theta")),
                    "vega": _number(quote.get("vega")),
                    "rho": _number(quote.get("rho")),
                    "break_even_price": _number(quote.get("break_even_price")),
                    "chance_of_profit_long": _number(quote.get("chance_of_profit_long")),
                    "uw_discovery": {
                        "premium": discovery["uw"].get("premium"),
                        "sweep_volume": discovery["uw"].get("sweep_volume"),
                        "ask_side_volume": discovery["uw"].get("ask_side_volume"),
                        "bid_side_volume": discovery["uw"].get("bid_side_volume"),
                        "next_earnings_date": discovery["uw"].get("next_earnings_date"),
                    },
                },
                config,
            )
        )
    return candidates


def _signature(candidates: list[Mapping[str, Any]]) -> str:
    compact = [
        {
            "id": item.get("candidate_id"),
            "styles": item.get("eligible_trade_styles", []),
        }
        for item in candidates
    ]
    return hashlib.sha256(json.dumps(compact, sort_keys=True).encode("utf-8")).hexdigest()


async def run_option_discovery(
    config: TradingConfig,
    *,
    state_path: Path,
    uw_client: UnusualWhalesClient | None = None,
    research_fetcher: Callable[[list[Mapping[str, str]]], Awaitable[dict[str, Any]]] = (
        fetch_contract_research
    ),
    now: datetime | None = None,
    commit: bool = True,
) -> dict[str, Any]:
    current_time = now or datetime.now(UTC)
    client = uw_client or UnusualWhalesClient()
    uw_rows: list[Mapping[str, Any]] = []
    attribution_path = state_path.with_name("uw_attribution.jsonl")
    uw_attribution: list[dict[str, Any]] = []
    for option_type in ("Calls", "Puts"):
        pre_record = {
            "timestamp": datetime.now(UTC).isoformat(),
            "stage": "PRE_UW",
            "query": "option_screener",
            "option_type": option_type,
            "action": "NO_TRADE_YET_DISCOVERY_ONLY",
            "conviction": 0.0,
        }
        _append_attribution(attribution_path, pre_record, commit=commit)
        query_rows = _rows(client.option_screener(option_type=option_type, limit=200))
        uw_rows.extend(query_rows)
        post_record = {
            "timestamp": datetime.now(UTC).isoformat(),
            "stage": "POST_UW",
            "query": "option_screener",
            "option_type": option_type,
            "action": "RESEARCH_CANDIDATES" if query_rows else "NO_CANDIDATES",
            "conviction": 0.0,
            "rows_returned": len(query_rows),
            "what_changed": "Discovery rows became available; no trade decision was made.",
        }
        _append_attribution(attribution_path, post_record, commit=commit)
        uw_attribution.extend([pre_record, post_record])
    discoveries = select_uw_discoveries(
        uw_rows, config=config, today=current_time.astimezone(EASTERN).date()
    )
    requests = [
        {
            "chain_symbol": item["symbol"],
            "expiration_dates": item["expiry"],
            "strike_price": f"{item['strike']:.4f}",
            "type": item["option_type"],
        }
        for item in discoveries
    ]
    research = (
        await research_fetcher(requests)
        if requests
        else {
            "instruments": [],
            "option_quotes": [],
            "equity_quotes": [],
            "equity_fundamentals": [],
        }
    )
    candidates = build_candidates(discoveries, research, now=current_time, config=config)
    gate = scan_candidates(candidates, config)
    qualified_ids = {item["candidate_id"] for item in gate["qualified"]}
    premium_floor = float(config.get("MIN_SINGLE_POSITION_PREMIUM_AT_RISK"))
    premium_limit = float(config.get("MAX_SINGLE_POSITION_PREMIUM_AT_RISK"))
    qualified = [
        item
        for item in candidates
        if item["candidate_id"] in qualified_ids
        and premium_floor <= float(item["ask"]) * 100 <= premium_limit
    ]
    signature = _signature(qualified)
    prior_signature: str | None = None
    if state_path.exists():
        try:
            prior = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(prior, Mapping):
                prior_signature = str(prior.get("signature") or "") or None
        except (OSError, json.JSONDecodeError):
            prior_signature = None
    changed = bool(qualified) and signature != prior_signature
    write_result = guarded_json_update(
        state_path,
        {
            "updated_at": current_time.astimezone(UTC).isoformat(),
            "signature": signature,
            "candidate_ids": [item["candidate_id"] for item in qualified],
        },
        commit=commit,
    )
    status = "QUALIFIED_CHANGED" if changed else "ZERO_QUALIFIED" if not qualified else "UNCHANGED"
    return {
        "status": status,
        "wake_luna": changed,
        "uw_rows": len(uw_rows),
        "discoveries_resolved": len(discoveries),
        "gate": gate,
        "qualified_candidates": qualified,
        "premium_limit": premium_limit,
        "premium_floor": premium_floor,
        "signature": signature,
        "uw_attribution": uw_attribution,
        "uw_attribution_log": str(attribution_path),
        "persistent_write": write_result,
        "orders_placed": 0,
        "orders_cancelled": 0,
    }


def run_sync(config: TradingConfig, *, state_path: Path, commit: bool = True) -> dict[str, Any]:
    return asyncio.run(run_option_discovery(config, state_path=state_path, commit=commit))
