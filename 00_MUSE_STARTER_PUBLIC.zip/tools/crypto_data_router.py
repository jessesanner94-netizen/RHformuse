"""Robinhood paper prices, public exchange research, explicit source provenance."""

import asyncio
import math
from datetime import UTC, datetime

from tools import binance_us_data, crypto_market_data, robinhood_crypto_data
from tools.crypto_paper import stamp, valid_quote
from tools.crypto_symbols import validate_symbol


async def validated_quote(quote, now=None):
    """Wait out bounded provider clock skew; never relabel or accept a future quote."""
    current = now or datetime.now(UTC)
    ahead = (stamp(quote["updated_at"]) - stamp(current)).total_seconds()
    if now is None and 0 < ahead <= 5:
        await asyncio.sleep(ahead + 0.01)
        current = datetime.now(UTC)
    valid_quote(quote, current)
    return quote


async def robinhood_quote(now=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    quote = await robinhood_crypto_data.fetch_quote(now=now, symbol=symbol)
    estimate = await asyncio.to_thread(
        robinhood_crypto_data.read_endpoint,
        f"/api/v2/crypto/trading/estimated_price/?symbol={symbol}&side=both&quantity=0.01",
    )
    current = now or datetime.now(UTC)
    rows = estimate.get("results", [])
    if len(rows) != 2 or {row.get("side") for row in rows} != {"bid", "ask"}:
        raise ValueError("fee_estimate_unavailable")
    fees = []
    for row in rows:
        fee = float(row["fee_ratio"])
        if (
            row.get("symbol") != symbol
            or float(row["quantity"]) != 0.01
            or not math.isfinite(fee)
            or not 0 <= fee < 1
            or not 0 <= (stamp(current) - stamp(row["timestamp"])).total_seconds() <= 60
        ):
            raise ValueError("invalid_fee_estimate")
        fees.append(fee)
    valid_quote(quote, current)
    return {
        **quote,
        "fee_ratio": max(fees),
        "fee_sample_quantity": 0.01,
        "fee_source": "ROBINHOOD_ESTIMATE",
        "size_adjusted_fill": False,
    }


async def fetch_quote(now=None, venue=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    if venue in (None, robinhood_crypto_data.VENUE):
        try:
            quote = await robinhood_quote(now=now, symbol=symbol)
            return await validated_quote(quote, now)
        except (ValueError, KeyError, TypeError, ConnectionError, TimeoutError):
            if venue is not None:
                raise
    if venue in (None, crypto_market_data.VENUE):
        try:
            quote = await crypto_market_data.fetch_quote(now=now, symbol=symbol)
            return await validated_quote(
                {
                    **quote,
                    "venue": crypto_market_data.VENUE,
                    "paper_price_fallback": venue is None,
                },
                now,
            )
        except (ValueError, KeyError, TypeError, ConnectionError, TimeoutError):
            if venue is not None:
                raise
    if venue in (None, binance_us_data.VENUE):
        return await validated_quote(
            {
                **await binance_us_data.fetch_quote(now=now, symbol=symbol),
                "paper_price_fallback": venue is None,
            },
            now,
        )
    raise ValueError("unsupported_paper_price_venue")


async def fetch_snapshot(now=None, venue=None, symbol="ETH-USD"):
    symbol = validate_symbol(symbol)
    research = await crypto_market_data.fetch_snapshot(now=now, symbol=symbol)
    if research.get("status") != "OK":
        research = await binance_us_data.fetch_snapshot(now=now, symbol=symbol)
    if research.get("status") != "OK":
        return research
    try:
        quote = await fetch_quote(now=now, venue=venue, symbol=symbol)
    except (ValueError, KeyError, TypeError):
        return {"status": "UNAVAILABLE", "reason": "paper_price_unavailable"}
    return {
        **research,
        "venue": quote["venue"],
        "quote": quote,
        "research_venue": research["venue"],
        "book_venue": research["venue"],
        "external_depth_is_not_robinhood": True,
    }
