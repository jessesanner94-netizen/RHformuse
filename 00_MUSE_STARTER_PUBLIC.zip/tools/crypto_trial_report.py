"""Read-only summary of a prospective JEV comparison; no models or provider calls."""

import argparse
import json
import sqlite3
from pathlib import Path

from tools.crypto_jev_trial import TRIAL_ID


def report(path, trial_id=TRIAL_ID):
    with sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True) as db:
        rows = [
            (at, kind, json.loads(body))
            for at, kind, body in db.execute(
                "SELECT at,kind,body FROM events WHERE kind IN "
                "('jev_trial_reserved','jev_trial_outcome','luna_decision','paper_exit',"
                "'cycle_unavailable') ORDER BY id"
            )
        ]
    samples = []
    for at, kind, body in rows:
        if kind != "jev_trial_reserved" or body.get("trial_id") != trial_id:
            continue
        observation = body.get("observation_id")
        matches = [
            b
            for _, k, b in rows
            if k == "jev_trial_outcome"
            and b.get("trial_id") == trial_id
            and b.get("observation_id") == observation
        ]
        outcome = matches[-1] if matches else {}
        decisions = [
            b["decision"]
            for _, k, b in rows
            if k == "luna_decision"
            and (b.get("jev_trial") or {}).get("trial_id") == trial_id
            and b.get("jev_observation_id") == observation
        ]
        position = (outcome.get("paper") or {}).get("position") or {}
        exits = [
            b
            for _, k, b in rows
            if k == "paper_exit" and position.get("id") and b.get("position_id") == position["id"]
        ]
        errors = [
            b
            for _, k, b in rows
            if k == "cycle_unavailable"
            and (b.get("jev_trial") or {}).get("observation_id") == observation
            and (b.get("jev_trial") or {}).get("trial_id") == trial_id
        ]
        samples.append(
            {
                "at": at,
                "symbol": body["symbol"],
                "slot": body.get("slot"),
                "jev_scores": (body.get("jev") or {}).get("scores"),
                "luna_decision": decisions[-1] if decisions else None,
                "status": outcome.get("status", "ERROR" if errors else "NO_OUTCOME_RECORDED"),
                "reason": outcome.get("reason"),
                "net_pnl": exits[-1]["net_pnl"] if exits else None,
            }
        )
    return {
        "trial_id": trial_id,
        "reviews_reserved": len(samples),
        "samples": samples,
        "limitation": "Prospective selected sample, not proof of profitability; "
        "unclosed or absent trades have no realized outcome.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trial-id", default=TRIAL_ID)
    parser.add_argument("--ledger", default="state/research/crypto_paper.sqlite3")
    args = parser.parse_args()
    print(json.dumps(report(args.ledger, args.trial_id), indent=2))
