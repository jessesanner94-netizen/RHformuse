"""Evaluate position-management triggers without calling a model or placing orders."""

from __future__ import annotations

import argparse
import json
import math
from collections.abc import Mapping
from pathlib import Path
from typing import Any

POSITION_STYLES = {"DAY", "SWING"}
PROTECTIVE_ORDER_STATES = {"WORKING", "FILLED", "MISSING", "NOT_REQUIRED"}
POLICY_FIELDS = (
    "stop_loss_percent",
    "take_profit_percent",
    "trailing_activation_percent",
    "trailing_giveback_percent",
    "day_trade_exit_minutes_before_close",
)


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def _trigger(code: str, *, contract_identifier: str | None = None) -> dict[str, str]:
    result = {"code": code}
    if contract_identifier is not None:
        result["contract_identifier"] = contract_identifier
    return result


def _validate_policy(policy: Any) -> tuple[dict[str, float | bool] | None, list[str]]:
    if not isinstance(policy, Mapping):
        return None, ["policy"]

    normalized: dict[str, float | bool] = {}
    invalid: list[str] = []
    for field in POLICY_FIELDS:
        value = _number(policy.get(field))
        if value is None:
            invalid.append(f"policy.{field}")
        else:
            normalized[field] = value

    require_protective_order = policy.get("require_protective_order")
    if not isinstance(require_protective_order, bool):
        invalid.append("policy.require_protective_order")
    else:
        normalized["require_protective_order"] = require_protective_order

    trailing_enabled = policy.get("trailing_enabled")
    if not isinstance(trailing_enabled, bool):
        invalid.append("policy.trailing_enabled")
    else:
        normalized["trailing_enabled"] = trailing_enabled

    bounded_percent_fields = (
        "stop_loss_percent",
        "trailing_giveback_percent",
    )
    for field in bounded_percent_fields:
        value = normalized.get(field)
        if isinstance(value, float) and not 0 < value < 100:
            invalid.append(f"policy.{field}")

    positive_fields = ("take_profit_percent", "trailing_activation_percent")
    for field in positive_fields:
        value = normalized.get(field)
        if isinstance(value, float) and value <= 0:
            invalid.append(f"policy.{field}")

    minutes = normalized.get("day_trade_exit_minutes_before_close")
    if isinstance(minutes, float) and minutes < 0:
        invalid.append("policy.day_trade_exit_minutes_before_close")

    return (normalized if not invalid else None), sorted(set(invalid))


def _position_metrics(
    position: Mapping[str, Any], policy: Mapping[str, float | bool]
) -> tuple[dict[str, Any], list[dict[str, str]], list[str]]:
    contract_id = position.get("contract_identifier")
    symbol = position.get("symbol")
    invalid: list[str] = []
    if not isinstance(contract_id, str) or not contract_id.strip():
        invalid.append("contract_identifier")
        contract_id = None
    if not isinstance(symbol, str) or not symbol.strip():
        invalid.append("symbol")

    style = position.get("trade_style")
    if style not in POSITION_STYLES:
        invalid.append("trade_style")

    quantity = _number(position.get("quantity"))
    if quantity is None or quantity <= 0 or not quantity.is_integer():
        invalid.append("quantity")

    entry = _number(position.get("entry_price"))
    current = _number(position.get("current_mark"))
    high_water = _number(position.get("high_water_mark"))
    if entry is None or entry <= 0:
        invalid.append("entry_price")
    if current is None or current < 0:
        invalid.append("current_mark")
    if high_water is None or high_water <= 0:
        invalid.append("high_water_mark")

    for field in ("quote_is_fresh", "hold_deadline_reached", "event_risk_changed"):
        if not isinstance(position.get(field), bool):
            invalid.append(field)
    if not isinstance(position.get("thesis_invalidated"), bool):
        invalid.append("thesis_invalidated")

    protective_state = position.get("protective_order_state")
    if protective_state not in PROTECTIVE_ORDER_STATES:
        invalid.append("protective_order_state")

    minutes_to_close = _number(position.get("minutes_to_close"))
    if style == "DAY" and (minutes_to_close is None or minutes_to_close < 0):
        invalid.append("minutes_to_close")

    if invalid:
        return {}, [], sorted(set(invalid))

    assert contract_id is not None
    assert entry is not None
    assert current is not None
    assert high_water is not None

    effective_high = max(high_water, current)
    return_percent = ((current - entry) / entry) * 100
    high_return_percent = ((effective_high - entry) / entry) * 100
    drawdown_percent = ((effective_high - current) / effective_high) * 100
    triggers: list[dict[str, str]] = []

    if position["quote_is_fresh"] is not True:
        triggers.append(_trigger("STALE_POSITION_QUOTE", contract_identifier=contract_id))
    else:
        if return_percent <= -float(policy["stop_loss_percent"]):
            triggers.append(_trigger("STOP_LOSS_REACHED", contract_identifier=contract_id))
        if return_percent >= float(policy["take_profit_percent"]):
            triggers.append(_trigger("TAKE_PROFIT_REACHED", contract_identifier=contract_id))
        if (
            policy["trailing_enabled"] is True
            and high_return_percent >= float(policy["trailing_activation_percent"])
            and drawdown_percent >= float(policy["trailing_giveback_percent"])
        ):
            triggers.append(_trigger("TRAILING_EXIT_REACHED", contract_identifier=contract_id))

    if policy["require_protective_order"] is True and protective_state in {
        "MISSING",
        "NOT_REQUIRED",
    }:
        triggers.append(_trigger("PROTECTIVE_ORDER_MISSING", contract_identifier=contract_id))
    if protective_state == "FILLED":
        triggers.append(_trigger("PROTECTIVE_ORDER_FILLED", contract_identifier=contract_id))
    if position["thesis_invalidated"] is True:
        triggers.append(_trigger("THESIS_INVALIDATED", contract_identifier=contract_id))
    if position["event_risk_changed"] is True:
        triggers.append(_trigger("EVENT_RISK_CHANGED", contract_identifier=contract_id))
    if (
        style == "DAY"
        and minutes_to_close is not None
        and minutes_to_close <= float(policy["day_trade_exit_minutes_before_close"])
    ):
        triggers.append(_trigger("DAY_TRADE_TIME_EXIT", contract_identifier=contract_id))
    if style == "SWING" and position["hold_deadline_reached"] is True:
        triggers.append(_trigger("SWING_HOLD_DEADLINE", contract_identifier=contract_id))

    metrics = {
        "contract_identifier": contract_id,
        "symbol": symbol,
        "trade_style": style,
        "quantity": int(quantity),
        "entry_price": round(entry, 4),
        "current_mark": round(current, 4),
        "high_water_mark": round(effective_high, 4),
        "return_percent": round(return_percent, 2),
        "drawdown_from_high_percent": round(drawdown_percent, 2),
    }
    return metrics, triggers, []


def run_monitor(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Return deterministic wake/no-wake triggers; never mutate broker or project state."""

    triggers: list[dict[str, str]] = []
    invalid_fields: list[str] = []
    policy, policy_invalid = _validate_policy(payload.get("policy"))
    invalid_fields.extend(policy_invalid)

    if not isinstance(payload.get("snapshot_is_fresh"), bool):
        invalid_fields.append("snapshot_is_fresh")
    elif payload["snapshot_is_fresh"] is not True:
        triggers.append(_trigger("STALE_BROKER_SNAPSHOT"))

    if not isinstance(payload.get("broker_reconciled"), bool):
        invalid_fields.append("broker_reconciled")
    elif payload["broker_reconciled"] is not True:
        triggers.append(_trigger("BROKER_RECONCILIATION_REQUIRED"))

    positions = payload.get("positions")
    if not isinstance(positions, list):
        invalid_fields.append("positions")
        positions = []

    results: list[dict[str, Any]] = []
    if policy is not None:
        seen_contracts: set[str] = set()
        for index, position in enumerate(positions):
            if not isinstance(position, Mapping):
                invalid_fields.append(f"positions[{index}]")
                continue
            metrics, position_triggers, position_invalid = _position_metrics(position, policy)
            invalid_fields.extend(f"positions[{index}].{field}" for field in position_invalid)
            contract_id = metrics.get("contract_identifier")
            if contract_id in seen_contracts:
                invalid_fields.append(f"positions[{index}].contract_identifier_duplicate")
            elif isinstance(contract_id, str):
                seen_contracts.add(contract_id)
            if metrics:
                metrics["triggers"] = [item["code"] for item in position_triggers]
                results.append(metrics)
                triggers.extend(position_triggers)

    if invalid_fields:
        triggers.insert(0, _trigger("INVALID_MONITOR_INPUT"))

    wake_codex = bool(triggers)
    return {
        "mode": "DETERMINISTIC_DRY_RUN",
        "status": "ATTENTION_REQUIRED" if wake_codex else "QUIET",
        "wake_codex": wake_codex,
        "triggers": triggers,
        "invalid_fields": sorted(set(invalid_fields)),
        "positions_evaluated": len(results),
        "positions": results,
        "orders_placed": 0,
        "orders_cancelled": 0,
        "persistent_writes": [],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        payload = {}
    print(json.dumps(run_monitor(payload), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
