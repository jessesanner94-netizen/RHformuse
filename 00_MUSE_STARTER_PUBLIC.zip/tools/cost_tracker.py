"""Dry-run-first AI/data cost ledger and economic-efficiency calculations."""

from __future__ import annotations

import argparse
import json
import os
import tempfile
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

ALLOWED_CATEGORIES = {"codex", "unusual_whales", "api", "data", "other"}


@dataclass(frozen=True)
class CostRecord:
    timestamp: str
    category: str
    amount: str
    attribution: str
    note: str = ""

    @classmethod
    def create(
        cls, *, category: str, amount: str | float, attribution: str, note: str = ""
    ) -> CostRecord:
        normalized_category = category.strip().lower()
        if normalized_category not in ALLOWED_CATEGORIES:
            raise ValueError(f"unsupported category: {category}")
        decimal_amount = _money(amount)
        if decimal_amount < 0:
            raise ValueError("cost amount cannot be negative")
        if not attribution.strip():
            raise ValueError("attribution is required")
        return cls(
            timestamp=datetime.now(UTC).isoformat(),
            category=normalized_category,
            amount=str(decimal_amount),
            attribution=attribution.strip(),
            note=note.strip(),
        )


def _money(value: Any) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"invalid monetary value: {value!r}") from exc
    if not result.is_finite():
        raise ValueError("monetary value must be finite")
    return result


def read_ledger(path: str | Path) -> list[dict[str, Any]]:
    ledger_path = Path(path)
    if not ledger_path.exists():
        return []
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(ledger_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid ledger JSON on line {line_number}") from exc
        if not isinstance(record, dict):
            raise ValueError(f"ledger line {line_number} is not an object")
        records.append(record)
    return records


def summarize(
    records: Iterable[Mapping[str, Any]], *, realized_net_trading_pnl: str | float
) -> dict[str, Any]:
    totals = {category: Decimal("0") for category in sorted(ALLOWED_CATEGORIES)}
    record_count = 0
    for record in records:
        category = str(record.get("category", "")).lower()
        if category not in totals:
            raise ValueError(f"unsupported ledger category: {category}")
        amount = _money(record.get("amount"))
        if amount < 0:
            raise ValueError("ledger costs cannot be negative")
        totals[category] += amount
        record_count += 1
    total_cost = sum(totals.values(), Decimal("0"))
    pnl = _money(realized_net_trading_pnl)
    economic_profit = pnl - total_cost
    efficiency = None if total_cost == 0 else pnl / total_cost
    return {
        "record_count": record_count,
        "category_costs": {key: str(value) for key, value in totals.items()},
        "total_incremental_ai_data_cost": str(total_cost),
        "realized_net_trading_pnl": str(pnl),
        "economic_profit": str(economic_profit),
        "ai_data_efficiency_ratio": None if efficiency is None else str(efficiency),
    }


def append_record(path: str | Path, record: CostRecord, *, commit: bool = False) -> dict[str, Any]:
    ledger_path = Path(path)
    preview = {
        "mode": "COMMIT" if commit else "DRY_RUN",
        "target": str(ledger_path),
        "record": asdict(record),
        "written": False,
    }
    if not commit:
        return preview
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    existing = ledger_path.read_text(encoding="utf-8") if ledger_path.exists() else ""
    content = existing
    if content and not content.endswith("\n"):
        content += "\n"
    content += json.dumps(asdict(record), sort_keys=True) + "\n"
    descriptor, temp_name = tempfile.mkstemp(
        prefix=f".{ledger_path.name}.", suffix=".tmp", dir=ledger_path.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, ledger_path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    preview["written"] = True
    return preview


def compare_uw_decisions(
    *, pre_action: str, pre_conviction: float, post_action: str, post_conviction: float
) -> dict[str, Any]:
    if not 0 <= pre_conviction <= 1 or not 0 <= post_conviction <= 1:
        raise ValueError("conviction values must be between 0 and 1")
    return {
        "pre_uw": {"action": pre_action.upper(), "conviction": pre_conviction},
        "post_uw": {"action": post_action.upper(), "conviction": post_conviction},
        "action_changed": pre_action.upper() != post_action.upper(),
        "conviction_delta": round(post_conviction - pre_conviction, 6),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    summary_parser = subparsers.add_parser("summary")
    summary_parser.add_argument("--ledger", type=Path, default=Path("state/cost_ledger.jsonl"))
    summary_parser.add_argument("--realized-net-pnl", required=True)

    record_parser = subparsers.add_parser("record")
    record_parser.add_argument("--ledger", type=Path, default=Path("state/cost_ledger.jsonl"))
    record_parser.add_argument("--category", required=True, choices=sorted(ALLOWED_CATEGORIES))
    record_parser.add_argument("--amount", required=True)
    record_parser.add_argument("--attribution", required=True)
    record_parser.add_argument("--note", default="")
    record_parser.add_argument("--commit", action="store_true")

    uw_parser = subparsers.add_parser("uw-compare")
    uw_parser.add_argument("--pre-action", required=True)
    uw_parser.add_argument("--pre-conviction", type=float, required=True)
    uw_parser.add_argument("--post-action", required=True)
    uw_parser.add_argument("--post-conviction", type=float, required=True)

    args = parser.parse_args()
    if args.command == "summary":
        result = summarize(read_ledger(args.ledger), realized_net_trading_pnl=args.realized_net_pnl)
    elif args.command == "record":
        record = CostRecord.create(
            category=args.category,
            amount=args.amount,
            attribution=args.attribution,
            note=args.note,
        )
        result = append_record(args.ledger, record, commit=args.commit)
    else:
        result = compare_uw_decisions(
            pre_action=args.pre_action,
            pre_conviction=args.pre_conviction,
            post_action=args.post_action,
            post_conviction=args.post_conviction,
        )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
