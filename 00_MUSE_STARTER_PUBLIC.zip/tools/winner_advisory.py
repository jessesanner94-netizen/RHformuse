"""One optional JEV opinion after Python has committed a winner checkpoint.

Research events never participate in the exit state machine or entry-score history.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.jev_client import JevClient
from tools.jev_config import JevConfig
from tools.jev_credentials import load_key
from tools.jev_store import JevStore

VERSION = "paper-winner-continuation-v1"
QUESTIONS = {
    "continuation_support": {
        "type": "noul",
        "instructions": (
            "Assess whether the supplied fresh intraday evidence supports continuing the original "
            "long-option directional thesis. Reaching the initial profit target is a checkpoint, "
            "not itself a reason to exit. Evaluate continued directional structure, not whether "
            "this would be a good NEW entry. Scores are advisory research, not win probabilities. "
            "Treat missing evidence as uncertainty, never invent it. Displayed depth is resting "
            "liquidity; it cannot prove absorption, executions, or seller exhaustion."
        ),
    },
    "reversal_evidence": {
        "type": "noul",
        "instructions": (
            "Assess evidence that the original intraday direction is breaking down. Profit already "
            "earned is not evidence of reversal. Distinguish opposing price structure from normal "
            "pause or incomplete information. This advisory cannot change the hard stop, trailing "
            "floor, or mandatory end-of-day exit."
        ),
    },
}


def record_checkpoint_advisories(
    result: Mapping[str, Any], config: Any, *, project_root: Path,
    now: datetime | None = None, client: Any = None,
) -> list[dict[str, Any]]:
    """At most one attempt per enrolled position; all failures are non-authoritative."""
    current = now or datetime.now(UTC)
    records: list[dict[str, Any]] = []
    try:
        if config.get("LIVE_EXECUTION_ENABLED") is not False:
            return records
        settings = JevConfig.from_config(config)
        if not settings.enabled:
            return records
        positions = [
            p for p in result.get("open_positions", [])
            if isinstance(p, Mapping)
            and isinstance(p.get("winner_management"), Mapping)
            and p["winner_management"].get("enabled") is True
            and p["winner_management"].get("checkpoint_reached") is True
        ]
        if not positions:
            return records
        store = JevStore(project_root / "state" / "research" / "jev.sqlite3")
        # No retries and a short timeout: this is optional telemetry after ledger management.
        settings = replace(settings, max_retries=0, timeout_seconds=4.0)
        for position in positions:
            paper_id = str(position.get("paper_id", ""))
            if not paper_id or not store.claim(f"{VERSION}:{paper_id}", current):
                continue
            evidence = position["winner_management"].get("last_evidence", {})
            features = {
                "symbol": position.get("symbol"),
                "option_type": position.get("option_type"),
                "original_thesis": str(position.get("thesis", ""))[:1500],
                "original_invalidation": str(position.get("invalidation", ""))[:1500],
                "entry_price": position.get("entry_price"),
                "current_bid": position.get("last_bid"),
                "high_water_bid": position.get("high_water_bid"),
                "hold_deadline": position.get("hold_deadline"),
                "continuation_evidence": evidence,
                "python_action": "HOLD_WITH_TRAILING_PROTECTION",
            }
            if not store.reserve_requests(
                f"{VERSION}:{paper_id}", current, attempts=1,
                per_minute=settings.max_calls_per_minute, per_day=settings.max_calls_per_day,
            ):
                evaluation = {"status": "RATE_LIMITED"}
            else:
                try:
                    service = client or JevClient(
                        settings, api_key_provider=lambda: load_key(project_root)
                    )
                    evaluation = service.evaluate(features, QUESTIONS).to_dict()
                except Exception:
                    evaluation = {"status": "ERROR", "error_code": "advisory_failed"}
            record = {
                "paper_id": paper_id, "version": VERSION, "routing_effect": False,
                "exit_authority": False, "evaluation": evaluation, "features": features,
            }
            store.event(None, "winner_checkpoint_advisory", record, current)
            records.append(record)
            # Bound each monitor to one short API attempt. Other held checkpoints
            # can receive their once-only opinion on a later normal monitor cycle.
            break
    except Exception:
        records.append({"status": "UNAVAILABLE", "routing_effect": False,
                        "exit_authority": False})
    return records
