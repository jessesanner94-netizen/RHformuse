"""Free scheduled macro-event evidence. Never used to inhibit position exits."""

import calendar
import json
import re
from datetime import UTC, datetime, timedelta
from html import unescape
from pathlib import Path
from urllib.request import Request, urlopen
from uuid import uuid4
from zoneinfo import ZoneInfo

from tools.config import TradingConfig

ET = ZoneInfo("America/New_York")
FED = "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"
BEA = "https://www.bea.gov/news/schedule/ics/online-calendar-subscription.ics"
BLS_NAMES = (
    "Consumer Price Index", "Producer Price Index", "Employment Situation",
    "Job Openings and Labor Turnover", "Employment Cost Index",
)


def fetch_text(url):
    request = Request(url, headers={"User-Agent": "RobinhoodPaperResearch/1.0"})
    with urlopen(request, timeout=12) as response:
        return response.read(2_000_000).decode("utf-8-sig")


def event(name, at, source, kind="RELEASE"):
    return {"name": name, "at": at.astimezone(UTC).isoformat(),
            "source": source, "kind": kind}


def parse_fed(body, year):
    section = re.search(rf"{year} FOMC Meetings(.*?)(?=\d{{4}} FOMC Meetings|\Z)",
                        body, re.S)
    if not section:
        raise ValueError("Fed calendar missing current year")
    pairs = re.findall(
        r'fomc-meeting__month[^>]*>(.*?)</div>\s*'
        r'<div[^>]*fomc-meeting__date[^>]*>(.*?)</div>', section[1], re.S)
    events = []
    for month, days in pairs:
        month = re.sub("<[^>]+>", "", month).strip().split("/")[-1]
        days = unescape(re.sub("<[^>]+>", "", days)).strip()
        # Ignore unscheduled notation votes; do not invent release times for them.
        if not re.fullmatch(r"\d{1,2}[-–]\d{1,2}\*?", days):
            continue
        month_number = next((i for i in range(1, 13)
                             if calendar.month_name[i].startswith(month)), None)
        if month_number is None:
            raise ValueError("Unrecognized FOMC month")
        day = int(re.split("[-–]", days.rstrip("*"))[-1])
        at = datetime(year, month_number, day, 14, tzinfo=ET)
        events.append(event("FOMC decision / press conference", at, FED, "FOMC"))
    if len(events) != 8:
        raise ValueError("Expected eight scheduled FOMC meetings")
    return events


def parse_bea(body):
    body = re.sub(r"\r?\n[ \t]", "", body)
    events = []
    for block in body.split("BEGIN:VEVENT")[1:]:
        title = re.search(r"(?m)^SUMMARY:(.+)", block)
        if not title:
            continue
        title = title[1].strip().replace("\\,", ",")
        if not title.startswith(("Gross Domestic Product,", "Personal Income and Outlays,")):
            continue
        stamp = re.search(r"(?m)^DTSTART(?:;VALUE=DATE-TIME)?:(\d{8}T\d{6}Z)\s*$", block)
        if not stamp:
            raise ValueError("BEA release has missing/unsupported timestamp")
        at = datetime.strptime(stamp[1], "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
        events.append(event(title, at, BEA))
    if not events:
        raise ValueError("No GDP/PCE calendar entries")
    return events


def parse_bls_reader(body, year, month, source):
    events = []
    for line in body.splitlines():
        cells = [cell.strip().replace("**", "") for cell in line.split("|")]
        if len(cells) < 5 or not any(cells[3].startswith(n) for n in BLS_NAMES):
            continue
        at = datetime.strptime(cells[1] + " " + cells[2],
                               "%A, %B %d, %Y %I:%M %p").replace(tzinfo=ET)
        if (at.year, at.month) != (year, month):
            raise ValueError("BLS calendar month mismatch")
        events.append(event(cells[3], at, source))
    if not all(any(e["name"].startswith(n) for e in events) for n in BLS_NAMES[:3]):
        raise ValueError("BLS calendar missing CPI/PPI/jobs dates")
    return events


def load_calendar(now, root, fetcher=fetch_text, *, allow_refresh=True):
    """Refresh at most hourly; retain failed status for five minutes, not forever."""
    path = root / "state" / "economic_calendar.json"
    local = now.astimezone(ET)
    period = local.strftime("%Y-%m")
    try:
        cached = json.loads(path.read_text(encoding="utf-8"))
        age = (now - datetime.fromisoformat(cached["fetched_at"])).total_seconds()
        ttl = 3600 if cached.get("status") == "OK" else 300
        if cached.get("period") == period and 0 <= age < ttl:
            return cached
    except (OSError, ValueError, KeyError, TypeError):
        pass
    if not allow_refresh:
        return {"status": "UNAVAILABLE", "period": period, "events": [],
                "fetched_at": now.isoformat(), "errors": ["offline_calendar_missing_or_stale"],
                "coverage": "UNAVAILABLE"}
    events, errors = [], []
    bls = f"https://www.bls.gov/schedule/{local.year}/{local.month:02d}_sched_list.htm"
    readers = (
        ("Fed", lambda: parse_fed(fetcher(FED), local.year)),
        ("BEA", lambda: parse_bea(fetcher(BEA))),
        # BLS returns 403 to this host; the reader renders the official list view.
        ("BLS via Jina reader", lambda: parse_bls_reader(
            fetcher("https://r.jina.ai/" + bls), local.year, local.month, bls)),
    )
    for name, reader in readers:
        try:
            rows = reader()
            if name == "BEA" and max(datetime.fromisoformat(e["at"]) for e in rows) < now:
                raise ValueError("BEA calendar coverage expired")
            events.extend(rows)
        except Exception as exc:
            errors.append(f"{name}: {type(exc).__name__}: {str(exc)[:120]}")
    result = {"status": "UNAVAILABLE" if errors else "OK", "period": period,
              "fetched_at": now.isoformat(), "events": sorted(events, key=lambda e: e["at"]),
              "errors": errors, "coverage": "FOMC, CPI, PPI, payrolls, JOLTS, ECI, GDP, PCE"}
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid4().hex + ".tmp")
    try:
        temporary.write_text(json.dumps(result, indent=2), encoding="utf-8")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)
    return result


def economic_context(now: datetime, config: TradingConfig, *, project_root: Path | None = None):
    if not config.get("ECONOMIC_CALENDAR_ENABLED", False):
        return {"status": "DISABLED", "entry_allowed": True}
    root = project_root or (config.source.parent if config.source else None)
    if root is None:
        return {"status": "UNAVAILABLE", "entry_allowed": False,
                "reason": "economic_calendar_root_missing"}
    try:
        if config.get("ECONOMIC_CALENDAR_OFFLINE") is True:
            calendar_data = load_calendar(now, root, allow_refresh=False)
        else:
            calendar_data = load_calendar(now, root)
        relevant, blocked = [], []
        for item in calendar_data["events"]:
            at = datetime.fromisoformat(item["at"])
            prefix = "FOMC" if item["kind"] == "FOMC" else "MACRO"
            before = int(config.get(prefix + "_BLACKOUT_MINUTES_BEFORE", 30))
            after = int(config.get(prefix + "_BLACKOUT_MINUTES_AFTER", 30))
            if at - timedelta(minutes=before) <= now <= at + timedelta(minutes=after):
                blocked.append(item)
            if now - timedelta(hours=8) <= at <= now + timedelta(days=7):
                relevant.append({**item, "phase": "RELEASED" if at <= now else "UPCOMING"})
        allowed = calendar_data["status"] == "OK" and not blocked
        return {"status": calendar_data["status"], "entry_allowed": allowed,
                "reason": "macro_event_blackout" if blocked else (
                    "calendar_clear" if allowed else "economic_calendar_unavailable"),
                "blocked_events": blocked, "events": relevant[:10],
                "errors": calendar_data["errors"], "fetched_at": calendar_data["fetched_at"],
                "coverage": calendar_data["coverage"],
                "note": "Schedule only; no release outcome/direction inferred. BLS: current month."}
    except Exception as exc:
        return {"status": "UNAVAILABLE", "entry_allowed": False,
                "reason": "economic_calendar_unavailable", "error": str(exc)[:160]}
