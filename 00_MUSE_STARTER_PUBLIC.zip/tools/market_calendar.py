"""Shared US equity session calendar for entries and software exit deadlines.

NYSE regular-session hours are intentionally used for SPY/QQQ, including 13:00 early
closes; the program does not rely on the extra options-only closing minutes.
"""

from datetime import UTC, date, datetime, timedelta
from functools import lru_cache
from zoneinfo import ZoneInfo

from tools.config import TradingConfig

EASTERN = ZoneInfo("America/New_York")


@lru_cache(maxsize=64)
def session_hours(day: date) -> tuple[datetime, datetime] | None:
    import pandas_market_calendars as mcal

    schedule = mcal.get_calendar("NYSE").schedule(start_date=day, end_date=day)
    if schedule.empty:
        return None
    row = schedule.iloc[0]
    return row["market_open"].to_pydatetime(), row["market_close"].to_pydatetime()


def market_window(now: datetime) -> tuple[bool, str]:
    local = now.astimezone(EASTERN)
    if local.weekday() >= 5:
        return False, "weekend"
    hours = session_hours(local.date())
    if hours is None:
        return False, "market_holiday"
    return hours[0] <= now <= hours[1], "regular_market_closed"


def entry_allowed(now: datetime, config: TradingConfig, style: str) -> bool:
    if config.get("DAY_ONLY_OPTIONS") is True and style != "DAY":
        return False
    if style not in {"DAY", "SWING"}:
        return False
    hours = session_hours(now.astimezone(EASTERN).date())
    if hours is None:
        return False
    cutoff = (
        f"{style}_TRADE_ENTRY_CUTOFF_MINUTES_BEFORE_CLOSE"
        if style == "DAY"
        else ("SWING_ENTRY_CUTOFF_MINUTES_BEFORE_CLOSE")
    )
    start = hours[0] + timedelta(minutes=int(config.get("MINUTES_AFTER_OPEN_BEFORE_NEW_ENTRY")))
    end = hours[1] - timedelta(minutes=int(config.get(cutoff)))
    if not start <= now <= end:
        return False
    from tools.economic_calendar import economic_context

    return economic_context(now, config)["entry_allowed"]


def day_deadline(now: datetime, minutes_before_close: int) -> str:
    hours = session_hours(now.astimezone(EASTERN).date())
    if hours is None:
        raise ValueError("no regular trading session for day deadline")
    return (hours[1] - timedelta(minutes=minutes_before_close)).astimezone(UTC).isoformat()
