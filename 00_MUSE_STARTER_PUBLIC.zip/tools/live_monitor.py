"""Adapt a live read-only Robinhood snapshot to the deterministic position monitor."""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import re
from collections.abc import Mapping
from datetime import UTC, date, datetime, time
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.config import load_config
from tools.position_monitor import run_monitor
from tools.robinhood_mcp import fetch_snapshot
from tools.state_manager import ProjectPosition, load_project_positions, reconcile_positions

EASTERN = ZoneInfo("America/New_York")
NUMBER = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)")
QUOTE_ID_FIELDS = ("instrument_id", "option_id", "id")
MARK_FIELDS = ("adjusted_mark_price", "mark_price", "mark", "mid_price")
QUOTE_TIME_FIELDS = ("updated_at", "last_trade_time", "timestamp")


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    elif isinstance(value, str):
        match = NUMBER.search(value.replace(",", ""))
        if not match:
            return None
        number = float(match.group())
    else:
        return None
    return number if math.isfinite(number) else None


def _timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    normalized = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _is_fresh(value: Any, *, now: datetime, maximum_age_seconds: int) -> bool:
    parsed = _timestamp(value)
    if parsed is None:
        return False
    age = (now.astimezone(UTC) - parsed).total_seconds()
    return -30 <= age <= maximum_age_seconds


def _position_rows(snapshot: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for raw in snapshot.get("positions", []):
        if not isinstance(raw, Mapping):
            rows.append({})
            continue
        contract_id = raw.get("option_id") or raw.get("instrument_id")
        quantity = _number(raw.get("quantity"))
        rows.append(
            {
                "contract_identifier": contract_id,
                "quantity": quantity,
                "raw": dict(raw),
            }
        )
    return rows


def _open_order_rows(snapshot: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for order in snapshot.get("open_option_orders", []):
        if not isinstance(order, Mapping):
            rows.append({})
            continue
        legs = order.get("legs")
        candidates = legs if isinstance(legs, list) and legs else [order]
        for leg in candidates:
            if not isinstance(leg, Mapping):
                rows.append({})
                continue
            contract_id = (
                leg.get("option_id")
                or leg.get("instrument_id")
                or order.get("option_id")
                or order.get("instrument_id")
            )
            rows.append(
                {
                    "contract_identifier": contract_id,
                    "position_effect": str(
                        leg.get("position_effect") or order.get("position_effect") or ""
                    ).lower(),
                    "order": dict(order),
                }
            )
    return rows


def _quote_body(row: Mapping[str, Any]) -> Mapping[str, Any]:
    nested = row.get("quote")
    return nested if isinstance(nested, Mapping) else row


def _quote_id(row: Mapping[str, Any]) -> str | None:
    body = _quote_body(row)
    for source in (body, row):
        for field in QUOTE_ID_FIELDS:
            value = source.get(field)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def _quote_mark(row: Mapping[str, Any]) -> float | None:
    body = _quote_body(row)
    for field in MARK_FIELDS:
        value = _number(body.get(field))
        if value is not None and value >= 0:
            return value
    bid = _number(body.get("bid_price") or body.get("bid"))
    ask = _number(body.get("ask_price") or body.get("ask"))
    if bid is None or ask is None or bid < 0 or ask < bid:
        return None
    return (bid + ask) / 2


def _quote_time(row: Mapping[str, Any]) -> Any:
    body = _quote_body(row)
    for field in QUOTE_TIME_FIELDS:
        if body.get(field):
            return body[field]
    return None


def _quote_map(snapshot: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for raw in snapshot.get("option_quotes", []):
        if isinstance(raw, Mapping):
            contract_id = _quote_id(raw)
            if contract_id:
                result[contract_id] = raw
    return result


def _minutes_to_close(now: datetime) -> float:
    local = now.astimezone(EASTERN)
    close = datetime.combine(local.date(), time(16, 0), tzinfo=EASTERN)
    return max(0.0, (close - local).total_seconds() / 60)


def _deadline_reached(raw: str, *, now: datetime) -> bool:
    value = raw.strip()
    if not value:
        raise ValueError("time stop is missing")
    normalized = value.replace("Z", "+00:00")
    try:
        deadline: date | datetime = datetime.fromisoformat(normalized)
    except ValueError:
        try:
            deadline = date.fromisoformat(value)
        except ValueError as exc:
            raise ValueError("time stop must be an ISO date or datetime") from exc
    if isinstance(deadline, datetime):
        if deadline.tzinfo is None:
            deadline = deadline.replace(tzinfo=EASTERN)
        return now.astimezone(UTC) >= deadline.astimezone(UTC)
    return now.astimezone(EASTERN).date() >= deadline


def _has_working_protective_order(contract_id: str, open_orders: list[dict[str, Any]]) -> bool:
    for row in open_orders:
        if row.get("contract_identifier") != contract_id:
            continue
        if row.get("position_effect") not in {"close", "closing"}:
            continue
        serialized = json.dumps(row.get("order", {}), sort_keys=True).lower()
        if "stop" in serialized:
            return True
    return False


def _state_position_to_monitor(
    project: ProjectPosition,
    *,
    quote: Mapping[str, Any],
    open_orders: list[dict[str, Any]],
    now: datetime,
    quote_max_age_seconds: int,
) -> dict[str, Any]:
    fields = project.fields
    style = fields.get("trade style", "").upper()
    entry = _number(fields.get("entry fill"))
    high_water = _number(fields.get("high-water option mark"))
    current = _quote_mark(quote)
    symbol = project.heading.split()[0].upper() if project.heading.split() else ""
    required = {
        "trade style": style,
        "entry fill": entry,
        "high-water option mark": high_water,
        "current option mark": current,
    }
    missing = [name for name, value in required.items() if value in {None, ""}]
    if missing:
        raise ValueError(f"{project.heading}: missing/invalid {', '.join(missing)}")
    assert entry is not None
    assert high_water is not None
    assert current is not None
    if style == "SWING":
        hold_deadline_reached = _deadline_reached(fields.get("time stop", ""), now=now)
    else:
        hold_deadline_reached = False
    thesis = fields.get("current thesis status", "").upper()
    if thesis not in {"INTACT", "WEAKENING", "INVALIDATED"}:
        raise ValueError(f"{project.heading}: current thesis status is unresolved")
    return {
        "contract_identifier": project.contract_identifier,
        "symbol": symbol,
        "trade_style": style,
        "quantity": project.quantity,
        "entry_price": entry,
        "current_mark": current,
        "high_water_mark": high_water,
        "quote_is_fresh": _is_fresh(
            _quote_time(quote), now=now, maximum_age_seconds=quote_max_age_seconds
        ),
        "protective_order_state": (
            "WORKING"
            if _has_working_protective_order(project.contract_identifier, open_orders)
            else "MISSING"
        ),
        "minutes_to_close": _minutes_to_close(now),
        "hold_deadline_reached": hold_deadline_reached,
        "event_risk_changed": False,
        "thesis_invalidated": thesis == "INVALIDATED",
    }


def adapt_snapshot(
    snapshot: Mapping[str, Any],
    *,
    project_positions: list[ProjectPosition],
    policy: Mapping[str, Any],
    now: datetime | None = None,
    snapshot_max_age_seconds: int = 240,
    quote_max_age_seconds: int = 180,
) -> dict[str, Any]:
    """Build and run the fail-closed monitor from a Robinhood snapshot."""

    current_time = now or datetime.now(UTC)
    snapshot_fresh = _is_fresh(
        snapshot.get("as_of"), now=current_time, maximum_age_seconds=snapshot_max_age_seconds
    )
    broker_positions = _position_rows(snapshot)
    open_orders = _open_order_rows(snapshot)
    reconciliation = reconcile_positions(
        project_positions,
        {
            "snapshot_is_fresh": snapshot_fresh,
            "positions": broker_positions,
            "open_orders": open_orders,
        },
    )
    quotes = _quote_map(snapshot)
    monitor_positions: list[dict[str, Any]] = []
    adapter_errors: list[str] = []
    if reconciliation.get("status") == "RECONCILED":
        for project in project_positions:
            quote = quotes.get(project.contract_identifier)
            if quote is None:
                adapter_errors.append(f"{project.heading}: option quote missing")
                continue
            try:
                monitor_positions.append(
                    _state_position_to_monitor(
                        project,
                        quote=quote,
                        open_orders=open_orders,
                        now=current_time,
                        quote_max_age_seconds=quote_max_age_seconds,
                    )
                )
            except ValueError as exc:
                adapter_errors.append(str(exc))
    result = run_monitor(
        {
            "snapshot_is_fresh": snapshot_fresh,
            "broker_reconciled": reconciliation.get("status") == "RECONCILED"
            and not adapter_errors,
            "positions": monitor_positions,
            "policy": dict(policy),
        }
    )
    result["snapshot_as_of"] = snapshot.get("as_of")
    result["reconciliation"] = reconciliation
    result["adapter_errors"] = adapter_errors
    result["account"] = snapshot.get("account")
    return result


async def run_live_monitor(project_root: Path) -> dict[str, Any]:
    config = load_config(project_root / "CONFIG.md")
    snapshot = await fetch_snapshot()
    poll_seconds = int(config.get("OPEN_POSITION_POLL_SECONDS"))
    return adapt_snapshot(
        snapshot,
        project_positions=load_project_positions(project_root / "state" / "POSITIONS.md"),
        policy=config.monitor_policy(),
        snapshot_max_age_seconds=max(180, poll_seconds * 2),
        quote_max_age_seconds=max(120, poll_seconds * 2),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    args = parser.parse_args()
    try:
        result = asyncio.run(run_live_monitor(args.project_root.resolve()))
    except Exception as exc:  # fail closed at the live adapter boundary
        result = {
            "status": "ATTENTION_REQUIRED",
            "wake_codex": True,
            "triggers": [{"code": "LIVE_MONITOR_ADAPTER_ERROR"}],
            "error": f"{type(exc).__name__}: {exc}",
            "orders_placed": 0,
            "orders_cancelled": 0,
        }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result.get("status") != "ERROR" else 1


if __name__ == "__main__":
    raise SystemExit(main())
