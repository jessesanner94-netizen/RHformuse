"""Optional Python -> JEV -> Luna research bridge; shadow cannot affect routing."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tools.jev_client import JevClient
from tools.jev_config import JevConfig
from tools.jev_credentials import load_key
from tools.jev_features import completed_minute, market_features, number
from tools.jev_questions import (
    BOOK_QUESTION_VERSION,
    QUESTION_VERSION,
    book_questions,
    market_questions,
)
from tools.jev_store import JevStore, serialized


def research_enabled(config: Any) -> bool:
    """An invalid optional configuration must not disable the baseline system."""
    try:
        return JevConfig.from_config(config).enabled
    except (ValueError, TypeError):
        return False


def escalation_policy(scores: Mapping[str, Any], config: Any, *, calls_remaining: int) -> dict:
    values = config if isinstance(config, Mapping) else config.values
    thresholds = {}
    for name, default in (
        ("JEV_SETUP_THRESHOLD", 0.85),
        ("JEV_ESCALATE_THRESHOLD", 0.8),
        ("JEV_MAX_FALSE_BREAKOUT", 0.25),
    ):
        value = number(values.get(name, default))
        if value is None or not 0 <= value <= 1:
            return {"would_escalate": None, "reason": "invalid_threshold"}
        thresholds[name] = value
    if values.get("ENABLE_DYNAMIC_LUNA_ESCALATION") is True and calls_remaining <= 3:
        thresholds["JEV_SETUP_THRESHOLD"] = min(0.99, thresholds["JEV_SETUP_THRESHOLD"] + 0.05)
    setup, escalation, false_breakout = (
        number(scores.get(key))
        for key in ("setup_quality", "escalate_to_luna", "false_breakout_risk")
    )
    if None in (setup, escalation, false_breakout):
        return {"would_escalate": None, "reason": "scores_unavailable"}
    qualifies = (
        setup >= thresholds["JEV_SETUP_THRESHOLD"]
        and escalation >= thresholds["JEV_ESCALATE_THRESHOLD"]
        and false_breakout <= thresholds["JEV_MAX_FALSE_BREAKOUT"]
    )
    return {
        "would_escalate": qualifies,
        "budget_available": calls_remaining > 0,
        "thresholds": thresholds,
        "threshold_status": "unvalidated_research_defaults",
    }


def evaluate_candidate(
    packet: Mapping[str, Any],
    config: Any,
    *,
    project_root: Path,
    now: datetime | None = None,
    book_summary: Mapping[str, Any] | None = None,
    calls_remaining: int = 0,
    client: Any = None,
) -> dict[str, Any]:
    """Log even failures; never leak exceptions, secrets, or account state to the caller."""
    current = now or datetime.now(UTC)
    try:
        settings = JevConfig.from_config(config)
        if not settings.enabled:
            return {"status": "DISABLED", "routing_effect": False}
        store = JevStore(project_root / "state" / "research" / "jev.sqlite3")
        features = market_features(packet)
        from tools.crypto_jev_trial import active

        crypto_trial = (
            features.get("candidate", {}).get("asset_type") == "SPOT_LONG"
            and features.get("candidate", {}).get("symbol") in {"ETH-USD", "BTC-USD"}
            and (
                active(config, current)
                or (
                    config.get("CRYPTO_JEV_ABOVE_AVERAGE") is True
                    and config.get("PAPER_TRADING_ENABLED") is True
                    and config.get("LIVE_EXECUTION_ENABLED") is False
                )
            )
        )
        options_review = (
            (config.get("PAPER_TRADING_ENABLED") is True
             or (config.get("LIVE_EXECUTION_ENABLED") is True
                 and config.get("OPTIONS_JEV_RANKING_ONLY") is True))
            and features.get("candidate", {}).get("symbol") in {"SPY", "QQQ"}
            and features.get("candidate", {}).get("option_type") in {"CALL", "PUT"}
        )
        questions = market_questions(
            crypto_review_trial=crypto_trial, options_review=options_review
        )
        versions = [QUESTION_VERSION]
        if options_review:
            versions.append("options-review-v3")
        if crypto_trial:
            versions.append("crypto-review-trial-v1")
        if settings.orderflow_features_enabled and book_summary is not None:
            features["orderbook"] = dict(book_summary)
            if settings.orderflow_jev_enabled and book_summary.get("status") == "OK":
                questions.update(book_questions())
                versions.append(BOOK_QUESTION_VERSION)
        # Deduplicate identical observations within a minute, including after process restart.
        key = hashlib.sha256(
            serialized(
                {
                    "features": {key: value for key, value in features.items() if key != "as_of"},
                    "minute": current.replace(second=0, microsecond=0).isoformat(),
                    "versions": versions,
                }
            ).encode()
        ).hexdigest()
        if not store.claim(key, current):
            store.event(None, "duplicate_evaluation", {"evaluation_key": key}, current)
            return {"status": "DUPLICATE", "routing_effect": False}
        if not store.reserve_requests(
            key,
            current,
            attempts=settings.max_retries + 1,
            per_minute=settings.max_calls_per_minute,
            per_day=settings.max_calls_per_day,
        ):
            evaluation = {"status": "RATE_LIMITED", "error_code": "local_request_budget"}
        else:
            service = client or JevClient(settings, api_key_provider=lambda: load_key(project_root))
            try:
                evaluation = service.evaluate(features, questions).to_dict()
            except Exception:
                evaluation = {"status": "ERROR", "error_code": "evaluation_failed"}
        scores = {
            name: answer["noul"]
            for name, answer in evaluation.get("answers", {}).items()
            if isinstance(answer, Mapping) and answer.get("type") == "noul"
        }
        evaluation.update(
            {
                "available_at": datetime.now(UTC).isoformat(),
                "scores": scores,
                "question_versions": versions,
                "policy": escalation_policy(scores, config, calls_remaining=calls_remaining),
                "shadow": settings.shadow_mode,
                "trade_print_judgments": "UNAVAILABLE_NO_EXECUTED_PRINT_FEED",
            }
        )
        candidate_id = str(features["candidate"].get("candidate_id", ""))
        history = [
            row
            for row in store.history(candidate_id, current)
            if row.get("question_versions") == versions
            and row.get("model") == evaluation.get("model")
        ]
        observation_id = store.observe(
            features=features,
            evaluation=evaluation,
            now=current,
            python_pass=True,
            shadow=settings.shadow_mode,
        )
        values = config if isinstance(config, Mapping) else config.values
        active = (
            not settings.shadow_mode
            and settings.escalation_enabled
            and values.get("LIVE_EXECUTION_ENABLED") is False
            and values.get("PAPER_TRADING_ENABLED") is True
        )
        return {
            **evaluation,
            "observation_id": observation_id,
            "candidate_id": candidate_id,
            "orderbook_context": features.get("orderbook"),
            "routing_effect": active and evaluation.get("status") == "OK",
            "recent_scores": [
                {"as_of": row["as_of"], "scores": row.get("scores", {})} for row in history
            ],
            "score_delta": {
                name: value - history[-1].get("scores", {}).get(name, value)
                for name, value in scores.items()
            }
            if history
            else {},
        }
    except Exception:
        # Optional research failure must never turn into an entry/exit system outage.
        return {
            "status": "UNAVAILABLE",
            "error_code": "jev_research_failure",
            "routing_effect": False,
        }


def record_routing(project_root: Path, result: Mapping[str, Any], *, now: datetime | None) -> None:
    """Store the actual model/cache/budget outcome separately from inference inputs."""
    evaluations = result.get("jev_evaluations", [])
    if not evaluations and not result.get("jev_ranking"):
        return
    try:
        store = JevStore(project_root / "state" / "research" / "jev.sqlite3")
        ranking = result.get("jev_ranking")
        if isinstance(ranking, dict):
            from tools.jev_relative import relative_setup_policy

            selected = (result.get("decision_packet") or {}).get("candidate", {})
            winner = next(
                (item for item in evaluations
                 if item.get("candidate_id") == ranking.get("selected_candidate_id")),
                {},
            )
            comparison = relative_setup_policy(
                store.path, winner, symbol=str(selected.get("symbol") or ""),
                now=now or datetime.now(UTC), option_type=selected.get("option_type"),
            )
            count = comparison["history_count"]
            comparison = {
                **comparison,
                "above_average": comparison["would_escalate"] if count else None,
                "routing_effect": False,
                "option_type": selected.get("option_type"),
                "candidate_id": ranking.get("selected_candidate_id"),
                "selection_count": len(ranking.get("candidate_ids", [])),
                "selection_kind": "watch" if ranking.get("selected_watch_ready") else "ranked",
            }
            comparison.pop("would_escalate", None)
            ranking["historical_comparison"] = comparison
            store.event(winner.get("observation_id"), "options_winner_comparison", comparison,
                        now or datetime.now(UTC))
        suppression_reasons = {
            str(candidate.get("candidate_id")): str(candidate.get("reason"))
            for candidate in result.get("suppressed_candidates", [])
            if candidate.get("candidate_id") and candidate.get("reason")
        }
        for evaluation in evaluations:
            identifier = evaluation.get("observation_id")
            if identifier:
                selected = (result.get("decision_packet") or {}).get("candidate", {})
                candidate_id = str(evaluation.get("candidate_id") or "")
                same = selected.get("candidate_id") == candidate_id
                decision = (result.get("decision") or {}) if same else {}
                suppression_reason = suppression_reasons.get(candidate_id) or decision.get("reason")
                suppressed = not same or suppression_reason in {
                    "jev_escalation_filtered",
                    "jev_active_unavailable",
                }
                store.event(
                    identifier,
                    "candidate_suppressed" if suppressed else "luna_routing",
                    {
                        "path": (
                            "python_book_jev_luna"
                            if evaluation.get("routing_effect") is True
                            and BOOK_QUESTION_VERSION in evaluation.get("question_versions", [])
                            else "python_jev_luna"
                            if evaluation.get("routing_effect") is True
                            else "python_luna"
                        ),
                        "decision": result.get("decision_verdict") if same else None,
                        "status": "SUPPRESSED" if suppressed else decision.get("status"),
                        "reason": suppression_reason
                        or ("candidate_not_selected" if suppressed else None),
                        "luna_escalated": decision.get("codex_invoked") is True,
                        "cached": decision.get("cached") is True,
                    },
                    now or datetime.now(UTC),
                )
    except Exception:
        return


def record_rejections(project_root: Path, rejections: list, *, now: datetime | None) -> None:
    try:
        store = JevStore(project_root / "state" / "research" / "jev.sqlite3")
        for rejection in rejections:
            store.observe(
                features={
                    "candidate": {
                        key: rejection.get(key) for key in ("candidate_id", "symbol", "option_type")
                    },
                    "python_gate": rejection.get("gate"),
                },
                evaluation={"status": "NOT_EVALUATED_PYTHON_REJECTED"},
                now=now or datetime.now(UTC),
                python_pass=False,
                shadow=True,
            )
    except Exception:
        return


def evaluate_completed_minute(
    packet: Mapping[str, Any],
    bar: Mapping[str, Any],
    config: Any,
    *,
    project_root: Path,
    now: datetime | None = None,
    client: Any = None,
) -> dict[str, Any]:
    """Provider-neutral minute callback; does not schedule anything or invoke Luna."""
    current = now or datetime.now(UTC)
    closed_at = completed_minute(bar, now=current)
    if closed_at is None or packet.get("python_gate", {}).get("status") != "QUALIFIED":
        return {"status": "SKIPPED", "reason": "completed_bar_and_python_gate_required"}
    try:
        as_of = datetime.fromisoformat(str(packet.get("as_of", "")).replace("Z", "+00:00"))
        if as_of.tzinfo is None or not 0 <= (current - as_of).total_seconds() <= 120:
            raise ValueError("stale packet")
        if bar.get("symbol") != packet.get("candidate", {}).get("symbol"):
            raise ValueError("symbol mismatch")
        store = JevStore(project_root / "state" / "research" / "jev.sqlite3")
        identity = str(packet.get("candidate", {}).get("candidate_id", ""))
        if not store.claim("minute:" + identity + ":" + closed_at, current):
            return {"status": "DUPLICATE", "routing_effect": False}
    except Exception:
        return {"status": "UNAVAILABLE", "routing_effect": False}
    prices = {key: number(bar.get(key)) for key in ("open", "high", "low", "close", "volume")}
    if any(value is None for value in prices.values()):
        return {"status": "SKIPPED", "reason": "numeric_completed_bar_required"}
    if not (
        0
        < prices["low"]
        <= min(prices["open"], prices["close"])
        <= max(prices["open"], prices["close"])
        <= prices["high"]
        and prices["volume"] >= 0
    ):
        return {"status": "SKIPPED", "reason": "invalid_completed_bar"}
    enriched = {**packet, "completed_minute": {**prices, "ends_at": closed_at}}
    return evaluate_candidate(
        enriched, config, project_root=project_root, now=current, client=client
    )


def record_execution(project_root: Path, result: Mapping[str, Any], *, now: datetime) -> None:
    """Join observed candidates to real downstream execution results, never fabricate fills."""
    routing = result.get("routing", {})
    candidate_id = (routing.get("decision_verdict") or {}).get("candidate_id")
    evaluations = routing.get("jev_evaluations", [])
    if not evaluations:
        return
    try:
        store = JevStore(project_root / "state" / "research" / "jev.sqlite3")
        for evaluation in evaluations:
            if evaluation.get("candidate_id") != candidate_id or not evaluation.get(
                "observation_id"
            ):
                continue
            store.event(
                evaluation["observation_id"],
                "execution_result",
                {
                    "paper": result.get("paper_decision"),
                    "live": result.get("live_decision"),
                },
                now,
            )
    except Exception:
        return
