"""Read Robinhood's remote MCP directly without invoking an LLM.

The first run performs Robinhood's standard OAuth browser flow. Tokens and the dynamically
registered client use Windows DPAPI or current-user-only Linux files.
CLI commands are read-only. Explicit live-order entry points are used only by the
authorized executor.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import stat
import sys
import tempfile
import time
import webbrowser
from collections.abc import Mapping
from datetime import UTC, date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from mcp.client.auth import OAuthClientProvider

from tools.order_protocol import OrderRequestRejected, placement_arguments

ROBINHOOD_MCP_URL = "https://agent.robinhood.com/mcp/trading"
ROBINHOOD_OAUTH_TOKEN_URL = "https://api.robinhood.com/oauth2/token/"
CALLBACK_HOST = "127.0.0.1"
CALLBACK_PORT = 8765
CALLBACK_PATH = "/callback"
CALLBACK_URL = f"http://{CALLBACK_HOST}:{CALLBACK_PORT}{CALLBACK_PATH}"
TOKEN_CREDENTIAL = "oauth_tokens.dpapi"
CLIENT_CREDENTIAL = "oauth_client.dpapi"
OPEN_ORDER_STATES = ("queued", "confirmed", "partially_filled", "pending_cancelled")


class CredentialStorage:
    """Current-user OAuth storage: Windows DPAPI or private Linux files."""

    def __init__(self, directory: Path | None = None) -> None:
        if directory is None:
            if os.name == "nt":
                local_app_data = os.environ.get("LOCALAPPDATA")
                if not local_app_data:
                    raise RuntimeError("LOCALAPPDATA is unavailable")
                directory = Path(local_app_data) / "RobinhoodAgentic"
            else:
                data_home = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share")
                if not data_home.is_absolute():
                    raise RuntimeError("XDG_DATA_HOME must be absolute")
                directory = data_home / "RobinhoodAgentic"
        self.directory = Path(directory)
        if os.name != "nt" and not self.directory.is_absolute():
            raise RuntimeError("OAuth credential directory must be absolute")

    def _path(self, name: str) -> Path:
        if os.name == "nt":
            return self.directory / name
        return self.directory / name.replace(".dpapi", ".json")

    def _private_directory(self, *, create: bool) -> bool:
        if os.name == "nt":
            if create:
                self.directory.mkdir(parents=True, exist_ok=True)
            return self.directory.is_dir()
        if create:
            self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            info = self.directory.lstat()
        except FileNotFoundError:
            return False
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
            raise PermissionError("OAuth credential directory must be owned by the current user")
        if info.st_mode & 0o077:
            raise PermissionError("OAuth credential directory must have mode 0700")
        return True

    @staticmethod
    def _private_file(path: Path) -> None:
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise PermissionError("OAuth credential file must be current-user-only")

    def _read(self, name: str) -> str | None:
        if not self._private_directory(create=False):
            return None
        path = self._path(name)
        if not path.exists():
            return None
        if os.name == "nt":
            import win32crypt

            _, plaintext = win32crypt.CryptUnprotectData(path.read_bytes(), None, None, None, 0)
            return plaintext.decode("utf-8")
        self._private_file(path)
        return path.read_text(encoding="utf-8")

    def _write(self, name: str, value: str) -> None:
        self._private_directory(create=True)
        data = value.encode("utf-8")
        if os.name == "nt":
            import win32crypt

            data = win32crypt.CryptProtectData(
                data, "Robinhood Agentic MCP OAuth", None, None, None, 0
            )
        target = self._path(name)
        if os.name != "nt" and target.exists():
            self._private_file(target)
        fd, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=self.directory)
        temporary = Path(temporary_name)
        try:
            if os.name != "nt":
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
            if os.name != "nt":
                directory_fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
        finally:
            temporary.unlink(missing_ok=True)

    async def get_tokens(self) -> Any:
        from mcp.shared.auth import OAuthToken

        value = self._read(TOKEN_CREDENTIAL)
        return OAuthToken.model_validate_json(value) if value else None

    async def set_tokens(self, tokens: Any) -> None:
        self._write(TOKEN_CREDENTIAL, tokens.model_dump_json())

    async def get_client_info(self) -> Any:
        from mcp.shared.auth import OAuthClientInformationFull

        value = self._read(CLIENT_CREDENTIAL)
        return OAuthClientInformationFull.model_validate_json(value) if value else None

    async def set_client_info(self, client_info: Any) -> None:
        self._write(CLIENT_CREDENTIAL, client_info.model_dump_json())

    def token_saved_at(self) -> float | None:
        """Return the token write time without decrypting or exposing its contents."""

        path = self._path(TOKEN_CREDENTIAL)
        try:
            if os.name != "nt":
                self._private_directory(create=False)
                self._private_file(path)
            return path.stat().st_mtime
        except OSError:
            return None


def _persisted_token_expiry(storage: Any, tokens: Any, *, safety_seconds: int = 60) -> float | None:
    """Recover an absolute expiry for MCP tokens whose schema stores only ``expires_in``.

    The upstream MCP client restores a token on every short-lived scheduled process but does not
    restore its absolute expiry time. That makes an expired token look valid until Robinhood sends
    a 401, at which point the client starts interactive OAuth instead of trying the saved refresh
    token. The encrypted token file's modification time is the issuance/refresh time because every
    successful token response rewrites it.
    """

    saved_at_getter = getattr(storage, "token_saved_at", None)
    if not callable(saved_at_getter):
        return None
    saved_at = _finite_number(saved_at_getter())
    expires_in = _finite_number(getattr(tokens, "expires_in", None))
    if saved_at is None or expires_in is None or expires_in <= 0:
        return None
    return saved_at + max(0.0, expires_in - max(0, safety_seconds))


class _PersistedExpiryOAuthClientProvider(OAuthClientProvider):
    """OAuth provider that refreshes an expired token before Robinhood rejects it."""

    def _get_token_endpoint(self) -> str:
        """Use Robinhood's advertised endpoint before per-process metadata discovery runs."""

        if self.context.oauth_metadata is None:
            return ROBINHOOD_OAUTH_TOKEN_URL
        return super()._get_token_endpoint()

    async def _refresh_token(self) -> Any:
        """Build the Robinhood refresh request without its unsupported resource field."""

        import httpx
        from mcp.client.auth import OAuthTokenError

        tokens = self.context.current_tokens
        client = self.context.client_info
        if tokens is None or not tokens.refresh_token:
            raise OAuthTokenError("No refresh token available")
        if client is None or not client.client_id:
            raise OAuthTokenError("No client info available")
        refresh_data = {
            "grant_type": "refresh_token",
            "refresh_token": tokens.refresh_token,
            "client_id": client.client_id,
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        refresh_data, headers = self.context.prepare_token_auth(refresh_data, headers)
        return httpx.Request(
            "POST",
            self._get_token_endpoint(),
            data=refresh_data,
            headers=headers,
        )

    async def _initialize(self) -> None:
        await super()._initialize()
        if self.context.current_tokens is None:
            return
        expiry = _persisted_token_expiry(self.context.storage, self.context.current_tokens)
        if expiry is not None:
            self.context.token_expiry_time = expiry


class _CallbackServer(HTTPServer):
    authorization_code: str | None = None
    authorization_state: str | None = None
    authorization_error: str | None = None


class _CallbackHandler(BaseHTTPRequestHandler):
    server: _CallbackServer

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        parsed = urlparse(self.path)
        if parsed.path != CALLBACK_PATH:
            self.send_error(404)
            return
        query = parse_qs(parsed.query)
        self.server.authorization_code = query.get("code", [None])[0]
        self.server.authorization_state = query.get("state", [None])[0]
        self.server.authorization_error = query.get("error", [None])[0]
        body = (
            b"Robinhood authorization received. You can close this tab and return to the terminal."
        )
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return


async def _open_authorization_url(url: str) -> None:
    print(f"Opening Robinhood authorization in your browser...\n{url}", file=sys.stderr, flush=True)
    if not webbrowser.open(url):
        print("The browser did not open; use the URL above manually.", file=sys.stderr, flush=True)


def _wait_for_callback_sync(timeout_seconds: int = 300) -> tuple[str, str | None]:
    server = _CallbackServer((CALLBACK_HOST, CALLBACK_PORT), _CallbackHandler)
    server.timeout = 1
    deadline = time.monotonic() + timeout_seconds
    try:
        while time.monotonic() < deadline and server.authorization_code is None:
            server.handle_request()
            if server.authorization_error:
                raise RuntimeError(f"Robinhood authorization failed: {server.authorization_error}")
    finally:
        server.server_close()
    if server.authorization_code is None:
        raise TimeoutError("Robinhood authorization timed out")
    return server.authorization_code, server.authorization_state


async def _wait_for_callback() -> tuple[str, str | None]:
    return await asyncio.to_thread(_wait_for_callback_sync)


async def _authorization_required(*args: Any) -> Any:
    """Unattended readers must never open a browser or wait for interactive login."""
    raise RuntimeError("robinhood_authorization_required: run the explicit auth command")


def _complete_snapshot_rows(payload: Mapping[str, Any], field: str) -> list[Mapping[str, Any]]:
    """Missing/malformed/paginated broker state never means a flat account."""
    rows = payload.get(field)
    if not isinstance(rows, list) or any(not isinstance(row, Mapping) for row in rows):
        raise RuntimeError(f"Robinhood {field} are invalid")
    if payload.get("next"):
        raise RuntimeError(f"Robinhood {field} are incomplete")
    if field == "positions" and any(
        not row.get("option_id") or (_finite_number(row.get("quantity")) or 0) <= 0 for row in rows
    ):
        raise RuntimeError("Robinhood positions have invalid identity/quantity")
    return rows


def _tool_error_category(result: Any) -> str:
    # Inspect locally, emit only a fixed category; never log raw provider error bodies.
    raw = str(getattr(result, "structuredContent", "")) + " ".join(
        str(getattr(item, "text", "")) for item in getattr(result, "content", [])
    )
    text = raw[:20000].lower()
    for category, markers in (
        ("rate_limited", ("429", "rate limit", "too many requests")),
        ("authentication", ("401", "403", "unauthorized", "forbidden")),
        ("timeout", ("timeout", "timed out")),
        ("server_unavailable", ("500", "502", "503", "504", "service unavailable")),
        ("invalid_request", ("400", "invalid argument", "validation error")),
    ):
        if any(marker in text for marker in markers):
            return category
    return "unspecified_provider_error"


async def _read_option_instruments(session, arguments):
    """One bounded retry of this read-only endpoint; never retry an order operation."""
    result = await session.call_tool("get_option_instruments", arguments)
    if getattr(result, "isError", False) and _tool_error_category(result) in {
        "timeout",
        "server_unavailable",
    }:
        await asyncio.sleep(1)
        result = await session.call_tool("get_option_instruments", arguments)
    return result


def _tool_payload(result: Any, tool_name: str) -> dict[str, Any]:
    if getattr(result, "isError", False):
        raise RuntimeError(
            f"Robinhood MCP tool failed: {tool_name} [category={_tool_error_category(result)}]"
        )
    structured = getattr(result, "structuredContent", None)
    if isinstance(structured, Mapping):
        return dict(structured)
    for item in getattr(result, "content", []):
        text = getattr(item, "text", None)
        if isinstance(text, str):
            try:
                decoded = json.loads(text)
            except json.JSONDecodeError:
                continue
            if isinstance(decoded, Mapping):
                return dict(decoded)
    raise RuntimeError(f"Robinhood MCP returned no structured data: {tool_name}")


def _data(payload: Mapping[str, Any]) -> dict[str, Any]:
    value = payload.get("data")
    return dict(value) if isinstance(value, Mapping) else dict(payload)


async def _complete_option_instruments(session, arguments):
    """Finish each expiry before ranking strikes; never silently rank a partial chain."""
    instruments = []
    seen_cursors = set()
    cursor = None
    for page in range(64):
        request = {**arguments, **({"cursor": cursor} if cursor else {})}
        payload = _tool_payload(
            await _read_option_instruments(session, request), "get_option_instruments"
        )
        data = _data(payload)
        rows = data.get("instruments", data.get("results"))
        if not isinstance(rows, list):
            raise RuntimeError("option_chain_invalid_page")
        instruments.extend(row for row in rows if isinstance(row, Mapping))
        next_url = data.get("next") or payload.get("next")
        if not next_url:
            return instruments, {
                "pages": page + 1,
                "instruments": len(instruments),
                "complete": True,
            }
        if not isinstance(next_url, str):
            raise RuntimeError("option_chain_invalid_pagination")
        if "://" in next_url or next_url.startswith("/"):
            # Retain compatibility with older URL-shaped pagination responses.
            values = parse_qs(urlparse(next_url).query).get("cursor", [])
            cursor = values[0] if values else None
        else:
            # Current MCP contract: pass `next` back verbatim as the cursor.
            cursor = (
                next_url
                if len(next_url) <= 4096 and not any(character.isspace() for character in next_url)
                else None
            )
        if not cursor or cursor in seen_cursors:
            raise RuntimeError("option_chain_invalid_or_repeated_cursor")
        seen_cursors.add(cursor)
        if len(instruments) >= 20000:
            break
    raise RuntimeError("option_chain_incomplete_safety_limit")


def _iso_date(value: Any) -> date | None:
    if not isinstance(value, str):
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def _finite_number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number and abs(number) != float("inf") else None


def _near_money_instruments(
    instruments: list[Any], equity_quotes: list[Any], *, per_expiration_type: int = 20
) -> list[Mapping[str, Any]]:
    """Bound quote work to near-money contracts while retaining both directions/styles."""

    prices: dict[str, float] = {}
    for row in equity_quotes:
        if not isinstance(row, Mapping):
            continue
        quote = row.get("quote") if isinstance(row.get("quote"), Mapping) else row
        symbol = str(quote.get("symbol", "")).upper()
        price = _finite_number(
            quote.get("last_trade_price") or quote.get("last_non_reg_trade_price")
        )
        if symbol and price is not None and price > 0:
            prices[symbol] = price
    groups: dict[tuple[str, str, str], list[tuple[float, Mapping[str, Any]]]] = {}
    for row in instruments:
        if not isinstance(row, Mapping):
            continue
        symbol = str(row.get("chain_symbol", "")).upper()
        expiration = str(row.get("expiration_date", ""))
        option_type = str(row.get("type", "")).lower()
        strike = _finite_number(row.get("strike_price"))
        price = prices.get(symbol)
        if not symbol or not expiration or option_type not in {"call", "put"}:
            continue
        if strike is None or price is None:
            continue
        groups.setdefault((symbol, expiration, option_type), []).append(
            (abs(strike - price) / price, row)
        )
    selected: list[Mapping[str, Any]] = []
    for group in groups.values():
        group.sort(key=lambda item: item[0])
        selected.extend(row for _, row in group[:per_expiration_type])
    return selected


def select_expirations(
    values: set[str], *, maximum: int, swing_minimum: date | None = None
) -> list[str]:
    """Keep nearby DAY expiries and one bounded SWING window instead of centering on 16 DTE."""
    ordered = sorted(values)
    chosen = ordered[: max(1, maximum - 1)]
    if swing_minimum is not None:
        swing = next(
            (value for value in ordered if date.fromisoformat(value) >= swing_minimum), None
        )
        if swing is not None and swing not in chosen:
            chosen.append(swing)
    chosen.extend(value for value in ordered if value not in chosen)
    return chosen[:maximum]


def _select_agentic_account(accounts: list[Any]) -> dict[str, Any]:
    eligible = [
        item
        for item in accounts
        if isinstance(item, Mapping) and item.get("agentic_allowed") is True
    ]
    if len(eligible) != 1:
        message = f"Expected exactly one accessible Agentic account; found {len(eligible)}"
        raise RuntimeError(message)
    return dict(eligible[0])


def _mask_account(account_number: str) -> str:
    return f"••••{account_number[-4:]}"


async def _validated_order_call(session: Any, action: str, arguments: Mapping[str, Any]) -> Any:
    """Validate against the live tool schema before sending any order-related call."""
    from jsonschema import Draft202012Validator

    outgoing = placement_arguments(arguments) if action == "place_option_order" else dict(arguments)
    listed = await session.list_tools()
    tool = next((item for item in listed.tools if item.name == action), None)
    if tool is None:
        raise OrderRequestRejected(f"Robinhood tool unavailable: {action}")
    errors = list(Draft202012Validator(tool.inputSchema).iter_errors(outgoing))
    if errors:
        paths = [".".join(str(part) for part in error.absolute_path) or "root" for error in errors]
        raise OrderRequestRejected(f"{action} schema mismatch at {', '.join(paths)}")
    return await session.call_tool(action, outgoing)


async def _with_session(
    action: str, option_requests: list[Mapping[str, str]] | None = None
) -> dict[str, Any]:
    import httpx
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    from mcp.shared.auth import OAuthClientMetadata

    metadata = OAuthClientMetadata(
        redirect_uris=[CALLBACK_URL],
        token_endpoint_auth_method="none",
        grant_types=["authorization_code", "refresh_token"],
        response_types=["code"],
        scope="internal",
        client_name="Robinhood Agentic deterministic monitor",
        software_id="robinhood-agentic-monitor",
        software_version="0.1.0",
    )
    auth = _PersistedExpiryOAuthClientProvider(
        ROBINHOOD_MCP_URL,
        metadata,
        CredentialStorage(),
        redirect_handler=_open_authorization_url if action == "auth" else _authorization_required,
        callback_handler=_wait_for_callback if action == "auth" else _authorization_required,
    )
    timeout = httpx.Timeout(30, read=300)
    async with (
        httpx.AsyncClient(auth=auth, follow_redirects=True, timeout=timeout) as client,
        streamable_http_client(
            ROBINHOOD_MCP_URL,
            http_client=client,
            terminate_on_close=False,
        ) as streams,
        ClientSession(streams[0], streams[1]) as session,
    ):
        await session.initialize()
        if action == "equity_price_book":
            symbols = [str(item["symbol"]) for item in (option_requests or [])]
            if not 1 <= len(symbols) <= 4:
                raise ValueError("price book requires one to four symbols")
            response = await session.call_tool("get_equity_price_book", {"symbols": symbols})
            return _data(_tool_payload(response, "get_equity_price_book"))
        if action == "tools":
            listed = await session.list_tools()
            return {
                "status": "OK",
                "tools": [
                    {
                        "name": tool.name,
                        "description": tool.description,
                        "input_schema": tool.inputSchema,
                    }
                    for tool in listed.tools
                ],
            }
        if action == "popular_watchlists":
            popular_result = await session.call_tool("get_popular_watchlists", {})
            return {
                "status": "OK",
                "as_of": datetime.now(UTC).isoformat(),
                "popular_watchlists": _data(
                    _tool_payload(popular_result, "get_popular_watchlists")
                ),
            }
        if action == "market_movers":
            popular_result = await session.call_tool("get_popular_watchlists", {})
            popular_data = _data(_tool_payload(popular_result, "get_popular_watchlists"))
            lists = popular_data.get("lists")
            daily = (
                next(
                    (
                        item
                        for item in lists
                        if isinstance(item, Mapping)
                        and str(item.get("display_name", "")).casefold() == "daily movers"
                    ),
                    None,
                )
                if isinstance(lists, list)
                else None
            )
            if not isinstance(daily, Mapping) or not daily.get("id"):
                raise RuntimeError("Robinhood Daily movers curated list is unavailable")
            items_result = await session.call_tool(
                "get_watchlist_items", {"list_id": str(daily["id"])}
            )
            items_data = _data(_tool_payload(items_result, "get_watchlist_items"))
            item_rows = items_data.get("items")
            symbols = (
                sorted(
                    {
                        str(item.get("symbol", "")).strip().upper()
                        for item in item_rows
                        if isinstance(item, Mapping)
                        and item.get("object_type") == "instrument"
                        and str(item.get("symbol", "")).strip()
                    }
                )
                if isinstance(item_rows, list)
                else []
            )
            equity_quotes: list[Any] = []
            equity_fundamentals: list[Any] = []
            if symbols:
                equity_result = await session.call_tool(
                    "get_equity_quotes", {"symbols": symbols[:20]}
                )
                equity_data = _data(_tool_payload(equity_result, "get_equity_quotes"))
                quote_rows = equity_data.get("results") or equity_data.get("quotes")
                if isinstance(quote_rows, list):
                    equity_quotes.extend(item for item in quote_rows if item is not None)
                for offset in range(0, min(len(symbols), 20), 10):
                    fundamentals_result = await session.call_tool(
                        "get_equity_fundamentals",
                        {"symbols": symbols[offset : offset + 10], "bounds": "regular"},
                    )
                    fundamentals_data = _data(
                        _tool_payload(fundamentals_result, "get_equity_fundamentals")
                    )
                    rows = fundamentals_data.get("results") or fundamentals_data.get("fundamentals")
                    if isinstance(rows, list):
                        equity_fundamentals.extend(item for item in rows if item is not None)
            return {
                "status": "OK",
                "as_of": datetime.now(UTC).isoformat(),
                "list": dict(daily),
                "items": items_data,
                "equity_quotes": equity_quotes,
                "equity_fundamentals": equity_fundamentals,
            }
        if action == "contract_research":
            instruments: list[Any] = []
            symbols: set[str] = set()
            for request in option_requests or []:
                symbol = str(request.get("chain_symbol", "")).strip().upper()
                if symbol:
                    symbols.add(symbol)
                instrument_result = await session.call_tool(
                    "get_option_instruments",
                    {
                        "chain_symbol": symbol,
                        "expiration_dates": request.get("expiration_dates"),
                        "strike_price": request.get("strike_price"),
                        "type": request.get("type"),
                        "state": "active",
                        "tradability": "tradable",
                    },
                )
                instrument_data = _data(_tool_payload(instrument_result, "get_option_instruments"))
                rows = instrument_data.get("instruments") or instrument_data.get("results")
                if isinstance(rows, list):
                    instruments.extend(item for item in rows if item is not None)
            option_ids = [
                str(item.get("id") or item.get("instrument_id"))
                for item in instruments
                if isinstance(item, Mapping) and (item.get("id") or item.get("instrument_id"))
            ]
            quotes: list[Any] = []
            for offset in range(0, len(option_ids), 20):
                quote_result = await session.call_tool(
                    "get_option_quotes", {"instrument_ids": option_ids[offset : offset + 20]}
                )
                quote_data = _data(_tool_payload(quote_result, "get_option_quotes"))
                rows = quote_data.get("results") or quote_data.get("quotes")
                if isinstance(rows, list):
                    quotes.extend(item for item in rows if item is not None)
            equity_quotes: list[Any] = []
            equity_fundamentals: list[Any] = []
            if symbols:
                equity_result = await session.call_tool(
                    "get_equity_quotes", {"symbols": sorted(symbols)}
                )
                equity_data = _data(_tool_payload(equity_result, "get_equity_quotes"))
                rows = equity_data.get("results") or equity_data.get("quotes")
                if isinstance(rows, list):
                    equity_quotes.extend(item for item in rows if item is not None)
                symbol_rows = sorted(symbols)
                for offset in range(0, len(symbol_rows), 10):
                    fundamentals_result = await session.call_tool(
                        "get_equity_fundamentals",
                        {"symbols": symbol_rows[offset : offset + 10], "bounds": "regular"},
                    )
                    fundamentals_data = _data(
                        _tool_payload(fundamentals_result, "get_equity_fundamentals")
                    )
                    rows = fundamentals_data.get("results") or fundamentals_data.get("fundamentals")
                    if isinstance(rows, list):
                        equity_fundamentals.extend(item for item in rows if item is not None)
            return {
                "status": "OK",
                "as_of": datetime.now(UTC).isoformat(),
                "instruments": instruments,
                "option_quotes": quotes,
                "equity_quotes": equity_quotes,
                "equity_fundamentals": equity_fundamentals,
            }
        if action == "quote_refresh":
            tp_history: dict[str, Any] = {}
            for item in option_requests or []:
                if not item.get("tp_history_start"):
                    continue
                contract_id = str(item.get("option_id", ""))
                try:
                    history_result = await session.call_tool(
                        "get_option_historicals",
                        {
                            "instrument_ids": [contract_id],
                            "start_time": item["tp_history_start"],
                            "interval": "minute",
                            "bounds": "regular",
                        },
                    )
                    history_data = _data(_tool_payload(history_result, "get_option_historicals"))
                    tp_history[contract_id] = {
                        "status": "OK",
                        "results": history_data.get("results", []),
                    }
                except Exception as exc:
                    tp_history[contract_id] = {"status": "UNAVAILABLE", "error": str(exc)[:200]}
            option_ids = sorted(
                {
                    str(item.get("option_id", "")).strip()
                    for item in option_requests or []
                    if str(item.get("option_id", "")).strip()
                }
            )
            symbols = sorted(
                {
                    str(item.get("symbol", "")).strip().upper()
                    for item in option_requests or []
                    if str(item.get("symbol", "")).strip()
                }
            )
            quotes: list[Any] = []
            for offset in range(0, len(option_ids), 20):
                quote_result = await session.call_tool(
                    "get_option_quotes", {"instrument_ids": option_ids[offset : offset + 20]}
                )
                quote_data = _data(_tool_payload(quote_result, "get_option_quotes"))
                rows = quote_data.get("results") or quote_data.get("quotes")
                if isinstance(rows, list):
                    quotes.extend(item for item in rows if item is not None)
            equity_quotes: list[Any] = []
            for offset in range(0, len(symbols), 20):
                equity_result = await session.call_tool(
                    "get_equity_quotes", {"symbols": symbols[offset : offset + 20]}
                )
                equity_data = _data(_tool_payload(equity_result, "get_equity_quotes"))
                rows = equity_data.get("results") or equity_data.get("quotes")
                if isinstance(rows, list):
                    equity_quotes.extend(item for item in rows if item is not None)
            return {
                "status": "OK",
                "as_of": datetime.now(UTC).isoformat(),
                "option_quotes": quotes,
                "equity_quotes": equity_quotes,
                "tp_history": tp_history,
            }
        if action == "symbol_contract_research":
            pagination_audit = []
            instruments: list[Any] = []
            chains: list[Any] = []
            symbols = sorted(
                {
                    str(item.get("symbol", "")).strip().upper()
                    for item in option_requests or []
                    if str(item.get("symbol", "")).strip()
                }
            )
            request_by_symbol = {
                str(item.get("symbol", "")).strip().upper(): item
                for item in option_requests or []
                if str(item.get("symbol", "")).strip()
            }
            for symbol in symbols:
                request = request_by_symbol[symbol]
                minimum = date.fromisoformat(str(request["min_expiration"]))
                maximum = date.fromisoformat(str(request["max_expiration"]))
                max_expirations = max(1, min(int(request.get("max_expirations", 2)), 3))
                chain_result = await session.call_tool(
                    "get_option_chains", {"underlying_symbol": symbol}
                )
                chain_payload = _tool_payload(chain_result, "get_option_chains")
                chain_data = _data(chain_payload)
                chain_rows = chain_data.get("results") or chain_data.get("chains")
                if not isinstance(chain_rows, list):
                    chain_rows = []
                symbol_chains = [item for item in chain_rows if isinstance(item, Mapping)]
                chains.extend(symbol_chains)
                valid_expirations: set[str] = set()
                for chain in symbol_chains:
                    values = chain.get("expiration_dates", [])
                    if not isinstance(values, list):
                        continue
                    for raw in values:
                        parsed = _iso_date(raw)
                        if parsed is not None and minimum <= parsed <= maximum:
                            valid_expirations.add(str(raw))
                swing_minimum = _iso_date(request.get("min_swing_expiration"))
                expirations = select_expirations(
                    valid_expirations, maximum=max_expirations, swing_minimum=swing_minimum
                )
                for expiration in expirations:
                    for chain in symbol_chains:
                        expiration_dates = chain.get("expiration_dates", [])
                        chain_id = chain.get("id")
                        if not chain_id or expiration not in expiration_dates:
                            continue
                        rows, audit = await _complete_option_instruments(
                            session,
                            {
                                "chain_id": str(chain_id),
                                "expiration_dates": expiration,
                                "state": "active",
                                "tradability": "tradable",
                            },
                        )
                        instruments.extend(rows)
                        pagination_audit.append(
                            {"symbol": symbol, "expiration": expiration, **audit}
                        )
            equity_quotes: list[Any] = []
            equity_fundamentals: list[Any] = []
            if symbols:
                equity_result = await session.call_tool("get_equity_quotes", {"symbols": symbols})
                equity_data = _data(_tool_payload(equity_result, "get_equity_quotes"))
                rows = equity_data.get("results") or equity_data.get("quotes")
                if isinstance(rows, list):
                    equity_quotes.extend(item for item in rows if item is not None)
                for offset in range(0, len(symbols), 10):
                    fundamentals_result = await session.call_tool(
                        "get_equity_fundamentals",
                        {"symbols": symbols[offset : offset + 10], "bounds": "regular"},
                    )
                    fundamentals_data = _data(
                        _tool_payload(fundamentals_result, "get_equity_fundamentals")
                    )
                    rows = fundamentals_data.get("results") or fundamentals_data.get("fundamentals")
                    if isinstance(rows, list):
                        equity_fundamentals.extend(item for item in rows if item is not None)
            instruments = list(_near_money_instruments(instruments, equity_quotes))
            option_ids = [
                str(item.get("id") or item.get("instrument_id"))
                for item in instruments
                if item.get("id") or item.get("instrument_id")
            ]
            option_quotes: list[Any] = []
            for offset in range(0, len(option_ids), 20):
                quote_result = await session.call_tool(
                    "get_option_quotes", {"instrument_ids": option_ids[offset : offset + 20]}
                )
                quote_data = _data(_tool_payload(quote_result, "get_option_quotes"))
                rows = quote_data.get("results") or quote_data.get("quotes")
                if isinstance(rows, list):
                    option_quotes.extend(item for item in rows if item is not None)
            return {
                "status": "OK",
                "as_of": datetime.now(UTC).isoformat(),
                "chain_pagination": pagination_audit,
                "chains": chains,
                "instruments": instruments,
                "option_quotes": option_quotes,
                "equity_quotes": equity_quotes,
                "equity_fundamentals": equity_fundamentals,
            }
        account_result = await session.call_tool("get_accounts", {})
        accounts_data = _data(_tool_payload(account_result, "get_accounts"))
        accounts = accounts_data.get("accounts")
        if not isinstance(accounts, list):
            raise RuntimeError("Robinhood MCP returned an invalid accounts list")
        account = _select_agentic_account(accounts)
        account_number = str(account["account_number"])
        public_account = {
            "account_number": _mask_account(account_number),
            "nickname": account.get("nickname"),
            "state": account.get("state"),
            "type": account.get("type"),
            "option_level": account.get("option_level"),
        }
        if action == "auth":
            return {"status": "AUTHORIZED", "account": public_account}
        if action in {"review_option_order", "place_option_order"}:
            if not option_requests or len(option_requests) != 1:
                raise ValueError(f"{action} requires exactly one order request")
            arguments = (
                placement_arguments(option_requests[0])
                if action == "place_option_order"
                else dict(option_requests[0])
            )
            arguments["account_number"] = account_number
            order_result = await _validated_order_call(session, action, arguments)
            return {
                "status": "REVIEWED" if action == "review_option_order" else "SUBMITTED",
                "as_of": datetime.now(UTC).isoformat(),
                "account": public_account,
                "request": {
                    key: value for key, value in arguments.items() if key != "account_number"
                },
                "result": _tool_payload(order_result, action),
            }
        if action == "option_order_status":
            if not option_requests or len(option_requests) != 1:
                raise ValueError("option_order_status requires exactly one order request")
            order_id = str(option_requests[0].get("order_id", "")).strip()
            if not order_id:
                raise ValueError("order_id is required")
            order_result = await session.call_tool(
                "get_option_orders",
                {"account_number": account_number, "order_id": order_id},
            )
            return {
                "status": "OK",
                "as_of": datetime.now(UTC).isoformat(),
                "account": public_account,
                "result": _tool_payload(order_result, "get_option_orders"),
            }

        portfolio_result = await session.call_tool(
            "get_portfolio", {"account_number": account_number}
        )
        positions_result = await session.call_tool(
            "get_option_positions",
            {"account_number": account_number, "nonzero": True},
        )
        order_rows: list[Any] = []
        for state in OPEN_ORDER_STATES:
            order_result = await session.call_tool(
                "get_option_orders",
                {"account_number": account_number, "state": state},
            )
            order_data = _data(_tool_payload(order_result, "get_option_orders"))
            orders = _complete_snapshot_rows(order_data, "orders")
            order_rows.extend(orders)

        positions_data = _data(_tool_payload(positions_result, "get_option_positions"))
        positions = _complete_snapshot_rows(positions_data, "positions")
        option_ids = [
            str(item["option_id"])
            for item in positions
            if isinstance(item, Mapping) and item.get("option_id")
        ]
        quote_rows: list[Any] = []
        if option_ids:
            quotes_result = await session.call_tool(
                "get_option_quotes", {"instrument_ids": option_ids}
            )
            quotes_data = _data(_tool_payload(quotes_result, "get_option_quotes"))
            quotes = quotes_data.get("results") or quotes_data.get("quotes")
            if isinstance(quotes, list):
                quote_rows = [item for item in quotes if item is not None]

        return {
            "status": "OK",
            "as_of": datetime.now(UTC).isoformat(),
            "account": public_account,
            "portfolio": _data(_tool_payload(portfolio_result, "get_portfolio")),
            "positions": [item for item in positions if item is not None],
            "open_option_orders": order_rows,
            "option_quotes": quote_rows,
        }


def _transient_read_error(exc: BaseException) -> bool:
    import anyio
    import httpx

    if isinstance(exc, BaseExceptionGroup):
        return bool(exc.exceptions) and all(_transient_read_error(e) for e in exc.exceptions)
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in {408, 429, 500, 502, 503, 504}
    return isinstance(
        exc,
        (
            anyio.BrokenResourceError,
            anyio.EndOfStream,
            httpx.TransportError,
            ConnectionError,
            TimeoutError,
        ),
    )


async def _monitoring_read(action: str, requests=None) -> dict[str, Any]:
    """One fresh-session retry for transient reads; never retry order submission."""
    if action not in {"snapshot", "quote_refresh"}:
        raise ValueError("monitoring retry is restricted to read-only actions")
    try:
        return await _with_session(action, requests)
    except Exception as exc:
        if not _transient_read_error(exc):
            raise
    await asyncio.sleep(2)
    # Limit added outage latency; any second failure reaches normal error reporting.
    return await asyncio.wait_for(_with_session(action, requests), timeout=30)


async def fetch_equity_price_book(symbols: list[str]) -> dict[str, Any]:
    """Read resting equity depth; this does not expose executed trade prints."""
    if not 1 <= len(symbols) <= 4 or any(not symbol.strip() for symbol in symbols):
        raise ValueError("price book requires one to four symbols")
    return await _with_session("equity_price_book", [{"symbol": symbol} for symbol in symbols])


async def fetch_snapshot() -> dict[str, Any]:
    """Return a fresh read-only account/position/order/quote snapshot."""

    return await _monitoring_read("snapshot")


async def fetch_contract_research(
    option_requests: list[Mapping[str, str]],
) -> dict[str, Any]:
    """Resolve exact option contracts and fetch fresh option/underlying quotes read-only."""

    return await _with_session("contract_research", option_requests)


async def fetch_quote_refresh(
    requests: list[Mapping[str, str]],
) -> dict[str, Any]:
    """Fetch exact option and underlying quotes without any order interface."""

    return await _monitoring_read("quote_refresh", requests)


async def fetch_paper_monitor_quotes(requests: list[Mapping[str, str]]) -> dict[str, Any]:
    """Read held-option quotes only; the fast loop owns timeout/backoff, with no retry."""
    return await _with_session(
        "quote_refresh", [{"option_id": str(item["option_id"])} for item in requests]
    )


async def review_live_option_order(request: Mapping[str, Any]) -> dict[str, Any]:
    """Run Robinhood's pre-trade option review without placing an order."""

    return await _with_session("review_option_order", [request])


async def place_live_option_order(request: Mapping[str, Any]) -> dict[str, Any]:
    """Place one user-authorized option order through the Agentic account."""

    return await _with_session("place_option_order", [request])


async def fetch_option_order_status(order_id: str) -> dict[str, Any]:
    """Fetch one option order by id through the Agentic account."""

    return await _with_session("option_order_status", [{"order_id": order_id}])


async def fetch_symbol_contract_research(
    requests: list[Mapping[str, str]],
) -> dict[str, Any]:
    """Resolve a small expiration window for news-originated symbols read-only."""

    return await _with_session("symbol_contract_research", requests)


async def fetch_popular_watchlists() -> dict[str, Any]:
    """Return Robinhood-curated market lists without following or modifying them."""

    return await _with_session("popular_watchlists")


async def fetch_market_movers() -> dict[str, Any]:
    """Return Robinhood's current curated Daily movers list read-only."""

    return await _with_session("market_movers")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        choices=(
            "auth",
            "snapshot",
            "tools",
            "popular-watchlists",
            "market-movers",
            "contract-research",
            "symbol-contract-research",
        ),
    )
    parser.add_argument("--tool", help="With 'tools', return only this exact tool name")
    parser.add_argument("--names-only", action="store_true", help="With 'tools', omit schemas")
    parser.add_argument("--input", type=Path, help="JSON request list for contract-research")
    parser.add_argument("--symbol", help="Ticker for symbol-contract-research")
    parser.add_argument("--min-dte", type=int, default=7)
    parser.add_argument("--max-dte", type=int, default=45)
    parser.add_argument("--max-expirations", type=int, default=1)
    parser.add_argument("--summary", action="store_true")
    args = parser.parse_args()
    try:
        requests: list[Mapping[str, str]] | None = None
        action = args.command.replace("-", "_")
        if action == "contract_research":
            if args.input is None:
                raise ValueError("--input is required for contract-research")
            raw_requests = json.loads(args.input.read_text(encoding="utf-8"))
            if not isinstance(raw_requests, list) or not all(
                isinstance(item, Mapping) for item in raw_requests
            ):
                raise ValueError("contract-research input must be a JSON array of objects")
            requests = raw_requests
        elif action == "symbol_contract_research":
            if not args.symbol:
                raise ValueError("--symbol is required for symbol-contract-research")
            today = date.today()
            requests = [
                {
                    "symbol": args.symbol.strip().upper(),
                    "min_expiration": (today + timedelta(days=args.min_dte)).isoformat(),
                    "max_expiration": (today + timedelta(days=args.max_dte)).isoformat(),
                    "max_expirations": str(args.max_expirations),
                }
            ]
        result = asyncio.run(_with_session(action, requests))
        if args.command == "tools" and args.tool and isinstance(result.get("tools"), list):
            result["tools"] = [item for item in result["tools"] if item.get("name") == args.tool]
        if args.command == "tools" and args.names_only and isinstance(result.get("tools"), list):
            result["tools"] = [item.get("name") for item in result["tools"]]
        if args.summary and action == "symbol_contract_research":
            result = {
                "status": result.get("status"),
                "as_of": result.get("as_of"),
                "chains": len(result.get("chains", [])),
                "instruments": len(result.get("instruments", [])),
                "option_quotes": len(result.get("option_quotes", [])),
                "equity_quotes": len(result.get("equity_quotes", [])),
                "equity_fundamentals": len(result.get("equity_fundamentals", [])),
                "sample_instrument": next(iter(result.get("instruments", [])), None),
            }
    except Exception as exc:  # fail closed at the CLI boundary
        result = {"status": "ERROR", "error": f"{type(exc).__name__}: {exc}"}
        print(json.dumps(result, indent=2, sort_keys=True))
        return 1
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
