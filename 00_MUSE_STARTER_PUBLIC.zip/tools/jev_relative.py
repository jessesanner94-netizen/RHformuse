"""Point-in-time, same-configuration relative JEV score policy."""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Mapping
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from tools.jev_features import number

METRIC = "setup_quality"


def _timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo is not None else None


def _result(
    *,
    would_escalate: bool,
    reason: str,
    history_count: int,
    history_mean: float | None,
    score: float | None,
    model: str | None,
    question_versions: list[str],
    symbol: str | None,
) -> dict[str, Any]:
    return {
        "would_escalate": would_escalate,
        "reason": reason,
        "history_count": history_count,
        "history_mean": history_mean,
        "score": score,
        "metric": METRIC,
        "model": model,
        "question_versions": question_versions,
        "symbol": symbol,
    }


def _score(value: Any) -> Decimal | None:
    numeric = number(value)
    if numeric is None or not 0 <= numeric <= 1:
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None


def _current_fields(
    evaluation: Mapping[str, Any],
) -> tuple[float, Decimal, str, list[str]] | None:
    if evaluation.get("status") != "OK":
        return None
    scores = evaluation.get("scores")
    decimal_score = _score(scores.get(METRIC)) if isinstance(scores, Mapping) else None
    model = evaluation.get("model")
    versions = evaluation.get("question_versions")
    if (
        decimal_score is None
        or not isinstance(model, str)
        or not model
        or not isinstance(versions, list)
        or not versions
        or any(not isinstance(item, str) or not item for item in versions)
    ):
        return None
    return float(decimal_score), decimal_score, model, list(versions)


def relative_setup_policy(
    path: Path,
    evaluation: Mapping[str, Any],
    *,
    symbol: str,
    now: datetime,
    option_type: str | None = None,
) -> dict[str, Any]:
    """Allow only a strictly above-mean same-coin, point-in-time setup score.

    The current evaluation is excluded by observation ID when it is already persisted.
    A missing database is a cold start; an unreadable database fails closed.
    """
    current = _current_fields(evaluation)
    if now.tzinfo is None or current is None or not isinstance(symbol, str) or not symbol:
        return _result(
            would_escalate=False,
            reason="relative_setup_current_invalid",
            history_count=0,
            history_mean=None,
            score=None,
            model=None,
            question_versions=[],
            symbol=symbol if isinstance(symbol, str) else None,
        )
    score, decimal_score, model, versions = current
    if not path.exists():
        return _result(
            would_escalate=True,
            reason="relative_setup_bootstrap_no_history",
            history_count=0,
            history_mean=None,
            score=score,
            model=model,
            question_versions=versions,
            symbol=symbol,
        )

    current_id = evaluation.get("observation_id")
    values: list[Decimal] = []
    try:
        with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            rows = db.execute(
                "SELECT observation_id,as_of,evaluation_json,features_json,python_pass "
                "FROM observations "
                "WHERE symbol=? AND python_pass=1",
                (symbol,),
            )
            for row in rows:
                if option_type is not None:
                    try:
                        features = json.loads(row["features_json"])
                        if features.get("candidate", {}).get("option_type") != option_type:
                            continue
                    except (ValueError, AttributeError, TypeError):
                        continue
                if current_id is not None and row["observation_id"] == current_id:
                    continue
                as_of = _timestamp(row["as_of"])
                if as_of is None or as_of >= now:
                    continue
                try:
                    prior = json.loads(row["evaluation_json"])
                except (TypeError, json.JSONDecodeError):
                    continue
                if not isinstance(prior, Mapping):
                    continue
                available_at = _timestamp(prior.get("available_at"))
                prior_scores = prior.get("scores")
                prior_score = (
                    _score(prior_scores.get(METRIC))
                    if isinstance(prior_scores, Mapping)
                    else None
                )
                if (
                    prior.get("status") != "OK"
                    or available_at is None
                    or available_at > now
                    or prior.get("model") != model
                    or prior.get("question_versions") != versions
                    or prior_score is None
                ):
                    continue
                values.append(prior_score)
    except (OSError, sqlite3.Error):
        return _result(
            would_escalate=False,
            reason="relative_setup_history_unavailable",
            history_count=0,
            history_mean=None,
            score=score,
            model=model,
            question_versions=versions,
            symbol=symbol,
        )

    if not values:
        return _result(
            would_escalate=True,
            reason="relative_setup_bootstrap_no_history",
            history_count=0,
            history_mean=None,
            score=score,
            model=model,
            question_versions=versions,
            symbol=symbol,
        )
    mean = sum(values) / Decimal(len(values))
    return _result(
        would_escalate=decimal_score > mean,
        reason=(
            "relative_setup_above_mean"
            if decimal_score > mean
            else "relative_setup_not_above_mean"
        ),
        history_count=len(values),
        history_mean=float(mean),
        score=score,
        model=model,
        question_versions=versions,
        symbol=symbol,
    )
