"""Run one offline/manual trading-agent cycle with live execution structurally disabled."""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from tools.cheap_scan import scan_candidates
from tools.config import load_config
from tools.portfolio_risk import evaluate_risk
from tools.state_manager import load_project_positions, reconcile_positions

RESEARCH_TOOLS = ("vibe", "news_social")


def _open_position_reviews(broker_snapshot: Mapping[str, Any], reviews: Any) -> dict[str, Any]:
    positions = broker_snapshot.get("positions", [])
    if not positions:
        return {"status": "NOT_REQUIRED", "decisions": []}
    if not isinstance(reviews, list):
        return {"status": "INSUFFICIENT_DATA", "decisions": [], "missing": "all"}
    review_map = {
        item.get("contract_identifier"): item
        for item in reviews
        if isinstance(item, dict) and item.get("contract_identifier")
    }
    decisions: list[dict[str, Any]] = []
    missing: list[str] = []
    for position in positions:
        contract_id = position.get("contract_identifier")
        review = review_map.get(contract_id)
        if not review or review.get("review_complete") is not True:
            missing.append(str(contract_id))
            continue
        decision = review.get("decision", "WAIT")
        if decision not in {"HOLD", "REDUCE", "EXIT", "WAIT"}:
            missing.append(str(contract_id))
            continue
        decisions.append(
            {
                "contract_identifier": contract_id,
                "decision": decision,
                "review_complete": True,
            }
        )
    return {
        "status": "REVIEWED" if not missing else "INSUFFICIENT_DATA",
        "decisions": decisions,
        "missing": missing,
    }


def run_cycle(
    payload: Mapping[str, Any], *, config_path: str | Path, positions_path: str | Path
) -> dict[str, Any]:
    """Evaluate a supplied snapshot. This function has no order-placement or cancellation API."""

    config = load_config(config_path)
    broker_snapshot = payload.get("broker_snapshot")
    if not isinstance(broker_snapshot, dict):
        broker_snapshot = {}
    reconciliation = reconcile_positions(load_project_positions(positions_path), broker_snapshot)
    position_review = _open_position_reviews(broker_snapshot, payload.get("open_position_reviews"))
    tool_status = payload.get("tool_status")
    if not isinstance(tool_status, dict):
        tool_status = {}

    blockers: list[str] = []
    if tool_status.get("robinhood") != "OK":
        blockers.append("robinhood_unavailable")
    if reconciliation["status"] != "RECONCILED":
        blockers.append("position_reconciliation_incomplete")
    if position_review["status"] == "INSUFFICIENT_DATA":
        blockers.append("open_position_review_incomplete")

    scan: dict[str, Any]
    candidate_decisions: list[dict[str, Any]] = []
    if blockers:
        scan = {
            "status": "NOT_RUN",
            "reason": "manage_and_reconcile_open_positions_before_new_opportunities",
            "counts": {"input": 0, "qualified": 0, "rejected": 0, "insufficient_data": 0},
            "qualified": [],
            "rejected": [],
            "insufficient_data": [],
        }
    else:
        raw_candidates = payload.get("candidates", [])
        if not isinstance(raw_candidates, list):
            raw_candidates = []
        scan = scan_candidates(raw_candidates, config)
        candidate_map = {
            str(item.get("candidate_id", "")): item
            for item in raw_candidates
            if isinstance(item, dict)
        }
        for qualified in scan["qualified"]:
            candidate_id = qualified["candidate_id"]
            symbol = qualified["symbol"]
            candidate = candidate_map[candidate_id]
            risk = evaluate_risk(
                payload.get("account", {}),
                candidate,
                config,
                historical=payload.get("historical"),
            ).as_dict()
            reasons: list[str] = []
            if risk["status"] != "ALLOWED":
                reasons.append("hard_risk_gate_not_allowed")
            if risk["analytics"].get("status") != "CALCULATED":
                reasons.append("portfolio_analytics_incomplete")
            for tool in RESEARCH_TOOLS:
                if tool_status.get(tool) != "OK":
                    reasons.append(f"{tool}_research_unavailable")
            if candidate.get("event_review_complete") is not True:
                reasons.append("event_review_incomplete")
            if candidate.get("contract_review_complete") is not True:
                reasons.append("robinhood_contract_review_incomplete")
            if not reasons:
                reasons.append("escalated_agent_review_required")
            candidate_decisions.append(
                {
                    "candidate_id": candidate_id,
                    "symbol": symbol,
                    "decision": "WAIT",
                    "reasons": reasons,
                    "risk": risk,
                    "order_preview": "NOT_REQUESTED",
                }
            )

    status = "WAIT" if blockers or candidate_decisions else "NO TRADE"
    if scan["status"] == "INSUFFICIENT_DATA":
        status = "INSUFFICIENT DATA"
    return {
        "mode": "DRY_RUN",
        "live_execution": "PROHIBITED",
        "configured_live_execution_was_ignored": config.live_execution_enabled,
        "live_readiness": {
            "status": "BLOCKED" if config.live_blockers() else "READY",
            "blockers": config.live_blockers(),
        },
        "status": status,
        "blockers": blockers,
        "reconciliation": reconciliation,
        "open_position_management": position_review,
        "cheap_scan": scan,
        "candidate_decisions": candidate_decisions,
        "persistent_writes": [],
        "orders_placed": 0,
        "orders_cancelled": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("CONFIG.md"))
    parser.add_argument("--positions", type=Path, default=Path("state/POSITIONS.md"))
    parser.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    result = run_cycle(payload, config_path=args.config, positions_path=args.positions)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
