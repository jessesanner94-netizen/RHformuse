"""Trade-style-aware DTE and normalized Greek quality checks."""

from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

from tools.config import TradingConfig

STYLE_CONFIG_FIELDS = (
    "MIN_DAY_TRADE_DTE",
    "MIN_SWING_DTE",
    "MAX_DTE",
    "GREEKS_REQUIRED",
    "DAY_MIN_ABS_DELTA",
    "DAY_MAX_ABS_DELTA",
    "DAY_MAX_THETA_PERCENT_OF_PREMIUM",
    "DAY_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE",
    "SWING_MIN_ABS_DELTA",
    "SWING_MAX_ABS_DELTA",
    "SWING_MAX_THETA_PERCENT_OF_PREMIUM",
    "SWING_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE",
)


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def assess_option_styles(candidate: Mapping[str, Any], config: TradingConfig) -> dict[str, Any]:
    """Return eligible DAY/SWING styles plus comparable Greek-risk metrics."""

    missing_config = config.missing(STYLE_CONFIG_FIELDS)
    if missing_config:
        return {
            "eligible_styles": [],
            "common_reasons": [f"unresolved_config:{name}" for name in missing_config],
            "style_reasons": {"DAY": [], "SWING": []},
            "metrics": {},
        }
    dte = _number(candidate.get("dte"))
    underlying = _number(candidate.get("underlying_price"))
    bid = _number(candidate.get("bid"))
    ask = _number(candidate.get("ask"))
    delta = _number(candidate.get("delta"))
    gamma = _number(candidate.get("gamma"))
    theta = _number(candidate.get("theta"))
    vega = _number(candidate.get("vega"))
    implied_volatility = _number(candidate.get("implied_volatility"))
    values = (dte, underlying, bid, ask, delta, gamma, theta, vega, implied_volatility)
    if any(value is None for value in values):
        return {
            "eligible_styles": [],
            "common_reasons": ["greek_or_style_data_missing"],
            "style_reasons": {"DAY": [], "SWING": []},
            "metrics": {},
        }
    assert None not in values
    midpoint = (bid + ask) / 2
    if midpoint <= 0 or underlying <= 0:
        return {
            "eligible_styles": [],
            "common_reasons": ["invalid_greek_normalization_inputs"],
            "style_reasons": {"DAY": [], "SWING": []},
            "metrics": {},
        }
    abs_delta = abs(delta)
    theta_percent = abs(theta) / midpoint * 100
    gamma_delta_per_1_percent_move = gamma * underlying * 0.01
    metrics = {
        "abs_delta": round(abs_delta, 6),
        "gamma": round(gamma, 6),
        "gamma_delta_per_1_percent_move": round(gamma_delta_per_1_percent_move, 6),
        "theta": round(theta, 6),
        "theta_percent_of_premium_per_day": round(theta_percent, 4),
        "vega": round(vega, 6),
        "implied_volatility": round(implied_volatility, 6),
    }
    common: list[str] = []
    option_type = str(candidate.get("option_type", "")).upper()
    if option_type == "CALL" and delta <= 0:
        common.append("call_delta_sign_invalid")
    elif option_type == "PUT" and delta >= 0:
        common.append("put_delta_sign_invalid")
    if gamma < 0:
        common.append("negative_gamma_invalid")
    if theta > 0:
        common.append("positive_long_option_theta_invalid")
    if vega < 0:
        common.append("negative_vega_invalid")
    if implied_volatility <= 0:
        common.append("nonpositive_implied_volatility")

    numeric_fields = {
        field: _number(config.get(field))
        for field in STYLE_CONFIG_FIELDS
        if field != "GREEKS_REQUIRED"
    }
    if any(value is None for value in numeric_fields.values()):
        common.append("invalid_style_config")
    elif (
        float(numeric_fields["MIN_DAY_TRADE_DTE"]) < 0
        or float(numeric_fields["MIN_SWING_DTE"]) < 0
        or float(numeric_fields["MAX_DTE"])
        < max(
            float(numeric_fields["MIN_DAY_TRADE_DTE"]),
            float(numeric_fields["MIN_SWING_DTE"]),
        )
        or not 0
        <= float(numeric_fields["DAY_MIN_ABS_DELTA"])
        <= float(numeric_fields["DAY_MAX_ABS_DELTA"])
        <= 1
        or not 0
        <= float(numeric_fields["SWING_MIN_ABS_DELTA"])
        <= float(numeric_fields["SWING_MAX_ABS_DELTA"])
        <= 1
        or float(numeric_fields["DAY_MAX_THETA_PERCENT_OF_PREMIUM"]) < 0
        or float(numeric_fields["SWING_MAX_THETA_PERCENT_OF_PREMIUM"]) < 0
        or float(numeric_fields["DAY_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE"]) < 0
        or float(numeric_fields["SWING_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE"]) < 0
    ):
        common.append("invalid_style_config_range")
    if config.get("GREEKS_REQUIRED") is not True:
        common.append("greeks_required_must_be_true")
    style_reasons: dict[str, list[str]] = {"DAY": [], "SWING": []}
    if not common:
        day = style_reasons["DAY"]
        if dte < float(numeric_fields["MIN_DAY_TRADE_DTE"]):
            day.append("day_dte_too_short")
        if dte > float(numeric_fields["MAX_DTE"]):
            day.append("day_dte_too_long")
        if not (
            float(numeric_fields["DAY_MIN_ABS_DELTA"])
            <= abs_delta
            <= float(numeric_fields["DAY_MAX_ABS_DELTA"])
        ):
            day.append("day_delta_out_of_range")
        if theta_percent > float(numeric_fields["DAY_MAX_THETA_PERCENT_OF_PREMIUM"]):
            day.append("day_theta_decay_too_high")
        if gamma_delta_per_1_percent_move > float(
            numeric_fields["DAY_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE"]
        ):
            day.append("day_gamma_too_high")

        swing = style_reasons["SWING"]
        if dte < float(numeric_fields["MIN_SWING_DTE"]):
            swing.append("swing_dte_too_short")
        if dte > float(numeric_fields["MAX_DTE"]):
            swing.append("swing_dte_too_long")
        if not (
            float(numeric_fields["SWING_MIN_ABS_DELTA"])
            <= abs_delta
            <= float(numeric_fields["SWING_MAX_ABS_DELTA"])
        ):
            swing.append("swing_delta_out_of_range")
        if theta_percent > float(numeric_fields["SWING_MAX_THETA_PERCENT_OF_PREMIUM"]):
            swing.append("swing_theta_decay_too_high")
        if gamma_delta_per_1_percent_move > float(
            numeric_fields["SWING_MAX_GAMMA_DELTA_PER_1_PERCENT_MOVE"]
        ):
            swing.append("swing_gamma_too_high")
    if config.get("DAY_ONLY_OPTIONS") is True:
        style_reasons["SWING"].append("swing_disabled_day_only")
    eligible = [style for style, reasons in style_reasons.items() if not common and not reasons]
    return {
        "eligible_styles": eligible,
        "common_reasons": common,
        "style_reasons": style_reasons,
        "metrics": metrics,
    }


def annotate_option_styles(candidate: Mapping[str, Any], config: TradingConfig) -> dict[str, Any]:
    """Return a candidate copy annotated with deterministic style eligibility."""

    result = dict(candidate)
    assessment = assess_option_styles(result, config)
    result["eligible_trade_styles"] = assessment["eligible_styles"]
    result["greek_metrics"] = assessment["metrics"]
    result["style_rejection_reasons"] = {
        "common": assessment["common_reasons"],
        **assessment["style_reasons"],
    }
    return result
