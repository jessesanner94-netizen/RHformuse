"""Bounded, process-wide advisory locking for small runtime state files."""

from __future__ import annotations

import os
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


class RuntimeLockUnavailable(OSError):
    """The runtime state lock could not be acquired within its deadline."""


@contextmanager
def advisory_file_lock(path: Path, *, timeout_seconds: float = 5.0) -> Iterator[None]:
    """Lock a stable companion file; release automatically even if the caller fails.

    The lock file may remain on disk. Ownership belongs to the operating system's
    advisory lock, so a crashed process cannot leave a stale claim behind.
    """

    lock_path = path.with_name(f"{path.name}.lock")
    try:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        handle = lock_path.open("a+b")
    except OSError as exc:
        raise RuntimeLockUnavailable(str(exc)) from exc

    if os.name == "nt":
        import msvcrt
    else:
        import fcntl

    acquired = False
    deadline = time.monotonic() + timeout_seconds
    try:
        while not acquired:
            try:
                if os.name == "nt":
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except OSError as exc:
                if time.monotonic() >= deadline:
                    raise RuntimeLockUnavailable(str(exc)) from exc
                time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
        yield
    finally:
        if acquired:
            if os.name == "nt":
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()
