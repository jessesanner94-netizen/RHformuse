"""Resident live-position protection; read-only unless BOTH CLI and config permit execution."""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import time
from collections import deque
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.config import ConfigError, TradingConfig, load_config
from tools.live_monitor import adapt_snapshot
from tools.live_trading import monitor_live_portfolio
from tools.market_calendar import market_window
from tools.options_strategy import ledger_directory
from tools.paper_fast_monitor import retry_delay
from tools.robinhood_mcp import (
    _with_session,
    fetch_option_order_status,
    place_live_option_order,
    review_live_option_order,
)
from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock
from tools.state_manager import guarded_json_update, load_project_positions
from tools.windows_notify import send_notification

EASTERN = ZoneInfo("America/New_York")
QUIET_RECHECK_SECONDS = 300
ALERT_COOLDOWN_SECONDS = 1800
EXPOSURE_ALERT_COOLDOWN_SECONDS = 600


def _transient_failure(result: Mapping[str, Any]) -> bool:
    return result.get("reason") == "live_broker_rate_limit" or (
        result.get("reason") == "live_monitor_request_failed"
        and result.get("failed_operation", "snapshot") == "snapshot"
    )


def _loss_limit(config: TradingConfig, day: Mapping[str, Any]) -> float:
    values = [
        day.get("start_equity"),
        config.get("MAX_DAILY_LOSS_DOLLARS"),
        config.get("MAX_DAILY_LOSS_PERCENT"),
    ]
    if any(
        isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0
        for v in values
    ):
        raise ValueError("invalid finished-day risk inputs")
    return min(values[1], values[0] * values[2] / 100)


class FailureNotices:
    """Limit recurring connection notices across brief recoveries; preserve urgent alerts."""

    def __init__(self):
        self.last_sent = None
        self.first_failure = None
        self.failures = 0
        self.last_sustained_sent = None
        self.last_severity = None
        self.last_attempt = None

    def should_send(self, result: Mapping[str, Any], now: float) -> bool:
        transient = _transient_failure(result)
        if not transient:
            self.first_failure = None
            self.failures = 0
            return False
        self.failures += 1
        if self.first_failure is None:
            self.first_failure = now
        sustained = self.failures >= 3 or now - self.first_failure >= 30
        # Unknown exposure is treated conservatively, including unreadable local state.
        severity = "exposure" if result.get("exposure_present") is not False else "flat"
        cooldown = (
            EXPOSURE_ALERT_COOLDOWN_SECONDS if severity == "exposure" else ALERT_COOLDOWN_SECONDS
        )
        # Healthy ticks reset the consecutive-failure count, never the delivery
        # cooldown. New failure streaks while flat cannot bypass that cooldown.
        sustained_notice = (
            severity == "exposure"
            and sustained
            and (
                self.last_sustained_sent is None
                or now - self.last_sustained_sent >= EXPOSURE_ALERT_COOLDOWN_SECONDS
            )
        )
        send = (
            self.last_sent is None
            or now - self.last_sent >= cooldown
            or (severity == "exposure" and self.last_severity != "exposure")
            or sustained_notice
        )
        return send and (
            self.last_attempt is None
            or (self.last_sent is not None and self.last_sent >= self.last_attempt)
            or now - self.last_attempt >= 30
        )

    def sent(self, result: Mapping[str, Any], now: float):
        self.last_sent = now
        self.last_severity = "exposure" if result.get("exposure_present") is not False else "flat"
        if self.last_severity == "exposure" and result.get("sustained_failure", False):
            self.last_sustained_sent = now


def settings(config: TradingConfig) -> tuple[int, int, int]:
    values = (
        config.get("LIVE_OPEN_POSITION_POLL_SECONDS", 10),
        config.get("LIVE_POSITION_QUOTE_MAX_AGE_SECONDS", 20),
        config.get("LIVE_MONITOR_REQUEST_TIMEOUT_SECONDS", 8),
    )
    if any(isinstance(v, bool) or not isinstance(v, int) or not 1 <= v <= 30 for v in values):
        raise ConfigError("invalid live fast-monitor timing")
    if values[2] > values[0] or values[1] > 2 * values[0]:
        raise ConfigError("live monitor timeout/freshness exceeds polling budget")
    return values


def entry_monitor_ready(root: Path, config: TradingConfig, now: datetime) -> bool:
    """A read-only heartbeat or a dead/stale owner never authorizes new exposure."""
    if config.get("LIVE_FAST_MONITOR_ENABLED") is not True:
        return False
    interval, _, _ = settings(config)
    try:
        with advisory_file_lock(root / "state/runtime/live_fast_monitor.owner", timeout_seconds=0):
            return False
    except RuntimeLockUnavailable:
        pass
    try:
        record = json.loads((root / "state/runtime/live_fast_monitor.json").read_text())
        stamp = datetime.fromisoformat(record["timestamp"])
        age = (now - stamp).total_seconds()
        return (
            record.get("execution_enabled") is True
            and record.get("status") in {"QUIET", "MONITORED", "ENTRY_FILLED", "EXIT_FILLED"}
            and record.get("entry_safe") is True
            and record.get("strategy_epoch") == config.get("OPTIONS_STRATEGY_EPOCH")
            and -2 <= age <= 2 * interval
        )
    except (OSError, KeyError, TypeError, ValueError):
        return False


async def _snapshot() -> dict[str, Any]:
    # The loop owns reconnect timing/backoff: never retry a 429 immediately.
    return await _with_session("snapshot")


class LiveMonitor:
    def __init__(
        self,
        root: Path,
        *,
        execute: bool = False,
        snapshot_fetcher: Callable[..., Awaitable] = _snapshot,
        reviewer: Callable[..., Awaitable] = review_live_option_order,
        placer: Callable[..., Awaitable] = place_live_option_order,
        status_fetcher: Callable[..., Awaitable] = fetch_option_order_status,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
        monotonic: Callable[[], float] = time.monotonic,
    ):
        self.root, self.execute = root, execute
        self.snapshot, self.review, self.place, self.order_status = (
            snapshot_fetcher,
            reviewer,
            placer,
            status_fetcher,
        )
        self.clock, self.monotonic = clock, monotonic
        self.retry_at = 0.0
        self.polling = False
        self.epoch = None
        self.quiet_until = 0.0
        self.quiet_day = None
        self.quiet_config = None
        self.quiet_reason = None
        self.last_broker_check = None

    def _local_state(self, config: TradingConfig) -> Mapping[str, Any]:
        path = ledger_directory(self.root, config, "live") / "STATE.json"
        state = json.loads(path.read_text())
        if (
            not isinstance(state, dict)
            or not isinstance(state.get("day"), dict)
            or not isinstance(state.get("positions"), list)
            or not isinstance(state.get("pending_orders"), list)
            or state.get("position")
            or state.get("pending_order")
            or state.get("strategy_epoch") != config.get("OPTIONS_STRATEGY_EPOCH")
        ):
            raise ValueError("invalid finished-day ledger")
        return state

    def _exposure_present(self, config: TradingConfig) -> bool:
        try:
            state = self._local_state(config)
            return bool(state["positions"] or state["pending_orders"])
        except (OSError, KeyError, TypeError, ValueError):
            return True

    def _quiet_still_valid(self, config: TradingConfig) -> bool:
        if (
            self.quiet_config != config.values
            or self.quiet_day != self.clock().astimezone(EASTERN).date().isoformat()
        ):
            return False
        try:
            state = self._local_state(config)
            day = state["day"]
            return (
                day.get("date") == self.quiet_day
                and not state["positions"]
                and not state["pending_orders"]
                and (
                    (
                        self.quiet_reason == "daily_green_lock_active"
                        and config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
                        and day.get("green_lock_active") is True
                    )
                    or (
                        self.quiet_reason == "daily_loss_limit_reached"
                        and float(day["realized_pnl"]) <= -_loss_limit(config, day)
                    )
                )
            )
        except (OSError, KeyError, TypeError, ValueError):
            return False

    def _arm_quiet(self, config, result, snapshot):
        """Only a fresh, complete broker reconciliation can establish quiet mode."""
        day = result.get("day", {})
        if (
            not result.get("entry_safe")
            or snapshot.get("status") != "OK"
            or snapshot.get("positions") != []
            or snapshot.get("open_option_orders") != []
            or result.get("positions") != []
            or result.get("pending_order_count") != 0
            or day.get("date") != self.clock().astimezone(EASTERN).date().isoformat()
        ):
            return
        reason = None
        if (
            config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
            and day.get("green_lock_active") is True
        ):
            reason = "daily_green_lock_active"
        else:
            try:
                limit = _loss_limit(config, day)
                pnl = result["portfolio"]["daily_pnl"]
                if (
                    not isinstance(pnl, bool)
                    and isinstance(pnl, (int, float))
                    and math.isfinite(pnl)
                    and pnl <= -limit
                    and float(day["realized_pnl"]) <= -limit
                ):
                    reason = "daily_loss_limit_reached"
            except (KeyError, TypeError, ValueError):
                return
        if reason:
            self.quiet_day, self.quiet_reason = day["date"], reason
            self.quiet_config = dict(config.values)
            self.quiet_until = self.monotonic() + QUIET_RECHECK_SECONDS
            self.last_broker_check = snapshot.get("as_of")

    async def poll(self, config: TradingConfig) -> dict[str, Any]:
        self.epoch = config.get("OPTIONS_STRATEGY_EPOCH")
        if self.polling:
            return {
                "status": "ATTENTION",
                "reason": "live_monitor_poll_already_running",
                "orders_placed": 0,
                "orders_cancelled": 0,
            }
        if self.execute and (
            not config.live_execution_enabled or config.get("LIVE_FAST_MONITOR_ENABLED") is not True
        ):
            return {
                "status": "DISABLED",
                "reason": "live_execution_locked",
                "orders_placed": 0,
                "orders_cancelled": 0,
            }
        self.polling = True
        operation = "snapshot"
        try:
            _, max_age, timeout = settings(config)
            if (
                self.execute
                and self.monotonic() < self.quiet_until
                and self._quiet_still_valid(config)
            ):
                return {
                    "status": "QUIET",
                    "reason": "finished_for_day",
                    "finished_reason": self.quiet_reason,
                    "entry_safe": False,
                    "broker_check_skipped": True,
                    "last_broker_check": self.last_broker_check,
                    "next_broker_check_seconds": self.quiet_until - self.monotonic(),
                    "orders_placed": 0,
                    "orders_cancelled": 0,
                }
            self.quiet_until = 0.0
            if self.monotonic() < self.retry_at:
                return {
                    "status": "ATTENTION",
                    "reason": "live_broker_rate_limit",
                    "exposure_present": self._exposure_present(config),
                    "retry_in_seconds": self.retry_at - self.monotonic(),
                    "orders_placed": 0,
                }

            async def bounded(fn, *args, name="snapshot"):
                nonlocal operation
                operation = name
                try:
                    return await asyncio.wait_for(fn(*args), timeout=timeout)
                except Exception as exc:
                    self.retry_at = max(
                        self.retry_at, self.monotonic() + retry_delay(exc, self.clock())
                    )
                    raise

            if not self.execute:
                snapshot = await bounded(self.snapshot)
                result = adapt_snapshot(
                    snapshot,
                    project_positions=load_project_positions(self.root / "state/POSITIONS.md"),
                    policy=config.monitor_policy(),
                    now=self.clock(),
                    snapshot_max_age_seconds=max_age,
                    quote_max_age_seconds=max_age,
                )
                return {
                    **result,
                    "execution_enabled": False,
                    "entry_safe": False,
                    "orders_placed": 0,
                    "orders_cancelled": 0,
                }
            broker_snapshot = {}

            async def fresh_snapshot():
                nonlocal broker_snapshot
                broker_snapshot = await bounded(self.snapshot)
                return broker_snapshot

            result = await monitor_live_portfolio(
                config,
                project_root=self.root,
                snapshot_fetcher=fresh_snapshot,
                reviewer=lambda request: bounded(self.review, request, name="order_review"),
                placer=lambda request: bounded(self.place, request, name="order_placement"),
                order_status_fetcher=lambda order: bounded(
                    self.order_status, order, name="order_status"
                ),
                quote_max_age_seconds=max_age,
                snapshot_max_age_seconds=max_age,
                retry_snapshot=False,
            )
            actions = result.get("position_actions", [])
            result["entry_safe"] = (
                result.get("pending_order_count") == 0
                and not any(a.get("status") in {"ATTENTION", "BLOCKED"} for a in actions)
                and result.get("status") in {"QUIET", "MONITORED", "ENTRY_FILLED", "EXIT_FILLED"}
            )
            result["retry_in_seconds"] = max(0, self.retry_at - self.monotonic())
            self._arm_quiet(config, result, broker_snapshot)
            if self.quiet_until:
                result["finished_reason"] = self.quiet_reason
                result["next_broker_check_seconds"] = QUIET_RECHECK_SECONDS
                result["entry_safe"] = False
            return result
        except Exception as exc:
            return {
                "status": "ATTENTION",
                "reason": "live_monitor_request_failed",
                "error_type": type(exc).__name__,
                "failed_operation": operation,
                "exposure_present": self._exposure_present(config),
                "entry_safe": False,
                "retry_in_seconds": max(0, self.retry_at - self.monotonic()),
                "orders_placed": 0,
                "orders_cancelled": 0,
            }
        finally:
            self.polling = False


def publish(
    root: Path,
    result: Mapping[str, Any],
    *,
    monitor: LiveMonitor,
    started: datetime,
    tick: float,
    previous: datetime | None,
    interval: int,
):
    record = {
        "timestamp": monitor.clock().isoformat(),
        "poll_started_at": started.isoformat(),
        "execution_enabled": monitor.execute,
        "status": result.get("status"),
        "reason": result.get("reason"),
        "entry_safe": result.get("entry_safe", False),
        "strategy_epoch": monitor.epoch,
        "target_interval_seconds": interval,
        "duration_seconds": round(monitor.monotonic() - tick, 3),
        "observed_interval_seconds": round((started - previous).total_seconds(), 3)
        if previous
        else None,
        "retry_in_seconds": result.get("retry_in_seconds", 0),
        "position_actions": result.get("position_actions", []),
        "models_invoked": 0,
        "orders_placed": result.get("orders_placed", 0),
        "orders_cancelled": 0,
    }
    for field in (
        "error_type",
        "failed_operation",
        "exposure_present",
        "finished_reason",
        "broker_check_skipped",
        "last_broker_check",
        "next_broker_check_seconds",
    ):
        if field in result:
            record[field] = result[field]
    guarded_json_update(root / "state/runtime/live_fast_monitor.json", record, commit=True)
    if record["status"] not in {"QUIET", "MONITORED"} or record["position_actions"]:
        path = root / "state/runtime/live_fast_monitor" / f"{started.date()}.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, separators=(",", ":")) + "\n")
    return record


async def run(root: Path, *, monitor: LiveMonitor, once: bool = False, notifications: bool = False):
    previous = None
    notification_job = None
    last_notice = None
    failures = FailureNotices()
    queue = deque()
    transient_pending = False

    async def deliver_notices():
        nonlocal transient_pending
        while queue:
            alert, transient = queue.popleft()
            try:
                outcome = await asyncio.to_thread(
                    send_notification,
                    {"cycle": "positions", "live": alert},
                    project_root=root,
                    execute=True,
                )
                # A failed phone delivery must not start the incident cooldown.
                phone = outcome.get("channels", {}).get("ntfy", {})
                if transient and phone.get("status") == "SENT":
                    failures.sent(alert, monitor.monotonic())
            except Exception:
                # Notification transport must never terminate position protection.
                pass
            finally:
                if transient:
                    transient_pending = False

    while True:
        config = load_config(root / "CONFIG.md")
        interval, _, _ = settings(config)
        started, tick = monitor.clock(), monitor.monotonic()
        if not once and not market_window(started)[0]:
            # Invalidate the last healthy heartbeat immediately on shutdown.
            result = {"status": "SKIPPED", "reason": "outside_regular_session"}
        else:
            result = await monitor.poll(config)
        record = publish(
            root,
            result,
            monitor=monitor,
            started=started,
            tick=tick,
            previous=previous,
            interval=interval,
        )
        actions = result.get("position_actions", [])
        material = result.get("status") in {"ATTENTION", "BLOCKED"} or any(
            action.get("status") in {"SUBMITTED", "ENTRY_FILLED", "EXIT_FILLED"}
            for action in actions
        )
        notice = (
            result.get("status"),
            result.get("reason"),
            tuple((a.get("status"), a.get("order_id"), a.get("reason")) for a in actions),
        )
        transient = _transient_failure(result)
        failure_notice = failures.should_send(result, monitor.monotonic())
        if (
            notifications
            and monitor.execute
            and material
            and (failure_notice if transient else notice != last_notice)
            and (not transient or not transient_pending)
        ):
            alert = dict(result)
            if transient:
                transient_pending = True
                failures.last_attempt = monitor.monotonic()
                alert["sustained_failure"] = failures.failures >= 3
                label = "sustained failure" if alert["sustained_failure"] else "request failed"
                alert["reason"] = (
                    f"Broker monitor {label}"
                    f" ({result.get('failed_operation', 'snapshot')}: "
                    f"{result.get('error_type', result.get('reason'))}). "
                    "Monitoring continues; new entries require a healthy broker check."
                )
                if result.get("exposure_present") is not False:
                    alert["reason"] += (
                        " Position/order exposure is present or unknown; check Robinhood."
                    )
                queue.append((alert, True))
            else:
                # Preserve event order; never drop a fill or reconciliation alert because
                # an unrelated transient phone notification is still in flight.
                queue.append((alert, False))
            if notification_job is None or notification_job.done():
                notification_job = asyncio.create_task(deliver_notices())
            last_notice = notice
        if not material:
            last_notice = None
        if once or result.get("status") in {"DISABLED", "SKIPPED"}:
            if notification_job is not None:
                await notification_job
            return record
        previous = started
        # No catch-up bursts and no overlapping cycles when a request overruns.
        await asyncio.sleep(max(0.1, interval - (monitor.monotonic() - tick)))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--notifications", action="store_true")
    parser.add_argument(
        "--execute", action="store_true", help="Also requires the explicit live config flag"
    )
    args = parser.parse_args()
    root = args.project_root.resolve()
    try:
        with advisory_file_lock(root / "state/runtime/live_fast_monitor.owner", timeout_seconds=0):
            result = asyncio.run(
                run(
                    root,
                    monitor=LiveMonitor(root, execute=args.execute),
                    once=args.once,
                    notifications=args.notifications,
                )
            )
    except RuntimeLockUnavailable:
        result = {"status": "SKIPPED", "reason": "live_monitor_already_running"}
    print(json.dumps(result))
    return 1 if result.get("status") in {"ATTENTION", "DISABLED"} else 0


if __name__ == "__main__":
    raise SystemExit(main())
