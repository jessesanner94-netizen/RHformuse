# Deterministic Tools

All commands emit JSON. Scanner/risk functions are pure; persistent-write commands preview by
default. The manual coordinator has no live-order code path.

## `cheap_scan.py`

Rejects weak or untradeable inputs before expensive reasoning. Required candidate fields are:

- stable `candidate_id`, `symbol`, `option_type`, and `dte`
- underlying price, option bid/ask, volume/OI, and average daily underlying dollar volume
- exact booleans `quote_is_fresh` and `setup_qualified`

`setup_qualified` is deliberately supplied by an approved upstream deterministic research rule;
this repository does not invent technical weights. The gate returns `QUALIFIED`, `REJECTED`, or
`INSUFFICIENT_DATA`.

```powershell
uv run python -m tools.cheap_scan --input candidates.json
```

## `portfolio_risk.py`

Consumes `account` and `candidate` JSON objects. It enforces all configured hard limits and applies
the earnings multiplier only to an explicit earnings hold. An optional `historical` return matrix
produces skfolio CVaR and a correlation diagnostic. Analytics are reported separately from hard-rule
status so missing history is visible.

```powershell
uv run python -m tools.portfolio_risk --input risk-input.json
```

## `cost_tracker.py`

Records incremental costs, calculates economic profit/efficiency, and compares pre-/post-UW
decisions. `record` does not write without `--commit`.

```powershell
uv run python -m tools.cost_tracker summary --realized-net-pnl 0
uv run python -m tools.cost_tracker record --category codex --amount 1.25 `
  --attribution manual-dry-run
uv run python -m tools.cost_tracker uw-compare --pre-action WAIT --pre-conviction 0.4 `
  --post-action PASS --post-conviction 0.8
```

## `state_manager.py`

Parses actual position sections from `state/POSITIONS.md`, ignoring its template, and compares them
to a fresh broker snapshot. Missing/duplicate positions, quantity differences, malformed orders,
and unrecorded open orders are mismatches. Snapshot writes are atomic, hash-guarded, and preview-only
without `--commit`.

```powershell
uv run python -m tools.state_manager reconcile --broker broker-snapshot.json
uv run python -m tools.state_manager snapshot --input runtime-state.json
```

## `unusual_whales.py`

Provides a read-only Unusual Whales REST boundary for the cheap/deterministic and manual dry-run
layers. It only calls allowlisted official GET endpoints, reads its secret from `UW_API_KEY`, and
never puts the key in a URL or emitted JSON.

```powershell
uv run python -m tools.unusual_whales status
uv run python -m tools.unusual_whales market-tide
uv run python -m tools.unusual_whales flow-alerts --ticker SPY --min-premium 100000
uv run python -m tools.unusual_whales gex SPY
```

In trial mode, do not run a data command until the pre-UW action and conviction have been recorded.

## `dry_run.py`

Runs reconciliation and open-position management before the cheap gate. Qualified candidates pass
through risk checks and stop at `WAIT` for escalated research/review. Output always reports zero
orders placed/cancelled and no persistent writes.

## `position_monitor.py`

The October 9 active paper deployment uses `paper_fast_monitor.py` as a resident
loop with 10-second held-option quote checks and 20-second quote freshness. It
calls the existing locked paper exit/accounting engine, has no entry/live/model
authority, and writes timing/failure telemetry to
`state/runtime/paper_fast_monitor.json`. While flat there are no broker requests.
See `docs/PAPER_FAST_MONITOR.md` for its mode fences, throttling and task setup.

Evaluates a fresh position snapshot using deterministic stop-loss, profit-target, trailing-exit,
time-stop, event/thesis, protective-order, and reconciliation triggers. A quiet result returns
`wake_codex: false`, so an external scheduler can poll without starting an LLM run. It is a pure
dry-run component: it neither fetches data nor places/cancels orders.

```powershell
uv run python -m tools.position_monitor `
  --input tests/fixtures/position_monitor_quiet.json
```

## `robinhood_mcp.py`

Calls Robinhood's official remote MCP directly from Python, so routine position/quote polling does
not invoke GPT. The first command opens Robinhood's OAuth page; credentials are saved in the current
Windows user's DPAPI-encrypted local application storage rather than the repository. Every command
exposed by its public CLI is read-only. The internal live executor also uses programmatic
review/place/status adapters; no cancellation adapter is exposed.

```powershell
uv run python -m tools.robinhood_mcp auth
uv run python -m tools.robinhood_mcp snapshot
```

## `codex_trigger.py`

Consumes deterministic monitor output. `wake_codex: false` structurally skips Codex, while a true
trigger is still preview-only unless `--execute` is supplied. Triggered reviews pin
`gpt-5.6-sol`/`xhigh` and return structured decisions to the configured paper/live executor.

```powershell
uv run python -m tools.codex_trigger `
  --input monitor-result.json
```

## Live adapters and scheduled cycles

`live_monitor.py` reads Robinhood directly, normalizes option positions/orders/quotes, reconciles
them with `state/POSITIONS.md`, and feeds `position_monitor.py`. `news_delta.py` performs model-free
RSS hashing with a quiet first-run baseline. `option_discovery.py` uses the UW screener only for
diversified high-options-volume discovery and requires exact fresh Robinhood
bid/ask/volume/OI/Greeks plus the configured premium limit. `market_movers.py` runs Robinhood's
liquidity-filtered Daily Movers feed first, then sends its symbols through the same bounded
near-money contract and style-aware Greek gate.

`scheduled_cycle.py` combines those components. Routine results stop with no model. Python ranks a
bounded shortlist, rejects deterministic direction/flow/risk/event conflicts, and advances to the
next distinct symbol/direction without a model call. For the first aligned contract,
`decision_context.py` compresses four technical timeframes, exact contract quality, account/risk,
instrument-aware earnings status, UW flow, and bounded news/social labels. One isolated Luna/high
instance returns the final decision without tools or repository access. Robinhood's expiration-based
`chance_of_profit_long` is deliberately excluded from this pre-expiration decision packet. A
thirteen-call daily ceiling
and a material-state cache for same-contract `PASS`, unchanged `WAIT`, or a still-valid `BUY`
prevent repeated analysis. At the ceiling, the Windows opportunity task disables itself for the
rest of the trading day and a hidden weekday 9:25 a.m. reset task re-enables it. Structured
decisions return to deterministic Python for fresh reconciliation, risk checks, Robinhood review,
and configured paper/live application.

```powershell
uv run python -m tools.scheduled_cycle positions
uv run python -m tools.scheduled_cycle news
uv run python -m tools.scheduled_cycle opportunities
```

`live_trading.py` is not a general order CLI. It is invoked only by `scheduled_cycle.py`, persists a
client UUID/order ID before retries, rejects any non-empty broker alert, never cancels/reprices an
order, and calculates the 25% stop and 30% target from the actual entry fill. GPT can recommend an
earlier exit but cannot widen or delay those deterministic controls.

Robinhood equity quotes timestamp prices with `venue_last_trade_time` and
`venue_last_non_reg_trade_time`; option quotes use `updated_at`. The entry gate validates the
timestamp paired with the newest equity trade and reports each missing/stale refresh component.
