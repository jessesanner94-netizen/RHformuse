"""Poll public news feeds and wake a model only when a genuinely new item appears."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections.abc import Callable, Iterable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote_plus
from urllib.request import Request, urlopen
from xml.etree import ElementTree

from tools.state_manager import guarded_json_update

TICKER = re.compile(r"^[A-Z][A-Z0-9.-]{0,14}$")
MAX_SEEN_ITEMS = 5000


def _safe_symbols(symbols: Iterable[str]) -> list[str]:
    normalized = sorted({symbol.strip().upper() for symbol in symbols if symbol.strip()})
    invalid = [symbol for symbol in normalized if not TICKER.fullmatch(symbol)]
    if invalid:
        raise ValueError(f"invalid ticker(s): {', '.join(invalid)}")
    return normalized


def fetch_google_news_rss(symbol: str, *, timeout: float = 15.0) -> list[dict[str, str]]:
    """Fetch a bounded one-day Google News RSS search without using a model."""

    query = quote_plus(f"{symbol} stock when:1d")
    url = f"https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en"
    request = Request(url, headers={"User-Agent": "Robinhood-Agentic-News-Monitor/0.1"})
    with urlopen(request, timeout=timeout) as response:
        raw = response.read()
    root = ElementTree.fromstring(raw)
    items: list[dict[str, str]] = []
    for node in root.findall("./channel/item")[:100]:
        title = (node.findtext("title") or "").strip()
        link = (node.findtext("link") or "").strip()
        published = (node.findtext("pubDate") or "").strip()
        source_node = node.find("source")
        source = (source_node.text or "").strip() if source_node is not None else ""
        if title and link:
            items.append(
                {
                    "symbol": symbol,
                    "title": title,
                    "link": link,
                    "published": published,
                    "source": source,
                }
            )
    return items


def _item_id(item: Mapping[str, Any]) -> str:
    stable = "\n".join(
        str(item.get(field, "")).strip().casefold() for field in ("symbol", "title", "link")
    )
    return hashlib.sha256(stable.encode("utf-8")).hexdigest()


def _load_seen(path: Path) -> list[str] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    seen = payload.get("seen") if isinstance(payload, Mapping) else None
    if not isinstance(seen, list) or not all(isinstance(item, str) for item in seen):
        return []
    return seen


def detect_news_delta(
    symbols: Iterable[str],
    *,
    state_path: Path,
    fetcher: Callable[[str], list[dict[str, str]]] = fetch_google_news_rss,
    commit: bool = True,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Hash/deduplicate headlines; the first successful run creates a quiet baseline."""

    checked_at = (now or datetime.now(UTC)).astimezone(UTC).isoformat()
    normalized = _safe_symbols(symbols)
    if not normalized:
        return {
            "status": "QUIET",
            "wake_luna": False,
            "reason": "no_open_position_symbols",
            "symbols": [],
            "new_items": [],
            "feed_errors": [],
            "persistent_write": None,
        }

    items: list[dict[str, str]] = []
    errors: list[dict[str, str]] = []
    for symbol in normalized:
        try:
            items.extend(fetcher(symbol))
        except Exception as exc:  # isolate a failed feed while preserving other symbols
            errors.append({"symbol": symbol, "error": f"{type(exc).__name__}: {exc}"})

    previous = _load_seen(state_path)
    baseline_created = previous is None
    previous_ids = set(previous or [])
    unique: dict[str, dict[str, str]] = {}
    for item in items:
        identifier = _item_id(item)
        unique.setdefault(identifier, dict(item))
    new_items = (
        []
        if baseline_created
        else [
            {"id": identifier, **item}
            for identifier, item in unique.items()
            if identifier not in previous_ids
        ]
    )
    all_seen = list(dict.fromkeys([*unique.keys(), *(previous or [])]))[:MAX_SEEN_ITEMS]
    write_result: dict[str, Any] | None = None
    if items:
        write_result = guarded_json_update(
            state_path,
            {
                "updated_at": checked_at,
                "symbols": normalized,
                "seen": all_seen,
            },
            commit=commit,
        )
    status = "NEW_ITEMS" if new_items else "DEGRADED" if errors else "QUIET"
    return {
        "status": status,
        "wake_luna": bool(new_items),
        "baseline_created": baseline_created,
        "symbols": normalized,
        "items_seen": len(unique),
        "new_items": new_items,
        "feed_errors": errors,
        "persistent_write": write_result,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("symbols", nargs="*")
    parser.add_argument("--state", type=Path, default=Path("state/runtime/news_seen.json"))
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()
    try:
        result = detect_news_delta(
            args.symbols,
            state_path=args.state,
            commit=not args.preview,
        )
    except (OSError, ValueError, ElementTree.ParseError) as exc:
        result = {
            "status": "ERROR",
            "wake_luna": False,
            "error": f"{type(exc).__name__}: {exc}",
        }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 1 if result["status"] == "ERROR" else 0


if __name__ == "__main__":
    raise SystemExit(main())
