"""Numerical/semantic research inputs. Never include broker account or secret data."""

from __future__ import annotations

import math
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

FEATURE_VERSION = "jev-features-v1"


def number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def market_features(packet: Mapping[str, Any]) -> dict[str, Any]:
    candidate = packet.get("candidate", {})
    technical = packet.get("technical", {})
    candidate_keys = (
        "candidate_id",
        "asset_type",
        "direction",
        "venue",
        "hold_minutes",
        "invalidation_price",
        "target_price",
        "symbol",
        "option_type",
        "expiration",
        "strike",
        "dte",
        "underlying_price",
        "bid",
        "ask",
        "spread_percent",
        "volume",
        "open_interest",
        "quote_updated_at",
        "quote_is_fresh",
        "eligible_styles",
        "python_preferred_style",
        "greeks",
        "underlying_liquidity",
    )
    frames: dict[str, Any] = {}
    for name, raw in technical.get("timeframes", {}).items():
        if not isinstance(raw, Mapping):
            continue
        # Explicit allowlist excludes raw bars, prose feeds, account and broker IDs.
        values = {
            key: raw[key]
            for key in (
                "status",
                "trend",
                "trend_score",
                "rsi_14",
                "macd",
                "macd_histogram",
                "relative_volume_20",
                "atr_14",
                "price",
                "close",
                "change_percent",
                "as_of",
                "last_bar_at",
                "bar_end",
                "bars_count",
                "latest_close",
                "change_1_bar_percent",
                "change_3_bar_percent",
                "change_10_bar_percent",
                "sma_20",
                "sma_50",
            )
            if key in raw
        }
        rvol = number(raw.get("relative_volume_20"))
        values["relative_volume_state"] = (
            "unavailable"
            if rvol is None
            else "elevated"
            if rvol >= 1.5
            else "normal"
            if rvol >= 0.8
            else "subdued"
        )
        if isinstance(raw.get("bars"), int) and not isinstance(raw.get("bars"), bool):
            values["bars"] = raw["bars"]
        frames[str(name)] = values
    structure = technical.get("intraday_structure", {})
    structure = structure if isinstance(structure, Mapping) else {}
    allowed_structure = (
        "status",
        "session_date",
        "opening_range_high",
        "opening_range_low",
        "opening_range_midpoint",
        "latest_close",
        "opening_range_position",
        "held_opening_range_low",
        "held_opening_range_high",
        "swept_and_reclaimed_opening_range_low",
        "swept_and_rejected_opening_range_high",
        "bias_score",
        "bias",
        "session_vwap",
    )
    compact_structure = {
        key: structure[key]
        for key in allowed_structure
        if key in structure and isinstance(structure[key], (str, int, float, bool))
    }
    timing = structure.get("entry_timing", {})
    timing = timing if isinstance(timing, Mapping) else {}
    compact_structure["entry_timing"] = {
        key: timing[key]
        for key in (
            "status",
            "completed_bar_at",
            "completed_bar_age_seconds",
            "latest_completed_close",
            "session_vwap",
            "vwap_distance_percent",
            "session_high",
            "session_low",
            "distance_from_session_high_percent",
            "distance_from_session_low_percent",
        )
        if key in timing and isinstance(timing[key], (str, int, float, bool))
    }
    price = number(candidate.get("underlying_price"))
    vwap = number(structure.get("session_vwap", timing.get("session_vwap")))
    atr = number(technical.get("timeframes", {}).get("5M", {}).get("atr_14"))
    distance = (price - vwap) / atr if None not in (price, vwap, atr) and atr > 0 else None
    return {
        "feature_version": FEATURE_VERSION,
        "hard_exit_policy": {
            key: value
            for key, value in packet.get("hard_exit_policy", {}).items()
            if key in ("stop_loss_percent", "take_profit_percent", "software_managed")
        },
        "completed_minute": {
            key: value
            for key, value in packet.get("completed_minute", {}).items()
            if key in ("open", "high", "low", "close", "volume", "ends_at")
        },
        "as_of": packet.get("as_of"),
        "candidate": {key: candidate[key] for key in candidate_keys if key in candidate},
        "technical": {"timeframes": frames, "intraday_structure": compact_structure},
        "vwap_distance_atr": distance,
        "vwap_position": (
            "unavailable"
            if distance is None
            else "near"
            if abs(distance) < 0.2
            else "moderately_above"
            if 0 < distance <= 1
            else "far_above"
            if distance > 1
            else "moderately_below"
            if distance >= -1
            else "far_below"
        ),
        "news_label": packet.get("news", {}).get("label"),
        "social_label": packet.get("social", {}).get("label"),
        "python_gate": packet.get("python_gate", {}),
        "selection_scope": "python_qualified_shortlist_not_entire_market",
        "score_interpretation": "uncalibrated_model_scores_not_trade_win_probabilities",
    }


def completed_minute(bar: Mapping[str, Any], *, now: datetime) -> str | None:
    """Accept only explicitly complete, noninterpolated, recent one-minute bars."""
    if now.tzinfo is None or bar.get("interpolated") is not False:
        return None
    try:
        start = datetime.fromisoformat(str(bar["starts_at"]).replace("Z", "+00:00"))
        end = datetime.fromisoformat(str(bar["ends_at"]).replace("Z", "+00:00"))
    except (KeyError, ValueError):
        return None
    if start.tzinfo is None or end.tzinfo is None:
        return None
    age = (now - end).total_seconds()
    if (end - start).total_seconds() != 60 or not 0 <= age <= 120:
        return None
    return end.astimezone(UTC).isoformat()
