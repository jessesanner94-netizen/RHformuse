"""Separate review metadata from executable order arguments and classify failures."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class OrderRequestRejected(ValueError):
    """The order was rejected locally, before the placement call was sent."""


ORDER_FIELDS = {
    "account_number",
    "legs",
    "direction",
    "type",
    "quantity",
    "price",
    "stop_price",
    "time_in_force",
    "market_hours",
    "ref_id",
}
REVIEW_ONLY_FIELDS = {"chain_symbol", "underlying_type"}


def placement_arguments(request: Mapping[str, Any]) -> dict[str, Any]:
    unknown = set(request) - ORDER_FIELDS - REVIEW_ONLY_FIELDS
    if unknown:
        raise OrderRequestRejected(f"unsupported placement fields: {', '.join(sorted(unknown))}")
    # These identify fee/collateral context for review, not executable order semantics.
    return {key: value for key, value in request.items() if key not in REVIEW_ONLY_FIELDS}


def exception_leaves(exc: BaseException) -> list[BaseException]:
    children = getattr(exc, "exceptions", ())
    if isinstance(children, tuple) and children:
        return [leaf for child in children for leaf in exception_leaves(child)]
    if exc.__cause__ is not None:
        return exception_leaves(exc.__cause__)
    return [exc]


def exception_summary(exc: BaseException) -> str:
    return " | ".join(f"{type(leaf).__name__}: {leaf}" for leaf in exception_leaves(exc))[:1000]


def rejected_before_submission(exc: BaseException) -> bool:
    from mcp.shared.exceptions import McpError

    # Only definite local/schema rejections permit clearing a pending submission. A timeout,
    # disconnect, or mixed exception group may hide a broker-accepted order: retain its ref_id.
    return all(
        isinstance(leaf, OrderRequestRejected)
        or (isinstance(leaf, McpError) and leaf.error.code == -32602)
        for leaf in exception_leaves(exc)
    )
