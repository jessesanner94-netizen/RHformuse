"""Bounded, fail-closed collection of Robinhood resting equity price books."""

from __future__ import annotations

import asyncio
import inspect
import json
import math
import sqlite3
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Literal, Protocol

MAX_SYMBOLS, MAX_LEVELS_PER_SIDE = 4, 1_000
MAX_REPORTED_ZONES, MAX_REPORTED_ZONE_EVENTS = 6, 12
FETCH_TIMEOUT_SECONDS = 10.0
MAX_BOOK_AGE, MAX_FUTURE_SKEW, RETENTION = (
    timedelta(seconds=30),
    timedelta(seconds=5),
    timedelta(minutes=60),
)


class OrderBookValidationError(ValueError):
    """A provider payload cannot safely be used as level-two depth."""


@dataclass(frozen=True)
class Level:
    price: float
    quantity: float


@dataclass(frozen=True)
class Level2Book:
    symbol: str
    updated_at: datetime
    asks: tuple[Level, ...]
    bids: tuple[Level, ...]


@dataclass(frozen=True)
class ExecutedTradePrint:
    """A genuine provider-supplied execution, separate from resting depth."""

    executed_at: datetime
    price: float
    quantity: float
    venue: str | None
    side: Literal["buy", "sell", "unknown"]


class ExecutedTradePrintProvider(Protocol):
    """Future provider boundary; Robinhood price-book data does not implement it."""

    async def fetch_executed_trade_prints(
        self, symbols: list[str]
    ) -> Sequence[ExecutedTradePrint]: ...


Fetcher = Callable[[list[str]], Awaitable[Mapping[str, Any]] | Mapping[str, Any]]


def _utc(value: datetime | None = None) -> datetime:
    result = value or datetime.now(UTC)
    if result.tzinfo is None:
        raise OrderBookValidationError("now must be timezone-aware")
    return result.astimezone(UTC)


def _number(value: Any, field: str) -> float:
    if isinstance(value, bool):
        raise OrderBookValidationError(f"{field} must be a finite number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise OrderBookValidationError(f"{field} must be a finite number") from exc
    if not math.isfinite(result) or result <= 0:
        raise OrderBookValidationError(f"{field} must be positive and finite")
    return result


def _timestamp(value: Any, *, field: str = "updated_at") -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise OrderBookValidationError(f"{field} must be an ISO-8601 timestamp")
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise OrderBookValidationError(f"{field} must be an ISO-8601 timestamp") from exc
    if result.tzinfo is None:
        raise OrderBookValidationError(f"{field} must include an offset")
    return result.astimezone(UTC)


def _levels(value: Any, *, side: str) -> tuple[Level, ...]:
    if not isinstance(value, list):
        raise OrderBookValidationError(f"{side} must be a list")
    if len(value) > MAX_LEVELS_PER_SIDE:
        raise OrderBookValidationError(f"{side} exceeds maximum depth")
    result: list[Level] = []
    prices: set[float] = set()
    prior: float | None = None
    for index, row in enumerate(value):
        if not isinstance(row, Mapping):
            raise OrderBookValidationError(f"{side}[{index}] must be an object")
        level = Level(
            _number(row.get("price"), f"{side}[{index}].price"),
            _number(row.get("quantity"), f"{side}[{index}].quantity"),
        )
        if level.price in prices:
            raise OrderBookValidationError(f"duplicate {side} price")
        if prior is not None and (
            (side == "asks" and level.price <= prior) or (side == "bids" and level.price >= prior)
        ):
            raise OrderBookValidationError(f"{side} levels are out of order")
        prices.add(level.price)
        prior = level.price
        result.append(level)
    return tuple(result)


def parse_level2_book(payload: Mapping[str, Any], *, now: datetime | None = None) -> Level2Book:
    """Parse a price-book row with strict values, ordering, and clock checks."""
    if not isinstance(payload, Mapping):
        raise OrderBookValidationError("book must be an object")
    symbol = payload.get("symbol")
    if not isinstance(symbol, str) or not symbol.strip():
        raise OrderBookValidationError("symbol is required")
    updated_at, current = _timestamp(payload.get("updated_at")), _utc(now)
    if updated_at > current + MAX_FUTURE_SKEW:
        raise OrderBookValidationError("book timestamp is in the future")
    if current - updated_at > MAX_BOOK_AGE:
        raise OrderBookValidationError("book timestamp is stale")
    asks, bids = (
        _levels(payload.get("asks"), side="asks"),
        _levels(payload.get("bids"), side="bids"),
    )
    if asks and bids and bids[0].price >= asks[0].price:
        raise OrderBookValidationError("crossed or locked book")
    return Level2Book(symbol.strip().upper(), updated_at, asks, bids)


def parse_price_book(payload: Mapping[str, Any], *, now: datetime | None = None) -> Level2Book:
    return parse_level2_book(payload, now=now)


def parse_executed_trade_print(payload: Mapping[str, Any]) -> ExecutedTradePrint:
    """Only accept a separately labeled genuine print; resting levels never enter here."""
    side = str(payload.get("side") or "unknown").casefold()
    venue = payload.get("venue")
    if venue is not None and not isinstance(venue, str):
        raise OrderBookValidationError("venue must be a string when supplied")
    return ExecutedTradePrint(
        _timestamp(payload.get("executed_at"), field="executed_at"),
        _number(payload.get("price"), "print.price"),
        _number(payload.get("quantity"), "print.quantity"),
        venue,
        side if side in {"buy", "sell", "unknown"} else "unknown",
    )


def _imbalance(bids: Sequence[Level], asks: Sequence[Level]) -> float | None:
    bid, ask = sum(x.quantity for x in bids), sum(x.quantity for x in asks)
    return (bid - ask) / (bid + ask) if bid + ask else None


def _wall(levels: Sequence[Level]) -> dict[str, float] | None:
    return asdict(max(levels, key=lambda x: (x.quantity, x.price))) if levels else None


def book_features(book: Level2Book) -> dict[str, Any]:
    """Displayed-liquidity features only; none represents executed flow."""
    bid, ask = (book.bids[0] if book.bids else None), (book.asks[0] if book.asks else None)
    bid_depth, ask_depth = sum(x.quantity for x in book.bids), sum(x.quantity for x in book.asks)
    bid_wall, ask_wall = _wall(book.bids), _wall(book.asks)
    mid = (bid.price + ask.price) / 2 if bid and ask else None
    weighted_bid = sum(x.quantity / max((mid or x.price) - x.price, 1e-6) for x in book.bids)
    weighted_ask = sum(x.quantity / max(x.price - (mid or x.price), 1e-6) for x in book.asks)
    return {
        "best_bid": asdict(bid) if bid else None,
        "best_ask": asdict(ask) if ask else None,
        "spread": ask.price - bid.price if bid and ask else None,
        "mid": mid,
        "microprice": (ask.price * bid.quantity + bid.price * ask.quantity)
        / (bid.quantity + ask.quantity)
        if bid and ask
        else None,
        "near_imbalance": _imbalance(book.bids[:3], book.asks[:3]),
        "cumulative_imbalance": _imbalance(book.bids, book.asks),
        "weighted_imbalance": (weighted_bid - weighted_ask) / (weighted_bid + weighted_ask)
        if weighted_bid + weighted_ask
        else None,
        "bid_depth": bid_depth,
        "ask_depth": ask_depth,
        "largest_bid_wall": bid_wall,
        "largest_ask_wall": ask_wall,
        "largest_bid_wall_relative_depth": bid_wall["quantity"] / bid_depth if bid_wall else None,
        "largest_ask_wall_relative_depth": ask_wall["quantity"] / ask_depth if ask_wall else None,
        "executed_trade_prints": {
            "status": "UNAVAILABLE",
            "reason": "provider_has_resting_depth_only",
        },
        "absorption": {"status": "UNAVAILABLE", "reason": "requires_executed_trade_prints"},
        "exhaustion": {"status": "UNAVAILABLE", "reason": "requires_executed_trade_prints"},
    }


def _connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.execute(
        """CREATE TABLE IF NOT EXISTS orderbook_snapshots (
        symbol TEXT NOT NULL, updated_at REAL NOT NULL, observed_at REAL NOT NULL,
        bids_json TEXT NOT NULL, asks_json TEXT NOT NULL,
        PRIMARY KEY (symbol, updated_at))"""
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_orderbook_symbol_time "
        "ON orderbook_snapshots(symbol, updated_at)"
    )
    return connection


def _serialize(levels: Sequence[Level]) -> str:
    return json.dumps([asdict(x) for x in levels], separators=(",", ":"), sort_keys=True)


def _restore(symbol: str, row: tuple[Any, ...]) -> Level2Book:
    stamp, bids, asks = row
    return Level2Book(
        symbol,
        datetime.fromtimestamp(float(stamp), UTC),
        tuple(Level(**x) for x in json.loads(asks)),
        tuple(Level(**x) for x in json.loads(bids)),
    )


def _save(connection: sqlite3.Connection, book: Level2Book, *, now: datetime) -> None:
    latest = connection.execute(
        "SELECT MAX(updated_at) FROM orderbook_snapshots WHERE symbol = ?", (book.symbol,)
    ).fetchone()[0]
    stamp = book.updated_at.timestamp()
    if latest is not None and stamp <= float(latest):
        raise OrderBookValidationError(
            "duplicate snapshot timestamp"
            if stamp == float(latest)
            else "out-of-order snapshot timestamp"
        )
    connection.execute(
        "INSERT INTO orderbook_snapshots "
        "(symbol, updated_at, observed_at, bids_json, asks_json) VALUES (?, ?, ?, ?, ?)",
        (book.symbol, stamp, now.timestamp(), _serialize(book.bids), _serialize(book.asks)),
    )


def _history(
    connection: sqlite3.Connection, symbol: str, *, start: datetime, end: datetime
) -> list[Level2Book]:
    rows = connection.execute(
        "SELECT updated_at, bids_json, asks_json FROM orderbook_snapshots "
        "WHERE symbol = ? AND updated_at >= ? AND updated_at <= ? AND observed_at <= ? "
        "ORDER BY updated_at ASC",
        (symbol, start.timestamp(), end.timestamp(), end.timestamp()),
    ).fetchall()
    return [_restore(symbol, row) for row in rows]


def _proxies(features: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if len(features) < 2:
        absent = {"observed": False, "reason": "need_prior_book"}
        return {"test": absent, "rejection": absent}
    current, prior = features[-1], features[-2]
    test: dict[str, Any] = {"observed": False, "reason": "no_same_price_top_level_change"}
    for side in ("best_bid", "best_ask"):
        before, after = prior.get(side), current.get(side)
        if (
            before
            and after
            and before["price"] == after["price"]
            and before["quantity"] != after["quantity"]
        ):
            test = {
                "observed": True,
                "side": side,
                "price": after["price"],
                "displayed_quantity_change": after["quantity"] - before["quantity"],
                "meaning": (
                    "resting-depth test proxy; cancellations and executions are indistinguishable"
                ),
            }
            break
    rejection: dict[str, Any] = {
        "observed": False,
        "reason": "need_approach_then_moveaway_quote_path",
    }
    if len(features) >= 3:
        old = features[-3]
        for side, approach, away in (
            ("best_bid", lambda a, b: b > a, lambda a, b: b < a),
            ("best_ask", lambda a, b: b < a, lambda a, b: b > a),
        ):
            first, middle, last = old.get(side), prior.get(side), current.get(side)
            if (
                first
                and middle
                and last
                and approach(first["price"], middle["price"])
                and away(middle["price"], last["price"])
            ):
                rejection = {
                    "observed": True,
                    "side": side,
                    "approached_price": middle["price"],
                    "moved_away_price": last["price"],
                    "meaning": "quote-path rejection proxy; not a confirmed trade rejection",
                }
                break
    return {"test": test, "rejection": rejection}


def _zones(history: Sequence[Level2Book]) -> dict[str, Any]:
    """Track fixed side/price displayed zones, retaining former large walls."""
    tracked: dict[tuple[str, float], dict[str, Any]] = {}
    for index, book in enumerate(history):
        for side, levels in (("bid", book.bids), ("ask", book.asks)):
            depth = sum(x.quantity for x in levels)
            for level in levels:
                key = side, level.price
                zone = tracked.setdefault(
                    key,
                    {
                        "side": side,
                        "price": level.price,
                        "first": book.updated_at,
                        "last": book.updated_at,
                        "initial": level.quantity,
                        "max": level.quantity,
                        "initial_share": level.quantity / depth if depth else None,
                        "count": 0,
                        "last_index": index,
                    },
                )
                zone.update(
                    {
                        "last": book.updated_at,
                        "max": max(zone["max"], level.quantity),
                        "last_index": index,
                    }
                )
                zone["count"] += 1
                if index == len(history) - 1:
                    zone.update(
                        {
                            "current": level.quantity,
                            "current_share": level.quantity / depth if depth else None,
                        }
                    )
    rows, events = [], []
    for zone in tracked.values():
        present = zone["last_index"] == len(history) - 1
        current, initial = (zone.get("current", 0.0) if present else 0.0), zone["initial"]
        change = current - initial
        state = (
            "disappeared"
            if not present
            else "growing"
            if change > 0
            else "shrinking"
            if change < 0
            else "persistent"
        )
        if not present or zone["first"] != history[0].updated_at:
            events.append(
                {
                    "at": (zone["last"] if not present else zone["first"]).isoformat(),
                    "side": zone["side"],
                    "price": zone["price"],
                    "event": "disappeared" if not present else "appeared",
                    "cause": "ambiguous_resting_order_change",
                }
            )
        rows.append(
            {
                "side": zone["side"],
                "price": zone["price"],
                "state": state,
                "first_seen": zone["first"].isoformat(),
                "last_seen": zone["last"].isoformat(),
                "persistence_seconds": (zone["last"] - zone["first"]).total_seconds(),
                "initial_size": initial,
                "max_size": zone["max"],
                "current_size": current,
                "size_change": change,
                "size_change_ratio": current / initial - 1 if initial else None,
                "initial_relative_depth": zone["initial_share"],
                "current_relative_depth": zone.get("current_share", 0.0) if present else 0.0,
                "observations": zone["count"],
                "cause": "ambiguous_resting_order_change",
            }
        )
    rows.sort(key=lambda x: (-x["max_size"], x["side"], x["price"]))
    events.sort(key=lambda x: x["at"], reverse=True)
    return {"zones": rows[:MAX_REPORTED_ZONES], "events": events[:MAX_REPORTED_ZONE_EVENTS]}


def _wall_change(
    current: Mapping[str, Any] | None, prior: Mapping[str, Any] | None
) -> dict[str, Any]:
    if current is None and prior is None:
        return {"state": "unavailable"}
    if current is None:
        return {"state": "disappeared", "cause": "ambiguous_resting_order_change"}
    if prior is None:
        return {"state": "appeared", "cause": "ambiguous_resting_order_change"}
    if current["price"] != prior["price"]:
        return {"state": "migrated", "from_price": prior["price"], "to_price": current["price"]}
    return {
        "state": "persistent",
        "growth": current["quantity"] - prior["quantity"],
        "growth_ratio": current["quantity"] / prior["quantity"] - 1 if prior["quantity"] else None,
    }


def _window_summary(
    history: Sequence[Level2Book], *, now: datetime, seconds: int
) -> dict[str, Any]:
    if not history:
        return {
            "status": "INSUFFICIENT_HISTORY",
            "temporal_available": False,
            "samples": 0,
            "coverage_seconds": 0.0,
            "coverage_ratio": 0.0,
            "gap_count": 0,
            "largest_gap_seconds": None,
            "freshness_seconds": None,
        }
    features, times = [book_features(x) for x in history], [x.updated_at for x in history]
    gaps = [
        (after - before).total_seconds() for before, after in zip(times, times[1:], strict=False)
    ]
    coverage, ratio = (times[-1] - times[0]).total_seconds(), 1.0
    if seconds:
        ratio = min(1.0, coverage / seconds)
        status, temporal = (
            ("INSUFFICIENT_HISTORY", False)
            if len(history) == 1
            else ("PARTIAL", False)
            if ratio < 0.8
            else ("OK", True)
        )
    else:
        status, temporal = "CURRENT_ONLY", False
    current, prior = features[-1], features[-2] if len(features) > 1 else None
    elapsed = (times[-1] - times[-2]).total_seconds() if len(times) > 1 else None
    velocity = (
        None
        if not elapsed or prior is None
        else {
            "bid_depth_per_second": (current["bid_depth"] - prior["bid_depth"]) / elapsed,
            "ask_depth_per_second": (current["ask_depth"] - prior["ask_depth"]) / elapsed,
        }
    )
    proxies = _proxies(features)
    flips = sum(
        1
        for old, new in zip(features, features[1:], strict=False)
        if old["near_imbalance"] is not None
        and new["near_imbalance"] is not None
        and old["near_imbalance"] * new["near_imbalance"] < 0
    )
    return {
        "status": status,
        "temporal_available": temporal,
        "samples": len(history),
        "coverage_seconds": coverage,
        "coverage_ratio": ratio,
        "gap_count": sum(gap > 30 for gap in gaps),
        "largest_gap_seconds": max(gaps, default=None),
        "freshness_seconds": max(0.0, (now - times[-1]).total_seconds()),
        "features": current,
        "spread_delta": current["spread"] - prior["spread"]
        if prior and current["spread"] is not None and prior["spread"] is not None
        else None,
        "depth_velocity": velocity,
        "book_flips": flips,
        "wall_changes": {
            "bid": _wall_change(
                current["largest_bid_wall"], prior["largest_bid_wall"] if prior else None
            ),
            "ask": _wall_change(
                current["largest_ask_wall"], prior["largest_ask_wall"] if prior else None
            ),
        },
        "liquidity_zones": _zones(history),
        "migration_proxy": proxies["rejection"],
        "observed_proxies": proxies,
    }


def _summary(connection: sqlite3.Connection, book: Level2Book, *, now: datetime) -> dict[str, Any]:
    if not book.bids or not book.asks:
        return {
            "status": "NO_DEPTH",
            "symbol": book.symbol,
            "updated_at": book.updated_at.isoformat(),
            "reason": "provider_returned_empty_bid_or_ask_depth",
            "temporal_available": False,
            "executed_trade_prints": {"status": "UNAVAILABLE"},
        }
    windows = {
        name: _window_summary(
            [book]
            if seconds == 0
            else _history(connection, book.symbol, start=now - timedelta(seconds=seconds), end=now),
            now=now,
            seconds=seconds,
        )
        for name, seconds in (("current", 0), ("1m", 60), ("5m", 300), ("15m", 900), ("60m", 3600))
    }
    temporal = any(row["temporal_available"] for name, row in windows.items() if name != "current")
    return {
        "status": "OK",
        "symbol": book.symbol,
        "updated_at": book.updated_at.isoformat(),
        "temporal_available": temporal,
        "windows": windows,
        "features": windows["current"]["features"],
        "executed_trade_prints": {
            "status": "UNAVAILABLE",
            "reason": "provider_has_resting_depth_only",
        },
    }


def _error_status(message: str) -> str:
    text = message.casefold()
    if "stale" in text:
        return "STALE"
    if "future" in text:
        return "FUTURE"
    if "out-of-order" in text:
        return "OUT_OF_ORDER"
    if "crossed" in text or "locked" in text:
        return "CROSSED"
    if "duplicate" in text:
        return "DUPLICATE"
    return "INVALID_BOOK"


async def collect_orderbooks(
    symbols: Sequence[str],
    store_path: Path | str,
    *,
    now: datetime | None = None,
    fetcher: Fetcher | None = None,
) -> dict[str, Any]:
    """Make one bounded, read-only fetch; this function never polls or submits an order."""
    requested = [str(symbol).strip().upper() for symbol in symbols]
    if not 1 <= len(requested) <= MAX_SYMBOLS or any(not x for x in requested):
        raise ValueError("collect_orderbooks requires one to four non-empty symbols")
    if len(set(requested)) != len(requested):
        raise ValueError("symbols must be unique")
    current = _utc(now)
    if fetcher is None:
        from tools.robinhood_mcp import fetch_equity_price_book

        fetcher = fetch_equity_price_book
    try:
        response = fetcher(requested)
        payload = await asyncio.wait_for(
            response if inspect.isawaitable(response) else _value(response), FETCH_TIMEOUT_SECONDS
        )
    except TimeoutError:
        return {"status": "UNAVAILABLE", "reason": "provider_timeout", "summaries": {}}
    except Exception as exc:
        return {
            "status": "UNAVAILABLE",
            "reason": f"provider_error:{type(exc).__name__}",
            "summaries": {},
        }
    if not isinstance(payload, Mapping):
        return {"status": "UNAVAILABLE", "reason": "invalid_provider_response", "summaries": {}}
    # A fresh provider timestamp is naturally later than the request start. Use
    # receipt time in production; retain an injected clock for deterministic replays.
    current = _utc(now)
    rows, errors = payload.get("books"), payload.get("errors")
    books = (
        {str(x.get("symbol", "")).strip().upper(): x for x in rows if isinstance(x, Mapping)}
        if isinstance(rows, list)
        else {}
    )
    provider_errors = (
        {str(x.get("symbol", "")).strip().upper(): x for x in errors if isinstance(x, Mapping)}
        if isinstance(errors, list)
        else {}
    )
    summaries: dict[str, Any] = {}
    connection = _connect(Path(store_path))
    try:
        connection.execute(
            "DELETE FROM orderbook_snapshots WHERE updated_at < ?",
            ((current - RETENTION).timestamp(),),
        )
        for symbol in requested:
            if symbol in provider_errors:
                summaries[symbol] = {
                    "status": "PROVIDER_ERROR",
                    "symbol": symbol,
                    "reason": str(provider_errors[symbol].get("error", "unknown_provider_error")),
                }
                continue
            if (raw := books.get(symbol)) is None:
                summaries[symbol] = {"status": "MISSING_BOOK", "symbol": symbol}
                continue
            try:
                book = parse_level2_book(raw, now=current)
                if book.symbol != symbol:
                    raise OrderBookValidationError("book symbol does not match request")
                _save(connection, book, now=current)
                summaries[symbol] = _summary(connection, book, now=current)
            except OrderBookValidationError as exc:
                summaries[symbol] = {
                    "status": _error_status(str(exc)),
                    "symbol": symbol,
                    "reason": str(exc),
                }
        connection.commit()
    finally:
        connection.close()
    statuses = {x["status"] for x in summaries.values()}
    return {
        "status": "OK"
        if "OK" in statuses
        else "NO_DEPTH"
        if statuses == {"NO_DEPTH"}
        else "UNAVAILABLE",
        "summaries": summaries,
    }


async def _value(value: Mapping[str, Any]) -> Mapping[str, Any]:
    return value
