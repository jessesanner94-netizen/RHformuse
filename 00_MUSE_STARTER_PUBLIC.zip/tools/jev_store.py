"""Single-host, append-only JEV research evidence, separate from trading ledgers."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from collections.abc import Mapping
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

SCHEMA_VERSION = 1


def timestamp(value: datetime) -> str:
    if value.tzinfo is None:
        raise ValueError("timezone_required")
    return value.astimezone(UTC).isoformat()


def serialized(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


class JevStore:
    """SQLite transactions coordinate processes on this computer, not OneDrive hosts."""

    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self.connect() as db:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, SCHEMA_VERSION):
                raise ValueError("unsupported_jev_schema")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS observations (
                    observation_id TEXT PRIMARY KEY, as_of TEXT NOT NULL,
                    candidate_id TEXT NOT NULL, symbol TEXT NOT NULL,
                    features_json TEXT NOT NULL, evaluation_json TEXT NOT NULL,
                    python_pass INTEGER NOT NULL, shadow INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS observation_history
                    ON observations(candidate_id, as_of);
                CREATE TABLE IF NOT EXISTS events (
                    event_id INTEGER PRIMARY KEY, observation_id TEXT,
                    as_of TEXT NOT NULL, kind TEXT NOT NULL, payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS request_reservations (
                    reservation_id TEXT PRIMARY KEY, as_of TEXT NOT NULL,
                    trading_day TEXT NOT NULL, attempts INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS evaluation_claims (
                    evaluation_key TEXT PRIMARY KEY, claimed_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS outcomes (
                    observation_id TEXT NOT NULL, horizon_minutes INTEGER NOT NULL,
                    measured_at TEXT NOT NULL, payload_json TEXT NOT NULL,
                    PRIMARY KEY(observation_id, horizon_minutes)
                );
                PRAGMA user_version=1;
            """)

    def connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.path, timeout=3)
        db.row_factory = sqlite3.Row
        return db

    def claim(self, key: str, now: datetime) -> bool:
        # Never automatically retry the same evidence after an uncertain request.
        with self.connect() as db:
            return (
                db.execute(
                    "INSERT OR IGNORE INTO evaluation_claims VALUES (?, ?)", (key, timestamp(now))
                ).rowcount
                == 1
            )

    def reserve_requests(
        self, key: str, now: datetime, *, attempts: int, per_minute: int, per_day: int
    ) -> bool:
        if min(attempts, per_minute, per_day) < 1:
            return False
        day = now.astimezone(ZoneInfo("America/New_York")).date().isoformat()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            daily = db.execute(
                "SELECT COALESCE(SUM(attempts),0) FROM request_reservations WHERE trading_day=?",
                (day,),
            ).fetchone()[0]
            recent = db.execute(
                "SELECT COALESCE(SUM(attempts),0) FROM request_reservations WHERE as_of>?",
                (timestamp(now - timedelta(minutes=1)),),
            ).fetchone()[0]
            if daily + attempts > per_day or recent + attempts > per_minute:
                return False
            return (
                db.execute(
                    "INSERT OR IGNORE INTO request_reservations VALUES (?,?,?,?)",
                    (key, timestamp(now), day, attempts),
                ).rowcount
                == 1
            )

    def observe(
        self,
        *,
        features: Mapping[str, Any],
        evaluation: Mapping[str, Any],
        now: datetime,
        python_pass: bool,
        shadow: bool,
    ) -> str:
        candidate = features.get("candidate", {})
        body = serialized(features)
        identifier = hashlib.sha256(
            (timestamp(now) + body + serialized(evaluation)).encode()
        ).hexdigest()
        with self.connect() as db:
            db.execute(
                "INSERT OR IGNORE INTO observations VALUES (?,?,?,?,?,?,?,?)",
                (
                    identifier,
                    timestamp(now),
                    str(candidate.get("candidate_id", "")),
                    str(candidate.get("symbol", "")),
                    body,
                    serialized(evaluation),
                    int(python_pass),
                    int(shadow),
                ),
            )
        return identifier

    def event(self, observation_id: str | None, kind: str, payload: Any, now: datetime) -> None:
        with self.connect() as db:
            db.execute(
                "INSERT INTO events(observation_id,as_of,kind,payload_json) VALUES(?,?,?,?)",
                (observation_id, timestamp(now), kind, serialized(payload)),
            )

    def history(self, candidate_id: str, now: datetime, limit: int = 5) -> list[dict[str, Any]]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT as_of,evaluation_json FROM observations "
                "WHERE candidate_id=? AND as_of<=? ORDER BY as_of DESC LIMIT ?",
                (candidate_id, timestamp(now), min(max(limit, 1), 20)),
            ).fetchall()
        return [
            {"as_of": row["as_of"], **json.loads(row["evaluation_json"])} for row in reversed(rows)
        ]
