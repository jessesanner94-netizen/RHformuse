"""Dormant, offline options experiments using the production decision and paper engines.

No data client, model, scheduler, notification or order executor is called here.
Inputs are point-in-time observations, never previously realized trade outcomes.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import re
import shutil
from collections import Counter
from collections.abc import Mapping, Sequence
from datetime import UTC, date, datetime
from functools import partial
from pathlib import Path
from typing import Any

from tools.cheap_scan import evaluate_candidate
from tools.config import TradingConfig, load_config
from tools.decision_context import build_decision_packet
from tools.economic_calendar import economic_context
from tools.market_calendar import EASTERN, entry_allowed
from tools.option_style import annotate_option_styles
from tools.options_strategy import entry_locked, ledger_directory
from tools.paper_runner import apply_paper_decision
from tools.paper_trading import (
    _append_event,
    _atomic_text_write,
    _exclusive_lock,
    ensure_paper_portfolio,
    manage_paper_positions,
    paper_summary,
)
from tools.scheduled_cycle import _jev_rank, _route_compact_decision_impl

ROOT = Path(__file__).resolve().parents[1]
LAB = ROOT / "research" / "options_lab"
POLICIES = ("CONFIG.md", "AGENTS.md", "strategy/STRATEGY.md", "strategy/RISK.md",
            "strategy/COST_POLICY.md", "strategy/EXECUTION_RULES.md",
            "strategy/DATA_SOURCES.md", "strategy/EARNINGS_NEWS_SOCIAL.md")
SAFETY = {
    "LIVE_EXECUTION_ENABLED": False,
    "LIVE_NEW_ENTRIES_ENABLED": False,
    "LIVE_UNATTENDED_AUTHORIZED": False,
    "PAPER_TRADING_ENABLED": True,
    "PAPER_BASELINE_ENABLED": False,
    "PAPER_DAILY_GREEN_LOCK_ENABLED": False,
    "ECONOMIC_CALENDAR_OFFLINE": True,
}
OBSERVATION_TIMES = {"as_of", "updated_at", "quote_updated_at", "underlying_quote_updated_at",
                     "fetched_at", "timestamp", "venue_last_trade_time", "completed_at",
                     "observed_at", "received_at", "published_at", "bar_close_at"}
OUTCOME_FIELDS = {"outcome", "outcomes", "outcome_timestamp", "realized_pnl", "exit_price",
                  "exit_at", "exit_time", "forward_return", "future_return"}


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _read(path: Path) -> Any:
    def invalid(value):
        raise ValueError(f"non-finite JSON value: {value}")
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=invalid)


def _write(path: Path, value: Any) -> None:
    _atomic_text_write(path, json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def _name(value: str) -> str:
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,79}", value):
        raise ValueError("names must use lowercase letters, numbers, underscores or hyphens")
    return value


def _time(value: Any) -> datetime:
    if not isinstance(value, str):
        raise ValueError("observation needs an ISO timestamp with a timezone")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("naive observation timestamp")
    return parsed.astimezone(UTC)


def _fresh(value: Any, now: datetime, seconds: int) -> bool:
    try:
        return 0 <= (now - _time(value)).total_seconds() <= seconds
    except (TypeError, ValueError):
        return False


def _config_text(values: Mapping[str, Any]) -> str:
    def scalar(value):
        if isinstance(value, bool):
            return str(value).lower()
        if value is None:
            return "TODO"
        return str(value)
    return "# Frozen research configuration; never use for live execution.\n" + "".join(
        f"{key}: {scalar(value)}\n" for key, value in sorted(values.items())
    )


def _validate_config(config: TradingConfig) -> None:
    if any(config.get(key) != value for key, value in SAFETY.items()):
        raise ValueError("experiment execution safety settings changed")
    if config.get("OPTIONS_LUNA_VETO_ENABLED") is not False:
        raise ValueError("lab supports the current deterministic no-Luna options route only")
    if config.get("WATCHLIST_ONLY") is not True or config.get("DAY_ONLY_OPTIONS") is not True:
        raise ValueError("lab requires the current fixed-watchlist DAY options strategy")
    blockers = config.paper_blockers() + config.options_blockers()
    if blockers:
        raise ValueError(f"unresolved experiment configuration: {sorted(set(blockers))}")
    config.watchlist_symbols()


def init_experiment(
    name: str, *, project_root: Path = ROOT, lab_root: Path = LAB,
    overrides: Mapping[str, Any] | None = None,
) -> Path:
    """Freeze the baseline without starting a process or initializing a trading ledger."""
    destination = lab_root.resolve() / "experiments" / _name(name)
    source = load_config(project_root / "CONFIG.md")
    changes = dict(overrides or {})
    if any(key in SAFETY and value != SAFETY[key] for key, value in changes.items()):
        raise ValueError("research overrides cannot enable execution or network calendar refresh")
    unknown = set(changes) - set(source.values) - set(SAFETY)
    if unknown:
        raise ValueError(f"unknown research override settings: {sorted(unknown)}")
    values = {**source.values, **changes, **SAFETY}
    _validate_config(TradingConfig(values))
    destination.mkdir(parents=True, exist_ok=False)
    (destination / "CONFIG.md").write_text(_config_text(values), encoding="utf-8")
    for relative in POLICIES:
        target = destination / "policy" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(project_root / relative, target)
    code = {str(p.relative_to(ROOT)): _hash(p) for p in sorted((ROOT / "tools").glob("*.py"))}
    for relative in (*code, "pyproject.toml", "uv.lock"):
        target = destination / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    manifest = {
        "schema_version": 1, "name": name, "status": "DORMANT", "mode": "OFFLINE_PAPER_ONLY",
        "created_at": datetime.now(UTC).isoformat(), "strategy_epoch":
        source.get("OPTIONS_STRATEGY_EPOCH"), "config_sha256": _hash(destination / "CONFIG.md"),
        "source_config_sha256": _hash(project_root / "CONFIG.md"), "code_sha256": code,
        "dependency_sha256": {p: _hash(ROOT / p) for p in ("pyproject.toml", "uv.lock")},
        "policy_sha256": {p: _hash(destination / "policy" / p) for p in POLICIES},
        "research_overrides": changes, "execution_overrides": SAFETY,
        "strategy_setting_changes": {k: {"source": source.get(k), "experiment": v}
                                     for k, v in values.items()
                                     if k not in SAFETY and v != source.get(k)},
    }
    _write(destination / "MANIFEST.json", manifest)
    return destination


def load_experiment(experiment: Path) -> tuple[TradingConfig, dict[str, Any]]:
    manifest = _read(experiment / "MANIFEST.json")
    if _hash(experiment / "CONFIG.md") != manifest["config_sha256"]:
        raise ValueError("frozen experiment config changed; initialize a new experiment")
    for relative, expected in manifest["policy_sha256"].items():
        if _hash(experiment / "policy" / relative) != expected:
            raise ValueError(f"frozen policy evidence changed: {relative}")
    for relative, expected in {
        **manifest["code_sha256"], **manifest["dependency_sha256"]
    }.items():
        if _hash(experiment / "source" / relative) != expected:
            raise ValueError(f"archived source evidence changed: {relative}")
        if _hash(ROOT / relative) != expected:
            raise ValueError(f"source code changed: {relative}; initialize a new experiment")
    config = load_config(experiment / "CONFIG.md")
    _validate_config(config)
    return config, manifest


def _validate_observation(value: Any, now: datetime) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if key in OUTCOME_FIELDS or key.startswith(("forward_", "future_")):
                raise ValueError(f"outcome labels are prohibited in observations: {key}")
            if key in OBSERVATION_TIMES and item is not None and _time(item) > now:
                raise ValueError(f"future observation: {key}")
            _validate_observation(item, now)
    elif isinstance(value, list):
        for item in value:
            _validate_observation(item, now)


def read_frames(path: Path, *, content: str | None = None) -> list[dict[str, Any]]:
    """Validate the complete tape before creating a run or changing a paper ledger."""
    frames = []
    previous = None
    source = content if content is not None else path.read_text(encoding="utf-8")
    for line in source.splitlines():
        if not line.strip():
            continue
        # Re-serialization below also rejects non-finite numbers nested in evidence.
        frame = json.loads(line)
        json.dumps(frame, allow_nan=False)
        if not isinstance(frame, dict) or frame.get("schema_version") != 1:
            raise ValueError("each input line must be a schema_version 1 observation")
        now = _time(frame.get("as_of"))
        if previous is not None and now <= previous:
            raise ValueError("observations must be strictly chronological; no duplicates")
        if frame.get("kind") not in {"opportunity", "monitor"}:
            raise ValueError("observation kind must be opportunity or monitor")
        if not isinstance(frame.get("source"), str) or not frame["source"].strip():
            raise ValueError("observation source is required")
        for field in ("quotes", "technical", "jev", "economic_calendar", "uw",
                      "market_intelligence", "orderbooks"):
            if field in frame and not isinstance(frame[field], dict):
                raise ValueError(f"{field} must be an object")
        if not isinstance(frame.get("candidates", []), list) or any(
            not isinstance(candidate, dict) for candidate in frame.get("candidates", [])
        ):
            raise ValueError("candidates must be an array of objects")
        _validate_observation(frame, now)
        frames.append(frame)
        previous = now
    if not frames:
        raise ValueError("empty observation tape")
    return frames


async def _step(frame: dict[str, Any], config: TradingConfig, run: Path) -> dict[str, Any]:
    now = _time(frame["as_of"])
    directory = ledger_directory(run, config, "paper")
    paths = {"portfolio_path": directory / "PORTFOLIO.json",
             "event_log_path": directory / "EVENTS.jsonl"}
    state = ensure_paper_portfolio(config, **paths, now=now)
    previous_at = _time(state["updated_at"])
    had_position = bool(state["open_positions"])
    refresh = frame.get("quotes") or {"option_quotes": []}
    # The shared engine handles missing/stale/crossed quotes and never invents exits.
    monitor = manage_paper_positions(refresh, config, **paths, now=now)
    issues = [item["code"] for item in monitor.get("attention", [])]
    if had_position and (now - previous_at).total_seconds() > float(
        config.get("PAPER_OPEN_POSITION_POLL_SECONDS", 10)
    ) * 1.5:
        issues.append("monitoring_gap")
    result = {"as_of": frame["as_of"], "kind": frame["kind"], "source": frame["source"],
              "monitor": monitor, "data_issues": issues, "orders_placed": 0, "model_calls": 0}
    if frame["kind"] == "monitor":
        return result
    if monitor.get("attention") or entry_locked(monitor["portfolio"]):
        result["skip_reason"] = "position_data_unavailable" if monitor.get("attention") else (
            "daily_green_lock_active"
        )
        return result
    calendar = run / "state" / "economic_calendar.json"
    if isinstance(frame.get("economic_calendar"), dict):
        _write(calendar, frame["economic_calendar"])
    else:
        calendar.unlink(missing_ok=True)
    macro = economic_context(now, config, project_root=run)
    if macro["status"] not in {"OK", "DISABLED"}:
        issues.append("economic_calendar_unavailable")
    if not entry_allowed(now, config, "DAY"):
        result["skip_reason"] = "session_or_economic_calendar_gate"
        return result
    candidates, rejected = [], []
    for original in frame.get("candidates", []):
        candidate = dict(original)
        symbol = str(candidate.get("symbol", "")).upper()
        if symbol not in config.watchlist_symbols():
            rejected.append({"candidate_id": candidate.get("candidate_id"),
                             "reasons": ["outside_experiment_universe"]})
            continue
        candidate["quote_is_fresh"] = _fresh(candidate.get("quote_updated_at"), now, 180)
        if not _fresh(candidate.get("underlying_quote_updated_at"), now, 240):
            candidate["quote_is_fresh"] = False
        try:
            candidate["dte"] = (date.fromisoformat(candidate["expiration"])
                                - now.astimezone(EASTERN).date()).days
        except (KeyError, TypeError, ValueError):
            candidate["dte"] = None
        candidate = annotate_option_styles(candidate, config)
        candidate["entry_eligible_trade_styles"] = [
            style for style in candidate["eligible_trade_styles"]
            if entry_allowed(now, config, style)
        ]
        gate = evaluate_candidate(candidate, config)
        if gate.status == "QUALIFIED":
            candidates.append(candidate)
        else:
            rejected.append(gate.as_dict())
            if gate.status == "INSUFFICIENT_DATA":
                issues.append("candidate_data_unavailable")
    result["scanner_rejections"] = rejected

    def technical(symbol, **kwargs):
        evidence = frame.get("technical", {}).get(symbol, {})
        if evidence.get("status") != "OK" or not _fresh(evidence.get("as_of"), now, 600):
            issues.append("technical_evidence_missing_or_stale")
            return {"status": "UNAVAILABLE"}
        return evidence

    def jev(packet, *args, **kwargs):
        identifier = packet["candidate"]["candidate_id"]
        evidence = frame.get("jev", {}).get(identifier, {})
        if _jev_rank(evidence) is None or not _fresh(evidence.get("as_of"), now, 240):
            issues.append("jev_evidence_missing_or_stale")
            return {"status": "UNAVAILABLE"}
        return evidence

    builder = partial(build_decision_packet, technical_fetcher=technical,
                      uw_fetcher=lambda symbol, kind: frame.get("uw", {}).get(
                          f"{symbol}:{kind}", {"status": "UNAVAILABLE"}))
    event = {"option_discovery": {"qualified_candidates": candidates},
             "paper_portfolio": monitor,
             "market_intelligence": frame.get("market_intelligence", {}),
             "orderbooks": frame.get("orderbooks", {"summaries": {}})}
    routing = await _route_compact_decision_impl(
        event, config=config, project_root=run, execute_models=True, now=now,
        packet_builder=builder, jev_evaluator=jev,
    )
    routing.pop("_jev_pending", None)

    async def recorded_quotes(requests):
        return refresh

    result["routing"] = routing
    result["entry"] = await apply_paper_decision(
        routing, event, config, project_root=run, now=now, quote_fetcher=recorded_quotes,
    )
    if any("missing" in reason or "stale" in reason or "invalid" in reason
           for reason in result["entry"].get("reasons", [])):
        issues.append("final_entry_data_unavailable")
    return result


def report(run: Path) -> dict[str, Any]:
    config = load_config(run / "CONFIG.md")
    state = _read(ledger_directory(run, config, "paper") / "PORTFOLIO.json")
    metadata = _read(run / "RUN.json")
    rows = [json.loads(line) for line in (run / "CYCLES.jsonl").read_text().splitlines()]
    issues = Counter(issue for row in rows for issue in row.get("data_issues", []))
    losses, wins = float(state.get("gross_losses", 0)), float(state.get("gross_wins", 0))
    count = int(state["closed_trade_count"])
    result = {"schema_version": 1, "experiment": metadata["experiment"], "mode": metadata["mode"],
              "input_sha256": metadata["input_sha256"], "config_sha256": metadata["config_sha256"],
              "last_as_of": rows[-1]["as_of"], "observations": len(rows),
              "input_sources": sorted({row["source"] for row in rows}),
              "performance": paper_summary(state), "win_rate":
              state.get("winning_trades", 0) / count if count else None,
              "profit_factor": wins / abs(losses) if losses else None,
              "data_issues": dict(issues), "skip_reasons": dict(Counter(
                  row["skip_reason"] for row in rows if row.get("skip_reason"))),
              "status": "INCOMPLETE_DATA" if issues or state["open_positions"] else "COMPLETED",
              "scope": "conditional_on_supplied_candidate_snapshots_and_recorded_jev",
              "economic_profit": None, "incremental_ai_data_cost": None,
              "limitations": ["Not a full-market or historical-policy backtest.",
                              "Only observed quotes produce fills; gaps are not interpolated.",
                              "Open positions keep their last available bid; no forced close.",
                              "Paper costs are assumptions; AI/data dollar costs are unknown."]}
    _write(run / "METRICS.json", result)
    summary = result["performance"]
    _atomic_text_write(run / "REPORT.md", (
        f"# Options experiment: {metadata['experiment']}\n\n"
        f"Status: {result['status']}. Mode: {metadata['mode']}. Observations: {len(rows)}.\n\n"
        f"Input sources: {', '.join(result['input_sources'])}.\n\n"
        f"Starting cash ${summary['starting_cash']:.2f}; equity ${summary['equity']:.2f}; "
        f"realized P&L ${summary['realized_pnl']:.2f}; closed trades {count}; "
        f"open positions {summary['open_positions']}.\n\n"
        f"Data issues: {dict(issues)}.\n\n" + "\n".join(result["limitations"]) + "\n"
    ))
    return result


async def run_tape(experiment: Path, tape: Path, name: str, *, mode: str = "replay") -> dict:
    if mode not in {"replay", "paper"}:
        raise ValueError("invalid experiment mode")
    _, manifest = load_experiment(experiment)
    raw_input = tape.read_bytes()
    frames = read_frames(tape, content=raw_input.decode("utf-8"))
    run = experiment / "runs" / _name(name)
    # One lock covers chronology, config, accounting and reporting across the batch.
    with _exclusive_lock(experiment / "runs" / f"{name}.lock"):
        if run.exists():
            if mode != "paper":
                raise ValueError("replay run already exists; choose a new run name")
            metadata = _read(run / "RUN.json")
            if metadata["mode"] != mode or metadata["config_sha256"] != manifest["config_sha256"]:
                raise ValueError("run identity mismatch")
            if _hash(run / "CONFIG.md") != manifest["config_sha256"]:
                raise ValueError("run configuration changed")
            if metadata.get("status") != "COMPLETE":
                raise ValueError("interrupted run requires inspection; automatic retry prohibited")
            if _time(frames[0]["as_of"]) <= _time(metadata["last_as_of"]):
                raise ValueError("paper observations already processed or out of order")
        else:
            run.mkdir(parents=True, exist_ok=False)
            shutil.copy2(experiment / "CONFIG.md", run / "CONFIG.md")
            metadata = {"schema_version": 1, "experiment": manifest["name"], "mode": mode,
                        "config_sha256": manifest["config_sha256"], "input_sha256": [],
                        "code_sha256": manifest["code_sha256"]}
        metadata["status"] = "PROCESSING"
        metadata["input_sha256"].append(hashlib.sha256(raw_input).hexdigest())
        _write(run / "RUN.json", metadata)
        config = load_config(run / "CONFIG.md")
        _validate_config(config)
        archive = run / "inputs" / f"{len(metadata['input_sha256']):06d}.jsonl"
        archive.parent.mkdir(parents=True, exist_ok=True)
        archive.write_bytes(raw_input)
        for frame in frames:
            result = await _step(frame, config, run)
            _append_event(run / "CYCLES.jsonl", result)
        metadata.update(status="COMPLETE", last_as_of=frames[-1]["as_of"])
        _write(run / "RUN.json", metadata)
        return report(run)


def compare(runs: Sequence[Path]) -> dict[str, Any]:
    reports = [_read(run / "METRICS.json") for run in runs]
    identical = all(r["input_sha256"] == reports[0]["input_sha256"] for r in reports)
    return {"same_observation_tapes": identical, "results": [
        {"experiment": r["experiment"], "status": r["status"], **r["performance"],
         "data_issues": r["data_issues"]} for r in reports
    ], "interpretation": "Descriptive paper comparison; no statistical edge established."}


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    initialize = commands.add_parser("init")
    initialize.add_argument("name")
    initialize.add_argument("--overrides", type=Path, help="Research-only JSON settings")
    for mode in ("replay", "paper"):
        command = commands.add_parser(mode, help="Process recorded observations; no network")
        command.add_argument("--experiment", type=Path, required=True)
        command.add_argument("--input", type=Path, required=True)
        command.add_argument("--run", required=True)
    inspect = commands.add_parser("status")
    inspect.add_argument("--experiment", type=Path, required=True)
    comparison = commands.add_parser("compare")
    comparison.add_argument("runs", type=Path, nargs="+")
    args = parser.parse_args(argv)
    try:
        if args.command == "init":
            path = init_experiment(args.name, overrides=_read(args.overrides)
                                   if args.overrides else None)
            result = {"status": "DORMANT", "experiment": str(path)}
        elif args.command in {"replay", "paper"}:
            result = asyncio.run(run_tape(args.experiment.resolve(), args.input.resolve(), args.run,
                                         mode=args.command))
        elif args.command == "compare":
            result = compare(args.runs)
        else:
            _, result = load_experiment(args.experiment.resolve())
            result = {key: result[key] for key in ("name", "status", "mode", "strategy_epoch",
                                                  "research_overrides", "strategy_setting_changes")}
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "BLOCKED", "reason": str(exc)}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
