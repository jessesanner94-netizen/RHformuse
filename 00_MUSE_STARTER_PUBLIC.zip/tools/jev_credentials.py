"""Optional Windows-user-bound credential storage, never stored in source or telemetry."""

from __future__ import annotations

import os
from pathlib import Path


def credential_path(project_root: Path) -> Path:
    return project_root / "state" / "runtime" / "jev_api_key.dpapi"


def save_key(project_root: Path, key: str) -> None:
    import win32crypt

    if not key.strip() or len(key) > 4096:
        raise ValueError("invalid_api_key")
    path = credential_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    protected = win32crypt.CryptProtectData(
        key.strip().encode(), "JEV API credential", None, None, None, 0
    )
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(protected)
    os.replace(temporary, path)


def load_key(project_root: Path) -> str | None:
    key = os.environ.get("TYPESAFE_API_KEY") or os.environ.get("JEV_API_KEY")
    if key:
        return key
    path = credential_path(project_root)
    if not path.exists():
        return None
    import win32crypt

    _, plaintext = win32crypt.CryptUnprotectData(path.read_bytes(), None, None, None, 0)
    return plaintext.decode()
