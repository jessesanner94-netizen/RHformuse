"""Forward integration: one account, additive evidence and protected exits."""

import asyncio
import copy
import json
from datetime import UTC, date, datetime, timedelta

import pytest

from research.options_lab import forward
from research.options_lab.event_tape import SessionTape
from tools.option_style import annotate_option_styles
from tools.options_lab import _step, init_experiment

NOW = datetime(2026, 10, 22, 14, tzinfo=UTC)


def observation(now=NOW, bid=1.08, ask=1.1):
    stamp = now.isoformat()
    candidate = {
        "candidate_id": "synthetic-spy",
        "symbol": "SPY",
        "option_type": "CALL",
        "strike": 500,
        "expiration": "2026-11-06",
        "dte": 15,
        "underlying_price": 500,
        "bid": bid,
        "ask": ask,
        "quote_updated_at": stamp,
        "underlying_quote_updated_at": stamp,
        "option_volume": 1000,
        "option_open_interest": 5000,
        "underlying_avg_daily_dollar_volume": 1e10,
        "setup_qualified": True,
        "implied_volatility": 0.25,
        "delta": 0.5,
        "gamma": 0.002,
        "theta": -0.02,
        "vega": 0.1,
        "rho": 0.02,
        "event_review_complete": True,
        "contract_review_complete": True,
    }
    return {
        "schema_version": 1,
        "as_of": stamp,
        "kind": "opportunity",
        "source": "SYNTHETIC",
        "candidates": [candidate],
        "quotes": {
            "status": "OK",
            "as_of": stamp,
            "option_quotes": [
                {
                    "instrument_id": "synthetic-spy",
                    "bid_price": str(bid),
                    "ask_price": str(ask),
                    "updated_at": stamp,
                    "volume": 1000,
                    "open_interest": 5000,
                    **{
                        k: candidate[k]
                        for k in ("delta", "gamma", "theta", "vega", "rho", "implied_volatility")
                    },
                }
            ],
        },
        "technical": {
            "SPY": {
                "status": "OK",
                "as_of": stamp,
                "instrument_type": "ETF",
                "style_scores": {"DAY": 7, "SWING": 17},
                "timeframes": {
                    "5M": {"status": "OK", "trend": "BULLISH", "trend_score": 3},
                    "15M": {"status": "OK", "trend": "BULLISH", "trend_score": 3},
                },
                "earnings": {"status": "NOT_APPLICABLE", "next_date": None},
            }
        },
        "jev": {
            "synthetic-spy": {
                "status": "OK",
                "as_of": stamp,
                "scores": {
                    "setup_quality": 0.7,
                    "entry_timing_quality": 0.7,
                    "escalate_to_luna": 0.7,
                },
            }
        },
        "economic_calendar": {
            "status": "OK",
            "period": "2026-10",
            "fetched_at": stamp,
            "events": [],
            "errors": [],
            "coverage": "SYNTHETIC",
        },
    }


@pytest.fixture
def bot(tmp_path, monkeypatch):
    lab = tmp_path / "lab"
    monkeypatch.setattr(forward, "LAB", lab)
    monkeypatch.setattr(
        forward, "init_experiment", lambda name: init_experiment(name, lab_root=lab)
    )
    experiment = forward.prepare("forward_test", date(2026, 10, 22))
    result = forward.ForwardExperiment(experiment, clock=lambda: NOW)
    return result


def seed(bot, arm):
    result = asyncio.run(_step(observation(), bot.configs[arm], bot.roots[arm]))
    assert result["entry"]["opened"] is True


def row(kind, at, payload, source="yahoo", venue="CONSOLIDATED_UNVERIFIED", identity="test"):
    return {
        "schema_version": 1,
        "kind": kind,
        "symbol": "SPY",
        "source": source,
        "venue": venue,
        "event_id": identity,
        "event_at": at.isoformat(),
        "received_at": at.isoformat(),
        "available_at": at.isoformat(),
        "payload": payload,
    }


def news_and_bar(volume=10000):
    event = NOW - timedelta(seconds=120)
    news = row(
        "news",
        event,
        {
            "event_key": "test-event",
            "title": "Synthetic primary event",
            "url": "https://test.gov/a",
            "verified": True,
            "material": True,
            "novel": True,
            "direction": "UNKNOWN",
            "classification_method": "TEST",
            "verification_basis": "primary_publication_provenance",
            "relevant_symbols": ["SPY"],
        },
        source="federal_reserve",
        venue="UNSPECIFIED",
    )
    bar = row(
        "bar",
        NOW,
        {
            "start_at": (NOW - timedelta(seconds=60)).isoformat(),
            "end_at": NOW.isoformat(),
            "open": 500,
            "high": 500.1,
            "low": 499,
            "close": 499,
            "volume": volume,
        },
    )
    return [news, bar]


def test_single_account_and_core_strategy_unchanged(bot):
    assert bot.guards() == []
    states = [bot.state(arm, NOW) for arm in forward.ACCOUNTS]
    assert all(s["starting_cash"] == 369 and not s["open_positions"] for s in states)
    assert len({str(bot.paths(arm)["portfolio_path"]) for arm in forward.ACCOUNTS}) == 1
    assert all(
        not c.live_execution_enabled and c.get("PAPER_TRADING_ENABLED")
        for c in bot.configs.values()
    )
    source = forward.load_config(forward.ROOT / "CONFIG.md")
    for key, value in source.values.items():
        if key not in forward.load_experiment(bot.experiment)[1]["execution_overrides"]:
            assert bot.config.get(key) == value


def test_missing_required_additions_block_single_paper_account(bot):
    assert bot.review("paper", "SPY", "CALL", NOW)["status"] == "UNAVAILABLE"


def test_known_bad_news_confirmed_exit_requires_fresh_quote(bot):
    seed(bot, "paper")
    bot.tape.ingest(news_and_bar())
    bot.health["news"] = {"status": "OK", "as_of": NOW.isoformat()}

    async def quotes(requests):
        direct = observation()["quotes"]
        direct["option_quotes"] = [{"quote": q} for q in direct["option_quotes"]]
        return direct

    bot.fast_quotes = quotes
    results = asyncio.run(bot.monitor())
    assert results["paper"]["news_reviews"][0]["exit"]["closed"] is True
    assert bot.state("paper", NOW)["closed_trade_count"] == 1
    assert bot.opportunity_wake.is_set()
    assert not results["paper"]["news_reviews"][0]["review"]["news"]["reversal_authorized"]


def test_missing_volume_is_unavailable_and_never_early_exits(bot):
    result = forward.review_news(
        news_and_bar(None),
        "SPY",
        "CALL",
        NOW,
        forward.POLICY,
        {"status": "OK", "as_of": NOW.isoformat()},
    )
    assert result["action"] == "PAUSE_PRIMARY_NEWS_AWAITING_REACTION"


def test_retracted_primary_news_cannot_exit_on_older_version():
    rows = news_and_bar()
    correction = copy.deepcopy(rows[0])
    correction["event_id"] = "correction"
    correction["available_at"] = NOW.isoformat()
    correction["payload"].update(material=False, supersedes_event_id=rows[0]["event_id"])
    result = forward.review_news(
        [*rows, correction],
        "SPY",
        "CALL",
        NOW,
        forward.POLICY,
        {"status": "OK", "as_of": NOW.isoformat()},
    )
    assert result["status"] == "ALLOW"
    assert result["action"] == "NO_EVENT_ACTION"


def test_research_failure_cannot_interrupt_original_stop_exits(bot, monkeypatch):
    for arm in forward.ACCOUNTS:
        seed(bot, arm)

    async def quotes(requests):
        return observation(bid=0.7, ask=0.72)["quotes"]

    bot.fast_quotes = quotes
    monkeypatch.setattr(bot, "review", lambda *args: (_ for _ in ()).throw(ValueError("bad feed")))
    results = asyncio.run(bot.monitor())
    assert all(bot.state(arm, NOW)["closed_trade_count"] == 1 for arm in forward.ACCOUNTS)
    assert all(not r["monitor"]["attention"] for r in results.values())


def test_stale_news_exit_quote_does_not_create_fill(bot):
    seed(bot, "paper")
    bot.tape.ingest(news_and_bar())
    bot.health["news"] = {"status": "OK", "as_of": NOW.isoformat()}

    async def quotes(requests):
        return observation(NOW - timedelta(seconds=21))["quotes"]

    bot.fast_quotes = quotes
    result = asyncio.run(bot.monitor())
    assert not result["paper"]["news_reviews"][0]["exit"]["closed"]
    assert bot.state("paper", NOW)["closed_trade_count"] == 0


def test_history_dedup_preserves_earliest_entry():
    requests = forward.ForwardExperiment.requests(
        [
            {"open_positions": [{"contract_identifier": "same", "symbol": "SPY", "entry_at": at}]}
            for at in ("2026-10-22T14:00:00+00:00", "2026-10-22T14:05:00+00:00")
        ]
    )
    assert len(requests) == 1
    assert requests[0]["tp_history_start"] == "2026-10-22T14:00:00+00:00"


def test_guard_detects_changed_frozen_config_but_monitor_still_runs(bot):
    seed(bot, "paper")
    with (bot.roots["paper"] / "CONFIG.md").open("a") as handle:
        handle.write("\n# changed on disk\n")
    assert bot.guards()

    async def quotes(requests):
        return observation(bid=0.7, ask=0.72)["quotes"]

    bot.fast_quotes = quotes
    asyncio.run(bot.monitor())
    assert bot.state("paper", NOW)["closed_trade_count"] == 1


@pytest.mark.parametrize("additions_available", [False, True])
@pytest.mark.parametrize("book_condition", ["missing", "wall", "read_failure"])
def test_forward_opportunity_shared_research_and_account_budget(
    bot, monkeypatch, additions_available, book_condition
):
    frame = observation()
    captured = {}
    original_route = forward._route_compact_decision_impl
    original_apply = forward.apply_paper_decision

    async def route(*args, **kwargs):
        return await original_route(*args, **kwargs, now=NOW)

    async def apply(*args, **kwargs):
        return await original_apply(*args, **kwargs, now=NOW)

    async def discovery(config, **kwargs):
        captured["premium_ceiling"] = kwargs["premium_ceiling"]
        return {
            "status": "QUALIFIED_CHANGED",
            "wake_luna": True,
            "qualified_candidates": [
                annotate_option_styles(copy.deepcopy(c), config) for c in frame["candidates"]
            ],
        }

    def technical(symbol, **kwargs):
        captured["technical_calls"] = captured.get("technical_calls", 0) + 1
        return frame["technical"][symbol]

    def jev(packet, config, **kwargs):
        captured["jev_calls"] = captured.get("jev_calls", 0) + 1
        return frame["jev"]["synthetic-spy"]

    async def books(*args, **kwargs):
        return {"status": "DISABLED", "summaries": {}}

    async def quotes(requests):
        return frame["quotes"]

    monkeypatch.setattr(forward, "load_calendar", lambda *args: frame["economic_calendar"])
    monkeypatch.setattr(forward, "_route_compact_decision_impl", route)
    monkeypatch.setattr(forward, "apply_paper_decision", apply)
    monkeypatch.setattr(forward, "run_watchlist_option_discovery", discovery)
    monkeypatch.setattr(forward, "fetch_vibe_snapshot", technical)
    monkeypatch.setattr(forward, "evaluate_candidate", jev)
    monkeypatch.setattr(
        forward,
        "divergence_review",
        lambda *args: {
            "status": "OK",
            "latest_confirmed_divergences": [{"kind": "regular_bullish"}],
        },
    )
    monkeypatch.setattr(forward, "collect_market_intelligence", lambda *args, **kw: {})
    monkeypatch.setattr("tools.orderbook.collect_orderbooks", books)
    if additions_available:
        # Exercise the real final research gate with complete bar/news evidence.
        for offset in range(-6, 0):
            start = NOW + timedelta(minutes=offset)
            end = start + timedelta(minutes=1)
            bot.tape.ingest(
                [
                    row(
                        "bar",
                        end,
                        {
                            "start_at": start.isoformat(),
                            "end_at": end.isoformat(),
                            "open": 500,
                            "high": 500.1,
                            "low": 499.9,
                            "close": 500,
                            "volume": 1000,
                        },
                        identity="bar:" + end.isoformat(),
                    )
                ]
            )
        bot.health["news"] = {"status": "OK", "as_of": NOW.isoformat()}
    if book_condition == "wall":
        from tests.test_book_ranking import snapshots

        bot.tape.ingest(snapshots(0, wall="CALL", now=NOW))
    if book_condition == "read_failure":
        original_observations = bot.tape.observations

        def observations(symbol, **kwargs):
            if kwargs.get("kinds") == ["book", "gap"]:
                raise OSError("Unavailable depth history")
            return original_observations(symbol, **kwargs)

        monkeypatch.setattr(bot.tape, "observations", observations)
    bot.quotes = quotes
    result = asyncio.run(bot.opportunities())
    assert result["status"] == "OK"
    assert captured["premium_ceiling"] == pytest.approx(171.6)
    assert captured["technical_calls"] == captured["jev_calls"] == 1
    assert bool(bot.state("paper", NOW)["open_positions"]) is additions_available
    event = json.loads((bot.directory / "OPPORTUNITIES.jsonl").read_text().splitlines()[0])
    assert event["orders_placed"] == event["codex_calls"] == 0
    assert event["rsi_candidate_priority"] == {"synthetic-spy": 1}
    assert event["results"]["paper"]["routing"]["jev_ranking"]["candidate_priority"] == {
        "synthetic-spy": 3 if book_condition == "wall" else 4
    }
    ranked = event["results"]["paper"]["entry_ranking"]["candidates"]["synthetic-spy"]
    assert ranked["book_score"] == (-1 if book_condition == "wall" else 0)
    assert ranked["rank"] == 1 and ranked["selected"] and ranked["priority_applied"]
    if additions_available:
        review = event["results"]["paper"]["addition_reviews"][0]
        assert review["status"] == "ALLOW"
        assert review["zones"]["evidence"]["liquidity"]["status"] == "DISABLED"
    if additions_available:
        assert event["results"]["paper"]["entry_quality"][0]["changes_entry_decision"] is False


def test_bounded_tape_reads_keep_gap_history(tmp_path):
    tape = SessionTape(tmp_path / "tape.db")
    rows = news_and_bar()
    tape.ingest(rows)
    result = tape.observations("SPY", as_of=NOW, since=NOW - timedelta(seconds=60))
    assert len(result) == 1 and result[0]["kind"] == "bar"


def test_single_account_carry_preserves_loss_history_and_risk(bot):
    seed(bot, "paper")

    async def quotes(requests):
        return observation(bid=0.7, ask=0.72)["quotes"]

    bot.fast_quotes = quotes
    asyncio.run(bot.monitor())
    source = bot.state("paper", NOW)
    assert source["realized_pnl"] < 0
    destination = forward.prepare("carried", NOW.date(), carry_from=bot.roots["paper"])
    carried = forward.ForwardExperiment(destination, clock=lambda: NOW)
    assert carried.state("paper", NOW)["cash"] == source["cash"]
    assert carried.state("paper", NOW)["day"] == source["day"]
    assert carried.state("paper", NOW)["closed_trade_count"] == 1
    assert carried.metadata["history_carry_forward"]["cash_or_history_reset"] is False
    assert carried.guards() == []


def test_status_presents_exactly_one_paper_account(bot):
    status = bot.report()
    assert "accounts" not in status
    assert status["account"]["cash"] == 369
    assert bot.metadata["accounts"] == ["paper"]
    assert len(bot.roots) == 1


def test_user_reset_starts_new_account_and_preserves_archived_loss(bot):
    seed(bot, "paper")

    async def quotes(requests):
        return observation(bid=0.7, ask=0.72)["quotes"]

    bot.fast_quotes = quotes
    asyncio.run(bot.monitor())
    original_state = bot.paths("paper")["portfolio_path"].read_bytes()
    original_events = bot.paths("paper")["event_log_path"].read_bytes()
    destination = forward.prepare("reset", NOW.date(), reset_from=bot.roots["paper"])
    reset = forward.ForwardExperiment(destination, clock=lambda: NOW)
    state = reset.state("paper", NOW)
    assert state["cash"] == state["equity"] == 369
    assert state["realized_pnl"] == state["closed_trade_count"] == 0
    assert state["day"]["new_positions"] == 0
    assert state["day"]["green_lock_active"] is False
    assert bot.paths("paper")["portfolio_path"].read_bytes() == original_state
    assert bot.paths("paper")["event_log_path"].read_bytes() == original_events
    assert reset.metadata["paper_strategy_reset"]["cash_or_history_reset"] is True
    assert reset.metadata["features"]["rsi_divergence"] == "STRONG_PRIORITY_NOT_REQUIRED"


@pytest.mark.parametrize(
    "side,direction,bid,closed",
    [
        ("CALL", "UP", 1.35, True),
        ("CALL", "UP", 1.34, False),
        ("CALL", "DOWN", 0.9, True),
        ("PUT", "DOWN", 1.35, True),
        ("PUT", "UP", 0.9, True),
    ],
)
def test_forward_depth_exits_commit_at_bid_and_retain_original_locks(
    bot, monkeypatch, side, direction, bid, closed
):
    from tests.test_depth_exits import books

    seed(bot, "paper")
    active = bot.state("paper", NOW)["open_positions"][0]
    # Synthetic evidence relative to this fixture's clock, not historical outcomes.
    at = NOW + timedelta(minutes=2)
    bot.clock = lambda: at
    if side == "PUT":
        path = bot.paths("paper")["portfolio_path"]
        state = json.loads(path.read_text())
        state["open_positions"][0]["option_type"] = side
        path.write_text(json.dumps(state))
    monkeypatch.setattr("tests.test_depth_exits.NOW", at)
    bot.tape.ingest(books(direction))
    bot.health["news"] = {"status": "OK", "as_of": at.isoformat()}

    async def quotes(requests):
        return observation(at, bid=bid, ask=bid + 0.02)["quotes"]

    bot.fast_quotes = quotes
    result = asyncio.run(bot.monitor())["paper"]
    state = bot.state("paper", at)
    assert bool(state["closed_trade_count"]) is closed
    assert len(result["depth_exit_reviews"]) == 1
    if closed:
        trade = state["recent_closed_positions"][0]
        assert trade["exit_reason"] == "PAPER_DEPTH_SPIKE_" + (
            "TAKE_PROFIT" if bid > 1.1 else "DEFENSIVE_EXIT"
        )
        assert trade["exit_price"] == bid
        assert trade["realized_pnl"] == pytest.approx(round(bid * 100 - 110 - 2.10, 2))
        assert state["day"]["green_lock_active"] is (bid > 1.1)
        assert bot.opportunity_wake.is_set()
    else:
        assert state["open_positions"][0]["paper_id"] == active["paper_id"]


@pytest.mark.parametrize("bid,reason", [(0.7, "STOP_LOSS"), (1.5, "TAKE_PROFIT")])
def test_broken_optional_depth_evidence_cannot_block_original_exit(bot, monkeypatch, bid, reason):
    seed(bot, "paper")
    monkeypatch.setattr(
        bot,
        "depth_review",
        lambda *args: (_ for _ in ()).throw(
            AssertionError("Original stop must finish before optional depth")
        ),
    )

    async def quotes(requests):
        return observation(bid=bid, ask=bid + 0.02)["quotes"]

    bot.fast_quotes = quotes
    result = asyncio.run(bot.monitor())["paper"]
    assert result["depth_exit_reviews"] == []
    assert bot.state("paper", NOW)["recent_closed_positions"][0]["exit_reason"] == reason


def test_optional_depth_failure_does_not_block_news_exit(bot, monkeypatch):
    seed(bot, "paper")
    bot.tape.ingest(news_and_bar())
    bot.health["news"] = {"status": "OK", "as_of": NOW.isoformat()}
    monkeypatch.setattr(
        bot, "depth_review", lambda *args: (_ for _ in ()).throw(ValueError("bad depth"))
    )

    async def quotes(requests):
        return observation()["quotes"]

    bot.fast_quotes = quotes
    asyncio.run(bot.monitor())
    assert (
        bot.state("paper", NOW)["recent_closed_positions"][0]["exit_reason"]
        == "PAPER_NEWS_REACTION"
    )


def test_paper_ranking_overrides_are_frozen_and_core_policy_stays_fixed(bot):
    from tools.options_lab import _hash

    previous = _hash(forward.ROOT / "CONFIG.md")
    path = forward.prepare(
        "custom_ranking",
        NOW.date(),
        book_ranking_policy={"rsi_weight": 7, "direction_weight": 3, "opposing_wall_penalty": 2},
    )
    custom = forward.ForwardExperiment(path, clock=lambda: NOW)
    assert custom.guards() == []
    assert custom.policy["book_ranking"]["rsi_weight"] == 7
    assert _hash(forward.ROOT / "CONFIG.md") == previous
    metadata = json.loads((custom.directory / "EXPERIMENT.json").read_text())
    metadata["policy"]["book_ranking"]["rsi_weight"] = 8
    (custom.directory / "EXPERIMENT.json").write_text(json.dumps(metadata))
    assert "frozen paper metadata changed" in custom.guards()
