"""Research evaluator tests: chronology, clocks, outcomes and honest denominators."""

import copy
import json
from datetime import UTC, date, datetime, timedelta

import pytest

from research.regime_backtest import evaluate as bt

DAY = date(2022, 1, 3)
OPEN = datetime(2022, 1, 3, 14, 30, tzinfo=UTC)
CLOSE = OPEN + timedelta(minutes=390)


def minute_bars(*, chop=False, count=390):
    rows = []
    previous = 500.0
    for i in range(count):
        value = 500 + (0.1 if i % 2 else 0) if chop else 500 + (i + 1) * 0.1
        if chop and i == count - 1:
            value = 500
        rows.append(
            {
                "timestamp": (OPEN + timedelta(minutes=i)).isoformat(),
                "open": previous,
                "high": max(previous, value) + 0.01,
                "low": min(previous, value) - 0.01,
                "close": value,
                "volume": 1000,
            }
        )
        previous = value
    return rows


def mapping(rows):
    return {bt.stamp(row["timestamp"]): row for row in rows}


def protocol():
    return json.loads((bt.HERE / "PROTOCOL.json").read_text())


@pytest.mark.parametrize("chop,expected", [(False, "TREND"), (True, "CHOPPY")])
def test_independent_outcome_captures_monotonic_and_oscillating_paths(chop, expected):
    result = bt.outcome(minute_bars(chop=chop))
    assert result["label"] == expected


def test_outcome_includes_final_partial_block_and_actual_close():
    bars = minute_bars(count=359)
    initial = bt.outcome(bars)
    bars[-1].update(close=490, low=489)
    final = bt.outcome(bars)
    assert initial["direction"] == "UP" and final["direction"] == "DOWN"
    assert final["bars"] == 359
    assert bt.outcome(bars[:29])["label"] == "UNKNOWN"


def test_forecasts_do_not_see_later_minutes_or_session_outcomes():
    before = mapping(minute_bars())
    after = copy.deepcopy(before)
    cutoff = OPEN + timedelta(minutes=30, seconds=15)
    for at, bar in after.items():
        if at >= cutoff:
            bar.update(open=500, high=501, low=499, close=500)
    classifier = bt.historical_classifier()
    first = bt.predict(before, "SPY", cutoff, classifier)
    second = bt.predict(after, "SPY", cutoff, classifier)
    assert first == second
    assert bt.outcome(list(before.values())) != bt.outcome(list(after.values()))
    assert first["window_end"] == (OPEN + timedelta(minutes=30)).isoformat()


def test_initial_entry_window_is_unknown_and_availability_delay_is_real():
    rows = mapping(minute_bars())
    classifier = bt.historical_classifier()
    at = OPEN + timedelta(minutes=20, seconds=15)
    assert bt.predict(rows, "SPY", at, classifier)["structure"] == "UNKNOWN"
    at += timedelta(minutes=1)
    assert bt.predict(rows, "SPY", at, classifier)["structure"] == "TREND"
    assert bt.predict(rows, "SPY", at, classifier, delay=30)["structure"] == "UNKNOWN"


def test_source_adapter_changes_only_provenance_acceptance():
    from research.volatility_paper.regime import POLICY

    isolated = bt.historical_classifier()
    assert isolated.POLICY == {**POLICY, "source": "alpaca", "venue": "SIP"}
    assert POLICY["source"] == "yahoo"


def test_future_targets_start_after_prediction_and_end_at_session_close():
    rows = bt.score_session(
        mapping(minute_bars()), "SPY", DAY, (OPEN, CLOSE), bt.historical_classifier(), protocol()
    )
    ten = next(r for r in rows if r["time"] == "10:00:15")
    assert bt.stamp(ten["future_start"]) > bt.stamp(ten["forecast_at"])
    assert ten["future_end"] == CLOSE.isoformat()
    assert ten["future"] == "TREND"


def test_missing_minutes_are_never_interpolated_into_outcomes():
    rows = mapping(minute_bars())
    rows.pop(OPEN + timedelta(minutes=120))
    assert bt.interval(rows, OPEN, CLOSE) is None
    scores = bt.score_session(
        rows, "SPY", DAY, (OPEN, CLOSE), bt.historical_classifier(), protocol()
    )
    ten = next(r for r in scores if r["time"] == "10:00:15")
    assert ten["prediction"] == "TREND"
    assert ten["future"] == "UNKNOWN"
    assert ten["future_30"] == "TREND"


def test_early_close_blocks_afternoon_forecast():
    shortened = OPEN + timedelta(minutes=210)
    rows = bt.score_session(
        mapping(minute_bars(count=210)),
        "SPY",
        DAY,
        (OPEN, shortened),
        bt.historical_classifier(),
        protocol(),
    )
    afternoon = next(r for r in rows if r["time"] == "14:00:15")
    assert afternoon["status"] == "OUTSIDE_SESSION"


def test_unknown_and_mixed_predictions_are_in_accuracy_denominator():
    rows = [
        {"date": "2022-01-03", "status": "OK", "prediction": prediction, "future": actual}
        for prediction, actual in [
            ("TREND", "TREND"),
            ("CHOPPY", "TREND"),
            ("UNKNOWN", "TREND"),
            ("MIXED", "CHOPPY"),
        ]
    ]
    result = bt.summarize(rows)
    assert result["outcome_available"] == 4
    assert result["accuracy_all_outcomes"] == 0.25
    assert result["classes"]["TREND"]["recall"] == pytest.approx(1 / 3)
    assert result["classes"]["TREND"]["precision"] == 1
    assert result["majority_baseline_accuracy"] == 0.75


def test_bootstrap_groups_both_symbols_by_date():
    rows = [
        {"date": str(day), "status": "OK", "prediction": pred, "future": actual}
        for day in range(10)
        for pred, actual in [("TREND", "TREND"), ("CHOPPY", "CHOPPY")]
    ]
    result = bt.bootstrap_lift(rows, "TREND", protocol())
    assert result["unit"] == "DATE_BLOCK_BOTH_SYMBOLS"
    assert result["lift_95_percentile"] == [0.5, 0.5]


def test_lossless_archive_column_encoding():
    rows = minute_bars(count=2)
    columns = ["timestamp", "open", "high", "low", "close", "volume"]
    envelope = {
        "columns": columns,
        "source_counts": {"records": 10},
        "response": {
            "request": {"feed": "sip", "timeframe": "1Min", "limit": 10000},
            "counts": {"records": 2},
            "bars": {"SPY": [[row[c] for c in columns] for row in rows]},
        },
    }
    decoded = bt.decode_response(envelope)
    assert decoded["bars"]["SPY"] == rows
    # Column compaction does not mutate the original archived document.
    assert isinstance(envelope["response"]["bars"]["SPY"][0], list)


@pytest.mark.parametrize("damage", ["page_cap", "truncated_rows", "wrong_timeframe"])
def test_bad_or_capped_archives_fail_closed(damage):
    envelope = {
        "source_counts": {"records": 10},
        "response": {
            "request": {"feed": "sip", "timeframe": "1Min", "limit": 10000},
            "counts": {"records": 1},
            "bars": {"SPY": minute_bars(count=1)},
        },
    }
    if damage == "page_cap":
        envelope["source_counts"]["records"] = 10000
    elif damage == "truncated_rows":
        envelope["response"]["counts"]["records"] = 2
    else:
        envelope["response"]["request"]["timeframe"] = "5Min"
    with pytest.raises(ValueError):
        bt.decode_response(envelope)


def test_baseline_only_learns_from_prior_closed_sessions():
    rows = [
        {
            "date": f"2022-01-0{day}",
            "symbol": symbol,
            "time": "10:00:15",
            "status": "OK",
            "future": value,
        }
        for day, value in [(3, "CHOPPY"), (4, "TREND"), (5, "TREND")]
        for symbol in ("SPY", "QQQ")
    ]
    bt.prior_majority_baseline(rows)
    for symbol in ("SPY", "QQQ"):
        subset = [row for row in rows if row["symbol"] == symbol]
        assert [r["prior_session_baseline_samples"] for r in subset] == [0, 1, 2]
        assert subset[0]["prior_session_majority"] == "UNKNOWN"
        assert subset[1]["prior_session_majority"] == "CHOPPY"


def test_split_queries_validate_each_provider_row_limit():
    request = {"feed": "sip", "timeframe": "1Min", "limit": 10000}
    envelope = {
        "source_queries": [
            {"request": request, "counts": {"records": 6000}},
            {"request": request, "counts": {"records": 6000}},
        ],
        "response": {
            "request": request,
            "counts": {"records": 1},
            "bars": {"SPY": minute_bars(count=1)},
        },
    }
    assert bt.decode_response(envelope)["counts"]["records"] == 1
    envelope["source_queries"][1]["counts"]["records"] = 10000
    with pytest.raises(ValueError, match="capped"):
        bt.decode_response(envelope)
