"""Offline overlapping-entry/monitor regressions; no real broker interfaces."""

import asyncio
import json
from datetime import UTC, datetime, timedelta

import pytest
from test_options_deterministic import NOW, candidate, config, refresh, review, routing, snapshot

import tools.live_fast_monitor as fast
import tools.live_trading as live
from tools.config import TradingConfig
from tools.options_strategy import ledger_directory
from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock


@pytest.fixture
def entry_environment(tmp_path, resolved_config, monkeypatch):
    cfg = TradingConfig(
        {**config(resolved_config, live_mode=True).values, "LIVE_FAST_MONITOR_ENABLED": True}
    )
    clock = [NOW]

    class Clock(datetime):
        @classmethod
        def now(cls, tz=UTC):
            return clock[0].astimezone(tz)

    monkeypatch.setattr(live, "datetime", Clock)
    path = ledger_directory(tmp_path, cfg, "live") / "STATE.json"
    state = live._load_state(path, account_value=10000, now=NOW, config=cfg)
    live._save_state(path, state)
    runtime = tmp_path / "state/runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    monitor = fast.LiveMonitor(
        tmp_path,
        execute=True,
        snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot(clock[0])),
        clock=lambda: clock[0],
    )

    async def poll():
        result = await monitor.poll(cfg)
        fast.publish(
            tmp_path,
            result,
            monitor=monitor,
            started=clock[0],
            tick=monitor.monotonic(),
            previous=None,
            interval=10,
        )
        return result

    async def enter(reviewer, placer, symbol="SPY"):
        return await live.apply_live_decision(
            routing(symbol, now=clock[0]),
            {"option_discovery": {"qualified_candidates": [candidate(symbol=symbol)]}},
            cfg,
            project_root=tmp_path,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot(clock[0])),
            quote_fetcher=lambda _: asyncio.sleep(0, result=refresh(symbol=symbol, now=clock[0])),
            reviewer=reviewer,
            placer=placer,
        )

    with advisory_file_lock(runtime / "live_fast_monitor.owner", timeout_seconds=0):
        asyncio.run(poll())
        yield cfg, path, clock, monitor, poll, enter


def test_monitor_can_reconcile_during_entry_review(entry_environment):
    cfg, path, clock, monitor, poll, enter = entry_environment
    observations, placed = [], []

    async def reviewer(request):
        observations.append(await poll())
        return await review(request)

    async def place(request):
        pending = json.loads(path.read_text())["pending_orders"]
        assert pending[0]["status"] == "SUBMITTING"
        assert pending[0]["ref_id"] == request["ref_id"]
        # Placement still owns the ledger lock and its durable duplicate fence.
        with pytest.raises(RuntimeLockUnavailable), advisory_file_lock(path, timeout_seconds=0):
            pytest.fail("submission lost the ledger lock")
        placed.append(request)
        return {"id": "synthetic-entry"}

    result = asyncio.run(enter(reviewer, place))
    assert observations[0]["status"] == "QUIET", observations
    assert observations[0]["entry_safe"] is True
    assert result["status"] == "SUBMITTED", result
    assert len(placed) == 1


@pytest.mark.parametrize(
    "change,reason",
    [
        ("green", "daily_green_lock_active"),
        ("pending", "local_live_order_pending"),
        ("risk", "live_risk_gate_blocked"),
        ("position", "broker_local_position_mismatch"),
    ],
)
def test_state_changed_during_review_is_rechecked(entry_environment, change, reason):
    cfg, path, clock, monitor, poll, enter = entry_environment

    async def reviewer(request):
        with advisory_file_lock(path, timeout_seconds=0):
            state = json.loads(path.read_text())
            if change == "green":
                state["day"].update(green_lock_active=True, realized_pnl=10)
            elif change == "pending":
                state["pending_orders"] = [{"purpose": "EXIT", "order_id": "other-exit"}]
            elif change == "risk":
                state["day"]["new_positions"] = cfg.get("MAX_NEW_POSITIONS_PER_DAY")
            else:
                state["positions"] = [
                    {"position_id": "new-position", "contract_identifier": "other", "quantity": 1}
                ]
            live._save_state(path, state)
        return await review(request)

    async def forbidden(_):
        pytest.fail("changed state reached placement")

    result = asyncio.run(enter(reviewer, forbidden))
    assert result["reason"] == reason
    state = json.loads(path.read_text())
    if change == "pending":
        assert state["pending_orders"][0]["order_id"] == "other-exit"


def test_overlapping_reviews_submit_only_one_entry(entry_environment):
    cfg, path, clock, monitor, poll, enter = entry_environment
    calls, placed = [], []

    async def scenario():
        both_reviewing = asyncio.Event()

        async def reviewer(request):
            calls.append(request)
            if len(calls) == 2:
                both_reviewing.set()
            await asyncio.wait_for(both_reviewing.wait(), timeout=2)
            return await review(request)

        async def place(request):
            placed.append(request)
            return {"id": "only-entry"}

        return await asyncio.gather(enter(reviewer, place), enter(reviewer, place))

    results = asyncio.run(scenario())
    assert sorted(r["status"] for r in results) == ["BLOCKED", "SUBMITTED"]
    assert len(placed) == 1
    assert len(json.loads(path.read_text())["pending_orders"]) == 1


@pytest.mark.parametrize("failure", ["expired", "unhealthy"])
def test_review_cannot_bypass_freshness_or_monitor_health(entry_environment, failure):
    cfg, path, clock, monitor, poll, enter = entry_environment

    async def reviewer(request):
        if failure == "expired":
            clock[0] += timedelta(seconds=21)
        else:

            async def unavailable():
                raise TimeoutError()

            monitor.snapshot = unavailable
        await poll()
        return await review(request)

    async def forbidden(_):
        pytest.fail("expired or unhealthy state reached placement")

    result = asyncio.run(enter(reviewer, forbidden))
    assert result["reason"] == "live_pre_submit_state_expired_or_changed"
    assert json.loads(path.read_text())["pending_orders"] == []


def test_cancelled_review_leaves_no_submission_or_held_lock(entry_environment):
    cfg, path, clock, monitor, poll, enter = entry_environment

    async def cancelled(_):
        raise asyncio.CancelledError()

    async def forbidden(_):
        pytest.fail("cancelled review reached placement")

    with pytest.raises(asyncio.CancelledError):
        asyncio.run(enter(cancelled, forbidden))
    with advisory_file_lock(path, timeout_seconds=0):
        assert json.loads(path.read_text())["pending_orders"] == []


def test_existing_position_stop_can_proceed_during_entry_review(entry_environment):
    cfg, path, clock, monitor, poll, enter = entry_environment
    state = json.loads(path.read_text())
    state["positions"] = [
        {
            "position_id": "held-spy",
            "contract_identifier": "SPY-fixture",
            "symbol": "SPY",
            "quantity": 1,
            "entry_price": 0.5,
            "entry_cost": 50,
            "last_bid": 0.5,
            "stop_price": 0.375,
            "take_profit_price": 0.65,
            "high_water_bid": 0.5,
            "trade_style": "DAY",
            "hold_deadline": (NOW + timedelta(hours=2)).isoformat(),
            "status": "OPEN",
        }
    ]
    live._save_state(path, state)
    held_snapshot = {
        **snapshot(),
        "positions": [{"option_id": "SPY-fixture", "quantity": "1"}],
        "option_quotes": [
            {"instrument_id": "SPY-fixture", "bid_price": ".3", "updated_at": NOW.isoformat()}
        ],
    }
    exits = []

    async def place_exit(request):
        exits.append(request)
        return {"id": "held-stop-exit"}

    monitor.snapshot = lambda: asyncio.sleep(0, result=held_snapshot)
    monitor.review = review
    monitor.place = place_exit

    async def reviewer(request):
        result = await poll()
        assert result["orders_placed"] == 1
        return await review(request)

    async def forbidden(_):
        pytest.fail("new entry raced an existing protective exit")

    async def scenario():
        return await live.apply_live_decision(
            routing("QQQ"),
            {"option_discovery": {"qualified_candidates": [candidate(symbol="QQQ")]}},
            cfg,
            project_root=path.parents[4],
            snapshot_fetcher=lambda: asyncio.sleep(0, result=held_snapshot),
            quote_fetcher=lambda _: asyncio.sleep(0, result=refresh(symbol="QQQ")),
            reviewer=reviewer,
            placer=forbidden,
        )

    result = asyncio.run(scenario())
    assert result["reason"] == "local_live_order_pending"
    assert len(exits) == 1 and exits[0]["legs"][0]["side"] == "sell"
    saved = json.loads(path.read_text())
    assert saved["pending_orders"][0]["order_id"] == "held-stop-exit"
