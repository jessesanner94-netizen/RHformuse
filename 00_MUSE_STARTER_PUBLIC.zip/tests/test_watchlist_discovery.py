from __future__ import annotations

import asyncio
from datetime import UTC, datetime

from tools.config import TradingConfig
from tools.watchlist_discovery import run_watchlist_option_discovery


def test_watchlist_discovery_resolves_only_configured_symbols(tmp_path) -> None:
    config = TradingConfig(
        {
            "LIVE_EXECUTION_ENABLED": False,
            "WATCHLIST_ONLY": True,
            "WATCHLIST_SYMBOLS": "spy, QQQ, SPY",
        }
    )
    calls = []

    async def resolver(symbols, received_config, **kwargs):
        calls.append((symbols, received_config, kwargs))
        return {
            "status": "QUALIFIED",
            "qualified_candidates": [
                {"candidate_id": "spy-call", "symbol": "SPY"},
                {"candidate_id": "qqq-put", "symbol": "qqq"},
                {"candidate_id": "blocked-aapl", "symbol": "AAPL"},
            ],
        }

    result = asyncio.run(
        run_watchlist_option_discovery(
            config,
            state_path=tmp_path / "seen.json",
            now=datetime(2026, 8, 31, 15, 0, tzinfo=UTC),
            commit=False,
            option_resolver=resolver,
        )
    )

    assert calls[0][0] == ["SPY", "QQQ"]
    assert calls[0][1] is config
    assert calls[0][2]["discovery_source"] == "CONFIGURED_WATCHLIST"
    assert result["symbols"] == ["SPY", "QQQ"]
    assert [item["candidate_id"] for item in result["qualified_candidates"]] == [
        "spy-call",
        "qqq-put",
    ]
    assert result["orders_placed"] == 0
    assert not (tmp_path / "seen.json").exists()
