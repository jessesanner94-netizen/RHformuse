"""Offline cost/lock regressions using real paper accounting, never broker orders."""

import asyncio
import json
from datetime import UTC, datetime, timedelta

import pytest

import tools.decision_context as context
import tools.paper_experiment as experiment
import tools.paper_runner as runner
import tools.scheduled_cycle as cycle
from tools.config import TradingConfig
from tools.paper_trading import (
    close_paper_position,
    ensure_paper_portfolio,
    load_paper_portfolio,
    manage_paper_positions,
    net_reward_risk,
    open_paper_position,
)

NOW = datetime(2026, 9, 4, 15, 0, tzinfo=UTC)


@pytest.fixture
def config(resolved_config):
    return TradingConfig({
        **resolved_config.values,
        "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS": 0.05,
        "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS": 1.0,
        "ENTRY_EXIT_COST_BUFFER_DOLLARS": 2.1,
        "MIN_NET_REWARD_TO_RISK": 1.0,
        "PAPER_DAILY_GREEN_LOCK_ENABLED": True,
        "PAPER_BASELINE_ENABLED": True,
        "UW_ENABLED": False,
        "ECONOMIC_CALENDAR_ENABLED": False,
    })


def candidate(*, ask=1.1, symbol="SPY", now=NOW):
    return {
        "candidate_id": symbol + "-fixture", "symbol": symbol, "option_type": "CALL",
        "option_symbol": symbol + "-SYNTHETIC", "strike": 500.0,
        "expiration": "2026-09-18", "dte": 14, "underlying_price": 500.0,
        "bid": ask - 0.02, "ask": ask, "option_volume": 1000,
        "option_open_interest": 5000, "underlying_avg_daily_dollar_volume": 1e10,
        "quote_is_fresh": True, "quote_updated_at": now.isoformat(),
        "setup_qualified": True, "implied_volatility": 0.25, "delta": 0.5,
        "gamma": 0.002, "theta": -0.02, "vega": 0.1, "rho": 0.02,
        "entry_eligible_trade_styles": ["DAY"],
    }


def verdict(*, action="BUY", symbol="SPY"):
    return {
        "action": action, "candidate_id": symbol + "-fixture", "trade_style": "DAY",
        "thesis": "Synthetic aligned setup", "invalidation": "Synthetic support fails",
        "reason": "Offline fixture", "confidence": 0.7, "holds_through_earnings": False,
    }


def routing(*, action="BUY", cached=False, symbol="SPY"):
    return {
        "decision": {"status": "COMPLETED", "cached": cached,
                     "output": json.dumps(verdict(action=action, symbol=symbol))},
        "decision_packet": {
            "python_gate": {"status": "QUALIFIED"}, "as_of": NOW.isoformat(),
            "candidate": {"candidate_id": symbol + "-fixture", "python_preferred_style": "DAY"},
        },
    }


def refresh(*, ask=1.1, bid=None, now=NOW, symbol="SPY"):
    item = candidate(ask=ask, symbol=symbol, now=now)
    return {"as_of": now.isoformat(), "option_quotes": [{"quote": {
        "instrument_id": item["candidate_id"], "bid_price": bid if bid is not None else ask - .02,
        "ask_price": ask, "updated_at": now.isoformat(), "volume": 1000, "open_interest": 5000,
        **{key: item[key] for key in ("implied_volatility", "delta", "gamma", "theta", "vega")},
    }}]}


def paths(root, name="daily_green_lock"):
    directory = root / "state" / name
    return {"portfolio_path": directory / "PORTFOLIO.json",
            "event_log_path": directory / "EVENTS.jsonl"}


def test_gross_favorable_target_fails_after_costs(config):
    result = net_reward_risk(candidate(ask=.50), config)
    assert .50 * .30 > .50 * .25
    assert result["net_reward_dollars"] == 12.9
    assert result["net_risk_dollars"] == 14.6
    assert result["expected_entry_debit_dollars"] == 51.05
    assert result["net_take_profit_pnl_dollars"] == 12.9
    assert result["net_stop_loss_pnl_dollars"] == -14.6
    assert result["reasons"] == ["net_reward_to_risk_below_minimum"]


def test_exact_one_to_one_passes_and_matches_real_accounting(tmp_path, config):
    item = candidate(ask=.84)
    plan = net_reward_risk(item, config)
    assert plan["status"] == "QUALIFIED"
    assert plan["net_reward_to_risk"] == 1.0
    assert plan["net_reward_dollars"] == plan["net_risk_dollars"] == 23.1
    for scenario, price, expected in (("target", 1.092, 23.1), ("stop", .63, -23.1)):
        ledger = paths(tmp_path, scenario)
        opened = open_paper_position(verdict(), item, config, **ledger, now=NOW)
        closed = close_paper_position(
            opened["position"]["paper_id"], bid=price, quote_updated_at=NOW.isoformat(),
            reason="TEST", config=config, **ledger, now=NOW,
        )
        assert closed["position"]["realized_pnl"] == expected


@pytest.mark.parametrize("minimum", [None, 0, -1, True, float("nan"), float("inf")])
def test_invalid_minimum_fails_closed(config, minimum):
    changed = TradingConfig({**config.values, "MIN_NET_REWARD_TO_RISK": minimum})
    assert net_reward_risk(candidate(), changed)["status"] == "REJECTED"


def test_nonpositive_reward_and_zero_risk_fail_closed(config):
    zero_reward = TradingConfig({**config.values, "TAKE_PROFIT_PERCENT": 0})
    assert "net_reward_not_positive" in net_reward_risk(candidate(), zero_reward)["reasons"]
    zero_risk = TradingConfig({**config.values, "STOP_LOSS_PERCENT": 0,
                              "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS": 0,
                              "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS": 0})
    assert net_reward_risk(candidate(), zero_risk)["reasons"] == ["net_risk_invalid_or_zero"]


def test_bad_ratio_never_reaches_jev_or_luna(tmp_path, monkeypatch, config):
    cfg = TradingConfig({**config.values, "ENABLE_JEV": True, "JEV_SHADOW_MODE": False,
                         "OPTIONS_JEV_RANKING_ONLY": True})
    state = ensure_paper_portfolio(cfg, **paths(tmp_path, "paper"), now=NOW)
    from tools.paper_trading import paper_summary

    event = {"option_discovery": {"qualified_candidates": [candidate(ask=.50)]},
             "paper_portfolio": {"portfolio": paper_summary(state), "open_positions": []}}

    def forbidden(*args, **kwargs):
        raise AssertionError("rejected economics must not spend data/model calls")

    monkeypatch.setattr(context, "fetch_vibe_snapshot", forbidden)
    monkeypatch.setattr(cycle, "evaluate_candidate", forbidden)  # JEV
    monkeypatch.setattr(cycle, "run_trigger", forbidden)  # Luna
    result = asyncio.run(cycle._route_compact_decision(
        event, config=cfg, project_root=tmp_path, execute_models=True, now=NOW,
    ))
    assert result["decision"]["codex_invoked"] is False
    gate = result["python_rejections"][0]["gate"]
    assert gate["net_reward_dollars"] == 12.9
    assert gate["reasons"] == ["net_reward_to_risk_below_minimum"]
    assert not (tmp_path / "state/runtime/model_budget.json").exists()


@pytest.mark.parametrize("ledger_name", ["paper", "paper_baseline", "daily_green_lock"])
def test_final_refresh_cannot_bypass_ratio(tmp_path, config, ledger_name):
    result = asyncio.run(runner.apply_paper_decision(
        routing(), {"option_discovery": {"qualified_candidates": [candidate()]}}, config,
        project_root=tmp_path, now=NOW, ledger_name=ledger_name,
        quote_fetcher=lambda _: asyncio.sleep(0, result=refresh(ask=.50)),
    ))
    assert result["opened"] is False
    assert result["reasons"] == ["net_reward_to_risk_below_minimum"]
    assert result["net_reward_risk"]["net_reward_to_risk"] < 1


def test_realized_only_lock_is_sticky_and_resets_next_session(tmp_path, config):
    ledger = paths(tmp_path)
    first = open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
    second = open_paper_position(
        verdict(symbol="QQQ"), candidate(symbol="QQQ"), config, **ledger, now=NOW,
    )
    assert first["opened"] and second["opened"]
    marked = manage_paper_positions(
        refresh(bid=1.4, ask=1.41), config, **ledger, now=NOW,
    )
    assert marked["portfolio"]["unrealized_pnl"] > 0
    assert marked["portfolio"]["day"]["green_lock_active"] is False
    close_time = NOW + timedelta(minutes=1)
    closed = close_paper_position(
        first["position"]["paper_id"], bid=1.44, quote_updated_at=close_time.isoformat(),
        reason="TEST", config=config, **ledger, now=close_time,
    )
    day = closed["portfolio"]["day"]
    assert day["green_lock_active"] is True
    assert day["realized_pnl_at_activation"] == 31.9
    assert day["lock_activated_at"] == close_time.isoformat()
    assert closed["portfolio"]["open_positions"] == 1  # No forced close.
    losing = close_paper_position(
        second["position"]["paper_id"], bid=.1, quote_updated_at=close_time.isoformat(),
        reason="TEST", config=config, **ledger, now=close_time,
    )
    assert losing["portfolio"]["day"]["realized_pnl"] < 0
    rejected = open_paper_position(verdict(), candidate(), config, **ledger, now=close_time)
    assert rejected["reasons"] == ["daily_green_lock_active"]
    assert rejected["portfolio"]["day"]["skipped_entry_count"] == 1
    # September 7 is a holiday; next actual trading day is September 8.
    next_session = NOW + timedelta(days=4)
    opened = open_paper_position(
        verdict(), candidate(now=next_session), config, **ledger, now=next_session,
    )
    assert opened["opened"]
    assert opened["portfolio"]["day"]["green_lock_active"] is False
    assert opened["portfolio"]["day"]["skipped_entry_count"] == 0
    events = [json.loads(line) for line in ledger["event_log_path"].read_text().splitlines()]
    assert all(event["strategy_variant"] == "daily_green_lock" for event in events)
    assert len([event for event in events if event["event"] == "DAILY_GREEN_LOCK_ACTIVATED"]) == 1


def test_net_zero_close_does_not_lock_and_monitor_close_does(tmp_path, config):
    ledger = paths(tmp_path)
    first = open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
    zero = close_paper_position(
        first["position"]["paper_id"], bid=1.121, quote_updated_at=NOW.isoformat(),
        reason="TEST", config=config, **ledger, now=NOW,
    )
    assert zero["portfolio"]["day"]["realized_pnl"] == 0
    assert zero["portfolio"]["day"]["green_lock_active"] is False
    open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
    exited = manage_paper_positions(refresh(bid=1.44, ask=1.46), config, **ledger, now=NOW)
    assert exited["portfolio"]["day"]["green_lock_active"] is True
    assert exited["paper_events"][0]["event"] == "PAPER_EXIT"


def test_assumed_tp_limit_keeps_more_conservative_trigger_plan(tmp_path, config):
    cfg = TradingConfig({**config.values, "PAPER_ASSUME_TP_TRADE_THROUGH": True})
    ledger = paths(tmp_path)
    entry = NOW - timedelta(minutes=3)
    opened = open_paper_position(verdict(), candidate(ask=.84, now=entry), cfg, **ledger, now=entry)
    assert opened["net_reward_risk"]["net_reward_dollars"] == 23.1
    snapshot = refresh(ask=.85, bid=.83)
    snapshot["tp_history"] = {"SPY-fixture": {"status": "OK", "results": [{
        "instrument_id": "SPY-fixture", "interval": "minute", "bars": [{
            "begins_at": (NOW - timedelta(minutes=2)).isoformat(),
            "high_price": "1.11", "low_price": ".80", "interpolated": False,
        }],
    }]}}
    exited = manage_paper_positions(snapshot, cfg, **ledger, now=NOW)
    assert exited["paper_events"][0]["fill_price"] == 1.10
    assert exited["portfolio"]["realized_pnl"] == 23.9
    assert exited["portfolio"]["day"]["green_lock_active"] is True


def test_locked_variant_skips_before_quote_fetch(tmp_path, config):
    ledger = paths(tmp_path)
    opened = open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
    close_paper_position(opened["position"]["paper_id"], bid=1.44,
                         quote_updated_at=NOW.isoformat(), reason="TEST", config=config,
                         **ledger, now=NOW)

    async def forbidden(_):
        raise AssertionError("locked comparator does not need a new fill quote")

    result = asyncio.run(experiment.apply_green_lock_decision(
        routing(), {"option_discovery": {"qualified_candidates": [candidate()]}},
        config, project_root=tmp_path, now=NOW, quote_fetcher=forbidden,
    ))
    assert result["reasons"] == ["daily_green_lock_active"]
    assert result["portfolio"]["day"]["skipped_entry_count"] == 1


def test_profitable_close_must_take_cumulative_day_above_zero(tmp_path, config):
    ledger = paths(tmp_path)
    for bid, expected, active in ((.80, -32.1, False), (1.44, -.2, False), (1.44, 31.7, True)):
        opened = open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
        closed = close_paper_position(
            opened["position"]["paper_id"], bid=bid, quote_updated_at=NOW.isoformat(),
            reason="TEST", config=config, **ledger, now=NOW,
        )
        assert closed["portfolio"]["day"]["realized_pnl"] == expected
        assert closed["portfolio"]["day"]["green_lock_active"] is active


def test_one_cent_realized_profit_activates(tmp_path, config):
    ledger = paths(tmp_path)
    opened = open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
    closed = close_paper_position(
        opened["position"]["paper_id"], bid=1.1211, quote_updated_at=NOW.isoformat(),
        reason="TEST", config=config, **ledger, now=NOW,
    )
    assert closed["portfolio"]["day"]["realized_pnl_at_activation"] == .01


def test_failed_variant_monitor_blocks_its_entry(tmp_path, config):
    result = asyncio.run(experiment.apply_green_lock_decision(
        routing(), {"option_discovery": {"qualified_candidates": [candidate()]},
                    "daily_green_lock_portfolio": {"status": "ATTENTION"}},
        config, project_root=tmp_path, now=NOW,
    ))
    assert result["opened"] is False
    assert result["reasons"] == ["daily_green_lock_monitor_not_ready"]


@pytest.mark.parametrize("action,cached", [("PASS", False), ("WATCH", False), ("BUY", True)])
def test_variant_never_bypasses_luna_or_replays_cached_buy(tmp_path, config, action, cached):
    result = asyncio.run(experiment.apply_green_lock_decision(
        routing(action=action, cached=cached),
        {"option_discovery": {"qualified_candidates": [candidate()]}}, config,
        project_root=tmp_path, now=NOW,
    ))
    assert result["opened"] is False
    assert result["skip_recorded"] is True


def test_variant_does_not_modify_existing_ledgers_and_is_paper_only(tmp_path, config):
    for name in ("paper", "paper_baseline"):
        open_paper_position(verdict(), candidate(), config, **paths(tmp_path, name), now=NOW)
    files = [path for name in ("paper", "paper_baseline")
             for path in paths(tmp_path, name)["portfolio_path"].parent.iterdir()]
    before = {path: path.read_bytes() for path in files}
    ledger = paths(tmp_path)
    opened = open_paper_position(verdict(), candidate(), config, **ledger, now=NOW)
    close_paper_position(opened["position"]["paper_id"], bid=1.44,
                         quote_updated_at=NOW.isoformat(), reason="TEST", config=config,
                         **ledger, now=NOW)
    assert before == {path: path.read_bytes() for path in files}
    live = TradingConfig({**config.values, "LIVE_EXECUTION_ENABLED": True})
    assert experiment.green_lock_enabled(live) is False
    result = open_paper_position(verdict(), candidate(), live, **ledger, now=NOW)
    assert result["reasons"] == ["daily_green_lock_paper_only"]
    assert load_paper_portfolio(ledger["portfolio_path"], starting_cash=10000,
                                now=NOW)["day"]["green_lock_active"] is True
