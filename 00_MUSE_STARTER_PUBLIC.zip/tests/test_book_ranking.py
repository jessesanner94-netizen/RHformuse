"""Synthetic point-in-time paper ranking checks; no brokerage/model/data clients."""

import asyncio
import copy
import json
from datetime import UTC, datetime, timedelta

import pytest

from research.options_lab.book_ranking import (
    book_policy,
    book_signal,
    candidate_components,
    ranking_audit,
)
from research.options_lab.forward import POLICY
from tools.config import TradingConfig
from tools.scheduled_cycle import _route_compact_decision_impl

NOW = datetime(2026, 10, 23, 14, tzinfo=UTC)


def snapshots(direction=1, *, wall=None, thin=False, price_gap=False, now=NOW):
    rows = []
    for offset in range(-130, 1, 10):
        confirming = offset >= -20
        mid = 500 + (direction * (offset + 20) / 100 if confirming else 0)
        bid, ask = (500, 50) if direction == 1 else (50, 500) if direction == -1 else (200, 200)
        if not confirming:
            bid = ask = 1000 if thin else 400
        stamp = (now + timedelta(seconds=offset)).isoformat()
        step = 0.2 if price_gap else 0.01
        payload = {
            "symbol": "SPY",
            "updated_at": stamp,
            "bids": [{"price": mid - 0.01 - i * step, "quantity": bid} for i in range(5)],
            "asks": [{"price": mid + 0.01 + i * step, "quantity": ask} for i in range(5)],
        }
        if wall:
            name, price = ("asks", 501.5) if wall == "CALL" else ("bids", 498.5)
            # Only the persistent wall, outside the five near levels, earns a penalty.
            price = 500.9 if wall == "CALL" else 499.1
            payload[name].append({"price": price, "quantity": 10000})
        rows.append(
            {
                "schema_version": 1,
                "kind": "book",
                "source": "robinhood",
                "venue": "UNSPECIFIED",
                "symbol": "SPY",
                "event_id": stamp,
                "event_at": stamp,
                "received_at": stamp,
                "available_at": stamp,
                "payload": payload,
            }
        )
    return rows


def score(rows, side="CALL", *, now=NOW, rsi=None, policy=None):
    observation = book_signal(rows, "SPY", now, policy=policy, wall_policy=POLICY["zones"])
    return candidate_components(
        {"candidate_id": side, "symbol": "SPY", "option_type": side},
        rsi or {"status": "OK"},
        observation,
        policy=policy,
    )


@pytest.mark.parametrize(
    "direction,side,value", [(1, "CALL", 4), (1, "PUT", -4), (-1, "CALL", -4), (-1, "PUT", 4)]
)
def test_confirmed_book_direction_rewards_and_penalizes(direction, side, value):
    result = score(snapshots(direction), side)
    assert result["book_status"] == "OK" and result["book_score"] == value
    assert result["book_evidence"]["executed_volume_available"] is False
    assert result["book_evidence"]["latest_available_at"] == NOW.isoformat()
    assert result["book_entry_veto"] is False


@pytest.mark.parametrize("thin,price_gap", [(True, False), (False, True)])
def test_sparse_depth_only_amplifies_an_already_confirmed_direction(thin, price_gap):
    assert score(snapshots(1, thin=thin, price_gap=price_gap))["book_score"] == 5
    result = score(snapshots(0, thin=thin, price_gap=price_gap))
    assert result["book_score"] == 0 and result["direction_alignment"] == "NEUTRAL"


@pytest.mark.parametrize("side", ["CALL", "PUT"])
def test_persistent_opposing_wall_is_a_bounded_penalty(side):
    result = score(snapshots(0, wall=side), side)
    assert result["book_score"] == -1 and result["book_entry_veto"] is False
    assert result["components"]["persistent_direction"] == 0


def test_wall_appearance_or_disappearance_alone_is_not_directional():
    for rows in [snapshots(0), snapshots(0, wall="CALL")]:
        if len(rows[-1]["payload"]["asks"]) == 5:
            rows[-1]["payload"]["asks"].append({"price": 500.9, "quantity": 10000})
        else:
            rows[-1]["payload"]["asks"].pop()
        result = score(rows)
        assert result["book_score"] == 0 and result["direction_alignment"] == "NEUTRAL"


@pytest.mark.parametrize(
    "change",
    [
        "missing",
        "stale",
        "transport_gap",
        "conflict",
        "wrong_feed",
        "one_sided",
        "duplicate_only",
        "old_session",
    ],
)
def test_unavailable_book_is_neutral_and_never_vetoes(change):
    rows = snapshots()
    at = NOW
    if change == "missing":
        rows = []
    elif change == "stale":
        at += timedelta(seconds=31)
    elif change == "transport_gap":
        rows = rows[:4] + rows[8:]
    elif change == "conflict":
        bad = copy.deepcopy(rows[-1])
        bad["payload"]["bids"][0]["quantity"] += 1
        rows.append(bad)
    elif change == "wrong_feed":
        for row in rows:
            row["source"] = "different"
    elif change == "one_sided":
        rows[-1]["payload"]["asks"] = []
    elif change == "duplicate_only":
        rows = [rows[-1]] * 20
    elif change == "old_session":
        for row in rows:
            for k in ["event_at", "received_at", "available_at"]:
                row[k] = (datetime.fromisoformat(row[k]) - timedelta(days=1)).isoformat()
            row["payload"]["updated_at"] = row["event_at"]
    result = score(rows, now=at)
    assert result["book_status"] == "UNAVAILABLE" and result["book_score"] == 0
    assert result["book_entry_veto"] is False


def test_delayed_and_future_observations_cannot_change_original_ranking():
    rows = snapshots()
    for row in rows[-3:]:
        row["available_at"] = (NOW + timedelta(seconds=1)).isoformat()
    assert score(rows)["book_score"] == 0
    assert score(rows, now=NOW + timedelta(seconds=1))["book_score"] == 4


def test_fixed_midpoint_or_inconsistent_pressure_is_ambiguous():
    rows = snapshots()
    for row in rows[-3:]:
        delta = (float(row["payload"]["bids"][0]["price"]) + 0.01) - 500
        for side in ["bids", "asks"]:
            for level in row["payload"][side]:
                level["price"] -= delta
    assert score(rows)["book_score"] == 0
    rows = snapshots()
    rows[-2]["payload"]["asks"][0]["quantity"] = 10000
    assert score(rows)["book_score"] == 0


def test_weights_caps_and_disabled_feature_are_explicit():
    rsi = {"status": "OK", "latest_confirmed_divergences": [{"kind": "regular_bullish"}]}
    result = score(snapshots(), rsi=rsi, policy={"rsi_weight": 7, "direction_weight": 2})
    assert result["total_priority"] == 9
    assert (
        score(snapshots(1, thin=True), policy={"maximum_absolute_book_score": 3})["book_score"] == 3
    )
    assert score(snapshots(), policy={"enabled": False})["book_score"] == 0
    for invalid in [{"rsi_weight": True}, {"imaginary_field": 1}, {"minimum_imbalance": 2}]:
        with pytest.raises(ValueError):
            book_policy(invalid)


@pytest.mark.parametrize(
    "supported_rsi,book_direction,expected",
    [(False, -1, "put"), (True, 0, "call"), (False, 0, "call")],
)
def test_existing_python_selector_uses_combined_rank_before_jev(
    tmp_path, resolved_config, supported_rsi, book_direction, expected
):
    config = TradingConfig(
        {
            **resolved_config.values,
            "OPTIONS_LUNA_VETO_ENABLED": False,
            "OPTIONS_JEV_RANKING_ONLY": True,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": False,
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": True,
            "ENABLE_MULTI_WATCH": False,
        }
    )
    candidates = [
        {"candidate_id": "call", "symbol": "SPY", "option_type": "CALL"},
        {"candidate_id": "put", "symbol": "QQQ", "option_type": "PUT"},
    ]
    components = {}
    for c in candidates:
        rows = snapshots(book_direction if c["candidate_id"] == "put" else 0)
        rows = copy.deepcopy(rows)
        for row in rows:
            row["symbol"] = row["payload"]["symbol"] = c["symbol"]
        b = book_signal(rows, c["symbol"], NOW, wall_policy=POLICY["zones"])
        r = {
            "status": "OK",
            "latest_confirmed_divergences": (
                [{"kind": "regular_bullish"}] if supported_rsi else []
            ),
        }
        components[c["candidate_id"]] = candidate_components(c, r, b)
    calls = []

    async def build(event, config, **kwargs):
        c = next(
            (c for c in candidates if c["candidate_id"] not in kwargs["excluded_candidate_ids"]),
            None,
        )
        return (
            {
                "status": "READY",
                "selected_candidates": [c],
                "packet": {
                    "candidate": c,
                    "as_of": NOW.isoformat(),
                    "earnings_event": {},
                    "python_gate": {"status": "QUALIFIED"},
                },
            }
            if c
            else {"status": "NO_CANDIDATE"}
        )

    def jev(packet, *args, **kwargs):
        key = packet["candidate"]["candidate_id"]
        calls.append(key)
        value = 0.95 if key == "call" else 0.0
        return {
            "status": "OK",
            "opinion": "AVOID" if key == "put" else "STRONG",
            "scores": {
                k: value for k in ["setup_quality", "entry_timing_quality", "escalate_to_luna"]
            },
        }

    routing = asyncio.run(
        _route_compact_decision_impl(
            {"paper_portfolio": {"open_positions": [], "portfolio": {"open_positions": 0}}},
            config=config,
            project_root=tmp_path,
            execute_models=True,
            now=NOW,
            packet_builder=build,
            jev_evaluator=jev,
            candidate_priority=lambda c: components[c["candidate_id"]]["total_priority"],
        )
    )
    assert json.loads(routing["decision"]["output"])["candidate_id"] == expected
    audit = ranking_audit(routing, components)
    assert audit["ranked_candidate_ids"][0] == expected
    assert calls == ["call", "put"] and routing["decision"]["codex_invoked"] is False
