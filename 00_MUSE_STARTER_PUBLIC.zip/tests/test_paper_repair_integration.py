"""Offline regression of the actual watchlist -> model boundary -> fill -> exit path."""

import asyncio
import json
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

import tools.decision_context as context
import tools.paper_experiment as experiment
import tools.paper_runner as runner
import tools.scheduled_cycle as cycle
from tools.config import TradingConfig, load_config
from tools.market_calendar import day_deadline, entry_allowed, market_window, session_hours
from tools.news_option_discovery import run_symbol_option_discovery
from tools.paper_trading import (
    close_paper_position,
    ensure_paper_portfolio,
    manage_paper_positions,
    open_paper_position,
    paper_account_metrics,
)
from tools.portfolio_risk import evaluate_risk, planned_entry_budget
from tools.robinhood_mcp import select_expirations
from tools.watchlist_discovery import run_watchlist_option_discovery

ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 9, 4, 15, 0, tzinfo=UTC)
ET = ZoneInfo("America/New_York")


def candidate(now=NOW, *, symbol="SPY", ask=1.10, bid=1.05):
    return {
        "candidate_id": symbol + "-fixture",
        "symbol": symbol,
        "option_type": "CALL",
        "option_symbol": symbol + "-SYNTHETIC",
        "strike": 500.0,
        "expiration": "2026-09-08",
        "dte": 4,
        "underlying_price": 500.0,
        "bid": bid,
        "ask": ask,
        "option_volume": 1000,
        "option_open_interest": 5000,
        "underlying_avg_daily_dollar_volume": 1e10,
        "quote_is_fresh": True,
        "quote_updated_at": now.isoformat(),
        "setup_qualified": True,
        "implied_volatility": 0.25,
        "delta": 0.5,
        "gamma": 0.002,
        "theta": -0.02,
        "vega": 0.1,
        "rho": 0.02,
    }


def decision(action="BUY", symbol="SPY"):
    return {
        "action": action,
        "candidate_id": symbol + "-fixture",
        "trade_style": "DAY",
        "thesis": "Synthetic aligned setup",
        "invalidation": "Synthetic support fails",
        "reason": "Offline test verdict",
        "confidence": 0.7,
        "hold_deadline": None,
        "earnings_event": "ETF; synthetic event review",
        "holds_through_earnings": False,
        "decision_valid_until": None,
        "reconsider_above": None,
        "reconsider_below": None,
    }


def quote(now=NOW, *, symbol="SPY", ask=1.10, bid=1.05):
    item = candidate(now, symbol=symbol, ask=ask, bid=bid)
    return {
        "as_of": now.isoformat(),
        "option_quotes": [
            {
                "quote": {
                    "instrument_id": item["candidate_id"],
                    "bid_price": str(bid),
                    "ask_price": str(ask),
                    "updated_at": now.isoformat(),
                    "volume": 1000,
                    "open_interest": 5000,
                    **{
                        key: item[key]
                        for key in ("implied_volatility", "delta", "gamma", "theta", "vega", "rho")
                    },
                }
            }
        ],
    }


def technical(symbol, **_):
    return {
        "status": "OK",
        "symbol": symbol,
        "instrument_type": "ETF",
        "earnings": {"status": "NOT_APPLICABLE", "next_date": None},
        "headlines": [],
        "style_scores": {"DAY": 6, "SWING": 2},
        "timeframes": {
            tf: {"status": "OK", "trend": "BULLISH", "trend_score": 2, "change_1_bar_percent": 1}
            for tf in ("5M", "15M", "4H", "1D")
        },
        "intraday_structure": {"status": "OK", "bias": "BULLISH", "bias_score": 1},
    }


@pytest.fixture
def production():
    # These pre-calendar paper fixtures exercise fills, cutoffs, and accounting.
    # Keep the production calendar gate covered elsewhere, without making these
    # historical tests depend on a live scheduled-release feed.
    config = load_config(ROOT / "CONFIG.md")
    return TradingConfig(
        {
            **config.values,
            "ECONOMIC_CALENDAR_ENABLED": False,
            "ENABLE_JEV": False,
            "ENABLE_LEVEL2": False,
            # Retain the historical Luna/control route as a regression fixture.
            "OPTIONS_LUNA_VETO_ENABLED": True,
            "OPTIONS_STRATEGY_EPOCH": None,
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": False,
            "PAPER_PRIMARY_DAILY_GREEN_LOCK_ENABLED": False,
            "PAPER_DAILY_GREEN_LOCK_ENABLED": True,
        }
    )


def test_real_packet_deterministic_primary_entry_exit_and_lock(tmp_path, monkeypatch, production):
    from tools.option_style import annotate_option_styles

    cfg = TradingConfig(
        {
            **production.values,
            "OPTIONS_LUNA_VETO_ENABLED": False,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": False,
            "OPTIONS_JEV_RANKING_ONLY": True,
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": True,
            "OPTIONS_STRATEGY_EPOCH": "synthetic_forward_epoch",
            "PAPER_BASELINE_ENABLED": False,
            "PAPER_DAILY_GREEN_LOCK_ENABLED": False,
        }
    )
    counts = {"jev": 0, "scan": 0}

    async def watchlist(*args, **kwargs):
        counts["scan"] += 1
        return {
            "status": "QUALIFIED",
            "qualified_candidates": [annotate_option_styles(candidate(), cfg)],
        }

    async def packet(*args, **kwargs):
        return await context.build_decision_packet(*args, **kwargs, technical_fetcher=technical)

    def jev(*args, **kwargs):
        counts["jev"] += 1
        return {
            "status": "OK",
            "scores": {"setup_quality": 0.1, "entry_timing_quality": 0.1, "escalate_to_luna": 0.1},
        }

    def forbidden(*args, **kwargs):
        raise AssertionError("The deterministic route must not call Luna/cache/budget")

    monkeypatch.setattr(cycle, "load_config", lambda _: cfg)
    monkeypatch.setattr(
        cycle,
        "run_live_monitor",
        lambda _: asyncio.sleep(0, result={"status": "QUIET", "wake_codex": False}),
    )
    monkeypatch.setattr(cycle, "collect_market_intelligence", lambda *a, **k: {"status": "QUIET"})
    monkeypatch.setattr(cycle, "run_watchlist_option_discovery", watchlist)
    monkeypatch.setattr(cycle, "build_decision_packet", packet)
    monkeypatch.setattr(cycle, "evaluate_candidate", jev)
    monkeypatch.setattr(runner, "fetch_quote_refresh", lambda _: asyncio.sleep(0, result=quote()))
    for name in (
        "run_trigger",
        "cached_decision_blocks",
        "model_call_budget_status",
        "reserve_model_call",
    ):
        monkeypatch.setattr(cycle, name, forbidden)
    first = asyncio.run(
        cycle.run_cycle("opportunities", project_root=tmp_path, execute_models=True, now=NOW)
    )
    assert first["paper_decision"]["opened"] is True
    assert counts == {"jev": 1, "scan": 1}
    path, events = runner._paths(tmp_path, config=cfg)
    opened = first["paper_decision"]["position"]
    close_paper_position(
        opened["paper_id"],
        bid=1.2,
        quote_updated_at=NOW.isoformat(),
        reason="TEST",
        config=cfg,
        portfolio_path=path,
        event_log_path=events,
        now=NOW,
    )
    monkeypatch.setattr(cycle, "collect_market_intelligence", forbidden)
    locked = asyncio.run(
        cycle.run_cycle("opportunities", project_root=tmp_path, execute_models=True, now=NOW)
    )
    assert locked["reason"] == "daily_green_lock_active"
    assert counts == {"jev": 1, "scan": 1}
    assert (path.parent.parent / "evaluation/METRICS.json").exists()
    assert not (tmp_path / "state/paper/PORTFOLIO.json").exists()
    assert not (tmp_path / "state/evaluation/METRICS.json").exists()


@pytest.mark.parametrize("action", ["BUY", "PASS", "WAIT", "WATCH"])
def test_real_watchlist_handoff_and_paired_exit(tmp_path, monkeypatch, production, action):
    config = TradingConfig({**production.values, "PAPER_BASELINE_ENABLED": True})
    model_packets = []
    fresh_quotes = []

    async def broker_research(requests):
        assert requests[0]["min_expiration"] == "2026-09-06"
        item = candidate()
        return {
            **quote(),
            "instruments": [
                {
                    "id": item["candidate_id"],
                    "chain_symbol": "SPY",
                    "expiration_date": item["expiration"],
                    "strike_price": "500",
                    "type": "call",
                }
            ],
            "equity_quotes": [{"symbol": "SPY", "last_trade_price": "500"}],
            "equity_fundamentals": [{"symbol": "SPY", "average_volume_30_days": "20000000"}],
        }

    async def resolver(symbols, cfg, **kwargs):
        return await run_symbol_option_discovery(
            symbols, cfg, **kwargs, research_fetcher=broker_research
        )

    async def watchlist(cfg, **kwargs):
        return await run_watchlist_option_discovery(cfg, **kwargs, option_resolver=resolver)

    async def packet(*args, **kwargs):
        return await context.build_decision_packet(*args, **kwargs, technical_fetcher=technical)

    def model(event, **kwargs):
        if not kwargs.get("execute") or event.get(kwargs.get("wake_key")) is not True:
            return {"status": "SKIPPED", "codex_invoked": False}
        assert kwargs["model"] == "gpt-5.6-luna"
        assert kwargs["sandbox"] == "read-only"
        evidence = event["decision_packet"]
        assert evidence["candidate"]["eligible_styles"] == ["DAY"]
        assert evidence["python_gate"]["status"] == "QUALIFIED"
        assert evidence["net_reward_risk"]["net_reward_dollars"] == 30.9
        assert evidence["net_reward_risk"]["net_risk_dollars"] == 29.6
        assert evidence["net_reward_risk"]["net_reward_to_risk"] >= 1.0
        model_packets.append(evidence)
        return {
            "status": "COMPLETED",
            "codex_invoked": True,
            "output": json.dumps(decision(action)),
        }

    async def refresh(requests):
        fresh_quotes.append(requests)
        return quote()

    monkeypatch.setattr(cycle, "load_config", lambda _: config)
    monkeypatch.setattr(
        cycle,
        "run_live_monitor",
        lambda _: asyncio.sleep(0, result={"status": "QUIET", "wake_codex": False, "triggers": []}),
    )
    monkeypatch.setattr(cycle, "collect_market_intelligence", lambda *a, **kw: {"status": "QUIET"})
    monkeypatch.setattr(cycle, "run_watchlist_option_discovery", watchlist)
    monkeypatch.setattr(cycle, "build_decision_packet", packet)
    monkeypatch.setattr(cycle, "run_trigger", model)
    monkeypatch.setattr(experiment, "fetch_quote_refresh", refresh)
    result = asyncio.run(
        cycle.run_cycle(
            "opportunities",
            project_root=tmp_path,
            execute_models=True,
            notifications=False,
            now=NOW,
        )
    )
    assert len(model_packets) == 1
    assert len(fresh_quotes) == 1  # Both ledgers use exactly the same snapshot.
    assert result["paper_decision"].get("opened", False) is (action == "BUY")
    assert result["baseline_decision"]["opened"] is True
    assert result["daily_green_lock_decision"].get("opened", False) is (action == "BUY")
    assert result["orders_placed"] == 0
    assert result["funnel"]["entry_time_passed"] == 1
    assert result["funnel"]["model_calls"] == 1
    assert result["funnel"]["paper_entries"] == int(action == "BUY")
    assert result["funnel"]["baseline_entries"] == 1
    if action == "BUY":
        assert result["paper_decision"]["position"]["entry_price"] == 1.10
        assert result["paper_decision"]["portfolio"]["cash"] == 257.95
    exit_time = NOW + timedelta(minutes=2)
    monkeypatch.setattr(
        runner,
        "fetch_quote_refresh",
        lambda _: asyncio.sleep(0, result=quote(exit_time, bid=1.44, ask=1.46)),
    )
    exited = asyncio.run(
        cycle.run_cycle(
            "positions",
            project_root=tmp_path,
            execute_models=False,
            notifications=False,
            now=exit_time,
        )
    )
    assert exited["baseline"]["paper_events"][0]["exit_reason"] == "TAKE_PROFIT"
    assert exited["baseline"]["portfolio"]["realized_pnl"] == 31.90
    if action == "BUY":
        assert exited["paper"]["paper_events"][0]["exit_reason"] == "TAKE_PROFIT"
        assert exited["paper"]["portfolio"]["realized_pnl"] == 31.90
        assert exited["daily_green_lock"]["portfolio"]["realized_pnl"] == 31.90
        assert exited["daily_green_lock"]["portfolio"]["day"]["green_lock_active"] is True
    metrics = json.loads((tmp_path / "state/evaluation/METRICS.json").read_text())
    assert metrics["day_control"]["closed_trades"] == 1
    assert metrics["daily_green_lock"]["closed_trades"] == int(action == "BUY")
    assert metrics["cost_coverage"] == "AI_DATA_COSTS_NOT_RECORDED"
    assert metrics["matched_day_comparison"]["completed_pairs"] == 1
    assert metrics["matched_day_comparison"]["model_net_pnl"] == (31.9 if action == "BUY" else 0)
    assert metrics["matched_day_comparison"]["control_net_pnl"] == 31.9


def test_daily_budget_caps_premium_and_reserves_other_positions(production):
    account = {
        "account_value": 369.0,
        "account_value_start_of_day": 369.0,
        "daily_pnl": 0.0,
        "buying_power": 369.0,
        "open_premium_at_risk": 0.0,
        "open_position_count": 0,
        "new_positions_today": 0,
    }
    assert planned_entry_budget(account, production)["premium_ceiling"] == 171.6
    risk_candidate = {
        "symbol": "SPY",
        "premium_at_risk": 171.6,
        "quantity": 1,
        "holds_through_earnings": False,
        "is_averaging_down": False,
        "protective_stop_planned": True,
    }
    assert evaluate_risk(account, risk_candidate, production).status == "ALLOWED"
    rejected = evaluate_risk(account, {**risk_candidate, "premium_at_risk": 250}, production)
    assert "planned_stop_loss_exceeds_remaining_daily_budget" in rejected.reasons
    lower = {**account, "daily_pnl": -10, "open_stop_risk": 15}
    assert planned_entry_budget(lower, production)["premium_ceiling"] == 71.6
    assert (
        planned_entry_budget({**account, "daily_pnl": 100}, production)["premium_ceiling"] == 171.6
    )


def test_short_expiries_and_swing_window_have_bounded_coverage():
    values = {"2026-09-08", "2026-09-09", "2026-09-10", "2026-09-11", "2026-09-18"}
    assert select_expirations(values, maximum=3, swing_minimum=date(2026, 9, 11)) == [
        "2026-09-08",
        "2026-09-09",
        "2026-09-11",
    ]


def test_watchlist_normalization_removes_day_after_cutoff(production):
    raw = {
        "wake_luna": True,
        "qualified_candidates": [
            {**candidate(), "eligible_trade_styles": ["DAY"]},
            {**candidate(symbol="QQQ"), "eligible_trade_styles": ["DAY", "SWING"]},
        ],
    }
    late = datetime(2026, 9, 4, 19, 40, tzinfo=UTC)
    result = cycle._merge_option_discoveries({}, raw, config=production, now=late)
    assert result["qualified_candidates"] == []
    legacy = TradingConfig({**production.values, "DAY_ONLY_OPTIONS": False})
    result = cycle._merge_option_discoveries({}, raw, config=legacy, now=late)
    assert len(result["qualified_candidates"]) == 1
    assert result["qualified_candidates"][0]["symbol"] == "QQQ"
    assert result["qualified_candidates"][0]["entry_eligible_trade_styles"] == ["SWING"]
    raw["qualified_candidates"] = raw["qualified_candidates"][:1]
    result = cycle._merge_option_discoveries({}, raw, config=production, now=late)
    assert result["status"] == "ZERO_QUALIFIED"
    assert not result["wake_luna"]


def test_scheduler_can_scan_other_ticker_with_paper_position(tmp_path, monkeypatch, production):
    config = TradingConfig({**production.values, "PAPER_BASELINE_ENABLED": False})
    path, events = tmp_path / "state/paper/PORTFOLIO.json", tmp_path / "state/paper/EVENTS.jsonl"
    open_paper_position(
        decision(), candidate(), config, portfolio_path=path, event_log_path=events, now=NOW
    )
    called = []

    async def watchlist(*args, **kwargs):
        called.append(kwargs["premium_ceiling"])
        return {"status": "ZERO_QUALIFIED", "qualified_candidates": []}

    monkeypatch.setattr(cycle, "load_config", lambda _: config)
    monkeypatch.setattr(
        cycle,
        "run_live_monitor",
        lambda _: asyncio.sleep(0, result={"status": "QUIET", "wake_codex": False, "triggers": []}),
    )
    monkeypatch.setattr(runner, "fetch_quote_refresh", lambda _: asyncio.sleep(0, result=quote()))
    monkeypatch.setattr(cycle, "collect_market_intelligence", lambda *a, **kw: {"status": "QUIET"})
    monkeypatch.setattr(cycle, "run_watchlist_option_discovery", watchlist)
    result = asyncio.run(
        cycle.run_cycle(
            "opportunities",
            project_root=tmp_path,
            execute_models=False,
            notifications=False,
            now=NOW,
        )
    )
    assert len(called) == 1
    assert called[0] == 53.2  # Remaining budget after the first position and all estimated costs.
    assert result["paper"]["portfolio"]["open_positions"] == 1


@pytest.mark.parametrize("bad", ["wide", "stale", "missing_volume"])
def test_final_paper_refresh_rejects_bad_quotes(tmp_path, production, bad):
    refresh = quote()
    values = refresh["option_quotes"][0]["quote"]
    if bad == "wide":
        values.update(bid_price="1.00", ask_price="1.50")
    elif bad == "stale":
        values["updated_at"] = (NOW - timedelta(minutes=10)).isoformat()
    else:
        values.pop("volume")
    result = asyncio.run(
        runner.apply_paper_decision(
            {"decision": {"status": "COMPLETED", "output": json.dumps(decision())}},
            {"option_discovery": {"qualified_candidates": [candidate()]}},
            production,
            project_root=tmp_path,
            now=NOW,
            quote_fetcher=lambda _: asyncio.sleep(0, result=refresh),
        )
    )
    assert result["status"] == "BLOCKED"
    assert not result["opened"]
    assert not (tmp_path / "state/paper/PORTFOLIO.json").exists()


@pytest.mark.parametrize("value", [-1, None, True, float("nan")])
def test_cost_estimates_fail_closed(production, value):
    config = TradingConfig({**production.values, "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS": value})
    assert "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS" in config.paper_blockers()


def test_discovery_prices_and_directional_coverage(production):
    async def research(_):
        instruments, quotes = [], []
        for number, (kind, ask) in enumerate(
            [("call", 1.10), ("call", 1.11), ("put", 1.10), ("call", 2.50), ("put", 0.40)]
        ):
            identifier = f"fixture-{number}"
            instruments.append(
                {
                    "id": identifier,
                    "chain_symbol": "SPY",
                    "type": kind,
                    "strike_price": "500",
                    "expiration_date": "2026-09-08",
                }
            )
            values = quote(ask=ask, bid=ask - 0.02)["option_quotes"][0]["quote"]
            values.update(instrument_id=identifier, delta=0.5 if kind == "call" else -0.5)
            quotes.append({"quote": values})
        return {
            "as_of": NOW.isoformat(),
            "instruments": instruments,
            "option_quotes": quotes,
            "equity_quotes": [{"symbol": "SPY", "last_trade_price": "500"}],
            "equity_fundamentals": [{"symbol": "SPY", "average_volume_30_days": 20000000}],
        }

    result = asyncio.run(
        run_symbol_option_discovery(
            ["SPY"],
            production,
            discovery_source="TEST",
            now=NOW,
            premium_ceiling=171.6,
            research_fetcher=research,
        )
    )
    assert result["funnel"]["tradability_passed"] == 5
    assert result["funnel"]["premium_rejected"] == 2
    assert result["funnel"]["premium_passed"] == 3
    assert {item["option_type"] for item in result["qualified_candidates"]} == {"CALL", "PUT"}


def test_holidays_and_early_close_are_shared(production):
    assert market_window(datetime(2026, 9, 7, 11, tzinfo=ET)) == (False, "market_holiday")
    early = datetime(2026, 11, 27, 12, 30, tzinfo=ET)
    assert entry_allowed(early, production, "DAY")
    assert not entry_allowed(early + timedelta(seconds=1), production, "DAY")
    assert not entry_allowed(early + timedelta(minutes=10), production, "SWING")
    legacy = TradingConfig({**production.values, "DAY_ONLY_OPTIONS": False})
    assert entry_allowed(early + timedelta(minutes=10), legacy, "SWING")
    assert day_deadline(early, 15) == "2026-11-27T17:45:00+00:00"
    assert session_hours(date(2026, 12, 24))[1].astimezone(ET).hour == 13
    assert session_hours(date(2026, 7, 3)) is None


def test_overnight_daily_pnl_and_two_distinct_positions(tmp_path, production):
    # Isolate historical accounting from the new 1:1 admission policy. This fixture's
    # second $50 contract deliberately cannot qualify under the production threshold.
    production = TradingConfig({**production.values, "MIN_NET_REWARD_TO_RISK": 0.8})
    first = open_paper_position(
        decision(),
        candidate(),
        production,
        portfolio_path=tmp_path / "PORTFOLIO.json",
        event_log_path=tmp_path / "EVENTS.jsonl",
        now=NOW,
    )
    second = open_paper_position(
        decision(symbol="QQQ"),
        candidate(symbol="QQQ", bid=0.49, ask=0.50),
        production,
        portfolio_path=tmp_path / "PORTFOLIO.json",
        event_log_path=tmp_path / "EVENTS.jsonl",
        now=NOW,
    )
    assert first["opened"] and second["opened"]
    assert second["portfolio"]["open_positions"] == 2
    repeated = open_paper_position(
        decision(symbol="QQQ"),
        candidate(symbol="QQQ", bid=0.49, ask=0.50),
        production,
        portfolio_path=tmp_path / "PORTFOLIO.json",
        event_log_path=tmp_path / "EVENTS.jsonl",
        now=NOW,
    )
    assert repeated["reasons"] == ["underlying_already_held"]


def test_overnight_marks_do_not_double_count_yesterday_loss(tmp_path, resolved_config):
    start = datetime(2026, 8, 24, 15, tzinfo=UTC)
    path, events = tmp_path / "PORTFOLIO.json", tmp_path / "EVENTS.jsonl"
    order = {**decision(), "trade_style": "SWING", "hold_deadline": "2026-09-01T19:00:00+00:00"}
    contract = {**candidate(start), "dte": 14}
    entry = open_paper_position(
        order, contract, resolved_config, portfolio_path=path, event_log_path=events, now=start
    )
    assert entry["opened"]
    manage_paper_positions(
        quote(start + timedelta(hours=4), bid=0.90, ask=0.92),
        resolved_config,
        portfolio_path=path,
        event_log_path=events,
        now=start + timedelta(hours=4),
    )
    tomorrow = start + timedelta(days=1)
    state = ensure_paper_portfolio(
        resolved_config, portfolio_path=path, event_log_path=events, now=tomorrow
    )
    assert paper_account_metrics(state)["daily_pnl"] == 0
    mark = manage_paper_positions(
        quote(tomorrow, bid=0.95, ask=0.97),
        resolved_config,
        portfolio_path=path,
        event_log_path=events,
        now=tomorrow,
    )
    assert mark["portfolio"]["daily_pnl"] == 5
    closed = close_paper_position(
        entry["position"]["paper_id"],
        bid=1.0,
        quote_updated_at=tomorrow.isoformat(),
        reason="FIXTURE",
        config=resolved_config,
        portfolio_path=path,
        event_log_path=events,
        now=tomorrow,
    )
    assert closed["portfolio"]["daily_pnl"] == 10
    assert closed["position"]["realized_pnl"] == -10
