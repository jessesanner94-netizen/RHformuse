from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest

import tools.scheduled_cycle as scheduled_cycle
from tools.config import TradingConfig
from tools.decision_context import (
    _pass_recheck_state,
    build_decision_packet,
    cache_decision,
    cached_decision_blocks,
    fetch_uw_summary,
    model_call_budget_status,
    reserve_model_call,
)

NOW = datetime(2026, 8, 26, 15, 0, tzinfo=UTC)


def _held_event():
    event = _event()
    event["paper_portfolio"]["open_positions"] = [
        {
            "symbol": " purr ",
            "quantity": 1,
            "entry_cost": 120,
            "last_bid": 1.2,
            "stop_price": 0.9,
        }
    ]
    event["paper_portfolio"]["portfolio"].update(
        {
            "open_positions": 1,
            "open_premium_at_risk": 120,
            "new_positions_today": 1,
        }
    )
    return event


def _unexpected_research(*args, **kwargs):
    raise AssertionError("held tickers must be excluded before research or model calls")


@pytest.mark.parametrize(
    ("kind", "strike", "expiry"),
    [
        ("CALL", 15, "2026-09-18"),
        ("CALL", 20, "2026-10-02"),
        ("PUT", 10, "2026-09-04"),
    ],
)
def test_entire_held_ticker_chain_is_excluded_before_research(
    tmp_path, resolved_config, kind, strike, expiry
):
    event = _held_event()
    event["option_discovery"]["qualified_candidates"] = [
        {
            **_candidate(),
            "symbol": "PURR",
            "option_type": kind,
            "strike": strike,
            "expiration": expiry,
        }
    ]
    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=_unexpected_research,
            uw_fetcher=_unexpected_research,
        )
    )
    assert result["status"] == "NO_ALIGNED_CANDIDATE"
    assert result["candidates_evaluated"] == 0
    assert result["python_rejections"][0]["gate"]["reasons"] == ["underlying_already_held"]


def test_held_ticker_advances_to_other_symbol_and_releases_after_close(tmp_path, resolved_config):
    event = _held_event()
    event["option_discovery"]["qualified_candidates"].insert(
        0,
        {
            **_candidate(),
            "candidate_id": "held-purr",
            "symbol": "PURR",
            "option_volume": 100000,
        },
    )

    def technical(symbol, *, project_root):
        assert symbol == "SPY"
        return _technical(symbol, project_root=project_root)

    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            uw_fetcher=lambda *_: {"status": "OK", "supports_contract_direction": True},
        )
    )
    assert result["status"] == "READY"
    assert result["packet"]["candidate"]["symbol"] == "SPY"
    assert result["candidates_evaluated"] == 1
    assert result["python_rejections"][0]["symbol"] == "PURR"
    event["paper_portfolio"]["open_positions"] = []
    event["paper_portfolio"]["portfolio"]["open_positions"] = 0
    event["option_discovery"]["qualified_candidates"] = [
        event["option_discovery"]["qualified_candidates"][0]
    ]
    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=lambda symbol, **kw: _technical("SPY", **kw),
            uw_fetcher=lambda *_: {"status": "OK", "supports_contract_direction": True},
        )
    )
    assert result["status"] == "READY"
    assert result["packet"]["candidate"]["symbol"] == "PURR"


def test_repeated_held_only_cycles_never_reserve_calls(tmp_path, resolved_config, monkeypatch):
    event = _held_event()
    event["option_discovery"]["qualified_candidates"] = [{**_candidate(), "symbol": "PURR"}]

    async def packet(*args, **kwargs):
        return await build_decision_packet(
            *args, **kwargs, technical_fetcher=_unexpected_research, uw_fetcher=_unexpected_research
        )

    monkeypatch.setattr(scheduled_cycle, "build_decision_packet", packet)
    monkeypatch.setattr(scheduled_cycle, "reserve_model_call", _unexpected_research)
    monkeypatch.setattr(scheduled_cycle, "run_trigger", _unexpected_research)
    for _ in range(3):
        result = asyncio.run(
            scheduled_cycle._route_compact_decision(
                event, config=resolved_config, project_root=tmp_path, now=NOW, execute_models=True
            )
        )
        assert result["decision"]["codex_invoked"] is False
        assert result["decision"]["status"] == "SKIPPED"
    assert not (tmp_path / "state" / "runtime" / "model_budget.json").exists()


@pytest.mark.parametrize("cached", [False, True])
def test_final_fence_blocks_held_ticker_even_if_packet_builder_misses_it(
    tmp_path, resolved_config, monkeypatch, cached
):
    event = _held_event()

    async def bad_packet(*args, **kwargs):
        return {
            "status": "READY",
            "packet": {},
            "packet_signature": "fixture",
            "selected_candidates": [{"candidate_id": "other-contract", "symbol": "PURR"}],
        }

    monkeypatch.setattr(scheduled_cycle, "build_decision_packet", bad_packet)
    monkeypatch.setattr(
        scheduled_cycle,
        "cached_decision_blocks",
        lambda *a, **kw: {
            "blocked": cached,
            "reason": "valid_buy_cached" if cached else "not_cached",
            "decision": {"action": "BUY"},
        },
    )
    monkeypatch.setattr(scheduled_cycle, "reserve_model_call", _unexpected_research)
    monkeypatch.setattr(scheduled_cycle, "run_trigger", _unexpected_research)
    result = asyncio.run(
        scheduled_cycle._route_compact_decision(
            event, config=resolved_config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert result["decision"]["reason"] == "underlying_already_held"
    assert result["decision"]["codex_invoked"] is False
    assert "decision_verdict" not in result


@pytest.mark.parametrize("positions", [None, [], [{}]])
def test_unknown_held_ticker_state_fails_closed(tmp_path, resolved_config, positions):
    event = _held_event()
    event["paper_portfolio"]["open_positions"] = positions
    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=_unexpected_research,
            uw_fetcher=_unexpected_research,
        )
    )
    assert result["status"] == "INSUFFICIENT_DATA"
    assert result["candidates_evaluated"] == 0


def _candidate() -> dict[str, object]:
    return {
        "candidate_id": "compact-contract",
        "symbol": "SPY",
        "option_symbol": "SPY260918C00500000",
        "expiration": "2026-09-18",
        "strike": 500.0,
        "option_type": "CALL",
        "dte": 23,
        "underlying_price": 500.0,
        "bid": 1.0,
        "ask": 1.1,
        "chance_of_profit_long": 0.20,
        "option_volume": 5000,
        "option_open_interest": 10000,
        "quote_is_fresh": True,
        "quote_updated_at": NOW.isoformat(),
        "implied_volatility": 0.25,
        "delta": 0.5,
        "gamma": 0.002,
        "theta": -0.02,
        "vega": 0.1,
        "rho": 0.02,
        "greek_metrics": {
            "abs_delta": 0.5,
            "gamma_delta_per_1_percent_move": 0.01,
            "theta_percent_of_premium_per_day": 1.9,
        },
        "entry_eligible_trade_styles": ["DAY", "SWING"],
        "discovery_source": "ROBINHOOD_DAILY_MOVERS",
        "discovery_context": {"change_percent": 2.5, "relative_volume": 1.8},
    }


def _event() -> dict[str, object]:
    return {
        "option_discovery": {"qualified_candidates": [_candidate()]},
        "paper_portfolio": {
            "status": "QUIET",
            "open_positions": [],
            "portfolio": {
                "starting_cash": 10_000,
                "cash": 10_000,
                "equity": 10_000,
                "unrealized_pnl": 0,
                "open_premium_at_risk": 0,
                "open_positions": 0,
                "day": {
                    "start_equity": 10_000,
                    "realized_pnl": 0,
                    "new_positions": 0,
                },
            },
        },
        "live_portfolio": {
            "status": "QUIET",
            "portfolio": {
                "account_value": 10_000,
                "account_value_start_of_day": 10_000,
                "buying_power": 5_000,
                "daily_pnl": 0,
                "open_premium_at_risk": 0,
                "open_position_count": 0,
                "new_positions_today": 0,
            },
        },
        "live_position_preflight": {"status": "QUIET"},
        "market_intelligence": {
            "news": {
                "new_items": [
                    {
                        "title": "SPY rallies after strong data",
                        "source": "Fixture",
                        "published": NOW.isoformat(),
                        "link": "https://example.test/this-must-not-reach-luna",
                    }
                ]
            },
            "social": {
                "results": [
                    {
                        "channel": "reddit",
                        "output": "SPY bullish breakout\n" + "irrelevant full post " * 5000,
                    }
                ]
            },
        },
        "entry_windows": {"DAY": True, "SWING": True},
    }


def _technical(symbol: str, *, project_root: Path) -> dict[str, object]:
    assert symbol == "SPY"
    return {
        "status": "OK",
        "timeframes": {
            "1D": {"status": "OK", "trend": "BULLISH", "trend_score": 3},
            "4H": {"status": "OK", "trend": "BULLISH", "trend_score": 4},
            "15M": {"status": "OK", "trend": "BULLISH", "trend_score": 3},
            "5M": {"status": "OK", "trend": "NEUTRAL", "trend_score": 0},
        },
        "style_scores": {"DAY": 7, "SWING": 17},
        "instrument_type": "ETF",
        "headlines": [{"title": "SPY upgrade", "source": "Fixture", "published": "now"}],
        "earnings": {"status": "NOT_APPLICABLE", "next_date": None},
    }


def test_packet_is_small_and_contains_no_raw_social_or_urls(
    tmp_path: Path, resolved_config
) -> None:
    result = asyncio.run(
        build_decision_packet(
            _event(),
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=_technical,
            uw_fetcher=lambda symbol, option_type: {
                "status": "OK",
                "label": "BULLISH",
                "supports_contract_direction": True,
            },
        )
    )

    assert result["status"] == "READY"
    packet = result["packet"]
    assert packet["candidate"]["python_preferred_style"] == "SWING"
    assert packet["candidate"]["underlying_instrument_type"] == "ETF"
    assert packet["python_gate"]["status"] == "QUALIFIED"
    assert packet["python_gate"]["directional_alignment_score"] == 17
    assert "chance_of_profit_long" not in packet["candidate"]
    assert "analytics" not in packet["risk"]
    assert packet["packet_characters"] < 18_000
    rendered = str(packet)
    assert "irrelevant full post" not in rendered
    assert "https://" not in rendered
    assert packet["social"]["label"] == "BULLISH"


def test_paper_packet_keeps_essential_data_without_calling_disabled_uw(
    tmp_path: Path, resolved_config
) -> None:
    event = _event()
    candidate = event["option_discovery"]["qualified_candidates"][0]
    candidate.update(
        {
            "underlying_average_volume_30d": 82_000_000,
            "underlying_avg_daily_dollar_volume": 1_000_000_000,
            "discovery_context": {
                "current_volume": 41_000_000,
                "relative_volume": 1.35,
            },
        }
    )
    paper_config = TradingConfig({**resolved_config.values, "UW_ENABLED": False})

    def technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        snapshot = _technical(symbol, project_root=project_root)
        snapshot["timeframes"]["15M"].update(
            {"rsi_14": 58.2, "macd_histogram": 0.14, "relative_volume_20": 1.4}
        )
        return snapshot

    def unexpected_uw(*_args, **_kwargs):
        raise AssertionError("UW must not be called when disabled")

    result = asyncio.run(
        build_decision_packet(
            event,
            paper_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            uw_fetcher=unexpected_uw,
        )
    )

    assert result["status"] == "READY"
    packet = result["packet"]
    assert packet["mode"] == "PAPER"
    assert packet["unusual_whales"] == {"status": "DISABLED", "reason": "uw_disabled"}
    assert packet["candidate"]["underlying_liquidity"] == {
        "average_volume_30d": 82_000_000,
        "average_daily_dollar_volume": 1_000_000_000,
        "session_volume": 41_000_000,
        "relative_volume": 1.35,
    }
    assert packet["candidate"]["greeks"]["delta"] == 0.5
    assert packet["candidate"]["volume"] == 5000
    assert packet["technical"]["timeframes"]["15M"]["rsi_14"] == 58.2
    assert packet["technical"]["timeframes"]["15M"]["macd_histogram"] == 0.14


def test_python_rejects_directional_conflict_after_checking_flow_and_advances(
    tmp_path: Path, resolved_config
) -> None:
    bad_put = {
        **_candidate(),
        "candidate_id": "bad-put",
        "symbol": "BAD",
        "option_symbol": "BAD260918P00500000",
        "option_type": "PUT",
        "bid": 0.99,
        "ask": 1.0,
        "option_volume": 100_000,
        "option_open_interest": 100_000,
        "discovery_context": {"change_percent": 0.0, "relative_volume": 3.0},
    }
    good_call = {
        **_candidate(),
        "candidate_id": "good-call",
        "symbol": "GOOD",
        "option_symbol": "GOOD260918C00500000",
        "discovery_context": {"change_percent": 0.0, "relative_volume": 1.0},
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [bad_put, good_call]}
    uw_calls: list[tuple[str, str]] = []

    def technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical("SPY", project_root=project_root)
        return {**result, "symbol": symbol}

    def uw(symbol: str, option_type: str) -> dict[str, object]:
        uw_calls.append((symbol, option_type))
        return {
            "status": "OK",
            "label": "BULLISH",
            "supports_contract_direction": option_type == "CALL",
        }

    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            uw_fetcher=uw,
        )
    )

    assert result["status"] == "READY"
    assert result["packet"]["candidate"]["candidate_id"] == "good-call"
    assert result["python_rejections"][0]["candidate_id"] == "bad-put"
    assert result["python_rejections"][0]["gate"]["reasons"] == [
        "preferred_style_technical_direction_not_supportive",
        "available_uw_flow_opposes_contract_direction",
        "countertrend_day_requires_5m_15m_confirmation",
        "countertrend_day_requires_fresh_level_confirmation",
    ]
    assert uw_calls == [("BAD", "PUT"), ("GOOD", "CALL")]


def test_strong_flow_and_nonopposing_intraday_structure_can_reach_luna(
    tmp_path: Path, resolved_config
) -> None:
    candidate = {
        **_candidate(),
        "dte": 2,
        "entry_eligible_trade_styles": ["DAY"],
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [candidate]}

    def flow_led_technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical(symbol, project_root=project_root)
        return {
            **result,
            "style_scores": {"DAY": -8, "SWING": -14},
            "intraday_structure": {"status": "OK", "bias": "NEUTRAL", "bias_score": 0},
        }

    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=flow_led_technical,
            uw_fetcher=lambda symbol, option_type: {
                "status": "OK",
                "label": "STRONG_BULLISH",
                "supports_contract_direction": True,
            },
        )
    )

    gate = result["packet"]["python_gate"]
    assert result["status"] == "READY"
    assert gate["setup_mode"] == "FLOW_LED_REVERSAL"
    assert gate["directional_alignment_score"] == -8
    assert gate["intraday_directional_structure_score"] == 0


def test_old_countertrend_signal_skips_model_and_cached_buy(tmp_path, resolved_config, monkeypatch):
    event = _event()
    event["option_discovery"]["qualified_candidates"] = [
        {
            **_candidate(),
            "option_type": "PUT",
            "delta": -0.5,
            "entry_eligible_trade_styles": ["DAY"],
        }
    ]

    def technical(symbol, *, project_root):
        result = _technical(symbol, project_root=project_root)
        result["style_scores"]["DAY"] = -9
        result["timeframes"]["5M"]["trend"] = "BEARISH"
        result["timeframes"]["15M"]["trend"] = "NEUTRAL"
        result["intraday_structure"] = {
            "status": "OK",
            "bias_score": -1,
            "swept_and_rejected_opening_range_high": True,
        }
        return result

    async def packet(*args, **kwargs):
        return await build_decision_packet(
            *args,
            **kwargs,
            technical_fetcher=technical,
            uw_fetcher=lambda *_: {
                "status": "OK",
                "label": "STRONG_BEARISH",
                "supports_contract_direction": True,
            },
        )

    def forbidden(*args, **kwargs):
        raise AssertionError("unconfirmed countertrend must not reach model, budget, or cached BUY")

    monkeypatch.setattr(scheduled_cycle, "build_decision_packet", packet)
    monkeypatch.setattr(scheduled_cycle, "reserve_model_call", forbidden)
    monkeypatch.setattr(scheduled_cycle, "run_trigger", forbidden)
    monkeypatch.setattr(scheduled_cycle, "cached_decision_blocks", forbidden)
    result = asyncio.run(
        scheduled_cycle._route_compact_decision(
            event,
            config=resolved_config,
            project_root=tmp_path,
            now=NOW,
            execute_models=True,
        )
    )
    assert result["decision"]["codex_invoked"] is False
    assert result["decision"]["status"] == "SKIPPED"
    assert not (tmp_path / "state" / "runtime" / "model_budget.json").exists()


def test_weak_flow_cannot_override_a_technical_conflict(tmp_path: Path, resolved_config) -> None:
    candidate = {
        **_candidate(),
        "dte": 2,
        "entry_eligible_trade_styles": ["DAY"],
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [candidate]}

    def conflicted_technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical(symbol, project_root=project_root)
        return {
            **result,
            "style_scores": {"DAY": -3, "SWING": -8},
            "intraday_structure": {"status": "OK", "bias": "NEUTRAL", "bias_score": 0},
        }

    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=conflicted_technical,
            uw_fetcher=lambda symbol, option_type: {
                "status": "OK",
                "label": "BULLISH",
                "supports_contract_direction": True,
            },
        )
    )

    assert result["status"] == "NO_ALIGNED_CANDIDATE"
    assert result["python_rejections"][0]["gate"]["reasons"] == [
        "preferred_style_technical_direction_not_supportive"
    ]


def test_uw_summary_uses_direction_tags_not_call_minus_put_premium() -> None:
    class FakeClient:
        def options_volume(self, symbol: str):
            return SimpleNamespace(payload=[{"call_volume": 1_000, "put_volume": 2_000}])

        def ticker_flow(self, symbol: str):
            return SimpleNamespace(
                payload=[
                    {"option_type": "put", "premium": "9000", "tags": ["bid_side", "bullish"]},
                    {"option_type": "call", "premium": "1000", "tags": ["ask_side", "bullish"]},
                    {"option_type": "call", "premium": "1000", "tags": ["bid_side", "bearish"]},
                ]
            )

    result = fetch_uw_summary("SPY", "CALL", client_factory=FakeClient)

    assert result["label"] == "STRONG_BULLISH"
    assert result["supports_contract_direction"] is True
    assert result["bullish_premium"] == 10_000
    assert result["bearish_premium"] == 1_000


def test_bearish_raw_score_is_positive_directional_alignment_for_put(
    tmp_path: Path, resolved_config
) -> None:
    put = {
        **_candidate(),
        "candidate_id": "aligned-put",
        "option_symbol": "SPY260918P00500000",
        "option_type": "PUT",
        "delta": -0.5,
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [put]}

    def bearish_technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical(symbol, project_root=project_root)
        return {**result, "style_scores": {"DAY": -7, "SWING": -17}}

    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=bearish_technical,
            uw_fetcher=lambda symbol, option_type: {
                "status": "OK",
                "label": "BEARISH",
                "supports_contract_direction": True,
            },
        )
    )

    gate = result["packet"]["python_gate"]
    assert result["status"] == "READY"
    assert gate["raw_style_score"] == -17
    assert gate["directional_alignment_score"] == 17
    assert gate["technical_direction_supported"] is True


def test_day_only_accepts_bearish_intraday_setup_despite_bullish_daily_context(
    tmp_path: Path, resolved_config
) -> None:
    config = TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True})
    candidate = {
        **_candidate(),
        "option_type": "PUT",
        "delta": -0.5,
        "entry_eligible_trade_styles": ["DAY", "SWING"],
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [candidate]}

    def technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical(symbol, project_root=project_root)
        result["timeframes"]["5M"]["trend"] = "BEARISH"
        result["timeframes"]["15M"]["trend"] = "BEARISH"
        result["style_scores"] = {"DAY": -7, "SWING": 17}
        result["intraday_structure"] = {
            "status": "OK",
            "bias": "BEARISH",
            "bias_score": -2,
        }
        return result

    result = asyncio.run(
        build_decision_packet(
            event,
            config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            uw_fetcher=lambda *_: {
                "status": "OK",
                "label": "STRONG_BEARISH",
                "supports_contract_direction": True,
            },
        )
    )

    assert result["status"] == "READY"
    packet = result["packet"]
    assert packet["candidate"]["python_preferred_style"] == "DAY"
    assert packet["python_gate"]["directional_alignment_score"] == 7
    assert packet["python_gate"]["countertrend_entry_timing"] == {
        "required": False,
        "reasons": [],
        "policy": "intraday_day_only",
    }
    assert packet["trading_policy"] == {
        "day_only_options": True,
        "technical_horizon": "INTRADAY",
    }


def test_day_only_still_rejects_opposing_intraday_direction(
    tmp_path: Path, resolved_config
) -> None:
    config = TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True})
    candidate = {
        **_candidate(),
        "option_type": "PUT",
        "delta": -0.5,
        "entry_eligible_trade_styles": ["DAY"],
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [candidate]}

    def technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical(symbol, project_root=project_root)
        result["style_scores"] = {"DAY": 7, "SWING": 17}
        result["intraday_structure"] = {
            "status": "OK",
            "bias": "BULLISH",
            "bias_score": 2,
        }
        return result

    result = asyncio.run(
        build_decision_packet(
            event,
            config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            uw_fetcher=lambda *_: {
                "status": "OK",
                "label": "STRONG_BEARISH",
                "supports_contract_direction": True,
            },
        )
    )

    assert result["status"] == "NO_ALIGNED_CANDIDATE"
    gate = result["python_rejections"][0]["gate"]
    assert gate["reasons"] == ["preferred_style_technical_direction_not_supportive"]
    assert gate["countertrend_entry_timing"]["policy"] == "intraday_day_only"


def test_day_only_policy_changes_packet_signature(tmp_path: Path, resolved_config) -> None:
    event = _event()
    event["option_discovery"]["qualified_candidates"][0][
        "entry_eligible_trade_styles"
    ] = ["DAY"]
    kwargs = {
        "project_root": tmp_path,
        "now": NOW,
        "technical_fetcher": _technical,
        "uw_fetcher": lambda *_: {
            "status": "OK",
            "label": "STRONG_BULLISH",
            "supports_contract_direction": True,
        },
    }
    legacy = asyncio.run(build_decision_packet(event, resolved_config, **kwargs))
    day_only = asyncio.run(
        build_decision_packet(
            event,
            TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True}),
            **kwargs,
        )
    )

    assert legacy["status"] == day_only["status"] == "READY"
    assert legacy["packet_signature"] != day_only["packet_signature"]
    assert legacy["packet"]["trading_policy"]["day_only_options"] is False
    assert day_only["packet"]["trading_policy"]["day_only_options"] is True


def test_day_only_pass_recheck_ignores_broader_frames() -> None:
    packet = {
        "trading_policy": {"day_only_options": True},
        "technical": {
            "timeframes": {
                "1D": {"trend": "BULLISH"},
                "4H": {"trend": "BULLISH"},
                "15M": {"trend": "BEARISH"},
                "5M": {"trend": "BEARISH"},
            },
            "intraday_structure": {"bias": "BEARISH"},
        },
    }

    state = _pass_recheck_state(packet, {"option_type": "PUT"})

    assert state["day_only_options"] is True
    assert state["technical_supports_direction"] is True


def test_day_only_does_not_fall_back_to_swing_candidate(tmp_path: Path, resolved_config) -> None:
    event = _event()
    event["option_discovery"]["qualified_candidates"][0][
        "entry_eligible_trade_styles"
    ] = ["SWING"]

    result = asyncio.run(
        build_decision_packet(
            event,
            TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True}),
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=_technical,
            uw_fetcher=lambda *_: {
                "status": "OK",
                "label": "STRONG_BULLISH",
                "supports_contract_direction": True,
            },
        )
    )

    assert result["status"] == "NO_ALIGNED_CANDIDATE"
    assert result["python_rejections"][0]["gate"]["preferred_style"] == "NONE"


def test_uw_discovery_earnings_date_fills_worker_calendar_gap(
    tmp_path: Path, resolved_config
) -> None:
    candidate = {
        **_candidate(),
        "symbol": "SOFI",
        "uw_discovery": {"next_earnings_date": "2026-10-27"},
    }
    event = _event()
    event["option_discovery"] = {"qualified_candidates": [candidate]}

    def technical(symbol: str, *, project_root: Path) -> dict[str, object]:
        result = _technical("SPY", project_root=project_root)
        return {
            **result,
            "instrument_type": "EQUITY",
            "earnings": {"status": "UNAVAILABLE", "next_date": None},
        }

    result = asyncio.run(
        build_decision_packet(
            event,
            resolved_config,
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            uw_fetcher=lambda symbol, option_type: {
                "status": "OK",
                "label": "BULLISH",
                "supports_contract_direction": True,
            },
        )
    )

    assert result["status"] == "READY"
    assert result["packet"]["earnings_event"] == {
        "status": "AVAILABLE",
        "next_date": "2026-10-27",
        "source": "UW_DISCOVERY",
    }


def test_daily_budget_reserves_then_blocks(tmp_path: Path) -> None:
    path = tmp_path / "budget.json"
    first = reserve_model_call(path, maximum_calls=1, now=NOW, packet_signature="one")
    second = reserve_model_call(path, maximum_calls=1, now=NOW, packet_signature="two")

    assert first["status"] == "RESERVED"
    assert second["status"] == "BLOCKED"


def test_daily_budget_status_exhausts_then_resets_next_eastern_day(tmp_path: Path) -> None:
    path = tmp_path / "budget.json"
    reserve_model_call(path, maximum_calls=1, now=NOW, packet_signature="one")

    exhausted = model_call_budget_status(path, maximum_calls=1, now=NOW)
    tomorrow = model_call_budget_status(
        path,
        maximum_calls=1,
        now=NOW + timedelta(days=1),
    )

    assert exhausted["status"] == "EXHAUSTED"
    assert exhausted["calls_remaining"] == 0
    assert tomorrow["status"] == "AVAILABLE"
    assert tomorrow["calls_reserved"] == 0


def test_wait_cache_only_releases_after_exact_threshold(tmp_path: Path) -> None:
    path = tmp_path / "decision.json"
    candidate = _candidate()
    decision = {
        "action": "WAIT",
        "reconsider_above": 501.0,
        "reconsider_below": None,
        "decision_valid_until": (NOW + timedelta(hours=1)).isoformat(),
    }
    cache_decision(path, decision, packet_signature="same", candidate=candidate, now=NOW)

    blocked = cached_decision_blocks(
        path, packet_signature="same", candidate=candidate, now=NOW + timedelta(minutes=5)
    )
    crossed_candidate = {**candidate, "underlying_price": 501.1}
    released = cached_decision_blocks(
        path,
        packet_signature="same",
        candidate=crossed_candidate,
        now=NOW + timedelta(minutes=6),
    )

    assert blocked["blocked"] is True
    assert released["blocked"] is False
    assert released["reason"] == "wait_threshold_crossed"


def test_unchanged_valid_buy_is_cached_without_another_model_call(tmp_path: Path) -> None:
    path = tmp_path / "decision.json"
    candidate = _candidate()
    decision = {
        "action": "BUY",
        "candidate_id": candidate["candidate_id"],
        "decision_valid_until": (NOW + timedelta(minutes=30)).isoformat(),
    }
    cache_decision(path, decision, packet_signature="same", candidate=candidate, now=NOW)

    blocked = cached_decision_blocks(
        path,
        packet_signature="same",
        candidate=candidate,
        now=NOW + timedelta(minutes=10),
    )
    changed = cached_decision_blocks(
        path,
        packet_signature="changed",
        candidate=candidate,
        now=NOW + timedelta(minutes=10),
    )

    assert blocked["blocked"] is True
    assert blocked["reason"] == "valid_buy_cached"
    assert changed["blocked"] is False


def test_pass_cache_ignores_immaterial_packet_signature_changes(tmp_path: Path) -> None:
    path = tmp_path / "decision.json"
    candidate = _candidate()
    packet = {
        "technical": {
            "timeframes": {
                "1D": {"trend": "BULLISH"},
                "4H": {"trend": "BULLISH"},
                "15M": {"trend": "NEUTRAL"},
                "5M": {"trend": "NEUTRAL"},
            }
        },
        "unusual_whales": {
            "label": "STRONG_BULLISH",
            "supports_contract_direction": True,
        },
        "news": {"label": "NEUTRAL"},
        "social": {"label": "NEUTRAL"},
        "risk": {"status": "ALLOWED"},
        "earnings_event": {"status": "AVAILABLE", "next_date": None},
        "entry_windows": {"DAY": True, "SWING": True},
    }
    decision = {
        "action": "PASS",
        "candidate_id": candidate["candidate_id"],
        "decision_valid_until": (NOW + timedelta(hours=4)).isoformat(),
    }
    cache_decision(
        path,
        decision,
        packet_signature="old-signature",
        candidate=candidate,
        packet=packet,
        now=NOW,
    )
    changed_packet = {
        **packet,
        "technical": {
            "timeframes": {
                "1D": {"trend": "BULLISH"},
                "4H": {"trend": "BULLISH"},
                "15M": {"trend": "BULLISH"},
                "5M": {"trend": "NEUTRAL"},
            }
        },
    }

    blocked = cached_decision_blocks(
        path,
        packet_signature="new-signature",
        candidate={**candidate, "underlying_price": 501.25},
        packet=changed_packet,
        now=NOW + timedelta(minutes=10),
    )

    assert blocked["blocked"] is True
    assert blocked["reason"] == "material_pass_state_unchanged"


def test_pass_cache_releases_on_material_flow_flip(tmp_path: Path) -> None:
    path = tmp_path / "decision.json"
    candidate = _candidate()
    packet = {
        "technical": {"timeframes": {}},
        "unusual_whales": {
            "label": "STRONG_BEARISH",
            "supports_contract_direction": False,
        },
        "news": {"label": "NEUTRAL"},
        "social": {"label": "NEUTRAL"},
        "risk": {"status": "ALLOWED"},
        "earnings_event": {"status": "AVAILABLE", "next_date": None},
        "entry_windows": {"DAY": True, "SWING": True},
    }
    decision = {
        "action": "PASS",
        "candidate_id": candidate["candidate_id"],
        "decision_valid_until": (NOW + timedelta(hours=4)).isoformat(),
    }
    cache_decision(
        path,
        decision,
        packet_signature="old-signature",
        candidate=candidate,
        packet=packet,
        now=NOW,
    )
    flipped = {
        **packet,
        "unusual_whales": {
            "label": "STRONG_BULLISH",
            "supports_contract_direction": True,
        },
    }

    released = cached_decision_blocks(
        path,
        packet_signature="new-signature",
        candidate=candidate,
        packet=flipped,
        now=NOW + timedelta(minutes=10),
    )

    assert released["blocked"] is False
    assert released["reason"] == "material_pass_state_changed"
