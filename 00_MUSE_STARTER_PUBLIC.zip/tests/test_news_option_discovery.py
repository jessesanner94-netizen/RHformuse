import asyncio
from datetime import UTC, datetime, timedelta

from tools.news_option_discovery import run_news_option_discovery


def test_luna_news_symbol_resolves_to_liquid_contract(resolved_config) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    expiration = (now.date() + timedelta(days=14)).isoformat()

    async def research(requests):
        assert requests[0]["symbol"] == "NVDA"
        return {
            "status": "OK",
            "as_of": now.isoformat(),
            "instruments": [
                {
                    "id": "news-contract-1",
                    "chain_symbol": "NVDA",
                    "expiration_date": expiration,
                    "strike_price": "100.0000",
                    "type": "call",
                    "symbol": "NVDA-FIXTURE",
                }
            ],
            "option_quotes": [
                {
                    "quote": {
                        "instrument_id": "news-contract-1",
                        "bid_price": "1.00",
                        "ask_price": "1.05",
                        "volume": 1000,
                        "open_interest": 5000,
                        "delta": "0.50",
                        "gamma": "0.002",
                        "theta": "-0.02",
                        "vega": "0.10",
                        "rho": "0.02",
                        "updated_at": now.isoformat(),
                        "implied_volatility": "0.42",
                    }
                }
            ],
            "equity_quotes": [{"quote": {"symbol": "NVDA", "last_trade_price": "100"}}],
            "equity_fundamentals": [{"symbol": "NVDA", "average_volume_30_days": "10000000"}],
        }

    result = asyncio.run(
        run_news_option_discovery(["NVDA"], resolved_config, now=now, research_fetcher=research)
    )

    assert result["status"] == "QUALIFIED"
    assert result["qualified_candidates"][0]["candidate_id"] == "news-contract-1"
    assert result["qualified_candidates"][0]["discovery_source"] == "NEWS_AFTER_LUNA"


def test_invalid_luna_symbol_never_calls_robinhood(resolved_config) -> None:
    async def never_called(requests):
        raise AssertionError("research should not run")

    result = asyncio.run(
        run_news_option_discovery(["not a ticker"], resolved_config, research_fetcher=never_called)
    )

    assert result["status"] == "SKIPPED"


def test_pre_diversification_day_delta_audit_keeps_unselected_affordable_quote(
    resolved_config,
) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    expiration = (now.date() + timedelta(days=14)).isoformat()

    async def research(requests):
        assert requests[0]["symbol"] == "NVDA"
        return {
            "as_of": now.isoformat(),
            "instruments": [
                {
                    "id": contract_id,
                    "chain_symbol": "NVDA",
                    "expiration_date": expiration,
                    "strike_price": strike,
                    "type": "call",
                    "symbol": contract_id,
                }
                for contract_id, strike in (("low-delta", "101"), ("high-delta", "100"))
            ],
            "option_quotes": [
                {
                    "quote": {
                        "instrument_id": contract_id,
                        "bid_price": bid,
                        "ask_price": ask,
                        "volume": 1000,
                        "open_interest": 5000,
                        "delta": delta,
                        "gamma": "0.002",
                        "theta": "-0.02",
                        "vega": "0.10",
                        "rho": "0.02",
                        "updated_at": now.isoformat(),
                        "implied_volatility": "0.42",
                    }
                }
                for contract_id, bid, ask, delta in (
                    ("low-delta", "1.00", "1.04", "0.25"),
                    ("high-delta", "1.14", "1.20", "0.35"),
                )
            ],
            "equity_quotes": [{"quote": {"symbol": "NVDA", "last_trade_price": "100"}}],
            "equity_fundamentals": [
                {"symbol": "NVDA", "average_volume_30_days": "10000000"}
            ],
        }

    result = asyncio.run(
        run_news_option_discovery(["NVDA"], resolved_config, now=now, research_fetcher=research)
    )

    assert result["status"] == "QUALIFIED"
    assert [item["candidate_id"] for item in result["qualified_candidates"]] == ["low-delta"]
    assert result["day_delta_audit"] == [
        {
            "symbol": "NVDA",
            "option_type": "CALL",
            "eligible_count": 2,
            "max_abs_delta": 0.35,
            "highest_delta_quote": {
                "candidate_id": "high-delta",
                "option_symbol": "high-delta",
                "expiration": expiration,
                "strike": 100.0,
                "dte": 14,
                "bid": 1.14,
                "ask": 1.2,
                "delta": 0.35,
                "option_volume": 1000.0,
                "option_open_interest": 5000.0,
                "quote_updated_at": now.isoformat(),
            },
        }
    ]


def test_day_only_discovery_does_not_reserve_swing_expiration(resolved_config):
    from tools.config import TradingConfig

    config = TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True})
    async def research(requests):
        assert requests
        assert all("min_swing_expiration" not in row for row in requests)
        return {"status": "OK", "instruments": [], "option_quotes": []}
    asyncio.run(run_news_option_discovery(
        ["SPY"], config, now=datetime(2026, 9, 22, 15, tzinfo=UTC),
        research_fetcher=research,
    ))
