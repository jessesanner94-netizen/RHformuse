from copy import deepcopy
from datetime import UTC, datetime
from types import SimpleNamespace

from tools.config import TradingConfig
from tools.jev_store import JevStore
from tools.winner_advisory import record_checkpoint_advisories


def position_result():
    return {"open_positions": [{
        "paper_id": "paper-trial-a", "symbol": "SPY", "option_type": "PUT",
        "winner_management": {"enabled": True, "checkpoint_reached": True,
                              "last_evidence": {"status": "INTACT"}},
        "stop_price": 0.75, "last_bid": 1.3,
    }], "paper_events": []}


def test_negative_advisory_is_once_only_and_cannot_change_position(tmp_path):
    result = position_result()
    before = deepcopy(result)
    calls = []

    def evaluate(features, questions):
        calls.append(features)
        return SimpleNamespace(to_dict=lambda: {
            "status": "OK", "answers": {"continuation_support": {"noul": 0.0}}
        })

    client = SimpleNamespace(evaluate=evaluate)
    config = TradingConfig({"ENABLE_JEV": True, "LIVE_EXECUTION_ENABLED": False})
    now = datetime(2026, 9, 24, 15, tzinfo=UTC)
    first = record_checkpoint_advisories(result, config, project_root=tmp_path,
                                        now=now, client=client)
    second = record_checkpoint_advisories(result, config, project_root=tmp_path,
                                         now=now, client=client)
    assert len(calls) == 1
    assert first[0]["exit_authority"] is False
    assert first[0]["routing_effect"] is False
    assert second == []
    assert result == before


def test_failed_advisory_does_not_change_position_or_retry(tmp_path):
    result = position_result()
    before = deepcopy(result)

    def fail(*args):
        raise TimeoutError("private provider diagnostics")

    config = TradingConfig({"ENABLE_JEV": True, "LIVE_EXECUTION_ENABLED": False})
    first = record_checkpoint_advisories(result, config, project_root=tmp_path,
                                        client=SimpleNamespace(evaluate=fail))
    assert first[0]["evaluation"] == {"status": "ERROR", "error_code": "advisory_failed"}
    assert record_checkpoint_advisories(result, config, project_root=tmp_path) == []
    assert result == before


def test_no_checkpoint_no_advisory(tmp_path):
    result = position_result()
    result["open_positions"][0]["winner_management"]["checkpoint_reached"] = False
    config = TradingConfig({"ENABLE_JEV": True, "LIVE_EXECUTION_ENABLED": False})
    assert record_checkpoint_advisories(result, config, project_root=tmp_path) == []
    assert not (tmp_path / "state").exists()


def test_shared_request_ceiling_blocks_advisory_only(tmp_path):
    now = datetime(2026, 9, 24, 15, tzinfo=UTC)
    store = JevStore(tmp_path / "state" / "research" / "jev.sqlite3")
    assert store.reserve_requests("already-spent", now, attempts=1, per_minute=6, per_day=1)
    config = TradingConfig({"ENABLE_JEV": True, "LIVE_EXECUTION_ENABLED": False,
                            "JEV_MAX_CALLS_PER_DAY": 1})
    result = position_result()
    before = deepcopy(result)

    def no_call(*args):
        raise AssertionError("Budget exhausted")

    advisory = record_checkpoint_advisories(result, config, project_root=tmp_path,
                                           now=now, client=SimpleNamespace(evaluate=no_call))
    assert advisory[0]["evaluation"]["status"] == "RATE_LIMITED"
    assert result == before
    with store.connect() as db:
        # Continuation opinions must not contaminate entry-score averages or rankings.
        assert db.execute("SELECT COUNT(*) FROM observations").fetchone()[0] == 0


def test_multiple_winners_get_only_one_advisory_per_monitor(tmp_path):
    result = position_result()
    second = deepcopy(result["open_positions"][0])
    second["paper_id"] = "paper-trial-b"
    result["open_positions"].append(second)
    config = TradingConfig({"ENABLE_JEV": True, "LIVE_EXECUTION_ENABLED": False})
    client = SimpleNamespace(
        evaluate=lambda *args: SimpleNamespace(to_dict=lambda: {"status": "OK"})
    )
    one = record_checkpoint_advisories(result, config, project_root=tmp_path, client=client)
    two = record_checkpoint_advisories(result, config, project_root=tmp_path, client=client)
    assert len(one) == len(two) == 1
    assert one[0]["paper_id"] != two[0]["paper_id"]
