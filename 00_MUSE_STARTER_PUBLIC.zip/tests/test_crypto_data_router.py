import asyncio
from datetime import UTC, datetime, timedelta

import pytest

from tests.test_crypto_cycle import setup, snapshot
from tools import crypto_data_router as router
from tools.crypto_cycle import run_cycle
from tools.crypto_paper import CryptoPaperStore

NOW = datetime(2026, 9, 20, 15, 0, 15, tzinfo=UTC)


async def failed(**kwargs):
    raise ValueError("provider unavailable")


def test_small_future_quote_waits_without_rewriting_timestamp(monkeypatch):
    clock = [NOW]
    waits = []

    class Clock:
        @staticmethod
        def now(tz):
            return clock[0]

    async def sleep(seconds):
        waits.append(seconds)
        clock[0] += timedelta(seconds=seconds)

    monkeypatch.setattr(router, "datetime", Clock)
    monkeypatch.setattr(router.asyncio, "sleep", sleep)
    q = {**snapshot()["quote"], "updated_at": (NOW + timedelta(milliseconds=36)).isoformat()}
    assert asyncio.run(router.validated_quote(q)) == q
    assert waits == [pytest.approx(0.046)]
    from tools.crypto_paper import valid_quote

    valid_quote(q, clock[0])


@pytest.mark.parametrize("offset", [6, -61])
def test_invalid_quote_times_still_rejected(offset):
    q = {**snapshot()["quote"], "updated_at": (NOW + timedelta(seconds=offset)).isoformat()}
    with pytest.raises(ValueError):
        asyncio.run(router.validated_quote(q, NOW))


def test_robinhood_network_failure_allows_unpinned_fallback(monkeypatch):
    async def connection(**kwargs):
        raise ConnectionError("unavailable")

    async def public(**kwargs):
        return snapshot()["quote"]

    monkeypatch.setattr(router, "robinhood_quote", connection)
    monkeypatch.setattr(router.crypto_market_data, "fetch_quote", public)
    assert asyncio.run(router.fetch_quote(now=NOW))["venue"] == "COINBASE_EXCHANGE"
    with pytest.raises(ConnectionError):
        asyncio.run(router.fetch_quote(now=NOW, venue="ROBINHOOD_CRYPTO_V2"))


def test_invalid_robinhood_uses_labeled_coinbase(monkeypatch):
    async def public(**kwargs):
        return snapshot()["quote"]

    monkeypatch.setattr(router, "robinhood_quote", failed)
    monkeypatch.setattr(router.crypto_market_data, "fetch_quote", public)
    quote = asyncio.run(router.fetch_quote(now=NOW))
    assert quote["venue"] == "COINBASE_EXCHANGE" and quote["paper_price_fallback"]
    with pytest.raises(ValueError):
        asyncio.run(router.fetch_quote(now=NOW, venue="ROBINHOOD_CRYPTO_V2"))


def test_binance_fallback_does_not_mix_candles(monkeypatch):
    async def unavailable(**kwargs):
        return {"status": "UNAVAILABLE"}

    async def binance(**kwargs):
        return {**snapshot(), "venue": "BINANCE_US"}

    async def price(**kwargs):
        return {**snapshot()["quote"], "venue": "BINANCE_US"}

    monkeypatch.setattr(router, "robinhood_quote", failed)
    monkeypatch.setattr(router.crypto_market_data, "fetch_quote", failed)
    monkeypatch.setattr(router.crypto_market_data, "fetch_snapshot", unavailable)
    monkeypatch.setattr(router.binance_us_data, "fetch_snapshot", binance)
    monkeypatch.setattr(router.binance_us_data, "fetch_quote", price)
    result = asyncio.run(router.fetch_snapshot(now=NOW))
    assert result["status"] == "OK"
    assert result["research_venue"] == result["book_venue"] == result["venue"] == "BINANCE_US"
    assert result["external_depth_is_not_robinhood"]
    with pytest.raises(ValueError):
        asyncio.run(router.fetch_quote(now=NOW, venue="COINBASE_EXCHANGE"))


@pytest.mark.parametrize("monitor", [True, False])
def test_market_hours_flat_skips_all_data_and_models(tmp_path, monitor):
    setup(tmp_path)

    async def forbidden(**kwargs):
        pytest.fail("market-hours flat run must not fetch data")

    result = asyncio.run(
        run_cycle(
            tmp_path,
            now=datetime(2026, 9, 21, 14, tzinfo=UTC),
            monitor_only=monitor,
            fetcher=forbidden,
            quote_fetcher=forbidden,
        )
    )
    assert result["status"] == "SKIPPED"
    assert result["reason"] == "equity_session_crypto_idle"


def test_fees_and_venue_persist_with_position(tmp_path):
    config = setup(tmp_path)
    store = CryptoPaperStore(tmp_path / "ledger.sqlite3", config)
    quote = {**snapshot()["quote"], "venue": "ROBINHOOD_CRYPTO_V2", "fee_ratio": 0.0095}
    result = store.buy(
        quote,
        {"action": "BUY", "symbol": "ETH-USD", "thesis": "test", "invalidation": "test"},
        NOW,
        deadline="2026-09-20T16:00:00+00:00",
    )
    assert result["position"]["fee_ratio"] == 0.0095
    assert result["position"]["total_entry_cost"] == pytest.approx(50 * 1.0095)
    with pytest.raises(ValueError, match="venue_mismatch"):
        store.monitor({**quote, "venue": "COINBASE_EXCHANGE"}, NOW)


def test_open_position_still_exits_at_market_open(tmp_path):
    config = setup(tmp_path)
    store = CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config)
    before = datetime(2026, 9, 21, 13, 29, tzinfo=UTC)
    opened = datetime(2026, 9, 21, 13, 30, tzinfo=UTC)
    quote = {**snapshot()["quote"], "updated_at": before.isoformat(), "venue": "COINBASE_EXCHANGE"}
    store.buy(
        quote,
        {"action": "BUY", "symbol": "ETH-USD", "thesis": "test", "invalidation": "test"},
        before,
        deadline=opened.isoformat(),
    )

    async def prices(**kwargs):
        return {**quote, "updated_at": opened.isoformat()}

    result = asyncio.run(run_cycle(tmp_path, now=opened, quote_fetcher=prices))
    assert result["monitor"]["status"] == "PAPER_EXIT"
    assert result["monitor"]["reason"] == "DEADLINE"


def test_binance_normalizes_real_zero_volume_and_rejects_bad_intervals():
    from tools import binance_us_data

    rows = []
    end = NOW.replace(second=0)
    for i in range(90):
        start = int((end - timedelta(minutes=5 * (90 - i))).timestamp() * 1000)
        rows.append(
            [start, "100", "102", "99", "101", "0.0000", start + 299999, "0", 0, "0", "0", "0"]
        )

    def transport(url):
        if url == binance_us_data.KLINES:
            return rows
        assert url == binance_us_data.DEPTH
        return {"bids": [["100", "2"]], "asks": [["101", "2"]]}

    result = asyncio.run(binance_us_data.fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "OK"
    assert all(row["volume"] == 0 for row in result["candles_5m"])
    rows[-1][6] += 1
    assert (
        asyncio.run(binance_us_data.fetch_snapshot(now=NOW, transport=transport))["status"]
        == "UNAVAILABLE"
    )


def test_robinhood_fresh_fee_estimate_is_used(monkeypatch):
    async def prices(**kwargs):
        return {**snapshot()["quote"], "venue": "ROBINHOOD_CRYPTO_V2"}

    def estimate(path):
        assert "estimated_price" in path
        return {
            "results": [
                {
                    "side": side,
                    "symbol": "ETH-USD",
                    "quantity": 0.01,
                    "fee_ratio": 0.0095,
                    "timestamp": NOW.isoformat(),
                }
                for side in ("bid", "ask")
            ]
        }

    monkeypatch.setattr(router.robinhood_crypto_data, "fetch_quote", prices)
    monkeypatch.setattr(router.robinhood_crypto_data, "read_endpoint", estimate)
    assert asyncio.run(router.robinhood_quote(now=NOW))["fee_ratio"] == 0.0095
    with pytest.raises(ValueError):
        asyncio.run(router.robinhood_quote(now=NOW + timedelta(seconds=61)))
