from __future__ import annotations

import asyncio
import sqlite3
from datetime import UTC, datetime, timedelta

import pytest

from tools.orderbook import (
    OrderBookValidationError,
    book_features,
    collect_orderbooks,
    parse_level2_book,
)

NOW = datetime(2026, 9, 18, 14, 0, tzinfo=UTC)


def raw_book(*, updated_at: datetime = NOW, bids=None, asks=None) -> dict:
    return {
        "symbol": "SPY",
        "updated_at": updated_at.isoformat(),
        "bids": bids
        if bids is not None
        else [{"price": "100", "quantity": 10}, {"price": "99", "quantity": 5}],
        "asks": asks
        if asks is not None
        else [{"price": "101", "quantity": 2}, {"price": "102", "quantity": 8}],
    }


def test_parser_and_core_formulas() -> None:
    features = book_features(parse_level2_book(raw_book(), now=NOW))
    assert features["spread"] == 1
    assert features["mid"] == 100.5
    assert features["microprice"] == pytest.approx((101 * 10 + 100 * 2) / 12)
    assert features["near_imbalance"] == pytest.approx(5 / 25)
    assert features["weighted_imbalance"] > 0
    assert features["absorption"]["status"] == "UNAVAILABLE"


@pytest.mark.parametrize(
    "change",
    [
        {"bids": [{"price": "100", "quantity": 1}, {"price": "101", "quantity": 2}]},
        {"bids": [{"price": "100", "quantity": 1}, {"price": "100", "quantity": 2}]},
        {"asks": [{"price": "100", "quantity": 1}]},
        {"bids": [{"price": "100", "quantity": "nan"}]},
    ],
)
def test_parser_rejects_malformed_or_crossed_depth(change: dict) -> None:
    payload = raw_book()
    payload.update(change)
    with pytest.raises(OrderBookValidationError):
        parse_level2_book(payload, now=NOW)


def test_parser_rejects_stale_and_future_timestamps() -> None:
    with pytest.raises(OrderBookValidationError, match="stale"):
        parse_level2_book(raw_book(updated_at=NOW - timedelta(seconds=31)), now=NOW)
    with pytest.raises(OrderBookValidationError, match="future"):
        parse_level2_book(raw_book(updated_at=NOW + timedelta(seconds=6)), now=NOW)


def test_empty_weekend_depth_is_no_depth_without_signal(tmp_path) -> None:
    async def fetcher(symbols):
        return {
            "books": [{"symbol": "SPY", "updated_at": NOW.isoformat(), "bids": [], "asks": []}],
            "errors": [],
        }

    result = asyncio.run(
        collect_orderbooks(["SPY"], tmp_path / "book.sqlite3", now=NOW, fetcher=fetcher)
    )
    assert result["status"] == "NO_DEPTH"
    assert result["summaries"]["SPY"]["status"] == "NO_DEPTH"


def test_collection_validates_against_receipt_clock(tmp_path, monkeypatch) -> None:
    from tools import orderbook

    clock = [NOW]

    class Clock(datetime):
        @classmethod
        def now(cls, tz=None):
            return clock[0].astimezone(tz)

    async def fetcher(symbols):
        clock[0] += timedelta(seconds=7)
        return {"books": [raw_book(updated_at=clock[0])], "errors": []}

    monkeypatch.setattr(orderbook, "datetime", Clock)
    result = asyncio.run(collect_orderbooks(["SPY"], tmp_path / "book.sqlite3", fetcher=fetcher))
    assert result["status"] == "OK"
    assert result["summaries"]["SPY"]["status"] == "OK"


def test_history_windows_wall_change_velocity_and_duplicate_rejection(tmp_path) -> None:
    snapshots = [
        raw_book(
            updated_at=NOW - timedelta(minutes=5),
            bids=[{"price": "100", "quantity": 10}],
            asks=[{"price": "101", "quantity": 5}],
        ),
        raw_book(
            updated_at=NOW,
            bids=[{"price": "100", "quantity": 20}],
            asks=[{"price": "101", "quantity": 4}],
        ),
    ]
    calls = iter(snapshots)

    async def fetcher(symbols):
        return {"books": [next(calls)], "errors": []}

    path = tmp_path / "book.sqlite3"
    asyncio.run(collect_orderbooks(["SPY"], path, now=NOW - timedelta(minutes=5), fetcher=fetcher))
    result = asyncio.run(collect_orderbooks(["SPY"], path, now=NOW, fetcher=fetcher))
    summary = result["summaries"]["SPY"]
    assert summary["windows"]["5m"]["samples"] == 2
    assert summary["windows"]["5m"]["wall_changes"]["bid"]["growth"] == 10
    assert summary["windows"]["5m"]["depth_velocity"]["bid_depth_per_second"] > 0

    async def duplicate(symbols):
        return {"books": [snapshots[-1]], "errors": []}

    duplicate_result = asyncio.run(collect_orderbooks(["SPY"], path, now=NOW, fetcher=duplicate))
    assert duplicate_result["summaries"]["SPY"]["status"] == "DUPLICATE"


def test_provider_errors_and_bounded_timeout_are_fail_closed(tmp_path) -> None:
    async def error(symbols):
        return {"books": [], "errors": [{"symbol": "SPY", "error": "closed"}]}

    result = asyncio.run(
        collect_orderbooks(["SPY"], tmp_path / "book.sqlite3", now=NOW, fetcher=error)
    )
    assert result["status"] == "UNAVAILABLE"
    assert result["summaries"]["SPY"]["status"] == "PROVIDER_ERROR"


def test_symbol_bounds_and_uniqueness(tmp_path) -> None:
    with pytest.raises(ValueError):
        asyncio.run(collect_orderbooks(["SPY", "SPY"], tmp_path / "book.sqlite3", now=NOW))
    with pytest.raises(ValueError):
        asyncio.run(
            collect_orderbooks(["A", "B", "C", "D", "E"], tmp_path / "book.sqlite3", now=NOW)
        )


def test_out_of_order_snapshot_is_rejected(tmp_path) -> None:
    snapshots = [
        raw_book(updated_at=NOW - timedelta(seconds=1)),
        raw_book(updated_at=NOW - timedelta(seconds=2)),
    ]
    calls = iter(snapshots)

    async def fetcher(symbols):
        return {"books": [next(calls)], "errors": []}

    path = tmp_path / "book.sqlite3"
    asyncio.run(collect_orderbooks(["SPY"], path, now=NOW, fetcher=fetcher))
    result = asyncio.run(collect_orderbooks(["SPY"], path, now=NOW, fetcher=fetcher))
    assert result["summaries"]["SPY"]["status"] == "OUT_OF_ORDER"


def test_history_does_not_leak_future_or_later_observed_rows(tmp_path) -> None:
    from tools.orderbook import _history

    path = tmp_path / "book.sqlite3"

    async def fetcher(symbols):
        return {"books": [raw_book()], "errors": []}

    asyncio.run(collect_orderbooks(["SPY"], path, now=NOW, fetcher=fetcher))
    connection = sqlite3.connect(path)
    try:
        connection.execute(
            "INSERT INTO orderbook_snapshots VALUES (?, ?, ?, ?, ?)",
            (
                "SPY",
                (NOW + timedelta(seconds=1)).timestamp(),
                (NOW + timedelta(seconds=1)).timestamp(),
                "[]",
                "[]",
            ),
        )
        connection.commit()
        assert len(_history(connection, "SPY", start=NOW - timedelta(minutes=1), end=NOW)) == 1
    finally:
        connection.close()


def test_fixed_price_zone_keeps_former_wall_after_it_stops_being_largest(tmp_path) -> None:
    snapshots = [
        raw_book(
            updated_at=NOW - timedelta(seconds=10),
            bids=[{"price": "100", "quantity": 100}, {"price": "99", "quantity": 10}],
            asks=[{"price": "101", "quantity": 10}],
        ),
        raw_book(
            updated_at=NOW,
            bids=[{"price": "100", "quantity": 10}, {"price": "99", "quantity": 50}],
            asks=[{"price": "101", "quantity": 10}],
        ),
    ]
    calls = iter(snapshots)

    async def fetcher(symbols):
        return {"books": [next(calls)], "errors": []}

    path = tmp_path / "book.sqlite3"
    asyncio.run(collect_orderbooks(["SPY"], path, now=NOW - timedelta(seconds=10), fetcher=fetcher))
    result = asyncio.run(collect_orderbooks(["SPY"], path, now=NOW, fetcher=fetcher))
    zones = result["summaries"]["SPY"]["windows"]["1m"]["liquidity_zones"]["zones"]
    former_wall = next(zone for zone in zones if zone["side"] == "bid" and zone["price"] == 100)
    assert former_wall["state"] == "shrinking"
    assert former_wall["initial_size"] == 100
    assert former_wall["current_size"] == 10
