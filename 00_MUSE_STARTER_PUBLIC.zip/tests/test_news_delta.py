from pathlib import Path

from tools.news_delta import detect_news_delta


def test_first_news_poll_baselines_without_waking_then_new_item_wakes(tmp_path: Path) -> None:
    items = [
        {
            "symbol": "SPY",
            "title": "Existing item",
            "link": "https://example.com/old",
            "published": "today",
            "source": "Example",
        }
    ]

    def fetcher(symbol: str):
        assert symbol == "SPY"
        return list(items)

    state = tmp_path / "news.json"
    baseline = detect_news_delta(["SPY"], state_path=state, fetcher=fetcher)
    assert baseline["wake_luna"] is False
    assert baseline["baseline_created"] is True

    items.append(
        {
            "symbol": "SPY",
            "title": "Brand new item",
            "link": "https://example.com/new",
            "published": "now",
            "source": "Example",
        }
    )
    changed = detect_news_delta(["SPY"], state_path=state, fetcher=fetcher)
    assert changed["wake_luna"] is True
    assert changed["new_items"][0]["title"] == "Brand new item"


def test_no_symbols_performs_no_fetch_or_write(tmp_path: Path) -> None:
    def unexpected_fetcher(symbol: str):
        raise AssertionError(symbol)

    state = tmp_path / "news.json"
    result = detect_news_delta([], state_path=state, fetcher=unexpected_fetcher)
    assert result["status"] == "QUIET"
    assert result["reason"] == "no_open_position_symbols"
    assert not state.exists()
