import asyncio
from datetime import UTC, datetime, timedelta

import pytest

from tools import robinhood_crypto_data as data

NOW = datetime(2026, 9, 20, 17, tzinfo=UTC)


def reader(path):
    assert path == data.QUOTE_PATH
    return {
        "results": [
            {"symbol": "ETH-USD", "bid": "2600", "ask": "2601", "timestamp": NOW.isoformat()}
        ]
    }


def test_quote_and_missing_capabilities():
    quote = asyncio.run(data.fetch_quote(now=NOW, reader=reader))
    assert quote["bid"] == 2600 and quote["timestamp_source"] == "provider"
    snapshot = asyncio.run(data.fetch_snapshot(now=NOW, reader=reader))
    assert snapshot["status"] == "UNAVAILABLE"
    assert snapshot["book"] is None and snapshot["candles_5m"] == []


@pytest.mark.parametrize("value", ["NaN", "Infinity", "-1", True, "2700"])
def test_bad_or_crossed_bid_rejected(value):
    def bad(path):
        result = reader(path)
        result["results"][0]["bid"] = value
        return result

    with pytest.raises(ValueError):
        asyncio.run(data.fetch_quote(now=NOW, reader=bad))


def test_stale_quote_rejected():
    with pytest.raises(ValueError):
        asyncio.run(data.fetch_quote(now=NOW + timedelta(seconds=61), reader=reader))


def test_write_paths_and_external_hosts_rejected_before_credentials():
    for path in ("https://evil.test/", "/api/v2/crypto/trading/orders/", "//evil.test/"):
        with pytest.raises(ValueError, match="unsupported_read_endpoint"):
            data.read_endpoint(path)


def test_cycle_missing_history_cannot_call_models(tmp_path):
    from tests.test_crypto_cycle import setup
    from tools.crypto_cycle import run_cycle

    setup(tmp_path)

    async def snapshot(**kwargs):
        return await data.fetch_snapshot(now=NOW, reader=reader)

    def forbidden(*args, **kwargs):
        pytest.fail("missing history must not reach JEV or Luna")

    result = asyncio.run(
        run_cycle(
            tmp_path,
            now=NOW,
            execute_models=True,
            fetcher=snapshot,
            evaluator=forbidden,
            model=forbidden,
        )
    )
    assert result["status"] == "UNAVAILABLE"
    assert result["monitor"]["status"] == "FLAT"
