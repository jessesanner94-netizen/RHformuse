from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime, timedelta

from tools.jev_replay import (
    attach_outcomes,
    measure_forward,
    read_evidence,
    report,
    write_completed_outcomes,
)
from tools.jev_store import JevStore

NOW = datetime(2026, 9, 18, 15, 0, tzinfo=UTC)


def row(minute: int, price: float, *, high: float | None = None, low: float | None = None) -> dict:
    return {"symbol": "SPY", "timestamp": (NOW + timedelta(minutes=minute)).isoformat(),
            "price": price, "high": high if high is not None else price,
            "low": low if low is not None else price}


def features(direction: str = "CALL") -> dict:
    return {"candidate": {"candidate_id": "spy-contract", "symbol": "SPY", "direction": direction,
                            "target_price": 102, "stop_price": 98}}


def test_forward_measurement_never_uses_a_future_price_as_the_asof_price():
    prices = {"SPY": [row(1, 101), row(2, 102)]}
    result = measure_forward(features(), NOW, prices)
    assert result[1] == {"status": "UNAVAILABLE", "reason": "as_of_price_unavailable_or_stale"}


def test_missing_coverage_is_unavailable_and_not_filled_with_later_observation():
    prices = {"SPY": [row(0, 100), row(1, 101), row(5, 105)]}
    result = measure_forward(features(), NOW, prices, max_gap_minutes=1)
    assert result[1]["status"] == "MEASURED"
    assert result[5]["status"] == "UNAVAILABLE"
    assert result[5]["reason"] == "horizon_or_coverage_missing"


def test_asof_uses_bounded_prior_tick_and_never_measures_into_the_future():
    as_of = NOW + timedelta(seconds=15)
    prices = {"SPY": [row(minute, 100 + minute) for minute in range(2)]}
    measured = measure_forward(features(), as_of, prices, now=NOW + timedelta(minutes=2))
    assert measured[1]["entry_source_at"] == NOW.isoformat()
    assert measured[1]["measured_at"] == (NOW + timedelta(minutes=1)).isoformat()
    future = measure_forward(features(), as_of, prices, now=as_of)
    assert future[1]["reason"] == "future_horizon"


def test_same_bar_target_and_stop_is_explicitly_ambiguous():
    prices = {"SPY": [row(0, 100), row(1, 100, high=103, low=97)]}
    result = measure_forward(features(), NOW, prices)
    assert result[1]["target_stop"] == {
        "status": "AMBIGUOUS", "at": (NOW + timedelta(minutes=1)).isoformat(),
        "reason": "target_and_stop_crossed_same_bar",
    }


def test_mfe_mae_exclude_the_asof_bar_high_low_from_future_evidence():
    prices = {"SPY": [row(0, 100, high=150, low=50), row(1, 101, high=101, low=101)]}
    result = measure_forward(features(), NOW, prices)
    assert result[1]["mfe_underlying_pct"] == 1.0
    assert result[1]["mae_underlying_pct"] == 0.0


def test_put_mfe_mae_and_target_order_are_direction_aware():
    prices = {"SPY": [row(0, 100), row(1, 99, high=100, low=97)]}
    put = features("PUT")
    put["candidate"]["target_price"] = 98
    put["candidate"]["stop_price"] = 102
    result = measure_forward(put, NOW, prices)
    assert result[1]["underlying_directional_return_pct"] == 1.0
    assert result[1]["mfe_underlying_pct"] == 3.0
    assert result[1]["mae_underlying_pct"] == 0.0
    assert result[1]["target_stop"]["status"] == "TARGET_FIRST"


def test_outcomes_append_without_changing_inference_and_refuse_conflicts(tmp_path):
    db_path = tmp_path / "jev.sqlite3"
    store = JevStore(db_path)
    observation = store.observe(features=features(), evaluation={"scores": {"setup_quality": 0.9}},
                                now=NOW, python_pass=True, shadow=False)
    evidence = read_evidence(db_path)
    prices = {"SPY": [row(minute, 100 + minute) for minute in range(31)]}
    attached = attach_outcomes(evidence, prices)
    assert write_completed_outcomes(db_path, attached)["written"] == 4
    reloaded = read_evidence(db_path)
    assert reloaded[0]["evaluation"]["scores"]["setup_quality"] == 0.9
    changed = deepcopy(attached)
    changed[observation][1]["close_price"] = 999
    assert write_completed_outcomes(db_path, changed)["conflicts"] == 1
    assert read_evidence(db_path)[0]["outcomes"][1]["payload"]["close_price"] == 101


def test_report_keeps_absent_baseline_unavailable_and_never_calls_underlying_return_pnl(tmp_path):
    store = JevStore(tmp_path / "jev.sqlite3")
    observation = store.observe(
        features=features(),
        evaluation={"status": "OK", "scores": {"setup_quality": 0.9},
                    "question_versions": ["jev-market-v2"],
                    "policy": {"would_escalate": True}},
        now=NOW, python_pass=True, shadow=False,
    )
    store.event(observation, "luna_routing", {"luna_escalated": True, "decision": "BUY"}, NOW)
    evidence = read_evidence(tmp_path / "jev.sqlite3")
    prices = {"SPY": [row(minute, 100 + minute) for minute in range(31)]}
    write_completed_outcomes(tmp_path / "jev.sqlite3", attach_outcomes(evidence, prices))
    result = report(read_evidence(tmp_path / "jev.sqlite3"))
    assert set(result["observed_groups"]) == {"python_jev_luna"}
    group = result["observed_groups"]["python_jev_luna"]
    assert group["calls_actually_consumed"] == 1
    assert group["hypothetical_calls_saved"] is None
    assert group["winner_retention"] == 1
    assert group["realized_metrics"]["status"] == "UNAVAILABLE"


def test_attach_anchors_score_labels_at_response_availability(tmp_path):
    store = JevStore(tmp_path / "jev.sqlite3")
    store.observe(
        features=features(),
        evaluation={"status": "OK", "available_at": (NOW + timedelta(minutes=2)).isoformat()},
        now=NOW,
        python_pass=True,
        shadow=True,
    )
    prices = {"SPY": [row(minute, 100 + minute) for minute in range(33)]}
    evidence = read_evidence(tmp_path / "jev.sqlite3")
    outcome = next(iter(attach_outcomes(evidence, prices).values()))[1]
    assert outcome["outcome_anchor_at"] == (NOW + timedelta(minutes=2)).isoformat()
    assert outcome["entry_source_at"] == (NOW + timedelta(minutes=2)).isoformat()


def test_shadow_route_is_baseline_with_only_a_potential_suppression_count(tmp_path):
    store = JevStore(tmp_path / "jev.sqlite3")
    observation = store.observe(
        features=features(),
        evaluation={"status": "OK", "scores": {"setup_quality": 0.95},
                    "question_versions": ["jev-market-v2"],
                    "policy": {"would_escalate": False}},
        now=NOW,
        python_pass=True,
        shadow=True,
    )
    store.event(observation, "luna_routing", {"luna_escalated": True}, NOW)
    result = report(read_evidence(tmp_path / "jev.sqlite3"))
    baseline = result["observed_groups"]["python_luna"]
    assert baseline["potential_shadow_policy_suppressions"] == 1
    assert baseline["winner_retention"] is None
    assert baseline["loser_rejection"] is None


def test_non_routing_events_cannot_duplicate_a_shadow_route_or_realized_metrics(tmp_path):
    store = JevStore(tmp_path / "jev.sqlite3")
    observation = store.observe(
        features=features(),
        evaluation={"status": "OK", "policy": {"would_escalate": False}},
        now=NOW,
        python_pass=True,
        shadow=True,
    )
    store.event(observation, "luna_routing", {"luna_escalated": True}, NOW)
    store.event(observation, "execution_result", {"realized_pnl": 3}, NOW)
    store.event(observation, "candidate_suppressed", {"realized_pnl": 99}, NOW)
    baseline = report(read_evidence(tmp_path / "jev.sqlite3"))["observed_groups"]["python_luna"]
    assert baseline["routing_events"] == 1
    assert baseline["calls_actually_consumed"] == 1
    assert baseline["realized_metrics"]["count"] == 1
    assert baseline["realized_metrics"]["expectancy"] == 3
