import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from tools.windows_notify import (
    notification_payload,
    send_notification,
    send_ntfy_notification,
)

OPEN_CHECK_TIME = datetime(2026, 8, 28, 13, 32, tzinfo=UTC)


def _opening_block(cycle="positions"):
    return {
        "cycle": cycle,
        "live": {
            "status": "BLOCKED",
            "reason": "robinhood_order_review_blocked",
            "symbol": "IBIT",
            "purpose": "EXIT",
            "exit_reason": "STOP_LOSS",
            "orders_placed": 0,
            "review": {
                "allowed": False,
                "reasons": ["OPTION_MARKET_INVALID_TIME_MARKET_OPEN"],
                "checks": {
                    "alertType": "OPTION_MARKET_INVALID_TIME_MARKET_OPEN",
                    "details": {"regularTradingMarketOpen": "2026-08-28 09:35:00-04:00"},
                },
            },
        },
    }


def test_opening_review_explains_exit_and_broker_time_without_allowing_order(tmp_path):
    result = send_notification(_opening_block(), project_root=tmp_path, now=OPEN_CHECK_TIME)
    assert result["status"] == "PREVIEW"
    assert "NO ORDER — IBIT exit blocked (STOP_LOSS)" in result["message"]
    assert "09:35:00-04:00" in result["message"]
    assert "OPTION_MARKET_INVALID_TIME_MARKET_OPEN" in result["message"]
    assert not (tmp_path / "state").exists()


def test_opening_review_deduplicates_across_cycles_but_not_after_window(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setattr(
        "tools.windows_notify._send_windows_notification", lambda *a, **k: {"status": "SENT"}
    )

    def sender(title, message):
        calls.append(message)
        return {"status": "SENT"}

    first = send_notification(
        _opening_block(),
        project_root=tmp_path,
        execute=True,
        ntfy_sender=sender,
        now=OPEN_CHECK_TIME,
    )
    second = send_notification(
        _opening_block("opportunities"),
        project_root=tmp_path,
        execute=True,
        ntfy_sender=sender,
        now=OPEN_CHECK_TIME + timedelta(minutes=1),
    )
    assert first["status"] == "SENT"
    assert second["reason"] == "opening_review_already_notified"
    assert len(calls) == 1
    # A persisting rejection after the broker's time must get through, not silently wait forever.
    after = send_notification(
        _opening_block(),
        project_root=tmp_path,
        execute=True,
        ntfy_sender=sender,
        now=OPEN_CHECK_TIME + timedelta(minutes=3),
    )
    assert after["status"] == "SENT"
    assert len(calls) == 2


def test_failed_phone_alert_remains_retryable_even_if_desktop_succeeds(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "tools.windows_notify._send_windows_notification", lambda *a, **k: {"status": "SENT"}
    )
    for _ in range(2):
        result = send_notification(
            _opening_block(),
            project_root=tmp_path,
            execute=True,
            ntfy_sender=lambda *a: {"status": "ERROR"},
            now=OPEN_CHECK_TIME,
        )
        assert result["channels"]["ntfy"]["status"] == "ERROR"
    assert not (tmp_path / "state/runtime/opening_review_notifications.json").exists()


@pytest.mark.parametrize("stamp", ["", "invalid", "2026-08-28 09:35:00"])
def test_invalid_broker_time_never_suppresses_notifications(tmp_path, monkeypatch, stamp):
    monkeypatch.setattr(
        "tools.windows_notify._send_windows_notification", lambda *a, **k: {"status": "SKIPPED"}
    )
    payload = _opening_block()
    payload["live"]["review"]["checks"]["details"]["regularTradingMarketOpen"] = stamp
    for _ in range(2):
        assert (
            send_notification(
                payload,
                project_root=tmp_path,
                execute=True,
                ntfy_sender=lambda *a: {"status": "SENT"},
                now=OPEN_CHECK_TIME,
            )["status"]
            == "SENT"
        )


def test_other_broker_rejection_exposes_actual_details():
    payload = _opening_block()
    payload["live"]["review"]["checks"] = {
        "alertType": "INSUFFICIENT_POSITION",
        "details": {"quantity": "0"},
    }
    title, message = notification_payload(payload)
    assert "Attention" in title
    assert "INSUFFICIENT_POSITION" in message
    assert '"quantity":"0"' in message
    assert "NO ORDER" in message


def test_quiet_result_has_no_notification(tmp_path: Path) -> None:
    result = send_notification(
        {"cycle": "news", "routing": {"luna": {"status": "SKIPPED"}, "sol": None}},
        project_root=tmp_path,
    )
    assert result["status"] == "SKIPPED"


def test_exhausted_model_budget_has_no_repeating_notification(tmp_path: Path) -> None:
    result = send_notification(
        {
            "cycle": "opportunities",
            "status": "SLEEPING",
            "routing": {
                "decision": {
                    "status": "BUDGET_BLOCKED",
                    "reason": "daily_model_call_budget_reached",
                }
            },
        },
        project_root=tmp_path,
    )

    assert result == {"status": "SKIPPED", "reason": "no_material_user_alert"}


def test_sol_completion_produces_bounded_preview(tmp_path: Path) -> None:
    payload = {
        "cycle": "opportunities",
        "routing": {
            "luna": {"status": "COMPLETED"},
            "sol": {"status": "COMPLETED", "output": "WAIT"},
        },
    }
    result = send_notification(payload, project_root=tmp_path)
    assert result["status"] == "PREVIEW"
    assert result["message"] == "WAIT"


def test_compact_decision_completion_produces_bounded_preview(tmp_path: Path) -> None:
    payload = {
        "cycle": "opportunities",
        "routing": {
            "decision": {"status": "COMPLETED", "output": '{"action":"PASS"}'},
            "decision_packet": {
                "candidate": {
                    "symbol": "TLT",
                    "expiration": "2026-09-04",
                    "strike": 83,
                    "option_type": "PUT",
                    "ask": 0.66,
                }
            },
        },
    }
    result = send_notification(payload, project_root=tmp_path)
    assert result["status"] == "PREVIEW"
    assert result["message"].startswith("PASS — TLT 9/4/26 $83 PUT @ $0.66.")
    assert "{" not in result["message"]


def test_blocked_buy_alert_says_no_order_and_names_contract() -> None:
    payload = notification_payload(
        {
            "cycle": "opportunities",
            "live_decision": {
                "status": "BLOCKED",
                "reason": "fresh_entry_option_or_underlying_quote_missing",
                "blockers": ["underlying_trade_timestamp_missing"],
                "orders_placed": 0,
            },
            "routing": {
                "decision_verdict": {"action": "BUY"},
                "decision_packet": {
                    "candidate": {
                        "symbol": "SOFI",
                        "expiration": "2026-08-28",
                        "strike": 19.5,
                        "option_type": "CALL",
                        "ask": 0.29,
                    }
                },
            },
        }
    )

    assert payload is not None
    assert "NO ORDER" in payload[1]
    assert "SOFI 8/28/26 $19.5 CALL @ $0.29" in payload[1]
    assert "underlying_trade_timestamp_missing" in payload[1]


def test_position_trigger_has_priority() -> None:
    payload = notification_payload(
        {
            "cycle": "positions",
            "monitor": {
                "wake_codex": True,
                "triggers": [{"code": "PROTECTIVE_ORDER_MISSING"}],
            },
        }
    )
    assert payload is not None
    assert "PROTECTIVE_ORDER_MISSING" in payload[1]


def test_paper_entry_produces_material_alert() -> None:
    payload = notification_payload(
        {
            "cycle": "opportunities",
            "paper_decision": {
                "event": {
                    "event": "PAPER_ENTRY",
                    "symbol": "SPY",
                    "expiration": "2026-09-15",
                    "strike": 755,
                    "option_type": "PUT",
                    "quantity": 1,
                    "fill_price": 1.63,
                    "trade_style": "DAY",
                }
            },
        }
    )
    assert payload is not None
    assert "PAPER_ENTRY" in payload[1]
    assert "1x SPY 9/15/26 $755 PUT @ $1.63" in payload[1]
    assert "premium $163.00" in payload[1]
    assert "; DAY" in payload[1]


def test_live_exit_fill_produces_material_alert() -> None:
    payload = notification_payload(
        {
            "cycle": "positions",
            "live": {
                "event": {
                    "event": "LIVE_EXIT_FILLED",
                    "symbol": "SPY",
                    "fill_price": 1.3,
                    "realized_pnl": 25,
                    "exit_reason": "TAKE_PROFIT",
                }
            },
        }
    )
    assert payload is not None
    assert "LIVE_EXIT_FILLED" in payload[1]
    assert "TAKE_PROFIT" in payload[1]


def test_live_entry_fill_names_trade_style() -> None:
    payload = notification_payload(
        {
            "cycle": "opportunities",
            "live_decision": {
                "event": {
                    "event": "LIVE_ENTRY_FILLED",
                    "symbol": "QQQ",
                    "fill_price": 1.45,
                    "trade_style": "SWING",
                }
            },
        }
    )
    assert payload is not None
    assert "LIVE_ENTRY_FILLED" in payload[1]
    assert "; SWING" in payload[1]


def test_cycle_error_produces_alert() -> None:
    payload = notification_payload(
        {"cycle": "opportunities", "status": "ERROR", "error": "fixture failure"}
    )
    assert payload is not None
    assert "fixture failure" in payload[1]


def test_manual_cancel_action_produces_explicit_alert() -> None:
    payload = notification_payload(
        {
            "cycle": "positions",
            "live_decision": {
                "status": "ATTENTION",
                "manual_action": "CANCEL_ORDER",
                "order_id": "order-123",
                "reason": "thesis invalidated before fill",
            },
        }
    )
    assert payload is not None
    assert payload[0] == "Robinhood — CANCEL ORDER"
    assert "order-123" in payload[1]
    assert "Robinhood app" in payload[1]


class _FakeNtfyResponse:
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *_args) -> None:
        return None


@pytest.mark.parametrize(
    ("title", "message", "warning"),
    [
        ("Robinhood — Opportunities", "PASS — no trade", False),
        ("Robinhood — Entry Filled", "PURR entry filled", False),
        ("Robinhood — Exit Filled", "LIVE_EXIT_FILLED", False),
        ("Robinhood — CANCEL ORDER", "Manual action required", True),
        ("Robinhood — Positions Error", "Connection failed", True),
        ("Robinhood — Attention", "Pending order needs review", True),
        ("Robinhood — Status", "BLOCKED: missing quote", True),
    ],
)
def test_ntfy_send_uses_normal_priority_and_does_not_return_topic(
    title: str, message: str, warning: bool
) -> None:
    captured = {}

    def opener(request, *, timeout):
        captured["body"] = request.data
        captured["timeout"] = timeout
        return _FakeNtfyResponse()

    topic = "random-topic-12345678901234567890"
    result = send_ntfy_notification(
        title,
        message,
        topic=topic,
        opener=opener,
    )
    assert result == {"status": "SENT", "http_status": 200}
    assert captured["timeout"] == 10
    assert topic.encode() in captured["body"]
    assert topic not in str(result)
    body = json.loads(captured["body"])
    assert body["priority"] == 3
    assert body["tags"] == (["warning"] if warning else ["chart_with_upwards_trend"])


def test_ntfy_send_skips_when_topic_is_not_configured(monkeypatch) -> None:
    monkeypatch.delenv("NTFY_TOPIC", raising=False)
    assert send_ntfy_notification("Title", "Message") == {
        "status": "SKIPPED",
        "reason": "ntfy_topic_not_configured",
    }


def test_model_failure_notification_never_sends_cli_prompt():
    from tools.windows_notify import notification_payload

    result = {
        "cycle": "opportunities",
        "routing": {
            "decision": {
                "status": "ERROR",
                "error": "OpenAI Codex banner user PRIVATE_PACKET invalid_json_schema",
                "output": "",
            },
            "decision_packet": {
                "candidate": {"symbol": "QQQ", "option_type": "CALL", "strike": 740}
            },
        },
    }
    title, message = notification_payload(result)
    assert "Error" in title and "NO ORDER" in message and "response schema" in message
    assert "PRIVATE_PACKET" not in message and "OpenAI Codex" not in message


def test_blocked_paper_buy_does_not_claim_entry():
    payload = {
        "cycle": "opportunities",
        "paper_decision": {"status": "BLOCKED", "reasons": ["fill_spread_too_wide"]},
        "routing": {
            "decision": {"status": "COMPLETED", "output": '{"action":"BUY"}'},
            "decision_packet": {"candidate": {"symbol": "QQQ"}},
        },
    }
    title, message = notification_payload(payload)
    assert "Attention" in title
    assert "NO PAPER TRADE" in message and "fill_spread_too_wide" in message
    assert not message.startswith("BUY")


@pytest.mark.parametrize("status", ["REJECTED", "CAP_REACHED", None])
def test_unsaved_watch_does_not_claim_monitoring(status):
    result = {
        "routing": {
            "decision": {"status": "COMPLETED", "output": '{"action":"WATCH"}'},
            "watch_saved": {"status": status},
        }
    }
    title, message = notification_payload(result)
    assert "Attention" in title and "WATCH NOT SAVED" in message


@pytest.mark.parametrize("status", ["SAVED", "REPLACED"])
def test_saved_watch_retains_normal_notification(status):
    result = {
        "routing": {
            "decision": {"status": "COMPLETED", "output": '{"action":"WATCH"}'},
            "watch_saved": {"status": status},
        }
    }
    title, message = notification_payload(result)
    assert "Attention" not in title and message.startswith("WATCH —")
