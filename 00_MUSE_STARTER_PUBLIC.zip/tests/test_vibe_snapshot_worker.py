from __future__ import annotations

import sys
from types import SimpleNamespace

from tools.vibe_snapshot_worker import _intraday_structure, _news_and_earnings, _summary


def _bar(
    timestamp: str, *, open_: float, high: float, low: float, close: float
) -> dict[str, object]:
    return {
        "trade_date": timestamp,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": 1_000,
    }


def test_summary_keeps_the_latest_consecutive_bars() -> None:
    raw = {
        "data": [
            _bar(
                f"2026-08-26T13:{30 + index:02d}:00Z",
                open_=100 + index,
                high=101 + index,
                low=99 + index,
                close=100 + index,
            )
            for index in range(10)
        ]
    }

    result = _summary(raw, max_bars=4)

    assert result["bars"] == 4
    assert result["latest_close"] == 109
    assert result["change_3_bar_percent"] == 2.8302


def test_intraday_structure_recognizes_opening_range_reclaim() -> None:
    raw = {
        "data": [
            _bar("2026-08-26T13:30:00Z", open_=101, high=102, low=100, close=101),
            _bar("2026-08-26T13:35:00Z", open_=101, high=103, low=100.5, close=102),
            _bar("2026-08-26T13:40:00Z", open_=102, high=102.5, low=101, close=102),
            _bar("2026-08-26T13:45:00Z", open_=101, high=101.5, low=99, close=100.5),
            _bar("2026-08-26T13:50:00Z", open_=100.5, high=103, low=100.4, close=102.5),
        ]
    }

    result = _intraday_structure(raw)

    assert result["status"] == "OK"
    assert result["opening_range_low"] == 100
    assert result["swept_and_reclaimed_opening_range_low"] is True
    assert result["bias"] == "BULLISH"


def test_etf_earnings_are_not_applicable(monkeypatch) -> None:
    class FakeTicker:
        news: list[object] = []

        def get_history_metadata(self) -> dict[str, str]:
            return {"instrumentType": "ETF"}

        @property
        def calendar(self):
            raise AssertionError("ETF calendar must not be queried")

    monkeypatch.setitem(
        sys.modules,
        "yfinance",
        SimpleNamespace(Ticker=lambda symbol: FakeTicker()),
    )

    headlines, earnings, instrument_type = _news_and_earnings("TLT")

    assert headlines == []
    assert instrument_type == "ETF"
    assert earnings == {"status": "NOT_APPLICABLE", "next_date": None}


def test_equity_earnings_date_remains_required(monkeypatch) -> None:
    class FakeTicker:
        news: list[object] = []
        calendar = {"Earnings Date": "2026-10-22"}

        def get_history_metadata(self) -> dict[str, str]:
            return {"instrumentType": "EQUITY"}

    monkeypatch.setitem(
        sys.modules,
        "yfinance",
        SimpleNamespace(Ticker=lambda symbol: FakeTicker()),
    )

    _, earnings, instrument_type = _news_and_earnings("SOFI")

    assert instrument_type == "EQUITY"
    assert earnings == {"status": "AVAILABLE", "next_date": "2026-10-22"}
