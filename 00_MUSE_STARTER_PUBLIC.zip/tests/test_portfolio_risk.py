from __future__ import annotations

from tools.portfolio_risk import evaluate_risk


def test_candidate_within_hard_limits_is_allowed(
    account, base_candidate, resolved_config, historical
) -> None:
    result = evaluate_risk(account, base_candidate, resolved_config, historical=historical)
    assert result.status == "ALLOWED"
    assert result.reasons == ()
    assert result.analytics["status"] == "CALCULATED"


def test_daily_loss_limit_blocks_new_risk(account, base_candidate, resolved_config) -> None:
    account = {**account, "daily_pnl": -600}
    result = evaluate_risk(account, base_candidate, resolved_config)
    assert result.status == "BLOCKED"
    assert "daily_loss_dollar_limit_reached" in result.reasons


def test_earnings_multiplier_reduces_single_position_cap(
    account, base_candidate, resolved_config
) -> None:
    candidate = {
        **base_candidate,
        "holds_through_earnings": True,
        "earnings_decision": "HOLD THROUGH EARNINGS",
    }
    result = evaluate_risk(account, candidate, resolved_config)
    assert result.status == "BLOCKED"
    assert result.metrics["effective_single_position_cap"] == 250.0
    assert "single_position_premium_limit_exceeded" in result.reasons


def test_missing_account_data_fails_closed(base_candidate, resolved_config) -> None:
    result = evaluate_risk({}, base_candidate, resolved_config)
    assert result.status == "INSUFFICIENT_DATA"


def test_contract_quantity_limit_blocks_candidate(account, base_candidate, resolved_config) -> None:
    candidate = {**base_candidate, "quantity": 3}
    result = evaluate_risk(account, candidate, resolved_config)

    assert result.status == "BLOCKED"
    assert "max_contracts_per_position_exceeded" in result.reasons


def test_minimum_position_premium_blocks_tiny_contract(
    account, base_candidate, resolved_config
) -> None:
    candidate = {**base_candidate, "premium_at_risk": 49}
    result = evaluate_risk(account, candidate, resolved_config)

    assert result.status == "BLOCKED"
    assert "single_position_premium_minimum_not_met" in result.reasons
    assert result.metrics["minimum_single_position_premium"] == 50.0


def test_daily_new_position_limit_blocks_candidate(
    account, base_candidate, resolved_config
) -> None:
    account = {**account, "new_positions_today": 5}
    result = evaluate_risk(account, base_candidate, resolved_config)

    assert result.status == "BLOCKED"
    assert "max_new_positions_per_day_exceeded" in result.reasons


def test_protective_stop_is_required(account, base_candidate, resolved_config) -> None:
    candidate = {**base_candidate, "protective_stop_planned": False}
    result = evaluate_risk(account, candidate, resolved_config)

    assert result.status == "BLOCKED"
    assert "protective_stop_required" in result.reasons


def test_averaging_down_is_prohibited(account, base_candidate, resolved_config) -> None:
    candidate = {**base_candidate, "is_averaging_down": True}
    result = evaluate_risk(account, candidate, resolved_config)

    assert result.status == "BLOCKED"
    assert "averaging_down_prohibited" in result.reasons
