import asyncio
import json
from dataclasses import replace
from datetime import timedelta

import pytest

from tests.test_crypto_cycle import NOW, decision, dependencies, setup, snapshot
from tools.crypto_cycle import parse_decision, run_cycle, run_universe
from tools.crypto_notifications import drain_notifications
from tools.crypto_paper import CryptoPaperStore


def btc_snapshot():
    data = snapshot()
    data["symbol"] = data["book"]["symbol"] = data["quote"]["symbol"] = "BTC-USD"
    return data


def test_btc_pipeline_uses_shared_cash_and_rejects_second_asset(tmp_path):
    config = setup(tmp_path)
    calls, kwargs = dependencies()

    async def fetch(**kw):
        return btc_snapshot()

    async def quote(**kw):
        return btc_snapshot()["quote"]

    def model(*args, **kw):
        packet = args[0]["decision_packet"]
        assert packet["candidate"]["symbol"] == "BTC-USD"
        return {"status": "COMPLETED", "output": json.dumps({**decision(), "symbol": "BTC-USD"})}

    kwargs.update(fetcher=fetch, quote_fetcher=quote, model=model)
    result = asyncio.run(
        run_cycle(tmp_path, execute_models=True, now=NOW, symbol="BTC-USD", **kwargs)
    )
    assert result["status"] == "PAPER_BUY", result
    store = CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config)
    state = store.read()
    assert state["position"]["symbol"] == "BTC-USD"
    assert state["cash"] < 369 and state["day"]["entries"] == 1
    with pytest.raises(ValueError, match="symbol_mismatch"):
        store.monitor({**snapshot()["quote"], "symbol": "ETH-USD"}, NOW)
    second = asyncio.run(run_cycle(tmp_path, now=NOW, symbol="ETH-USD", **kwargs))
    assert second["status"] == "SKIPPED"
    assert store.read()["cash"] == state["cash"]


def test_wrong_symbol_model_decision_rejected():
    with pytest.raises(ValueError, match="symbol"):
        parse_decision(json.dumps(decision()), btc_snapshot()["quote"], NOW, "BTC-USD")


def test_both_assets_researched_once_per_bar(tmp_path):
    setup(tmp_path)
    calls, kwargs = dependencies(jev_ok=False)

    async def btc(**kw):
        return btc_snapshot()

    for symbol in ("ETH-USD", "BTC-USD", "ETH-USD", "BTC-USD"):
        args = {**kwargs}
        if symbol == "BTC-USD":
            args["fetcher"] = btc
        asyncio.run(run_cycle(tmp_path, now=NOW, symbol=symbol, **args))
    assert calls["jev"] == 2 and calls["model"] == 0


def test_universe_monitors_held_btc_first(tmp_path, monkeypatch):
    config = setup(tmp_path)
    config = replace(config, values={**config.values, "CRYPTO_SYMBOL": "BTC-USD"})
    store = CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config)
    store.buy(
        btc_snapshot()["quote"],
        {**decision(), "symbol": "BTC-USD"},
        NOW,
        deadline=NOW + timedelta(hours=1),
    )
    calls = []

    async def cycle(*args, **kwargs):
        calls.append(kwargs["symbol"])
        return {"status": "HOLD"}

    monkeypatch.setattr("tools.crypto_cycle.run_cycle", cycle)
    asyncio.run(run_universe(tmp_path, now=NOW))
    assert calls == ["BTC-USD"]


@pytest.mark.parametrize("symbol", ["ETH-USD", "BTC-USD"])
def test_trade_notifications_retry_only_failed_channel_and_deduplicate(tmp_path, symbol):
    config = setup(tmp_path)
    config = replace(config, values={**config.values, "CRYPTO_SYMBOL": symbol})
    store = CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config)
    quote = {**snapshot()["quote"], "symbol": symbol}
    store.buy(quote, {**decision(), "symbol": symbol}, NOW, deadline=NOW + timedelta(minutes=1))
    calls = []
    fail_phone = True

    def sender(channel, title, message, root):
        calls.append(channel)
        assert "PAPER" in title and symbol in title
        assert "no real order" in message
        return {"status": "ERROR" if channel == "ntfy" and fail_phone else "SENT"}

    drain_notifications(tmp_path, sender=sender)
    assert calls == ["windows", "ntfy"]
    fail_phone = False
    drain_notifications(tmp_path, sender=sender)
    assert calls == ["windows", "ntfy", "ntfy"]
    drain_notifications(tmp_path, sender=sender)
    assert len(calls) == 3
    now = NOW + timedelta(minutes=2)
    store.monitor({**quote, "updated_at": now.isoformat()}, now)
    result = drain_notifications(tmp_path, sender=sender)
    assert len(result["events"]) == 1
    assert calls[-2:] == ["windows", "ntfy"]


@pytest.mark.parametrize("failure", ["UNAVAILABLE", "MODEL_ERROR", "ERROR"])
def test_universe_reports_child_failure_to_scheduler(tmp_path, monkeypatch, failure):
    setup(tmp_path)

    async def cycle(*args, **kwargs):
        return {"status": failure if kwargs["symbol"] == "BTC-USD" else "PASS"}

    monkeypatch.setattr("tools.crypto_cycle.run_cycle", cycle)
    result = asyncio.run(run_universe(tmp_path, now=NOW))
    assert result["status"] == "UNAVAILABLE"
    assert result["orders_placed"] == 0


@pytest.mark.parametrize(
    "notification",
    [
        {"status": "ERROR", "reason": "fixture"},
        {"status": "CHECKED", "events": [{"channels": {"ntfy": {"status": "ERROR"}}}]},
    ],
)
def test_crypto_cli_notification_failure_is_visible_to_scheduler(
    tmp_path, monkeypatch, notification
):
    from tools import crypto_cycle

    async def universe(*args, **kwargs):
        return {"status": "COMPLETED", "orders_placed": 0}

    monkeypatch.setattr(crypto_cycle, "run_universe", universe)
    monkeypatch.setattr("tools.crypto_notifications.drain_notifications", lambda *a: notification)
    assert crypto_cycle.main(["--project-root", str(tmp_path), "--notifications"]) == 1
