"""Synthetic, offline tests for point-in-time zone vetoes, not strategy returns."""

import copy
import json
import socket
from datetime import UTC, datetime, timedelta

import pytest

from research.options_lab.zone_signals import DEFAULT_ZONE_POLICY, zone_review

NOW = datetime(2026, 10, 21, 14, tzinfo=UTC)
POLICY = {
    **DEFAULT_ZONE_POLICY,
    "book_source": "synthetic",
    "book_venue": "TEST",
    "bar_source": "synthetic",
    "bar_venue": "TEST",
    "displacement_lookback_bars": 2,
}


def stamp(seconds):
    return (NOW + timedelta(seconds=seconds)).isoformat()


def event(kind, at, payload):
    return {
        "schema_version": 1,
        "symbol": "SPY",
        "source": "synthetic",
        "venue": "TEST",
        "kind": kind,
        "event_id": f"{kind}-{at}",
        "event_at": stamp(at),
        "received_at": stamp(at),
        "available_at": stamp(at),
        "payload": payload,
    }


def book(at, *, ask=1000, bid=10):
    return event(
        "book",
        at,
        {
            "symbol": "SPY",
            "updated_at": stamp(at),
            "bids": [{"price": 100, "quantity": bid}],
            "asks": [{"price": 100.1, "quantity": ask}],
        },
    )


def bar(end, *, opening=100, close=100, high=100.1, low=99.9, volume=100):
    return event(
        "bar",
        end,
        {
            "start_at": stamp(end - 60),
            "end_at": stamp(end),
            "open": opening,
            "close": close,
            "high": high,
            "low": low,
            "volume": volume,
        },
    )


def review(rows, side="CALL", at=20, *, liquidity=True, supply_demand=False, policy=None):
    return zone_review(
        rows,
        "SPY",
        side,
        NOW + timedelta(seconds=at),
        liquidity=liquidity,
        supply_demand=supply_demand,
        policy=POLICY if policy is None else policy,
    )


def supply_rows():
    return [
        bar(-120),
        bar(-60),
        bar(0, close=99.5, high=100, low=99.4, volume=500),
        bar(60, opening=99.5, close=99.85, high=99.9, low=99.4),
    ]


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("zone research attempted network access")

    monkeypatch.setattr(socket.socket, "connect", forbidden)


def test_persistent_resting_wall_is_directional_and_json_safe():
    rows = [book(0), book(10), book(20)]
    original = copy.deepcopy(rows)
    result = review(rows)
    assert result["status"] == "BLOCK"
    assert review(rows, "PUT")["status"] == "ALLOW"
    wall = result["evidence"]["liquidity"]["evidence"]["walls"][0]
    assert wall["samples"] == 3 and wall["duration_seconds"] == 20
    assert result["evidence"]["coverage"] == "UNVERIFIED_FEED_COVERAGE"
    json.dumps(result, allow_nan=False)
    assert rows == original
    assert (
        review(
            [book(0, ask=10, bid=1000), book(10, ask=10, bid=1000), book(20, ask=10, bid=1000)],
            "PUT",
        )["status"]
        == "BLOCK"
    )


def test_wall_disappearance_breaks_persistence_and_expiry():
    rows = [book(0), book(10), book(20)]
    assert review(rows + [book(30, ask=1)], at=30)["status"] == "ALLOW"
    assert review(rows + [book(30, ask=1), book(40)], at=40)["status"] == "ALLOW"
    assert review(rows, at=51)["status"] == "UNAVAILABLE"
    assert review(rows + [book(100)], at=100)["status"] == "UNAVAILABLE"


def test_future_and_not_yet_available_walls_cannot_be_used():
    rows = [book(0, ask=1), book(10, ask=1), book(20, ask=1)]
    late = [book(0), book(10), book(20)]
    for row in late:
        row["event_id"] += "late"
        row["available_at"] = stamp(21)
    assert review(rows + late + [book(30)])["status"] == "ALLOW"
    assert review(late)["status"] == "UNAVAILABLE"


def test_duplicates_do_not_manufacture_samples_and_feed_is_pinned():
    assert review([book(0), book(0), book(20)])["status"] == "UNAVAILABLE"
    rows = [book(0), book(10), book(20)]
    for row in rows:
        row["venue"] = "OTHER"
    assert review(rows)["status"] == "UNAVAILABLE"
    assert review(rows, policy=DEFAULT_ZONE_POLICY)["status"] == "UNAVAILABLE"


def test_known_gap_blocks_and_future_gap_does_not_leak():
    rows = [book(0), book(10), book(20)]
    gap = event("gap", 10, {"gap_key": "g", "start_at": stamp(5), "end_at": stamp(10)})
    assert review(rows + [gap])["status"] == "UNAVAILABLE"
    gap["available_at"] = stamp(21)
    assert review(rows + [gap])["status"] == "BLOCK"


def test_recovered_transport_gap_requires_observed_completed_bar_coverage():
    rows = supply_rows()
    gap = event("gap", 0, {"gap_key": "initial", "start_at": stamp(-120), "end_at": stamp(-60)})
    result = review(rows + [gap], at=60, liquidity=False, supply_demand=True)
    assert result["status"] == "BLOCK"  # Actual supply zone, not a data-unavailable verdict.
    assert result["evidence"]["supply_demand"]["evidence"][
        "recovered_transport_gaps_covered_by_completed_bars"
    ] == ["initial"]
    incomplete = [r for r in rows if r["event_id"] != rows[1]["event_id"]]
    assert (
        review(incomplete + [gap], at=60, liquidity=False, supply_demand=True)["status"]
        == "UNAVAILABLE"
    )
    gap["payload"]["end_at"] = None
    assert (
        review(rows + [gap], at=60, liquidity=False, supply_demand=True)["status"] == "UNAVAILABLE"
    )


def test_supply_activates_only_after_completed_displacement_is_available():
    rows = supply_rows()
    displacement = rows[2]
    displacement["available_at"] = stamp(5)
    assert review(rows, at=0, liquidity=False, supply_demand=True)["status"] == "UNAVAILABLE"
    result = review(rows, at=60, liquidity=False, supply_demand=True)
    assert result["status"] == "BLOCK"
    zone = result["evidence"]["supply_demand"]["evidence"]["zones"][0]
    assert zone["activated_at"] == stamp(5)
    assert (zone["low"], zone["high"]) == (99.9, 100.1)
    assert review(rows, "PUT", at=60, liquidity=False, supply_demand=True)["status"] == "ALLOW"


def test_supply_invalidation_is_point_in_time_and_survives_price_return():
    rows = supply_rows()
    breaker = bar(120, opening=99.85, close=100.2, high=100.3, low=99.8)
    later = bar(180, opening=100.2, close=100, high=100.3, low=99.9)
    assert (
        review(rows + [breaker, later], at=60, liquidity=False, supply_demand=True)["status"]
        == "BLOCK"
    )
    result = review(rows + [breaker, later], at=180, liquidity=False, supply_demand=True)
    assert result["status"] == "ALLOW"
    assert (
        result["evidence"]["supply_demand"]["evidence"]["zones"][0]["invalidated_by"] == "bar-120"
    )


def test_demand_direction_and_invalidation():
    rows = [
        bar(-120),
        bar(-60),
        bar(0, close=100.5, high=100.6, low=100, volume=500),
        bar(60, opening=100.5, close=100.15, high=100.6, low=100.1),
    ]
    assert review(rows, "PUT", at=60, liquidity=False, supply_demand=True)["status"] == "BLOCK"
    assert review(rows, "CALL", at=60, liquidity=False, supply_demand=True)["status"] == "ALLOW"
    rows.append(bar(120, opening=100.15, close=99.8, high=100.2, low=99.7))
    assert review(rows, "PUT", at=120, liquidity=False, supply_demand=True)["status"] == "ALLOW"


@pytest.mark.parametrize("damage", ["volume", "stale", "gap", "expiry"])
def test_bar_evidence_and_expiry(damage):
    rows = supply_rows()
    policy = dict(POLICY)
    at = 60
    if damage == "volume":
        rows[0]["payload"]["volume"] = None
    elif damage == "stale":
        at = 151
    elif damage == "gap":
        rows.pop(1)
    else:
        policy["zone_max_age_seconds"] = 30
    result = review(rows, at=at, liquidity=False, supply_demand=True, policy=policy)
    assert result["status"] == ("ALLOW" if damage == "expiry" else "UNAVAILABLE")


def test_unavailable_branch_never_looks_supportive_and_disabled_is_explicit():
    result = review([book(0), book(10), book(20)], supply_demand=True)
    assert result["status"] == "UNAVAILABLE"
    assert result["evidence"]["liquidity"]["status"] == "BLOCK"
    assert review([], liquidity=False)["evidence"]["liquidity"]["status"] == "DISABLED"


@pytest.mark.parametrize(
    "field,value",
    [
        ("wall_min_samples", True),
        ("wall_min_samples", 1),
        ("wall_min_duration_seconds", 0),
        ("wall_min_depth_fraction", 1.1),
        ("bar_max_age_seconds", float("nan")),
        ("bar_source", ""),
        ("displacement_lookback_bars", 2.5),
        ("displacement_volume_multiple", 1),
        ("typo", 2),
    ],
)
def test_policy_thresholds_are_validated(field, value):
    with pytest.raises(ValueError):
        review([], policy={**POLICY, field: value})


def test_naive_time_is_rejected_and_prior_session_is_excluded():
    with pytest.raises(ValueError):
        zone_review(
            [],
            "SPY",
            "CALL",
            NOW.replace(tzinfo=None),
            liquidity=True,
            supply_demand=False,
            policy=POLICY,
        )
    rows = [book(0), book(10), book(20)]
    assert review(rows, at=86420)["status"] == "UNAVAILABLE"
