import subprocess
from datetime import UTC, datetime
from pathlib import Path

from tools.market_intelligence import (
    collect_agent_reach_social,
    collect_broad_news,
    collect_market_intelligence,
)


def test_broad_news_first_item_wakes_once(tmp_path: Path) -> None:
    now = datetime(2026, 8, 24, 13, 30, tzinfo=UTC)

    def fetcher(label: str, query: str) -> list[dict[str, str]]:
        return [
            {
                "channel": label,
                "title": f"Material {label} headline",
                "link": f"https://example.test/{label}",
                "published": now.isoformat(),
                "source": "Fixture Wire",
            }
        ]

    state = tmp_path / "news.json"
    first = collect_broad_news(state_path=state, fetcher=fetcher, now=now)
    second = collect_broad_news(state_path=state, fetcher=fetcher, now=now)

    assert first["status"] == "NEW_ITEMS"
    assert first["wake_luna"] is True
    assert len(first["new_items"]) == 3
    assert {item["channel"] for item in first["new_items"]} == {
        "earnings",
        "macro",
        "market",
    }
    assert second["status"] == "QUIET"
    assert second["wake_luna"] is False


def test_social_fails_closed_when_agent_reach_has_no_backend(tmp_path: Path) -> None:
    capabilities = {
        "channels": {
            "twitter": {"active_backend": None},
            "reddit": {"active_backend": None},
        }
    }
    result = collect_agent_reach_social(
        capabilities,
        state_path=tmp_path / "social.json",
        enabled=True,
        environ={},
    )

    assert result["status"] == "UNAVAILABLE"
    assert result["wake_luna"] is False
    assert result["unavailable_channels"] == ["twitter", "reddit"]
    assert not (tmp_path / "social.json").exists()


def test_social_uses_connected_opencli_before_platform_is_verified(
    tmp_path: Path, monkeypatch
) -> None:
    capabilities = {
        "opencli_connected": True,
        "channels": {
            "twitter": {"active_backend": None, "backends": ["OpenCLI"]},
            "reddit": {"active_backend": None, "backends": ["OpenCLI"]},
        },
    }
    monkeypatch.setattr(
        "tools.market_intelligence.shutil.which",
        lambda executable: "C:/opencli.cmd" if executable == "opencli" else None,
    )

    def runner(command, **kwargs):
        return subprocess.CompletedProcess(command, 0, stdout="one result", stderr="")

    result = collect_agent_reach_social(
        capabilities,
        state_path=tmp_path / "social.json",
        enabled=True,
        runner=runner,
        environ={},
    )

    assert result["status"] == "NEW_ITEMS"
    assert result["wake_luna"] is True
    assert len(result["results"]) == 2
    assert {(item["channel"], item["backend"]) for item in result["results"]} == {
        ("twitter", "OpenCLI"),
        ("reddit", "OpenCLI"),
    }
    assert result["unavailable_channels"] == []


def test_social_digest_ignores_volatile_engagement_counts(tmp_path: Path, monkeypatch) -> None:
    capabilities = {
        "opencli_connected": True,
        "channels": {
            "twitter": {"active_backend": None, "backends": ["OpenCLI"]},
            "reddit": {"active_backend": None, "backends": ["OpenCLI"]},
        },
    }
    monkeypatch.setattr(
        "tools.market_intelligence.shutil.which",
        lambda executable: "C:/opencli.cmd" if executable == "opencli" else None,
    )
    views = iter(("10", "20", "11", "21"))

    def runner(command, **kwargs):
        identifier = "tweet-1" if "twitter" in command else "reddit-1"
        return subprocess.CompletedProcess(
            command,
            0,
            stdout=f"- id: '{identifier}'\n  views: '{next(views)}'",
            stderr="",
        )

    state = tmp_path / "social.json"
    first = collect_agent_reach_social(
        capabilities,
        state_path=state,
        enabled=True,
        runner=runner,
        environ={},
    )
    second = collect_agent_reach_social(
        capabilities,
        state_path=state,
        enabled=True,
        runner=runner,
        environ={},
    )

    assert first["status"] == "NEW_ITEMS"
    assert second["status"] == "QUIET"
    assert second["wake_luna"] is False


def test_market_intelligence_reports_observed_social_backends(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    monkeypatch.setattr(
        "tools.market_intelligence.collect_broad_news",
        lambda **kwargs: {"status": "QUIET", "wake_luna": False, "new_items": []},
    )
    monkeypatch.setattr(
        "tools.market_intelligence.agent_reach_capabilities",
        lambda **kwargs: {
            "status": "OK",
            "cached": True,
            "opencli_connected": True,
            "channels": {
                "twitter": {"active_backend": None},
                "reddit": {"active_backend": None},
            },
        },
    )
    monkeypatch.setattr(
        "tools.market_intelligence.collect_agent_reach_social",
        lambda capabilities, **kwargs: {
            "status": "NEW_ITEMS",
            "wake_luna": True,
            "results": [
                {
                    "channel": "twitter",
                    "backend": "OpenCLI",
                    "status": "OK",
                    "output": "x result",
                },
                {
                    "channel": "reddit",
                    "backend": "OpenCLI",
                    "status": "OK",
                    "output": "reddit result",
                },
            ],
        },
    )

    result = collect_market_intelligence(
        resolved_config,
        runtime_dir=tmp_path,
        commit=False,
    )

    assert result["agent_reach"]["twitter_available"] is True
    assert result["agent_reach"]["reddit_available"] is True
    assert result["agent_reach"]["twitter_backend"] == "OpenCLI"
    assert result["agent_reach"]["reddit_backend"] == "OpenCLI"
    assert result["agent_reach"]["doctor_twitter_backend"] is None
    assert result["agent_reach"]["doctor_reddit_backend"] is None
