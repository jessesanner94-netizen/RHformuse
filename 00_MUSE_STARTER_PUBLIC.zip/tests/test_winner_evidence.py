from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from tools.winner_evidence import collect_winner_evidence

NOW = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)


def _position(*, option_type: str = "CALL", checkpoint: bool = True) -> dict[str, Any]:
    return {
        "paper_id": "paper-1",
        "contract_identifier": "contract-1",
        "symbol": "SPY",
        "option_type": option_type,
        "take_profit_price": 1.3,
        "thesis": "Momentum persists.",
        "invalidation": "Close below the opening-range low.",
        "winner_management": {"enabled": True, "checkpoint_reached": checkpoint},
    }


def _snapshot(
    *, five: str = "BULLISH", structure: str = "NEUTRAL", fifteen: str = "BEARISH"
) -> dict[str, Any]:
    return {
        "status": "OK",
        "symbol": "SPY",
        "as_of": NOW.isoformat(),
        "timeframes": {
            "5M": {"status": "OK", "trend": five, "trend_score": 2},
            "15M": {"status": "OK", "trend": fifteen, "trend_score": -2},
        },
        "intraday_structure": {
            "status": "OK",
            "bias": structure,
            "bias_score": 0,
            "session_date": "2026-09-24",
            "entry_timing": {
                "status": "OK",
                "completed_bar_at": (NOW - timedelta(minutes=5)).isoformat(),
                "completed_bar_age_seconds": 0,
            },
        },
    }


async def _books(symbols, path, *, now):
    assert symbols == ["SPY"]
    return {
        "status": "OK",
        "summaries": {
            "SPY": {
                "status": "OK",
                "updated_at": now.isoformat(),
                "features": {
                    "near_imbalance": 0.2,
                    "best_bid": {"price": 500, "quantity": 10},
                    "best_ask": {"price": 500.01, "quantity": 8},
                    "microprice": 500.006,
                    "mid": 500.005,
                },
            }
        },
    }


def test_one_aligned_intraday_signal_is_intact_and_15m_cannot_veto(tmp_path: Path) -> None:
    seen: dict[str, Any] = {}

    def technical(symbol, *, project_root, timeout, intraday_only):
        seen.update(
            {
                "symbol": symbol,
                "project_root": project_root,
                "timeout": timeout,
                "intraday_only": intraday_only,
            }
        )
        return _snapshot()

    result = asyncio.run(
        collect_winner_evidence(
            [_position()],
            {"contract-1": {"bid_price": "1.30"}},
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            orderbook_collector=_books,
        )
    )

    evidence = result["SPY"]
    assert seen == {
        "symbol": "SPY",
        "project_root": tmp_path,
        "timeout": 12.0,
        "intraday_only": True,
    }
    assert evidence["status"] == "INTACT"
    assert "five_minute_direction_aligned" in evidence["reasons"]
    assert "fifteen_minute_opposing_nonveto" in evidence["reasons"]
    assert evidence["evidence"]["orderbook"]["direction_context"] == "BULLISH"
    assert evidence["evidence"]["orderbook"]["executed_trade_prints"]["status"] == "UNAVAILABLE"
    assert evidence["evidence"]["thesis_context"]["interpretation"].startswith("free_text")


def test_explicit_required_intraday_opposition_is_broken(tmp_path: Path) -> None:
    def technical(*args, **kwargs):
        return _snapshot(five="BEARISH", structure="BULLISH")

    result = asyncio.run(
        collect_winner_evidence(
            [_position()],
            {"contract-1": {"bid_price": "1.30"}},
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            orderbook_collector=_books,
        )
    )

    assert result["SPY"]["status"] == "BROKEN"
    assert result["SPY"]["reasons"] == ["five_minute_direction_opposes_option"]


def test_both_neutral_required_signals_are_unavailable(tmp_path: Path) -> None:
    def technical(*args, **kwargs):
        return _snapshot(five="NEUTRAL", structure="NEUTRAL", fifteen="BULLISH")

    result = asyncio.run(
        collect_winner_evidence(
            [_position()],
            {"contract-1": {"bid_price": "1.30"}},
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            orderbook_collector=_books,
        )
    )

    assert result["SPY"]["status"] == "UNAVAILABLE"
    assert result["SPY"]["reasons"] == ["intraday_directions_neutral"]


def test_only_target_or_checkpoint_positions_trigger_collection(tmp_path: Path) -> None:
    calls: list[str] = []

    def technical(symbol, **kwargs):
        calls.append(symbol)
        return _snapshot()

    below_target = _position(checkpoint=False)
    result = asyncio.run(
        collect_winner_evidence(
            [below_target],
            {"contract-1": {"bid_price": "1.29"}},
            project_root=tmp_path,
            now=NOW,
            technical_fetcher=technical,
            orderbook_collector=_books,
        )
    )

    assert result == {}
    assert calls == []
