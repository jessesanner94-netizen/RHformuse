"""Synthetic paper hypotheses; these tests do not establish a market edge."""

import copy
from datetime import UTC, datetime, timedelta

import pytest

from research.options_lab.depth_exits import depth_exit_review

NOW = datetime(2026, 10, 23, 15, tzinfo=UTC)


def position(side="CALL"):
    return {
        "symbol": "SPY",
        "option_type": side,
        "paper_id": "test",
        "contract_identifier": "contract",
        "entry_at": (NOW - timedelta(seconds=60)).isoformat(),
        "quantity": 1,
        "entry_cost": 110.0,
        "entry_cost_estimate": 1.05,
        "exit_cost_estimate": 1.05,
    }


def quote(bid=1.35, at=NOW):
    return {
        "instrument_id": "contract",
        "bid_price": str(bid),
        "ask_price": str(bid + 0.02),
        "updated_at": at.isoformat(),
    }


def books(direction="UP"):
    rows = []
    for offset in range(-170, 1, 10):
        at = NOW + timedelta(seconds=offset)
        surge = offset >= -10
        mid = 500 + ((0.2 if direction == "UP" else -0.2) if surge else 0)
        stamp = at.isoformat()
        bid_size = 500 if surge and direction == "UP" else 40
        ask_size = 500 if surge and direction == "DOWN" else 40
        rows.append(
            {
                "schema_version": 1,
                "kind": "book",
                "source": "robinhood",
                "venue": "UNSPECIFIED",
                "symbol": "SPY",
                "event_id": stamp,
                "event_at": stamp,
                "received_at": stamp,
                "available_at": stamp,
                "payload": {
                    "symbol": "SPY",
                    "updated_at": stamp,
                    "bids": [
                        {"price": mid - 0.01 - i * 0.01, "quantity": bid_size} for i in range(5)
                    ],
                    "asks": [
                        {"price": mid + 0.01 + i * 0.01, "quantity": ask_size} for i in range(5)
                    ],
                },
            }
        )
    return rows


@pytest.mark.parametrize(
    "side,direction,action",
    [
        ("CALL", "UP", "TAKE_PROFIT"),
        ("PUT", "DOWN", "TAKE_PROFIT"),
        ("CALL", "DOWN", "DEFENSIVE_EXIT"),
        ("PUT", "UP", "DEFENSIVE_EXIT"),
    ],
)
def test_direction_mapping(side, direction, action):
    result = depth_exit_review(books(direction), position(side), quote(), NOW)
    assert result["status"] == "OK" and result["action"] == action
    assert result["evidence"]["executed_volume_available"] is False


@pytest.mark.parametrize(
    "bid,action", [(1.34, "HOLD"), (1.341, "TAKE_PROFIT"), (1.35, "TAKE_PROFIT")]
)
def test_exact_twenty_percent_net_floor_includes_both_costs(bid, action):
    result = depth_exit_review(books(), position(), quote(bid), NOW)
    assert result["action"] == action
    assert result["evidence"]["minimum_net_profit_dollars"] == 22


@pytest.mark.parametrize("bid", [0.9, 1.1, 1.25])
def test_adverse_pressure_can_exit_red_flat_or_green(bid):
    result = depth_exit_review(books("DOWN"), position(), quote(bid), NOW)
    assert result["action"] == "DEFENSIVE_EXIT"


def test_one_snapshot_spike_and_size_without_price_confirmation_do_not_exit():
    rows = books()
    rows[-2] = copy.deepcopy(rows[-3])
    rows[-2].update(
        {
            k: (NOW - timedelta(seconds=10)).isoformat()
            for k in ["event_id", "event_at", "received_at", "available_at"]
        }
    )
    rows[-2]["payload"]["updated_at"] = rows[-2]["event_at"]
    assert depth_exit_review(rows, position(), quote(), NOW)["action"] == "HOLD"
    rows = books()
    for row in rows[-2:]:
        for name in ["bids", "asks"]:
            for level in row["payload"][name]:
                level["price"] -= 0.2
    assert depth_exit_review(rows, position(), quote(), NOW)["action"] == "HOLD"


def test_persistent_third_snapshot_still_qualifies():
    rows = books()
    next_row = copy.deepcopy(rows[-1])
    at = NOW + timedelta(seconds=10)
    for key in ["event_id", "event_at", "received_at", "available_at"]:
        next_row[key] = at.isoformat()
    next_row["payload"]["updated_at"] = at.isoformat()
    assert (
        depth_exit_review([*rows, next_row], position(), quote(at=at), at)["action"]
        == "TAKE_PROFIT"
    )


@pytest.mark.parametrize(
    "change",
    [
        "future",
        "stale",
        "gap",
        "duplicate",
        "wrong_source",
        "crossed",
        "missing_side",
        "old_position_confirmation",
    ],
)
def test_unusable_evidence_or_predating_confirmation_never_exits(change):
    rows = books()
    held = position()
    now = NOW
    if change == "future":
        for row in rows[-2:]:
            row["available_at"] = (NOW + timedelta(seconds=1)).isoformat()
    elif change == "stale":
        now += timedelta(seconds=21)
    elif change == "gap":
        rows = rows[:8] + rows[12:]
    elif change == "duplicate":
        bad = copy.deepcopy(rows[-1])
        bad["payload"]["bids"][0]["quantity"] += 1
        rows.append(bad)
    elif change == "wrong_source":
        for row in rows:
            row["source"] = "other"
    elif change == "crossed":
        rows[-1]["payload"]["bids"][0]["price"] = 999
    elif change == "missing_side":
        rows[-1]["payload"]["asks"] = []
    elif change == "old_position_confirmation":
        held["entry_at"] = (NOW - timedelta(seconds=5)).isoformat()
    assert depth_exit_review(rows, held, quote(), now)["action"] == "HOLD"


@pytest.mark.parametrize(
    "change", ["old", "future", "before_signal", "wrong_contract", "crossed", "nan"]
)
def test_exit_quote_must_be_fresh_and_after_signal(change):
    market = quote()
    if change == "old":
        market["updated_at"] = (NOW - timedelta(seconds=21)).isoformat()
    elif change == "future":
        market["updated_at"] = (NOW + timedelta(seconds=1)).isoformat()
    elif change == "before_signal":
        market["updated_at"] = (NOW - timedelta(seconds=1)).isoformat()
    elif change == "wrong_contract":
        market["instrument_id"] = "other"
    elif change == "crossed":
        market["ask_price"] = ".01"
    elif change == "nan":
        market["bid_price"] = "nan"
    result = depth_exit_review(books(), position(), market, NOW)
    assert result["status"] == "UNAVAILABLE" and result["action"] == "HOLD"


def test_duplicate_identical_books_do_not_manufacture_persistence():
    rows = [books()[-1]] * 20
    assert depth_exit_review(rows, position(), quote(), NOW)["action"] == "HOLD"


def test_current_session_and_explicit_transport_gap_are_required():
    rows = books()
    gap = copy.deepcopy(rows[3])
    gap["kind"] = "gap"
    gap["payload"] = {"gap_key": "lost-depth", "start_at": gap["event_at"], "end_at": None}
    assert depth_exit_review([*rows, gap], position(), quote(), NOW)["reason"] == "book_data_gap"
    for row in rows:
        for key in ["event_at", "received_at", "available_at"]:
            row[key] = (datetime.fromisoformat(row[key]) - timedelta(days=1)).isoformat()
        row["payload"]["updated_at"] = row["event_at"]
    assert depth_exit_review(rows, position(), quote(), NOW)["status"] == "UNAVAILABLE"


def test_close_adapter_rejects_live_mode_and_changed_or_aged_quote(resolved_config, monkeypatch):
    from research.options_lab.depth_exits import close_depth_exit
    from tools.config import TradingConfig

    monkeypatch.setattr(
        "tools.paper_trading.close_paper_position",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("No exit should be committed")),
    )
    held, market = position(), quote()
    review = depth_exit_review(books(), held, market, NOW)
    live = TradingConfig({**resolved_config.values, "LIVE_EXECUTION_ENABLED": True})
    assert not close_depth_exit(review, held, market, config=live, paths={}, now=NOW)["closed"]
    market["bid_price"] = "1.34"
    assert not close_depth_exit(review, held, market, config=resolved_config, paths={}, now=NOW)[
        "closed"
    ]
    assert not close_depth_exit(
        review, held, quote(), config=resolved_config, paths={}, now=NOW + timedelta(seconds=21)
    )["closed"]
