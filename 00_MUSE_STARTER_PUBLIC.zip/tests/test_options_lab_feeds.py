import asyncio
import sqlite3
import threading
import time
from datetime import UTC, datetime, timedelta
from email.utils import format_datetime

from research.options_lab.event_tape import SessionTape
from research.options_lab.forward_feeds import FED_RSS, ForwardFeeds, classify_news


class Clock:
    now = datetime(2026, 10, 21, 15, 0, tzinfo=UTC)

    def __call__(self):
        return self.now


def run(coro):
    return asyncio.run(coro)


def rows(tape, clock):
    return tape.observations("SPY", as_of=clock())


def book(clock):
    return {"symbol": "SPY", "updated_at": clock().isoformat(),
            "bids": [{"price": "600", "quantity": "20"},
                     {"price": "599", "quantity": "40"}],
            "asks": [{"price": "601", "quantity": "30"},
                     {"price": "602", "quantity": "50"}]}


def test_batched_full_depth_and_gap_recovery(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    calls = []

    async def fetch(symbols):
        calls.append(symbols)
        return {"books": [book(clock)]}

    feeds = ForwardFeeds(tape, ["SPY", "QQQ"], book_fetcher=fetch, clock=clock)
    status = run(feeds.poll_books())
    assert calls == [["SPY", "QQQ"]]
    assert status["symbols"]["SPY"]["status"] == "OK"
    stored = rows(tape, clock)[0]
    assert stored["source"] == "robinhood" and stored["venue"] == "UNSPECIFIED"
    assert len(stored["payload"]["bids"]) == 2
    assert stored["event_at"] == book(clock)["updated_at"]
    assert not any(r["kind"] == "trade" for r in rows(tape, clock))
    # Bad book opens a stable gap; restart and recovery close that same identity.
    async def bad(_):
        raise OSError("network")
    feeds.book_fetcher = bad
    run(feeds.poll_books())
    clock.now += timedelta(seconds=10)
    feeds = ForwardFeeds(tape, ["SPY"], book_fetcher=fetch, clock=clock)
    run(feeds.poll_books())
    gaps = [r["payload"] for r in rows(tape, clock) if r["kind"] == "gap"]
    assert len(gaps) == 2
    assert gaps[0]["gap_key"] == gaps[1]["gap_key"]
    assert gaps[0]["end_at"] is None and gaps[1]["end_at"] == clock().isoformat()


def test_book_timeout_is_bounded(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    async def slow(_):
        await asyncio.sleep(1)
    feeds = ForwardFeeds(tape, ["SPY"], book_fetcher=slow, clock=clock,
                         timeout_seconds=.001)
    assert run(feeds.poll_books())["symbols"]["SPY"]["reason"] == "TimeoutError"
    assert rows(tape, clock)[0]["kind"] == "gap"


def chart(clock):
    epochs = [(clock() - timedelta(minutes=m)).timestamp() for m in (3, 2, 1, 0)]
    return {"chart": {"result": [{"meta": {"symbol": "SPY"}, "timestamp": epochs,
            "indicators": {"quote": [{"open": [600, 600, None, 600],
            "close": [601, 601, 601, 601], "low": [599] * 4, "high": [602] * 4,
            "volume": [12, None, 99, 100]}]}}]}}


def test_only_actual_completed_ohlcv_receipt_availability(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    feeds = ForwardFeeds(tape, ["SPY"], bar_fetcher=lambda _: chart(clock), clock=clock)
    assert run(feeds.poll_context())["symbols"]["SPY"]["inserted"] == 1
    stored = [r for r in rows(tape, clock) if r["kind"] == "bar"]
    assert len(stored) == 1
    assert stored[0]["payload"]["volume"] == 12
    assert stored[0]["available_at"] == clock().isoformat()
    assert stored[0]["source"] == "yahoo"
    assert stored[0]["venue"] == "CONSOLIDATED_UNVERIFIED"
    assert run(feeds.poll_context())["symbols"]["SPY"]["inserted"] == 0


def article(clock, **changes):
    return {"title": "Federal Reserve issues FOMC statement", "source": "Federal Reserve Board",
            "link": "https://news.google.com/rss/articles/example",
            "published": format_datetime(clock() - timedelta(seconds=30)), **changes}


def test_aggregator_unverified_primary_provenance_direction_unknown():
    clock = Clock()
    classified = classify_news(article(clock), "google_news")
    assert not classified["verified"] and classified["material"]
    assert classified["direction"] == "UNKNOWN"
    primary = article(clock, link="https://www.federalreserve.gov/newsevents/pressreleases/monetary.htm",
                      primary_feed=FED_RSS)
    classified = classify_news(primary, "federal_reserve")
    assert classified["verified"] and classified["material"]
    assert classified["direction"] == "UNKNOWN"
    assert not classified["semantic_direction_verified"]
    spoofed = {**primary, "link": "https://www.federalreserve.gov.evil.test/newsevents/pressreleases/a"}
    assert not classify_news(spoofed, "federal_reserve")["verified"]


def test_news_dedup_restart_revision_keeps_first_publication(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    item = article(clock)
    def fetch(channel):
        return [dict(item)] if channel == "google_news" else []
    feeds = ForwardFeeds(tape, ["SPY"], news_fetcher=fetch, clock=clock)
    assert run(feeds.poll_news())["status"] == "OK"
    assert len(rows(tape, clock)) == 1
    first = rows(tape, clock)[0]
    clock.now += timedelta(seconds=30)
    feeds = ForwardFeeds(tape, ["SPY"], news_fetcher=fetch, clock=clock)
    run(feeds.poll_news())
    assert len(rows(tape, clock)) == 1
    item.update(title="Federal Reserve issues corrected FOMC statement",
                published=format_datetime(clock()))
    run(feeds.poll_news())
    news = rows(tape, clock)
    assert len(news) == 2
    assert news[-1]["payload"]["supersedes_event_id"] == first["event_id"]
    assert news[-1]["event_at"] == first["event_at"]
    assert news[-1]["payload"]["event_key"] == first["payload"]["event_key"]


def test_unrelated_earnings_not_ingested(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, news_fetcher=lambda _: [
        article(clock, title="Small biotech reports earnings beat")])
    run(feeds.poll_news())
    assert rows(tape, clock) == []


def test_startup_reads_only_current_session_identity_kinds(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    async def fetch(_):
        return {"books": [book(clock)]}
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, book_fetcher=fetch)
    run(feeds.poll_books())
    run(feeds._gap("google_news", "UNSPECIFIED", "SPY", "test_failure"))
    # Corrupt full-book and historical records deliberately: constructor must not
    # read/decode them. They remain on disk instead of being deleted or retained in RAM.
    with sqlite3.connect(tape.path) as con:
        con.execute("UPDATE events SET record='not-json' WHERE kind='book'")
        con.execute("INSERT INTO events SELECT '2026-10-20',source,venue,symbol,kind,"
                    "event_id,event_epoch,available_epoch,identity_hash,'not-json' "
                    "FROM events WHERE kind='gap'")
    recovered = ForwardFeeds(tape, ["SPY"], clock=clock)
    assert ("google_news", "SPY") in recovered.gaps
    assert recovered.bar_hashes == {}


def test_bar_corrections_explicitly_counted_keep_first_observation(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    data = chart(clock)
    async def fetch(_):
        return data
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=fetch)
    assert run(feeds.poll_context())["status"] == "OK"
    data["chart"]["result"][0]["indicators"]["quote"][0]["volume"][0] = 15
    # Restore baseline fingerprints from only the current session across restart.
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=fetch)
    status = run(feeds.poll_context())
    assert status["symbols"]["SPY"]["ignored_revisions"] == 1
    assert status["bar_revision_policy"] == "FIRST_OBSERVATION_IMMUTABLE_CORRECTIONS_COUNTED"
    assert [r["payload"]["volume"] for r in rows(tape, clock) if r["kind"] == "bar"] == [12]


def test_top_level_source_failure_status(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    async def fail(_):
        raise OSError("test")
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, book_fetcher=fail, bar_fetcher=fail)
    assert run(feeds.poll_books())["status"] == "UNAVAILABLE"
    assert run(feeds.poll_context())["status"] == "UNAVAILABLE"


def test_large_initial_batches_do_not_block_other_coroutines(tmp_path, monkeypatch):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    clock.now = datetime(2026, 10, 21, 17, 0, tzinfo=UTC)
    original_ingest, calls = tape.ingest, []
    disk_active = threading.Event()
    def delayed_ingest(events):
        calls.append((events[0]["kind"], len(events)))
        disk_active.set()
        try:
            time.sleep(.08)  # Simulate expensive fsync, never in the event loop.
            return original_ingest(events)
        finally:
            disk_active.clear()
    monkeypatch.setattr(tape, "ingest", delayed_ingest)
    async def bars(_):
        return {"chart": {"result": [{"timestamp": [
            (clock() - timedelta(minutes=m)).timestamp() for m in range(120, 0, -1)],
            "indicators": {"quote": [{"open": [600] * 120, "high": [602] * 120,
            "low": [599] * 120, "close": [601] * 120, "volume": [100] * 120}]}}]}}
    async def news(channel):
        return [article(clock, link=f"https://news.google.com/rss/articles/{n}",
                        title=f"Federal Reserve emergency statement {n}") for n in range(20)
                ] if channel == "google_news" else []
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=bars, news_fetcher=news)
    async def exercise():
        ticks = 0
        task = asyncio.gather(feeds.poll_context(), feeds.poll_news())
        while not task.done():
            await asyncio.sleep(.005)
            ticks += int(disk_active.is_set())
        await task
        return ticks
    assert run(exercise()) >= 5
    assert sorted(calls) == [("bar", 120), ("news", 20)]
    assert len(feeds.bar_hashes) == 120 and len(feeds.articles) == 20


def test_failed_batch_does_not_claim_committed_bar_identity(tmp_path, monkeypatch):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    original_ingest = tape.ingest
    def reject_bars(events):
        if events[0]["kind"] == "bar":
            raise OSError("simulated disk error")
        return original_ingest(events)
    monkeypatch.setattr(tape, "ingest", reject_bars)
    async def fetch(_):
        return chart(clock)
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=fetch)
    assert run(feeds.poll_context())["status"] == "UNAVAILABLE"
    assert feeds.bar_hashes == {}
    assert not any(r["kind"] == "bar" for r in rows(tape, clock))


def test_large_book_captures_explicit_provider_ordered_prefix(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    raw = {"symbol": "SPY", "updated_at": clock().isoformat(),
           "bids": [{"price": 600 - i / 100, "quantity": 20} for i in range(4374)],
           "asks": [{"price": 601 + i / 100, "quantity": 30} for i in range(1397)]}
    async def fetch(_):
        return {"books": [raw]}
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, book_fetcher=fetch)
    assert run(feeds.poll_books())["status"] == "OK"
    stored = rows(tape, clock)[0]["payload"]
    assert stored["bids"] == raw["bids"][:1000]
    assert stored["asks"] == raw["asks"][:1000]
    assert stored["depth_capture"] == {
        "original_counts": {"bids": 4374, "asks": 1397},
        "captured_counts": {"bids": 1000, "asks": 1000}, "truncated": True,
        "policy": "FIRST_1000_PROVIDER_ORDERED_LEVELS_PER_SIDE",
        "omitted_levels_archived": False}
    assert len(raw["bids"]) == 4374  # Original provider object is not mutated.


def test_large_book_malformed_prefix_still_rejected(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    raw = {"symbol": "SPY", "updated_at": clock().isoformat(),
           "bids": [{"price": 600 - i / 100, "quantity": 20} for i in range(1100)],
           "asks": [{"price": 601 + i / 100, "quantity": 30} for i in range(1100)]}
    raw["bids"][1], raw["bids"][2] = raw["bids"][2], raw["bids"][1]
    async def fetch(_):
        return {"books": [raw]}
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, book_fetcher=fetch)
    assert run(feeds.poll_books())["status"] == "UNAVAILABLE"
    assert not any(r["kind"] == "book" for r in rows(tape, clock))


def bars_at(starts):
    return {"chart": {"result": [{"meta": {"symbol": "SPY"},
        "timestamp": [s.timestamp() for s in starts], "indicators": {"quote": [{
            "open": [600] * len(starts), "high": [602] * len(starts),
            "low": [599] * len(starts), "close": [601] * len(starts),
            "volume": [100] * len(starts)}]}}]}}


def test_opening_warmup_has_no_fake_gap_and_first_completed_bar_recovers(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    opening = datetime(2026, 10, 22, 13, 30, tzinfo=UTC)
    clock.now = opening + timedelta(seconds=23)
    async def fetch(_):
        return bars_at([opening])
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=fetch)
    assert run(feeds.poll_context())["status"] == "WARMUP"
    assert rows(tape, clock) == []
    clock.now = opening + timedelta(seconds=83)
    assert run(feeds.poll_context())["status"] == "OK"
    assert [r["kind"] for r in rows(tape, clock)] == ["bar"]


def test_true_http_failure_during_warmup_stays_gap_until_completed_bar(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    opening = datetime(2026, 10, 22, 13, 30, tzinfo=UTC)
    clock.now = opening + timedelta(seconds=10)
    async def fail(_):
        raise OSError("HTTP failure")
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=fail)
    assert run(feeds.poll_context())["status"] == "UNAVAILABLE"
    async def fetch(_):
        return bars_at([opening])
    feeds.bar_fetcher = fetch
    clock.now = opening + timedelta(seconds=30)
    assert run(feeds.poll_context())["status"] == "WARMUP"
    assert len(rows(tape, clock)) == 1
    assert rows(tape, clock)[0]["payload"]["end_at"] is None
    clock.now = opening + timedelta(seconds=83)
    assert run(feeds.poll_context())["status"] == "OK"
    gaps = [r for r in rows(tape, clock) if r["kind"] == "gap"]
    assert len(gaps) == 2
    assert gaps[0]["payload"]["gap_key"] == gaps[1]["payload"]["gap_key"]
    assert gaps[1]["payload"]["end_at"] == clock().isoformat()
    assert sum(r["kind"] == "bar" for r in rows(tape, clock)) == 1


def test_after_first_minute_missing_bar_and_invalid_chart_are_failures(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    opening = datetime(2026, 10, 22, 13, 30, tzinfo=UTC)
    clock.now = opening + timedelta(seconds=61)
    async def absent(_):
        return bars_at([opening - timedelta(days=1)])
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=absent)
    assert run(feeds.poll_context())["status"] == "UNAVAILABLE"
    assert not any(r["kind"] == "bar" for r in rows(tape, clock))
    clock.now = opening + timedelta(seconds=20)
    async def invalid(_):
        data = bars_at([opening])
        data["chart"]["result"][0]["indicators"]["quote"][0]["volume"] = []
        return data
    # Separate tape avoids using a clock before a previously recorded gap.
    feeds = ForwardFeeds(SessionTape(tmp_path / "invalid.sqlite"), ["SPY"],
                         clock=clock, bar_fetcher=invalid)
    assert run(feeds.poll_context())["status"] == "UNAVAILABLE"


def test_preopen_warmup_and_calendar_early_close_filter_prior_or_extended_bars(tmp_path):
    clock, tape = Clock(), SessionTape(tmp_path / "tape.sqlite")
    opening = datetime(2026, 11, 27, 14, 30, tzinfo=UTC)
    clock.now = opening - timedelta(minutes=10)
    data = bars_at([opening - timedelta(days=1), opening - timedelta(minutes=2)])
    async def fetch(_):
        return data
    feeds = ForwardFeeds(tape, ["SPY"], clock=clock, bar_fetcher=fetch)
    assert run(feeds.poll_context())["status"] == "WARMUP"
    assert rows(tape, clock) == []
    # NYSE closes at 18:00 UTC (13:00 ET) on this actual early-close date.
    close = datetime(2026, 11, 27, 18, 0, tzinfo=UTC)
    clock.now = close + timedelta(minutes=2)
    data = bars_at([opening - timedelta(days=1), opening - timedelta(minutes=1),
                    close - timedelta(minutes=1), close])
    assert run(feeds.poll_context())["status"] == "OK"
    stored = rows(tape, clock)
    assert len(stored) == 1
    assert stored[0]["payload"]["start_at"] == (close - timedelta(minutes=1)).isoformat()
