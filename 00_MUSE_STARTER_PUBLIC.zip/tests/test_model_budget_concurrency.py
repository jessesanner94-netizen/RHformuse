"""The daily model-call cap must survive separate scheduled Python processes."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import pytest

from tools.decision_context import model_call_budget_status, reserve_model_call
from tools.runtime_lock import RuntimeLockUnavailable, advisory_file_lock

NOW = datetime(2026, 9, 18, 14, 0, tzinfo=UTC)
RESERVE_SCRIPT = """
import json
import sys
import time
from datetime import datetime
from pathlib import Path
import tools.decision_context as context

original_write = context.guarded_json_update
def delayed_write(*args, **kwargs):
    time.sleep(0.25)
    return original_write(*args, **kwargs)
context.guarded_json_update = delayed_write

result = context.reserve_model_call(
    Path(sys.argv[1]), maximum_calls=int(sys.argv[2]),
    now=datetime.fromisoformat(sys.argv[3]), packet_signature=sys.argv[4],
)
print(json.dumps(result))
"""
HOLD_SCRIPT = """
import sys
import time
from pathlib import Path
from tools.runtime_lock import advisory_file_lock

with advisory_file_lock(Path(sys.argv[1])):
    Path(sys.argv[2]).write_text("locked", encoding="utf-8")
    time.sleep(1)
"""


def test_separate_processes_cannot_exceed_model_call_limit(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"
    maximum = 3
    processes = [
        subprocess.Popen(
            [sys.executable, "-c", RESERVE_SCRIPT, str(budget), str(maximum), NOW.isoformat(),
             f"packet-{number}"],
            cwd=Path(__file__).resolve().parents[1],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        for number in range(8)
    ]
    results = []
    try:
        for process in processes:
            stdout, stderr = process.communicate(timeout=25)
            assert process.returncode == 0, stderr
            results.append(json.loads(stdout))
    finally:
        for process in processes:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)

    assert [item["status"] for item in results].count("RESERVED") == maximum
    assert [item["status"] for item in results].count("BLOCKED") == 5
    assert json.loads(budget.read_text(encoding="utf-8"))["calls_reserved"] == maximum
    assert model_call_budget_status(budget, maximum_calls=maximum, now=NOW)["status"] == "EXHAUSTED"


@pytest.mark.parametrize(
    "content",
    [
        "{bad json",
        "[]",
        '{"date":"2026-09-18","calls_reserved":1}',
        '{"date":"2026-09-18","calls_reserved":true,"maximum_calls":3}',
        '{"date":"2026-09-18","calls_reserved":-1,"maximum_calls":3}',
        '{"date":"2026-09-18","calls_reserved":1,"maximum_calls":0}',
        '{"date":"2026-09-18","calls_reserved":4,"maximum_calls":3}',
        '{"date":"2026-09-99","calls_reserved":1,"maximum_calls":3}',
    ],
)
def test_corrupt_budget_blocks_without_overwriting_state(tmp_path: Path, content: str) -> None:
    budget = tmp_path / "model_budget.json"
    budget.write_text(content, encoding="utf-8")

    status = model_call_budget_status(budget, maximum_calls=3, now=NOW)
    reservation = reserve_model_call(budget, maximum_calls=3, now=NOW, packet_signature="test")

    assert status["status"] == "UNAVAILABLE"
    assert status["reason"] == "model_budget_state_unreadable"
    assert reservation["status"] == "BLOCKED"
    assert reservation["reason"] == "model_budget_state_unreadable"
    assert budget.read_text(encoding="utf-8") == content


def test_invalid_config_limit_blocks_before_file_creation(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"
    assert reserve_model_call(budget, maximum_calls=0, now=NOW, packet_signature="test") == {
        "status": "BLOCKED",
        "reason": "invalid_model_call_limit",
    }
    assert not budget.exists()


def test_lock_contention_times_out_then_recovers(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"
    ready = tmp_path / "holder.ready"
    process = subprocess.Popen(
        [sys.executable, "-c", HOLD_SCRIPT, str(budget), str(ready)],
        cwd=Path(__file__).resolve().parents[1],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        deadline = time.monotonic() + 5
        while not ready.exists() and process.poll() is None and time.monotonic() < deadline:
            time.sleep(0.01)
        assert ready.read_text(encoding="utf-8") == "locked"
        with pytest.raises(RuntimeLockUnavailable), advisory_file_lock(
            budget, timeout_seconds=0.05
        ):
            pytest.fail("the lock was acquired by two processes")
        _, stderr = process.communicate(timeout=5)
        assert process.returncode == 0, stderr
        with advisory_file_lock(budget, timeout_seconds=0.05):
            pass
    finally:
        if process.poll() is None:
            process.kill()
            process.wait(timeout=5)
