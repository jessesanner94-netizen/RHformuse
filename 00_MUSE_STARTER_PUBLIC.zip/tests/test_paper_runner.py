import asyncio
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import tools.paper_runner as paper_runner
from tools.config import load_config


def test_completed_sol_buy_opens_with_refreshed_ask(tmp_path: Path, monkeypatch) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    small_account_config = load_config(
        Path(__file__).parent / "fixtures" / "CONFIG.small-account-proposal-test-only.md"
    )
    candidate = {
        "candidate_id": "contract-1",
        "symbol": "SPY",
        "option_symbol": "SPY-FIXTURE",
        "expiration": "2026-09-18",
        "strike": 500.0,
        "option_type": "CALL",
        "dte": 25,
        "underlying_price": 500.0,
        "underlying_avg_daily_dollar_volume": 1_000_000_000,
        "setup_qualified": True,
    }
    decision = {
        "action": "BUY",
        "candidate_id": "contract-1",
        "paper_id": "",
        "trade_style": "DAY",
        "hold_deadline": "",
        "thesis": "Fixture",
        "invalidation": "Fixture invalidation",
        "reason": "Fixture decision",
        "confidence": 0.7,
        "earnings_event": "None in holding window",
        "holds_through_earnings": False,
        "pre_uw_action": "WAIT",
        "post_uw_action": "BUY",
        "what_uw_changed": "Confirmed activity",
    }

    async def refresh(requests):
        assert requests[0]["option_id"] == "contract-1"
        return {
            "as_of": now.isoformat(),
            "option_quotes": [
                {
                    "quote": {
                        "instrument_id": "contract-1",
                        "bid_price": "1.00",
                        "ask_price": "1.10",
                        "implied_volatility": "0.25",
                        "delta": "0.50",
                        "gamma": "0.002",
                        "theta": "-0.02",
                        "vega": "0.10",
                        "rho": "0.02",
                        "volume": 1000,
                        "open_interest": 5000,
                        "updated_at": now.isoformat(),
                    }
                }
            ],
        }

    monkeypatch.setattr(paper_runner, "fetch_quote_refresh", refresh)
    result = asyncio.run(
        paper_runner.apply_paper_decision(
            {"sol": {"status": "COMPLETED", "output": json.dumps(decision)}},
            {"option_discovery": {"qualified_candidates": [candidate]}},
            small_account_config,
            project_root=tmp_path,
            now=now,
        )
    )

    assert result["status"] == "OPENED"
    assert result["position"]["entry_price"] == 1.1
    assert result["portfolio"]["equity"] == 359.0


def test_expired_model_buy_never_reaches_paper_fill(tmp_path, monkeypatch):
    config = load_config(
        Path(__file__).parent / "fixtures/CONFIG.small-account-proposal-test-only.md"
    )

    async def refresh(requests):
        return {"option_quotes": []}

    def forbidden(*args, **kwargs):
        raise AssertionError("expired decision reached the ledger")

    monkeypatch.setattr(paper_runner, "open_paper_position", forbidden)
    for expiry in ("2026-08-24T14:59:00Z", "invalid", "2026-08-24T16:00:00"):
        result = asyncio.run(
            paper_runner.apply_paper_decision(
                {
                    "decision": {
                        "status": "COMPLETED",
                        "output": json.dumps(
                            {"action": "BUY", "candidate_id": "c", "decision_valid_until": expiry}
                        ),
                    }
                },
                {"qualified_candidates": [{"candidate_id": "c", "symbol": "SPY"}]},
                config,
                project_root=tmp_path,
                now=datetime(2026, 8, 24, 15, tzinfo=UTC),
                quote_fetcher=refresh,
            )
        )
        assert result["reasons"] == ["paper_decision_expired_or_invalid"]


def test_config_change_during_quote_refresh_blocks_paper_fill(tmp_path):
    source = Path(__file__).parent / "fixtures/CONFIG.small-account-proposal-test-only.md"
    path = tmp_path / "CONFIG.md"
    path.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    config = load_config(path)

    async def refresh(requests):
        path.write_text(
            path.read_text(encoding="utf-8").replace(
                "PAPER_TRADING_ENABLED: true", "PAPER_TRADING_ENABLED: false"
            ),
            encoding="utf-8",
        )
        return {"option_quotes": []}

    result = asyncio.run(
        paper_runner.apply_paper_decision(
            {"decision": {"status": "COMPLETED", "output": '{"action":"BUY","candidate_id":"c"}'}},
            {"qualified_candidates": [{"candidate_id": "c", "symbol": "SPY"}]},
            config,
            project_root=tmp_path,
            now=datetime(2026, 8, 24, 15, tzinfo=UTC),
            quote_fetcher=refresh,
        )
    )
    assert result["reasons"] == ["configuration_changed_before_paper_fill"]


def test_winner_evidence_uses_final_quote_after_parallel_collection(tmp_path, monkeypatch) -> None:
    now = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)
    from tools import winner_advisory, winner_evidence

    clock = [now]

    class Clock(datetime):
        @classmethod
        def now(cls, tz=None):
            return clock[0].astimezone(tz)

    monkeypatch.setattr(paper_runner, "datetime", Clock)
    monkeypatch.setattr(winner_evidence, "datetime", Clock)
    config = load_config(
        Path(__file__).parent / "fixtures/CONFIG.small-account-proposal-test-only.md"
    )
    position = {
        "paper_id": "paper-1",
        "contract_identifier": "contract-1",
        "symbol": "SPY",
        "option_type": "CALL",
        "entry_at": now.isoformat(),
        "entry_price": 1.0,
        "stop_price": 0.75,
        "take_profit_price": 1.3,
        "hold_deadline": (now.replace(hour=20)).isoformat(),
        "winner_management": {"enabled": True, "checkpoint_reached": True},
    }
    state = {"open_positions": [position]}
    refreshes: list[list[dict]] = []
    managed: list[dict] = []

    monkeypatch.setattr(paper_runner, "ensure_paper_portfolio", lambda *args, **kwargs: state)

    def manage(refresh, *args, **kwargs):
        managed.append(dict(refresh))
        return {
            "status": "MONITORED",
            "paper_events": [],
            "attention": [],
            "open_positions": [position],
            "portfolio": {},
            "orders_placed": 0,
            "orders_cancelled": 0,
        }

    monkeypatch.setattr(paper_runner, "manage_paper_positions", manage)

    async def refresh(requests):
        refreshes.append(requests)
        return {
            "as_of": now.isoformat(),
            "option_quotes": [
                {
                    "quote": {
                        "instrument_id": "contract-1",
                        "bid_price": "1.30",
                        "ask_price": "1.35",
                        "updated_at": now.isoformat(),
                    }
                }
            ],
        }

    def technical(*args, **kwargs):
        clock[0] = now + timedelta(seconds=5)
        return {
            "status": "OK",
            "symbol": "SPY",
            "as_of": clock[0].isoformat(),
            "timeframes": {"5M": {"status": "OK", "trend": "BULLISH"}, "15M": {}},
            "intraday_structure": {
                "status": "OK",
                "bias": "NEUTRAL",
                "session_date": "2026-09-24",
                "entry_timing": {
                    "status": "OK",
                    "completed_bar_at": (now - timedelta(minutes=5)).isoformat(),
                },
            },
        }

    async def books(*args, **kwargs):
        return {"summaries": {}}

    advisories: list[dict] = []

    def record_advisory(result, *args, **kwargs):
        assert managed, "JEV must run after Python's management pass"
        advisories.append(result)
        return [{"status": "OK", "exit_authority": False}]

    monkeypatch.setattr(winner_advisory, "record_checkpoint_advisories", record_advisory)
    result = asyncio.run(
        paper_runner.monitor_paper_portfolio(
            config,
            project_root=tmp_path,
            quote_fetcher=refresh,
            technical_fetcher=technical,
            orderbook_collector=books,
        )
    )

    assert result["status"] == "MONITORED"
    assert len(refreshes) == 2
    assert "tp_history_start" not in refreshes[0][0]
    assert managed[0]["continuation_evidence"]["SPY"]["status"] == "INTACT"
    assert advisories == [result]
    assert result["jev_winner_advisories"] == [{"status": "OK", "exit_authority": False}]


def test_initial_stop_manages_before_winner_evidence(tmp_path, monkeypatch) -> None:
    now = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)
    config = load_config(
        Path(__file__).parent / "fixtures/CONFIG.small-account-proposal-test-only.md"
    )
    position = {
        "paper_id": "paper-1",
        "contract_identifier": "contract-1",
        "symbol": "SPY",
        "option_type": "CALL",
        "entry_at": now.isoformat(),
        "stop_price": 0.75,
        "take_profit_price": 1.3,
        "hold_deadline": now.replace(hour=20).isoformat(),
        "winner_management": {"enabled": True, "checkpoint_reached": True},
    }
    state = {"open_positions": [position]}
    technical_called = False
    refresh_count = 0
    monkeypatch.setattr(paper_runner, "ensure_paper_portfolio", lambda *args, **kwargs: state)

    def manage(refresh, *args, **kwargs):
        return {
            "status": "EXITED",
            "paper_events": [{"event": "PAPER_EXIT"}],
            "attention": [],
            "open_positions": [],
            "portfolio": {},
            "orders_placed": 0,
            "orders_cancelled": 0,
        }

    monkeypatch.setattr(paper_runner, "manage_paper_positions", manage)

    async def refresh(requests):
        nonlocal refresh_count
        refresh_count += 1
        return {
            "as_of": now.isoformat(),
            "option_quotes": [
                {
                    "quote": {
                        "instrument_id": "contract-1",
                        "bid_price": "0.70",
                        "ask_price": "0.75",
                        "updated_at": now.isoformat(),
                    }
                }
            ],
        }

    def technical(*args, **kwargs):
        nonlocal technical_called
        technical_called = True
        return {}

    async def no_advisory(*args, **kwargs):
        return None

    monkeypatch.setattr(paper_runner, "_record_winner_advisories", no_advisory)
    result = asyncio.run(
        paper_runner.monitor_paper_portfolio(
            config,
            project_root=tmp_path,
            now=now,
            quote_fetcher=refresh,
            technical_fetcher=technical,
        )
    )

    assert result["status"] == "EXITED"
    assert refresh_count == 1
    assert technical_called is False
