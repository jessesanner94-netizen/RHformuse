import asyncio
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import tools.scheduled_cycle as scheduled_cycle
from tools.config import TradingConfig
from tools.scheduled_cycle import market_window, new_entry_window

EASTERN = ZoneInfo("America/New_York")


def _flat_paper_event(**values):
    return {
        **values,
        "paper_portfolio": {
            "status": "QUIET",
            "open_positions": [],
            "portfolio": {
                "open_positions": 0,
                "cash": 10000,
                "equity": 10000,
                "day": {"new_positions": 0, "start_equity": 10000},
            },
        },
    }


def test_approved_market_windows(resolved_config) -> None:
    monday = datetime(2026, 8, 24, 9, 49, tzinfo=EASTERN)
    assert market_window("positions", resolved_config, now=monday)[0] is True
    assert market_window("opportunities", resolved_config, now=monday)[0] is True
    assert new_entry_window(resolved_config, now=monday) is False

    at_entry_start = monday.replace(minute=50)
    assert new_entry_window(resolved_config, now=at_entry_start) is True

    after_entry_end = monday.replace(hour=15, minute=31)
    assert market_window("opportunities", resolved_config, now=after_entry_end)[0] is True
    assert new_entry_window(resolved_config, now=after_entry_end, trade_style="DAY") is False
    assert new_entry_window(resolved_config, now=after_entry_end, trade_style="SWING") is True

    after_swing_end = monday.replace(hour=15, minute=51)
    assert new_entry_window(resolved_config, now=after_swing_end, trade_style="SWING") is False


def test_weekend_is_skipped(resolved_config) -> None:
    sunday = datetime(2026, 8, 23, 12, 0, tzinfo=EASTERN)
    assert market_window("positions", resolved_config, now=sunday) == (False, "weekend")


def test_spy_qqq_mode_bypasses_broad_and_uw_discovery(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    config = TradingConfig(
        {
            **resolved_config.values,
            "UW_ENABLED": False,
            "WATCHLIST_ONLY": True,
            "WATCHLIST_SYMBOLS": "SPY,QQQ",
        }
    )
    watchlist_calls = []

    async def live_monitor(_project_root):
        return {"status": "QUIET", "wake_codex": False, "triggers": []}

    async def paper_monitor(*_args, **_kwargs):
        return _flat_paper_event()["paper_portfolio"]

    async def watchlist(*args, **kwargs):
        watchlist_calls.append((args, kwargs))
        return {
            "status": "ZERO_QUALIFIED",
            "wake_luna": False,
            "symbols": ["SPY", "QQQ"],
            "qualified_candidates": [],
            "orders_placed": 0,
            "orders_cancelled": 0,
        }

    def unexpected(*_args, **_kwargs):
        raise AssertionError("broad and UW discovery must be bypassed in watchlist mode")

    monkeypatch.setattr(scheduled_cycle, "load_config", lambda _path: config)
    monkeypatch.setattr(scheduled_cycle, "run_live_monitor", live_monitor)
    monkeypatch.setattr(scheduled_cycle, "monitor_paper_portfolio", paper_monitor)
    monkeypatch.setattr(
        scheduled_cycle,
        "collect_market_intelligence",
        lambda *a, **k: {"status": "QUIET", "wake_luna": False},
    )
    monkeypatch.setattr(scheduled_cycle, "run_watchlist_option_discovery", watchlist)
    monkeypatch.setattr(scheduled_cycle, "run_market_mover_discovery", unexpected)
    monkeypatch.setattr(scheduled_cycle, "run_option_discovery", unexpected)

    result = asyncio.run(
        scheduled_cycle.run_cycle(
            "opportunities",
            project_root=tmp_path,
            execute_models=False,
            notifications=False,
            now=datetime(2026, 8, 31, 11, 0, tzinfo=EASTERN),
        )
    )

    assert len(watchlist_calls) == 1
    assert result["event"]["option_discovery"]["symbols"] == ["SPY", "QQQ"]
    assert result["routing"]["decision"]["codex_invoked"] is False
    assert result["live_decision"]["status"] == "DISABLED"


def test_luna_news_symbol_is_enriched_before_sol(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    calls = 0
    sandboxes = []

    def trigger(event, **kwargs):
        nonlocal calls
        calls += 1
        sandboxes.append(kwargs["sandbox"])
        if calls == 1:
            return {
                "status": "COMPLETED",
                "output": json.dumps(
                    {
                        "material": True,
                        "action": "ESCALATE_SOL",
                        "symbols": ["NVDA"],
                        "candidate_ids": [],
                        "reason": "Material fixture headline",
                    }
                ),
            }
        assert (
            event["source_event"]["option_discovery"]["qualified_candidates"][0]["candidate_id"]
            == "news-contract-1"
        )
        return {"status": "COMPLETED", "output": "{}"}

    async def news_discovery(symbols, config, **kwargs):
        assert symbols == ["NVDA"]
        return {
            "status": "QUALIFIED",
            "qualified_candidates": [{"candidate_id": "news-contract-1", "symbol": "NVDA"}],
        }

    monkeypatch.setattr(scheduled_cycle, "run_trigger", trigger)
    monkeypatch.setattr(scheduled_cycle, "run_news_option_discovery", news_discovery)
    routing = asyncio.run(
        scheduled_cycle._route_luna_then_sol(
            {
                "wake_luna": True,
                "option_discovery": {"qualified_candidates": []},
            },
            config=resolved_config,
            project_root=tmp_path,
            execute_models=True,
            luna_prompt="TRIGGERED_CANDIDATE_TRIAGE.md",
            sol_prompt="TRIGGERED_CANDIDATE_REVIEW.md",
        )
    )

    assert routing["news_contract_discovery"]["status"] == "QUALIFIED"
    assert (
        routing["decision_event"]["option_discovery"]["qualified_candidates"][0]["candidate_id"]
        == "news-contract-1"
    )
    assert sandboxes == ["workspace-write", "workspace-write"]


def test_compact_route_makes_one_isolated_decision_call(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    calls = []

    async def packet(*args, **kwargs):
        return {
            "status": "READY",
            "packet": {"candidate": {"candidate_id": "compact-1"}},
            "selected_candidates": [
                {
                    "candidate_id": "compact-1",
                    "symbol": "SPY",
                    "option_type": "CALL",
                    "underlying_price": 500.0,
                }
            ],
            "packet_signature": "fixture-signature",
        }

    def trigger(event, **kwargs):
        calls.append((event, kwargs))
        return {
            "status": "COMPLETED",
            "output": json.dumps(
                {
                    "action": "PASS",
                    "decision_valid_until": "2026-08-26T16:00:00+00:00",
                }
            ),
        }

    monkeypatch.setattr(scheduled_cycle, "build_decision_packet", packet)
    monkeypatch.setattr(scheduled_cycle, "run_trigger", trigger)
    result = asyncio.run(
        scheduled_cycle._route_compact_decision(
            _flat_paper_event(option_discovery={"qualified_candidates": []}),
            config=resolved_config,
            project_root=tmp_path,
            execute_models=True,
            now=datetime(2026, 8, 26, 11, 0, tzinfo=EASTERN),
        )
    )

    assert len(calls) == 1
    assert calls[0][0]["decision_packet"] == {"candidate": {"candidate_id": "compact-1"}}
    assert calls[0][1]["isolated_agent"] is True
    assert calls[0][1]["sandbox"] == "read-only"
    assert result["decision"]["status"] == "COMPLETED"


def test_operational_position_attention_does_not_spend_model_budget(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    def unexpected_trigger(*args, **kwargs):
        raise AssertionError("operational data errors must not wake a model")

    monkeypatch.setattr(scheduled_cycle, "run_trigger", unexpected_trigger)
    result = scheduled_cycle._route_compact_position(
        {
            "status": "ATTENTION",
            "reason": "live_snapshot_invalid_or_stale",
            "wake_codex": True,
            "triggers": [],
        },
        config=resolved_config,
        project_root=tmp_path,
        execute_models=True,
        now=datetime(2026, 8, 26, 11, 0, tzinfo=EASTERN),
    )

    assert result["status"] == "SKIPPED"
    assert result["codex_invoked"] is False


def test_exhausted_budget_sleeps_before_opportunity_discovery(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    now = datetime(2026, 8, 26, 11, 0, tzinfo=EASTERN)
    budget_path = tmp_path / "state" / "runtime" / "model_budget.json"
    budget_path.parent.mkdir(parents=True)
    budget_path.write_text(
        json.dumps(
            {
                "date": "2026-08-26",
                "calls_reserved": 7,
                "maximum_calls": 7,
            }
        ),
        encoding="utf-8",
    )

    async def live_monitor(_project_root):
        return {"status": "QUIET", "wake_codex": False, "triggers": []}

    async def paper_monitor(*args, **kwargs):
        return {
            "status": "QUIET",
            "orders_placed": 0,
            "orders_cancelled": 0,
            "portfolio": {"open_positions": 0, "day": {"new_positions": 0}},
        }

    def unexpected_discovery(*args, **kwargs):
        raise AssertionError("an exhausted opportunity cycle must sleep before discovery")

    monkeypatch.setattr(scheduled_cycle, "load_config", lambda _path: resolved_config)
    monkeypatch.setattr(scheduled_cycle, "run_live_monitor", live_monitor)
    monkeypatch.setattr(scheduled_cycle, "monitor_paper_portfolio", paper_monitor)
    monkeypatch.setattr(scheduled_cycle, "collect_market_intelligence", unexpected_discovery)
    monkeypatch.setattr(scheduled_cycle, "run_option_discovery", unexpected_discovery)
    monkeypatch.setattr(scheduled_cycle, "run_market_mover_discovery", unexpected_discovery)

    result = asyncio.run(
        scheduled_cycle.run_cycle(
            "opportunities",
            project_root=tmp_path,
            execute_models=True,
            notifications=False,
            now=now,
        )
    )

    assert result["status"] == "SLEEPING"
    assert result["routing"]["decision"]["codex_invoked"] is False
    assert result["notification"] == {
        "status": "SKIPPED",
        "reason": "no_material_user_alert",
    }


def test_compact_route_reuses_valid_cached_buy_without_model(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    candidate = {
        "candidate_id": "compact-1",
        "symbol": "SPY",
        "option_type": "CALL",
        "underlying_price": 500.0,
    }

    async def packet(*args, **kwargs):
        return {
            "status": "READY",
            "packet": {"candidate": candidate},
            "selected_candidates": [candidate],
            "packet_signature": "fixture-signature",
        }

    cache_path = tmp_path / "state" / "runtime" / "decision_cache.json"
    cache_path.parent.mkdir(parents=True)
    cache_path.write_text(
        json.dumps(
            {
                "updated_at": "2026-08-26T14:55:00+00:00",
                "packet_signature": "fixture-signature",
                "candidate_id": "compact-1",
                "decision": {
                    "action": "BUY",
                    "candidate_id": "compact-1",
                    "decision_valid_until": "2026-08-26T16:00:00+00:00",
                },
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(scheduled_cycle, "build_decision_packet", packet)
    monkeypatch.setattr(
        scheduled_cycle,
        "run_trigger",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            AssertionError("cached BUY must not call a model")
        ),
    )
    result = asyncio.run(
        scheduled_cycle._route_compact_decision(
            _flat_paper_event(),
            config=resolved_config,
            project_root=tmp_path,
            execute_models=True,
            now=datetime(2026, 8, 26, 11, 0, tzinfo=EASTERN),
        )
    )

    assert result["decision"]["status"] == "COMPLETED"
    assert result["decision"]["codex_invoked"] is False
    assert result["decision"]["cached"] is True
    assert result["decision_verdict"]["action"] == "BUY"


def test_compact_route_skips_cached_pass_and_advances_to_next_candidate(
    tmp_path: Path, resolved_config, monkeypatch
) -> None:
    rejected = {
        "candidate_id": "tlt-put",
        "symbol": "TLT",
        "option_type": "PUT",
        "entry_eligible_trade_styles": ["DAY", "SWING"],
    }
    next_candidate = {
        "candidate_id": "spy-call",
        "symbol": "SPY",
        "option_type": "CALL",
        "entry_eligible_trade_styles": ["DAY", "SWING"],
    }
    rejected_packet = {
        "candidate": rejected,
        "technical": {
            "timeframes": {
                "1D": {"trend": "NEUTRAL"},
                "4H": {"trend": "BULLISH"},
                "15M": {"trend": "BULLISH"},
                "5M": {"trend": "NEUTRAL"},
            }
        },
        "unusual_whales": {
            "label": "STRONG_BULLISH",
            "supports_contract_direction": False,
        },
        "news": {"label": "NEUTRAL"},
        "social": {"label": "NEUTRAL"},
        "risk": {"status": "ALLOWED"},
        "earnings_event": {"status": "UNAVAILABLE", "next_date": None},
        "entry_windows": {"DAY": True, "SWING": True},
    }
    pass_state = {
        "desired_direction": "BEARISH",
        "technical_supports_direction": False,
        "intraday_direction": "NEUTRAL",
        "uw_direction": "OPPOSING",
        "uw_supports_contract_direction": False,
        "news_direction": "NEUTRAL",
        "social_direction": "NEUTRAL",
        "risk_status": "ALLOWED",
        "earnings_status": "UNAVAILABLE",
        "earnings_date": None,
        "eligible_styles": ["DAY", "SWING"],
        "entry_windows": {"DAY": True, "SWING": True},
    }
    cache_path = tmp_path / "state" / "runtime" / "decision_cache.json"
    cache_path.parent.mkdir(parents=True)
    cache_path.write_text(
        json.dumps(
            {
                "candidate_id": "tlt-put",
                "packet_signature": "old-tlt-signature",
                "pass_recheck_state": pass_state,
                "decision": {
                    "action": "PASS",
                    "candidate_id": "tlt-put",
                    "decision_valid_until": "2026-08-26T18:00:00+00:00",
                },
            }
        ),
        encoding="utf-8",
    )

    async def packet(*args, excluded_candidate_ids=None, **kwargs):
        if "tlt-put" not in (excluded_candidate_ids or set()):
            return {
                "status": "READY",
                "packet": rejected_packet,
                "selected_candidates": [rejected],
                "packet_signature": "changed-tlt-signature",
            }
        return {
            "status": "READY",
            "packet": {"candidate": next_candidate},
            "selected_candidates": [next_candidate],
            "packet_signature": "spy-signature",
        }

    monkeypatch.setattr(scheduled_cycle, "build_decision_packet", packet)
    result = asyncio.run(
        scheduled_cycle._route_compact_decision(
            _flat_paper_event(),
            config=resolved_config,
            project_root=tmp_path,
            execute_models=False,
            now=datetime(2026, 8, 26, 11, 0, tzinfo=EASTERN),
        )
    )

    assert result["decision"]["status"] == "PREVIEW"
    assert result["decision_packet"]["candidate"]["candidate_id"] == "spy-call"
    assert result["suppressed_candidates"] == [
        {
            "candidate_id": "tlt-put",
            "symbol": "TLT",
            "reason": "material_pass_state_unchanged",
        }
    ]


def test_exception_summary_preserves_nested_transport_cause() -> None:
    error = ExceptionGroup(
        "unhandled errors in a TaskGroup",
        [ConnectionError("Robinhood stream reset")],
    )

    summary = scheduled_cycle._exception_summary(error)

    assert "ExceptionGroup" in summary
    assert "ConnectionError: Robinhood stream reset" in summary


def test_handoff_diagnostics_accounts_for_technical_and_cache_blocks():
    event = {"option_discovery": {"qualified_candidates": [
        {"candidate_id": "put"}, {"candidate_id": "call"}, {"candidate_id": "unexamined"}
    ]}}
    result = {"python_rejections": [{"candidate_id": "put", "gate": {
        "reasons": ["countertrend_day_requires_5m_15m_confirmation"]}}],
        "suppressed_candidates": [{"candidate_id": "call",
                                    "reason": "material_pass_state_unchanged"}]}
    report = scheduled_cycle._handoff_diagnostics(event, result)
    assert report["discovery_candidate_count"] == 3
    assert report["python_rejected_count"] == 1
    assert report["routing_suppressed_count"] == 1
    assert report["not_evaluated_or_unexplained_ids"] == ["unexamined"]
    assert report["block_reasons"]["material_pass_state_unchanged"] == 1


def test_day_only_uses_day_cutoff_and_blocks_swing(resolved_config):
    config = TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True})
    during = datetime(2026, 9, 22, 14, 0, tzinfo=EASTERN)
    after = during.replace(hour=15, minute=40)
    assert new_entry_window(config, now=during)
    assert not new_entry_window(config, now=during, trade_style="SWING")
    assert not new_entry_window(config, now=after)
