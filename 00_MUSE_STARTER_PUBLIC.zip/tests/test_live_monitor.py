from datetime import UTC, datetime

from tools.live_monitor import adapt_snapshot
from tools.state_manager import parse_positions_markdown

POLICY = {
    "stop_loss_percent": 25,
    "take_profit_percent": 30,
    "trailing_enabled": False,
    "trailing_activation_percent": 25,
    "trailing_giveback_percent": 15,
    "day_trade_exit_minutes_before_close": 15,
    "require_protective_order": True,
}


def _project_position():
    return parse_positions_markdown(
        """\
### SPY 2026-09-18 500 CALL
- Robinhood contract identifier: contract-1
- Quantity: 1
- Entry fill: 1.00
- Trade style: DAY
- High-water option mark: 1.05
- Current thesis status: INTACT
"""
    )


def _snapshot(now: datetime, *, with_stop: bool = True):
    orders = []
    if with_stop:
        orders = [
            {
                "type": "stop_market",
                "stop_price": "0.75",
                "legs": [
                    {
                        "option_id": "contract-1",
                        "position_effect": "close",
                    }
                ],
            }
        ]
    return {
        "as_of": now.isoformat(),
        "account": {"account_number": "••••1206"},
        "positions": [{"option_id": "contract-1", "quantity": "1.0000"}],
        "open_option_orders": orders,
        "option_quotes": [
            {
                "quote": {
                    "instrument_id": "contract-1",
                    "adjusted_mark_price": "1.10",
                    "updated_at": now.isoformat(),
                }
            }
        ],
    }


def test_live_adapter_reconciles_and_stays_quiet() -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    result = adapt_snapshot(
        _snapshot(now),
        project_positions=_project_position(),
        policy=POLICY,
        now=now,
    )

    assert result["status"] == "QUIET"
    assert result["reconciliation"]["status"] == "RECONCILED"
    assert result["positions_evaluated"] == 1


def test_live_adapter_wakes_when_protective_stop_is_missing() -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    result = adapt_snapshot(
        _snapshot(now, with_stop=False),
        project_positions=_project_position(),
        policy=POLICY,
        now=now,
    )

    assert result["wake_codex"] is True
    assert "PROTECTIVE_ORDER_MISSING" in [item["code"] for item in result["triggers"]]


def test_live_adapter_is_quiet_when_broker_and_memory_are_empty() -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    snapshot = {
        "as_of": now.isoformat(),
        "positions": [],
        "open_option_orders": [],
        "option_quotes": [],
    }
    result = adapt_snapshot(snapshot, project_positions=[], policy=POLICY, now=now)

    assert result["status"] == "QUIET"
    assert result["positions_evaluated"] == 0
