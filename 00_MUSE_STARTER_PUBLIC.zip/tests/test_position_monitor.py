from tools.position_monitor import run_monitor


def policy() -> dict:
    return {
        "stop_loss_percent": 25,
        "take_profit_percent": 30,
        "trailing_activation_percent": 25,
        "trailing_giveback_percent": 15,
        "day_trade_exit_minutes_before_close": 15,
        "require_protective_order": True,
        "trailing_enabled": True,
    }


def position(**overrides) -> dict:
    result = {
        "contract_identifier": "contract-1",
        "symbol": "SPY",
        "trade_style": "SWING",
        "quantity": 1,
        "entry_price": 1.0,
        "current_mark": 1.05,
        "high_water_mark": 1.10,
        "quote_is_fresh": True,
        "protective_order_state": "WORKING",
        "minutes_to_close": 120,
        "hold_deadline_reached": False,
        "event_risk_changed": False,
        "thesis_invalidated": False,
    }
    result.update(overrides)
    return result


def payload(*positions: dict) -> dict:
    return {
        "snapshot_is_fresh": True,
        "broker_reconciled": True,
        "positions": list(positions),
        "policy": policy(),
    }


def trigger_codes(result: dict) -> set[str]:
    return {trigger["code"] for trigger in result["triggers"]}


def test_no_positions_does_not_wake_codex() -> None:
    result = run_monitor(payload())

    assert result["status"] == "QUIET"
    assert result["wake_codex"] is False
    assert result["orders_placed"] == 0


def test_healthy_position_does_not_wake_codex() -> None:
    result = run_monitor(payload(position()))

    assert result["wake_codex"] is False
    assert result["positions_evaluated"] == 1


def test_stale_snapshot_and_reconciliation_failure_wake_codex() -> None:
    test_payload = payload()
    test_payload["snapshot_is_fresh"] = False
    test_payload["broker_reconciled"] = False

    result = run_monitor(test_payload)

    assert result["wake_codex"] is True
    assert trigger_codes(result) == {
        "STALE_BROKER_SNAPSHOT",
        "BROKER_RECONCILIATION_REQUIRED",
    }


def test_missing_protective_order_wakes_codex() -> None:
    result = run_monitor(payload(position(protective_order_state="MISSING")))

    assert "PROTECTIVE_ORDER_MISSING" in trigger_codes(result)


def test_stop_loss_wakes_codex() -> None:
    result = run_monitor(payload(position(current_mark=0.74, high_water_mark=1.0)))

    assert "STOP_LOSS_REACHED" in trigger_codes(result)


def test_take_profit_wakes_codex() -> None:
    result = run_monitor(payload(position(current_mark=1.31, high_water_mark=1.31)))

    assert "TAKE_PROFIT_REACHED" in trigger_codes(result)


def test_trailing_drawdown_wakes_codex() -> None:
    result = run_monitor(payload(position(current_mark=1.10, high_water_mark=1.30)))

    assert "TRAILING_EXIT_REACHED" in trigger_codes(result)


def test_disabled_trailing_exit_stays_quiet() -> None:
    test_payload = payload(position(current_mark=1.10, high_water_mark=1.30))
    test_payload["policy"]["trailing_enabled"] = False

    result = run_monitor(test_payload)

    assert "TRAILING_EXIT_REACHED" not in trigger_codes(result)
    assert result["wake_codex"] is False


def test_day_trade_time_exit_wakes_codex() -> None:
    result = run_monitor(
        payload(position(trade_style="DAY", minutes_to_close=10, hold_deadline_reached=False))
    )

    assert "DAY_TRADE_TIME_EXIT" in trigger_codes(result)


def test_swing_hold_deadline_wakes_codex() -> None:
    result = run_monitor(payload(position(hold_deadline_reached=True)))

    assert "SWING_HOLD_DEADLINE" in trigger_codes(result)


def test_changed_risk_or_thesis_wakes_codex() -> None:
    result = run_monitor(payload(position(event_risk_changed=True, thesis_invalidated=True)))

    assert {"EVENT_RISK_CHANGED", "THESIS_INVALIDATED"}.issubset(trigger_codes(result))


def test_invalid_payload_fails_closed() -> None:
    result = run_monitor({"positions": "not-a-list", "policy": {}})

    assert result["status"] == "ATTENTION_REQUIRED"
    assert result["wake_codex"] is True
    assert "INVALID_MONITOR_INPUT" in trigger_codes(result)
    assert result["invalid_fields"]
