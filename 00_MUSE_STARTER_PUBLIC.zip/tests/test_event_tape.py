"""Point-in-time, feed isolation and no-execution checks for the research recorder."""

import copy
import socket
from datetime import UTC, datetime, timedelta

import pytest

from research.options_lab.event_tape import (
    ReactionPolicy,
    SessionTape,
    flow_features,
    news_reaction,
)

NOW = datetime(2026, 10, 21, 14, tzinfo=UTC)
POLICY = ReactionPolicy(120, 10, 1, 100, "synthetic", "TEST")


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("offline experiment attempted network access")
    monkeypatch.setattr(socket.socket, "connect", forbidden)


def event(kind, identifier, seconds=0, *, payload=None, source="synthetic", venue="TEST"):
    at = (NOW + timedelta(seconds=seconds)).isoformat()
    return {"schema_version": 1, "kind": kind, "source": source, "venue": venue,
            "symbol": "SPY", "event_id": identifier, "event_at": at,
            "received_at": at, "available_at": at, "payload": payload or {}}


def news(identifier="news", seconds=0, **changes):
    payload = {"event_key": "material-event-1", "title": "SYNTHETIC ADVERSE EVENT",
               "url": "https://example.com/synthetic-only", "classification_method":
               "SYNTHETIC_TEST_ANNOTATION", "verified": True, "material": True,
               "novel": True, "direction": "BEARISH", "relevant_symbols": ["SPY"]}
    return event("news", identifier, seconds, payload={**payload, **changes})


def bar(identifier="reaction", start=1, end=6, **changes):
    payload = {"start_at": (NOW + timedelta(seconds=start)).isoformat(),
               "end_at": (NOW + timedelta(seconds=end)).isoformat(),
               "open": 100, "high": 100, "low": 99.9, "close": 99.9, "volume": 1000}
    return event("bar", identifier, end, payload={**payload, **changes})


def book(identifier, seconds=0, quantity=100):
    return event("book", identifier, seconds, payload={
        "symbol": "SPY", "updated_at": (NOW + timedelta(seconds=seconds)).isoformat(),
        "bids": [{"price": 100, "quantity": quantity}],
        "asks": [{"price": 100.01, "quantity": 50}],
    })


def evaluate(store, seconds=6, held="CALL"):
    at = NOW + timedelta(seconds=seconds)
    rows = store.observations("SPY", as_of=at)
    return news_reaction(rows, symbol="SPY", held=held, as_of=at, policy=POLICY)


def test_fresh_verified_news_and_short_completed_reaction_produce_only_review(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(), bar()])
    result = evaluate(store)
    assert result["proposed_action"] == "EXIT_REVIEW"
    assert result["opposite_side_candidate"] == "PUT"
    assert result["decision_evaluated_within_ten_seconds_from_classification"] is True
    assert result["confirmation_available_within_ten_seconds_from_classification"] is True
    assert result["classified_to_confirmation_seconds"] == 6
    assert result["paper_fill"] is None
    assert result["execution_latency_seconds"] is None
    assert result["orders_placed"] == 0 and result["reversal_authorized"] is False
    assert evaluate(store, held="FLAT")["proposed_action"] == "REQUALIFY_DIRECTION"
    assert evaluate(store, held="PUT")["proposed_action"] == "REQUALIFY_DIRECTION"


def test_receipt_and_classification_delay_never_leak_backwards(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    row = news()
    row["received_at"] = (NOW + timedelta(seconds=3)).isoformat()
    row["available_at"] = (NOW + timedelta(seconds=4)).isoformat()
    store.ingest([row, bar(start=4, end=8)])
    assert evaluate(store, 2)["proposed_action"] == "NO_EVENT_ACTION"
    assert evaluate(store, 5)["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"
    result = evaluate(store, 8)
    assert result["event_to_received_seconds"] == 3
    assert result["received_to_classified_seconds"] == 1
    assert result["classified_to_confirmation_seconds"] == 4


@pytest.mark.parametrize("change", [{"verified": False}, {"novel": False}, {"material": False},
                                   {"relevant_symbols": ["QQQ"]}, {"direction": "UNKNOWN"}])
def test_unknown_irrelevant_or_unverified_news_never_authorizes_review(tmp_path, change):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(**change), bar()])
    assert evaluate(store)["proposed_action"] == "NO_EVENT_ACTION"


@pytest.mark.parametrize("reaction", [bar(volume=None), bar(volume=0), bar(start=-5, end=0),
                                      bar(start=1, end=301)])
def test_missing_volume_pre_event_or_five_minute_bars_do_not_confirm(tmp_path, reaction):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(), reaction])
    seconds = (datetime.fromisoformat(reaction["event_at"]) - NOW).total_seconds()
    assert evaluate(store, max(6, seconds))[
        "proposed_action"] != "EXIT_REVIEW"


def test_feed_is_pinned_and_gap_requires_review_instead_of_confirmation(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    wrong = bar()
    wrong["source"] = "other-feed"
    store.ingest([news(), wrong])
    assert evaluate(store)["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"
    store.ingest([bar(), event("gap", "dropped-data", 3, payload={
        "gap_key": "gap1", "start_at": (NOW + timedelta(seconds=2)).isoformat(),
        "end_at": (NOW + timedelta(seconds=3)).isoformat()})])
    assert evaluate(store)["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"


def test_conflicting_events_and_stale_republished_headline(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    opposite = news("opposite", 1, direction="BULLISH", event_key="other-event")
    store.ingest([news(), opposite, bar()])
    assert evaluate(store)["proposed_action"] == "PAUSE_REVIEW_CONFLICTING_EVENTS"
    republished = news("copy", 200)
    store.ingest([republished, bar("late-reaction", 201, 206)])
    assert evaluate(store, 206)["proposed_action"] == "NO_EVENT_ACTION"


def test_later_verification_can_become_knowable_without_reusing_preverification_bar(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(verified=False), news("verified-copy", 4), bar(start=1, end=6)])
    assert evaluate(store)["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"
    store.ingest([bar("post-verification", start=5, end=10)])
    assert evaluate(store, 10)["proposed_action"] == "EXIT_REVIEW"


def test_unlinked_news_correction_fails_closed_and_explicit_revision_replaces_old(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(), bar()])
    assert evaluate(store)["proposed_action"] == "EXIT_REVIEW"
    store.ingest([news("correction", 7, direction="BULLISH")])
    assert evaluate(store, 8)["proposed_action"] == "PAUSE_REVIEW_NEWS_REVISION"
    # A later explicit, verified correction supersedes the older same-event versions.
    store.ingest([news("linked-correction", 9, direction="BULLISH",
                       supersedes_event_id="correction")])
    assert evaluate(store, 10)["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"
    assert evaluate(store, 6)["proposed_action"] == "EXIT_REVIEW"


def test_confirmation_latency_is_separate_from_evaluation_latency(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(), bar()])
    result = evaluate(store, 15)
    assert result["confirmation_available_within_ten_seconds_from_classification"] is True
    assert result["decision_evaluated_within_ten_seconds_from_classification"] is False


def test_later_gap_does_not_erase_earlier_confirmation(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(), bar(), event("gap", "later-gap", 8, payload={
        "gap_key": "gap1", "start_at": (NOW + timedelta(seconds=7)).isoformat(),
        "end_at": (NOW + timedelta(seconds=8)).isoformat()})])
    assert evaluate(store, 8)["proposed_action"] == "EXIT_REVIEW"


def test_open_gap_before_news_blocks_until_recovery_and_new_complete_bar(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([event("gap", "open", -1, payload={
        "gap_key": "gap1", "start_at": (NOW - timedelta(seconds=1)).isoformat(),
        "end_at": None}), news(), bar()])
    assert evaluate(store)["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"
    store.ingest([event("gap", "recovered", 2, payload={
        "gap_key": "gap1", "start_at": (NOW - timedelta(seconds=1)).isoformat(),
        "end_at": (NOW + timedelta(seconds=2)).isoformat()}), bar("new-bar", 3, 8)])
    assert evaluate(store, 8)["proposed_action"] == "EXIT_REVIEW"


def test_full_session_history_survives_an_hour_and_depth_is_never_print_volume(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([book("first"), book("second", 7200, 500)])
    rows = store.observations("SPY", as_of=NOW + timedelta(hours=2))
    result = flow_features(rows, as_of=NOW + timedelta(hours=2))["feeds"][0]
    assert result["book_snapshots"] == 2 and result["max_snapshot_gap_seconds"] == 7200
    assert result["trade_prints"] == 0 and result["cvd"] is None
    assert result["displayed_zones"][0]["max_displayed_quantity"] == 500
    assert result["absorption"] == "UNAVAILABLE_UNVALIDATED"


def test_print_volume_unknown_side_and_trade_cancellations_are_point_in_time(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    trade = event("trade", "t1", payload={"price": 100, "quantity": 37})
    store.ingest([trade, event("trade_cancel", "cancel", 10, payload={"trade_id": "t1"})])
    before = flow_features(store.observations("SPY", as_of=NOW), as_of=NOW)["feeds"][0]
    assert before["observed_volume_at_price"] == {"100": 37}
    assert before["unknown_side_volume"] == 37 and before["cvd"] is None
    later = NOW + timedelta(seconds=10)
    after = flow_features(store.observations("SPY", as_of=later), as_of=later)["feeds"][0]
    assert after["trade_prints"] == 0


def test_feed_and_symbol_aggregation_are_separate_and_side_must_be_proven(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    signed = event("trade", "t1", payload={"price": 100, "quantity": 50,
                                          "aggressor_side": "sell", "side_basis": "provider"})
    other = copy.deepcopy(signed)
    other["venue"] = "OTHER"
    qqq = copy.deepcopy(signed)
    qqq["symbol"] = "QQQ"
    store.ingest([signed, other, qqq])
    rows = store.observations("SPY", as_of=NOW) + store.observations("QQQ", as_of=NOW)
    feeds = flow_features(rows, as_of=NOW)["feeds"]
    assert len(feeds) == 3 and all(r["cvd"] == -50 for r in feeds)
    signed["payload"]["side_basis"] = "guessed"
    with pytest.raises(ValueError, match="provider evidence"):
        store.ingest([signed])


def test_duplicates_retain_original_availability_and_conflicts_roll_back_batch(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    original = news()
    store.ingest([original])
    duplicate = copy.deepcopy(original)
    duplicate["received_at"] = duplicate["available_at"] = (NOW + timedelta(seconds=5)).isoformat()
    assert store.ingest([duplicate]) == {"inserted": 0, "duplicates": 1}
    assert len(store.observations("SPY", as_of=NOW)) == 1
    changed = copy.deepcopy(original)
    changed["payload"]["title"] = "different"
    with pytest.raises(ValueError, match="identity changed"):
        store.ingest([bar(), changed])
    assert len(store.observations("SPY", as_of=NOW + timedelta(seconds=6))) == 1


@pytest.mark.parametrize("damage", ["future_clock", "future_bar", "crossed", "nonfinite"])
def test_invalid_events_reject_whole_batch(tmp_path, damage):
    store = SessionTape(tmp_path / "tape.sqlite3")
    row = book("bad")
    if damage == "future_clock":
        row["event_at"] = (NOW + timedelta(seconds=1)).isoformat()
    elif damage == "future_bar":
        row = bar()
        row["payload"]["end_at"] = (NOW + timedelta(seconds=7)).isoformat()
    elif damage == "crossed":
        row["payload"]["bids"][0]["price"] = 101
    else:
        row["payload"]["bids"][0]["quantity"] = float("nan")
    with pytest.raises(ValueError):
        store.ingest([news(), row])
    assert store.observations("SPY", as_of=NOW + timedelta(seconds=10)) == []


def test_replay_fences_future_cancels_and_eastern_session(tmp_path):
    store = SessionTape(tmp_path / "tape.sqlite3")
    store.ingest([news(), bar()])
    assert not store.observations("SPY", as_of=NOW + timedelta(days=1))
    all_rows = store.observations("SPY", as_of=NOW + timedelta(seconds=6))
    result = news_reaction(all_rows, symbol="SPY", held="CALL", as_of=NOW, policy=POLICY)
    assert result["proposed_action"] == "PAUSE_NEW_ENTRIES_REVIEW_EVENT"
