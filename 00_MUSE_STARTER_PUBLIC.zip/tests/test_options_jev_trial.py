import asyncio
import json
from datetime import datetime
from types import SimpleNamespace

import pytest

from tests import test_jev_pipeline as fixtures
from tools import scheduled_cycle as cycle
from tools.jev_features import market_features
from tools.options_jev_trial import active, sample
from tools.robinhood_mcp import _read_option_instruments, _tool_payload

NOW = datetime.fromisoformat("2026-09-21T11:10:00-04:00")


def evaluation():
    return {
        "status": "OK",
        "routing_effect": True,
        "observation_id": "fixture",
        "scores": {"setup_quality": 0.27, "escalate_to_luna": 0.4, "false_breakout_risk": 0.2},
        "policy": {"would_escalate": False, "thresholds": {"JEV_MAX_FALSE_BREAKOUT": 0.25}},
    }


def test_trial_slots_and_expiry(tmp_path, resolved_config):
    config = resolved_config
    config.values.update(
        OPTIONS_JEV_BLIND_TEST=True, PAPER_TRADING_ENABLED=True, LIVE_EXECUTION_ENABLED=False
    )
    packet = fixtures.packet()
    assert sample(config, packet, evaluation(), tmp_path, NOW, reserve=True)
    assert not sample(config, packet, evaluation(), tmp_path, NOW, reserve=True)
    later = datetime.fromisoformat("2026-09-21T12:40:00-04:00")
    assert sample(config, packet, evaluation(), tmp_path, later, reserve=True)
    last = datetime.fromisoformat("2026-09-21T14:10:00-04:00")
    assert not sample(config, packet, evaluation(), tmp_path, last)
    packet["candidate"]["symbol"] = "QQQ"
    assert sample(config, packet, evaluation(), tmp_path, last, reserve=True)
    assert not active(config, datetime.fromisoformat("2026-09-21T15:30:00-04:00"))
    assert not active(config, datetime.fromisoformat("2026-09-22T11:10:00-04:00"))
    config.values["LIVE_EXECUTION_ENABLED"] = True
    assert not sample(config, packet, evaluation(), tmp_path, NOW)


@pytest.mark.parametrize("failure", [None, "error", "risk", "shadow", "budget"])
def test_blind_route_and_fail_closed(monkeypatch, tmp_path, resolved_config, failure):
    monkeypatch.setattr(fixtures, "NOW", NOW)
    config, _, seen = fixtures.setup_route(monkeypatch, tmp_path, resolved_config, shadow=False)
    config.values["OPTIONS_JEV_BLIND_TEST"] = True
    response = evaluation()
    if failure == "error":
        response["status"] = "ERROR"
    if failure == "risk":
        response["scores"]["false_breakout_risk"] = 0.9
    if failure == "shadow":
        response["routing_effect"] = False
    monkeypatch.setattr(cycle, "evaluate_candidate", lambda *a, **kw: response)
    if failure == "budget":
        from tools.decision_context import reserve_model_call

        for i in range(int(config.get("MAX_MODEL_CALLS_PER_DAY"))):
            reserve_model_call(
                tmp_path / "state/runtime/model_budget.json",
                maximum_calls=int(config.get("MAX_MODEL_CALLS_PER_DAY")),
                now=NOW,
                packet_signature=str(i),
            )
    result = asyncio.run(
        cycle._route_compact_decision(
            fixtures.event(), config=config, project_root=tmp_path, execute_models=True, now=NOW
        )
    )
    assert bool(seen) == (failure is None), result
    if seen:
        assert "jev" not in json.dumps(seen[0]).lower()
        assert result["options_jev_trial"]["slot"] == 0
        assert result["decision_verdict"]["action"] == "PASS"


def test_exit_policy_allowlist():
    packet = fixtures.packet()
    packet["hard_exit_policy"] = {
        "stop_loss_percent": 25,
        "take_profit_percent": 30,
        "software_managed": True,
        "secret": "excluded",
    }
    features = market_features(packet)
    assert features["hard_exit_policy"] == {
        "stop_loss_percent": 25,
        "take_profit_percent": 30,
        "software_managed": True,
    }


@pytest.mark.parametrize(
    "message,retries,category",
    [
        ("503 secret-api-key", 2, "server_unavailable"),
        ("429 secret-api-key", 1, "rate_limited"),
        ("401 secret-api-key", 1, "authentication"),
        ("unknown secret-api-key", 1, "unspecified_provider_error"),
    ],
)
def test_safe_broker_diagnostic_and_bounded_retry(monkeypatch, message, retries, category):
    class Session:
        calls = 0

        async def call_tool(self, name, args):
            assert name == "get_option_instruments"
            self.calls += 1
            return SimpleNamespace(isError=True, content=[SimpleNamespace(text=message)])

    async def sleep(seconds):
        assert seconds == 1

    monkeypatch.setattr("tools.robinhood_mcp.asyncio.sleep", sleep)
    session = Session()
    result = asyncio.run(_read_option_instruments(session, {}))
    assert session.calls == retries
    with pytest.raises(RuntimeError) as exc:
        _tool_payload(result, "get_option_instruments")
    assert category in str(exc.value)
    assert "secret-api-key" not in str(exc.value)
