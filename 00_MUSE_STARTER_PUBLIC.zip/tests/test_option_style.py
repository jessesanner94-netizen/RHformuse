from tools.option_style import assess_option_styles


def test_near_expiry_contract_can_be_day_only(base_candidate, resolved_config) -> None:
    candidate = {
        **base_candidate,
        "dte": 3,
        "bid": 0.95,
        "ask": 1.05,
        "delta": 0.40,
        "theta": -0.20,
    }
    result = assess_option_styles(candidate, resolved_config)

    assert result["eligible_styles"] == ["DAY"]
    assert "swing_dte_too_short" in result["style_reasons"]["SWING"]


def test_longer_dated_contract_can_pass_swing_greek_gate(base_candidate, resolved_config) -> None:
    candidate = {**base_candidate, "dte": 21}
    result = assess_option_styles(candidate, resolved_config)

    assert "SWING" in result["eligible_styles"]
    assert result["metrics"]["abs_delta"] == 0.5
    assert result["metrics"]["gamma_delta_per_1_percent_move"] == 0.01


def test_low_delta_lottery_contract_is_rejected_for_both_styles(
    base_candidate, resolved_config
) -> None:
    candidate = {**base_candidate, "delta": 0.05}
    result = assess_option_styles(candidate, resolved_config)

    assert result["eligible_styles"] == []
    assert "day_delta_out_of_range" in result["style_reasons"]["DAY"]
    assert "swing_delta_out_of_range" in result["style_reasons"]["SWING"]


def test_day_only_disables_swing_even_for_longer_dated_contract(base_candidate, resolved_config):
    from tools.config import TradingConfig

    config = TradingConfig({**resolved_config.values, "DAY_ONLY_OPTIONS": True})
    result = assess_option_styles({**base_candidate, "dte": 21}, config)
    assert result["eligible_styles"] == ["DAY"]
    assert "swing_disabled_day_only" in result["style_reasons"]["SWING"]
