from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from tools.config import TradingConfig
from tools.live_trading import (
    _load_state,
    _review_and_submit,
    apply_live_decision,
    monitor_live_portfolio,
)

NOW = datetime(2026, 8, 25, 14, 0, tzinfo=UTC)
CONTRACT_ID = "live-fixture-contract"


def test_opening_market_block_never_places_until_fresh_review_is_clear(tmp_path):
    now = datetime(2026, 8, 28, 13, 32, tzinfo=UTC)
    state_path = tmp_path / "state/live/STATE.json"
    state = _load_state(state_path, account_value=283.76, now=now)
    request = {
        "chain_symbol": "IBIT",
        "underlying_type": "equity",
        "type": "market",
        "quantity": "1",
        "time_in_force": "gfd",
        "market_hours": "regular_hours",
        "legs": [
            {
                "option_id": CONTRACT_ID,
                "position_effect": "close",
                "side": "sell",
                "ratio_quantity": 1,
            }
        ],
    }
    placements = []

    async def blocked_review(payload):
        return {
            "status": "REVIEWED",
            "result": {
                "data": {
                    **payload,
                    "order_checks": {
                        "alertType": "OPTION_MARKET_INVALID_TIME_MARKET_OPEN",
                        "details": {"regularTradingMarketOpen": "2026-08-28 09:35:00-04:00"},
                    },
                }
            },
        }

    async def place(payload):
        placements.append(payload)
        return {"status": "SUBMITTED", "result": {"data": {"id": "test-exit-order"}}}

    # Reaching the stated time alone never grants permission if the broker still rejects.
    for minute in (32, 36):
        result = asyncio.run(
            _review_and_submit(
                request,
                state=state,
                state_path=state_path,
                purpose="EXIT",
                context={},
                now=now.replace(minute=minute),
                reviewer=blocked_review,
                placer=place,
            )
        )
        assert result["status"] == "BLOCKED"
        assert result["review"]["allowed"] is False
        assert result["review"]["reasons"] == ["OPTION_MARKET_INVALID_TIME_MARKET_OPEN"]
        assert result["purpose"] == "EXIT"
        assert result["contract_identifier"] == CONTRACT_ID
        assert not placements
        assert not state["pending_orders"]
    cleared = asyncio.run(
        _review_and_submit(
            request,
            state=state,
            state_path=state_path,
            purpose="EXIT",
            context={},
            now=now.replace(minute=36),
            reviewer=_review,
            placer=place,
        )
    )
    assert cleared["status"] == "SUBMITTED"
    assert len(placements) == 1
    assert placements[0]["type"] == "market"


def _live_config(config: TradingConfig) -> TradingConfig:
    return TradingConfig(
        {
            **config.values,
            "LIVE_EXECUTION_ENABLED": True,
            "PAPER_TRADING_ENABLED": False,
            "MAX_OPEN_POSITIONS": 1,
            "MAX_CONTRACTS_PER_POSITION": 1,
            "MAX_NEW_POSITIONS_PER_DAY": 1,
        },
        source=config.source,
    )


def _snapshot(*, position: bool = False, bid: float = 1.0) -> dict[str, object]:
    return {
        "status": "OK",
        "as_of": NOW.isoformat(),
        "portfolio": {
            "total_value": "10000",
            "buying_power": {"buying_power": "10000"},
        },
        "positions": ([{"option_id": CONTRACT_ID, "quantity": "1"}] if position else []),
        "open_option_orders": [],
        "option_quotes": (
            [
                {
                    "instrument_id": CONTRACT_ID,
                    "bid_price": str(bid),
                    "ask_price": str(bid + 0.05),
                    "updated_at": NOW.isoformat(),
                }
            ]
            if position
            else []
        ),
    }


def _quote_refresh() -> dict[str, object]:
    return {
        "status": "OK",
        "as_of": NOW.isoformat(),
        "option_quotes": [
            {
                "instrument_id": CONTRACT_ID,
                "bid_price": "1.00",
                "ask_price": "1.05",
                "updated_at": NOW.isoformat(),
                "implied_volatility": "0.30",
                "delta": "0.50",
                "gamma": "0.01",
                "theta": "-0.05",
                "vega": "0.10",
                "rho": "0.02",
            }
        ],
        "equity_quotes": [
            {
                "symbol": "SPY",
                "last_trade_price": "100",
                "venue_last_trade_time": NOW.isoformat(),
            }
        ],
    }


def _decision(
    action: str = "BUY", *, position_id: str = "", order_id: str = ""
) -> dict[str, object]:
    return {
        "action": action,
        "candidate_id": CONTRACT_ID if action == "BUY" else "",
        "position_id": position_id,
        "order_id": order_id,
        "trade_style": "DAY" if action == "BUY" else "NONE",
        "hold_deadline": "",
        "thesis": "fixture thesis",
        "invalidation": "fixture invalidation",
        "reason": "fixture reason",
        "confidence": 0.8,
        "earnings_event": "none",
        "holds_through_earnings": False,
        "pre_uw_action": "BUY",
        "post_uw_action": "BUY",
        "what_uw_changed": "nothing",
    }


def _routing(decision: dict[str, object]) -> dict[str, object]:
    return {"sol": {"status": "COMPLETED", "output": json.dumps(decision)}}


def _event() -> dict[str, object]:
    return {
        "option_discovery": {
            "qualified_candidates": [
                {
                    "candidate_id": CONTRACT_ID,
                    "symbol": "SPY",
                    "option_symbol": "SPY260918C00100000",
                    "option_type": "CALL",
                    "expiration": "2026-09-18",
                    "strike": "100",
                    "dte": 24,
                    "underlying_price": 100.0,
                    "bid": 1.0,
                    "ask": 1.05,
                    "implied_volatility": 0.3,
                    "delta": 0.5,
                    "gamma": 0.01,
                    "theta": -0.05,
                    "vega": 0.1,
                    "rho": 0.02,
                }
            ]
        }
    }


async def _review(request):
    return {
        "status": "REVIEWED",
        "result": {"data": {**request, "order_checks": {}}},
    }


def test_live_entry_is_reviewed_persisted_and_submitted_once(
    tmp_path: Path, resolved_config
) -> None:
    placements: list[dict[str, object]] = []

    async def place(request):
        placements.append(dict(request))
        return {"status": "SUBMITTED", "result": {"data": {"id": "entry-order"}}}

    result = asyncio.run(
        apply_live_decision(
            _routing(_decision()),
            _event(),
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            quote_fetcher=lambda requests: asyncio.sleep(0, result=_quote_refresh()),
            reviewer=_review,
            placer=place,
        )
    )

    assert result["status"] == "SUBMITTED"
    assert result["orders_placed"] == 1
    assert len(placements) == 1
    assert placements[0]["type"] == "limit"
    assert placements[0]["time_in_force"] == "gfd"
    assert "ref_id" in placements[0]
    state = json.loads((tmp_path / "state" / "live" / "STATE.json").read_text())
    assert state["pending_orders"][0]["order_id"] == "entry-order"

    async def still_pending(_order_id):
        return {
            "status": "OK",
            "result": {"data": {"orders": [{"state": "confirmed"}]}},
        }

    pending = asyncio.run(
        monitor_live_portfolio(
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            order_status_fetcher=still_pending,
        )
    )
    assert pending["status"] == "ORDER_PENDING"
    assert pending["pending_entry"]["order_id"] == "entry-order"
    assert pending["pending_entry"]["symbol"] == "SPY"
    assert pending["pending_entry"]["thesis"] == "fixture thesis"


def test_live_entry_review_block_prevents_placement(tmp_path: Path, resolved_config) -> None:
    placements = 0

    async def review(request):
        return {
            "status": "REVIEWED",
            "result": {
                "data": {
                    **request,
                    "order_checks": {"BUYING_POWER": {"severity": "error"}},
                }
            },
        }

    async def place(request):
        nonlocal placements
        placements += 1
        return {}

    result = asyncio.run(
        apply_live_decision(
            _routing(_decision()),
            _event(),
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            quote_fetcher=lambda requests: asyncio.sleep(0, result=_quote_refresh()),
            reviewer=review,
            placer=place,
        )
    )

    assert result["status"] == "BLOCKED"
    assert placements == 0


@pytest.mark.parametrize("broker_quantity", [1, 2])
@pytest.mark.parametrize("unlimited_caps", [False, True])
@pytest.mark.parametrize("same_symbol", [False, True])
def test_live_entry_allows_only_second_reconciled_position_within_limits(
    tmp_path: Path, resolved_config, broker_quantity, unlimited_caps, same_symbol
) -> None:
    second_contract = "live-fixture-contract-2"
    config = TradingConfig(
        {
            **_live_config(resolved_config).values,
            "MAX_OPEN_POSITIONS": 3,
            "MAX_NEW_POSITIONS_PER_DAY": 3,
            **(
                {
                    "MAX_OPEN_POSITIONS": "UNLIMITED",
                    "MAX_PORTFOLIO_PREMIUM_AT_RISK": "UNLIMITED",
                    "MAX_SINGLE_POSITION_PREMIUM_AT_RISK": 150,
                    "MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT": 100,
                }
                if unlimited_caps
                else {}
            ),
        },
        source=resolved_config.source,
    )
    state_path = tmp_path / "state" / "live" / "STATE.json"
    state_path.parent.mkdir(parents=True)
    state_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "mode": "LIVE_UNATTENDED",
                "day": {
                    "date": "2026-08-25",
                    "start_equity": 10000,
                    "realized_pnl": 0,
                    "new_positions": 1,
                },
                "realized_pnl": 0,
                "pending_order": None,
                "positions": [
                    {
                        "position_id": "existing-position",
                        "contract_identifier": CONTRACT_ID,
                        "symbol": "SPY",
                        "entry_price": 1.0,
                        "entry_cost": 100,
                        "last_bid": 1.0,
                        "stop_price": 0.75,
                        "quantity": 1,
                    }
                ],
                "recent_closed_positions": [],
                "updated_at": NOW.isoformat(),
            }
        ),
        encoding="utf-8",
    )
    event = _event()
    candidate = event["option_discovery"]["qualified_candidates"][0]
    candidate["candidate_id"] = second_contract
    candidate["symbol"] = "SPY" if same_symbol else "QQQ"
    candidate["option_symbol"] = candidate["symbol"] + "260918C00101000"
    decision = _decision()
    decision["candidate_id"] = second_contract
    refresh = _quote_refresh()
    refresh["option_quotes"][0]["instrument_id"] = second_contract
    refresh["equity_quotes"][0]["symbol"] = candidate["symbol"]
    placements: list[dict[str, object]] = []

    async def place(request):
        placements.append(dict(request))
        return {"status": "SUBMITTED", "result": {"data": {"id": "second-entry"}}}

    snapshot = _snapshot()
    snapshot["positions"] = [{"option_id": CONTRACT_ID, "quantity": str(broker_quantity)}]
    result = asyncio.run(
        apply_live_decision(
            _routing(decision),
            event,
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot),
            quote_fetcher=lambda requests: asyncio.sleep(0, result=refresh),
            reviewer=_review,
            placer=place,
        )
    )

    if broker_quantity != 1:
        assert result["status"] == "BLOCKED"
        assert result["reason"] == "broker_local_position_quantity_mismatch"
        assert placements == []
        return
    if same_symbol:
        assert result["status"] == "BLOCKED"
        assert result["reason"] == "underlying_already_held"
        assert placements == []
        return
    assert result["status"] == "SUBMITTED"
    assert result["risk"]["metrics"]["prospective_open_positions"] == 2
    if unlimited_caps:
        assert result["risk"]["metrics"]["prospective_portfolio_premium_at_risk"] > 150
    assert len(placements) == 1


def test_live_entry_reports_exact_missing_underlying_timestamp(
    tmp_path: Path, resolved_config
) -> None:
    refresh = _quote_refresh()
    del refresh["equity_quotes"][0]["venue_last_trade_time"]

    result = asyncio.run(
        apply_live_decision(
            _routing(_decision()),
            _event(),
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            quote_fetcher=lambda requests: asyncio.sleep(0, result=refresh),
            reviewer=_review,
            placer=lambda request: asyncio.sleep(0, result={}),
        )
    )

    assert result["status"] == "BLOCKED"
    assert result["orders_placed"] == 0
    assert "underlying_trade_timestamp_missing" in result["blockers"]
    assert result["symbol"] == "SPY"


def test_cancel_entry_is_alert_only_and_never_calls_broker(tmp_path: Path, resolved_config) -> None:
    state_path = tmp_path / "state" / "live" / "STATE.json"
    state_path.parent.mkdir(parents=True)
    state_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "pending_order": {
                    "purpose": "ENTRY",
                    "order_id": "entry-order",
                    "context": {"candidate": {"symbol": "SPY"}},
                },
            }
        ),
        encoding="utf-8",
    )
    broker_calls = 0

    async def broker_call(*_args, **_kwargs):
        nonlocal broker_calls
        broker_calls += 1
        return {}

    result = asyncio.run(
        apply_live_decision(
            _routing(_decision("CANCEL_ENTRY", order_id="entry-order")),
            {},
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=broker_call,
            quote_fetcher=broker_call,
            reviewer=broker_call,
            placer=broker_call,
        )
    )

    assert result["status"] == "ATTENTION"
    assert result["manual_action"] == "CANCEL_ORDER"
    assert result["order_id"] == "entry-order"
    assert result["symbol"] == "SPY"
    assert result["orders_cancelled"] == 0
    assert broker_calls == 0


def test_software_stop_submits_market_exit_and_records_fill(
    tmp_path: Path, resolved_config
) -> None:
    config = _live_config(resolved_config)

    async def entry_place(request):
        return {"status": "SUBMITTED", "result": {"data": {"id": "entry-order"}}}

    asyncio.run(
        apply_live_decision(
            _routing(_decision()),
            _event(),
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            quote_fetcher=lambda requests: asyncio.sleep(0, result=_quote_refresh()),
            reviewer=_review,
            placer=entry_place,
        )
    )

    async def entry_filled(order_id):
        return {
            "status": "OK",
            "result": {"data": {"orders": [{"state": "filled", "average_price": "1.05"}]}},
        }

    entry_result = asyncio.run(
        monitor_live_portfolio(
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            order_status_fetcher=entry_filled,
        )
    )
    assert entry_result["status"] == "ENTRY_FILLED"
    assert entry_result["position"]["stop_price"] == 0.7875
    assert entry_result["position"]["take_profit_price"] == 1.365

    exits: list[dict[str, object]] = []

    async def exit_place(request):
        exits.append(dict(request))
        return {"status": "SUBMITTED", "result": {"data": {"id": "exit-order"}}}

    stop_result = asyncio.run(
        monitor_live_portfolio(
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot(position=True, bid=0.75)),
            reviewer=_review,
            placer=exit_place,
        )
    )
    assert stop_result["status"] == "SUBMITTED"
    assert stop_result["exit_reason"] == "STOP_LOSS"
    assert exits[0]["type"] == "market"
    assert exits[0]["legs"][0]["position_effect"] == "close"

    async def exit_filled(order_id):
        return {
            "status": "OK",
            "result": {"data": {"orders": [{"state": "filled", "average_price": "0.74"}]}},
        }

    filled = asyncio.run(
        monitor_live_portfolio(
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot(position=True, bid=0.74)),
            order_status_fetcher=exit_filled,
        )
    )
    assert filled["status"] == "EXIT_FILLED"
    assert filled["closed_position"]["realized_pnl"] == -31.0


def test_model_exit_requires_matching_persistent_position_id(
    tmp_path: Path, resolved_config
) -> None:
    result = asyncio.run(
        apply_live_decision(
            _routing(_decision("EXIT", position_id="missing")),
            {},
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot(position=True)),
            reviewer=_review,
            placer=lambda request: asyncio.sleep(0, result={}),
        )
    )
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "model_exit_local_position_or_order_invalid"


def test_live_snapshot_transient_exception_group_retries_once(
    tmp_path: Path, resolved_config
) -> None:
    calls = 0

    async def transient_snapshot():
        nonlocal calls
        calls += 1
        if calls == 1:
            raise ExceptionGroup("stream closed", [ConnectionError("temporary reset")])
        return _snapshot()

    result = asyncio.run(
        monitor_live_portfolio(
            _live_config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=transient_snapshot,
        )
    )

    assert calls == 2
    assert result["status"] == "QUIET"
    assert result["orders_placed"] == 0


@pytest.mark.parametrize("order_state", ["rejected", "cancelled", "failed", "voided", "expired"])
@pytest.mark.parametrize("reported_quantity", [None, "1"])
def test_terminal_failure_without_explicit_zero_fill_keeps_pending(
    tmp_path: Path, resolved_config, order_state: str, reported_quantity: str | None
) -> None:
    config = _live_config(resolved_config)
    state_path = tmp_path / "state" / "live" / "STATE.json"
    state_path.parent.mkdir(parents=True)
    state = _load_state(state_path, account_value=10000, now=NOW, config=config)
    state["pending_orders"] = [{
        "purpose": "ENTRY", "order_id": "synthetic-order", "ref_id": "synthetic-ref",
        "request": {"quantity": "1", "legs": [{"option_id": CONTRACT_ID}]},
        "context": {},
    }]
    state_path.write_text(json.dumps(state), encoding="utf-8")
    order = {"state": order_state}
    if reported_quantity is not None:
        order["processed_quantity"] = reported_quantity

    async def never_place(request):
        raise AssertionError("Ambiguous terminal order must not cause a new submission")

    for _ in range(2):  # The same ambiguity must remain fail-closed after restart.
        result = asyncio.run(monitor_live_portfolio(
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot()),
            order_status_fetcher=lambda _: asyncio.sleep(0, result={"orders": [order]}),
            placer=never_place,
        ))
        saved = json.loads(state_path.read_text(encoding="utf-8"))
        assert result["status"] == "ATTENTION"
        assert result["reason"] == "partial_fill_reconciliation_required"
        assert result["orders_placed"] == 0
        assert saved["pending_orders"][0]["order_id"] == "synthetic-order"
