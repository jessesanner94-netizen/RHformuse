import asyncio
from datetime import UTC, datetime, timedelta

import tools.watch_monitor as monitor


def test_fresh_equity_is_used_before_style_and_cheap_gates(monkeypatch, tmp_path):
    now = datetime(2026, 9, 21, 14, tzinfo=UTC)
    identity = {
        "symbol": "SPY",
        "candidate_id": "contract",
        "option_symbol": "SPYtest",
        "expiration": "2026-09-25",
        "strike": "500",
        "option_type": "CALL",
        "trade_style": "DAY",
    }
    monkeypatch.setattr(
        monitor,
        "active_watches",
        lambda *a, **k: [{"identity": identity, "status": "ACTIVE", "watch_id": "watch"}],
    )

    async def fetch(requests):
        return {
            "equity_quotes": [
                {
                    "symbol": "SPY",
                    "last_trade_price": "490",
                    "venue_last_trade_time": (now - timedelta(hours=1)).isoformat(),
                    "last_non_reg_trade_price": "501",
                    # Venue data commonly arrives after the cycle-start timestamp.
                    "venue_last_non_reg_trade_time": (now + timedelta(seconds=5)).isoformat(),
                }
            ]
        }

    def build(raw, **kwargs):
        assert raw["equity_quotes"][0]["last_trade_price"] == "501.0"
        return [{**identity, "underlying_price": 501, "eligible_trade_styles": ["DAY"]}]

    monkeypatch.setattr(monitor, "build_news_candidates", build)
    monkeypatch.setattr(
        monitor, "scan_candidates", lambda candidates, config: {"qualified": candidates}
    )
    result = asyncio.run(monitor.refresh_watches({}, project_root=tmp_path, now=now, fetcher=fetch))
    assert result["status"] == "OK"
    assert result["qualified_candidates"][0]["underlying_quote_updated_at"] == (
        now + timedelta(seconds=5)
    ).isoformat()
    assert result["watch_results"][0]["status"] == "ROUTE_READY"


def test_underlying_beyond_future_skew_is_diagnosed_without_routing(monkeypatch, tmp_path):
    now = datetime(2026, 9, 21, 14, tzinfo=UTC)
    identity = {
        "symbol": "SPY",
        "candidate_id": "contract",
        "expiration": "2026-09-25",
        "strike": "500",
        "option_type": "CALL",
        "trade_style": "DAY",
    }
    monkeypatch.setattr(
        monitor,
        "active_watches",
        lambda *a, **k: [{"identity": identity, "status": "ACTIVE", "watch_id": 7}],
    )

    async def fetch(requests):
        return {
            "equity_quotes": [
                {
                    "symbol": "SPY",
                    "last_trade_price": "501",
                    "venue_last_trade_time": (now + timedelta(seconds=31)).isoformat(),
                }
            ]
        }

    monkeypatch.setattr(
        monitor,
        "build_news_candidates",
        lambda *a, **k: [{**identity, "eligible_trade_styles": ["DAY"]}],
    )
    monkeypatch.setattr(
        monitor, "scan_candidates", lambda candidates, config: {"qualified": candidates}
    )
    result = asyncio.run(monitor.refresh_watches({}, project_root=tmp_path, now=now, fetcher=fetch))
    assert result["qualified_candidates"] == []
    assert result["watch_results"] == [
        {
            "watch_id": 7,
            "candidate_id": "contract",
            "status": "UNAVAILABLE",
            "reason": "fresh_underlying_quote_unavailable",
        }
    ]


def test_missing_exact_contract_is_diagnosed(monkeypatch, tmp_path):
    identity = {
        "symbol": "QQQ",
        "candidate_id": "missing",
        "expiration": "2026-09-23",
        "strike": "745",
        "option_type": "CALL",
        "trade_style": "DAY",
    }
    monkeypatch.setattr(
        monitor,
        "active_watches",
        lambda *a, **k: [{"identity": identity, "status": "ACTIVE", "watch_id": 3}],
    )
    monkeypatch.setattr(monitor, "build_news_candidates", lambda *a, **k: [])
    monkeypatch.setattr(monitor, "scan_candidates", lambda *a, **k: {"qualified": []})

    async def fetch(requests):
        return {"equity_quotes": []}

    result = asyncio.run(monitor.refresh_watches({}, project_root=tmp_path, fetcher=fetch))
    assert result["watch_results"][0]["reason"] == "exact_contract_or_quote_unavailable"
