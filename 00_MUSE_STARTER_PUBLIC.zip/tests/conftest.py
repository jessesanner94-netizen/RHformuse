from __future__ import annotations

from pathlib import Path

import pytest

from tools.config import TradingConfig, load_config

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures"


@pytest.fixture
def resolved_config() -> TradingConfig:
    return load_config(FIXTURES / "CONFIG.resolved-test-only.md")


@pytest.fixture
def base_candidate() -> dict[str, object]:
    return {
        "candidate_id": "spy-fixture-contract",
        "symbol": "SPY",
        "option_type": "CALL",
        "dte": 14,
        "underlying_price": 500.0,
        "bid": 4.8,
        "ask": 5.2,
        "option_volume": 1000,
        "option_open_interest": 5000,
        "underlying_avg_daily_dollar_volume": 1_000_000_000,
        "quote_is_fresh": True,
        "setup_qualified": True,
        "implied_volatility": 0.25,
        "delta": 0.5,
        "gamma": 0.002,
        "theta": -0.05,
        "vega": 0.1,
        "rho": 0.02,
        "premium_at_risk": 400,
        "quantity": 1,
        "holds_through_earnings": False,
        "is_averaging_down": False,
        "protective_stop_planned": True,
        "event_review_complete": True,
        "contract_review_complete": True,
    }


@pytest.fixture
def account() -> dict[str, float | int]:
    return {
        "account_value": 25_000,
        "account_value_start_of_day": 25_100,
        "buying_power": 5_000,
        "daily_pnl": -100,
        "open_premium_at_risk": 500,
        "open_position_count": 1,
        "new_positions_today": 0,
    }


@pytest.fixture
def historical() -> dict[str, object]:
    return {
        "asset_returns": [
            [0.01, 0.005],
            [-0.02, -0.01],
            [0.015, -0.002],
            [-0.01, 0.003],
            [0.004, 0.008],
        ],
        "weights": [0.5, 0.5],
        "confidence_level": 0.95,
    }
