from __future__ import annotations

from pathlib import Path

import pytest

from tools.config import ConfigError, load_config, parse_config_text

ROOT = Path(__file__).resolve().parents[1]


def test_production_config_has_approved_spy_qqq_paper_thresholds() -> None:
    config = load_config(ROOT / "CONFIG.md")
    assert config.live_execution_enabled is False
    assert config.paper_trading_enabled is True
    assert config.paper_blockers() == []
    assert "LIVE_EXECUTION_ENABLED" in config.live_blockers()
    assert config.get("UW_ENABLED") is False
    assert config.get("WATCHLIST_ONLY") is True
    assert config.watchlist_symbols() == ("SPY", "QQQ")
    assert config.get("TRADE_US_EQUITY_OPTIONS") is False
    assert config.get("TRADE_ETF_OPTIONS") is True
    assert config.get("PAPER_STARTING_CASH") == 369
    assert config.get("MAX_OPEN_POSITIONS") == "UNLIMITED"
    assert config.risk_limit("MAX_OPEN_POSITIONS") is None
    assert config.get("MAX_CONTRACTS_PER_POSITION") == 1
    assert config.get("MAX_NEW_POSITIONS_PER_DAY") == 3
    assert config.get("MIN_SINGLE_POSITION_PREMIUM_AT_RISK") == 50
    assert config.get("MAX_PORTFOLIO_PREMIUM_AT_RISK") == "UNLIMITED"
    assert config.risk_limit("MAX_PORTFOLIO_PREMIUM_AT_RISK") is None
    assert config.get("MAX_SINGLE_POSITION_PREMIUM_AT_RISK") == 250
    assert config.get("MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT") == 100
    assert config.get("NEW_OPPORTUNITY_SCAN_MINUTES") == 5
    assert config.get("ECONOMIC_CALENDAR_ENABLED") is True
    assert config.get("NEWS_TRIAGE_MODEL") == "gpt-5.6-luna"
    assert config.get("FINAL_DECISION_MODEL") == "gpt-5.6-luna"
    assert config.get("FINAL_DECISION_REASONING_EFFORT") == "high"
    assert config.get("MAX_MODEL_CALLS_PER_DAY") == 20
    assert config.get("OPTIONS_LUNA_VETO_ENABLED") is False
    assert config.get("PAPER_PRIMARY_DAILY_GREEN_LOCK_ENABLED") is True
    assert config.get("OPTIONS_DAILY_GREEN_LOCK_ENABLED") is True
    assert config.get("OPTIONS_STRATEGY_EPOCH") == "python_jev_green_lock_20261009"
    assert config.options_blockers() == []
    assert config.get("MIN_NET_REWARD_TO_RISK") == 1.00
    assert config.get("MAX_DAILY_LOSS_DOLLARS") == 45
    assert config.get("MAX_DAILY_LOSS_PERCENT") == 12.5
    assert config.get("TAKE_PROFIT_PERCENT") == 30
    assert config.get("PAPER_BASELINE_ENABLED") is False
    assert config.get("PAPER_DAILY_GREEN_LOCK_ENABLED") is False
    assert config.get("ENABLE_MULTI_WATCH") is False
    assert config.get("JEV_SHADOW_MODE") is False
    assert config.get("ENABLE_JEV_ESCALATION") is True
    assert config.get("CRYPTO_SYMBOL") == "ETH-USD"
    assert config.monitor_policy()["stop_loss_percent"] == 25


def test_duplicate_settings_are_rejected() -> None:
    with pytest.raises(ConfigError, match="duplicate setting"):
        parse_config_text("LIVE_EXECUTION_ENABLED: false\nLIVE_EXECUTION_ENABLED: true\n")


def test_missing_execution_lock_is_rejected() -> None:
    with pytest.raises(ConfigError, match="LIVE_EXECUTION_ENABLED is missing"):
        parse_config_text("MAX_OPEN_POSITIONS: 1\n")
