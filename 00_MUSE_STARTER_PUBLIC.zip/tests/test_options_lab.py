"""Offline strategy-parity, chronology, isolation and conservative fill checks."""

import asyncio
import copy
import json
import socket
from datetime import UTC, datetime, timedelta

import pytest

from tools.config import load_config
from tools.options_lab import (
    ROOT,
    compare,
    init_experiment,
    load_experiment,
    read_frames,
    run_tape,
)

NOW = datetime(2026, 10, 19, 14, tzinfo=UTC)


@pytest.fixture(autouse=True)
def offline_only(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("experiment attempted external I/O or a model call")
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr("tools.scheduled_cycle.run_trigger", forbidden)
    monkeypatch.setattr("tools.scheduled_cycle.evaluate_candidate", forbidden)
    monkeypatch.setattr("tools.paper_runner.fetch_quote_refresh", forbidden)
    monkeypatch.setattr("tools.economic_calendar.fetch_text", forbidden)


@pytest.fixture
def experiment(tmp_path):
    return init_experiment("baseline", lab_root=tmp_path)


def frame(at=NOW, *, kind="opportunity", bid=1.08, ask=1.1):
    stamp = at.isoformat()
    candidate = {
        "candidate_id": "synthetic-spy", "symbol": "SPY", "option_type": "CALL",
        "strike": 500, "expiration": "2026-11-06", "underlying_price": 500,
        "bid": bid, "ask": ask, "quote_updated_at": stamp,
        "underlying_quote_updated_at": stamp, "option_volume": 1000,
        "option_open_interest": 5000, "underlying_avg_daily_dollar_volume": 1e10,
        "setup_qualified": True, "implied_volatility": 0.25, "delta": 0.5,
        "gamma": 0.002, "theta": -0.02, "vega": 0.1, "rho": 0.02,
        "event_review_complete": True, "contract_review_complete": True,
    }
    return {
        "schema_version": 1, "as_of": stamp, "kind": kind, "source": "SYNTHETIC_TEST_ONLY",
        "candidates": [candidate] if kind == "opportunity" else [],
        "quotes": {"status": "OK", "as_of": stamp, "option_quotes": [{
            "instrument_id": "synthetic-spy", "bid_price": str(bid), "ask_price": str(ask),
            "updated_at": stamp, "volume": 1000, "open_interest": 5000,
            **{k: candidate[k] for k in ("delta", "gamma", "theta", "vega", "rho",
                                        "implied_volatility")},
        }]},
        "technical": {"SPY": {
            "status": "OK", "as_of": stamp, "instrument_type": "ETF",
            "style_scores": {"DAY": 7, "SWING": 17}, "timeframes": {
                "5M": {"status": "OK", "trend": "BULLISH", "trend_score": 3},
                "15M": {"status": "OK", "trend": "BULLISH", "trend_score": 3},
            }, "earnings": {"status": "NOT_APPLICABLE", "next_date": None},
        }},
        "jev": {"synthetic-spy": {"status": "OK", "as_of": stamp, "scores": {
            "setup_quality": 0.7, "entry_timing_quality": 0.7, "escalate_to_luna": 0.7,
        }}},
        "economic_calendar": {
            "status": "OK", "period": at.strftime("%Y-%m"), "fetched_at": stamp,
            "events": [], "errors": [], "coverage": "SYNTHETIC_TEST_ONLY",
        },
    }


def tape(tmp_path, frames, name="tape"):
    path = tmp_path / f"{name}.jsonl"
    path.write_text("".join(json.dumps(row) + "\n" for row in frames))
    return path


def run(experiment, path, name="run", mode="replay"):
    return asyncio.run(run_tape(experiment, path, name, mode=mode))


def cycles(experiment, name="run"):
    return [json.loads(line) for line in
            (experiment / "runs" / name / "CYCLES.jsonl").read_text().splitlines()]


def test_init_copies_strategy_without_modifying_production_or_starting(experiment):
    production = load_config(ROOT / "CONFIG.md")
    frozen, manifest = load_experiment(experiment)
    for key, value in production.values.items():
        if key not in manifest["execution_overrides"]:
            assert frozen.get(key) == value
    assert frozen.live_execution_enabled is False
    assert frozen.get("ECONOMIC_CALENDAR_OFFLINE") is True
    assert manifest["status"] == "DORMANT"
    assert manifest["strategy_setting_changes"] == {}
    assert not (experiment / "state").exists()
    assert not (experiment / "runs").exists()


def test_real_shared_route_bid_ask_costs_profit_lock_and_independent_runs(experiment, tmp_path):
    rows = [frame(), frame(NOW + timedelta(seconds=10), kind="monitor", bid=1.5, ask=1.52),
            frame(NOW + timedelta(seconds=20))]
    path = tape(tmp_path, rows)
    first = run(experiment, path)
    second = run(experiment, path, "same_again")
    assert first["performance"] == second["performance"]
    assert first["performance"]["realized_pnl"] == 37.9
    assert first["performance"]["equity"] == 406.9
    assert first["performance"]["estimated_execution_costs"] == 2.1
    assert first["performance"]["day"]["green_lock_active"] is True
    assert first["performance"]["closed_trades"] == 1
    assert first["performance"]["open_positions"] == 0
    assert first["status"] == "COMPLETED"
    assert first["input_sources"] == ["SYNTHETIC_TEST_ONLY"]
    log = cycles(experiment)
    assert log[0]["entry"]["position"]["entry_price"] == 1.1
    assert log[0]["routing"]["decision"]["codex_invoked"] is False
    assert log[2]["skip_reason"] == "daily_green_lock_active"
    assert compare([experiment / "runs/run", experiment / "runs/same_again"])[
        "same_observation_tapes"] is True


def test_missing_and_stale_quotes_do_not_invent_exits(experiment, tmp_path):
    missing = frame(NOW + timedelta(seconds=10), kind="monitor")
    missing["quotes"]["option_quotes"] = []
    stale = frame(NOW + timedelta(seconds=40), kind="monitor", bid=0.5, ask=0.52)
    stale["quotes"]["option_quotes"][0]["updated_at"] = NOW.isoformat()
    result = run(experiment, tape(tmp_path, [frame(), missing, stale]))
    assert result["status"] == "INCOMPLETE_DATA"
    assert result["performance"]["open_positions"] == 1
    assert result["performance"]["closed_trades"] == 0
    assert result["data_issues"]["PAPER_QUOTE_MISSING"] == 1
    assert result["data_issues"]["PAPER_QUOTE_STALE"] == 1
    assert result["data_issues"]["monitoring_gap"] == 1


def test_stop_uses_observed_gap_bid_and_never_guarantees_stop_price(experiment, tmp_path):
    result = run(experiment, tape(tmp_path, [frame(), frame(
        NOW + timedelta(minutes=5), kind="monitor", bid=0.5, ask=0.52)]))
    assert result["performance"]["realized_pnl"] == -62.1
    assert result["performance"]["closed_trades"] == 1
    assert result["status"] == "INCOMPLETE_DATA"


@pytest.mark.parametrize("missing", ["technical", "jev", "economic_calendar"])
def test_required_evidence_unavailable_blocks_without_external_calls(experiment, tmp_path, missing):
    row = frame()
    row.pop(missing)
    result = run(experiment, tape(tmp_path, [row]))
    assert result["performance"]["open_positions"] == 0
    assert result["performance"]["closed_trades"] == 0
    assert result["status"] == "INCOMPLETE_DATA"


def test_rank_selection_and_missing_partial_ranking_fail_closed(experiment, tmp_path):
    row = frame()
    qqq = {**row["candidates"][0], "candidate_id": "synthetic-qqq", "symbol": "QQQ"}
    row["candidates"].append(qqq)
    row["technical"]["QQQ"] = copy.deepcopy(row["technical"]["SPY"])
    row["quotes"]["option_quotes"].append({
        **row["quotes"]["option_quotes"][0], "instrument_id": "synthetic-qqq"})
    row["jev"]["synthetic-qqq"] = {
        "status": "OK", "as_of": NOW.isoformat(), "scores": {
            "setup_quality": 0.9, "entry_timing_quality": 0.9, "escalate_to_luna": 0.9}}
    run(experiment, tape(tmp_path, [row]))
    assert cycles(experiment)[0]["entry"]["position"]["symbol"] == "QQQ"
    row["jev"].pop("synthetic-spy")
    result = run(experiment, tape(tmp_path, [row], "partial"), "partial")
    assert result["performance"]["open_positions"] == 0
    assert result["status"] == "INCOMPLETE_DATA"
    assert cycles(experiment, "partial")[0]["routing"]["decision"]["reason"] == (
        "jev_ranking_unavailable")


def test_macro_blackout_is_a_normal_pass_and_stale_calendar_is_missing_data(experiment, tmp_path):
    row = frame()
    row["economic_calendar"]["events"] = [
        {"name": "synthetic macro", "at": NOW.isoformat(), "kind": "RELEASE"}]
    result = run(experiment, tape(tmp_path, [row]))
    assert result["performance"]["open_positions"] == 0
    assert result["status"] == "COMPLETED"
    row["economic_calendar"]["fetched_at"] = (NOW - timedelta(hours=2)).isoformat()
    result = run(experiment, tape(tmp_path, [row], "stale_macro"), "stale_macro")
    assert result["status"] == "INCOMPLETE_DATA"


def test_prospective_daily_loss_budget_blocks_a_too_large_premium(experiment, tmp_path):
    result = run(experiment, tape(tmp_path, [frame(bid=1.98, ask=2.0)]))
    assert result["performance"]["open_positions"] == 0
    assert "deterministic_risk_not_allowed" in str(cycles(experiment))


def test_rejects_technical_conflict_and_final_quote_economics(experiment, tmp_path):
    row = frame()
    row["technical"]["SPY"]["style_scores"]["DAY"] = -5
    result = run(experiment, tape(tmp_path, [row]))
    assert result["performance"]["open_positions"] == 0
    assert "preferred_style_technical_direction_not_supportive" in str(cycles(experiment))
    row = frame()
    row["quotes"]["option_quotes"][0].update(bid_price="0.79", ask_price="0.80")
    result = run(experiment, tape(tmp_path, [row], "cheap"), "cheap")
    assert result["performance"]["open_positions"] == 0
    assert "net_reward_to_risk_below_minimum" in str(cycles(experiment, "cheap"))


@pytest.mark.parametrize("damage", ["future", "duplicate", "reverse", "naive", "nan", "outcome"])
def test_bad_tape_rejected_before_a_run_is_created(experiment, tmp_path, damage):
    rows = [frame(), frame(NOW + timedelta(seconds=10), kind="monitor")]
    if damage == "future":
        rows[1]["quotes"]["option_quotes"][0]["updated_at"] = (
            NOW + timedelta(seconds=11)).isoformat()
    elif damage == "duplicate":
        rows[1] = copy.deepcopy(rows[0])
    elif damage == "reverse":
        rows.reverse()
    elif damage == "naive":
        rows[0]["as_of"] = "2026-10-19T14:00:00"
    elif damage == "nan":
        rows[0]["candidates"][0]["ask"] = float("nan")
    else:
        rows[0]["technical"]["SPY"]["future_return"] = 0.05
    with pytest.raises(ValueError):
        run(experiment, tape(tmp_path, rows))
    assert not (experiment / "runs/run").exists()


def test_paper_resume_deduplicates_and_is_separate_from_replay(experiment, tmp_path):
    first = tape(tmp_path, [frame()], "first")
    run(experiment, first, mode="paper")
    with pytest.raises(ValueError, match="already processed"):
        run(experiment, first, mode="paper")
    later = tape(tmp_path, [frame(NOW + timedelta(seconds=10), kind="monitor",
                                 bid=1.5, ask=1.52)], "later")
    result = run(experiment, later, mode="paper")
    assert result["performance"]["closed_trades"] == 1
    assert len(result["input_sha256"]) == 2
    assert len(cycles(experiment)) == 2
    with pytest.raises(ValueError, match="already exists"):
        run(experiment, later)


def test_tampered_configs_and_live_overrides_are_blocked(experiment, tmp_path):
    with pytest.raises(ValueError, match="cannot enable execution"):
        init_experiment("unsafe", lab_root=tmp_path, overrides={"LIVE_EXECUTION_ENABLED": True})
    with (experiment / "CONFIG.md").open("a") as handle:
        handle.write("\n# tampered\n")
    with pytest.raises(ValueError, match="frozen experiment config changed"):
        load_experiment(experiment)


def test_positive_day_resets_on_next_eastern_session(experiment, tmp_path):
    rows = [frame(), frame(NOW + timedelta(seconds=10), kind="monitor", bid=1.5, ask=1.52),
            frame(NOW + timedelta(days=1))]
    result = run(experiment, tape(tmp_path, rows))
    assert result["performance"]["day"]["date"] == "2026-10-20"
    assert result["performance"]["day"]["green_lock_active"] is False
    assert result["performance"]["open_positions"] == 1


def test_empty_input_rejected(tmp_path):
    with pytest.raises(ValueError, match="empty observation"):
        read_frames(tape(tmp_path, []))
