from __future__ import annotations

import json

import pytest

from tools.unusual_whales import (
    CLIENT_API_ID,
    UnusualWhalesClient,
    UnusualWhalesConfigurationError,
    configuration_status,
)


class FakeResponse:
    status = 200
    headers = {"X-RateLimit-Remaining": "29999", "X-RateLimit-Reset": "60"}

    def __enter__(self) -> FakeResponse:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def read(self) -> bytes:
        return json.dumps({"data": [{"ticker": "SPY"}]}).encode()


def test_status_never_reveals_key() -> None:
    result = configuration_status({"UW_API_KEY": "top-secret"})
    assert result["api_key_configured"] is True
    assert "top-secret" not in json.dumps(result)


def test_missing_key_fails_closed() -> None:
    with pytest.raises(UnusualWhalesConfigurationError, match="UW_API_KEY"):
        UnusualWhalesClient(api_key="")


def test_market_tide_uses_required_headers_without_key_in_url() -> None:
    captured = {}

    def opener(request, *, timeout):
        captured["url"] = request.full_url
        captured["authorization"] = request.get_header("Authorization")
        captured["client_id"] = request.get_header("Uw-client-api-id")
        captured["timeout"] = timeout
        return FakeResponse()

    result = UnusualWhalesClient(api_key="secret", opener=opener).market_tide()
    assert captured["authorization"] == "Bearer secret"
    assert captured["client_id"] == CLIENT_API_ID
    assert "secret" not in captured["url"]
    assert captured["timeout"] == 20.0
    assert result.rate_limit_remaining == "29999"


def test_endpoint_allowlist_rejects_unknown_paths() -> None:
    client = UnusualWhalesClient(api_key="secret", opener=lambda *args, **kwargs: None)
    with pytest.raises(UnusualWhalesConfigurationError, match="not allowlisted"):
        client._get("/api/options/flow")


def test_ticker_is_normalized_and_validated() -> None:
    seen = {}

    def opener(request, *, timeout):
        seen["url"] = request.full_url
        return FakeResponse()

    client = UnusualWhalesClient(api_key="secret", opener=opener)
    client.spot_gex_by_strike("spy")
    assert "/api/stock/SPY/spot-exposures/strike" in seen["url"]
    with pytest.raises(ValueError, match="invalid ticker"):
        client.dark_pool("SPY/../../bad")


def test_flow_direction_cannot_be_ambiguous() -> None:
    client = UnusualWhalesClient(api_key="secret", opener=lambda *args, **kwargs: None)
    with pytest.raises(ValueError, match="cannot both be true"):
        client.flow_alerts(is_call=True, is_put=True)
