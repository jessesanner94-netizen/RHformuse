from __future__ import annotations

import json
from pathlib import Path

from tools.dry_run import run_cycle

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "tests" / "fixtures" / "CONFIG.resolved-test-only.md"
POSITIONS = ROOT / "tests" / "fixtures" / "POSITIONS.empty-test-only.md"


def test_zero_candidate_cycle_stops_cheaply() -> None:
    payload = json.loads(
        (ROOT / "tests" / "fixtures" / "dry_run_zero_candidates.json").read_text(encoding="utf-8")
    )
    result = run_cycle(payload, config_path=CONFIG, positions_path=POSITIONS)
    assert result["status"] == "NO TRADE"
    assert result["cheap_scan"]["status"] == "ZERO_QUALIFIED"
    assert result["candidate_decisions"] == []
    assert result["orders_placed"] == 0


def test_memory_mismatch_stops_before_scanner(account, base_candidate) -> None:
    payload = {
        "account": account,
        "broker_snapshot": {
            "snapshot_is_fresh": True,
            "positions": [{"contract_identifier": "unrecorded", "quantity": 1}],
            "open_orders": [],
        },
        "tool_status": {"robinhood": "OK"},
        "candidates": [base_candidate],
    }
    result = run_cycle(payload, config_path=CONFIG, positions_path=POSITIONS)
    assert result["status"] == "WAIT"
    assert result["cheap_scan"]["status"] == "NOT_RUN"
    assert result["orders_placed"] == 0


def test_qualified_candidate_stops_for_agent_escalation(
    account, base_candidate, historical
) -> None:
    payload = {
        "account": account,
        "broker_snapshot": {"snapshot_is_fresh": True, "positions": [], "open_orders": []},
        "open_position_reviews": [],
        "tool_status": {"robinhood": "OK", "vibe": "OK", "news_social": "OK"},
        "candidates": [base_candidate],
        "historical": historical,
    }
    result = run_cycle(payload, config_path=CONFIG, positions_path=POSITIONS)
    assert result["status"] == "WAIT"
    assert result["cheap_scan"]["status"] == "QUALIFIED"
    assert result["candidate_decisions"][0]["reasons"] == ["escalated_agent_review_required"]
    assert result["candidate_decisions"][0]["order_preview"] == "NOT_REQUESTED"
    assert result["orders_placed"] == 0
    assert result["persistent_writes"] == []
