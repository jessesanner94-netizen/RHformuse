import json
from datetime import UTC, datetime
from pathlib import Path

from tools.event_log import append_cycle_log


def test_cycle_log_preserves_full_result_and_human_activity(tmp_path: Path) -> None:
    now = datetime(2026, 8, 24, 14, 0, tzinfo=UTC)
    result = {
        "routing": {"luna": {"status": "COMPLETED"}, "sol": None},
        "paper": {"status": "MONITORED"},
    }
    written = append_cycle_log(tmp_path, "opportunities", result, now=now)

    record = json.loads(Path(written["jsonl"]).read_text(encoding="utf-8"))
    assert record["result"] == result
    activity = Path(written["activity"]).read_text(encoding="utf-8")
    assert "luna=COMPLETED" in activity
    assert "paper=MONITORED" in activity
