from __future__ import annotations

import pytest

from tools.config import TradingConfig
from tools.portfolio_risk import evaluate_risk
from tools.scheduled_cycle import _live_entry_capacity_reached


@pytest.fixture
def cash_config(resolved_config):
    return TradingConfig(
        {
            **resolved_config.values,
            "MAX_OPEN_POSITIONS": "UNLIMITED",
            "MAX_PORTFOLIO_PREMIUM_AT_RISK": "UNLIMITED",
            "MAX_CONTRACTS_PER_POSITION": 1,
            "MAX_NEW_POSITIONS_PER_DAY": 3,
            "MIN_SINGLE_POSITION_PREMIUM_AT_RISK": 50,
            "MAX_SINGLE_POSITION_PREMIUM_AT_RISK": 150,
            "MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT": 100,
            "MAX_DAILY_LOSS_DOLLARS": 45,
            "MAX_DAILY_LOSS_PERCENT": 12.5,
        }
    )


@pytest.fixture
def cash_account():
    return {
        "account_value": 351.96,
        "account_value_start_of_day": 369,
        "buying_power": 248.96,
        "daily_pnl": 0,
        "open_stop_risk": 7.5,
        "open_premium_at_risk": 120,
        "open_position_count": 1,
        "new_positions_today": 1,
    }


@pytest.mark.parametrize("premium", [50, 150])
def test_more_than_150_total_premium_is_allowed(cash_config, cash_account, base_candidate, premium):
    result = evaluate_risk(
        cash_account, {**base_candidate, "premium_at_risk": premium}, cash_config
    )
    assert result.status == "ALLOWED"
    assert result.metrics["effective_single_position_cap"] == 150
    assert result.metrics["prospective_portfolio_premium_at_risk"] == 120 + premium


def test_fourth_open_position_is_allowed_with_cash(cash_config, cash_account, base_candidate):
    account = {**cash_account, "open_position_count": 3, "open_premium_at_risk": 150}
    result = evaluate_risk(account, {**base_candidate, "premium_at_risk": 150}, cash_config)
    assert result.status == "ALLOWED"
    assert result.metrics["prospective_open_positions"] == 4


@pytest.mark.parametrize(
    ("account_change", "candidate_change", "reason"),
    [
        ({}, {"premium_at_risk": 49}, "single_position_premium_minimum_not_met"),
        ({}, {"premium_at_risk": 150.01}, "single_position_premium_limit_exceeded"),
        ({"buying_power": 149.99}, {}, "insufficient_buying_power"),
        ({"new_positions_today": 3}, {}, "max_new_positions_per_day_exceeded"),
        ({"daily_pnl": -45}, {}, "daily_loss_dollar_limit_reached"),
        (
            {"account_value_start_of_day": 100, "daily_pnl": -13},
            {},
            "daily_loss_percent_limit_reached",
        ),
        ({}, {"quantity": 2}, "max_contracts_per_position_exceeded"),
        ({}, {"is_averaging_down": True}, "averaging_down_prohibited"),
        ({}, {"protective_stop_planned": False}, "protective_stop_required"),
    ],
)
def test_other_risk_gates_still_block(
    cash_config, cash_account, base_candidate, account_change, candidate_change, reason
):
    result = evaluate_risk(
        {**cash_account, **account_change},
        {**base_candidate, "premium_at_risk": 150, **candidate_change},
        cash_config,
    )
    assert result.status == "BLOCKED"
    assert reason in result.reasons


@pytest.mark.parametrize("field", ["MAX_OPEN_POSITIONS", "MAX_PORTFOLIO_PREMIUM_AT_RISK"])
@pytest.mark.parametrize("value", [None, False, 0, -1, float("inf"), float("nan"), "DISABLED"])
def test_invalid_caps_are_not_treated_as_unlimited(
    cash_config, cash_account, base_candidate, field, value
):
    config = TradingConfig({**cash_config.values, field: value})
    result = evaluate_risk(cash_account, {**base_candidate, "premium_at_risk": 100}, config)
    assert result.status == "INSUFFICIENT_DATA"
    assert field in config.live_blockers()


@pytest.mark.parametrize(
    ("field", "value", "reason"),
    [
        ("MAX_OPEN_POSITIONS", 1, "max_open_positions_exceeded"),
        ("MAX_PORTFOLIO_PREMIUM_AT_RISK", 150, "portfolio_premium_limit_exceeded"),
    ],
)
def test_numeric_caps_remain_enforced(
    cash_config, cash_account, base_candidate, field, value, reason
):
    config = TradingConfig({**cash_config.values, field: value})
    result = evaluate_risk(cash_account, {**base_candidate, "premium_at_risk": 150}, config)
    assert result.status == "BLOCKED"
    assert reason in result.reasons


@pytest.mark.parametrize(
    ("changes", "pending", "blocked"),
    [
        ({}, 0, False),
        ({"open_position_count": 8, "open_premium_at_risk": 600}, 0, False),
        ({"buying_power": 50}, 0, False),
        ({"buying_power": 49.99}, 0, True),
        ({"new_positions_today": 3}, 0, True),
        ({"daily_pnl": -45}, 0, True),
        ({"buying_power": None}, 0, True),
        ({}, 1, True),
        ({}, None, True),
    ],
)
def test_scheduler_capacity_uses_the_same_risk_gates(
    cash_config, cash_account, changes, pending, blocked
):
    live = {"portfolio": {**cash_account, **changes}, "pending_order_count": pending}
    assert _live_entry_capacity_reached(live, cash_config) is blocked


def test_unlimited_is_not_allowed_for_per_position_limit(cash_config, cash_account, base_candidate):
    config = TradingConfig(
        {**cash_config.values, "MAX_SINGLE_POSITION_PREMIUM_AT_RISK": "UNLIMITED"}
    )
    assert evaluate_risk(cash_account, base_candidate, config).status == "INSUFFICIENT_DATA"
