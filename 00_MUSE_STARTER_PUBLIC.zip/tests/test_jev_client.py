from __future__ import annotations

import json
from dataclasses import replace

import pytest

from tools.config import parse_config_text
from tools.jev_client import JEV_ENDPOINT, JevClient
from tools.jev_config import JevConfig
from tools.jev_questions import market_questions

QUESTIONS = {
    "setup_quality": {
        "type": "noul",
        "instructions": "Is the stated setup coherent?",
    },
    "market_regime": {
        "type": "choice",
        "instructions": "Which regime best fits the supplied evidence?",
        "criteria": {"range": "Sideways", "uptrend": "Rising"},
    },
}


def response(*, noul: object = 0.7, probabilities: dict | None = None) -> bytes:
    return json.dumps(
        {
            "model": "jev-1.13.0",
            "answers": {
                "setup_quality": {"type": "noul", "noul": noul},
                "market_regime": {
                    "type": "choice",
                    "choice": "range",
                    "probabilities": probabilities or {"range": 0.75, "uptrend": 0.25},
                    "confidence": 0.5,
                },
            },
            "usage": {"input_tokens": 42, "output_tokens": 12},
        }
    ).encode()


def test_success_exact_contract_and_telemetry_without_secret() -> None:
    seen = {}

    def transport(url, headers, body, timeout, maximum):
        seen.update(url=url, headers=headers, body=body, timeout=timeout, maximum=maximum)
        return 200, response()

    client = JevClient(
        JevConfig(enabled=True), transport=transport, api_key_provider=lambda: "secret123"
    )
    result = client.evaluate({"symbol": "SPY"}, QUESTIONS)
    assert result.status == "OK"
    assert result.answers["setup_quality"]["noul"] == 0.7
    assert result.usage == {"input_tokens": 42, "output_tokens": 12}
    assert result.attempts == 1
    assert result.request_bytes == len(seen["body"])
    assert result.response_bytes == len(response())
    assert seen["url"] == JEV_ENDPOINT
    assert seen["headers"]["Authorization"] == "Bearer secret123"
    assert json.loads(seen["body"])["model"] == "jev-latest"
    assert "secret123" not in json.dumps(result.to_dict())


def test_disabled_missing_credentials_and_oversize_make_no_request() -> None:
    calls = []

    def transport(*args):
        calls.append(args)
        return 200, response()

    assert JevClient(JevConfig(), transport=transport).evaluate("x", QUESTIONS).status == "DISABLED"
    assert (
        JevClient(JevConfig(enabled=True), transport=transport, api_key_provider=lambda: None)
        .evaluate("x", QUESTIONS)
        .error_code
        == "credential_unavailable"
    )
    config = JevConfig(enabled=True, max_request_bytes=100)
    assert (
        JevClient(config, transport=transport, api_key_provider=lambda: "key")
        .evaluate("x", QUESTIONS)
        .error_code
        == "request_too_large"
    )
    assert calls == []


def test_retries_only_transient_status_and_uses_exponential_backoff() -> None:
    statuses = iter([429, 529, 200])
    sleeps = []
    client = JevClient(
        JevConfig(enabled=True),
        transport=lambda *args: (next(statuses), response()),
        api_key_provider=lambda: "key",
        sleep=sleeps.append,
    )
    result = client.evaluate("x", QUESTIONS)
    assert result.status == "OK" and result.attempts == 3
    assert sleeps == [0.5, 1.0]

    for code in (301, 401, 422):
        attempts = []

        def rejected(*args, status=code, calls=attempts):
            calls.append(1)
            return status, b'{"secret":"do not expose"}'

        result = JevClient(
            JevConfig(enabled=True), transport=rejected, api_key_provider=lambda: "key"
        ).evaluate("x", QUESTIONS)
        assert result.error_code == f"http_{code}"
        assert result.attempts == 1
        assert len(attempts) == 1
        assert "secret" not in json.dumps(result.to_dict())


@pytest.mark.parametrize(
    "bad_response",
    [
        response(noul=True),
        response(noul=float("nan")),
        response(probabilities={"range": 0.7, "uptrend": 0.7}),
        response(probabilities={"range": 0.7}),
        b'{"model":"jev","answers":{},"usage":{"input_tokens":1,"output_tokens":2}}',
    ],
)
def test_malformed_or_partial_answers_fail_closed(bad_response: bytes) -> None:
    result = JevClient(
        JevConfig(enabled=True),
        transport=lambda *args: (200, bad_response),
        api_key_provider=lambda: "key",
    ).evaluate("x", QUESTIONS)
    assert result.status == "ERROR"
    assert result.error_code == "invalid_response"
    assert result.answers == {}


def test_response_size_and_client_rate_are_bounded() -> None:
    config = JevConfig(enabled=True, max_response_bytes=1000, max_calls_per_minute=1)
    client = JevClient(
        config, transport=lambda *args: (200, response()), api_key_provider=lambda: "key"
    )
    assert client.evaluate("x", QUESTIONS).status == "OK"
    assert client.evaluate("x", QUESTIONS).error_code == "client_rate_limit"
    oversize = JevClient(
        replace(config, max_calls_per_minute=6),
        transport=lambda *args: (200, b"x" * 1001),
        api_key_provider=lambda: "key",
    )
    assert oversize.evaluate("x", QUESTIONS).error_code == "response_too_large"


def test_versioned_question_batch_is_accepted() -> None:
    assert len(market_questions()) == 15
    client = JevClient(
        JevConfig(enabled=True), transport=lambda *args: (422, b""), api_key_provider=lambda: "key"
    )
    assert client.evaluate({}, market_questions()).error_code == "http_422"


def test_missing_jev_settings_fail_closed() -> None:
    config = JevConfig.from_config(parse_config_text("LIVE_EXECUTION_ENABLED: false\n"))
    assert config.enabled is False
    assert config.shadow_mode is True
    assert config.escalation_enabled is False
    assert config.level2_enabled is False
    assert config.orderflow_features_enabled is False
    assert config.orderflow_jev_enabled is False
    assert config.multi_watch_enabled is False
    assert config.dynamic_luna_escalation_enabled is False
    assert config.max_calls_per_minute == 6
    assert config.max_calls_per_day == 1000


def test_explicit_settings_and_invalid_values() -> None:
    config = JevConfig.from_config({"ENABLE_JEV": True, "JEV_MAX_RETRIES": 1})
    assert config.enabled is True
    assert config.max_retries == 1
    with pytest.raises(ValueError, match="ENABLE_JEV"):
        JevConfig.from_config({"ENABLE_JEV": "true"})
    with pytest.raises(ValueError, match="JEV_MAX_CALLS_PER_DAY"):
        JevConfig.from_config({"JEV_MAX_CALLS_PER_DAY": True})
    with pytest.raises(ValueError, match="JEV_TIMEOUT_SECONDS"):
        JevConfig.from_config({"JEV_TIMEOUT_SECONDS": float("nan")})
