from datetime import UTC, datetime, timedelta

from tools.jev_relative import relative_setup_policy
from tools.jev_store import JevStore

NOW = datetime(2026, 9, 22, 14, tzinfo=UTC)
VERSIONS = ["jev-market-v2", "crypto-review-trial-v1", "jev-book-v2"]


def evaluation(score, *, available_at=NOW - timedelta(minutes=1), model="jev-1.13.0"):
    return {
        "status": "OK",
        "model": model,
        "question_versions": VERSIONS,
        "available_at": available_at.isoformat(),
        "scores": {"setup_quality": score},
    }


def observe(store, score, *, at, symbol="ETH-USD", **kwargs):
    return store.observe(
        features={"candidate": {"candidate_id": f"{symbol}-{at.isoformat()}", "symbol": symbol}},
        evaluation=evaluation(score, available_at=at + timedelta(seconds=1), **kwargs),
        now=at,
        python_pass=True,
        shadow=False,
    )


def test_relative_setup_requires_strictly_above_prior_same_configuration_mean(tmp_path):
    path = tmp_path / "jev.sqlite3"
    store = JevStore(path)
    observe(store, 0.4, at=NOW - timedelta(minutes=4))
    observe(store, 0.6, at=NOW - timedelta(minutes=3))

    equal = relative_setup_policy(path, evaluation(0.5), symbol="ETH-USD", now=NOW)
    above = relative_setup_policy(path, evaluation(0.500001), symbol="ETH-USD", now=NOW)

    assert equal["would_escalate"] is False
    assert equal["reason"] == "relative_setup_not_above_mean"
    assert equal["history_count"] == 2
    assert equal["history_mean"] == 0.5
    assert above["would_escalate"] is True
    assert above["reason"] == "relative_setup_above_mean"
    assert above["metric"] == "setup_quality"


def test_relative_setup_does_not_pass_a_repeated_score_equal_to_its_decimal_mean(tmp_path):
    path = tmp_path / "jev.sqlite3"
    store = JevStore(path)
    for minutes in (4, 3, 2):
        observe(store, 0.7, at=NOW - timedelta(minutes=minutes))

    result = relative_setup_policy(path, evaluation(0.7), symbol="ETH-USD", now=NOW)

    assert result["history_mean"] == 0.7
    assert result["would_escalate"] is False
    assert result["reason"] == "relative_setup_not_above_mean"


def test_relative_setup_uses_only_prior_same_coin_model_and_exact_question_versions(tmp_path):
    path = tmp_path / "jev.sqlite3"
    store = JevStore(path)
    observe(store, 0.2, at=NOW - timedelta(minutes=4))
    observe(store, 0.99, at=NOW - timedelta(minutes=3), symbol="BTC-USD")
    observe(store, 0.99, at=NOW - timedelta(minutes=2), model="jev-other")
    observe(store, 0.4, at=NOW - timedelta(seconds=1))
    changed_versions = ["jev-market-v2"]
    store.observe(
        features={"candidate": {"candidate_id": "old-version", "symbol": "ETH-USD"}},
        evaluation={
            **evaluation(0.99, available_at=NOW - timedelta(minutes=1)),
            "question_versions": changed_versions,
        },
        now=NOW - timedelta(minutes=2),
        python_pass=True,
        shadow=False,
    )
    future = observe(store, 0.99, at=NOW + timedelta(minutes=1))

    result = relative_setup_policy(path, evaluation(0.31), symbol="ETH-USD", now=NOW)
    current = evaluation(0.31)
    current["observation_id"] = future
    excluded = relative_setup_policy(
        path, current, symbol="ETH-USD", now=NOW + timedelta(minutes=2)
    )

    assert result["history_count"] == 2
    assert result["history_mean"] == 0.3
    assert result["would_escalate"] is True
    assert excluded["history_count"] == 2


def test_relative_setup_bootstraps_only_when_no_valid_history_and_fails_closed_for_invalid_current(
    tmp_path,
):
    path = tmp_path / "jev.sqlite3"
    bootstrap = relative_setup_policy(path, evaluation(0.5), symbol="ETH-USD", now=NOW)
    invalid = relative_setup_policy(
        path, {"status": "OK", "scores": {}}, symbol="ETH-USD", now=NOW
    )

    assert bootstrap["would_escalate"] is True
    assert bootstrap["reason"] == "relative_setup_bootstrap_no_history"
    assert bootstrap["history_count"] == 0
    assert invalid["would_escalate"] is False
    assert invalid["reason"] == "relative_setup_current_invalid"


def test_options_winner_logging_is_advisory_and_matches_contract_direction(tmp_path):
    from tools.jev_pipeline import record_routing

    store = JevStore(tmp_path / "state/research/jev.sqlite3")
    for kind, score in [("CALL", 0.8), ("PUT", 0.1)]:
        store.observe(
            features={"candidate": {"symbol": "SPY", "option_type": kind,
                                    "candidate_id": kind}},
            evaluation=evaluation(score), now=NOW-timedelta(minutes=2),
            python_pass=True, shadow=False,
        )
    result = {
        "jev_ranking": {"selected_candidate_id": "winner", "candidate_ids": ["winner", "other"]},
        "decision_packet": {"candidate": {"candidate_id": "winner", "symbol": "SPY",
                                           "option_type": "CALL"}},
        "jev_evaluations": [{**evaluation(0.7), "candidate_id": "winner"}],
        "decision": {"status": "COMPLETED", "codex_invoked": True},
    }
    record_routing(tmp_path, result, now=NOW)
    audit = result["jev_ranking"]["historical_comparison"]
    assert audit["history_count"] == 1
    assert audit["history_mean"] == 0.8
    assert audit["above_average"] is False
    assert audit["routing_effect"] is False
    assert result["decision"]["codex_invoked"] is True
    with store.connect() as db:
        count = db.execute(
            "select count(*) from events where kind='options_winner_comparison'"
        ).fetchone()[0]
        assert count == 1


def test_options_winner_without_scores_is_logged_as_unknown(tmp_path):
    from tools.jev_pipeline import record_routing

    result = {"jev_ranking": {"selected_candidate_id": "winner"}, "jev_evaluations": []}
    record_routing(tmp_path, result, now=NOW)
    assert result["jev_ranking"]["historical_comparison"]["above_average"] is None
