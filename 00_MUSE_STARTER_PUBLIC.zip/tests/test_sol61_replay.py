import json
from pathlib import Path

from research.options.sol61_replay import (
    collect,
    digest,
    model_prompt,
    select_fixed_outcomes,
    summarize,
    validated_app_decisions,
)


def trade(paper_id, entry, exit_at, pnl):
    return {
        "entry": {"paper_id": paper_id, "timestamp": entry},
        "exit": {"timestamp": exit_at, "realized_pnl": pnl},
    }


def test_model_input_excludes_outcomes_and_historical_verdicts():
    packet = {"as_of": "2026-09-09T14:00:00Z", "candidate": {"candidate_id": "exact"}}
    item = {"packet": packet, "historical_action": "BUY", "outcomes": {"realized_pnl": -999999}}
    prompt = model_prompt(item["packet"], "POLICY", "INSTRUCTIONS")
    assert "-999999" not in prompt
    assert "historical_action" not in prompt
    assert "Treat packet.as_of as the current time" in prompt
    assert json.loads(prompt[prompt.index('{"decision_packet"') :])["decision_packet"] == packet


def test_outcomes_join_exact_entry_not_later_review_of_same_contract(tmp_path: Path):
    (tmp_path / "state/logs").mkdir(parents=True)
    packet = {"as_of": "2026-09-09T14:00:00Z", "candidate": {"candidate_id": "same-contract"}}
    first = {
        "routing": {
            "decision_packet": packet,
            "decision": {
                "codex_invoked": True,
                "status": "COMPLETED",
                "model": "luna",
                "output": '{"action":"PASS"}',
            },
        },
        "baseline_decision": {"position": {"paper_id": "entry-1"}},
    }
    second = {
        "routing": {
            "decision_packet": packet | {"as_of": "2026-09-09T14:05:00Z"},
            "decision": first["routing"]["decision"],
        }
    }
    (tmp_path / "state/logs/2026-09-09.jsonl").write_text(
        "\n".join(json.dumps({"result": x}) for x in (first, first, second))
    )
    for ledger in ("paper", "paper_baseline"):
        directory = tmp_path / "state" / ledger
        directory.mkdir()
        rows = (
            []
            if ledger == "paper"
            else [
                {
                    "event": "PAPER_ENTRY",
                    "paper_id": "entry-1",
                    "contract_identifier": "same-contract",
                },
                {"event": "PAPER_EXIT", "paper_id": "entry-1", "realized_pnl": 12.9},
            ]
        )
        (directory / "EVENTS.jsonl").write_text("\n".join(map(json.dumps, rows)))
    before = {p: p.read_bytes() for p in tmp_path.rglob("*.jsonl")}
    items, manifest = collect(tmp_path, "2026-09-09", "2026-10-08")
    assert len(items) == 2  # Exact duplicate deduplicated, later review retained.
    assert "paper_baseline" in items[0]["outcomes"]
    assert items[1]["outcomes"] == {}
    assert manifest["control_outcome_count"] == 1
    assert all(p.read_bytes() == content for p, content in before.items())


def test_green_lock_uses_net_realized_closes_and_resets_eastern_day():
    trades = [
        trade("loss", "2026-09-09T13:30:00Z", "2026-09-09T14:00:00Z", -2.1),
        trade("zero", "2026-09-09T14:00:00Z", "2026-09-09T14:10:00Z", 2.1),
        trade("green", "2026-09-09T14:10:00Z", "2026-09-09T14:20:00Z", 0.01),
        trade("already-open", "2026-09-09T14:15:00Z", "2026-09-09T14:25:00Z", -10),
        trade("skip", "2026-09-09T14:20:00Z", "2026-09-09T14:30:00Z", 100),
        trade("next-day", "2026-09-10T13:30:00Z", "2026-09-10T14:00:00Z", 5),
    ]
    result = select_fixed_outcomes(trades, True)
    assert result["paper_ids"] == ["loss", "zero", "green", "already-open", "next-day"]
    assert result["net_pnl_dollars"] == -4.99
    assert result["green_lock_skipped"] == 1


def test_missing_or_failed_sol_decisions_do_not_report_zero_performance():
    assert summarize([], [])["comparisons"] == {}
    assert summarize([], [])["standard_api_equivalent_dollars"] is None


def test_matched_comparison_uses_shared_outcome_and_flags_unknown_buys():
    t = trade("control", "2026-09-09T13:30:00Z", "2026-09-09T14:00:00Z", 20)
    items = [
        {"id": "one", "historical_action": "PASS", "outcomes": {"paper_baseline": t}},
        {"id": "two", "historical_action": "PASS", "outcomes": {}},
    ]
    results = [
        {
            "packet_hash": item["id"],
            "status": "COMPLETED",
            "decision": {"action": "BUY"},
            "usage": None,
        }
        for item in items
    ]
    report = summarize(items, results)
    assert report["comparisons"]["control_only:sol61"]["net_pnl_dollars"] == 20
    assert report["comparisons"]["control_only:historical_luna"]["trades"] == 0
    assert report["sol_buy_without_recorded_outcome"] == 1
    assert report["measured_codex_dollar_cost"] is None
    assert digest({"b": 2, "a": 1}) == digest({"a": 1, "b": 2})


def test_pass_none_style_is_valid_but_buy_none_is_rejected(tmp_path: Path):
    (tmp_path / "app_decisions").mkdir()
    schema = {
        "type": "object",
        "required": ["action", "candidate_id", "trade_style"],
        "properties": {
            "action": {"enum": ["PASS", "BUY"]},
            "candidate_id": {"type": "string"},
            "trade_style": {"enum": ["DAY", "NONE"]},
        },
    }
    (tmp_path / "policy_False.json").write_text(json.dumps({"schema": schema}))
    items = []
    for index, action in enumerate(("PASS", "BUY")):
        key = str(index)
        items.append(
            {
                "id": key,
                "packet": {"candidate": {"candidate_id": "contract", "eligible_styles": ["DAY"]}},
            }
        )
        record = {
            "packet_hash": key,
            "model": "gpt-6.1-sol",
            "status": "COMPLETED",
            "decision": {"candidate_id": "contract", "action": action, "trade_style": "NONE"},
        }
        (tmp_path / "app_decisions" / f"{key}.json").write_text(json.dumps(record))
    records = validated_app_decisions(tmp_path, items)
    assert records[0]["status"] == "COMPLETED"
    assert records[1]["status"] == "ERROR"
    assert records[1]["validation_error"] == "ineligible style"
