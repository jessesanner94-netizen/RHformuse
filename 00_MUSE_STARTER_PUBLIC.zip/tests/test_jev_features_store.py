from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta

from tools.jev_features import completed_minute, market_features
from tools.jev_store import JevStore

NOW = datetime(2026, 9, 18, 15, tzinfo=UTC)


def test_features_exclude_account_and_calculate_semantics():
    result = market_features(
        {
            "account": {"account_number": "PRIVATE"},
            "candidate": {"candidate_id": "spy-call", "underlying_price": 501},
            "technical": {
                "timeframes": {
                    "5M": {
                        "atr_14": 2,
                        "relative_volume_20": 1.7,
                        "raw_bars": ["not for inference"],
                    }
                },
                "intraday_structure": {"session_vwap": 500},
            },
        }
    )
    assert result["vwap_distance_atr"] == 0.5
    assert result["vwap_position"] == "moderately_above"
    assert "PRIVATE" not in str(result)
    assert "raw_bars" not in str(result)


def test_completed_bar_requires_real_one_minute_closed_data():
    bar = {
        "starts_at": (NOW - timedelta(minutes=1)).isoformat(),
        "ends_at": NOW.isoformat(),
        "interpolated": False,
    }
    assert completed_minute(bar, now=NOW) == NOW.isoformat()
    assert completed_minute(bar, now=NOW - timedelta(seconds=1)) is None
    assert completed_minute({**bar, "interpolated": True}, now=NOW) is None
    assert completed_minute(bar, now=NOW + timedelta(minutes=3)) is None


def test_request_budget_and_claims_are_concurrent(tmp_path):
    store = JevStore(tmp_path / "jev.sqlite3")
    with ThreadPoolExecutor(max_workers=4) as pool:
        claims = list(pool.map(lambda _: store.claim("same", NOW), range(4)))
    assert sum(claims) == 1
    with ThreadPoolExecutor(max_workers=4) as pool:
        allowed = list(
            pool.map(
                lambda i: store.reserve_requests(str(i), NOW, attempts=3, per_minute=6, per_day=6),
                range(4),
            )
        )
    assert sum(allowed) == 2
    assert not store.reserve_requests(
        "later", NOW + timedelta(minutes=2), attempts=1, per_minute=6, per_day=6
    )


def test_point_in_time_history_and_separate_outcomes(tmp_path):
    store = JevStore(tmp_path / "jev.sqlite3")
    features = {"candidate": {"candidate_id": "spy-call", "symbol": "SPY"}}
    first = store.observe(
        features=features,
        evaluation={"scores": {"setup_quality": 0.7}},
        now=NOW,
        python_pass=True,
        shadow=True,
    )
    store.observe(
        features=features,
        evaluation={"scores": {"setup_quality": 0.9}},
        now=NOW + timedelta(minutes=1),
        python_pass=True,
        shadow=True,
    )
    store.event(first, "routing", {"luna_escalated": False}, NOW)
    history = store.history("spy-call", NOW)
    assert len(history) == 1
    assert history[0]["scores"]["setup_quality"] == 0.7
