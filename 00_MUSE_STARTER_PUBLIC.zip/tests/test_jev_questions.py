from __future__ import annotations

from tools.jev_questions import (
    BOOK_QUESTION_IDS,
    BOOK_QUESTION_VERSION,
    BOOK_TRADE_PRINT_QUESTION_IDS,
    MARKET_QUESTION_IDS,
    QUESTION_VERSION,
    book_questions,
    market_questions,
)


def test_market_question_batch_is_versioned_atomic_and_complete() -> None:
    assert QUESTION_VERSION == "jev-market-v2"
    assert set(MARKET_QUESTION_IDS) == {
        "bullish_continuation",
        "bearish_continuation",
        "setup_quality",
        "entry_timing_quality",
        "momentum_quality",
        "volume_confirmation",
        "multi_timeframe_alignment",
        "breakout_quality",
        "false_breakout_risk",
        "exhaustion_risk",
        "reversal_risk",
        "trend_quality",
        "unusual_opportunity",
        "market_regime",
        "escalate_to_luna",
    }
    questions = market_questions()
    assert set(questions) == set(MARKET_QUESTION_IDS)
    assert all(
        isinstance(q["instructions"], str) and q["instructions"].endswith("?")
        for q in questions.values()
    )
    assert questions["market_regime"]["type"] == "choice"
    assert all(q["type"] == "noul" for key, q in questions.items() if key != "market_regime")
    questions["trend_quality"]["instructions"] = "changed"
    assert market_questions()["trend_quality"]["instructions"] != "changed"


def test_order_book_batch_is_separate() -> None:
    assert BOOK_QUESTION_VERSION == "jev-book-v2"
    assert set(BOOK_QUESTION_IDS) == {
        "bullish_orderflow_pressure",
        "bearish_orderflow_pressure",
        "bid_pressure",
        "ask_pressure",
        "depth_imbalance",
        "liquidity_withdrawal_risk",
        "bid_support_quality",
        "ask_resistance_quality",
        "upside_breakout_likelihood",
        "downside_breakdown_likelihood",
        "book_false_breakout_risk",
        "near_term_reversal_risk",
        "orderflow_confirmation",
    }
    assert set(book_questions()) == set(BOOK_QUESTION_IDS)
    assert set(BOOK_TRADE_PRINT_QUESTION_IDS) == {
        "absorption_likelihood",
        "exhaustion_likelihood",
    }
    assert set(book_questions(include_trade_prints=True)) == (
        set(BOOK_QUESTION_IDS) | set(BOOK_TRADE_PRINT_QUESTION_IDS)
    )
    assert not set(BOOK_QUESTION_IDS).intersection(MARKET_QUESTION_IDS)
    assert not set(BOOK_TRADE_PRINT_QUESTION_IDS).intersection(MARKET_QUESTION_IDS)
    assert all(
        question["type"] == "noul"
        for question in book_questions(include_trade_prints=True).values()
    )
