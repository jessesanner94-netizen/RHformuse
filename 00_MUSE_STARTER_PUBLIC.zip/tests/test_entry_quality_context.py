from datetime import UTC, datetime

import pytest

from research.entry_quality.context import entry_measurements


def test_quote_to_entry_move_is_measurement_not_a_promised_fill():
    result = entry_measurements(
        {"ask": 1.52},
        {"ask_price": "1.58", "bid_price": "1.57"},
        {},
        datetime(2026, 10, 22, 14, tzinfo=UTC),
    )
    assert result["one_contract_ask_change_dollars"] == 6
    assert result["ask_change_percent"] == pytest.approx(3.9474)
    assert result["no_chase_reference_would_wait"] is True
    assert result["changes_entry_decision"] is False


def test_unavailable_quote_cannot_become_a_no_chase_signal():
    result = entry_measurements(
        {"ask": 1.52}, {"ask_price": "nan"}, {}, datetime(2026, 10, 22, 14, tzinfo=UTC)
    )
    assert result["one_contract_ask_change_dollars"] is None
    assert result["no_chase_reference_would_wait"] is None
