import asyncio
from datetime import UTC, datetime, timedelta
from pathlib import Path

from tools.option_discovery import run_option_discovery


class _UWResult:
    def __init__(self, rows):
        self.payload = {"data": rows}


class _FakeUW:
    def __init__(self, row):
        self.row = row

    def option_screener(self, *, option_type, limit):
        assert limit == 200
        return _UWResult([self.row] if option_type == "Calls" else [])


def test_discovery_wakes_once_for_fresh_qualified_changed_candidate(
    tmp_path: Path, resolved_config
) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    expiry = (now.date() + timedelta(days=14)).isoformat()
    uw = _FakeUW(
        {
            "ticker_symbol": "SPY",
            "expiry": expiry,
            "strike": "500",
            "option_type": "call",
            "close": "1.00",
            "volume": 10000,
            "sweep_volume": 2000,
            "option_symbol": "SPY-FIXTURE",
        }
    )

    async def research(requests):
        assert requests[0]["chain_symbol"] == "SPY"
        return {
            "instruments": [
                {
                    "id": "contract-1",
                    "chain_symbol": "SPY",
                    "expiration_date": expiry,
                    "strike_price": "500.0000",
                    "type": "call",
                }
            ],
            "option_quotes": [
                {
                    "quote": {
                        "instrument_id": "contract-1",
                        "bid_price": "1.00",
                        "ask_price": "1.10",
                        "volume": 1000,
                        "open_interest": 5000,
                        "implied_volatility": "0.25",
                        "delta": "0.50",
                        "gamma": "0.002",
                        "theta": "-0.02",
                        "vega": "0.10",
                        "rho": "0.02",
                        "updated_at": now.isoformat(),
                    }
                }
            ],
            "equity_quotes": [{"quote": {"symbol": "SPY", "last_trade_price": "500"}}],
            "equity_fundamentals": [{"symbol": "SPY", "average_volume_30_days": "10000000"}],
        }

    state = tmp_path / "candidates.json"
    first = asyncio.run(
        run_option_discovery(
            resolved_config,
            state_path=state,
            uw_client=uw,
            research_fetcher=research,
            now=now,
        )
    )
    second = asyncio.run(
        run_option_discovery(
            resolved_config,
            state_path=state,
            uw_client=uw,
            research_fetcher=research,
            now=now,
        )
    )

    assert first["status"] == "QUALIFIED_CHANGED"
    assert first["wake_luna"] is True
    assert len(first["qualified_candidates"]) == 1
    assert first["uw_attribution"][0]["stage"] == "PRE_UW"
    attribution_lines = (tmp_path / "uw_attribution.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(attribution_lines) == 8
    assert second["status"] == "UNCHANGED"
    assert second["wake_luna"] is False
