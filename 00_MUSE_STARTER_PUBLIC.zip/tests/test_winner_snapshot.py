import sys
from datetime import UTC, datetime, timedelta
from types import ModuleType

from tools import vibe_snapshot_worker as worker


def test_intraday_snapshot_uses_closed_bars_and_skips_news(monkeypatch):
    current = datetime(2026, 9, 24, 15, 2, tzinfo=UTC)

    class Clock(datetime):
        @classmethod
        def now(cls, tz=None):
            return current.astimezone(tz)

    intervals = []

    def fetch(**kwargs):
        interval = kwargs['interval']
        intervals.append(interval)
        minutes = 5 if interval == '5m' else 15
        start = current.replace(hour=13, minute=30)
        bars = []
        while start <= current:
            price = 100 if start + timedelta(minutes=minutes) <= current else 500
            bars.append({'trade_date': start.isoformat(), 'open': price, 'high': price,
                         'low': price, 'close': price, 'volume': 1000})
            start += timedelta(minutes=minutes)
        return {'SPY.US': {'data': bars}}

    source = ModuleType('src.market_data')
    source.fetch_market_data = fetch
    monkeypatch.setitem(sys.modules, 'src.market_data', source)
    monkeypatch.setattr(worker, 'datetime', Clock)

    def no_news(*args):
        raise AssertionError('Continuation monitoring must not fetch news')

    monkeypatch.setattr(worker, '_news_and_earnings', no_news)
    result = worker.build_snapshot('SPY', intraday_only=True)
    assert sorted(intervals) == ['15m', '5m']
    assert result['timeframes']['5M']['latest_close'] == 100
    assert result['timeframes']['15M']['latest_close'] == 100
    assert result['intraday_structure']['latest_close'] == 100
    assert result['intraday_structure']['entry_timing']['completed_bar_at'].startswith(
        '2026-09-24T15:00:00'
    )
    assert result['earnings']['status'] == 'NOT_REQUESTED'
