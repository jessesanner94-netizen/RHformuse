from __future__ import annotations

import copy
from datetime import UTC, datetime, timedelta

import pytest

from tools.decision_context import _countertrend_timing_gate, _pre_model_gate
from tools.vibe_snapshot_worker import _intraday_structure

NOW = datetime(2026, 8, 27, 18, 51, tzinfo=UTC)


def nvda_technical():
    # Reduced exact fields from the 2026-08-27 14:50:50 saved NVDA decision packet.
    return {
        "status": "OK",
        "timeframes": {
            "1D": {"status": "OK", "trend": "BULLISH", "change_1_bar_percent": 7.5956},
            "4H": {"status": "OK", "trend": "BULLISH"},
            "15M": {"status": "OK", "trend": "NEUTRAL", "trend_score": -1},
            "5M": {"status": "OK", "trend": "BEARISH", "trend_score": -3},
        },
        "style_scores": {"DAY": -9, "SWING": 11},
        "intraday_structure": {
            "status": "OK",
            "bias_score": -1,
            "bias": "NEUTRAL",
            "swept_and_rejected_opening_range_high": True,
            "opening_range_high": 225.83,
            "opening_range_low": 220.9,
            "latest_close": 225.6,
        },
    }


def test_saved_nvda_would_be_rejected_despite_strong_flow_and_positive_put_score():
    result = _pre_model_gate(
        {"option_type": "PUT"},
        nvda_technical(),
        {"status": "OK", "label": "STRONG_BEARISH", "supports_contract_direction": True},
        {"status": "ALLOWED"},
        {"status": "AVAILABLE"},
        preferred_style="DAY",
        now=NOW,
    )
    assert result["directional_alignment_score"] == 9
    assert result["status"] == "REJECTED"
    assert result["reasons"] == [
        "countertrend_day_requires_5m_15m_confirmation",
        "countertrend_day_requires_fresh_level_confirmation",
    ]


@pytest.mark.parametrize("kind", ["PUT", "CALL"])
def test_fresh_confirmed_countertrend_is_not_blanket_banned(kind):
    technical = nvda_technical()
    desired = "BEARISH" if kind == "PUT" else "BULLISH"
    technical["timeframes"]["1D"] = {
        "status": "OK",
        "trend": "BULLISH" if kind == "PUT" else "BEARISH",
        "change_1_bar_percent": 7.5 if kind == "PUT" else -7.5,
    }
    for tf in ("5M", "15M"):
        technical["timeframes"][tf]["trend"] = desired
    key = "bearish_confirmation_levels" if kind == "PUT" else "bullish_confirmation_levels"
    technical["intraday_structure"]["entry_timing"] = {
        "status": "OK",
        "completed_bar_at": (NOW - timedelta(minutes=1)).isoformat(),
        key: ["SESSION_VWAP"],
    }
    result = _countertrend_timing_gate({"option_type": kind}, technical, style="DAY", now=NOW)
    assert result["required"] is True
    assert result["reasons"] == []
    for timestamp in (NOW - timedelta(minutes=11), NOW + timedelta(minutes=1)):
        technical["intraday_structure"]["entry_timing"]["completed_bar_at"] = timestamp.isoformat()
        result = _countertrend_timing_gate({"option_type": kind}, technical, style="DAY", now=NOW)
        assert result["reasons"] == ["countertrend_day_requires_fresh_level_confirmation"]


def test_trend_following_and_swing_unchanged_but_daily_change_cannot_be_ignored():
    technical = nvda_technical()
    assert _countertrend_timing_gate({"option_type": "CALL"}, technical, style="DAY", now=NOW) == {
        "required": False,
        "reasons": [],
    }
    assert _countertrend_timing_gate({"option_type": "PUT"}, technical, style="SWING", now=NOW) == {
        "required": False,
        "reasons": [],
    }
    technical["timeframes"]["1D"]["trend"] = "BEARISH"
    assert (
        _countertrend_timing_gate({"option_type": "PUT"}, technical, style="DAY", now=NOW)[
            "required"
        ]
        is True
    )  # Daily label bearish, but today's actual move is still +7.6%.
    technical["timeframes"].pop("1D")
    assert _countertrend_timing_gate({"option_type": "PUT"}, technical, style="DAY", now=NOW)[
        "reasons"
    ] == ["day_entry_daily_context_missing"]


def bars():
    rows = []
    start = datetime(2026, 8, 27, 13, 30, tzinfo=UTC)
    for index, (op, hi, lo, cl) in enumerate(
        [
            (100, 101, 99, 100),
            (100, 102, 99, 101),
            (101, 101.5, 100, 101),
            (101, 104, 101, 103),
            (103, 103, 100.8, 101),
            (101, 101.2, 100.7, 100.9),
            (100.9, 101, 100.5, 100.7),
        ]
    ):
        rows.append(
            {
                "trade_date": (start + timedelta(minutes=5 * index)).isoformat(),
                "open": op,
                "high": hi,
                "low": lo,
                "close": cl,
                "volume": 1000,
            }
        )
    return rows


def test_old_opening_range_rejection_is_not_a_fresh_signal_and_vwap_is_volume_weighted():
    raw = bars()
    now = datetime(2026, 8, 27, 14, 6, tzinfo=UTC)
    result = _intraday_structure(raw, now=now)
    assert result["swept_and_rejected_opening_range_high"] is True
    timing = result["entry_timing"]
    assert timing["status"] == "OK"
    assert timing["bearish_confirmation_levels"] == []
    expected = sum((r["high"] + r["low"] + r["close"]) / 3 for r in raw) / len(raw)
    assert timing["session_vwap"] == pytest.approx(expected, abs=0.0001)
    assert timing["session_high"] == 104
    assert timing["session_low"] == 99
    assert (
        _intraday_structure(raw, now=now + timedelta(minutes=11))["entry_timing"]["status"]
        == "STALE"
    )


def test_confirming_bar_must_be_completed_and_touch_the_level():
    raw = bars()
    raw[-1].update(open=102.2, high=102.3, low=101.5, close=101.8)
    before_close = datetime(2026, 8, 27, 14, 4, tzinfo=UTC)
    after_close = datetime(2026, 8, 27, 14, 6, tzinfo=UTC)
    before = _intraday_structure(raw, now=before_close)["entry_timing"]
    after = _intraday_structure(raw, now=after_close)["entry_timing"]
    assert "OPENING_RANGE_HIGH" not in before["bearish_confirmation_levels"]
    assert "OPENING_RANGE_HIGH" in after["bearish_confirmation_levels"]
    no_volume = copy.deepcopy(raw)
    for row in no_volume:
        row["volume"] = 0
    assert _intraday_structure(no_volume, now=after_close)["entry_timing"]["session_vwap"] is None
