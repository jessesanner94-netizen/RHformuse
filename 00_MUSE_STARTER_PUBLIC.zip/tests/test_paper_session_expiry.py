"""Calendar admission plus the actual single-paper discovery/router/fill funnel."""

import asyncio
import copy
import json
from datetime import UTC, date, datetime, timedelta
from functools import partial

import pytest

from research.options_lab import forward, session_expiry
from research.options_lab.session_expiry import paper_entry_config
from tests.test_options_lab_forward import NOW, observation, row
from tests.test_options_lab_forward import bot as bot
from tools.cheap_scan import evaluate_candidate
from tools.config import TradingConfig
from tools.news_option_discovery import run_symbol_option_discovery
from tools.watchlist_discovery import run_watchlist_option_discovery


@pytest.mark.parametrize(
    "day,expected,dte",
    [
        ("2026-10-22", "2026-10-23", 1),
        ("2026-10-23", "2026-10-26", 3),  # weekend
        ("2026-09-04", "2026-09-08", 4),  # Labor Day
        ("2026-04-02", "2026-04-06", 4),  # Good Friday
        ("2026-11-25", "2026-11-27", 2),  # Thanksgiving
        ("2026-11-27", "2026-11-30", 3),  # early close is a session
        ("2026-12-24", "2026-12-28", 4),  # Christmas
        ("2026-12-31", "2027-01-04", 4),  # New Year's Day
        ("2026-10-30", "2026-11-02", 3),  # DST changes over weekend
    ],
)
def test_next_session_calendar_and_unchanged_calendar_dte(bot, day, expected, dte):
    now = datetime.fromisoformat(day + "T10:00:00-04:00")
    config = paper_entry_config(bot.config, now)
    candidate = {"candidate_id": "test", "expiration": expected, "dte": dte}
    assert config.next_session.isoformat() == expected
    assert config.review(candidate, now)["status"] == "ALLOW"
    assert config.review(candidate, now)["calendar_dte"] == dte
    assert candidate["dte"] == dte
    assert config.get("MIN_DTE") == config.get("MIN_DAY_TRADE_DTE") == min(2, dte)
    assert config.values == bot.config.values
    for key in config.values.keys() - {"MIN_DTE", "MIN_DAY_TRADE_DTE"}:
        assert config.get(key) == bot.config.get(key)


@pytest.mark.parametrize(
    "expiry,dte,status",
    [
        ("2026-10-21", -1, "BLOCK"),
        ("2026-10-22", 0, "BLOCK"),
        ("2026-10-23", 1, "ALLOW"),
        ("2026-10-26", 4, "ALLOW"),
        ("2026-12-06", 45, "ALLOW"),
        ("2026-12-07", 46, "BLOCK"),
        ("2026-10-23", 0, "BLOCK"),
        ("2026-10-22", 1, "BLOCK"),
        ("bad-date", 1, "BLOCK"),
        (None, 1, "BLOCK"),
    ],
)
def test_exact_expiration_bounds_and_no_fabricated_dte(bot, expiry, dte, status):
    config = paper_entry_config(bot.config, NOW)
    assert config.review({"expiration": expiry, "dte": dte}, NOW)["status"] == status


def test_no_one_calendar_day_exception_when_tomorrow_is_closed(bot):
    now = NOW + timedelta(days=1)  # Friday
    config = paper_entry_config(bot.config, now)
    assert config.get("MIN_DTE") == config.get("MIN_DAY_TRADE_DTE") == 2
    assert config.review({"expiration": "2026-10-24", "dte": 1}, now)["status"] == "BLOCK"
    assert config.review({"expiration": "2026-10-26", "dte": 3}, now)["status"] == "ALLOW"


def test_eastern_date_midnight_and_context_rollover(bot):
    now = datetime(2026, 10, 23, 0, 30, tzinfo=UTC)  # still Thursday Eastern
    config = paper_entry_config(bot.config, now)
    candidate = {"expiration": "2026-10-23", "dte": 1}
    assert config.decision_date == date(2026, 10, 22)
    assert config.review(candidate, now)["status"] == "ALLOW"
    assert config.review(candidate, now + timedelta(hours=4))["status"] == "BLOCK"


def test_paper_only_and_calendar_unavailability(bot, monkeypatch):
    live = TradingConfig({**bot.config.values, "LIVE_EXECUTION_ENABLED": True})
    with pytest.raises(ValueError, match="isolated paper"):
        paper_entry_config(live, NOW)
    monkeypatch.setattr(session_expiry, "session_hours", lambda day: None)
    with pytest.raises(ValueError, match="next NYSE session unavailable"):
        paper_entry_config(bot.config, NOW)
    with pytest.raises(ValueError, match="timezone-aware"):
        paper_entry_config(bot.config, NOW.replace(tzinfo=None))


def test_new_expiry_passes_original_scanner_without_mutating_live_rules(bot):
    candidate = {
        **observation()["candidates"][0],
        "quote_is_fresh": True,
        "expiration": "2026-10-23",
        "dte": 1,
    }
    assert evaluate_candidate(candidate, bot.config).status == "REJECTED"
    assert evaluate_candidate(candidate, paper_entry_config(bot.config, NOW)).status == "QUALIFIED"
    for change in (
        {"theta": -2},
        {"gamma": 1},
        {"delta": 0.1},
        {"option_volume": 0},
        {"option_open_interest": 0},
        {"bid": 0.5},
        {"quote_is_fresh": False},
        {"setup_qualified": False},
    ):
        assert (
            evaluate_candidate({**candidate, **change}, paper_entry_config(bot.config, NOW)).status
            == "REJECTED"
        )


def run_forward(
    bot, monkeypatch, *, now=NOW, expiry="2026-10-23", failure=None, option_type="CALL"
):
    frame = observation(now)
    frame["economic_calendar"]["period"] = now.strftime("%Y-%m")
    candidate = frame["candidates"][0]
    candidate.update(expiration=expiry, dte=(date.fromisoformat(expiry) - now.date()).days)
    candidate["option_type"] = option_type
    if option_type == "PUT":
        frame["technical"]["SPY"]["style_scores"]["DAY"] = -7
        frame["quotes"]["option_quotes"][0]["delta"] = -0.5
    bot.clock = lambda: now
    captured = {"jev_calls": 0}
    original_route, original_apply = (
        forward._route_compact_decision_impl,
        forward.apply_paper_decision,
    )

    async def route(*args, **kwargs):
        return await original_route(*args, **kwargs, now=now)

    async def apply(*args, **kwargs):
        return await original_apply(*args, **kwargs, now=now)

    async def research(requests):
        captured["requests"] = requests
        minimum = date.fromisoformat(requests[0]["min_expiration"])
        instruments = (
            []
            if date.fromisoformat(expiry) < minimum
            else [
                {
                    "id": candidate["candidate_id"],
                    "chain_symbol": "SPY",
                    "expiration_date": expiry,
                    "strike_price": str(candidate["strike"]),
                    "type": option_type.lower(),
                    "symbol": "test-option",
                }
            ]
        )
        return {
            "instruments": instruments,
            "option_quotes": frame["quotes"]["option_quotes"],
            "equity_quotes": [{"symbol": "SPY", "last_trade_price": "500"}],
            "equity_fundamentals": [{"symbol": "SPY", "average_volume_30_days": 2e7}],
        }

    async def discovery(config, **kwargs):
        kwargs["now"] = now  # injected clock for the real discovery functions
        return await run_watchlist_option_discovery(
            config,
            **kwargs,
            option_resolver=partial(run_symbol_option_discovery, research_fetcher=research),
        )

    async def books(*args, **kwargs):
        return {"status": "DISABLED", "summaries": {}}

    def jev(packet, config, **kwargs):
        captured["jev_calls"] += 1
        captured["packet_dte"] = packet["candidate"]["dte"]
        if failure == "jev":
            return {"status": "UNAVAILABLE"}
        return {
            "status": "OK",
            "as_of": now.isoformat(),
            "scores": {"setup_quality": 0, "entry_timing_quality": 0, "escalate_to_luna": 0},
        }

    async def quotes(requests):
        refreshed = copy.deepcopy(frame["quotes"])
        quote = refreshed["option_quotes"][0]
        if failure == "greeks":
            quote["theta"] = -2
        elif failure == "liquidity":
            quote["volume"] = 0
        elif failure == "stale_quote":
            quote["updated_at"] = (now - timedelta(minutes=4)).isoformat()
        elif failure == "risk":
            quote.update(ask_price="1.80", bid_price="1.78")
        elif failure == "config_change":
            path = bot.roots["paper"] / "CONFIG.md"
            path.write_text(path.read_text().replace("MAX_DTE: 45", "MAX_DTE: 44"))
        return refreshed

    if failure == "direction":
        frame["technical"]["SPY"]["style_scores"]["DAY"] = -7
        for tf in frame["technical"]["SPY"]["timeframes"].values():
            tf.update(trend="BEARISH", trend_score=-3)
    if failure == "event":
        frame["economic_calendar"]["events"] = [
            {"name": "Synthetic FOMC", "kind": "FOMC", "at": now.isoformat()}
        ]
    monkeypatch.setattr(forward, "load_calendar", lambda *a: frame["economic_calendar"])
    monkeypatch.setattr(forward, "run_watchlist_option_discovery", discovery)
    monkeypatch.setattr(forward, "_route_compact_decision_impl", route)
    monkeypatch.setattr(forward, "apply_paper_decision", apply)
    monkeypatch.setattr(forward, "evaluate_candidate", jev)
    monkeypatch.setattr(
        forward, "fetch_vibe_snapshot", lambda symbol, **kw: frame["technical"][symbol]
    )
    monkeypatch.setattr(forward, "collect_market_intelligence", lambda *a, **kw: {})
    monkeypatch.setattr("tools.orderbook.collect_orderbooks", books)
    for offset in range(-6, 0):
        start = now + timedelta(minutes=offset)
        end = start + timedelta(minutes=1)
        bot.tape.ingest(
            [
                row(
                    "bar",
                    end,
                    {
                        "start_at": start.isoformat(),
                        "end_at": end.isoformat(),
                        "open": 500,
                        "high": 500.1,
                        "low": 499.9,
                        "close": 500,
                        "volume": 1000,
                    },
                    identity="bar:" + end.isoformat(),
                )
            ]
        )
    bot.health["news"] = {"status": "OK", "as_of": now.isoformat()}
    bot.quotes = quotes
    result = asyncio.run(bot.opportunities())
    path = bot.directory / "OPPORTUNITIES.jsonl"
    event = json.loads(path.read_text().splitlines()[-1]) if path.exists() else None
    return result, event, captured


@pytest.mark.parametrize("option_type", ["CALL", "PUT"])
@pytest.mark.parametrize(
    "now,expiry,dte",
    [
        (NOW, "2026-10-23", 1),
        (NOW + timedelta(days=1), "2026-10-26", 3),
        (datetime(2026, 9, 4, 14, tzinfo=UTC), "2026-09-08", 4),
    ],
)
def test_real_paper_funnel_admits_next_session_without_extra_account(
    bot, monkeypatch, now, expiry, dte, option_type
):
    result, event, captured = run_forward(
        bot, monkeypatch, now=now, expiry=expiry, option_type=option_type
    )
    assert result["status"] == "OK"
    assert event["results"]["paper"]["entry"]["opened"] is True
    assert captured["jev_calls"] == 1 and captured["packet_dte"] == dte
    assert (
        captured["requests"][0]["min_expiration"]
        == (now.date() + timedelta(days=min(2, dte))).isoformat()
    )
    assert event["discovery"]["qualified_candidates"][0]["dte"] == dte
    assert event["candidate_expiry_reviews"][0]["next_session_expiry"] is True
    assert len(event["results"]["paper"]["final_expiry_reviews"]) == 2
    assert list(bot.configs) == ["paper"]
    assert len(bot.state("paper", now)["open_positions"]) == 1
    assert bot.config.get("MIN_DTE") == 2  # persistent and protective config unchanged


@pytest.mark.parametrize(
    "failure,reason",
    [
        ("greeks", "day_theta_decay_too_high"),
        ("liquidity", "option_volume_too_low"),
        ("stale_quote", "freshness_unverified"),
        ("risk", "planned"),
        ("direction", "technical"),
        ("jev", "jev"),
        ("event", "original_session_or_calendar_gate"),
        ("config_change", "configuration_changed_before_paper_fill"),
    ],
)
def test_new_expiry_keeps_existing_python_jev_and_final_gates(bot, monkeypatch, failure, reason):
    result, event, _ = run_forward(bot, monkeypatch, failure=failure)
    assert not bot.state("paper", NOW)["open_positions"]
    assert reason in json.dumps(event or result)


@pytest.mark.parametrize(
    "now,expiry",
    [
        (NOW, "2026-10-22"),  # 0DTE
        (NOW.replace(hour=19, minute=40), "2026-10-23"),  # original 15:30 cutoff
        (NOW + timedelta(days=3), "2026-10-26"),  # Sunday
    ],
)
def test_zero_dte_timing_and_closed_session_never_enter(bot, monkeypatch, now, expiry):
    _, event, captured = run_forward(bot, monkeypatch, now=now, expiry=expiry)
    assert not bot.state("paper", now)["open_positions"]
    assert captured["jev_calls"] == 0
    assert event is None or not event["discovery"]["qualified_candidates"]
