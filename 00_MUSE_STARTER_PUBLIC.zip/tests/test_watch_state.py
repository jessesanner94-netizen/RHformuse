"""Offline state-machine tests. No broker or model is involved."""

from __future__ import annotations

import json
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from tools.watch_state import (
    active_watches,
    evaluate_watch,
    release_watch,
    resolve_watch,
    save_watch,
    watch_events,
)

NOW = datetime(2026, 9, 21, 14, 0, tzinfo=UTC)


def candidate(number: int = 1, **overrides):
    value = {
        "symbol": "SPY",
        "candidate_id": f"SPY-2026-09-25-{500 + number}-CALL",
        "option_symbol": f"SPY260925C00{500 + number}000",
        "option_type": "CALL",
        "expiration": "2026-09-25",
        "strike": 500 + number,
        "trade_style": "DAY",
    }
    value.update(overrides)
    return value


def decision(cand=None, *, wake=None, invalidate=None, expires=None, action="WATCH", **overrides):
    cand = cand or candidate()
    value = {
        "action": action,
        "candidate_id": cand["candidate_id"],
        "decision_valid_until": (NOW + timedelta(minutes=30)).isoformat(),
        "reconsider_above": None,
        "reconsider_below": None,
        "watch_conditions": {
            "wake_all": wake
            if wake is not None
            else [{"field": "underlying_price", "operator": "gte", "value": 502}],
            "invalidate_any": invalidate if invalidate is not None else [],
            "expires_at": (expires or NOW + timedelta(minutes=20)).isoformat(),
        },
    }
    value.update(overrides)
    return value


def observe(db, cand=None, values=None, *, observed_at=NOW, now=NOW):
    return evaluate_watch(
        db,
        candidate=cand or candidate(),
        observations=values if values is not None else {"underlying_price": 502},
        observed_at=observed_at,
        now=now,
    )


def test_wake_all_and_invalidate_any_precedence(tmp_path):
    db = tmp_path / "watch.sqlite"
    wake = [
        {"field": "underlying_price", "operator": "gte", "value": 502},
        {"field": "technical.confirmed", "operator": "eq", "value": True},
    ]
    invalid = [{"field": "news.label", "operator": "eq", "value": "ADVERSE"}]
    saved = save_watch(
        db, candidate=candidate(), decision=decision(wake=wake, invalidate=invalid), now=NOW
    )
    assert saved["status"] == "SAVED"
    first = observe(
        db, values={"underlying_price": 502, "technical": {"confirmed": False}}, observed_at=NOW
    )
    assert first["status"] == "WAITING"
    second = observe(
        db,
        values={
            "underlying_price": 502,
            "technical": {"confirmed": True},
            "news": {"label": "ADVERSE"},
        },
        observed_at=NOW + timedelta(seconds=1),
        now=NOW + timedelta(seconds=1),
    )
    assert second["status"] == "INVALIDATED"
    prior = observe(db, observed_at=NOW + timedelta(seconds=2), now=NOW + timedelta(seconds=2))
    assert prior["status"] == "NO_WATCH"
    assert prior["prior_status"] == "INVALIDATED"
    assert [event["to_status"] for event in watch_events(db, watch_id=saved["watch_id"])] == [
        "ACTIVE",
        "INVALIDATED",
    ]


def test_claim_once_across_concurrent_callers_and_resolution(tmp_path):
    db = tmp_path / "watch.sqlite"
    save_watch(db, candidate=candidate(), decision=decision(), now=NOW)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda _: observe(db), range(8)))
    assert sum(item["status"] == "READY" for item in results) == 1
    ready = next(item for item in results if item["status"] == "READY")
    assert all(item["status"] in {"READY", "ESCALATING"} for item in results)
    assert (
        resolve_watch(db, watch_id=ready["watch_id"], claim_token="wrong", outcome="PASS", now=NOW)[
            "status"
        ]
        == "NOT_CLAIMED"
    )
    assert (
        resolve_watch(
            db,
            watch_id=ready["watch_id"],
            claim_token=ready["claim_token"],
            outcome="PASS",
            now=NOW,
        )["status"]
        == "RESOLVED"
    )
    assert observe(db)["status"] == "RESOLVED"


def test_lease_expiry_requires_recovery_and_never_reclaims(tmp_path):
    db = tmp_path / "watch.sqlite"
    save_watch(db, candidate=candidate(), decision=decision(), now=NOW)
    ready = observe(db)
    later = NOW + timedelta(minutes=6)
    assert observe(db, observed_at=later, now=later)["status"] == "RECOVERY_REQUIRED"
    assert (
        observe(db, observed_at=later + timedelta(seconds=1), now=later + timedelta(seconds=1))[
            "status"
        ]
        == "RECOVERY_REQUIRED"
    )
    assert (
        save_watch(
            db,
            candidate=candidate(),
            decision=decision(),
            now=later,
        )["status"]
        == "RECOVERY_REQUIRED"
    )
    assert (
        resolve_watch(
            db,
            watch_id=ready["watch_id"],
            claim_token=ready["claim_token"],
            outcome="ERROR",
            now=later,
        )["status"]
        == "RESOLVED"
    )


def test_release_only_before_model_call(tmp_path):
    db = tmp_path / "watch.sqlite"
    save_watch(db, candidate=candidate(), decision=decision(), now=NOW)
    ready = observe(db)
    with pytest.raises(ValueError):
        release_watch(
            db,
            watch_id=ready["watch_id"],
            claim_token=ready["claim_token"],
            model_call_started=True,
            now=NOW,
        )
    assert (
        release_watch(
            db,
            watch_id=ready["watch_id"],
            claim_token=ready["claim_token"],
            model_call_started=False,
            now=NOW,
        )["status"]
        == "RELEASED"
    )
    assert (
        observe(db, observed_at=NOW + timedelta(seconds=1), now=NOW + timedelta(seconds=1))[
            "status"
        ]
        == "READY"
    )


def test_exact_identity_cap_replacement_and_expiration(tmp_path):
    db = tmp_path / "watch.sqlite"
    for number in range(1, 4):
        cand = candidate(number)
        assert save_watch(db, candidate=cand, decision=decision(cand), now=NOW)["status"] == "SAVED"
    fourth = candidate(4)
    assert (
        save_watch(db, candidate=fourth, decision=decision(fourth), now=NOW)["status"]
        == "CAP_REACHED"
    )
    assert (
        save_watch(db, candidate=candidate(), decision=decision(), now=NOW)["status"] == "REPLACED"
    )
    for variant in (
        candidate(option_type="PUT"),
        candidate(strike=999),
        candidate(trade_style="SWING"),
    ):
        assert observe(db, variant)["status"] == "NO_WATCH"
    # The provider's optional display symbol may disappear between snapshots.
    assert observe(db, candidate(option_symbol=""), values={"underlying_price": 500})[
        "status"
    ] == "WAITING"
    expired = NOW + timedelta(minutes=21)
    terminal = observe(db, candidate(), observed_at=expired, now=expired)
    assert terminal["status"] == "NO_WATCH"
    assert terminal["prior_status"] == "EXPIRED"
    assert (
        save_watch(
            db,
            candidate=fourth,
            decision=decision(
                fourth,
                expires=expired + timedelta(minutes=1),
                decision_valid_until=(expired + timedelta(minutes=2)).isoformat(),
            ),
            now=expired,
        )["status"]
        == "SAVED"
    )


def test_stale_future_out_of_order_and_missing_inputs_do_not_wake(tmp_path):
    db = tmp_path / "watch.sqlite"
    save_watch(db, candidate=candidate(), decision=decision(), now=NOW)
    assert observe(db, observed_at=NOW - timedelta(minutes=4))["reason"] == "stale_observation"
    assert observe(db, observed_at=NOW + timedelta(minutes=1))["reason"] == "future_observation"
    assert observe(db, values={})["status"] == "WAITING"
    assert observe(db)["reason"] == "out_of_order_observation"
    assert (
        observe(db, observed_at=NOW + timedelta(seconds=1), now=NOW + timedelta(seconds=1))[
            "status"
        ]
        == "READY"
    )


def test_watch_accepts_real_instrument_without_display_symbol(tmp_path):
    db = tmp_path / "watch.sqlite"
    contract = candidate(option_symbol="")
    saved = save_watch(db, candidate=contract, decision=decision(contract), now=NOW)
    assert saved["status"] == "SAVED"
    assert observe(db, candidate(option_symbol="OTHER"), values={"underlying_price": 502})[
        "status"
    ] == "READY"


def test_legacy_wait_price_trigger_and_validation(tmp_path):
    db = tmp_path / "watch.sqlite"
    old = decision(action="WAIT", watch_conditions=None, reconsider_below=499)
    assert save_watch(db, candidate=candidate(), decision=old, now=NOW)["status"] == "SAVED"
    assert observe(db, values={"underlying_price": 500})["status"] == "WAITING"
    assert (
        observe(
            db,
            values={"underlying_price": 499},
            observed_at=NOW + timedelta(seconds=1),
            now=NOW + timedelta(seconds=1),
        )["status"]
        == "READY"
    )
    invalid = decision(wake=[{"field": "underlying_price", "operator": "__import__", "value": 1}])
    with pytest.raises(ValueError):
        save_watch(tmp_path / "invalid.sqlite", candidate=candidate(), decision=invalid, now=NOW)
    with pytest.raises(ValueError):
        save_watch(
            tmp_path / "invalid.sqlite",
            candidate=candidate(),
            decision=decision(expires=NOW - timedelta(seconds=1)),
            now=NOW,
        )
    with pytest.raises(ValueError):
        save_watch(
            tmp_path / "invalid.sqlite",
            candidate=candidate(),
            decision=decision(wake=[{"field": "a", "operator": "gte", "value": "one"}]),
            now=NOW,
        )


def test_schema_keeps_watch_structured_and_wait_compatible():
    schema = json.loads(
        (
            Path(__file__).parents[1] / "prompts" / "watch_decision.schema.json"
        ).read_text(encoding="utf-8")
    )
    assert schema["properties"]["action"]["enum"] == ["BUY", "PASS", "WATCH", "WAIT"]
    assert "watch_conditions" in schema["required"]
    assert (
        schema["properties"]["watch_conditions"]["properties"]["wake_all"]["items"]["$ref"]
        == "#/$defs/condition"
    )


def test_transition_log_rejects_update_and_delete(tmp_path):
    db = tmp_path / "watch.sqlite"
    saved = save_watch(db, candidate=candidate(), decision=decision(), now=NOW)
    with sqlite3.connect(db) as connection:
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute(
                "UPDATE watch_events SET reason='altered' WHERE watch_id=?",
                (saved["watch_id"],),
            )
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute(
                "DELETE FROM watch_events WHERE watch_id=?",
                (saved["watch_id"],),
            )


def test_active_watches_maintains_expiration_without_candidate(tmp_path):
    db = tmp_path / "watch.sqlite"
    saved = save_watch(db, candidate=candidate(), decision=decision(), now=NOW)
    assert [row["watch_id"] for row in active_watches(db, now=NOW)] == [saved["watch_id"]]
    assert active_watches(db, now=NOW + timedelta(minutes=21)) == []
    assert watch_events(db, watch_id=saved["watch_id"])[-1]["to_status"] == "EXPIRED"


def test_overlong_watch_is_shortened_without_changing_triggers():
    from tools.watch_state import bound_watch_expiration, validate_handoff

    proposed = decision(expires=NOW + timedelta(hours=4),
                        decision_valid_until=(NOW + timedelta(hours=4)).isoformat())
    bounded = bound_watch_expiration(proposed, now=NOW,
                                    deadline=NOW + timedelta(minutes=60))
    assert bounded["watch_conditions"]["wake_all"] == proposed["watch_conditions"]["wake_all"]
    assert datetime.fromisoformat(bounded["watch_conditions"]["expires_at"]) == (
        NOW + timedelta(minutes=60)
    )
    assert proposed["watch_conditions"]["expires_at"] != bounded["watch_conditions"]["expires_at"]
    validate_handoff(bounded, {"underlying_price": 499}, now=NOW)


def test_shortening_never_revives_expired_watch():
    from tools.watch_state import bound_watch_expiration, validate_handoff

    proposed = decision(expires=NOW - timedelta(minutes=1))
    bounded = bound_watch_expiration(proposed, now=NOW,
                                    deadline=NOW + timedelta(minutes=60))
    with pytest.raises(ValueError, match="must be future"):
        validate_handoff(bounded, {"underlying_price": 499}, now=NOW)
