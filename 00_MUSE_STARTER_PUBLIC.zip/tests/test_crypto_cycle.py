import asyncio
import json
import shutil
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from tools.config import load_config
from tools.crypto_cycle import parse_decision, run_cycle
from tools.crypto_paper import CryptoPaperStore
from tools.decision_context import reserve_model_call

NOW = datetime(2026, 9, 20, 15, 0, 15, tzinfo=UTC)
TRIAL_NOW = datetime(2026, 9, 21, 20, 15, 15, tzinfo=UTC)
ROOT = Path(__file__).resolve().parents[1]


def setup(tmp_path, *, relative=False, trial=False):
    target = tmp_path / "CONFIG.md"
    shutil.copy(ROOT / "CONFIG.md", target)
    settings = {
        "CRYPTO_JEV_ABOVE_AVERAGE": relative,
        "CRYPTO_JEV_OVERNIGHT_TEST": trial,
    }
    lines = target.read_text(encoding="utf-8").splitlines()
    for index, line in enumerate(lines):
        name = line.partition(":")[0].strip()
        if name in settings:
            lines[index] = f"{name}: {str(settings[name]).lower()}"
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return load_config(target)


def snapshot(now=NOW, *, declining=False):
    end = now.replace(second=0, microsecond=0)
    bars = []
    for index in range(90):
        close = 3000 + (-index if declining else index)
        at = end - timedelta(minutes=5 * (90 - index))
        bars.append(
            {
                "starts_at": at.isoformat(),
                "ends_at": (at + timedelta(minutes=5)).isoformat(),
                "open": close - 0.2,
                "high": close + 1,
                "low": close - 1,
                "close": close,
                "volume": 100,
            }
        )
    return {
        "status": "OK",
        "symbol": "ETH-USD",
        "venue": "COINBASE_EXCHANGE",
        "quote": {"bid": 3089.0, "ask": 3089.1, "price": 3089.05, "updated_at": now.isoformat()},
        "candles_5m": bars,
        "book": {
            "symbol": "ETH-USD",
            "updated_at": now.isoformat(),
            "bids": [{"price": "3089", "quantity": 100}],
            "asks": [{"price": "3089.1", "quantity": 100}],
        },
    }


def decision(action="BUY", watch=None):
    return {
        "action": action,
        "symbol": "ETH-USD",
        "thesis": "Test continuation",
        "invalidation": "Loss of support",
        "reason": "Synthetic fixture only",
        "watch": watch,
    }


def dependencies(*, action="BUY", declined=False, jev_ok=True, watch=None, now=NOW):
    calls = {"model": 0, "jev": 0, "quotes": 0}

    async def fetcher(**kwargs):
        return snapshot(now=now, declining=declined)

    async def quote_fetcher(**kwargs):
        calls["quotes"] += 1
        return snapshot(now=now)["quote"]

    def evaluator(*args, **kwargs):
        calls["jev"] += 1
        return {
            "status": "OK" if jev_ok else "ERROR",
            "policy": {"would_escalate": jev_ok},
            "scores": {"setup_quality": 0.95},
            "routing_effect": True,
        }

    def model(*args, **kwargs):
        calls["model"] += 1
        assert kwargs["isolated_policy_name"] == "CRYPTO_AGENT_AGENTS.md"
        return {
            "status": "COMPLETED",
            "codex_invoked": True,
            "output": json.dumps(decision(action, watch)),
        }

    return calls, {
        "fetcher": fetcher,
        "quote_fetcher": quote_fetcher,
        "evaluator": evaluator,
        "model": model,
        "calendar": lambda *a, **k: {"status": "OK", "entry_allowed": True},
    }


def test_real_pipeline_paper_buy_and_duplicate_skip(tmp_path):
    config = setup(tmp_path)
    calls, kwargs = dependencies()
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert result["status"] == "PAPER_BUY", result
    assert result["orders_placed"] == 0
    assert calls == {"model": 1, "jev": 1, "quotes": 1}
    again = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert again["status"] == "HOLD"
    assert calls["model"] == 1
    assert CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config).read()[
        "position"
    ]


@pytest.mark.parametrize(
    "declined,jev_ok,expected,jev_calls",
    [(True, True, "PYTHON_REJECTED", 0), (False, False, "JEV_FILTERED", 1)],
)
def test_filters_never_call_model(tmp_path, declined, jev_ok, expected, jev_calls):
    setup(tmp_path)
    calls, kwargs = dependencies(declined=declined, jev_ok=jev_ok)
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert result["status"] == expected, result
    assert calls["model"] == 0 and calls["jev"] == jev_calls


def test_exhausted_budget_keeps_jev_research_and_monitor_exits(tmp_path):
    config = setup(tmp_path)
    path = tmp_path / "state/runtime/model_budget.json"
    for i in range(20):
        assert (
            reserve_model_call(path, maximum_calls=20, now=NOW, packet_signature=str(i))["status"]
            == "RESERVED"
        )
    calls, kwargs = dependencies()
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert result["status"] == "BUDGET_BLOCKED" and calls["jev"] == 1 and calls["model"] == 0
    ledger = CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config)
    ledger.buy(snapshot()["quote"], decision(), NOW, deadline=NOW + timedelta(hours=1))

    async def stopped(**kwargs):
        return {"bid": 3000.0, "ask": 3000.1, "updated_at": NOW.isoformat()}

    kwargs["quote_fetcher"] = stopped
    result = asyncio.run(run_cycle(tmp_path, monitor_only=True, now=NOW, **kwargs))
    assert result["monitor"]["status"] == "PAPER_EXIT"
    assert calls["model"] == 0 and calls["jev"] == 1


def test_changed_technical_after_luna_blocks_buy(tmp_path):
    setup(tmp_path)
    calls, kwargs = dependencies()
    fetch_count = 0

    async def changed(**kwargs):
        nonlocal fetch_count
        fetch_count += 1
        return snapshot(declining=fetch_count > 1)

    kwargs["fetcher"] = changed
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert calls["model"] == 1 and result["status"] == "BLOCKED"
    assert result["reason"] == "final_python_gate_failed"


def test_watch_is_persisted_and_watching_is_model_free(tmp_path):
    setup(tmp_path)
    watch = {
        "price_above": 3100,
        "invalidate_below": 3050,
        "expires_at": (NOW + timedelta(minutes=30)).isoformat(),
    }
    calls, kwargs = dependencies(action="WATCH", watch=watch)
    first = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    second = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert first["status"] == second["status"] == "WATCHING"
    assert calls["model"] == 1


def test_invalid_already_true_watch_rejected():
    value = decision(
        "WATCH",
        {
            "price_above": 3000,
            "invalidate_below": 2900,
            "expires_at": (NOW + timedelta(minutes=30)).isoformat(),
        },
    )
    with pytest.raises(ValueError, match="future price"):
        parse_decision(json.dumps(value), snapshot()["quote"], NOW)


def test_shadow_scores_cannot_authorize_crypto_route(tmp_path):
    setup(tmp_path)
    calls, kwargs = dependencies()
    original = kwargs["evaluator"]
    kwargs["evaluator"] = lambda *a, **k: {**original(*a, **k), "routing_effect": False}
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert result["status"] == "JEV_FILTERED" and calls["model"] == 0


def test_relative_below_mean_blocks_even_during_old_trial(monkeypatch, tmp_path):
    import tools.jev_relative as relative

    setup(tmp_path, relative=True, trial=True)
    calls, kwargs = dependencies(now=TRIAL_NOW)
    monkeypatch.setattr(
        relative,
        "relative_setup_policy",
        lambda *a, **k: {
            "would_escalate": False,
            "reason": "relative_setup_not_above_mean",
            "history_count": 4,
            "history_mean": 0.8,
            "score": 0.7,
        },
    )
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=TRIAL_NOW, **kwargs))
    assert result["status"] == "JEV_FILTERED"
    assert result["jev"]["policy"]["reason"] == "relative_setup_not_above_mean"
    assert calls["jev"] == 1 and calls["model"] == 0
    assert "jev_trial" not in result


def test_relative_above_mean_overrides_old_policy_without_exposing_jev(
    monkeypatch, tmp_path
):
    import tools.jev_relative as relative

    setup(tmp_path, relative=True)
    calls, kwargs = dependencies(action="PASS")
    original_evaluator = kwargs["evaluator"]
    original_model = kwargs["model"]

    def old_policy_rejects(*args, **kw):
        return {**original_evaluator(*args, **kw), "policy": {"would_escalate": False}}

    def inspect_model(event, *args, **kw):
        assert "jev_context" not in event["decision_packet"]
        return original_model(event, *args, **kw)

    kwargs["evaluator"] = old_policy_rejects
    kwargs["model"] = inspect_model
    monkeypatch.setattr(
        relative,
        "relative_setup_policy",
        lambda *a, **k: {
            "would_escalate": True,
            "reason": "relative_setup_above_mean",
            "history_count": 5,
            "history_mean": 0.6,
            "score": 0.7,
        },
    )
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert result["status"] == "PASS"
    assert result["jev"]["policy"]["reason"] == "relative_setup_above_mean"
    assert calls["model"] == 1


def test_relative_admission_still_obeys_shared_budget(monkeypatch, tmp_path):
    import tools.jev_relative as relative

    config = setup(tmp_path, relative=True)
    budget_path = tmp_path / "state/runtime/model_budget.json"
    for index in range(20):
        assert (
            reserve_model_call(
                budget_path,
                maximum_calls=20,
                now=NOW,
                packet_signature=f"prior-{index}",
            )["status"]
            == "RESERVED"
        )
    calls, kwargs = dependencies(action="PASS")
    monkeypatch.setattr(
        relative,
        "relative_setup_policy",
        lambda *a, **k: {"would_escalate": True, "reason": "relative_setup_above_mean"},
    )
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert config.get("CRYPTO_JEV_ABOVE_AVERAGE") is True
    assert result["status"] == "BUDGET_BLOCKED"
    assert calls["jev"] == 1 and calls["model"] == 0


def test_relative_admission_still_obeys_model_cooldown(monkeypatch, tmp_path):
    import tools.jev_relative as relative

    config = setup(tmp_path, relative=True)
    CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config).update(
        {"last_model_at": (NOW - timedelta(minutes=10)).isoformat()}
    )
    calls, kwargs = dependencies(action="PASS")
    monkeypatch.setattr(
        relative,
        "relative_setup_policy",
        lambda *a, **k: {"would_escalate": True, "reason": "relative_setup_above_mean"},
    )
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=NOW, **kwargs))
    assert result["status"] == "SKIPPED"
    assert result["reason"] == "unchanged_candidate_model_cooldown"
    assert calls["jev"] == 1 and calls["model"] == 0
