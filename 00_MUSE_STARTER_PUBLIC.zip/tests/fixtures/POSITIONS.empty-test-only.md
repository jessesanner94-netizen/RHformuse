# Empty position memory — test fixture only

No open positions. Never use live account memory for flat-broker unit tests.
