import asyncio
from types import SimpleNamespace

import pytest

from tools.robinhood_mcp import _complete_option_instruments, _near_money_instruments


def test_near_market_strikes_beyond_old_500_cutoff_are_retrieved():
    calls = []

    async def call_tool(name, args):
        calls.append(args)
        strikes = range(250, 750) if 'cursor' not in args else [767, 768, 769]
        rows = [{'id': str(k), 'chain_symbol': 'SPY', 'expiration_date': '2026-09-28',
                 'type': 'put', 'strike_price': k} for k in strikes]
        return SimpleNamespace(structuredContent={'data': {
            'results': rows, 'next': 'cD03MzMuMDAwMA=='
            if 'cursor' not in args else None}}, isError=False)

    rows, audit = asyncio.run(_complete_option_instruments(
        SimpleNamespace(call_tool=call_tool), {'chain_id': 'spy'}))
    selected = _near_money_instruments(rows, [{'symbol': 'SPY', 'last_trade_price': '768'}],
                                      per_expiration_type=3)
    assert {r['strike_price'] for r in selected} == {767, 768, 769}
    assert audit == {'pages': 2, 'instruments': 503, 'complete': True}
    assert calls[1]['cursor'] == 'cD03MzMuMDAwMA=='


@pytest.mark.parametrize('next_url', ['https://example.test/no-cursor',
                                     'https://example.test/?cursor=repeated'])
def test_incomplete_chain_never_returns_partial_selection(next_url):
    async def call_tool(*args):
        return SimpleNamespace(structuredContent={'results': [], 'next': next_url}, isError=False)

    with pytest.raises(RuntimeError, match='option_chain_invalid_or_repeated_cursor'):
        asyncio.run(_complete_option_instruments(SimpleNamespace(call_tool=call_tool), {}))


def test_page_limit_fails_explicitly():
    calls = []

    async def call_tool(name, args):
        calls.append(args)
        return SimpleNamespace(structuredContent={
            'results': [], 'next': f'https://example.test/?cursor={len(calls)}'}, isError=False)

    with pytest.raises(RuntimeError, match='option_chain_incomplete_safety_limit'):
        asyncio.run(_complete_option_instruments(SimpleNamespace(call_tool=call_tool), {}))
    assert len(calls) == 64
