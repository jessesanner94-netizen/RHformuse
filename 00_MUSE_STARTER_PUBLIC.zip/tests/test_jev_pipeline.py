import asyncio
import json
from copy import deepcopy
from datetime import UTC, datetime, timedelta

import pytest

import tools.scheduled_cycle as cycle
from tools.config import TradingConfig
from tools.decision_context import reserve_model_call
from tools.jev_client import JevResult
from tools.jev_pipeline import evaluate_candidate, record_routing
from tools.jev_store import JevStore

NOW = datetime(2026, 9, 18, 15, tzinfo=UTC)


def packet():
    return {
        "as_of": NOW.isoformat(),
        "candidate": {
            "candidate_id": "SPY-contract",
            "symbol": "SPY",
            "option_symbol": "SPY-test",
            "option_type": "CALL",
            "expiration": "2026-09-25",
            "strike": 500,
            "python_preferred_style": "DAY",
            "underlying_price": 500,
            "quote_updated_at": NOW.isoformat(),
            "underlying_quote_updated_at": NOW.isoformat(),
            "spread_percent": 2,
        },
        "technical": {"timeframes": {}},
        "python_gate": {"status": "QUALIFIED"},
    }


class FakeClient:
    def __init__(self, fail=False):
        self.calls = 0
        self.fail = fail

    def evaluate(self, state, questions):
        self.calls += 1
        assert "account" not in state
        if self.fail:
            raise TimeoutError("secret-like exception must not be logged")
        return JevResult(
            status="OK",
            model="jev-test",
            answers={
                "setup_quality": {"type": "noul", "noul": 0.1},
                "false_breakout_risk": {"type": "noul", "noul": 0.9},
                "escalate_to_luna": {"type": "noul", "noul": 0.1},
            },
        )


def event():
    return {
        "paper_portfolio": {
            "status": "QUIET",
            "open_positions": [],
            "portfolio": {"open_positions": 0},
        }
    }


def setup_route(monkeypatch, tmp_path, resolved_config, *, shadow=True, fail=False, watch=False):
    config = TradingConfig(
        {
            **resolved_config.values,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": shadow,
            "ENABLE_JEV_ESCALATION": True,
            "ENABLE_MULTI_WATCH": watch,
            "OPTIONS_JEV_RANKING_ONLY": False,
        }
    )
    client = FakeClient(fail)
    seen = []

    async def build(*a, **kw):
        p = packet()
        if p["candidate"]["candidate_id"] in kw["excluded_candidate_ids"]:
            return {"status": "NO_CANDIDATE", "selected_candidates": []}
        return {
            "status": "READY",
            "packet": p,
            "packet_signature": "fixture",
            "selected_candidates": [p["candidate"]],
        }

    def evaluate(p, cfg, **kw):
        return evaluate_candidate(p, cfg, **kw, client=client)

    def model(e, **kw):
        seen.append(deepcopy(e))
        return {
            "status": "COMPLETED",
            "codex_invoked": True,
            "output": json.dumps(
                {
                    "action": "PASS",
                    "candidate_id": "SPY-contract",
                    "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
                }
            ),
        }

    monkeypatch.setattr(cycle, "build_decision_packet", build)
    monkeypatch.setattr(cycle, "evaluate_candidate", evaluate)
    monkeypatch.setattr(cycle, "run_trigger", model)
    return config, client, seen


def setup_ranking_route(monkeypatch, resolved_config, candidates, evaluations, *, watch=False):
    config = TradingConfig(
        {
            **resolved_config.values,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": False,
            "ENABLE_JEV_ESCALATION": True,
            "ENABLE_MULTI_WATCH": watch,
            "OPTIONS_JEV_RANKING_ONLY": True,
        }
    )
    seen = []
    evaluated = []

    async def build(*args, **kwargs):
        excluded = kwargs["excluded_candidate_ids"]
        candidate = next(
            (deepcopy(item) for item in candidates if item["candidate_id"] not in excluded), None
        )
        if candidate is None:
            return {"status": "NO_CANDIDATE", "packet": None, "selected_candidates": []}
        return {
            "status": "READY",
            "packet": {
                "as_of": NOW.isoformat(),
                "candidate": candidate,
                "technical": {"timeframes": {}},
                "python_gate": {"status": "QUALIFIED"},
            },
            "packet_signature": "fixture-" + candidate["candidate_id"],
            "selected_candidates": [candidate],
            "candidates_evaluated": 1,
        }

    def evaluate(packet_value, *_args, **_kwargs):
        candidate_id = packet_value["candidate"]["candidate_id"]
        evaluated.append(candidate_id)
        return deepcopy(evaluations[candidate_id])

    def model(event_value, **_kwargs):
        seen.append(deepcopy(event_value))
        return {
            "status": "COMPLETED",
            "codex_invoked": True,
            "output": json.dumps(
                {
                    "action": "PASS",
                    "candidate_id": event_value["decision_packet"]["candidate"]["candidate_id"],
                    "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
                }
            ),
        }

    monkeypatch.setattr(cycle, "build_decision_packet", build)
    monkeypatch.setattr(cycle, "evaluate_candidate", evaluate)
    monkeypatch.setattr(cycle, "run_trigger", model)
    return config, seen, evaluated


def ranking_candidate(candidate_id, symbol, price):
    return {
        "candidate_id": candidate_id,
        "symbol": symbol,
        "option_symbol": candidate_id + "-display",
        "option_type": "CALL",
        "expiration": "2026-09-25",
        "strike": price,
        "python_preferred_style": "DAY",
        "eligible_styles": ["DAY"],
        "underlying_price": price,
        "underlying_quote_updated_at": NOW.isoformat(),
        "spread_percent": 2,
    }


def jev_scores(setup, timing, escalation):
    return {
        "status": "OK",
        "routing_effect": True,
        "scores": {
            "setup_quality": setup,
            "entry_timing_quality": timing,
            "escalate_to_luna": escalation,
        },
    }


@pytest.mark.parametrize("fail", [False, True])
def test_shadow_and_failure_leave_baseline_luna_packet_unchanged(
    monkeypatch,
    tmp_path,
    resolved_config,
    fail,
):
    config, client, seen = setup_route(monkeypatch, tmp_path, resolved_config, fail=fail)
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert client.calls == 1
    assert seen[0]["decision_packet"] == packet()
    assert result["decision_verdict"]["action"] == "PASS"
    store = JevStore(tmp_path / "state/research/jev.sqlite3")
    with store.connect() as db:
        assert db.execute("SELECT COUNT(*) FROM observations").fetchone()[0] == 1
        events = db.execute("SELECT payload_json FROM events").fetchall()
    assert json.loads(events[0][0])["luna_escalated"] is True


def test_active_jev_can_only_suppress_luna_not_buy(monkeypatch, tmp_path, resolved_config):
    config, client, seen = setup_route(monkeypatch, tmp_path, resolved_config, shadow=False)
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert client.calls == 1
    assert not seen
    assert result["decision"]["codex_invoked"] is False
    assert not (tmp_path / "state/runtime/model_budget.json").exists()


def test_active_paper_jev_failure_blocks_new_luna(monkeypatch, tmp_path, resolved_config):
    config, client, seen = setup_route(
        monkeypatch, tmp_path, resolved_config, shadow=False, fail=True
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert client.calls == 1
    assert seen == []
    assert result["decision"]["reason"] == "jev_active_unavailable"
    assert result["suppressed_candidates"][0]["reason"] == "jev_active_unavailable"
    assert not (tmp_path / "state/runtime/model_budget.json").exists()


def test_ranking_only_selects_best_of_three_without_threshold_veto(
    monkeypatch, tmp_path, resolved_config
):
    candidates = [
        ranking_candidate("first", "SPY", 500),
        ranking_candidate("best", "QQQ", 600),
        ranking_candidate("third", "SPY", 501),
    ]
    # Every score is below the former hard thresholds. They still rank rather than veto.
    evaluations = {
        "first": jev_scores(0.10, 0.90, 0.90),
        "best": jev_scores(0.20, 0.10, 0.10),
        "third": jev_scores(0.10, 0.95, 0.95),
    }
    config, seen, evaluated = setup_ranking_route(
        monkeypatch, resolved_config, candidates, evaluations
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert evaluated == ["first", "best", "third"]
    assert len(seen) == 1
    assert seen[0]["decision_packet"]["candidate"]["candidate_id"] == "best"
    assert "jev_context" not in seen[0]["decision_packet"]
    assert "jev" not in seen[0]["decision_packet"]["watch_observations"]
    assert result["jev_ranking"]["selected_candidate_id"] == "best"
    assert result["jev_ranking"]["valid_score_count"] == 3
    assert result["decision"]["codex_invoked"] is True


def test_ranking_only_falls_back_to_python_order_when_jev_unavailable(
    monkeypatch, tmp_path, resolved_config
):
    candidates = [
        ranking_candidate("python-first", "SPY", 500),
        ranking_candidate("python-second", "QQQ", 600),
    ]
    unavailable = {"status": "UNAVAILABLE", "routing_effect": False}
    config, seen, evaluated = setup_ranking_route(
        monkeypatch,
        resolved_config,
        candidates,
        {candidate["candidate_id"]: unavailable for candidate in candidates},
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert evaluated == ["python-first", "python-second"]
    assert seen[0]["decision_packet"]["candidate"]["candidate_id"] == "python-first"
    assert result["jev_ranking"]["fallback_used"] is True
    assert result["decision"]["codex_invoked"] is True


def test_ranking_only_partial_scores_also_use_python_order(
    monkeypatch, tmp_path, resolved_config
):
    candidates = [
        ranking_candidate("unavailable-first", "SPY", 500),
        ranking_candidate("scored-second", "QQQ", 600),
    ]
    config, seen, _ = setup_ranking_route(
        monkeypatch,
        resolved_config,
        candidates,
        {
            "unavailable-first": {
                "status": "OK",
                "routing_effect": True,
                "scores": {"setup_quality": 0.2, "escalate_to_luna": 0.9},
            },
            "scored-second": jev_scores(1, 1, 1),
        },
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert seen[0]["decision_packet"]["candidate"]["candidate_id"] == "unavailable-first"
    assert result["jev_ranking"]["fallback_used"] is True


def test_ranking_only_ready_watch_has_priority_and_resolves(
    monkeypatch, tmp_path, resolved_config
):
    from tools.watch_state import active_watches, save_watch

    candidates = [
        ranking_candidate("higher-score", "SPY", 500),
        ranking_candidate("watched", "QQQ", 600),
        ranking_candidate("not-reached", "SPY", 501),
    ]
    evaluations = {
        "higher-score": jev_scores(0.99, 0.99, 0.99),
        "watched": jev_scores(0.01, 0.01, 0.01),
        "not-reached": jev_scores(1.0, 1.0, 1.0),
    }
    config, seen, evaluated = setup_ranking_route(
        monkeypatch, resolved_config, candidates, evaluations, watch=True
    )
    save_watch(
        tmp_path / "state/research/watches.sqlite3",
        candidate={**candidates[1], "trade_style": "DAY"},
        decision={
            "action": "WATCH",
            "candidate_id": "watched",
            "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
            "watch_conditions": {
                "wake_all": [{"field": "underlying_price", "operator": "gte", "value": 600}],
                "invalidate_any": [],
                "expires_at": (NOW + timedelta(minutes=5)).isoformat(),
            },
        },
        now=NOW - timedelta(minutes=1),
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert evaluated == ["higher-score", "watched"]
    assert seen[0]["decision_packet"]["candidate"]["candidate_id"] == "watched"
    assert "previous_watch_thesis" in seen[0]["decision_packet"]
    assert result["jev_ranking"]["selected_watch_ready"] is True
    assert active_watches(tmp_path / "state/research/watches.sqlite3", now=NOW) == []


def test_ranking_only_budget_block_releases_ready_watch(
    monkeypatch, tmp_path, resolved_config
):
    from tools.watch_state import active_watches, save_watch

    watched = ranking_candidate("watched", "QQQ", 600)
    config, seen, _ = setup_ranking_route(
        monkeypatch,
        resolved_config,
        [watched],
        {"watched": jev_scores(0.5, 0.5, 0.5)},
        watch=True,
    )
    config = TradingConfig({**config.values, "MAX_MODEL_CALLS_PER_DAY": 1})
    reserve_model_call(
        tmp_path / "state/runtime/model_budget.json",
        maximum_calls=1,
        now=NOW,
        packet_signature="earlier",
    )
    save_watch(
        tmp_path / "state/research/watches.sqlite3",
        candidate={**watched, "trade_style": "DAY"},
        decision={
            "action": "WATCH",
            "candidate_id": "watched",
            "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
            "watch_conditions": {
                "wake_all": [{"field": "underlying_price", "operator": "gte", "value": 600}],
                "invalidate_any": [],
                "expires_at": (NOW + timedelta(minutes=5)).isoformat(),
            },
        },
        now=NOW - timedelta(minutes=1),
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert seen == []
    assert result["decision"]["status"] == "BUDGET_BLOCKED"
    active = active_watches(tmp_path / "state/research/watches.sqlite3", now=NOW)
    assert active[0]["status"] == "ACTIVE"
    assert active[0]["last_observed_at"] == NOW.isoformat(timespec="microseconds")


def test_ranking_only_all_cache_suppressed_does_not_route_last_candidate(
    monkeypatch, tmp_path, resolved_config
):
    candidates = [ranking_candidate("cached", "SPY", 500)]
    config, seen, evaluated = setup_ranking_route(
        monkeypatch, resolved_config, candidates, {"cached": jev_scores(1, 1, 1)}
    )
    monkeypatch.setattr(
        cycle,
        "cached_decision_blocks",
        lambda *a, **k: {"blocked": True, "reason": "unchanged_pass_cached"},
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert evaluated == []
    assert seen == []
    assert result["packet_status"] == "NO_CANDIDATE"
    assert result["decision"]["codex_invoked"] is False


@pytest.mark.parametrize("reason", ["jev_escalation_filtered", "jev_active_unavailable"])
def test_routing_records_the_exact_per_candidate_suppression_reason(tmp_path, reason):
    observation_id = "observation-id"
    record_routing(
        tmp_path,
        {
            "decision_packet": None,
            "decision": {"status": "SKIPPED", "reason": reason, "codex_invoked": False},
            "suppressed_candidates": [{"candidate_id": "SPY-contract", "reason": reason}],
            "jev_evaluations": [
                {
                    "observation_id": observation_id,
                    "candidate_id": "SPY-contract",
                    "routing_effect": True,
                    "question_versions": ["jev-market-v2"],
                }
            ],
        },
        now=NOW,
    )
    store = JevStore(tmp_path / "state/research/jev.sqlite3")
    with store.connect() as db:
        row = db.execute("SELECT kind,payload_json FROM events").fetchone()
    assert row["kind"] == "candidate_suppressed"
    assert json.loads(row["payload_json"])["reason"] == reason


def test_active_jev_has_no_live_routing_effect(tmp_path, resolved_config):
    config = {
        **resolved_config.values,
        "LIVE_EXECUTION_ENABLED": True,
        "PAPER_TRADING_ENABLED": False,
        "ENABLE_JEV": True,
        "JEV_SHADOW_MODE": False,
        "ENABLE_JEV_ESCALATION": True,
    }
    result = evaluate_candidate(
        packet(), config, project_root=tmp_path, now=NOW, client=FakeClient()
    )
    assert result["status"] == "OK"
    assert result["routing_effect"] is False


def test_shadow_does_not_wait_before_luna(monkeypatch, tmp_path, resolved_config):
    import threading

    config, client, seen = setup_route(monkeypatch, tmp_path, resolved_config)
    released = threading.Event()
    original = cycle.evaluate_candidate
    original_model = cycle.run_trigger

    def slow(*args, **kwargs):
        assert released.wait(5), "Shadow blocked Luna"
        return original(*args, **kwargs)

    def model(*args, **kwargs):
        released.set()
        return original_model(*args, **kwargs)

    monkeypatch.setattr(cycle, "evaluate_candidate", slow)
    monkeypatch.setattr(cycle, "run_trigger", model)
    asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert seen and client.calls == 1


def test_completed_minute_supplies_actual_bar(tmp_path):
    from tools.jev_pipeline import evaluate_completed_minute

    class Capture(FakeClient):
        def evaluate(self, state, questions):
            assert state["completed_minute"]["close"] == 501
            assert "secret" not in state["completed_minute"]
            return super().evaluate(state, questions)

    bar = {
        "symbol": "SPY",
        "starts_at": (NOW - timedelta(minutes=1)).isoformat(),
        "ends_at": NOW.isoformat(),
        "interpolated": False,
        "open": 500,
        "high": 502,
        "low": 499,
        "close": 501,
        "volume": 100,
        "secret": "excluded",
    }
    result = evaluate_completed_minute(
        packet(), bar, {"ENABLE_JEV": True}, project_root=tmp_path, now=NOW, client=Capture()
    )
    assert result["status"] == "OK"


def test_shadow_book_fetch_cannot_block_luna(monkeypatch, tmp_path, resolved_config):
    config, client, seen = setup_route(monkeypatch, tmp_path, resolved_config)
    original_model = cycle.run_trigger

    async def run():
        book = asyncio.get_running_loop().create_future()

        def model(*args, **kwargs):
            book.set_result({"status": "NO_DEPTH", "summaries": {}})
            return original_model(*args, **kwargs)

        monkeypatch.setattr(cycle, "run_trigger", model)
        return await asyncio.wait_for(
            cycle._route_compact_decision(
                {**event(), "_orderbook_pending": book},
                config=config,
                project_root=tmp_path,
                now=NOW,
                execute_models=True,
            ),
            timeout=5,
        )

    asyncio.run(run())
    assert seen and client.calls == 1


def test_exhausted_luna_budget_still_observes_jev(monkeypatch, tmp_path, resolved_config):
    config, client, seen = setup_route(monkeypatch, tmp_path, resolved_config)
    config = TradingConfig({**config.values, "MAX_MODEL_CALLS_PER_DAY": 1})
    reserve_model_call(
        tmp_path / "state/runtime/model_budget.json",
        maximum_calls=1,
        now=NOW,
        packet_signature="earlier",
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert client.calls == 1
    assert not seen
    assert result["decision"]["status"] == "BUDGET_BLOCKED"


def test_duplicate_observation_does_not_spend_again(tmp_path):
    client = FakeClient()
    cfg = {"ENABLE_JEV": True}
    first = evaluate_candidate(packet(), cfg, project_root=tmp_path, now=NOW, client=client)
    second = evaluate_candidate(packet(), cfg, project_root=tmp_path, now=NOW, client=client)
    assert first["status"] == "OK"
    assert second["status"] == "DUPLICATE"
    assert client.calls == 1


def test_watch_wakes_once_after_current_python_gates(monkeypatch, tmp_path, resolved_config):
    from tools.watch_state import save_watch

    config, client, seen = setup_route(monkeypatch, tmp_path, resolved_config, watch=True)
    save_watch(
        tmp_path / "state/research/watches.sqlite3",
        candidate=packet()["candidate"],
        decision={
            "action": "WATCH",
            "candidate_id": "SPY-contract",
            "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
            "watch_conditions": {
                "wake_all": [{"field": "underlying_price", "operator": "gte", "value": 500}],
                "invalidate_any": [],
                "expires_at": (NOW + timedelta(minutes=5)).isoformat(),
            },
        },
        now=NOW - timedelta(minutes=1),
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert result["watch"]["status"] == "READY"
    assert len(seen) == 1
    assert "previous_watch_thesis" in seen[0]["decision_packet"]
    assert "jev" not in seen[0]["decision_packet"]["watch_observations"]


def test_watch_is_observed_before_active_jev_suppression(
    monkeypatch, tmp_path, resolved_config
):
    from tools.watch_state import active_watches, save_watch

    config, client, seen = setup_route(
        monkeypatch, tmp_path, resolved_config, shadow=False, watch=True
    )
    save_watch(
        tmp_path / "state/research/watches.sqlite3",
        candidate=packet()["candidate"],
        decision={
            "action": "WATCH",
            "candidate_id": "SPY-contract",
            "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
            "watch_conditions": {
                "wake_all": [{"field": "underlying_price", "operator": "gte", "value": 500}],
                "invalidate_any": [],
                "expires_at": (NOW + timedelta(minutes=5)).isoformat(),
            },
        },
        now=NOW - timedelta(minutes=1),
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert client.calls == 1
    assert seen == []
    assert result["watch"]["status"] == "READY"
    assert result["suppressed_candidates"][0]["reason"] == "jev_escalation_filtered"
    assert result["suppressed_candidates"][0]["watch_status"] == "READY"
    active = active_watches(tmp_path / "state/research/watches.sqlite3", now=NOW)
    assert active[0]["status"] == "ACTIVE"
    assert active[0]["last_observed_at"] == NOW.isoformat(timespec="microseconds")


def test_expired_prior_watch_does_not_veto_fresh_candidate(
    monkeypatch, tmp_path, resolved_config
):
    from tools.watch_state import save_watch

    config, _, seen = setup_route(monkeypatch, tmp_path, resolved_config, watch=True)
    save_watch(
        tmp_path / "state/research/watches.sqlite3",
        candidate=packet()["candidate"],
        decision={
            "action": "WATCH",
            "candidate_id": "SPY-contract",
            "decision_valid_until": (NOW - timedelta(minutes=2)).isoformat(),
            "watch_conditions": {
                "wake_all": [{"field": "underlying_price", "operator": "gte", "value": 501}],
                "invalidate_any": [],
                "expires_at": (NOW - timedelta(minutes=2)).isoformat(),
            },
        },
        now=NOW - timedelta(minutes=10),
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert len(seen) == 1
    assert result["watch"]["status"] == "NO_WATCH"
    assert result["watch"]["prior_status"] == "EXPIRED"


def test_watch_wakes_using_model_selected_style_and_missing_display_symbol(
    monkeypatch, tmp_path, resolved_config
):
    from tools.watch_state import save_watch

    config, _, seen = setup_route(monkeypatch, tmp_path, resolved_config, watch=True)
    original_build = cycle.build_decision_packet

    async def build(*args, **kwargs):
        result = await original_build(*args, **kwargs)
        if result["status"] == "READY":
            result["packet"]["candidate"]["option_symbol"] = ""
            result["selected_candidates"][0]["watch_trade_style"] = "SWING"
        return result

    monkeypatch.setattr(cycle, "build_decision_packet", build)
    contract = {**packet()["candidate"], "option_symbol": "", "trade_style": "SWING"}
    save_watch(
        tmp_path / "state/research/watches.sqlite3",
        candidate=contract,
        decision={
            "action": "WATCH",
            "candidate_id": "SPY-contract",
            "decision_valid_until": (NOW + timedelta(minutes=5)).isoformat(),
            "watch_conditions": {
                "wake_all": [{"field": "underlying_price", "operator": "gte", "value": 500}],
                "invalidate_any": [],
                "expires_at": (NOW + timedelta(minutes=5)).isoformat(),
            },
        },
        now=NOW - timedelta(minutes=1),
    )
    result = asyncio.run(
        cycle._route_compact_decision(
            event(), config=config, project_root=tmp_path, now=NOW, execute_models=True
        )
    )
    assert result["watch"]["status"] == "READY"
    assert len(seen) == 1
