import asyncio
import json
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from tools import paper_fast_monitor as fast
from tools.config import ConfigError, TradingConfig
from tools.options_strategy import ledger_directory
from tools.paper_trading import _default_portfolio, manage_paper_positions

NOW = datetime(2026, 10, 9, 15, 0, tzinfo=UTC)


def config(resolved_config, **overrides):
    return TradingConfig(
        {
            **resolved_config.values,
            "PAPER_FAST_MONITOR_ENABLED": True,
            "OPTIONS_STRATEGY_EPOCH": "fast_monitor_test",
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": True,
            "PAPER_PRIMARY_DAILY_GREEN_LOCK_ENABLED": True,
            "PAPER_ASSUME_TP_TRADE_THROUGH": False,
            **overrides,
        }
    )


def seed(root, cfg):
    directory = ledger_directory(root, cfg, "paper")
    directory.mkdir(parents=True)
    state = _default_portfolio(10000, now=NOW)
    state["strategy_epoch"] = "fast_monitor_test"
    state["cash"] = 9888.95
    state["open_positions"] = [
        {
            "paper_id": "paper-fixture",
            "contract_identifier": "held-contract",
            "symbol": "QQQ",
            "entry_at": NOW.isoformat(),
            "entry_price": 1.10,
            "entry_cost": 110,
            "entry_cost_estimate": 1.05,
            "exit_cost_estimate": 1.05,
            "quantity": 1,
            "stop_price": 0.825,
            "take_profit_price": 1.43,
            "high_water_bid": 1.10,
            "last_bid": 1.09,
            "trade_style": "DAY",
            "hold_deadline": (NOW + timedelta(hours=1)).isoformat(),
        }
    ]
    path = directory / "PORTFOLIO.json"
    path.write_text(json.dumps(state))
    return path, directory / "EVENTS.jsonl"


def quote(now=NOW, bid=1.0):
    return {
        "status": "OK",
        "as_of": now.isoformat(),
        "option_quotes": [
            {
                "quote": {
                    "instrument_id": "held-contract",
                    "bid_price": str(bid),
                    "ask_price": str(bid + 0.01),
                    "updated_at": now.isoformat(),
                }
            }
        ],
    }


def test_flat_has_no_broker_calls_or_ledger_initialization(tmp_path, resolved_config):
    async def forbidden(_):
        pytest.fail("flat monitor must not call Robinhood")

    cfg = config(resolved_config)
    monitor = fast.PaperMonitor(tmp_path, quote_fetcher=forbidden, history_fetcher=forbidden)
    assert asyncio.run(monitor.poll(cfg))["status"] == "QUIET"
    assert not ledger_directory(tmp_path, cfg, "paper").exists()


@pytest.mark.parametrize(
    "override",
    [
        {"LIVE_EXECUTION_ENABLED": True},
        {"PAPER_TRADING_ENABLED": False},
        {"PAPER_FAST_MONITOR_ENABLED": False},
    ],
)
def test_paper_only_fence_does_not_read_quotes(tmp_path, resolved_config, override):
    async def forbidden(_):
        pytest.fail("disabled/live mode must not call broker or mutate paper state")

    cfg = config(resolved_config, **override)
    path, _ = seed(tmp_path, cfg)
    before = path.read_bytes()
    monitor = fast.PaperMonitor(tmp_path, quote_fetcher=forbidden)
    assert asyncio.run(monitor.poll(cfg))["status"] == "BLOCKED"
    assert before == path.read_bytes()


@pytest.mark.parametrize(
    "bid,elapsed,reason",
    [(0.70, 10, "STOP_LOSS"), (1.50, 10, "TAKE_PROFIT"), (1.00, 3600, "DAY_TRADE_TIME_EXIT")],
)
def test_fresh_exit_reuses_accounting_and_cannot_duplicate(
    tmp_path, resolved_config, bid, elapsed, reason
):
    cfg = config(resolved_config)
    path, events = seed(tmp_path, cfg)
    now = NOW + timedelta(seconds=elapsed)
    requests = []

    async def fetch(rows):
        requests.extend(rows)
        return quote(now, bid)

    monitor = fast.PaperMonitor(tmp_path, quote_fetcher=fetch, clock=lambda: now)
    result = asyncio.run(monitor.poll(cfg))
    assert requests == [{"option_id": "held-contract"}]
    assert result["paper_events"][0]["exit_reason"] == reason
    assert result["paper_events"][0]["realized_pnl"] == pytest.approx(bid * 100 - 112.10)
    assert result["orders_placed"] == result["orders_cancelled"] == 0
    again = manage_paper_positions(
        quote(now, bid), cfg, portfolio_path=path, event_log_path=events, now=now
    )
    assert again["paper_events"] == []
    assert events.read_text().count('"event":"PAPER_EXIT"') == 1
    day = json.loads(path.read_text())["day"]
    assert day["green_lock_active"] is (bid == 1.50)


@pytest.mark.parametrize("age", [21, -3])
def test_stale_or_future_quotes_cannot_exit(tmp_path, resolved_config, age):
    cfg = config(resolved_config)
    seed(tmp_path, cfg)

    async def fetch(_):
        return quote(NOW - timedelta(seconds=age), 0.70)

    monitor = fast.PaperMonitor(tmp_path, quote_fetcher=fetch, clock=lambda: NOW)
    result = asyncio.run(monitor.poll(cfg))
    assert result["status"] == "ATTENTION"
    assert result["attention"][0]["code"] == "PAPER_QUOTE_STALE"
    assert not result["paper_events"] and len(result["open_positions"]) == 1


def test_429_backoff_prevents_repeat_reads(tmp_path, resolved_config):
    cfg = config(resolved_config)
    seed(tmp_path, cfg)
    reads, tick = [], [0.0]

    async def throttled(_):
        reads.append(1)
        response = httpx.Response(
            429, headers={"Retry-After": "60"}, request=httpx.Request("GET", "https://example.test")
        )
        raise httpx.HTTPStatusError("fixture", request=response.request, response=response)

    monitor = fast.PaperMonitor(
        tmp_path, quote_fetcher=throttled, clock=lambda: NOW, monotonic=lambda: tick[0]
    )
    assert asyncio.run(monitor.poll(cfg))["retry_in_seconds"] == 60
    tick[0] = 10
    assert asyncio.run(monitor.poll(cfg))["retry_in_seconds"] == 50
    assert len(reads) == 1


def test_slow_history_never_delays_fresh_stop(tmp_path, resolved_config):
    cfg = config(resolved_config, PAPER_ASSUME_TP_TRADE_THROUGH=True)
    seed(tmp_path, cfg)
    bid = [1.0]

    async def fetch(_):
        return quote(NOW, bid[0])

    async def slow_history(_):
        await asyncio.Event().wait()

    async def scenario():
        monitor = fast.PaperMonitor(
            tmp_path, quote_fetcher=fetch, history_fetcher=slow_history, clock=lambda: NOW
        )
        await monitor.poll(cfg)
        await asyncio.sleep(0)
        bid[0] = 0.70
        result = await asyncio.wait_for(monitor.poll(cfg), timeout=0.5)
        assert result["paper_events"][0]["exit_reason"] == "STOP_LOSS"
        assert monitor.history_task is None

    asyncio.run(scenario())


def test_history_is_once_per_minute_and_preserves_assumed_tp(tmp_path, resolved_config):
    cfg = config(resolved_config, PAPER_ASSUME_TP_TRADE_THROUGH=True)
    seed(tmp_path, cfg)
    now, reads = [NOW + timedelta(minutes=2)], []

    async def fetch(_):
        return quote(now[0], 1.20)

    async def history(rows):
        reads.append(rows)
        return {
            "tp_history": {
                "held-contract": {
                    "status": "OK",
                    "results": [
                        {
                            "instrument_id": "held-contract",
                            "interval": "minute",
                            "bars": [
                                {
                                    "begins_at": (NOW + timedelta(minutes=1)).isoformat(),
                                    "high_price": "2.0",
                                    "low_price": "1.0",
                                    "interpolated": False,
                                }
                            ],
                        }
                    ],
                }
            }
        }

    async def scenario():
        monitor = fast.PaperMonitor(
            tmp_path, quote_fetcher=fetch, history_fetcher=history, clock=lambda: now[0]
        )
        await monitor.poll(cfg)
        await asyncio.wait_for(monitor.history_task, timeout=1)
        now[0] += timedelta(seconds=10)
        result = await monitor.poll(cfg)
        assert len(reads) == 1
        assert result["paper_events"][0]["exit_reason"] == "ASSUMED_LIMIT_TAKE_PROFIT"
        assert result["paper_events"][0]["fill_price"] == 1.43
        await monitor.close()

    asyncio.run(scenario())


def test_loop_targets_ten_seconds_and_logs_observed_interval(
    tmp_path, resolved_config, monkeypatch
):
    cfg = config(resolved_config)
    now, tick = [NOW], [0.0]
    monkeypatch.setattr(fast, "load_config", lambda _: cfg)
    monkeypatch.setattr(fast, "market_window", lambda t: (t <= NOW + timedelta(seconds=10), ""))

    async def advance(seconds):
        assert seconds == 10
        now[0] += timedelta(seconds=seconds)
        tick[0] += seconds

    monkeypatch.setattr(fast.asyncio, "sleep", advance)
    monitor = fast.PaperMonitor(tmp_path, clock=lambda: now[0], monotonic=lambda: tick[0])
    result = asyncio.run(fast.run(tmp_path, monitor=monitor))
    assert result["status"] == "SKIPPED"
    saved = json.loads((tmp_path / "state/runtime/paper_fast_monitor.json").read_text())
    assert saved["target_interval_seconds"] == saved["observed_interval_seconds"] == 10
    assert saved["models_invoked"] == saved["orders_placed"] == 0


@pytest.mark.parametrize("value", [False, 0, "10", 121])
def test_invalid_monitor_settings_fail_closed(resolved_config, value):
    with pytest.raises(ConfigError):
        fast.settings(config(resolved_config, PAPER_OPEN_POSITION_POLL_SECONDS=value))


def test_history_is_not_refetched_on_each_quote_tick(tmp_path, resolved_config):
    cfg = config(resolved_config, PAPER_ASSUME_TP_TRADE_THROUGH=True)
    seed(tmp_path, cfg)
    now, reads = [NOW], []

    async def fetch(_):
        return quote(now[0], 1.0)

    async def history(_):
        reads.append(now[0])
        return {"tp_history": {}}

    async def scenario():
        monitor = fast.PaperMonitor(
            tmp_path, quote_fetcher=fetch, history_fetcher=history, clock=lambda: now[0]
        )
        await monitor.poll(cfg)
        await monitor.history_task
        for elapsed in [10, 20, 30, 40, 50]:
            now[0] = NOW + timedelta(seconds=elapsed)
            await monitor.poll(cfg)
        assert len(reads) == 1
        now[0] = NOW + timedelta(seconds=60)
        await monitor.poll(cfg)
        await monitor.history_task
        assert len(reads) == 2
        await monitor.close()

    asyncio.run(scenario())


def test_quote_timeout_keeps_position_open(tmp_path, resolved_config):
    cfg = config(resolved_config, PAPER_OPEN_POSITION_POLL_SECONDS=1)
    path, _ = seed(tmp_path, cfg)
    before = path.read_bytes()

    async def hangs(_):
        await asyncio.Event().wait()

    result = asyncio.run(fast.PaperMonitor(tmp_path, quote_fetcher=hangs).poll(cfg))
    assert result["status"] == "ATTENTION"
    assert result["attention"][0]["error_type"] == "TimeoutError"
    assert path.read_bytes() == before


@pytest.mark.parametrize("age", [21, -3])
def test_normal_paper_monitor_uses_same_stricter_quote_age(tmp_path, resolved_config, age):
    cfg = config(resolved_config)
    path, events = seed(tmp_path, cfg)
    result = manage_paper_positions(
        quote(NOW - timedelta(seconds=age), 0.70),
        cfg,
        portfolio_path=path,
        event_log_path=events,
        now=NOW,
    )
    assert result["status"] == "ATTENTION" and not result["paper_events"]


def test_new_position_is_detected_on_next_ten_second_tick(tmp_path, resolved_config, monkeypatch):
    cfg = config(resolved_config)
    now, tick = [NOW], [0.0]
    monkeypatch.setattr(fast, "load_config", lambda _: cfg)
    monkeypatch.setattr(fast, "market_window", lambda t: (t <= NOW + timedelta(seconds=10), ""))

    async def advance(seconds):
        now[0] += timedelta(seconds=seconds)
        tick[0] += seconds
        if tick[0] == 10:
            seed(tmp_path, cfg)

    async def fetch(_):
        return quote(now[0], 0.70)

    monkeypatch.setattr(fast.asyncio, "sleep", advance)
    monitor = fast.PaperMonitor(
        tmp_path, quote_fetcher=fetch, clock=lambda: now[0], monotonic=lambda: tick[0]
    )
    asyncio.run(fast.run(tmp_path, monitor=monitor))
    _, events = (
        ledger_directory(tmp_path, cfg, "paper") / "PORTFOLIO.json",
        ledger_directory(tmp_path, cfg, "paper") / "EVENTS.jsonl",
    )
    event = json.loads(events.read_text().splitlines()[-1])
    assert event["exit_reason"] == "STOP_LOSS"
    assert event["timestamp"] == (NOW + timedelta(seconds=10)).isoformat()


def test_quote_adapter_strips_history_and_underlying_requests(monkeypatch):
    from tools import robinhood_mcp

    calls = []

    async def session(action, requests):
        calls.append((action, requests))
        return {"status": "OK"}

    monkeypatch.setattr(robinhood_mcp, "_with_session", session)
    asyncio.run(
        robinhood_mcp.fetch_paper_monitor_quotes(
            [{"option_id": "held", "symbol": "QQQ", "tp_history_start": NOW.isoformat()}]
        )
    )
    assert calls == [("quote_refresh", [{"option_id": "held"}])]


def test_duplicate_monitor_process_is_fenced(tmp_path, monkeypatch, capsys):
    import sys

    from tools.runtime_lock import advisory_file_lock

    owner = tmp_path / "state/runtime/paper_fast_monitor.owner"
    monkeypatch.setattr(sys, "argv", ["monitor", "--project-root", str(tmp_path), "--once"])
    with advisory_file_lock(owner, timeout_seconds=0):
        assert fast.main() == 0
    assert json.loads(capsys.readouterr().out)["reason"] == "paper_monitor_already_running"
