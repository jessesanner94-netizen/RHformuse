import asyncio
import hashlib
import json
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import pytest

from research.entry_quality import replay_day as replay
from research.options_lab.event_tape import SessionTape
from tools.config import load_config

NOW = datetime(2026, 10, 22, 14, 0, tzinfo=UTC)
ROOT = Path(__file__).resolve().parents[1]


def quote(ask="1.58", at=None):
    return {"instrument_id": "contract", "bid_price": "1.55", "ask_price": ask,
            "updated_at": (at or NOW - timedelta(seconds=9)).isoformat()}


def observation(arm="baseline", ask="1.58", available=None, at=None):
    return {"arm": arm, "available_at": (available or NOW - timedelta(seconds=8)).isoformat(),
            "refresh": {"option_quotes": [{"quote": quote(ask, at)}]}}


def test_first_baseline_observed_quote_not_later_cheapest_or_future():
    cycle = {"final_quotes": [
        observation("news_reaction", "1.56", NOW - timedelta(seconds=5)),
        observation("baseline", "1.58"),
        observation("baseline", "1.57", NOW - timedelta(seconds=6)),
        observation("baseline", "0.01", NOW + timedelta(seconds=1)),
    ]}
    refresh, provenance = replay.recorded_entry_quotes(cycle, NOW)
    assert refresh["option_quotes"][0]["ask_price"] == "1.58"
    assert provenance[0]["arm"] == "baseline"
    assert len(refresh["option_quotes"]) == 1


def test_future_provider_quote_never_enters_replay():
    refresh, provenance = replay.recorded_entry_quotes({"final_quotes": [
        observation(at=NOW + timedelta(seconds=1))]}, NOW)
    assert refresh == {"option_quotes": []} and provenance == []


def test_jev_uses_actual_available_time_without_fabricating_asof():
    value = {"status": "OK", "scores": {"setup_quality": .6, "entry_timing_quality": .5,
             "escalate_to_luna": .4}, "available_at": (NOW - timedelta(seconds=10)).isoformat()}
    assert replay._recorded_jev(value, NOW) is value
    assert "as_of" not in value
    assert replay._recorded_jev({**value, "available_at": (
        NOW + timedelta(seconds=1)).isoformat()}, NOW) is None
    assert replay._recorded_jev({**value, "as_of": (
        NOW + timedelta(seconds=1)).isoformat()}, NOW) is None


def test_archived_candidate_freshness_without_inventing_underlying_timestamp():
    candidate = {"quote_is_fresh": True, "quote_updated_at": (
        NOW - timedelta(seconds=20)).isoformat()}
    valid, basis = replay._candidate_freshness(candidate, NOW)
    assert valid and basis == "archived_scanner_freshness_flag_and_actual_option_timestamp"
    assert "underlying_quote_updated_at" not in candidate
    assert not replay._candidate_freshness({**candidate, "underlying_quote_updated_at": (
        NOW + timedelta(seconds=1)).isoformat()}, NOW)[0]
    assert not replay._candidate_freshness({**candidate, "quote_is_fresh": False}, NOW)[0]


def tape_row(kind, available, payload):
    return {"schema_version": 1, "kind": kind, "source": "yahoo",
            "venue": "CONSOLIDATED_UNVERIFIED", "symbol": "SPY",
            "event_id": kind + available.isoformat(), "event_at": available.isoformat(),
            "received_at": available.isoformat(), "available_at": available.isoformat(),
            "payload": payload}


def test_sqlite_is_readonly_and_availability_fenced_gaps_preserved(tmp_path):
    source = tmp_path / "source"
    tape = SessionTape(source / "SESSION_TAPE.sqlite3")
    start = NOW - timedelta(minutes=2)
    tape.ingest([tape_row("gap", start, {"start_at": start.isoformat(), "end_at": None,
                                        "gap_key": "missing-bars"}),
        tape_row("bar", NOW + timedelta(seconds=10), {
            "start_at": (NOW - timedelta(minutes=1)).isoformat(), "end_at": NOW.isoformat(),
            "open": 600, "high": 602, "low": 599, "close": 601, "volume": 100})])
    before = hashlib.sha256(tape.path.read_bytes()).hexdigest()
    evidence = replay.ReadOnlyEvidence([source])
    visible = evidence.observations("SPY", NOW)
    assert len(visible) == 1 and visible[0]["kind"] == "gap"
    assert len(evidence.observations("SPY", NOW + timedelta(seconds=11))) == 2
    assert hashlib.sha256(tape.path.read_bytes()).hexdigest() == before
    assert not (source / "SESSION_TAPE.sqlite3-wal").exists()


def test_current_session_bars_only_and_zone_horizon_preserves_gap_revisions(tmp_path):
    source = tmp_path / "source"
    tape = SessionTape(source / "SESSION_TAPE.sqlite3")
    now = NOW + timedelta(hours=2)
    old_same_session = NOW - timedelta(minutes=10)
    prior_day = NOW - timedelta(days=1)
    def bar(start, identity):
        row = tape_row("bar", now, {
            "start_at": start.isoformat(), "end_at": (start + timedelta(minutes=1)).isoformat(),
            "open": 600, "high": 602, "low": 599, "close": 601, "volume": 100})
        row["event_at"] = row["payload"]["end_at"]
        row["event_id"] = identity
        return row
    # Yahoo prefetched prior-day bars can have today's received/session label.
    recent = now - timedelta(minutes=1)
    gap_start = NOW - timedelta(minutes=20)
    opened = tape_row("gap", gap_start, {"start_at": gap_start.isoformat(),
                                          "end_at": None, "gap_key": "opening"})
    closed = tape_row("gap", gap_start + timedelta(minutes=1), {
        "start_at": gap_start.isoformat(), "end_at": (gap_start + timedelta(minutes=1)).isoformat(),
        "gap_key": "opening"})
    tape.ingest([bar(prior_day, "yesterday"), bar(old_same_session, "old-session-bar"),
                 bar(recent, "recent"), opened, closed])
    full = replay.ReadOnlyEvidence([source]).observations("SPY", now)
    assert {r["event_id"] for r in full if r["kind"] == "bar"} == {
        "old-session-bar", "recent"}
    selected = replay._entry_rows(full, now)
    assert [r["event_id"] for r in selected if r["kind"] == "bar"] == ["recent"]
    assert len([r for r in selected if r["kind"] == "gap"]) == 2


def test_historical_news_health_requires_actual_review():
    assert replay.archived_news_health({}, NOW)["status"] == "UNAVAILABLE"
    cycle = {"results": {"combined": {"addition_reviews": [
        {"news": {"status": "ALLOW", "action": "NO_EVENT_ACTION"}}]}}}
    health = replay.archived_news_health(cycle, NOW)
    assert health["status"] == "OK"
    assert health["basis"] == "contemporaneous_archived_successful_news_review"


def test_replay_honors_configured_book_window_without_lookahead(tmp_path):
    from tests.test_book_ranking import snapshots
    source=tmp_path/"archive"
    tape=SessionTape(source/"SESSION_TAPE.sqlite3")
    old=NOW-timedelta(seconds=400)
    rows=[snapshots(now=old)[-1],snapshots(now=NOW+timedelta(seconds=1))[-1]]
    tape.ingest(rows)
    assert replay.ReadOnlyEvidence([source]).observations("SPY",NOW)==[]
    extended=replay.ReadOnlyEvidence([source],book_history_seconds=600)
    selected=extended.observations("SPY",NOW)
    assert len(selected)==1 and selected[0]["event_at"]==old.isoformat()


def test_sources_merge_chronologically_dedupe_and_filter_asof(tmp_path):
    sources = [tmp_path / "a", tmp_path / "b"]
    monitor = {"as_of": NOW.isoformat(), "quote_refresh": {
        "option_quotes": [quote()]}}
    future = {"as_of": (NOW + timedelta(minutes=1)).isoformat(), "discovery": {}}
    for source in sources:
        source.mkdir()
        (source / "MONITOR.jsonl").write_text(json.dumps(monitor) + "\n")
        (source / "OPPORTUNITIES.jsonl").write_text(json.dumps(future) + "\n")
    events, fingerprints = replay._load_events(sources, NOW.date(), NOW)
    assert len(events) == 1 and events[0][1] == "monitor"
    assert len(fingerprints) == 4


def isolated_experiment(tmp_path, monkeypatch):
    experiment = tmp_path / "experiment"
    experiment.mkdir()
    frozen = ROOT / "research/options_lab/experiments/live_baseline_20261019/CONFIG.md"
    (experiment / "CONFIG.md").write_bytes(frozen.read_bytes())
    (experiment / "MANIFEST.json").write_text("{}")
    config = load_config(experiment / "CONFIG.md")
    monkeypatch.setattr(replay, "load_experiment", lambda _: (config, {}))
    return experiment


def test_empty_archive_is_insufficient_fresh_single_account_and_isolated(tmp_path, monkeypatch):
    experiment = isolated_experiment(tmp_path, monkeypatch)
    original_run = replay._run
    config_sources = []
    async def capture_source(config, *args, **kwargs):
        config_sources.append(config.source)
        return await original_run(config, *args, **kwargs)
    monkeypatch.setattr(replay, "_run", capture_source)
    source = tmp_path / "archive"
    source.mkdir()
    (source / "MONITOR.jsonl").write_text("")
    report = replay.replay_recorded_day(experiment, [source], tmp_path / "output",
                                        date(2026, 10, 22), NOW)
    assert report["status"] == "INSUFFICIENT_DATA" and report["net_pnl"] is None
    assert report["accounts"] == 1 and report["starting_cash"] == 369
    assert report["performance"]["cash"] == 369
    assert report["orders_placed"] == report["model_calls"] == 0
    assert config_sources == [tmp_path / "output" / "CONFIG.md"]
    assert not (experiment / "state").exists()
    assert (source / "MONITOR.jsonl").read_text() == ""
    with pytest.raises(ValueError, match="isolated"):
        replay.replay_recorded_day(experiment, [source], source / "output", NOW.date(), NOW)


def test_missing_monitor_quote_is_not_interpolated_from_previous_quote(tmp_path, monkeypatch):
    experiment = isolated_experiment(tmp_path, monkeypatch)
    config = load_config(experiment / "CONFIG.md")
    run = tmp_path / "run"
    captures = []
    original = replay.manage_paper_positions
    def capture(refresh, *args, **kwargs):
        captures.append(refresh)
        return original(refresh, *args, **kwargs)
    monkeypatch.setattr(replay, "manage_paper_positions", capture)
    events = [(NOW, "monitor", {"quote_refresh": {"option_quotes": [quote()]}}, {}),
              (NOW + timedelta(seconds=10), "monitor", {"quote_refresh": {
                  "option_quotes": [], "error_type": "TimeoutError"}}, {})]
    asyncio.run(replay._run(config, run, events, replay.ReadOnlyEvidence([]), NOW.date()))
    assert len(captures[0]["option_quotes"]) == 1
    assert captures[1]["option_quotes"] == []


def test_frozen_forward_research_metadata_and_archive_verified(tmp_path, monkeypatch):
    experiment = isolated_experiment(tmp_path, monkeypatch)
    relative = "research/entry_quality/frozen.py"
    archived = experiment / "source" / relative
    archived.parent.mkdir(parents=True)
    archived.write_text("frozen source")
    hashes = {relative: hashlib.sha256(archived.read_bytes()).hexdigest()}
    monkeypatch.setattr(replay, "code_hashes", lambda: hashes)
    metadata = experiment / "forward" / "EXPERIMENT.json"
    metadata.parent.mkdir()
    metadata.write_text(json.dumps({"research_code_sha256": hashes, "policy": replay.POLICY}))
    source = tmp_path / "source"
    source.mkdir()
    report = replay.replay_recorded_day(experiment, [source], tmp_path / "output",
                                        NOW.date(), NOW)
    assert report["frozen_research_metadata_sha256"] == hashlib.sha256(
        metadata.read_bytes()).hexdigest()
    archived.write_text("changed archive")
    with pytest.raises(ValueError, match="archived research source changed"):
        replay.replay_recorded_day(experiment, [source], tmp_path / "bad-output", NOW.date(), NOW)
    assert not (tmp_path / "bad-output").exists()


@pytest.mark.parametrize("exit_kind", ["news", "depth"])
def test_opportunity_receives_current_account_after_research_exit(tmp_path, monkeypatch, exit_kind):
    experiment = isolated_experiment(tmp_path, monkeypatch)
    config = load_config(experiment / "CONFIG.md")
    run = tmp_path / "run"
    def held_monitor(refresh, config, **kwargs):
        state = replay.ensure_paper_portfolio(config, **kwargs)
        return {"portfolio": replay.paper_summary(state), "attention": [], "open_positions": [{
            "symbol": "SPY", "option_type": "CALL", "paper_id": "position",
            "contract_identifier": "contract"}]}
    monkeypatch.setattr(replay, "manage_paper_positions", held_monitor)
    monkeypatch.setattr(replay, "review_news", lambda *args: {
        "status": "BLOCK", "action": "EXIT_REVIEW"})
    monkeypatch.setattr(replay, "close_paper_position", lambda *args, **kwargs: {"closed": True})
    if exit_kind == "depth":
        monkeypatch.setattr(replay, "depth_exit_review", lambda *args, **kwargs: {
            "status": "OK", "action": "TAKE_PROFIT"})
        monkeypatch.setattr(replay, "close_depth_exit", lambda *args, **kwargs: {"closed": True})
        monkeypatch.setattr(replay, "review_news", lambda *args: (
            _ for _ in ()).throw(AssertionError("Already closed by depth exit")))
    captured = []
    async def opportunity(cycle, config, run, now, evidence, monitor, **kwargs):
        captured.append(monitor)
        return {"data_issues": []}
    monkeypatch.setattr(replay, "_opportunity", opportunity)
    cycle = {"final_quotes": [observation()]}
    asyncio.run(replay._run(config, run, [(NOW, "opportunity", cycle, {})],
                            replay.ReadOnlyEvidence([]), NOW.date()))
    assert len(captured) == 1
    assert captured[0]["open_positions"] == []
    assert captured[0]["portfolio"]["cash"] == 369


@pytest.mark.parametrize("book_kind", ["missing", "wall", "support"])
def test_replay_uses_book_ranking_without_a_book_fill_veto(tmp_path, book_kind):
    import shutil

    from tests.test_book_ranking import snapshots
    from tests.test_options_lab_forward import observation, row
    from tools.paper_trading import ensure_paper_portfolio, paper_summary

    run = tmp_path / "replay"
    run.mkdir()
    source = ROOT / "research/options_lab/experiments/depth_exits_20261023/CONFIG.md"
    shutil.copy2(source, run / "CONFIG.md")
    config = load_config(run / "CONFIG.md")
    frame = observation(NOW)
    frame["candidates"][0]["quote_is_fresh"] = True
    rows = []
    for offset in range(-6, 0):
        start = NOW + timedelta(minutes=offset)
        end = start + timedelta(minutes=1)
        rows.append(
            row(
                "bar",
                end,
                {
                    "start_at": start.isoformat(),
                    "end_at": end.isoformat(),
                    "open": 500,
                    "high": 500.1,
                    "low": 499.9,
                    "close": 500,
                    "volume": 1000,
                },
                identity="bar:" + end.isoformat(),
            )
        )
    if book_kind != "missing":
        rows += snapshots(
            1 if book_kind == "support" else 0,
            wall="CALL" if book_kind == "wall" else None,
            now=NOW,
        )

    class Evidence:
        def observations(self, symbol, now):
            return rows

    state = ensure_paper_portfolio(config, **replay._paths(run, config), now=NOW)
    cycle = {
        "discovery": {"qualified_candidates": frame["candidates"]},
        "technical": frame["technical"],
        "jev": frame["jev"],
        "economic_calendar": frame["economic_calendar"],
        "final_quotes": [
            {"arm": "paper", "available_at": NOW.isoformat(), "refresh": frame["quotes"]}
        ],
        "results": {
            "paper": {
                "addition_reviews": [{"news": {"status": "ALLOW", "action": "NO_EVENT_ACTION"}}]
            }
        },
    }
    cycle["jev"]["synthetic-spy"]["scores"] = {
        k: 0.0 for k in ["setup_quality", "entry_timing_quality", "escalate_to_luna"]
    }
    result = asyncio.run(
        replay._opportunity(
            cycle,
            config,
            run,
            NOW,
            Evidence(),
            {"portfolio": paper_summary(state), "open_positions": [], "attention": []},
        )
    )
    assert result["entry"]["opened"] is True, result["entry"]
    record = result["entry_ranking"]["candidates"]["synthetic-spy"]
    assert record["book_score"] == {"missing": 0, "wall": -1, "support": 4}[book_kind]
    assert record["selected"] and record["book_entry_veto"] is False
