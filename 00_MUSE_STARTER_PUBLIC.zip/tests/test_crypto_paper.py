"""ETH paper-account risk, fills, session gates, and completed-bar setup tests."""

from __future__ import annotations

import copy
import math
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from tools.config import load_config
from tools.crypto_paper import CryptoPaperStore
from tools.crypto_strategy import build_packet, crypto_window, technical

ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 9, 20, 12, 0, tzinfo=UTC)
BUY = {
    "action": "BUY",
    "symbol": "ETH-USD",
    "thesis": "Completed 5m and 15m continuation",
    "invalidation": "Stop at one percent below entry",
}


@pytest.fixture
def config() -> dict:
    # Copy the actual user-controlled defaults; each test can override its own copy.
    return dict(load_config(ROOT / "CONFIG.md").values)


def quote(now: datetime, *, bid: float = 100.0, ask: float = 100.1) -> dict:
    return {"bid": bid, "ask": ask, "updated_at": now.isoformat()}


def store(tmp_path: Path, config: dict) -> CryptoPaperStore:
    return CryptoPaperStore(tmp_path / "crypto-paper.sqlite3", config)


def buy(paper: CryptoPaperStore, now: datetime = NOW, *, bid: float = 100.0) -> dict:
    return paper.buy(
        quote(now, bid=bid, ask=bid + 0.1),
        BUY,
        now,
        deadline=now + timedelta(hours=4),
    )


def test_ask_entry_bid_exit_charges_adverse_slippage_and_both_fees(
    tmp_path: Path, config: dict
) -> None:
    paper = store(tmp_path, config)
    entry = buy(paper)
    assert entry["status"] == "PAPER_BUY"
    position = entry["position"]
    fee_rate = config["CRYPTO_PAPER_FEE_PERCENT_SIDE"] / 100
    slip = config["CRYPTO_PAPER_SLIPPAGE_BPS_SIDE"] / 10000
    expected_entry = 100.1 * (1 + slip)
    expected_qty = config["CRYPTO_MAX_POSITION_DOLLARS"] / expected_entry
    expected_cost = config["CRYPTO_MAX_POSITION_DOLLARS"] * (1 + fee_rate)
    assert position["entry"] == pytest.approx(expected_entry)
    assert position["quantity"] == pytest.approx(expected_qty)
    assert position["total_entry_cost"] == pytest.approx(expected_cost)
    assert paper.read()["cash"] == pytest.approx(
        config["CRYPTO_PAPER_STARTING_CASH"] - expected_cost
    )

    when = NOW + timedelta(minutes=2)
    result = paper.monitor(quote(when, bid=100.0, ask=100.1), when)
    assert result["status"] == "HOLD"
    deadline = NOW + timedelta(hours=4)
    exit_result = paper.monitor(quote(deadline, bid=100.0, ask=100.1), deadline)
    expected_fill = 100.0 * (1 - slip)
    expected_proceeds = expected_qty * expected_fill * (1 - fee_rate)
    assert exit_result["status"] == "PAPER_EXIT"
    assert exit_result["reason"] == "DEADLINE"
    assert exit_result["model_required"] is False
    assert exit_result["fill"] == pytest.approx(expected_fill)
    assert exit_result["fee"] == pytest.approx(expected_qty * expected_fill * fee_rate)
    assert exit_result["net_pnl"] == pytest.approx(expected_proceeds - expected_cost)
    assert exit_result["net_pnl"] < 0
    assert paper.read()["cash"] == pytest.approx(
        config["CRYPTO_PAPER_STARTING_CASH"] + exit_result["net_pnl"]
    )
    with sqlite3.connect(paper.path) as db:
        kinds = [row[0] for row in db.execute("SELECT kind FROM events ORDER BY id")]
    assert kinds == ["paper_entry", "paper_exit"]


@pytest.mark.parametrize(
    ("bid", "elapsed", "reason"),
    [(97.0, timedelta(minutes=1), "STOP"),
     (106.0, timedelta(minutes=1), "TARGET"),
     (100.0, timedelta(hours=4), "DEADLINE")],
)
def test_monitor_exits_without_model_call(
    tmp_path: Path, config: dict, bid: float, elapsed: timedelta, reason: str
) -> None:
    paper = store(tmp_path, config)
    assert buy(paper)["status"] == "PAPER_BUY"
    when = NOW + elapsed
    outcome = paper.monitor(quote(when, bid=bid, ask=bid + 0.1), when)
    assert outcome["status"] == "PAPER_EXIT"
    assert outcome["reason"] == reason
    assert outcome["model_required"] is False
    assert paper.read()["position"] is None


def test_eastern_rollover_keeps_prior_equity_as_gap_baseline(tmp_path: Path, config: dict) -> None:
    paper = store(tmp_path, config)
    before_midnight = datetime(2026, 9, 21, 3, 59, tzinfo=UTC)
    assert buy(paper, before_midnight)["status"] == "PAPER_BUY"
    prior_equity = paper.read()["last_equity"]

    after_midnight = before_midnight + timedelta(minutes=2)
    outcome = paper.monitor(quote(after_midnight, bid=99.5, ask=99.6), after_midnight)
    state = paper.read()
    assert outcome["status"] == "HOLD"
    assert state["day"]["date"] == "2026-09-21"
    assert state["day"]["start_equity"] == pytest.approx(prior_equity)
    assert state["last_equity"] < prior_equity
    assert state["day"]["entries"] == 0


def test_one_position_and_daily_entry_cap_are_enforced(tmp_path: Path, config: dict) -> None:
    config["CRYPTO_MAX_ENTRIES_PER_DAY"] = 1
    paper = store(tmp_path, config)
    assert buy(paper)["status"] == "PAPER_BUY"
    assert buy(paper)["reason"] == "position_already_open"

    exit_time = NOW + timedelta(minutes=1)
    assert paper.monitor(quote(exit_time, bid=97.0, ask=97.1), exit_time)["reason"] == "STOP"
    later = NOW + timedelta(minutes=2)
    assert buy(paper, later)["reason"] == "daily_entry_limit"
    assert paper.read()["day"]["entries"] == 1


def test_cash_and_planned_daily_loss_fail_closed(tmp_path: Path, config: dict) -> None:
    cash_config = dict(config, CRYPTO_PAPER_STARTING_CASH=50)
    cash_paper = CryptoPaperStore(tmp_path / "cash.sqlite3", cash_config)
    assert buy(cash_paper)["reason"] == "insufficient_paper_cash"
    assert cash_paper.read()["position"] is None

    loss_config = dict(config, CRYPTO_MAX_DAILY_LOSS_DOLLARS=0.1)
    loss_paper = CryptoPaperStore(tmp_path / "loss.sqlite3", loss_config)
    assert buy(loss_paper)["reason"] == "daily_planned_loss_limit"
    assert loss_paper.read()["position"] is None


def test_concurrent_buys_create_only_one_position_and_event(tmp_path: Path, config: dict) -> None:
    paper = store(tmp_path, config)
    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(lambda _: buy(paper), range(2)))

    assert sorted(outcome["status"] for outcome in outcomes) == ["BLOCKED", "PAPER_BUY"]
    assert next(outcome for outcome in outcomes if outcome["status"] == "BLOCKED")[
        "reason"
    ] == "position_already_open"
    assert paper.read()["day"]["entries"] == 1
    with sqlite3.connect(paper.path) as db:
        assert db.execute("SELECT COUNT(*) FROM events WHERE kind='paper_entry'").fetchone()[0] == 1


@pytest.mark.parametrize(
    "bad_quote",
    [
        {"bid": 100.0, "ask": 100.1, "updated_at": (NOW - timedelta(seconds=61)).isoformat()},
        {"bid": 100.0, "ask": 100.1, "updated_at": (NOW + timedelta(seconds=1)).isoformat()},
        {"bid": 101.0, "ask": 100.0, "updated_at": NOW.isoformat()},
        {"bid": math.nan, "ask": 100.1, "updated_at": NOW.isoformat()},
        {"bid": 100.0, "ask": math.inf, "updated_at": NOW.isoformat()},
        {"bid": True, "ask": 100.1, "updated_at": NOW.isoformat()},
    ],
)
def test_bad_quotes_cannot_mutate_paper_account(
    tmp_path: Path, config: dict, bad_quote: dict
) -> None:
    paper = store(tmp_path, config)
    with pytest.raises(ValueError):
        paper.buy(bad_quote, BUY, NOW, deadline=NOW + timedelta(hours=4))
    assert paper.read()["position"] is None
    with sqlite3.connect(paper.path) as db:
        assert db.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 0


def test_nyse_session_boundaries_weekend_holiday_and_early_close() -> None:
    friday_open = datetime(2026, 9, 18, 13, 30, tzinfo=UTC)
    friday_close = datetime(2026, 9, 18, 20, 0, tzinfo=UTC)
    before_open = crypto_window(friday_open - timedelta(seconds=1))
    assert before_open["entry_allowed"] is True
    assert before_open["admission_limit"] is None
    assert before_open["deadline"] == friday_open.isoformat()
    assert crypto_window(friday_open)["reason"] == "equity_session"
    assert crypto_window(friday_close)["entry_allowed"] is True
    assert crypto_window(friday_close + timedelta(seconds=1))["entry_allowed"] is True

    assert crypto_window(datetime(2026, 9, 20, 12, tzinfo=UTC))["entry_allowed"] is True
    assert crypto_window(datetime(2026, 9, 7, 14, tzinfo=UTC))["entry_allowed"] is True
    early_close = datetime(2026, 11, 27, 18, tzinfo=UTC)
    assert crypto_window(early_close - timedelta(seconds=1))["entry_allowed"] is False
    assert crypto_window(early_close)["entry_allowed"] is True
    assert crypto_window(early_close + timedelta(seconds=1))["entry_allowed"] is True


def candles(now: datetime, count: int = 63) -> list[dict]:
    first = now - timedelta(minutes=5 * count)
    rows = []
    for index in range(count):
        start = first + timedelta(minutes=5 * index)
        close = 100.0 + index * 0.1
        rows.append({
            "starts_at": start.isoformat(),
            "ends_at": (start + timedelta(minutes=5)).isoformat(),
            "open": close - 0.05,
            "high": close + 0.1,
            "low": close - 0.1,
            "close": close,
            "volume": 10.0,
        })
    return rows


def test_consecutive_five_and_fifteen_minute_continuation_qualifies_packet(
    tmp_path: Path, config: dict
) -> None:
    paper = store(tmp_path, config)
    snapshot = {
        "status": "OK",
        "symbol": "ETH-USD",
        "quote": quote(NOW, bid=106.2, ask=106.3),
        "candles_5m": candles(NOW),
    }
    risk = paper.entry_check(paper.read(), snapshot["quote"], NOW)
    packet = build_packet(
        snapshot, config, paper.read(), risk, {"entry_allowed": True}, NOW
    )
    assert packet["python_gate"] == {"status": "QUALIFIED", "reasons": []}
    assert packet["mode"] == "PAPER_ONLY"
    assert packet["candidate"]["asset_type"] == "SPOT_LONG"
    assert packet["execution"]["broker_order"] is False
    frames = packet["technical"]["timeframes"]
    assert frames["5M"]["trend"] == frames["15M"]["trend"] == "BULLISH"
    assert frames["15M"]["bars_count"] == 21


def test_technical_rejects_missing_gapped_and_unclosed_bars() -> None:
    with pytest.raises(ValueError, match="insufficient consecutive"):
        technical({"candles_5m": candles(NOW, count=62)}, NOW)

    gapped = copy.deepcopy(candles(NOW))
    for key in ("starts_at", "ends_at"):
        shifted = datetime.fromisoformat(gapped[30][key]) + timedelta(minutes=5)
        gapped[30][key] = shifted.isoformat()
    with pytest.raises(ValueError, match="candle gap"):
        technical({"candles_5m": gapped}, NOW)

    unclosed = copy.deepcopy(candles(NOW))
    unclosed[-1]["ends_at"] = (NOW + timedelta(minutes=5)).isoformat()
    with pytest.raises(ValueError, match="unclosed"):
        technical({"candles_5m": unclosed}, NOW)
