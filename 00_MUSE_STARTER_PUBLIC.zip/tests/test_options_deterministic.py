"""Offline cutover tests; all broker, JEV and model calls are synthetic."""

import asyncio
import json
from datetime import UTC, datetime, timedelta

import pytest

import tools.live_trading as live
import tools.scheduled_cycle as cycle
from tools.config import TradingConfig
from tools.options_strategy import ledger_directory
from tools.paper_runner import _paths
from tools.paper_trading import close_paper_position, ensure_paper_portfolio, open_paper_position

NOW = datetime(2026, 10, 9, 15, tzinfo=UTC)
EPOCH = "python_jev_green_lock_test"


@pytest.fixture(autouse=True)
def synthetic_monitor_health(monkeypatch):
    # These broker fixtures exercise entry/risk gates; actual monitor ownership and
    # heartbeat admission are verified independently in test_live_fast_monitor.
    monkeypatch.setattr("tools.live_fast_monitor.entry_monitor_ready", lambda *args: True)


def config(base, *, live_mode=False):
    return TradingConfig(
        {
            **base.values,
            "LIVE_EXECUTION_ENABLED": live_mode,
            "LIVE_NEW_ENTRIES_ENABLED": live_mode,
            "PAPER_TRADING_ENABLED": not live_mode,
            "OPTIONS_LUNA_VETO_ENABLED": False,
            "OPTIONS_JEV_RANKING_ONLY": True,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": False,
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": True,
            "OPTIONS_STRATEGY_EPOCH": EPOCH,
            "ENABLE_MULTI_WATCH": True,
            "PAPER_BASELINE_ENABLED": False,
            "PAPER_DAILY_GREEN_LOCK_ENABLED": False,
            "PAPER_FEE_PER_CONTRACT_SIDE_DOLLARS": 0.05,
            "PAPER_SLIPPAGE_PER_CONTRACT_SIDE_DOLLARS": 1.0,
            "MIN_NET_REWARD_TO_RISK": 1.0,
            "ENTRY_EXIT_COST_BUFFER_DOLLARS": 2.1,
            "MAX_DAILY_LOSS_DOLLARS": 45,
            "MAX_DAILY_LOSS_PERCENT": 12.5,
            "MAX_SINGLE_POSITION_PREMIUM_AT_RISK": 250,
            "MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT": 100,
            "MAX_NEW_POSITIONS_PER_DAY": 3,
            "ECONOMIC_CALENDAR_ENABLED": False,
        }
    )


def candidate(ask=1.1, symbol="SPY", now=NOW):
    return {
        "candidate_id": symbol + "-fixture",
        "symbol": symbol,
        "option_type": "CALL",
        "option_symbol": symbol + "-SYNTHETIC",
        "strike": 500.0,
        "expiration": "2026-10-23",
        "dte": 14,
        "underlying_price": 500.0,
        "bid": ask - 0.02,
        "ask": ask,
        "option_volume": 1000,
        "option_open_interest": 5000,
        "underlying_avg_daily_dollar_volume": 1e10,
        "quote_is_fresh": True,
        "quote_updated_at": now.isoformat(),
        "setup_qualified": True,
        "implied_volatility": 0.25,
        "delta": 0.5,
        "gamma": 0.002,
        "theta": -0.02,
        "vega": 0.1,
        "rho": 0.02,
        "event_review_complete": True,
        "contract_review_complete": True,
        "python_preferred_style": "DAY",
    }


def decision(symbol="SPY"):
    return {
        "action": "BUY",
        "candidate_id": symbol + "-fixture",
        "trade_style": "DAY",
        "thesis": "Synthetic setup",
        "invalidation": "Synthetic invalidation",
        "reason": "DETERMINISTIC_PYTHON_JEV_NO_LUNA_VETO",
        "holds_through_earnings": False,
    }


def routing(symbol="SPY", now=NOW):
    return {
        "decision": {
            "status": "COMPLETED",
            "model_bypassed": True,
            "output": json.dumps(decision(symbol)),
        },
        "decision_packet": {
            "as_of": now.isoformat(),
            "python_gate": {"status": "QUALIFIED"},
            "candidate": candidate(symbol=symbol, now=now),
        },
    }


def snapshot(now=NOW):
    return {
        "status": "OK",
        "as_of": now.isoformat(),
        "positions": [],
        "open_option_orders": [],
        "portfolio": {"total_value": "10000", "buying_power": {"buying_power": "10000"}},
    }


def refresh(ask=1.1, symbol="SPY", now=NOW):
    c = candidate(ask, symbol, now)
    return {
        "status": "OK",
        "as_of": now.isoformat(),
        "option_quotes": [
            {
                "instrument_id": c["candidate_id"],
                "bid_price": str(ask - 0.02),
                "ask_price": str(ask),
                "updated_at": now.isoformat(),
                "volume": 1000,
                "open_interest": 5000,
                **{
                    k: c[k]
                    for k in ("delta", "gamma", "theta", "vega", "rho", "implied_volatility")
                },
            }
        ],
        "equity_quotes": [
            {"symbol": symbol, "last_trade_price": "500", "venue_last_trade_time": now.isoformat()}
        ],
    }


async def review(request):
    return {"status": "REVIEWED", "result": {"data": {**request, "order_checks": {}}}}


def forbidden(*args, **kwargs):
    raise AssertionError("Forbidden model/cache/budget/broker operation")


@pytest.mark.parametrize("live_mode", [False, True])
def test_no_luna_entry_ignores_cache_watch_budget_and_uses_jev(
    tmp_path, monkeypatch, resolved_config, live_mode
):
    cfg = config(resolved_config, live_mode=live_mode)
    calls = []

    async def build(*args, **kwargs):
        if "SPY-fixture" in kwargs["excluded_candidate_ids"]:
            return {"status": "NO_CANDIDATE", "selected_candidates": []}
        return {
            "status": "READY",
            "packet": routing()["decision_packet"],
            "selected_candidates": [candidate()],
            "packet_signature": "synthetic",
        }

    def jev(*args, **kwargs):
        calls.append(kwargs)
        return {
            "status": "OK",
            "scores": {"setup_quality": 0.1, "entry_timing_quality": 0.1, "escalate_to_luna": 0.1},
        }

    monkeypatch.setattr(cycle, "build_decision_packet", build)
    monkeypatch.setattr(cycle, "evaluate_candidate", jev)
    for name in (
        "run_trigger",
        "cached_decision_blocks",
        "model_call_budget_status",
        "reserve_model_call",
        "active_watches",
    ):
        monkeypatch.setattr(cycle, name, forbidden)
    event = {
        "live_portfolio": {
            "positions": [],
            "pending_order_count": 0,
            "portfolio": {"open_position_count": 0},
        },
        "paper_portfolio": {"open_positions": [], "portfolio": {"open_positions": 0}},
    }
    result = asyncio.run(
        cycle._route_compact_decision(
            event, config=cfg, project_root=tmp_path, execute_models=True, now=NOW
        )
    )
    assert result["decision"]["status"] == "COMPLETED"
    assert result["decision"]["codex_invoked"] is False
    assert result["decision_verdict"]["action"] == "BUY"
    assert len(calls) == 1 and calls[0]["calls_remaining"] == 0
    assert not (tmp_path / "state/runtime/model_budget.json").exists()


def test_jev_failure_never_falls_back_to_python_only(tmp_path, monkeypatch, resolved_config):
    cfg = config(resolved_config)

    async def build(*args, **kwargs):
        return (
            {"status": "NO_CANDIDATE", "selected_candidates": []}
            if kwargs["excluded_candidate_ids"]
            else {
                "status": "READY",
                "packet": routing()["decision_packet"],
                "selected_candidates": [candidate()],
            }
        )

    monkeypatch.setattr(cycle, "build_decision_packet", build)
    monkeypatch.setattr(cycle, "evaluate_candidate", lambda *a, **k: {"status": "UNAVAILABLE"})
    monkeypatch.setattr(cycle, "run_trigger", forbidden)
    result = asyncio.run(
        cycle._route_compact_decision_impl(
            {"paper_portfolio": {"open_positions": [], "portfolio": {"open_positions": 0}}},
            config=cfg,
            project_root=tmp_path,
            execute_models=True,
            now=NOW,
        )
    )
    assert result["decision"]["reason"] == "jev_ranking_unavailable"


def test_no_luna_position_review_never_calls_models(tmp_path, monkeypatch, resolved_config):
    monkeypatch.setattr(cycle, "run_trigger", forbidden)
    monkeypatch.setattr(cycle, "reserve_model_call", forbidden)
    result = cycle._route_compact_position(
        {"wake_codex": True, "triggers": [{"code": "EVENT_RISK_CHANGED"}]},
        config=config(resolved_config),
        project_root=tmp_path,
        execute_models=True,
        now=NOW,
    )
    assert result["reason"] == "deterministic_position_monitor_no_luna"


def test_primary_lock_and_epoch_preserve_all_historical_ledgers(tmp_path, resolved_config):
    cfg = config(resolved_config)
    originals = []
    for name in ("paper", "paper_baseline", "daily_green_lock", "live"):
        p = tmp_path / "state" / name / "historical.json"
        p.parent.mkdir(parents=True)
        p.write_bytes(b"HISTORICAL")
        originals.append(p)
    p, e = _paths(tmp_path, config=cfg)
    paths = {"portfolio_path": p, "event_log_path": e}
    ensure_paper_portfolio(cfg, **paths, now=NOW)
    opened = open_paper_position(decision(), candidate(), cfg, **paths, now=NOW)
    assert opened["opened"] is True
    closed = close_paper_position(
        opened["position"]["paper_id"],
        bid=1.2,
        quote_updated_at=NOW.isoformat(),
        reason="TEST",
        config=cfg,
        **paths,
        now=NOW,
    )
    assert closed["position"]["realized_pnl"] == 7.9
    persisted = json.loads(p.read_text())
    assert persisted["day"]["green_lock_active"] is True
    assert persisted["day"]["realized_pnl_at_activation"] == 7.9
    blocked = open_paper_position(decision("QQQ"), candidate(symbol="QQQ"), cfg, **paths, now=NOW)
    assert blocked["reasons"] == ["daily_green_lock_active"]
    assert blocked["portfolio"]["day"]["skipped_entry_count"] == 1
    tomorrow = NOW + timedelta(days=3)  # next actual session, Monday
    rolled = ensure_paper_portfolio(cfg, **paths, now=tomorrow)
    assert rolled["day"]["green_lock_active"] is False
    assert rolled["day"]["realized_pnl"] == 0 and rolled["day"]["skipped_entry_count"] == 0
    assert all(p.read_bytes() == b"HISTORICAL" for p in originals)
    assert ledger_directory(tmp_path, cfg, "live") != p.parent


@pytest.mark.parametrize("ask,expected", [(0.5, "BLOCKED"), (0.84, "SUBMITTED")])
def test_live_ready_post_cost_gate_precedes_review(tmp_path, resolved_config, ask, expected):
    cfg = config(resolved_config, live_mode=True)
    calls = []

    async def place(request):
        calls.append(request)
        return {"status": "SUBMITTED", "result": {"data": {"id": "synthetic-order"}}}

    result = asyncio.run(
        live.apply_live_decision(
            routing(),
            {"option_discovery": {"qualified_candidates": [candidate()]}},
            cfg,
            project_root=tmp_path,
            now=NOW,
            quote_fetcher=lambda _: asyncio.sleep(0, result=refresh(ask)),
            snapshot_fetcher=(
                forbidden if expected == "BLOCKED" else lambda: asyncio.sleep(0, result=snapshot())
            ),
            reviewer=(forbidden if expected == "BLOCKED" else review),
            placer=place,
        )
    )
    assert result["status"] == expected
    assert result["net_reward_risk"]["net_reward_to_risk"] == (
        1.0 if ask == 0.84 else pytest.approx(12.9 / 14.6)
    )
    assert len(calls) == int(expected == "SUBMITTED")


@pytest.mark.parametrize(
    "exit_price,locked", [(1.01, False), (1.021, False), (1.03, True), (0.9, False)]
)
def test_live_ready_realized_cost_lock_and_reset(tmp_path, resolved_config, exit_price, locked):
    cfg = config(resolved_config, live_mode=True)
    directory = ledger_directory(tmp_path, cfg, "live")
    path = directory / "STATE.json"
    state = live._load_state(path, account_value=10000, now=NOW, config=cfg)
    pending = {
        "order_id": "synthetic-entry",
        "context": {
            "candidate": candidate(1.0),
            "decision": decision(),
            "hold_deadline": (NOW + timedelta(hours=3)).isoformat(),
            "entry_cost_estimate": 1.05,
            "exit_cost_estimate": 1.05,
            "strategy_epoch": EPOCH,
        },
    }
    pos = live._build_live_position(pending, fill_price=1.0, now=NOW, config=cfg)
    state["positions"] = [pos]
    state["pending_orders"] = [
        {
            "purpose": "EXIT",
            "order_id": "synthetic-exit",
            "context": {"position_id": pos["position_id"], "exit_reason": "TEST"},
        }
    ]
    live._save_state(path, state)
    result = asyncio.run(
        live.monitor_live_portfolio(
            cfg,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot()),
            reviewer=forbidden,
            placer=forbidden,
            order_status_fetcher=lambda _: asyncio.sleep(
                0,
                result={
                    "status": "OK",
                    "result": {"data": {"state": "filled", "average_price": str(exit_price)}},
                },
            ),
        )
    )
    assert result["status"] == "EXIT_FILLED"
    saved = json.loads(path.read_text())
    assert saved["day"]["green_lock_active"] is locked
    assert saved["day"]["realized_pnl"] == round((exit_price - 1) * 100 - 2.1, 2)
    if locked:
        blocked = asyncio.run(
            live.apply_live_decision(
                routing("QQQ"),
                {"option_discovery": {"qualified_candidates": [candidate(symbol="QQQ")]}},
                cfg,
                project_root=tmp_path,
                now=NOW,
                snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot()),
                quote_fetcher=lambda _: asyncio.sleep(0, result=refresh(symbol="QQQ")),
                reviewer=forbidden,
                placer=forbidden,
            )
        )
        assert blocked["reason"] == "daily_green_lock_active"
        saved = json.loads(path.read_text())
        assert saved["day"]["skipped_entry_count"] == 1
    rolled = live._load_state(path, account_value=10000, now=NOW + timedelta(days=3), config=cfg)
    assert rolled["day"]["green_lock_active"] is False
    assert rolled["day"]["realized_pnl"] == 0


def test_lock_stays_latched_after_later_loss_and_never_uses_unrealized(resolved_config, tmp_path):
    from tools.options_strategy import activate_green_lock

    cfg = config(resolved_config, live_mode=True)
    state = live._load_state(tmp_path / "STATE.json", account_value=10000, now=NOW, config=cfg)
    state["unrealized_pnl"] = 500
    assert activate_green_lock(state, now=NOW, strategy_variant=EPOCH) is None
    state["day"]["realized_pnl"] = 0.01
    assert activate_green_lock(state, now=NOW, strategy_variant=EPOCH)["daily_realized_pnl"] == 0.01
    state["day"]["realized_pnl"] = -10
    assert (
        activate_green_lock(state, now=NOW + timedelta(minutes=1), strategy_variant=EPOCH) is None
    )
    assert state["day"]["green_lock_active"] is True
    assert state["day"]["realized_pnl_at_activation"] == 0.01


def test_live_planned_loss_budget_includes_existing_exit_cost(resolved_config, tmp_path):
    from tools.portfolio_risk import evaluate_risk

    cfg = config(resolved_config, live_mode=True)
    cfg = TradingConfig({**cfg.values, "MAX_OPEN_POSITIONS": "UNLIMITED"})
    state = live._load_state(tmp_path / "STATE.json", account_value=10000, now=NOW, config=cfg)
    state["positions"] = [
        {
            "contract_identifier": "held",
            "symbol": "QQQ",
            "entry_price": 1.0,
            "quantity": 1,
            "last_bid": 0.96,
            "stop_price": 0.75,
            "exit_cost_estimate": 1.05,
        }
    ]
    account = live._portfolio_metrics(snapshot(), state)
    request = {
        "symbol": "SPY",
        "premium_at_risk": 84.0,
        "quantity": 1,
        "holds_through_earnings": False,
        "is_averaging_down": False,
        "protective_stop_planned": True,
    }
    assert evaluate_risk({**account, "open_stop_risk": 21.0}, request, cfg).status == "ALLOWED"
    assert evaluate_risk(account, request, cfg).status == "BLOCKED"
