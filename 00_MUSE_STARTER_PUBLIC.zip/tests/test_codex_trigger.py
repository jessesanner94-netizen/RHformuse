import subprocess
from pathlib import Path

from tools.codex_trigger import MODEL, REASONING_EFFORT, build_command, run_trigger


def test_quiet_monitor_never_invokes_runner(tmp_path: Path) -> None:
    def unexpected_runner(*args, **kwargs):
        raise AssertionError("runner should not be called")

    result = run_trigger(
        {"wake_codex": False, "triggers": []},
        project_root=tmp_path,
        execute=True,
        runner=unexpected_runner,
    )

    assert result["status"] == "SKIPPED"
    assert result["codex_invoked"] is False


def test_trigger_defaults_to_preview_without_invocation(tmp_path: Path) -> None:
    result = run_trigger(
        {"wake_codex": True, "triggers": [{"code": "STOP_LOSS_REACHED"}]},
        project_root=tmp_path,
    )

    assert result["status"] == "PREVIEW"
    assert result["codex_invoked"] is False
    assert result["model"] == MODEL
    assert result["reasoning_effort"] == REASONING_EFFORT


def test_command_pins_model_and_reasoning(tmp_path: Path) -> None:
    command = build_command("codex.cmd", tmp_path)

    assert command[:2] == ["codex.cmd", "exec"]
    assert MODEL in command
    assert f'model_reasoning_effort="{REASONING_EFFORT}"' in command
    assert "--approve-for-me" in command
    assert "--sandbox" not in command
    assert "mcp_servers.robinhood.enabled=false" in command


def test_scheduled_read_only_command_disables_robinhood_writes(tmp_path: Path) -> None:
    schema = tmp_path / "schema.json"
    schema.write_text("{}", encoding="utf-8")
    command = build_command(
        "codex.cmd",
        tmp_path,
        model="gpt-5.6-luna",
        reasoning_effort="low",
        sandbox="read-only",
        output_schema=schema,
    )

    assert "gpt-5.6-luna" in command
    assert "read-only" in command
    assert "mcp_servers.robinhood.enabled=false" in command
    assert "--approve-for-me" not in command
    assert str(schema.resolve()) in command


def test_trigger_invokes_codex_when_explicitly_enabled(tmp_path: Path, monkeypatch) -> None:
    prompt_dir = tmp_path / "prompts"
    prompt_dir.mkdir()
    (prompt_dir / "TRIGGERED_POSITION_REVIEW.md").write_text(
        "Review Unicode market text — Treasury ‘buybacks’.", encoding="utf-8"
    )
    monkeypatch.setattr("tools.codex_trigger.shutil.which", lambda name: "codex.cmd")
    calls = []

    def fake_runner(command, **kwargs):
        calls.append((command, kwargs))
        return subprocess.CompletedProcess(command, 0, stdout="WAIT\n", stderr="")

    result = run_trigger(
        {"wake_codex": True, "triggers": [{"code": "STOP_LOSS_REACHED"}]},
        project_root=tmp_path,
        execute=True,
        runner=fake_runner,
    )

    assert result["status"] == "COMPLETED"
    assert result["codex_invoked"] is True
    assert result["output"] == "WAIT"
    assert len(calls) == 1
    assert "STOP_LOSS_REACHED" in calls[0][1]["input"]
    assert "Treasury ‘buybacks’" in calls[0][1]["input"]
    assert calls[0][1]["encoding"] == "utf-8"
    assert calls[0][1]["errors"] == "replace"


def test_watch_transport_preserves_local_conditional_validation():
    import json

    from jsonschema import Draft202012Validator

    root = Path(__file__).resolve().parents[1]
    local = json.loads((root / "prompts/watch_decision.schema.json").read_text())
    transport = json.loads((root / "prompts/watch_decision.transport.schema.json").read_text())
    assert "allOf" not in transport
    assert {k: v for k, v in local.items() if k != "allOf"} == transport
    Draft202012Validator.check_schema(transport)
    # Conditional business validation stays in the local schema.
    conditional = {"allOf": local["allOf"]}
    assert not Draft202012Validator(conditional).is_valid(
        {"action": "WATCH", "watch_conditions": None}
    )
    assert not Draft202012Validator(conditional).is_valid({"action": "BUY", "watch_conditions": {}})


def test_watch_uses_transport_schema_and_classifies_api_failure(monkeypatch):
    root = Path(__file__).resolve().parents[1]
    monkeypatch.setattr("tools.codex_trigger.shutil.which", lambda name: "codex.cmd")

    def runner(command, **kwargs):
        assert str(root / "prompts/watch_decision.transport.schema.json") in command
        return subprocess.CompletedProcess(
            command, 1, stdout="", stderr="CLI banner invalid_json_schema"
        )

    result = run_trigger(
        {"wake_codex": True},
        project_root=root,
        execute=True,
        output_schema_name="watch_decision.schema.json",
        runner=runner,
    )
    assert result["reason"] == "invalid_json_schema"
    assert result["status"] == "ERROR"


def test_watch_runtime_validates_conditional_rules(monkeypatch):
    import json

    root = Path(__file__).resolve().parents[1]
    monkeypatch.setattr("tools.codex_trigger.shutil.which", lambda name: "codex.cmd")
    schema = json.loads((root / "prompts/watch_decision.schema.json").read_text())
    payload = {key: "" for key in schema["required"]}
    payload.update(
        action="PASS",
        candidate_id="test",
        trade_style="DAY",
        confidence=0.5,
        holds_through_earnings=False,
        reconsider_above=None,
        reconsider_below=None,
        decision_valid_until="2026-09-21T18:00:00Z",
        watch_conditions=None,
    )

    def runner(command, **kwargs):
        return subprocess.CompletedProcess(command, 0, stdout=json.dumps(payload), stderr="")

    def invoke():
        return run_trigger(
            {"wake_codex": True},
            project_root=root,
            execute=True,
            output_schema_name="watch_decision.schema.json",
            runner=runner,
        )

    assert invoke()["status"] == "COMPLETED"
    payload["action"] = "WATCH"
    assert invoke()["reason"] == "invalid_model_output"
    payload["watch_conditions"] = {
        "wake_all": [],
        "invalidate_any": [],
        "expires_at": "2026-09-21T18:00:00Z",
    }
    assert invoke()["status"] == "COMPLETED"
    payload["action"] = "BUY"
    assert invoke()["reason"] == "invalid_model_output"
