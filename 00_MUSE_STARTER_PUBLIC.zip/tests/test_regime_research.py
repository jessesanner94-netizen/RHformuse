from datetime import UTC, datetime, timedelta

import numpy as np
import pandas as pd
import pytest

from research.regime_backtest.evaluate import outcome
from research.regime_research.data import (
    FEATURES,
    aggregate,
    feature_row,
    path_outcome,
)
from research.regime_research.model import (
    eligible_training,
    metrics,
    predict_frame,
    strong_labels,
)
from research.regime_research.range_strategy import (
    available_candidate,
    candidate,
    simulate_path,
)
from research.regime_research.run import bar_mark_drawdown

OPEN = datetime(2026, 10, 12, 13, 30, tzinfo=UTC)


def bar(o=100, c=100, h=101, low=99, volume=100):
    return {"open": o, "close": c, "high": h, "low": low, "volume": volume}


def reclaim():
    base = [bar(c=100.2 if i % 2 == 0 else 99.8, h=102, low=98) for i in range(6)]
    return [*base, bar(o=98.2, c=98.5, h=99, low=97.9)]


@pytest.mark.parametrize("direction", [1, -1])
def test_symmetric_range_reclaim(direction):
    bars = reclaim()
    if direction == -1:
        bars = [
            {
                **b,
                "open": 200 - b["open"],
                "close": 200 - b["close"],
                "high": 200 - b["low"],
                "low": 200 - b["high"],
            }
            for b in bars
        ]
    signal = candidate(bars, 0.1)
    assert signal["direction"] == direction
    assert signal["underlying_reward_risk"] >= 1
    assert signal["status"] == "RESEARCH_CANDIDATE_ONLY"


def test_range_signal_has_availability_fence_and_requires_consecutive_bars():
    mapping = {OPEN + timedelta(minutes=5 * i): b for i, b in enumerate(reclaim())}
    at = OPEN + timedelta(minutes=35)
    assert available_candidate(mapping, OPEN, at, 0.1) is None
    signal = available_candidate(mapping, OPEN, at + timedelta(seconds=1), 0.1)
    assert signal
    mapping[OPEN + timedelta(minutes=40)] = bar(c=999, h=1000)
    assert available_candidate(mapping, OPEN, at + timedelta(seconds=1), 0.1) == signal
    del mapping[OPEN + timedelta(minutes=5)]
    assert available_candidate(mapping, OPEN, at + timedelta(seconds=1), 0.1) is None


@pytest.mark.parametrize("mean_range", [0, -1, np.nan])
def test_no_range_candidate_with_invalid_risk_buffer(mean_range):
    assert candidate(reclaim(), mean_range) is None


def test_ambiguous_bar_stop_first_and_gap_loss():
    signal = {"direction": 1, "stop": 99, "target": 102}
    mapping = {OPEN: bar(h=103, low=98)}
    result = simulate_path(signal, mapping, OPEN, OPEN + timedelta(hours=6))
    assert result["exit"] == 99
    assert result["reason"] == "AMBIGUOUS_STOP_FIRST"
    mapping = {
        OPEN: bar(h=100.2, low=99.5),
        OPEN + timedelta(minutes=5): bar(o=98, c=98, h=98.5, low=97),
    }
    result = simulate_path(signal, mapping, OPEN, OPEN + timedelta(hours=6))
    assert result["exit"] == 98
    assert result["gross_bps"] < -199


def test_replay_does_not_fill_through_a_data_gap_or_past_target():
    signal = {"direction": 1, "stop": 99, "target": 102}
    assert (
        simulate_path(signal, {OPEN: bar(h=100.2, low=99.5)}, OPEN, OPEN + timedelta(hours=6))
        is None
    )
    assert (
        simulate_path(
            signal, {OPEN: bar(o=103, c=103, h=104, low=102)}, OPEN, OPEN + timedelta(hours=6)
        )
        is None
    )


def test_five_minute_outcome_matches_original_one_minute_definition():
    bars = {}
    for i in range(60):
        p = 100 + i * 0.01
        bars[OPEN + timedelta(minutes=i)] = bar(o=p, c=p + 0.008, h=p + 0.015, low=p - 0.005)
    aggregated = aggregate(bars, OPEN, OPEN + timedelta(minutes=60))
    old = outcome(list(bars.values()))
    new = path_outcome(list(aggregated.values()))
    assert old["label"] == new["label"] == "TREND"
    assert new["r_squared"] == pytest.approx(old["r_squared"])
    del bars[OPEN + timedelta(minutes=3)]
    assert len(aggregate(bars, OPEN, OPEN + timedelta(minutes=60))) == 11


def test_features_ignore_future_and_use_previous_session_volume_only():
    days = [f"2026-09-{i:02}" for i in range(1, 23)]
    sessions, data = {}, {}
    for day in days:
        opened = datetime.fromisoformat(day + "T13:30:00+00:00")
        sessions[day] = (opened, opened + timedelta(minutes=60))
        for symbol in ("SPY", "QQQ"):
            data[day, symbol] = {opened + timedelta(minutes=5 * i): bar() for i in range(12)}
    day = days[-1]
    f, reason = feature_row(days, sessions, data, day, "SPY", "09:50:15")
    assert reason == "OK" and f["early_relative_volume"] == 1
    for symbol in ("SPY", "QQQ"):
        data[day, symbol][sessions[day][0] + timedelta(minutes=20)] = bar(
            o=1000, c=1100, h=1200, low=900, volume=99999
        )
    assert feature_row(days, sessions, data, day, "SPY", "09:50:15")[0] == f
    delayed, reason = feature_row(days, sessions, data, day, "SPY", "09:50:15", delay=60)
    assert reason == "OK" and delayed["early_relative_volume"] == 1
    del data[day, "SPY"][sessions[day][0] + timedelta(minutes=5)]
    assert feature_row(days, sessions, data, day, "SPY", "09:50:15")[0] is None


def test_train_split_keeps_current_year_and_both_symbols_out():
    frame = pd.DataFrame(
        [
            {
                "date": day,
                "symbol": symbol,
                "clock": "09:50:15",
                "target": "REMAINDER",
                "feature_status": "OK",
                "outcome": "TREND",
            }
            for day in ("2023-12-29", "2024-01-02")
            for symbol in ("SPY", "QQQ")
        ]
    )
    train = eligible_training(frame, 2024, "09:50:15", "REMAINDER")
    assert set(train.date) == {"2023-12-29"}
    assert len(train) == 2


def test_inference_rejects_training_overlap():
    bundle = {"trained_through": "2025-12-31"}
    with pytest.raises(ValueError, match="overlaps"):
        predict_frame(bundle, pd.DataFrame({"date": ["2025-12-31"]}))


def test_abstention_preserves_mixed_and_uncertain_probabilities():
    assert strong_labels(
        np.array([[0.49, 0.45, 0.06], [0.6, 0.3, 0.1], [0.1, 0.7, 0.2], [0.1, 0.1, 0.8]])
    ) == ["UNCERTAIN", "TREND", "CHOPPY", "UNCERTAIN"]


def test_probability_metrics_and_brier_class_order():
    frame = pd.DataFrame(
        {
            "date": ["2025-01-02"] * 3,
            "outcome": ["TREND", "CHOPPY", "MIXED"],
            "prediction": ["TREND", "CHOPPY", "MIXED"],
            "strong_signal": ["TREND", "CHOPPY", "UNCERTAIN"],
        }
    )
    for c in ("TREND", "CHOPPY", "MIXED"):
        frame["p_" + c] = np.where(frame.outcome == c, 0.8, 0.1)
        frame["baseline_" + c] = 1 / 3
    result = metrics(frame)
    assert result["brier"] == pytest.approx(0.06)
    assert result["log_loss"] == pytest.approx(-np.log(0.8))
    assert result["classes"]["TREND"]["recall"] == 1


def test_drawdown_includes_open_adverse_marks():
    trades = [
        {
            "entry_at": "2026-10-12T14:00:00+00:00",
            "exit_at": "2026-10-12T14:05:00+00:00",
            "gross_bps": 10,
            "marks": [{"at": "2026-10-12T14:00:00+00:00", "adverse_bps": -30, "close_bps": 10}],
        }
    ]
    assert bar_mark_drawdown(trades, 2) >= 31


def test_all_protocol_features_are_explicit_and_finite_by_construction():
    assert len(FEATURES) == len(set(FEATURES)) == 14
