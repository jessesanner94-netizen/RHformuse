import asyncio
from datetime import UTC, datetime
from pathlib import Path

from tools.market_movers import run_market_mover_discovery, select_market_movers


def _snapshot(now: datetime) -> dict[str, object]:
    return {
        "as_of": now.isoformat(),
        "items": {"items": [{"symbol": symbol} for symbol in ("AAA", "BBB", "CCC")]},
        "equity_quotes": [
            {"symbol": "AAA", "last_trade_price": "12", "previous_close": "10"},
            {"symbol": "BBB", "last_trade_price": "8", "previous_close": "10"},
            {"symbol": "CCC", "last_trade_price": "10.5", "previous_close": "10"},
        ],
        "equity_fundamentals": [
            {"symbol": symbol, "average_volume_30_days": "10000000"}
            for symbol in ("AAA", "BBB", "CCC")
        ],
    }


def test_market_movers_selects_liquid_gainers_and_losers(resolved_config) -> None:
    movers = select_market_movers(
        _snapshot(datetime(2026, 8, 24, 15, 0, tzinfo=UTC)), resolved_config
    )

    assert [item["symbol"] for item in movers] == ["AAA", "CCC", "BBB"]
    assert movers[0]["change_percent"] == 20.0
    assert movers[-1]["change_percent"] == -20.0


def test_market_movers_run_before_shared_contract_gate(tmp_path: Path, resolved_config) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)

    async def mover_fetcher():
        return _snapshot(now)

    async def resolver(symbols, config, **kwargs):
        assert symbols == ["AAA", "CCC", "BBB"]
        assert kwargs["discovery_source"] == "ROBINHOOD_DAILY_MOVERS"
        return {
            "status": "QUALIFIED",
            "qualified_candidates": [
                {
                    "candidate_id": "contract-aaa",
                    "symbol": "AAA",
                    "bid": 1.0,
                    "ask": 1.05,
                    "eligible_trade_styles": ["DAY", "SWING"],
                }
            ],
        }

    result = asyncio.run(
        run_market_mover_discovery(
            resolved_config,
            state_path=tmp_path / "movers.json",
            now=now,
            mover_fetcher=mover_fetcher,
            option_resolver=resolver,
        )
    )

    assert result["status"] == "QUALIFIED_CHANGED"
    assert result["wake_luna"] is True
    assert result["qualified_candidates"][0]["candidate_id"] == "contract-aaa"
