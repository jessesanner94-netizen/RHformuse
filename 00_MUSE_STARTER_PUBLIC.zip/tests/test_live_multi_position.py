from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from tools.config import TradingConfig
from tools.live_trading import _load_state, monitor_live_portfolio

NOW = datetime(2026, 8, 27, 14, 0, tzinfo=UTC)


def _config(resolved_config):
    return TradingConfig(
        {
            **resolved_config.values,
            "LIVE_EXECUTION_ENABLED": True,
            "PAPER_TRADING_ENABLED": False,
            "MAX_OPEN_POSITIONS": 3,
            "MAX_NEW_POSITIONS_PER_DAY": 3,
            "MAX_CONTRACTS_PER_POSITION": 1,
            "MAX_PORTFOLIO_PREMIUM_AT_RISK": 150,
            "MAX_SINGLE_POSITION_PERCENT_OF_ACCOUNT": 41,
        }
    )


def _position(contract):
    return {
        "position_id": f"position-{contract}",
        "contract_identifier": contract,
        "symbol": contract.upper(),
        "expiration": "2026-09-04",
        "strike": 100,
        "option_type": "CALL",
        "quantity": 1,
        "entry_price": 0.60,
        "entry_cost": 60,
        "last_bid": 0.60,
        "high_water_bid": 0.60,
        "stop_price": 0.45,
        "take_profit_price": 0.78,
        "trade_style": "DAY",
        "hold_deadline": "2026-08-27T19:45:00+00:00",
        "thesis": "fixture thesis",
        "status": "OPEN",
    }


def _state(root, *, positions, pending=()):
    path = root / "state" / "live" / "STATE.json"
    path.parent.mkdir(parents=True)
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "mode": "LIVE_UNATTENDED",
                "day": {"date": "2026-08-27", "start_equity": 369, "new_positions": len(positions)},
                "positions": positions,
                "pending_orders": list(pending),
                "realized_pnl": 0,
                "recent_closed_positions": [],
            }
        ),
        encoding="utf-8",
    )
    return path


def _snapshot(bids):
    return {
        "status": "OK",
        "as_of": NOW.isoformat(),
        "portfolio": {"total_value": "369", "buying_power": {"buying_power": "249"}},
        "positions": [{"option_id": contract, "quantity": "1"} for contract in bids],
        "open_option_orders": [],
        "option_quotes": [
            {"instrument_id": contract, "bid_price": str(bid), "updated_at": NOW.isoformat()}
            for contract, bid in bids.items()
        ],
    }


async def _review(request):
    return {"status": "REVIEWED", "result": {"data": {**request, "order_checks": {}}}}


@pytest.mark.parametrize("bad_positions", [None, {}, [None], [{"quantity": 1}]])
def test_malformed_live_positions_fail_closed(tmp_path, bad_positions):
    path = _state(tmp_path, positions=[])
    state = json.loads(path.read_text())
    state["positions"] = bad_positions
    path.write_text(json.dumps(state))
    with pytest.raises(ValueError, match="invalid live position records"):
        _load_state(path, account_value=369, now=NOW)


def test_two_stops_submit_two_distinct_persisted_exits(tmp_path: Path, resolved_config):
    path = _state(tmp_path, positions=[_position("a"), _position("b")])
    placed = []

    async def place(request):
        placed.append(request)
        return {"result": {"data": {"id": f"exit-{len(placed)}"}}}

    result = asyncio.run(
        monitor_live_portfolio(
            _config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot({"a": 0.40, "b": 0.42})),
            reviewer=_review,
            placer=place,
        )
    )

    assert result["orders_placed"] == 2
    assert {request["legs"][0]["option_id"] for request in placed} == {"a", "b"}
    state = json.loads(path.read_text())
    assert len(state["positions"]) == 2
    assert len(state["pending_orders"]) == 2
    assert {order["context"]["position_id"] for order in state["pending_orders"]} == {
        "position-a",
        "position-b",
    }

    async def filled(order_id):
        price = "0.40" if order_id == "exit-1" else "0.42"
        return {"result": {"data": {"orders": [{"state": "filled", "average_price": price}]}}}

    result = asyncio.run(
        monitor_live_portfolio(
            _config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot({})),
            order_status_fetcher=filled,
            reviewer=_review,
            placer=place,
        )
    )
    state = json.loads(path.read_text())
    assert result["orders_placed"] == 0
    assert state["positions"] == []
    assert state["pending_orders"] == []
    assert state["realized_pnl"] == -38
    assert len(state["recent_closed_positions"]) == 2


def test_pending_entry_does_not_block_existing_position_stop(tmp_path: Path, resolved_config):
    pending = {
        "purpose": "ENTRY",
        "order_id": "entry-c",
        "ref_id": "entry-ref",
        "request": {"legs": [{"option_id": "c", "side": "buy", "position_effect": "open"}]},
        "context": {"candidate": {"symbol": "C"}, "decision": {}},
    }
    path = _state(tmp_path, positions=[_position("a")], pending=[pending])
    placed = []

    async def place(request):
        placed.append(request)
        return {"result": {"data": {"id": "exit-a"}}}

    async def working(order_id):
        return {"result": {"data": {"orders": [{"state": "confirmed"}]}}}

    for _ in range(2):
        result = asyncio.run(
            monitor_live_portfolio(
                _config(resolved_config),
                project_root=tmp_path,
                now=NOW,
                snapshot_fetcher=lambda: asyncio.sleep(0, result=_snapshot({"a": 0.40})),
                order_status_fetcher=working,
                reviewer=_review,
                placer=place,
            )
        )
    assert len(placed) == 1
    assert placed[0]["legs"][0]["option_id"] == "a"
    assert len(json.loads(path.read_text())["pending_orders"]) == 2
    assert result["orders_placed"] == 0


def test_one_stale_quote_does_not_block_other_position_stop(tmp_path: Path, resolved_config):
    _state(tmp_path, positions=[_position("a"), _position("b")])
    snapshot = _snapshot({"a": 0.60, "b": 0.40})
    snapshot["option_quotes"][0]["updated_at"] = "2026-08-26T14:00:00+00:00"
    placed = []

    async def place(request):
        placed.append(request)
        return {"result": {"data": {"id": "exit-b"}}}

    result = asyncio.run(
        monitor_live_portfolio(
            _config(resolved_config),
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot),
            reviewer=_review,
            placer=place,
        )
    )
    assert result["orders_placed"] == 1
    assert result["wake_codex"] is True
    assert placed[0]["legs"][0]["option_id"] == "b"
