import asyncio
from datetime import timedelta

import pytest

from tests.test_crypto_cycle import dependencies, setup, snapshot
from tools.crypto_cycle import run_cycle
from tools.crypto_jev_trial import END, SLOTS, START, TRIAL_ID, active, sample_allowed, slot
from tools.crypto_paper import CryptoPaperStore
from tools.decision_context import reserve_model_call
from tools.jev_questions import market_questions


def fixture(tmp_path):
    config = setup(tmp_path, trial=True)
    store = CryptoPaperStore(tmp_path / "state/research/crypto_paper.sqlite3", config)
    jev = {
        "status": "OK",
        "routing_effect": True,
        "scores": {"setup_quality": 0.59, "escalate_to_luna": 0.8, "false_breakout_risk": 0.23},
        "policy": {"would_escalate": False, "thresholds": {"JEV_MAX_FALSE_BREAKOUT": 0.25}},
    }
    return config, store, jev


def test_trial_window_and_paper_lock(tmp_path):
    config, _, _ = fixture(tmp_path)
    assert not active(config, START - timedelta(seconds=1))
    assert active(config, START)
    assert not active(config, END)
    config.values["LIVE_EXECUTION_ENABLED"] = True
    assert not active(config, START)


def test_durable_per_coin_and_total_caps(tmp_path):
    config, store, jev = fixture(tmp_path)
    assert sample_allowed(config, START, jev, store)
    store.event("jev_trial_reserved", {"trial_id": TRIAL_ID, "slot": slot(START)}, START)
    assert not sample_allowed(config, START, jev, store)
    store.symbol = "BTC-USD"
    assert sample_allowed(config, START, jev, store)
    store.event("jev_trial_reserved", {"trial_id": TRIAL_ID, "slot": slot(START)}, START)
    assert not sample_allowed(config, START, jev, store)
    for index, (at, _, name, _) in enumerate(SLOTS[1:]):
        store.symbol = "BTC-USD" if index % 2 else "ETH-USD"
        assert sample_allowed(config, at, jev, store)
        store.event("jev_trial_reserved", {"trial_id": TRIAL_ID, "slot": name}, at)
        store.symbol = "ETH-USD" if index % 2 else "BTC-USD"
        assert not sample_allowed(config, at, jev, store)
    assert not sample_allowed(config, END - timedelta(seconds=1), jev, store)


@pytest.mark.parametrize("failure", ["error", "shadow", "missing", "risk"])
def test_no_error_or_risk_bypass(tmp_path, failure):
    config, store, jev = fixture(tmp_path)
    if failure == "error":
        jev["status"] = "ERROR"
    elif failure == "shadow":
        jev["routing_effect"] = False
    elif failure == "missing":
        del jev["scores"]["setup_quality"]
    else:
        jev["scores"]["false_breakout_risk"] = 0.26
    assert not sample_allowed(config, START, jev, store)


@pytest.mark.parametrize("blocked", [False, True])
@pytest.mark.parametrize("action", ["PASS", "BUY"])
def test_sample_routes_through_existing_budget_and_logs_decision(tmp_path, blocked, action):
    _, store, jev = fixture(tmp_path)
    calls, kwargs = dependencies(action=action)
    original_model = kwargs["model"]

    def blind_model(event, **kw):
        import json

        packet = event["decision_packet"]
        encoded = json.dumps(packet).lower()
        assert "jev" not in encoded
        assert "sampled_jev_rejection" not in encoded
        assert "technical" in packet and "python_gate" in packet
        return original_model(event, **kw)

    kwargs["model"] = blind_model

    async def fetcher(**kw):
        return snapshot(START)

    async def quote_fetcher(**kw):
        return snapshot(START)["quote"]

    kwargs.update(fetcher=fetcher, quote_fetcher=quote_fetcher, evaluator=lambda *a, **k: jev)
    if blocked:
        for i in range(20):
            reserve_model_call(
                tmp_path / "state/runtime/model_budget.json",
                maximum_calls=20,
                now=START,
                packet_signature=str(i),
            )
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=START, **kwargs))
    assert result["status"] == (
        "BUDGET_BLOCKED" if blocked else "PASS" if action == "PASS" else "PAPER_BUY"
    ), result
    assert calls["model"] == (0 if blocked else 1)
    with store.connect() as db:
        assert db.execute("SELECT count(*) FROM events WHERE kind='jev_trial_reserved'").fetchone()[
            0
        ] == (0 if blocked else 1)
    assert bool(store.read()["position"]) == (not blocked and action == "BUY")
    from tools.crypto_trial_report import report

    summary = report(store.path)
    assert summary["reviews_reserved"] == (0 if blocked else 1)
    if not blocked:
        assert summary["samples"][0]["luna_decision"]["action"] == action
        assert summary["samples"][0]["status"] == result["status"]
        assert summary["samples"][0]["net_pnl"] is None


def test_errors_log_code_location_without_secret_text(tmp_path):
    fixture(tmp_path)

    async def fail(**kwargs):
        raise ValueError("private-provider-response-do-not-log")

    result = asyncio.run(run_cycle(tmp_path, now=START, monitor_only=True, quote_fetcher=fail))
    assert result["error_code"] == "unclassified"
    assert any(":fail:" in frame for frame in result["error_location"])
    assert "private-provider-response" not in str(result)


def test_normal_jev_pass_is_also_blind_during_trial(tmp_path):
    _, store, jev = fixture(tmp_path)
    jev["policy"]["would_escalate"] = True
    calls, kwargs = dependencies(action="PASS")
    original_model = kwargs["model"]

    async def fetcher(**kw):
        return snapshot(START)

    async def quote_fetcher(**kw):
        return snapshot(START)["quote"]

    def model(event, **kw):
        import json

        assert "jev" not in json.dumps(event).lower()
        return original_model(event, **kw)

    kwargs.update(
        fetcher=fetcher, quote_fetcher=quote_fetcher, model=model, evaluator=lambda *a, **k: jev
    )
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=START, **kwargs))
    assert result["status"] == "PASS" and calls["model"] == 1
    with store.connect() as db:
        assert (
            db.execute("SELECT count(*) FROM events WHERE kind='jev_trial_reserved'").fetchone()[0]
            == 0
        )


@pytest.mark.parametrize("block", ["python", "cooldown", "expired"])
def test_sample_respects_existing_gates(tmp_path, block):
    _, store, jev = fixture(tmp_path)
    calls, kwargs = dependencies(action="PASS")
    now = END if block == "expired" else START

    async def fetcher(**kw):
        return snapshot(now, declining=block == "python")

    kwargs.update(fetcher=fetcher, evaluator=lambda *a, **k: jev)
    if block == "cooldown":
        store.update({"last_model_at": (START - timedelta(minutes=5)).isoformat()})
    result = asyncio.run(run_cycle(tmp_path, execute_models=True, now=now, **kwargs))
    assert result["status"] in {"PYTHON_REJECTED", "SKIPPED"}, result
    assert calls["model"] == 0


@pytest.mark.parametrize("asset", ["SPOT_LONG", "OPTION"])
def test_pipeline_question_scope(tmp_path, asset):
    from tests.test_jev_pipeline import FakeClient, packet
    from tools.jev_pipeline import evaluate_candidate

    config, _, _ = fixture(tmp_path)
    candidate = packet()
    candidate["candidate"].update(asset_type=asset, symbol="BTC-USD")

    class InspectClient(FakeClient):
        def evaluate(self, state, questions):
            corrected = "ambiguity is not required" in questions["escalate_to_luna"]["instructions"]
            assert corrected == (asset == "SPOT_LONG")
            return super().evaluate(state, questions)

    result = evaluate_candidate(
        candidate, config, project_root=tmp_path, now=START, client=InspectClient()
    )
    assert result["status"] == "OK", result


def test_question_change_is_opt_in():
    assert "ambiguity" in market_questions()["escalate_to_luna"]["instructions"]
    assert (
        "ambiguity is not required"
        in market_questions(crypto_review_trial=True)["escalate_to_luna"]["instructions"]
    )
