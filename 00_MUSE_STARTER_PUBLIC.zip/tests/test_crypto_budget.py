"""Equity and crypto decision calls share one persistent daily budget."""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import pytest

from tools.decision_context import model_budget_day, model_call_budget_status, reserve_model_call

NOW = datetime(2026, 9, 18, 14, 0, tzinfo=UTC)
MAXIMUM_CALLS = 20
EQUITY_RESERVE = 7


@pytest.mark.parametrize(
    "before,after",
    [
        ("2026-09-20T13:29:59+00:00", "2026-09-20T13:30:00+00:00"),
        ("2026-11-01T14:29:59+00:00", "2026-11-01T14:30:00+00:00"),
        ("2026-03-08T13:29:59+00:00", "2026-03-08T13:30:00+00:00"),
    ],
)
def test_daily_0930_reset_weekends_and_dst(tmp_path, before, after):
    path = tmp_path / "budget.json"
    earlier, boundary = datetime.fromisoformat(before), datetime.fromisoformat(after)
    assert model_budget_day(earlier) != model_budget_day(boundary)
    for i in range(20):
        assert (
            reserve_model_call(path, maximum_calls=20, now=earlier, packet_signature=str(i))[
                "status"
            ]
            == "RESERVED"
        )
    assert model_call_budget_status(path, maximum_calls=20, now=earlier)["status"] == "EXHAUSTED"
    assert model_call_budget_status(path, maximum_calls=20, now=boundary)["calls_remaining"] == 20
    assert (
        reserve_model_call(path, maximum_calls=20, now=boundary, packet_signature="new-window")[
            "calls_reserved"
        ]
        == 1
    )


def test_midnight_does_not_reset_calls(tmp_path):
    path = tmp_path / "budget.json"
    evening = datetime.fromisoformat("2026-09-20T23:59:00-04:00")
    overnight = datetime.fromisoformat("2026-09-21T00:01:00-04:00")
    reserve_model_call(path, maximum_calls=20, now=evening, packet_signature="late")
    assert model_call_budget_status(path, maximum_calls=20, now=overnight)["calls_remaining"] == 19


def test_crypto_reserve_preserves_equity_calls_until_admission_lifts(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"

    for index in range(EQUITY_RESERVE):
        result = reserve_model_call(
            budget,
            maximum_calls=MAXIMUM_CALLS,
            admission_limit=EQUITY_RESERVE,
            now=NOW,
            packet_signature=f"crypto-{index}",
        )
        assert result["status"] == "RESERVED"
        assert result["maximum_calls"] == MAXIMUM_CALLS

    blocked = reserve_model_call(
        budget,
        maximum_calls=MAXIMUM_CALLS,
        admission_limit=EQUITY_RESERVE,
        now=NOW,
        packet_signature="crypto-extra",
    )
    assert blocked["status"] == "BLOCKED"
    assert blocked["reason"] == "session_model_call_reserve"
    assert blocked["calls_reserved"] == EQUITY_RESERVE
    assert json.loads(budget.read_text(encoding="utf-8"))["maximum_calls"] == MAXIMUM_CALLS

    for index in range(MAXIMUM_CALLS - EQUITY_RESERVE):
        assert (
            reserve_model_call(
                budget,
                maximum_calls=MAXIMUM_CALLS,
                now=NOW,
                packet_signature=f"equity-{index}",
            )["status"]
            == "RESERVED"
        )

    exhausted = reserve_model_call(
        budget,
        maximum_calls=MAXIMUM_CALLS,
        admission_limit=EQUITY_RESERVE,
        now=NOW,
        packet_signature="beyond-total",
    )
    assert exhausted["status"] == "BLOCKED"
    assert exhausted["reason"] == "daily_model_call_budget_reached"
    assert exhausted["calls_reserved"] == MAXIMUM_CALLS
    assert (
        model_call_budget_status(budget, maximum_calls=MAXIMUM_CALLS, now=NOW)["status"]
        == "EXHAUSTED"
    )


def test_existing_thirteen_call_state_is_not_reset_by_increased_limit(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"
    budget.write_text(
        json.dumps({"date": "2026-09-18", "calls_reserved": 13, "maximum_calls": 13}),
        encoding="utf-8",
    )

    blocked = reserve_model_call(
        budget,
        maximum_calls=MAXIMUM_CALLS,
        admission_limit=EQUITY_RESERVE,
        now=NOW,
        packet_signature="crypto-after-equity",
    )
    assert blocked["reason"] == "session_model_call_reserve"
    assert json.loads(budget.read_text(encoding="utf-8"))["calls_reserved"] == 13

    equity = reserve_model_call(
        budget, maximum_calls=MAXIMUM_CALLS, now=NOW, packet_signature="equity-next"
    )
    assert equity["status"] == "RESERVED"
    assert equity["calls_reserved"] == 14
    assert json.loads(budget.read_text(encoding="utf-8"))["maximum_calls"] == MAXIMUM_CALLS


@pytest.mark.parametrize("admission_limit", [0, -1, 21, True, 7.0, "7"])
def test_invalid_admission_limit_fails_without_creating_state(
    tmp_path: Path, admission_limit: object
) -> None:
    budget = tmp_path / "model_budget.json"
    result = reserve_model_call(
        budget,
        maximum_calls=MAXIMUM_CALLS,
        admission_limit=admission_limit,
        now=NOW,
        packet_signature="invalid",
    )
    assert result == {"status": "BLOCKED", "reason": "invalid_model_call_admission_limit"}
    assert not budget.exists()


def test_malformed_state_fails_closed_with_admission_limit(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"
    budget.write_text('{"date":"2026-09-18","calls_reserved":21,"maximum_calls":20}')

    result = reserve_model_call(
        budget,
        maximum_calls=MAXIMUM_CALLS,
        admission_limit=EQUITY_RESERVE,
        now=NOW,
        packet_signature="malformed",
    )
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "model_budget_state_unreadable"
    assert json.loads(budget.read_text(encoding="utf-8"))["calls_reserved"] == 21


RESERVE_SCRIPT = """
import json
import sys
import time
from datetime import datetime
from pathlib import Path
import tools.decision_context as context

original_write = context.guarded_json_update
def delayed_write(*args, **kwargs):
    time.sleep(0.05)
    return original_write(*args, **kwargs)
context.guarded_json_update = delayed_write

result = context.reserve_model_call(
    Path(sys.argv[1]), maximum_calls=20, admission_limit=7,
    now=datetime.fromisoformat(sys.argv[2]), packet_signature=sys.argv[3],
)
print(json.dumps(result))
"""


def test_concurrent_crypto_reservations_obey_shared_admission_limit(tmp_path: Path) -> None:
    budget = tmp_path / "model_budget.json"
    processes = [
        subprocess.Popen(
            [sys.executable, "-c", RESERVE_SCRIPT, str(budget), NOW.isoformat(), f"crypto-{i}"],
            cwd=Path(__file__).resolve().parents[1],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        for i in range(10)
    ]
    results = []
    try:
        for process in processes:
            stdout, stderr = process.communicate(timeout=25)
            assert process.returncode == 0, stderr
            results.append(json.loads(stdout))
    finally:
        for process in processes:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)

    assert sum(result["status"] == "RESERVED" for result in results) == EQUITY_RESERVE
    assert [result["reason"] for result in results if result["status"] == "BLOCKED"] == [
        "session_model_call_reserve"
    ] * 3
    state = json.loads(budget.read_text(encoding="utf-8"))
    assert state["calls_reserved"] == EQUITY_RESERVE
    assert state["maximum_calls"] == MAXIMUM_CALLS
