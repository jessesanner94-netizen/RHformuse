"""Regime availability, baseline strategy parity and second-account isolation."""

import asyncio
import copy
import json
import socket
from datetime import UTC, date, datetime, timedelta

import pytest
from test_options_lab_forward import observation

from research.options_lab import forward
from research.volatility_paper import bot, regime, report
from tools.config import load_config
from tools.option_style import annotate_option_styles
from tools.options_lab import ROOT, SAFETY, _step, init_experiment

NOW = datetime(2026, 10, 22, 14, tzinfo=UTC)


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("external call forbidden in offline verification")

    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr("tools.scheduled_cycle.run_trigger", forbidden)
    monkeypatch.setattr("tools.economic_calendar.fetch_text", forbidden)


def bars(*, high=False, chop=False):
    result = []
    first = NOW - timedelta(minutes=21)
    last = 500.0
    for i in range(21):
        start = first + timedelta(minutes=i)
        end = start + timedelta(minutes=1)
        close = 500 + (0.1 if i % 2 else 0) if chop else 500 + i * 0.1
        width = 1.0 if high else 0.01
        result.append(
            {
                "schema_version": 1,
                "kind": "bar",
                "source": "yahoo",
                "venue": "CONSOLIDATED_UNVERIFIED",
                "symbol": "SPY",
                "event_id": str(i),
                "event_at": end.isoformat(),
                "received_at": end.isoformat(),
                "available_at": end.isoformat(),
                "payload": {
                    "start_at": start.isoformat(),
                    "end_at": end.isoformat(),
                    "open": last,
                    "high": max(last, close) + width,
                    "low": min(last, close) - width,
                    "close": close,
                    "volume": 10000,
                },
            }
        )
        last = close
    return result


@pytest.mark.parametrize(
    "high,chop,structure,volatility",
    [
        (False, False, "TREND", "NORMAL"),
        (False, True, "CHOPPY", "NORMAL"),
        (True, False, "TREND", "HIGH_VOLATILITY"),
        (True, True, "CHOPPY", "HIGH_VOLATILITY"),
    ],
)
def test_independent_structure_and_volatility_axes(high, chop, structure, volatility):
    label = regime.classify(bars(high=high, chop=chop), "SPY", NOW)
    assert label["status"] == "OK"
    assert (label["structure"], label["volatility"]) == (structure, volatility)
    assert label["trading_effect"] == "NONE"


def test_late_future_uncompleted_and_other_session_evidence_never_changes_label():
    rows = bars()
    expected = regime.classify(rows, "SPY", NOW)
    late = copy.deepcopy(rows[-1])
    late["available_at"] = (NOW + timedelta(seconds=1)).isoformat()
    late["payload"]["close"] = 900
    future = copy.deepcopy(late)
    future["event_at"] = (NOW + timedelta(minutes=1)).isoformat()
    assert regime.classify(rows + [late, future], "SPY", NOW) == expected
    assert regime.classify(rows[:-1] + [late], "SPY", NOW)["status"] == "UNKNOWN"
    assert regime.classify(rows, "SPY", NOW + timedelta(days=1))["status"] == "UNKNOWN"


@pytest.mark.parametrize(
    "damage,reason",
    [
        ("missing", "insufficient_completed_bars"),
        ("stale", "stale_completed_bars"),
        ("conflict", "invalid_or_conflicting_bar_evidence"),
        ("nan", "invalid_or_conflicting_bar_evidence"),
        ("gap", "open_feed_gap"),
    ],
)
def test_unknown_for_missing_stale_conflicting_and_gapped_data(damage, reason):
    rows, at = bars(), NOW
    if damage == "missing":
        rows.pop(5)
    elif damage == "stale":
        at += timedelta(minutes=3)
    elif damage == "conflict":
        other = copy.deepcopy(rows[-1])
        other["payload"]["high"] += 1
        rows.append(other)
    elif damage == "nan":
        rows[-1]["payload"]["high"] = float("nan")
    else:
        rows.append(
            {
                **rows[-1],
                "kind": "gap",
                "event_id": "gap",
                "payload": {
                    "start_at": (NOW - timedelta(seconds=20)).isoformat(),
                    "end_at": None,
                    "gap_key": "outage",
                    "reason": "timeout",
                },
            }
        )
    label = regime.classify(rows, "SPY", at)
    assert label["status"] == "UNKNOWN"
    assert label["reason"] == reason


@pytest.fixture
def paper(tmp_path, monkeypatch):
    lab = tmp_path / "lab"
    monkeypatch.setattr(forward, "LAB", lab)
    monkeypatch.setattr(bot, "init_experiment", lambda name: init_experiment(name, lab_root=lab))
    path = bot.prepare("baseline_labels", date(2026, 10, 22))
    result = bot.BaselinePaperBot(path, clock=lambda: NOW)
    return result


def test_strategy_parity_new_cash_and_distinct_paths(paper):
    production = load_config(ROOT / "CONFIG.md")
    assert {k: v for k, v in paper.config.values.items() if k not in SAFETY} == {
        k: v for k, v in production.values.items() if k not in SAFETY
    }
    assert paper.guards() == []
    state = paper.state("paper", NOW)
    assert state["cash"] == 369 and state["closed_trade_count"] == 0
    assert not state["open_positions"]
    assert paper.paths("paper")["portfolio_path"].is_relative_to(paper.experiment)
    assert paper.review("paper", "SPY", "CALL", NOW)["news"]["status"] == "DISABLED"
    assert paper.depth_review({}, {}, NOW)["action"] == "HOLD"


def wire(paper, monkeypatch, *, missing_jev=False, change_quote=False):
    sample = observation(NOW)
    sample["candidates"] = [
        annotate_option_styles({**candidate, "quote_is_fresh": True}, paper.config)
        for candidate in sample["candidates"]
    ]

    async def discovery(*args, **kwargs):
        return {"status": "OK", "wake_luna": True, "qualified_candidates": sample["candidates"]}

    async def books(*args, **kwargs):
        return {"status": "OK", "summaries": {}}

    async def quotes(requests):
        value = copy.deepcopy(sample["quotes"])
        if change_quote:
            value["option_quotes"][0]["ask_price"] = "2.50"
        return value

    original_route, original_apply = bot._route_compact_decision_impl, bot.apply_paper_decision

    async def route(*args, **kwargs):
        assert "candidate_priority" not in kwargs  # No RSI/book/regime reranking.
        return await original_route(*args, **kwargs, now=NOW)

    async def apply(*args, **kwargs):
        return await original_apply(*args, **kwargs, now=NOW)

    monkeypatch.setattr(bot, "run_watchlist_option_discovery", discovery)
    monkeypatch.setattr("tools.orderbook.collect_orderbooks", books)
    monkeypatch.setattr(bot, "load_calendar", lambda *args: sample["economic_calendar"])
    monkeypatch.setattr(bot, "collect_market_intelligence", lambda *a, **k: {})
    monkeypatch.setattr(bot, "fetch_vibe_snapshot", lambda *a, **k: sample["technical"]["SPY"])
    monkeypatch.setattr(
        bot,
        "evaluate_candidate",
        lambda *a, **k: (
            {"status": "UNAVAILABLE"} if missing_jev else sample["jev"]["synthetic-spy"]
        ),
    )
    monkeypatch.setattr(bot, "_route_compact_decision_impl", route)
    monkeypatch.setattr(bot, "apply_paper_decision", apply)
    paper.quotes = paper.fast_quotes = quotes
    return sample


@pytest.mark.parametrize("label", ["UNKNOWN", "CHOPPY", "TREND", "HIGH_VOLATILITY"])
def test_labels_never_veto_or_modify_actual_baseline_fills(paper, monkeypatch, label):
    wire(paper, monkeypatch)
    monkeypatch.setattr(
        paper,
        "regime",
        lambda symbol, now: {
            "regime": label,
            "structure": label,
            "volatility": label,
            "trading_effect": "NONE",
        },
    )
    result = asyncio.run(paper.opportunities())
    assert result["status"] == "OK", result
    state = paper.state("paper", NOW)
    position = state["open_positions"][0]
    assert state["cash"] == 257.95
    assert (
        position["quantity"],
        position["entry_price"],
        position["stop_price"],
        position["take_profit_price"],
    ) == (1, 1.1, 0.825, 1.43)
    attached = report.records(paper.directory / "TRADE_REGIMES.jsonl")
    assert attached[0]["label"]["regime"] == label


@pytest.mark.parametrize("missing_jev,change_quote", [(True, False), (False, True)])
def test_original_jev_and_final_risk_gates_still_reject(
    paper, monkeypatch, missing_jev, change_quote
):
    wire(paper, monkeypatch, missing_jev=missing_jev, change_quote=change_quote)
    asyncio.run(paper.opportunities())
    assert not paper.state("paper", NOW)["open_positions"]


def test_baseline_monitor_gap_fill_and_green_lock_without_research(paper, monkeypatch):
    sample = wire(paper, monkeypatch)
    asyncio.run(paper.opportunities())
    sample["quotes"]["option_quotes"][0]["bid_price"] = "1.50"
    sample["quotes"]["option_quotes"][0]["ask_price"] = "1.52"
    result = asyncio.run(paper.monitor())["paper"]["monitor"]
    assert not result["open_positions"]
    state = paper.state("paper", NOW)
    assert state["day"]["green_lock_active"]
    assert state["realized_pnl"] == 37.9
    assert asyncio.run(paper.opportunities())["reason"] == "paper_account_entry_risk_or_green_lock"


def test_tampering_blocks_entries_but_original_stop_still_executes(paper, monkeypatch):
    sample = observation(NOW)
    assert asyncio.run(_step(sample, paper.config, paper.roots["paper"]))["entry"]["opened"]
    (paper.roots["paper"] / "CONFIG.md").write_text("LIVE_EXECUTION_ENABLED: true\n")
    assert paper.guards()
    assert asyncio.run(paper.opportunities())["status"] == "BLOCKED"

    async def quotes(requests):
        result = copy.deepcopy(sample["quotes"])
        result["option_quotes"][0]["bid_price"] = "0.50"
        return result

    paper.fast_quotes = quotes
    result = asyncio.run(paper.monitor())["paper"]["monitor"]
    assert not result["open_positions"]
    assert paper.state("paper", NOW)["realized_pnl"] == -62.1


def test_reports_use_entry_labels_costs_and_keep_unknowns(tmp_path):
    events = tmp_path / "EVENTS.jsonl"
    rows = [
        {
            "event": "PAPER_EXIT",
            "paper_id": str(i),
            "symbol": "SPY",
            "timestamp": (NOW + timedelta(minutes=i)).isoformat(),
            "realized_pnl": pnl,
            "exit_reason": "SYNTHETIC",
        }
        for i, pnl in enumerate([10, -20, 5])
    ]
    events.write_text("".join(json.dumps(row) + "\n" for row in rows))
    (tmp_path / "TRADE_REGIMES.jsonl").write_text(
        json.dumps({"paper_id": "0", "label": {"regime": "CHOPPY"}}) + "\n"
    )
    result = report.metrics(tmp_path, events, {})
    assert result["paper"]["overall"] == {
        "trade_count": 3,
        "net_pnl": -5.0,
        "expectancy": -1.67,
        "win_rate": 2 / 3,
        "closed_trade_drawdown_dollars": 20.0,
    }
    assert result["paper"]["by_entry_regime"]["UNKNOWN"]["trade_count"] == 2
    assert result["paper"]["by_entry_regime"]["CHOPPY"]["net_pnl"] == 10


def test_missing_internal_minute_and_recovered_transport_gap():
    rows = bars()
    older = copy.deepcopy(rows[0])
    for field in ("event_at", "received_at", "available_at"):
        older[field] = (datetime.fromisoformat(older[field]) - timedelta(minutes=1)).isoformat()
    for field in ("start_at", "end_at"):
        older["payload"][field] = (
            datetime.fromisoformat(older["payload"][field]) - timedelta(minutes=1)
        ).isoformat()
    missing = [older, *rows[:5], *rows[6:]]
    assert regime.classify(missing, "SPY", NOW)["reason"] == "missing_minute_in_lookback"
    closed = {
        **rows[-1],
        "kind": "gap",
        "event_id": "recovered",
        "payload": {
            "start_at": (NOW - timedelta(minutes=2)).isoformat(),
            "end_at": NOW.isoformat(),
            "gap_key": "outage",
            "reason": "recovered",
        },
    }
    assert regime.classify([*rows, closed], "SPY", NOW)["status"] == "OK"


def test_zero_candidates_do_not_spend_jev_or_technical_calls(paper, monkeypatch):
    sample = observation(NOW)
    monkeypatch.setattr(bot, "load_calendar", lambda *args: sample["economic_calendar"])

    async def discovery(*args, **kwargs):
        return {"status": "ZERO_QUALIFIED", "wake_luna": False, "qualified_candidates": []}

    def forbidden(*args, **kwargs):
        raise AssertionError("zero-candidate run attempted research")

    monkeypatch.setattr(bot, "run_watchlist_option_discovery", discovery)
    monkeypatch.setattr(bot, "evaluate_candidate", forbidden)
    monkeypatch.setattr(bot, "fetch_vibe_snapshot", forbidden)
    monkeypatch.setattr(bot, "collect_market_intelligence", forbidden)
    assert asyncio.run(paper.opportunities())["reason"] == "zero_qualified_candidates"


def test_live_reference_filters_earlier_trades_and_uses_entry_availability(tmp_path, monkeypatch):
    source = load_config(ROOT / "CONFIG.md")
    path = report.ledger_directory(tmp_path, source, "live") / "EVENTS.jsonl"
    path.parent.mkdir(parents=True)
    rows = []
    for i in range(2):
        at = NOW + timedelta(minutes=i * 2)
        rows.extend(
            [
                {"event": "LIVE_ENTRY_FILLED", "symbol": "SPY", "timestamp": at.isoformat()},
                {
                    "event": "LIVE_EXIT_FILLED",
                    "symbol": "SPY",
                    "timestamp": (at + timedelta(minutes=1)).isoformat(),
                    "realized_pnl": 12.9,
                    "gross_realized_pnl": 15,
                },
            ]
        )
    path.write_text("".join(json.dumps(row) + "\n" for row in rows))
    monkeypatch.setattr(report, "ROOT", tmp_path)
    monkeypatch.setattr(report, "load_config", lambda *args: source)
    times = []

    def label(symbol, at):
        times.append(at)
        return {"regime": "UNKNOWN"}

    result = report.live_reference((NOW + timedelta(seconds=30)).isoformat(), label)
    assert result["overall"]["trade_count"] == 1
    assert result["overall"]["net_pnl"] == 12.9
    assert times == [NOW + timedelta(minutes=2)]
