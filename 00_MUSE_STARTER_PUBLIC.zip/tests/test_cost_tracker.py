from __future__ import annotations

from decimal import Decimal

from tools.cost_tracker import (
    CostRecord,
    append_record,
    compare_uw_decisions,
    read_ledger,
    summarize,
)


def test_cost_summary_calculates_policy_metrics() -> None:
    records = [
        {"category": "codex", "amount": "10.00"},
        {"category": "data", "amount": "5.00"},
    ]
    result = summarize(records, realized_net_trading_pnl="45.00")
    assert Decimal(result["economic_profit"]) == Decimal("30.00")
    assert Decimal(result["ai_data_efficiency_ratio"]) == Decimal("3")


def test_record_is_preview_only_without_commit(tmp_path) -> None:
    ledger = tmp_path / "ledger.jsonl"
    record = CostRecord.create(category="codex", amount="1.25", attribution="test")
    result = append_record(ledger, record)
    assert result["mode"] == "DRY_RUN"
    assert result["written"] is False
    assert not ledger.exists()


def test_committed_record_round_trips(tmp_path) -> None:
    ledger = tmp_path / "ledger.jsonl"
    record = CostRecord.create(category="api", amount="2.50", attribution="fixture")
    result = append_record(ledger, record, commit=True)
    assert result["written"] is True
    assert read_ledger(ledger)[0]["amount"] == "2.50"


def test_uw_attribution_reports_action_and_conviction_change() -> None:
    result = compare_uw_decisions(
        pre_action="wait", pre_conviction=0.4, post_action="pass", post_conviction=0.8
    )
    assert result["action_changed"] is True
    assert result["conviction_delta"] == 0.4
