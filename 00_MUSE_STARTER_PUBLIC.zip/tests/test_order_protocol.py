from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest
from jsonschema import Draft202012Validator
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData

from tools.config import TradingConfig
from tools.live_trading import (
    _default_state,
    _entry_order_request,
    _exit_order_request,
    _order_fill_price,
    _order_id,
    _review_and_submit,
    monitor_live_portfolio,
)
from tools.order_protocol import (
    OrderRequestRejected,
    exception_summary,
    placement_arguments,
    rejected_before_submission,
)
from tools.robinhood_mcp import _validated_order_call
from tools.windows_notify import notification_payload

NOW = datetime(2026, 8, 27, 16, 0, tzinfo=UTC)
# Properties/types/required/additionalProperties from the live Robinhood 2026-08-27 schema.
PLACE_SCHEMA = {
    "type": "object",
    "properties": {
        **{
            key: {"type": "string"}
            for key in (
                "account_number",
                "direction",
                "type",
                "quantity",
                "price",
                "stop_price",
                "time_in_force",
                "market_hours",
                "ref_id",
            )
        },
        "legs": {
            "type": ["array", "null"],
            "items": {
                "type": "object",
                "properties": {
                    **{key: {"type": "string"} for key in ("option_id", "side", "position_effect")},
                    "ratio_quantity": {"type": "integer"},
                },
                "required": ["option_id", "side", "position_effect"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["account_number", "legs", "quantity"],
    "additionalProperties": False,
}
REVIEW_SCHEMA = {
    **PLACE_SCHEMA,
    "properties": {
        **{key: value for key, value in PLACE_SCHEMA["properties"].items() if key != "ref_id"},
        "chain_symbol": {"type": "string"},
        "underlying_type": {"type": "string"},
    },
}


def request(purpose):
    if purpose == "ENTRY":
        return _entry_order_request({"candidate_id": "contract", "symbol": "PCG", "ask": 0.70})
    return _exit_order_request({"contract_identifier": "contract", "symbol": "PCG", "quantity": 1})


@pytest.mark.parametrize("purpose", ["ENTRY", "EXIT"])
def test_review_and_place_obey_distinct_real_schemas(tmp_path, purpose):
    reviewed, placed = [], []
    state = _default_state(account_value=369, now=NOW)

    async def review(payload):
        Draft202012Validator(REVIEW_SCHEMA).validate({"account_number": "fixture", **payload})
        reviewed.append(payload)
        return {"status": "REVIEWED", "result": {"data": {**payload, "order_checks": {}}}}

    async def place(payload):
        Draft202012Validator(PLACE_SCHEMA).validate({"account_number": "fixture", **payload})
        placed.append(payload)
        return {"result": {"data": {"order": {"id": "broker-order", "legs": [{"id": "leg"}]}}}}

    result = asyncio.run(
        _review_and_submit(
            request(purpose),
            state=state,
            state_path=tmp_path / "STATE.json",
            purpose=purpose,
            context={},
            now=NOW,
            reviewer=review,
            placer=place,
        )
    )
    assert result["status"] == "SUBMITTED"
    assert result["order_id"] == "broker-order"
    assert reviewed[0]["chain_symbol"] == "PCG"
    assert "chain_symbol" not in placed[0] and "underlying_type" not in placed[0]
    assert placed[0]["ref_id"] == state["pending_orders"][0]["ref_id"]
    assert placed[0]["legs"] == reviewed[0]["legs"]
    assert placed[0].get("price") == reviewed[0].get("price")


@pytest.mark.parametrize("extra", [None, "typo", "bad_leg"])
def test_adapter_validates_live_schema_before_wire(extra):
    sent = []

    async def list_tools():
        return SimpleNamespace(
            tools=[SimpleNamespace(name="place_option_order", inputSchema=PLACE_SCHEMA)]
        )

    async def call_tool(action, args):
        sent.append(args)
        return "ok"

    payload = {"account_number": "fixture", **request("ENTRY"), "ref_id": "same-reference"}
    if extra == "typo":
        payload["prcie"] = "0.70"
    if extra == "bad_leg":
        payload["legs"][0]["ratio_quantity"] = "1"
    run = _validated_order_call(
        SimpleNamespace(list_tools=list_tools, call_tool=call_tool), "place_option_order", payload
    )
    if extra:
        with pytest.raises(OrderRequestRejected):
            asyncio.run(run)
        assert sent == []
    else:
        assert asyncio.run(run) == "ok"
        assert sent[0] == placement_arguments(payload)
        assert payload["chain_symbol"] == "PCG"


@pytest.mark.parametrize("definite", [True, False])
def test_rejected_submission_archives_but_ambiguous_failure_is_never_replayed(
    tmp_path, resolved_config, definite
):
    state_path = tmp_path / "state/live/STATE.json"
    state = _default_state(account_value=369, now=NOW)
    calls = []
    cause = (
        McpError(ErrorData(code=-32602, message="invalid params: unexpected additional properties"))
        if definite
        else ConnectionError("connection lost after send")
    )
    failure = ExceptionGroup("outer", [ExceptionGroup("inner", [cause])])

    async def review(payload):
        return {"status": "REVIEWED", "result": {"data": {**payload, "order_checks": {}}}}

    async def place(payload):
        calls.append(payload)
        raise failure

    result = asyncio.run(
        _review_and_submit(
            request("ENTRY"),
            state=state,
            state_path=state_path,
            purpose="ENTRY",
            context={},
            now=NOW,
            reviewer=review,
            placer=place,
        )
    )
    assert rejected_before_submission(failure) is definite
    assert str(cause) in exception_summary(failure)
    stored = json.loads(state_path.read_text())
    if definite:
        assert result["submission_state"] == "NOT_SUBMITTED"
        assert stored["pending_orders"] == []
        assert stored["rejected_submissions"][0]["ref_id"] == calls[0]["ref_id"]
    else:
        assert result["submission_state"] == "UNKNOWN"
        assert stored["pending_orders"][0]["ref_id"] == calls[0]["ref_id"]
    config = TradingConfig(
        {
            **resolved_config.values,
            "LIVE_EXECUTION_ENABLED": True,
            "PAPER_TRADING_ENABLED": False,
        }
    )
    snapshot = {
        "status": "OK",
        "as_of": NOW.isoformat(),
        "portfolio": {"total_value": "369", "buying_power": {"buying_power": "369"}},
        "positions": [],
        "open_option_orders": [],
        "option_quotes": [],
    }
    monitored = asyncio.run(
        monitor_live_portfolio(
            config,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot),
            placer=place,
        )
    )
    assert len(calls) == 1
    assert monitored["status"] == ("QUIET" if definite else "ATTENTION"), monitored


def test_mixed_exception_group_is_not_definite_rejection():
    assert not rejected_before_submission(
        ExceptionGroup("mixed", [OrderRequestRejected("local"), TimeoutError("unknown")])
    )


def test_actual_leg_fill_price_wins_over_order_limit():
    order = {"price": "0.70", "legs": [{"executions": [{"price": "0.66", "quantity": "1"}]}]}
    assert _order_fill_price(order) == 0.66
    assert _order_fill_price({"price": "0.70"}) is None
    assert (
        _order_fill_price(
            {"processed_premium": "66", "processed_quantity": "1", "trade_value_multiplier": "100"}
        )
        == 0.66
    )
    assert _order_id({"result": {"data": {"legs": [{"id": "not-an-order-id"}]}}}) is None


def test_unknown_submission_alert_does_not_claim_no_order():
    notice = notification_payload(
        {
            "cycle": "opportunities",
            "live_decision": {
                "status": "ATTENTION",
                "submission_state": "UNKNOWN",
                "error": "connection lost",
            },
        }
    )
    assert "uncertain" in notice[1]
    assert "NO ORDER" not in notice[1]
