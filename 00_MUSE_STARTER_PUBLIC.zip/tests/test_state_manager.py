from __future__ import annotations

from tools.state_manager import guarded_json_update, parse_positions_markdown, reconcile_positions

POSITIONS = """\
# Open Position Memory

### SPY 2026-09-18 500 CALL
- Robinhood contract identifier: contract-1
- Quantity: 2
- Current status: OPEN
"""


def test_markdown_positions_reconcile_with_fresh_broker_snapshot() -> None:
    project = parse_positions_markdown(POSITIONS)
    result = reconcile_positions(
        project,
        {
            "snapshot_is_fresh": True,
            "positions": [{"contract_identifier": "contract-1", "quantity": 2}],
            "open_orders": [],
        },
    )
    assert result["status"] == "RECONCILED"
    assert result["matched"] == ["contract-1"]


def test_broker_memory_mismatch_blocks_reconciliation() -> None:
    result = reconcile_positions(
        [],
        {
            "snapshot_is_fresh": True,
            "positions": [{"contract_identifier": "contract-1", "quantity": 1}],
            "open_orders": [],
        },
    )
    assert result["status"] == "MISMATCH"
    assert "broker_position_missing_from_project_memory" in result["reasons"]


def test_stale_snapshot_fails_closed() -> None:
    result = reconcile_positions(
        [], {"snapshot_is_fresh": False, "positions": [], "open_orders": []}
    )
    assert result["status"] == "INSUFFICIENT_DATA"


def test_guarded_update_defaults_to_preview(tmp_path) -> None:
    target = tmp_path / "runtime.json"
    result = guarded_json_update(target, {"status": "dry"})
    assert result["status"] == "PREVIEW"
    assert result["written"] is False
    assert not target.exists()


def test_guarded_update_detects_hash_conflict(tmp_path) -> None:
    target = tmp_path / "runtime.json"
    target.write_text("{}\n", encoding="utf-8")
    result = guarded_json_update(target, {"status": "new"}, commit=True, expected_sha256="wrong")
    assert result["status"] == "CONFLICT"
    assert target.read_text(encoding="utf-8") == "{}\n"
