"""Deterministic arithmetic and point-in-time candle tests; no profitability claims."""

import copy
import json
import socket
from datetime import UTC, datetime, timedelta

import pytest

from research.entry_quality.rsi_divergence import classify_pair, divergence_review, rsi_values

START = datetime(2026, 10, 22, 14, tzinfo=UTC)
UP = [100, 101, 102, 101, 104, 102, 101, 102, 103, 102, 101]
DOWN = [200 - c for c in UP]


def at(minute):
    return START + timedelta(minutes=minute)


def candles(closes=UP, *, kind="high", first=120, second=121):
    result = []
    for i, close in enumerate(closes):
        high, low = 115, 85
        if kind == "high":
            high = first if i == 4 else second if i == 8 else high
        else:
            low = first if i == 4 else second if i == 8 else low
        stamp = at(i + 1).isoformat()
        result.append(
            {
                "schema_version": 1,
                "kind": "bar",
                "symbol": "SPY",
                "source": "yahoo",
                "venue": "CONSOLIDATED_UNVERIFIED",
                "event_id": f"bar-{i}",
                "event_at": stamp,
                "received_at": stamp,
                "available_at": stamp,
                "payload": {
                    "start_at": at(i).isoformat(),
                    "end_at": stamp,
                    "open": close,
                    "close": close,
                    "high": high,
                    "low": low,
                    "volume": 1000,
                },
            }
        )
    return result


def review(rows, minute=11, **kwargs):
    return divergence_review(
        rows, "SPY", at(minute), period=3, pivot_left=2, pivot_right=2, **kwargs
    )


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("RSI research attempted network access")

    monkeypatch.setattr(socket.socket, "connect", forbidden)


def test_wilder_arithmetic_and_warmup():
    values = rsi_values([10, 11, 12, 11, 13], 3)
    assert values[:3] == [None, None, None]
    assert values[3] == pytest.approx(100 * 2 / 3)
    assert values[4] == pytest.approx(100 * 10 / 12)
    classic = [
        44.34,
        44.09,
        44.15,
        43.61,
        44.33,
        44.83,
        45.10,
        45.42,
        45.84,
        46.08,
        45.89,
        46.03,
        45.61,
        46.28,
        46.28,
        46.00,
    ]
    assert rsi_values(classic)[14:] == pytest.approx([70.4641350211, 66.2496185536])
    assert rsi_values([10, 11], 3) == [None, None]


@pytest.mark.parametrize(
    "closes,expected", [([1] * 20, 50), (list(range(1, 21)), 100), (list(range(20, 0, -1)), 0)]
)
def test_flat_gain_and_loss_rsi_are_finite(closes, expected):
    values = rsi_values(closes)
    assert values[-1] == expected
    json.dumps(values, allow_nan=False)


@pytest.mark.parametrize(
    "kind,a,b,x,y,expected",
    [
        ("high", 100, 101, 70, 60, "regular_bearish"),
        ("low", 100, 99, 30, 40, "regular_bullish"),
        ("high", 100, 99, 60, 70, "hidden_bearish"),
        ("low", 100, 101, 40, 30, "hidden_bullish"),
        ("high", 100, 100, 70, 60, None),
        ("low", 100, 99, 30, 30, None),
    ],
)
def test_strict_pair_definitions(kind, a, b, x, y, expected):
    assert classify_pair(kind, a, b, x, y) == expected


@pytest.mark.parametrize(
    "closes,kind,first,second,label",
    [
        (UP, "high", 120, 121, "regular_bearish"),
        (DOWN, "high", 121, 120, "hidden_bearish"),
        (DOWN, "low", 80, 79, "regular_bullish"),
        (UP, "low", 79, 80, "hidden_bullish"),
    ],
)
def test_completed_candle_integration_for_all_four_divergences(closes, kind, first, second, label):
    rows = candles(closes, kind=kind, first=first, second=second)
    before = copy.deepcopy(rows)
    result = review(rows)
    assert result["status"] == "OK"
    assert len(result["latest_confirmed_divergences"]) == 1
    signal = result["latest_confirmed_divergences"][0]
    assert signal["kind"] == label
    assert signal["first_pivot"]["event_id"] == "bar-4"
    assert signal["second_pivot"]["event_id"] == "bar-8"
    assert signal["second_pivot"]["rsi_at_close"] == rsi_values(closes, 3)[8]
    assert signal["confirmed_at"] == at(11).isoformat()
    assert signal["available_at"] == at(11).isoformat()
    assert result["evidence"]["entry_gate"] is False
    assert rows == before
    json.dumps(result, allow_nan=False)


def test_right_confirmation_never_leaks_into_earlier_evaluation():
    rows = candles()
    assert review(rows, 10)["latest_confirmed_divergences"] == []
    rows[-1]["available_at"] = at(11.5).isoformat()
    assert review(rows, 11)["latest_confirmed_divergences"] == []
    signal = review(rows, 11.5)["latest_confirmed_divergences"][0]
    assert signal["available_at"] == at(11.5).isoformat()
    assert signal["signal_at"] > signal["second_pivot"]["bar_end_at"]


def test_late_indicator_history_delays_whole_signal_not_just_pivots():
    rows = candles()
    rows[1]["available_at"] = at(11.25).isoformat()
    assert review(rows, 11)["status"] == "UNAVAILABLE"  # hole in available history
    result = review(rows, 11.25)
    assert result["latest_confirmed_divergences"][0]["available_at"] == at(11.25).isoformat()


def test_future_event_fencing_and_old_pivot_does_not_refresh_on_late_receipt():
    rows = candles()
    rows[-1]["event_at"] = rows[-1]["received_at"] = rows[-1]["available_at"] = at(12).isoformat()
    assert review(rows, 11)["latest_confirmed_divergences"] == []
    assert review(rows, 12)["latest_confirmed_divergences"][0]["available_at"] == at(12).isoformat()
    assert review(rows, 12, max_pivot_age_seconds=60)["latest_confirmed_divergences"] == []


@pytest.mark.parametrize(
    "damage",
    [
        "missing_volume",
        "zero_volume",
        "nan_volume",
        "synthetic",
        "interpolated",
        "gap",
        "duration",
        "stale",
        "conflict",
    ],
)
def test_invalid_or_missing_evidence_fails_unavailable(damage):
    rows = candles()
    minute = 11
    if damage == "missing_volume":
        rows[0]["payload"]["volume"] = None
    elif damage == "zero_volume":
        rows[0]["payload"]["volume"] = 0
    elif damage == "nan_volume":
        rows[0]["payload"]["volume"] = float("nan")
    elif damage in {"synthetic", "interpolated"}:
        rows[0]["payload"][damage] = True
    elif damage == "gap":
        rows.pop(1)
    elif damage == "duration":
        rows[1]["payload"]["start_at"] = at(0.5).isoformat()
    elif damage == "stale":
        minute = 13
    else:
        duplicate = copy.deepcopy(rows[0])
        duplicate["payload"]["volume"] = 2000
        rows.append(duplicate)
    result = review(rows, minute)
    assert result["status"] == "UNAVAILABLE"
    assert result["latest_confirmed_divergences"] == []


def test_identical_duplicate_does_not_shift_signal_availability():
    rows = candles()
    duplicate = copy.deepcopy(rows[-1])
    duplicate["available_at"] = at(11.5).isoformat()
    rows += [duplicate]
    result = review(list(reversed(rows)), 11.5)
    assert result["latest_confirmed_divergences"][0]["available_at"] == at(11).isoformat()


def test_pinned_feed_same_session_and_warmup():
    rows = candles()
    for row in rows:
        row["venue"] = "OTHER"
    assert review(rows)["status"] == "UNAVAILABLE"
    assert review(candles()[:3], 3)["status"] == "UNAVAILABLE"
    assert review(candles(), 11 + 1440)["status"] == "UNAVAILABLE"


def test_closed_transport_gap_needs_observed_candle_reconstruction():
    rows = candles()
    gap = {
        **rows[-1],
        "kind": "gap",
        "event_id": "gap",
        "payload": {"gap_key": "g", "start_at": at(4).isoformat(), "end_at": at(5).isoformat()},
    }
    result = review(rows + [gap])
    assert result["status"] == "OK"
    assert result["evidence"]["reconstructed_closed_transport_gaps"] == 1
    assert review(rows[:4] + rows[5:] + [gap])["status"] == "UNAVAILABLE"
    gap["payload"]["end_at"] = None
    assert review(rows + [gap])["status"] == "UNAVAILABLE"
    gap["available_at"] = at(12).isoformat()
    assert review(rows + [gap])["status"] == "OK"


@pytest.mark.parametrize(
    "kwargs",
    [
        {"period": True},
        {"pivot_left": 0},
        {"pivot_right": 2.5},
        {"max_bar_age_seconds": float("inf")},
        {"max_pivot_age_seconds": -1},
    ],
)
def test_invalid_parameters_raise(kwargs):
    with pytest.raises(ValueError):
        divergence_review([], "SPY", at(11), **kwargs)


def test_naive_time_rejected():
    with pytest.raises(ValueError):
        divergence_review([], "SPY", at(11).replace(tzinfo=None))


def test_late_gap_recovery_is_part_of_signal_knowledge_time():
    rows = candles()
    gap = {
        **rows[-1],
        "kind": "gap",
        "event_id": "gap-open",
        "payload": {"gap_key": "g", "start_at": at(4).isoformat(), "end_at": None},
    }
    recovery = copy.deepcopy(gap)
    recovery["event_id"] = "gap-closed"
    recovery["available_at"] = at(11.5).isoformat()
    recovery["payload"]["end_at"] = at(5).isoformat()
    assert review(rows + [gap, recovery], 11)["status"] == "UNAVAILABLE"
    signal = review(rows + [gap, recovery], 11.5)["latest_confirmed_divergences"][0]
    assert signal["available_at"] == at(11.5).isoformat()
