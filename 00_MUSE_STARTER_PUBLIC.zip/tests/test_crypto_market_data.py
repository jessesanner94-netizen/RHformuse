from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta

from tools.crypto_market_data import SYMBOL, VENUE, fetch_quote, fetch_snapshot

NOW = datetime(2026, 9, 20, 12, 0, tzinfo=UTC)


def _candles(*, count: int = 63, gap: bool = False, include_current: bool = False):
    end = NOW if include_current else NOW - timedelta(seconds=300)
    rows = []
    for index in range(count):
        start = end - timedelta(seconds=300 * (count - index))
        if gap and index == 30:
            start += timedelta(seconds=300)
        rows.append([int(start.timestamp()), "99", "101", "100", "100.5", "2"])
    if include_current:
        rows.append(
            [int(NOW.timestamp()), "99", "101", "100", "100.5", "2"]
        )
    return list(reversed(rows))


def _responses(*, ticker_time: datetime = NOW, book_time: datetime | None = NOW, **kwargs):
    book = {
        "bids": [["100", "3", 1], ["99", "2", 1]],
        "asks": [["101", "4", 1], ["102", "2", 1]],
    }
    if book_time is not None:
        book["time"] = book_time.isoformat().replace("+00:00", "Z")
    return {
        "/ticker": {
            "bid": "100",
            "ask": "101",
            "price": "100.5",
            "time": ticker_time.isoformat().replace("+00:00", "Z"),
        },
        "/book?level=2": book,
        "/candles?granularity=300": _candles(**kwargs),
    }


def test_normalizes_fixed_public_snapshot_and_bounds_book_levels():
    responses = _responses()
    responses["/book?level=2"]["bids"] += [[str(98 - i), "1", 1] for i in range(55)]
    responses["/book?level=2"]["asks"] += [[str(103 + i), "1", 1] for i in range(55)]
    calls = []

    async def transport(url):
        calls.append(url)
        return next(value for suffix, value in responses.items() if url.endswith(suffix))

    result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "OK"
    assert result["venue"] == VENUE
    assert result["symbol"] == SYMBOL
    assert len(calls) == 3
    assert all(
        url.startswith("https://api.exchange.coinbase.com/products/ETH-USD/") for url in calls
    )
    assert result["quote"]["bid"] == 100.0
    assert result["quote"]["ask"] == 101.0
    assert result["quote"]["price"] == 100.5
    candle = result["candles_5m"][0]
    assert all(
        isinstance(candle[key], float) for key in ("open", "high", "low", "close", "volume")
    )
    assert result["quote"]["updated_at"] == "2026-09-20T12:00:00Z"
    assert result["book"]["timestamp_source"] == "exchange_time"
    assert len(result["book"]["bids"]) == len(result["book"]["asks"]) == 50
    assert len(result["candles_5m"]) == 63
    assert result["candles_5m"] == sorted(result["candles_5m"], key=lambda row: row["starts_at"])


def test_receipt_time_is_explicit_when_book_has_no_exchange_timestamp():
    responses = _responses(book_time=None)

    def transport(url):
        return next(value for suffix, value in responses.items() if url.endswith(suffix))

    result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "OK"
    assert result["book"]["updated_at"] == "2026-09-20T12:00:00Z"
    assert result["book"]["timestamp_source"] == "receipt_time"


def test_rejects_stale_quote_future_quote_crossed_book_and_nonfinite_values():
    cases = [
        _responses(ticker_time=NOW - timedelta(seconds=61)),
        _responses(ticker_time=NOW + timedelta(seconds=6)),
        _responses(),
        _responses(),
    ]
    cases[2]["/book?level=2"]["asks"][0][0] = "100"
    cases[3]["/candles?granularity=300"][0][5] = "nan"
    for responses in cases:
        def transport(url, response_map=responses):
            return next(value for suffix, value in response_map.items() if url.endswith(suffix))

        result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
        assert result["status"] == "UNAVAILABLE"
        assert result["quality"]["status"] == "UNAVAILABLE"


def test_ignores_incomplete_current_candle_and_rejects_insufficient_or_gapped_history():
    responses = _responses(include_current=True)

    def transport(url):
        return next(value for suffix, value in responses.items() if url.endswith(suffix))

    result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "OK"
    assert len(result["candles_5m"]) == 63

    for response_map in (_responses(count=62), _responses(gap=True)):
        def bad_transport(url, values=response_map):
            return next(value for suffix, value in values.items() if url.endswith(suffix))

        unavailable = asyncio.run(fetch_snapshot(now=NOW, transport=bad_transport))
        assert unavailable["status"] == "UNAVAILABLE"


def test_accepts_bounded_350_row_response_and_retains_latest_300_completed_candles():
    responses = _responses(count=350)

    def transport(url):
        return next(value for suffix, value in responses.items() if url.endswith(suffix))

    result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "OK"
    assert len(result["candles_5m"]) == 300
    assert result["candles_5m"][0]["ends_at"] == "2026-09-19T11:00:00Z"
    assert result["candles_5m"][-1]["ends_at"] == "2026-09-20T11:55:00Z"


def test_rejects_more_than_500_raw_candle_rows():
    responses = _responses(count=501)

    def transport(url):
        return next(value for suffix, value in responses.items() if url.endswith(suffix))

    result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "UNAVAILABLE"
    assert result["reason"] == "candles must contain at most 500 rows"


def test_provider_failure_is_fail_closed():
    async def transport(_url):
        raise OSError("offline")

    result = asyncio.run(fetch_snapshot(now=NOW, transport=transport))
    assert result["status"] == "UNAVAILABLE"
    assert result["reason"] == "provider_error:OSError"


def test_quote_refresh_makes_one_ticker_request_and_returns_only_normalized_quote():
    calls = []

    async def transport(url):
        calls.append(url)
        return {"bid": "100", "ask": "101", "price": "100.5", "time": "2026-09-20T12:00:00Z"}

    result = asyncio.run(fetch_quote(now=NOW, transport=transport))
    assert result == {
        "symbol": "ETH-USD",
        "bid": 100.0,
        "ask": 101.0,
        "price": 100.5,
        "updated_at": "2026-09-20T12:00:00Z",
    }
    assert calls == ["https://api.exchange.coinbase.com/products/ETH-USD/ticker"]


def test_quote_refresh_raises_sanitized_error_when_data_is_unusable():
    async def transport(_url):
        return {"bid": "100", "ask": "101", "price": "100.5", "time": "not-a-time"}

    try:
        asyncio.run(fetch_quote(now=NOW, transport=transport))
    except ValueError as exc:
        assert str(exc) == "quote_unavailable"
    else:
        raise AssertionError("invalid quote must not be returned")
