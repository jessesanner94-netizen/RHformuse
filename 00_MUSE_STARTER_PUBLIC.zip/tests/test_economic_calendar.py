from datetime import UTC, datetime

import pytest

from tools.config import TradingConfig
from tools.economic_calendar import economic_context, load_calendar, parse_bea, parse_bls_reader
from tools.market_calendar import entry_allowed


def test_fed_year_validation_and_dst():
    from tools.economic_calendar import parse_fed

    body = "2026 FOMC Meetings" + "".join(
        f'<div class="fomc-meeting__month"><strong>{month}</strong></div>'
        f'<div class="fomc-meeting__date">{days}</div>'
        for month, days in [("January", "27-28"), ("March", "17-18*"),
                            ("April", "28-29"), ("June", "16-17*"),
                            ("July", "28-29"), ("September", "15-16*"),
                            ("October", "27-28"), ("December", "8-9*")])
    rows = parse_fed(body, 2026)
    assert rows[0]["at"] == "2026-01-28T19:00:00+00:00"
    assert rows[5]["at"] == "2026-09-16T18:00:00+00:00"
    with pytest.raises(ValueError):
        parse_fed(body, 2027)


def config(base, tmp_path):
    return TradingConfig({**base.values, "ECONOMIC_CALENDAR_ENABLED": True,
                          "FOMC_BLACKOUT_MINUTES_BEFORE": 30,
                          "FOMC_BLACKOUT_MINUTES_AFTER": 60}, source=tmp_path / "CONFIG.md")


@pytest.mark.parametrize("clock,allowed", [
    ("17:29:59", True), ("17:30:00", False), ("18:06:32", False),
    ("18:30:00", False), ("19:00:00", False), ("19:00:01", True),
])
def test_fomc_entry_boundaries(monkeypatch, tmp_path, resolved_config, clock, allowed):
    monkeypatch.setattr("tools.economic_calendar.load_calendar", lambda *a: {
        "status": "OK", "events": [{"name": "FOMC", "kind": "FOMC",
        "at": "2026-09-16T18:00:00+00:00"}], "errors": [],
        "fetched_at": "2026-09-16T17:00:00+00:00", "coverage": "test"})
    now = datetime.fromisoformat("2026-09-16T" + clock + "+00:00")
    cfg = config(resolved_config, tmp_path)
    assert economic_context(now, cfg)["entry_allowed"] is allowed
    assert entry_allowed(now, cfg, "DAY") is allowed
    assert entry_allowed(now, cfg, "SWING") is allowed


def test_failure_cached_and_closed(tmp_path, resolved_config):
    calls = []

    def fail(url):
        calls.append(url)
        raise OSError("offline")

    now = datetime(2026, 9, 16, 18, tzinfo=UTC)
    result = load_calendar(now, tmp_path, fail)
    assert result["status"] == "UNAVAILABLE"
    assert len(calls) == 3
    assert load_calendar(now, tmp_path, fail) == result
    assert len(calls) == 3
    assert economic_context(now, config(resolved_config, tmp_path))["entry_allowed"] is False


def test_bls_dst_and_required_coverage():
    names = ("Consumer Price Index", "Producer Price Index", "Employment Situation")
    body = "\n".join(f"| Friday, November 6, 2026 | 08:30 AM | **{n}** |" for n in names)
    rows = parse_bls_reader(body, 2026, 11, "official")
    assert all(e["at"] == "2026-11-06T13:30:00+00:00" for e in rows)
    with pytest.raises(ValueError):
        parse_bls_reader("error page", 2026, 11, "official")


def test_bea_folded_title_and_invalid_time():
    body = ("BEGIN:VEVENT\nSUMMARY:Personal Income and Outlays\\, Sep\n tember 2026\n"
            "DTSTART:20261030T123000Z\nEND:VEVENT")
    rows = parse_bea(body)
    assert rows[0]["name"] == "Personal Income and Outlays, September 2026"
    with pytest.raises(ValueError):
        parse_bea(body.replace("20261030T123000Z", "20261030"))


def test_packet_blocks_before_technical_fetch(monkeypatch, tmp_path, resolved_config):
    import asyncio

    from tools.decision_context import build_decision_packet

    monkeypatch.setattr("tools.decision_context.economic_context", lambda *a, **k: {
        "status": "OK", "entry_allowed": False, "reason": "macro_event_blackout"})
    result = asyncio.run(build_decision_packet({}, resolved_config, project_root=tmp_path))
    assert result["packet"] is None
    assert result["reason"] == "macro_event_blackout"
