"""Offline broker lifecycle/recovery and resident monitor tests. Never real orders."""

import asyncio
import json
from datetime import UTC, datetime, timedelta

import httpx
import pytest

import tools.live_fast_monitor as fast
import tools.live_trading as live
from tools.config import TradingConfig
from tools.options_strategy import ledger_directory
from tools.runtime_lock import advisory_file_lock

NOW = datetime(2026, 10, 9, 15, tzinfo=UTC)


def config(base):
    return TradingConfig(
        {
            **base.values,
            "LIVE_EXECUTION_ENABLED": True,
            "PAPER_TRADING_ENABLED": False,
            "LIVE_FAST_MONITOR_ENABLED": True,
            "OPTIONS_LUNA_VETO_ENABLED": False,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": False,
            "OPTIONS_JEV_RANKING_ONLY": True,
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": True,
            "MIN_NET_REWARD_TO_RISK": 1.00,
        }
    )


def position():
    return {
        "position_id": "p-spy",
        "contract_identifier": "spy",
        "symbol": "SPY",
        "quantity": 1,
        "entry_price": 1.0,
        "entry_cost": 100,
        "last_bid": 1,
        "high_water_bid": 1,
        "stop_price": 0.75,
        "take_profit_price": 1.30,
        "trade_style": "DAY",
        "hold_deadline": (NOW + timedelta(minutes=45)).isoformat(),
        "status": "OPEN",
    }


def seed(root, cfg, *, positions=(), pending=()):
    path = ledger_directory(root, cfg, "live") / "STATE.json"
    state = live._default_state(account_value=369, now=NOW)
    state.update(positions=list(positions), pending_orders=list(pending))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state))
    return path


def snapshot(bid=None, stamp=NOW):
    return {
        "status": "OK",
        "as_of": NOW.isoformat(),
        "portfolio": {"total_value": "369", "buying_power": {"buying_power": "200"}},
        "positions": [] if bid is None else [{"option_id": "spy", "quantity": "1"}],
        "open_option_orders": [],
        "option_quotes": []
        if bid is None
        else [{"instrument_id": "spy", "bid_price": str(bid), "updated_at": stamp.isoformat()}],
    }


async def review(request):
    return {"status": "REVIEWED", "result": {"data": {**request, "order_checks": {}}}}


@pytest.fixture
def frozen_executor(monkeypatch):
    original = live.monitor_live_portfolio

    async def frozen(*args, **kwargs):
        return await original(*args, now=NOW, **kwargs)

    monkeypatch.setattr(fast, "monitor_live_portfolio", frozen)


def test_locked_execute_makes_no_broker_call(tmp_path, resolved_config):
    async def forbidden(*args):
        pytest.fail("disabled live execution reached broker")

    monitor = fast.LiveMonitor(
        tmp_path, execute=True, snapshot_fetcher=forbidden, reviewer=forbidden, placer=forbidden
    )
    assert asyncio.run(monitor.poll(resolved_config))["status"] == "DISABLED"


def test_default_read_only_cannot_submit_even_with_live_config(tmp_path, resolved_config):
    cfg = config(resolved_config)
    path = seed(tmp_path, cfg, positions=[position()])
    before = path.read_bytes()
    (tmp_path / "state/POSITIONS.md").write_text("# Open positions\n")

    async def forbidden(*args):
        pytest.fail("read-only monitor reached order interface")

    monitor = fast.LiveMonitor(
        tmp_path,
        snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot()),
        reviewer=forbidden,
        placer=forbidden,
        clock=lambda: NOW,
    )
    result = asyncio.run(monitor.poll(cfg))
    assert result["orders_placed"] == 0 and result["execution_enabled"] is False
    assert path.read_bytes() == before


@pytest.mark.parametrize("age,places", [(20, 1), (20.01, 0), (-2, 1), (-2.01, 0)])
def test_quote_age_boundaries_and_bid_stop(tmp_path, resolved_config, age, places):
    cfg = config(resolved_config)
    seed(tmp_path, cfg, positions=[position()])
    placed = []

    async def place(request):
        placed.append(request)
        return {"result": {"data": {"id": "exit-spy"}}}

    result = asyncio.run(
        live.monitor_live_portfolio(
            cfg,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(
                0, result=snapshot(0.70, NOW - timedelta(seconds=age))
            ),
            reviewer=review,
            placer=place,
        )
    )
    assert len(placed) == places
    assert result["orders_cancelled"] == 0


def test_timeout_after_send_survives_restart_without_duplicate_exit(
    tmp_path, resolved_config, frozen_executor
):
    cfg = config(resolved_config)
    path = seed(tmp_path, cfg, positions=[position()])
    placements = []

    async def uncertain(request):
        placements.append(request)
        raise TimeoutError("reply missing after send")

    async def read():
        return snapshot(0.70)

    for _ in range(2):
        monitor = fast.LiveMonitor(
            tmp_path,
            execute=True,
            snapshot_fetcher=read,
            reviewer=review,
            placer=uncertain,
            clock=lambda: NOW,
        )
        result = asyncio.run(monitor.poll(cfg))
        assert not result["entry_safe"]
    state = json.loads(path.read_text())
    assert len(placements) == 1
    assert state["pending_orders"][0]["status"] == "SUBMISSION_UNKNOWN"
    assert state["positions"][0]["position_id"] == "p-spy"


def test_429_backoff_reconnects_next_tick_without_immediate_retry(tmp_path, resolved_config):
    cfg = config(resolved_config)
    calls, tick = [], [0.0]

    async def read():
        calls.append(1)
        if len(calls) == 1:
            response = httpx.Response(
                429,
                headers={"Retry-After": "45"},
                request=httpx.Request("GET", "https://example.test"),
            )
            raise httpx.HTTPStatusError("limited", request=response.request, response=response)
        return snapshot()

    monitor = fast.LiveMonitor(
        tmp_path, snapshot_fetcher=read, clock=lambda: NOW, monotonic=lambda: tick[0]
    )
    (tmp_path / "state").mkdir()
    (tmp_path / "state/POSITIONS.md").write_text("# Positions\n")
    assert asyncio.run(monitor.poll(cfg))["retry_in_seconds"] == 45
    tick[0] = 10
    assert asyncio.run(monitor.poll(cfg))["reason"] == "live_broker_rate_limit"
    assert len(calls) == 1
    tick[0] = 45
    assert asyncio.run(monitor.poll(cfg))["orders_placed"] == 0
    assert len(calls) == 2


def test_overlapping_polls_never_overlap_requests(tmp_path, resolved_config):
    async def scenario():
        started, release = asyncio.Event(), asyncio.Event()

        async def read():
            started.set()
            await release.wait()
            return snapshot()

        monitor = fast.LiveMonitor(tmp_path, snapshot_fetcher=read, clock=lambda: NOW)
        first = asyncio.create_task(monitor.poll(config(resolved_config)))
        await started.wait()
        assert (await monitor.poll(config(resolved_config)))[
            "reason"
        ] == "live_monitor_poll_already_running"
        release.set()
        await first

    asyncio.run(scenario())


@pytest.mark.parametrize(
    "field,value",
    [
        ("execution_enabled", False),
        ("entry_safe", False),
        ("status", "ATTENTION"),
        ("strategy_epoch", "wrong"),
    ],
)
def test_entry_requires_healthy_executing_owner(tmp_path, resolved_config, field, value):
    cfg = config(resolved_config)
    runtime = tmp_path / "state/runtime"
    runtime.mkdir(parents=True)
    record = {
        "timestamp": NOW.isoformat(),
        "execution_enabled": True,
        "entry_safe": True,
        "status": "QUIET",
        "strategy_epoch": cfg.get("OPTIONS_STRATEGY_EPOCH"),
    }
    path = runtime / "live_fast_monitor.json"
    path.write_text(json.dumps(record))
    assert not fast.entry_monitor_ready(tmp_path, cfg, NOW)  # no resident owner
    with advisory_file_lock(runtime / "live_fast_monitor.owner", timeout_seconds=0):
        assert fast.entry_monitor_ready(tmp_path, cfg, NOW)
        assert not fast.entry_monitor_ready(tmp_path, cfg, NOW + timedelta(seconds=21))
        record[field] = value
        path.write_text(json.dumps(record))
        assert not fast.entry_monitor_ready(tmp_path, cfg, NOW)


@pytest.mark.parametrize(
    "order_state,qty,expected",
    [
        ("cancelled", 0, "ATTENTION"),
        ("filled", 0, "ATTENTION"),
        ("cancelled", 1, "ENTRY_FILLED"),
        ("partially_filled", 1, "ENTRY_FILLED"),
        ("partially_filled", 0.5, "ATTENTION"),
        ("partially_filled", None, "ATTENTION"),
    ],
)
def test_cancelled_or_partial_entry_never_discards_fill_evidence(
    tmp_path, resolved_config, order_state, qty, expected
):
    cfg = config(resolved_config)
    request = live._entry_order_request({"candidate_id": "spy", "symbol": "SPY", "ask": 1})
    pending = {
        "purpose": "ENTRY",
        "order_id": "entry",
        "ref_id": "reference",
        "request": request,
        "context": {
            "candidate": {"candidate_id": "spy", "symbol": "SPY"},
            "decision": {"trade_style": "DAY"},
            "hold_deadline": (NOW + timedelta(minutes=45)).isoformat(),
        },
    }
    path = seed(tmp_path, cfg, pending=[pending])
    order = {"state": order_state, "average_price": "1.00"}
    if qty is not None:
        order["processed_quantity"] = str(qty)
    result = asyncio.run(
        live.monitor_live_portfolio(
            cfg,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot(1.0) if qty else snapshot()),
            order_status_fetcher=lambda _: asyncio.sleep(0, result={"orders": [order]}),
        )
    )
    assert result["status"] == expected
    state = json.loads(path.read_text())
    if qty == 1:
        assert state["positions"][0]["entry_price"] == 1
        assert state["pending_orders"] == []
        # Reconciliation after process restart must not count the fill twice.
        asyncio.run(
            live.monitor_live_portfolio(
                cfg,
                project_root=tmp_path,
                now=NOW,
                snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot(1.0)),
            )
        )
        assert json.loads(path.read_text())["day"]["new_positions"] == 1
    elif qty != 0:
        assert len(state["pending_orders"]) == 1


def test_cancelled_placement_persists_uncertain_reference(tmp_path):
    state = live._default_state(account_value=369, now=NOW)

    async def cancelled(request):
        raise asyncio.CancelledError()

    with pytest.raises(asyncio.CancelledError):
        asyncio.run(
            live._review_and_submit(
                live._exit_order_request(position()),
                state=state,
                state_path=tmp_path / "STATE.json",
                purpose="EXIT",
                context={},
                now=NOW,
                reviewer=review,
                placer=cancelled,
            )
        )
    assert (
        json.loads((tmp_path / "STATE.json").read_text())["pending_orders"][0]["status"]
        == "SUBMISSION_UNKNOWN"
    )


def test_pretrade_state_expiring_during_review_never_submits(tmp_path):
    async def forbidden(request):
        pytest.fail("expired state reached placement")

    result = asyncio.run(
        live._review_and_submit(
            live._exit_order_request(position()),
            state=live._default_state(account_value=369, now=NOW),
            state_path=tmp_path / "STATE.json",
            purpose="EXIT",
            context={},
            now=NOW,
            reviewer=review,
            placer=forbidden,
            pre_submit_check=lambda: False,
        )
    )
    assert result["reason"] == "live_pre_submit_state_expired_or_changed"
    assert not (tmp_path / "STATE.json").exists()


def test_actual_read_timeout_is_bounded_and_next_poll_can_recover(tmp_path, resolved_config):
    calls = []

    async def slow():
        calls.append(1)
        await asyncio.Event().wait()

    cfg = TradingConfig(
        {**config(resolved_config).values, "LIVE_MONITOR_REQUEST_TIMEOUT_SECONDS": 1}
    )
    result = asyncio.run(fast.LiveMonitor(tmp_path, snapshot_fetcher=slow).poll(cfg))
    assert result["error_type"] == "TimeoutError"
    assert len(calls) == 1


@pytest.mark.parametrize("duration,expected", [(0, [10, 10]), (12, [0.1, 0.1])])
def test_resident_cadence_has_no_catchup_bursts(
    tmp_path, resolved_config, monkeypatch, duration, expected
):
    cfg = config(resolved_config)
    (tmp_path / "CONFIG.md").write_text(
        "\n".join(
            f"{k}: {str(v).lower() if isinstance(v, bool) else v}" for k, v in cfg.values.items()
        )
    )
    tick, polls, sleeps = [0.0], [], []
    monitor = fast.LiveMonitor(
        tmp_path, clock=lambda: NOW + timedelta(seconds=tick[0]), monotonic=lambda: tick[0]
    )

    async def poll(cfg):
        monitor.epoch = cfg.get("OPTIONS_STRATEGY_EPOCH")
        polls.append(tick[0])
        tick[0] += duration
        return {"status": "QUIET" if len(polls) < 3 else "DISABLED"}

    async def sleep(seconds):
        sleeps.append(seconds)
        tick[0] += seconds

    monkeypatch.setattr(monitor, "poll", poll)
    monkeypatch.setattr(fast.asyncio, "sleep", sleep)
    monkeypatch.setattr(fast, "market_window", lambda now: (True, "regular"))
    result = asyncio.run(fast.run(tmp_path, monitor=monitor))
    assert sleeps == expected
    assert all(b - a >= 10 for a, b in zip(polls, polls[1:], strict=False))
    assert result["entry_safe"] is False


def test_new_entry_switch_blocks_but_does_not_disable_management(tmp_path, resolved_config):
    cfg = TradingConfig({**config(resolved_config).values, "LIVE_NEW_ENTRIES_ENABLED": False})
    result = asyncio.run(
        live.apply_live_decision(
            {"decision": {"status": "COMPLETED", "output": json.dumps({"action": "BUY"})}},
            {},
            cfg,
            project_root=tmp_path,
            now=NOW,
        )
    )
    assert result["reason"] == "live_new_entries_locked"
    assert result["orders_placed"] == 0
    seed(tmp_path, cfg, positions=[position()])
    protected = asyncio.run(
        live.monitor_live_portfolio(
            cfg,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot(0.70)),
            reviewer=review,
            placer=lambda _: asyncio.sleep(0, result={"id": "protected-exit"}),
        )
    )
    assert protected["status"] == "SUBMITTED" and protected["orders_placed"] == 1


def test_open_entry_switch_still_requires_live_monitor(tmp_path, resolved_config):
    cfg = TradingConfig({**config(resolved_config).values, "LIVE_NEW_ENTRIES_ENABLED": True})
    result = asyncio.run(
        live.apply_live_decision(
            {"decision": {"status": "COMPLETED", "output": json.dumps({"action": "BUY"})}},
            {},
            cfg,
            project_root=tmp_path,
            now=NOW,
        )
    )
    assert result["reason"] == "live_position_monitor_not_ready"


@pytest.mark.parametrize("rows,next_page", [(None, None), ({}, None), ([None], None), ([], "more")])
def test_missing_or_incomplete_broker_state_cannot_mean_flat(rows, next_page):
    from tools.robinhood_mcp import _complete_snapshot_rows

    with pytest.raises(RuntimeError):
        _complete_snapshot_rows({"positions": rows, "next": next_page}, "positions")
    assert _complete_snapshot_rows({"positions": []}, "positions") == []


def test_unattended_authentication_failure_never_launches_browser(monkeypatch):
    from tools.robinhood_mcp import _authorization_required

    monkeypatch.setattr("webbrowser.open", lambda *args: pytest.fail("browser opened"))
    with pytest.raises(RuntimeError, match="robinhood_authorization_required"):
        asyncio.run(_authorization_required("https://example.test/login"))


def test_prior_day_exit_recovery_does_not_lock_the_new_day(tmp_path, resolved_config):
    cfg = config(resolved_config)
    path = seed(
        tmp_path,
        cfg,
        positions=[position()],
        pending=[
            {
                "purpose": "EXIT",
                "order_id": "prior-exit",
                "request": live._exit_order_request(position()),
                "context": {"position_id": "p-spy", "exit_reason": "TAKE_PROFIT"},
            }
        ],
    )
    order = {
        "state": "filled",
        "legs": [
            {
                "executions": [
                    {
                        "quantity": "1",
                        "price": "1.30",
                        "timestamp": (NOW - timedelta(days=1)).isoformat(),
                    }
                ]
            }
        ],
    }
    result = asyncio.run(
        live.monitor_live_portfolio(
            cfg,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot()),
            order_status_fetcher=lambda _: asyncio.sleep(0, result={"orders": [order]}),
        )
    )
    state = json.loads(path.read_text())
    assert state["realized_pnl"] == 30
    assert state["day"]["realized_pnl"] == 0
    assert not state["day"].get("green_lock_active", False)
    assert result["event"]["late_reconciliation"] is True


def test_working_entry_past_deadline_requests_manual_cancel_without_calling_cancel(
    tmp_path, resolved_config
):
    cfg = config(resolved_config)
    pending = {
        "purpose": "ENTRY",
        "order_id": "late",
        "request": {"quantity": "1"},
        "context": {
            "hold_deadline": (NOW - timedelta(seconds=1)).isoformat(),
            "candidate": {"symbol": "SPY"},
        },
    }
    seed(tmp_path, cfg, pending=[pending])
    result = asyncio.run(
        live.monitor_live_portfolio(
            cfg,
            project_root=tmp_path,
            now=NOW,
            snapshot_fetcher=lambda: asyncio.sleep(0, result=snapshot()),
            order_status_fetcher=lambda _: asyncio.sleep(
                0, result={"orders": [{"state": "confirmed"}]}
            ),
        )
    )
    assert result["manual_action"] == "CANCEL_ORDER"
    assert result["orders_cancelled"] == 0 and result["orders_placed"] == 0


def green_monitor(root, cfg):
    path = seed(root, cfg)
    state = json.loads(path.read_text())
    state["day"].update(green_lock_active=True, realized_pnl=10)
    state["strategy_epoch"] = cfg.get("OPTIONS_STRATEGY_EPOCH")
    path.write_text(json.dumps(state))
    calls, tick = [], [0.0]

    async def read():
        calls.append(tick[0])
        return snapshot()

    monitor = fast.LiveMonitor(
        root,
        execute=True,
        snapshot_fetcher=read,
        clock=lambda: NOW,
        monotonic=lambda: tick[0],
    )
    return monitor, calls, tick, path


def test_finished_day_skips_broker_but_reconciles_every_five_minutes(
    tmp_path, resolved_config, frozen_executor
):
    monitor, calls, tick, _ = green_monitor(tmp_path, config(resolved_config))
    first = asyncio.run(monitor.poll(config(resolved_config)))
    assert first["finished_reason"] == "daily_green_lock_active"
    assert first["entry_safe"] is False
    for moment in (10, 100, 299):
        tick[0] = moment
        result = asyncio.run(monitor.poll(config(resolved_config)))
        assert result["reason"] == "finished_for_day"
        assert result["broker_check_skipped"] and not result["entry_safe"]
    assert calls == [0]
    tick[0] = 300
    asyncio.run(monitor.poll(config(resolved_config)))
    assert calls == [0, 300]


@pytest.mark.parametrize("change", ["position", "pending", "corrupt", "day", "bad_day", "config"])
def test_quiet_mode_wakes_on_local_change(tmp_path, resolved_config, frozen_executor, change):
    cfg = config(resolved_config)
    monitor, calls, tick, path = green_monitor(tmp_path, cfg)
    asyncio.run(monitor.poll(cfg))
    state = json.loads(path.read_text())
    if change == "position":
        state["positions"] = [position()]
    elif change == "pending":
        state["pending_orders"] = [{"purpose": "ENTRY"}]
    elif change == "day":
        state["day"]["date"] = "2026-10-08"
    elif change == "bad_day":
        state["day"] = []
    elif change == "config":
        cfg = TradingConfig({**cfg.values, "OPTIONS_DAILY_GREEN_LOCK_ENABLED": False})
    path.write_text("invalid" if change == "corrupt" else json.dumps(state))
    tick[0] = 10
    asyncio.run(monitor.poll(cfg))
    assert calls == [0, 10]


def test_quiet_mode_wakes_at_eastern_date_rollover(tmp_path, resolved_config, frozen_executor):
    cfg = config(resolved_config)
    monitor, calls, tick, _ = green_monitor(tmp_path, cfg)
    asyncio.run(monitor.poll(cfg))
    monitor.clock = lambda: NOW + timedelta(days=1)
    tick[0] = 10
    asyncio.run(monitor.poll(cfg))
    assert calls == [0, 10]
    assert monitor.quiet_until == 0


def test_quiet_recheck_failure_restores_fast_polling(tmp_path, resolved_config, frozen_executor):
    cfg = config(resolved_config)
    monitor, calls, tick, _ = green_monitor(tmp_path, cfg)
    asyncio.run(monitor.poll(cfg))

    async def fail():
        calls.append(tick[0])
        raise TimeoutError()

    monitor.snapshot = fail
    tick[0] = 300
    result = asyncio.run(monitor.poll(cfg))
    assert result["error_type"] == "TimeoutError"
    assert result["failed_operation"] == "snapshot"
    tick[0] = 310
    asyncio.run(monitor.poll(cfg))
    assert calls == [0, 300, 310]


@pytest.mark.parametrize("field", ["positions", "open_option_orders"])
def test_untracked_broker_exposure_cannot_arm_quiet(
    tmp_path, resolved_config, frozen_executor, field
):
    cfg = config(resolved_config)
    monitor, _, _, _ = green_monitor(tmp_path, cfg)
    value = snapshot()
    value[field] = [{"option_id": "unknown", "quantity": "1"}]
    monitor.snapshot = lambda: asyncio.sleep(0, result=value)
    asyncio.run(monitor.poll(cfg))
    assert monitor.quiet_until == 0


def test_hard_loss_quiet_requires_both_realized_and_broker_loss(
    tmp_path, resolved_config, frozen_executor
):
    cfg = config(resolved_config)
    monitor, _, _, path = green_monitor(tmp_path, cfg)
    state = json.loads(path.read_text())
    state["day"].update(green_lock_active=False, realized_pnl=-45)
    path.write_text(json.dumps(state))
    asyncio.run(monitor.poll(cfg))
    assert monitor.quiet_until == 0  # Broker equity has not lost $45.
    value = snapshot()
    value["portfolio"]["total_value"] = "324"
    monitor.snapshot = lambda: asyncio.sleep(0, result=value)
    result = asyncio.run(monitor.poll(cfg))
    assert result["finished_reason"] == "daily_loss_limit_reached"
    assert not result["entry_safe"]


def test_flat_failure_streaks_cannot_bypass_thirty_minute_cooldown():
    notices = fast.FailureNotices()
    failure = {"reason": "live_monitor_request_failed", "exposure_present": False}
    assert notices.should_send(failure, 0)
    notices.sent(failure, 0)
    assert not notices.should_send({"status": "QUIET"}, 10)
    assert not notices.should_send(failure, 20)
    assert not notices.should_send(failure, 30)
    assert not notices.should_send(failure, 40)  # Still the same flat connection incident.
    assert not notices.should_send(failure, 50)
    assert not notices.should_send(failure, 640)
    assert notices.should_send(failure, 1800)


def test_repeated_recoveries_do_not_reset_flat_alert_cooldown():
    notices = fast.FailureNotices()
    failure = {"reason": "live_monitor_request_failed", "exposure_present": False}
    sent = []
    for now in range(0, 3601, 10):
        result = {"status": "QUIET"} if now % 40 == 30 else failure
        if notices.should_send(result, now):
            sent.append(now)
            notices.sent({**result, "sustained_failure": notices.failures >= 3}, now)
    assert sent == [0, 1800, 3600]


def test_exposure_sustained_escalation_survives_brief_recoveries():
    notices = fast.FailureNotices()
    failure = {"reason": "live_monitor_request_failed", "exposure_present": True}
    assert notices.should_send(failure, 0)
    notices.sent(failure, 0)
    assert not notices.should_send(failure, 10)
    assert notices.should_send(failure, 20)
    notices.sent({**failure, "sustained_failure": True}, 20)
    assert not notices.should_send({"status": "MONITORED"}, 30)
    for now in (40, 50, 60, 70, 619):
        assert not notices.should_send(failure, now)
    assert notices.should_send(failure, 620)


def test_new_exposure_escalates_without_waiting_for_notification_cooldown():
    notices = fast.FailureNotices()
    assert notices.should_send(
        {"reason": "live_monitor_request_failed", "exposure_present": False}, 0
    )
    notices.sent({"exposure_present": False}, 0)
    assert notices.should_send({"reason": "live_monitor_request_failed"}, 10)


def test_publish_retains_safe_failure_diagnostics(tmp_path):
    monitor = fast.LiveMonitor(tmp_path, clock=lambda: NOW, monotonic=lambda: 0)
    result = {
        "status": "ATTENTION",
        "reason": "live_monitor_request_failed",
        "error_type": "TimeoutError",
        "failed_operation": "snapshot",
    }
    record = fast.publish(
        tmp_path, result, monitor=monitor, started=NOW, tick=0, previous=None, interval=10
    )
    assert record["error_type"] == "TimeoutError"
    path = tmp_path / "state/runtime/live_fast_monitor/2026-10-09.jsonl"
    assert json.loads(path.read_text())["failed_operation"] == "snapshot"


def test_failed_alert_delivery_does_not_consume_success_cooldown():
    notices = fast.FailureNotices()
    failure = {"reason": "live_monitor_request_failed", "exposure_present": False}
    assert notices.should_send(failure, 0)
    notices.last_attempt = 0  # Scheduled, but transport failed; do not call sent().
    assert not notices.should_send(failure, 10)
    assert notices.should_send(failure, 30)
    assert notices.last_sent is None


def test_rate_limit_backoff_retains_known_flat_exposure(tmp_path, resolved_config):
    cfg = config(resolved_config)
    monitor, calls, tick, _ = green_monitor(tmp_path, cfg)
    monitor.retry_at = 45
    result = asyncio.run(monitor.poll(cfg))
    assert result["reason"] == "live_broker_rate_limit"
    assert result["exposure_present"] is False
    assert calls == []


def test_order_operation_failures_are_not_grouped_with_snapshot_failures():
    assert not fast._transient_failure(
        {"reason": "live_monitor_request_failed", "failed_operation": "order_placement"}
    )


def test_inflight_transient_notice_does_not_drop_order_fill(tmp_path, resolved_config, monkeypatch):
    cfg = config(resolved_config)
    (tmp_path / "CONFIG.md").write_text(
        "\n".join(
            f"{k}: {str(v).lower() if isinstance(v, bool) else v}" for k, v in cfg.values.items()
        )
    )

    async def scenario():
        started, release = asyncio.Event(), asyncio.Event()
        sent, count = [], [0]
        monitor = fast.LiveMonitor(tmp_path, execute=True, clock=lambda: NOW)

        async def poll(cfg):
            count[0] += 1
            if count[0] == 1:
                return {"status": "ATTENTION", "reason": "live_monitor_request_failed"}
            if count[0] == 2:
                return {
                    "status": "EXIT_FILLED",
                    "event": {"event": "LIVE_EXIT_FILLED"},
                    "position_actions": [{"status": "EXIT_FILLED", "order_id": "exit"}],
                }
            release.set()
            return {"status": "DISABLED"}

        async def to_thread(fn, payload, **kwargs):
            sent.append(payload["live"])
            if len(sent) == 1:
                started.set()
                await release.wait()
            return {"channels": {"ntfy": {"status": "SENT"}}}

        async def sleep(seconds):
            await started.wait()

        monkeypatch.setattr(monitor, "poll", poll)
        monkeypatch.setattr(fast.asyncio, "to_thread", to_thread)
        monkeypatch.setattr(fast.asyncio, "sleep", sleep)
        monkeypatch.setattr(fast, "market_window", lambda now: (True, "regular"))
        await fast.run(tmp_path, monitor=monitor, notifications=True)
        assert any(alert.get("status") == "EXIT_FILLED" for alert in sent)

    asyncio.run(scenario())


def test_flat_error_grouping_preserves_immediate_order_failure_alert(
    tmp_path, resolved_config, monkeypatch
):
    cfg = config(resolved_config)
    (tmp_path / "CONFIG.md").write_text(
        "\n".join(
            f"{k}: {str(v).lower() if isinstance(v, bool) else v}" for k, v in cfg.values.items()
        )
    )
    original_sleep = asyncio.sleep

    async def scenario():
        tick, count, sent = [0.0], [0], []
        monitor = fast.LiveMonitor(
            tmp_path, execute=True, clock=lambda: NOW, monotonic=lambda: tick[0]
        )

        async def poll(cfg):
            count[0] += 1
            if count[0] == 4:
                return {"status": "QUIET"}
            if count[0] == 8:
                return {
                    "status": "ATTENTION",
                    "reason": "live_monitor_request_failed",
                    "failed_operation": "order_placement",
                }
            if count[0] == 12:
                return {"status": "DISABLED"}
            return {
                "status": "ATTENTION",
                "reason": "live_monitor_request_failed",
                "failed_operation": "snapshot",
                "exposure_present": False,
            }

        async def to_thread(fn, payload, **kwargs):
            sent.append(payload["live"])
            return {"channels": {"ntfy": {"status": "SENT"}}}

        async def sleep(seconds):
            tick[0] += seconds
            await original_sleep(0)

        monkeypatch.setattr(monitor, "poll", poll)
        monkeypatch.setattr(fast.asyncio, "to_thread", to_thread)
        monkeypatch.setattr(fast.asyncio, "sleep", sleep)
        monkeypatch.setattr(fast, "market_window", lambda now: (True, "regular"))
        await fast.run(tmp_path, monitor=monitor, notifications=True)
        assert len(sent) == 2
        assert sent[0]["failed_operation"] == "snapshot"
        assert sent[1]["failed_operation"] == "order_placement"

    asyncio.run(scenario())


def test_cli_uses_monday_fresh_reader_with_retained_monitor(tmp_path, monkeypatch):
    import sys

    captured = []

    async def run(root, *, monitor, once, notifications):
        captured.append((root, monitor.snapshot, monitor.execute, once, notifications))
        return {"status": "QUIET"}

    monkeypatch.setattr(fast, "run", run)
    monkeypatch.setattr(
        sys, "argv", ["monitor", "--project-root", str(tmp_path), "--execute", "--once"]
    )
    assert fast.main() == 0
    assert captured == [(tmp_path, fast._snapshot, True, True, False)]
