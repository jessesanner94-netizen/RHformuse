import asyncio
import copy
import json
from datetime import UTC, datetime

import pytest

from research.entry_quality.priority import rsi_priority
from tools.config import TradingConfig
from tools.scheduled_cycle import _route_compact_decision_impl

NOW = datetime(2026, 10, 22, 15, tzinfo=UTC)


@pytest.mark.parametrize(
    "kind,side,expected",
    [
        ("regular_bearish", "PUT", 1),
        ("hidden_bearish", "PUT", 1),
        ("regular_bullish", "CALL", 1),
        ("hidden_bullish", "CALL", 1),
        ("regular_bearish", "CALL", -1),
        ("hidden_bullish", "PUT", -1),
    ],
)
def test_directional_priority(kind, side, expected):
    assert (
        rsi_priority(
            {"option_type": side},
            {"status": "OK", "latest_confirmed_divergences": [{"kind": kind}]},
        )
        == expected
    )


def test_absent_unavailable_or_conflicting_rsi_is_neutral():
    for evidence in (
        {"status": "UNAVAILABLE"},
        {"status": "OK"},
        {
            "status": "OK",
            "latest_confirmed_divergences": [
                {"kind": "regular_bearish"},
                {"kind": "hidden_bullish"},
            ],
        },
    ):
        assert rsi_priority({"option_type": "PUT"}, evidence) == 0


@pytest.mark.parametrize(
    "priority,missing_jev,expected",
    [
        (None, False, "higher_jev"),
        ({"higher_jev": 0, "supported": 1}, False, "supported"),
        ({"higher_jev": 0, "supported": 0}, False, "higher_jev"),
        ({"higher_jev": 0, "supported": 1}, True, "jev_ranking_unavailable"),
        ({"higher_jev": 0, "supported": True}, False, "candidate_priority_unavailable"),
    ],
)
def test_optional_priority_preserves_raw_jev_and_default_route(
    tmp_path, resolved_config, priority, missing_jev, expected
):
    config = TradingConfig(
        {
            **resolved_config.values,
            "LIVE_EXECUTION_ENABLED": False,
            "LIVE_NEW_ENTRIES_ENABLED": False,
            "PAPER_TRADING_ENABLED": True,
            "OPTIONS_LUNA_VETO_ENABLED": False,
            "OPTIONS_JEV_RANKING_ONLY": True,
            "ENABLE_JEV": True,
            "JEV_SHADOW_MODE": False,
            "OPTIONS_DAILY_GREEN_LOCK_ENABLED": True,
            "ENABLE_MULTI_WATCH": False,
        }
    )
    candidates = [
        {
            "candidate_id": key,
            "symbol": symbol,
            "option_type": "PUT",
            "python_preferred_style": "DAY",
        }
        for key, symbol in (("higher_jev", "SPY"), ("supported", "QQQ"))
    ]
    scores = {"higher_jev": 0.9, "supported": 0.1}
    evidence = {
        key: {
            "status": "OK",
            "scores": {
                "setup_quality": value,
                "entry_timing_quality": value,
                "escalate_to_luna": value,
            },
        }
        for key, value in scores.items()
    }
    before = copy.deepcopy(evidence)

    async def build(event, config, **kwargs):
        candidate = next(
            (c for c in candidates if c["candidate_id"] not in kwargs["excluded_candidate_ids"]),
            None,
        )
        if candidate is None:
            return {"status": "NO_CANDIDATE", "selected_candidates": []}
        return {
            "status": "READY",
            "selected_candidates": [candidate],
            "packet": {
                "as_of": NOW.isoformat(),
                "candidate": candidate,
                "python_gate": {"status": "QUALIFIED"},
                "earnings_event": {"status": "NOT_APPLICABLE"},
            },
        }

    def jev(packet, *args, **kwargs):
        key = packet["candidate"]["candidate_id"]
        return {"status": "UNAVAILABLE"} if missing_jev and key == "supported" else evidence[key]

    result = asyncio.run(
        _route_compact_decision_impl(
            {"paper_portfolio": {"open_positions": [], "portfolio": {"open_positions": 0}}},
            config=config,
            project_root=tmp_path,
            execute_models=True,
            now=NOW,
            packet_builder=build,
            jev_evaluator=jev,
            candidate_priority=(lambda c: priority[c["candidate_id"]]) if priority else None,
        )
    )
    if expected in scores:
        assert json.loads(result["decision"]["output"])["candidate_id"] == expected
    else:
        assert result["decision"]["reason"] == expected
    assert evidence == before
    assert result["decision"]["codex_invoked"] is False
