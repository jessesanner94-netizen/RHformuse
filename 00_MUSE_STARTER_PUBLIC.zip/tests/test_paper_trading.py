from datetime import UTC, datetime
from pathlib import Path

import pytest

from tools.config import TradingConfig, load_config
from tools.paper_trading import (
    close_paper_position,
    load_paper_portfolio,
    manage_paper_positions,
    open_paper_position,
)


@pytest.mark.parametrize(
    "high,low,interpolated,bar_time,expected",
    [
        (2.0, 1.1, False, "2026-08-24T15:01:00Z", True),
        (1.43, 1.1, False, "2026-08-24T15:01:00Z", False),
        (2.0, 0.1, False, "2026-08-24T15:01:00Z", False),
        (2.0, 1.1, True, "2026-08-24T15:01:00Z", False),
        (2.0, 1.1, False, "2026-08-24T14:59:00Z", False),
        (2.0, 1.1, False, "2026-08-24T15:02:00Z", False),
    ],
)
def test_automatic_assumed_tp(
    tmp_path, resolved_config, high, low, interpolated, bar_time, expected
):
    from tools.config import TradingConfig

    config = TradingConfig({**resolved_config.values, "PAPER_ASSUME_TP_TRADE_THROUGH": True})
    entry = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    now = datetime(2026, 8, 24, 15, 2, 30, tzinfo=UTC)
    portfolio, events = tmp_path / "portfolio.json", tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(entry),
        config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=entry,
    )
    refresh = _refresh(now, 1.2, 1.21)
    refresh["tp_history"] = {
        "contract-1": {
            "status": "OK",
            "results": [
                {
                    "instrument_id": "contract-1",
                    "interval": "minute",
                    "bars": [
                        {
                            "begins_at": bar_time,
                            "high_price": str(high),
                            "low_price": str(low),
                            "interpolated": interpolated,
                        }
                    ],
                }
            ],
        }
    }
    result = manage_paper_positions(
        refresh, config, portfolio_path=portfolio, event_log_path=events, now=now
    )
    assert bool(result["paper_events"]) is expected
    if expected:
        assert result["paper_events"][0]["fill_price"] == 1.43
        assert result["paper_events"][0]["fill_side"] == "ASSUMED_RESTING_LIMIT"
        assert result["portfolio"]["open_positions"] == 0
        again = manage_paper_positions(
            refresh, config, portfolio_path=portfolio, event_log_path=events, now=now
        )
        assert again["paper_events"] == []


def test_history_touch_without_optional_interpolated_flag(tmp_path, resolved_config):
    entry = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    now = datetime(2026, 8, 24, 15, 3, tzinfo=UTC)
    portfolio, events = tmp_path / "portfolio.json", tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(entry),
        resolved_config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=entry,
    )
    refresh = _refresh(now, 1.2, 1.21)
    refresh["tp_history"] = {
        "contract-1": {
            "status": "OK",
            "results": [
                {
                    "instrument_id": "contract-1",
                    "bars": [
                        {
                            "begins_at": "2026-08-24T15:01:00Z",
                            "high_price": "9.0",
                            "interpolated": True,
                        },
                        {"begins_at": "2026-08-24T15:02:00Z", "high_price": "2.0"},
                    ],
                }
            ],
        }
    }
    result = manage_paper_positions(
        refresh, resolved_config, portfolio_path=portfolio, event_log_path=events, now=now
    )
    evidence = result["open_positions"][0]["take_profit_evidence"]
    assert evidence["highest_trade_bar_price"] == 2.0
    assert evidence["first_possible_touch_bar"] == "2026-08-24T15:02:00Z"
    assert evidence["fill_confirmed"] is False
    assert result["paper_events"] == []


def test_authorized_assumed_close_is_labeled_and_cannot_duplicate(tmp_path, resolved_config):
    from tools.config import TradingConfig

    config = TradingConfig({**resolved_config.values, "PAPER_TRADING_ENABLED": True})
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    portfolio, events = tmp_path / "portfolio.json", tmp_path / "events.jsonl"
    opened = open_paper_position(
        _decision(),
        _candidate(now),
        config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=now,
    )
    kwargs = dict(
        bid=1.43,
        quote_updated_at="",
        reason="USER_APPROVED_ASSUMED_TAKE_PROFIT",
        config=config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=now,
        assumed_fill_evidence={"user_approved": True, "source": "test"},
    )
    result = close_paper_position(opened["position"]["paper_id"], **kwargs)
    assert result["closed"] is True
    assert result["event"]["fill_side"] == "ASSUMED_RESTING_LIMIT"
    assert result["event"]["fill_confirmed"] is False
    assert close_paper_position(opened["position"]["paper_id"], **kwargs)["closed"] is False


def _candidate(now: datetime) -> dict[str, object]:
    return {
        "candidate_id": "contract-1",
        "symbol": "SPY",
        "option_symbol": "SPY-FIXTURE",
        "expiration": "2026-09-18",
        "strike": 500.0,
        "option_type": "CALL",
        "dte": 25,
        "underlying_price": 500.0,
        "bid": 1.00,
        "ask": 1.10,
        "implied_volatility": 0.25,
        "delta": 0.50,
        "gamma": 0.002,
        "theta": -0.02,
        "vega": 0.10,
        "rho": 0.02,
        "quote_is_fresh": True,
        "quote_updated_at": now.isoformat(),
    }


def _decision() -> dict[str, object]:
    return {
        "action": "BUY",
        "candidate_id": "contract-1",
        "trade_style": "DAY",
        "hold_deadline": None,
        "thesis": "Fixture trend continuation",
        "invalidation": "Underlying loses support",
        "reason": "Synthetic test",
        "confidence": 0.7,
        "earnings_event": "None in the day-trade window",
        "holds_through_earnings": False,
    }


def _refresh(now: datetime, bid: float, ask: float) -> dict[str, object]:
    return {
        "as_of": now.isoformat(),
        "option_quotes": [
            {
                "quote": {
                    "instrument_id": "contract-1",
                    "bid_price": str(bid),
                    "ask_price": str(ask),
                    "updated_at": now.isoformat(),
                }
            }
        ],
    }


def _winner_config(resolved_config, *, trial_date: str = "2026-09-24") -> TradingConfig:
    return TradingConfig(
        {
            **resolved_config.values,
            "PAPER_WINNER_TRIAL_DATE": trial_date,
            "PAPER_WINNER_TRAIL_GIVEBACK_PERCENT": 10,
            "PAPER_WINNER_MIN_PROFIT_PERCENT": 10,
        }
    )


def _continuation(now: datetime, status: str = "INTACT") -> dict[str, object]:
    return {
        "SPY": {
            "status": status,
            "as_of": now.isoformat(),
            "option_type": "CALL",
            "reasons": ["fixture"],
        }
    }


def test_paper_entry_buys_at_ask_and_revalues_at_bid(tmp_path: Path, resolved_config) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    portfolio = tmp_path / "portfolio.json"
    events = tmp_path / "events.jsonl"
    result = open_paper_position(
        _decision(),
        _candidate(now),
        resolved_config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=now,
    )

    assert result["status"] == "OPENED"
    assert result["position"]["entry_price"] == 1.1
    assert result["event"]["trade_style"] == "DAY"
    assert result["event"]["expiration"] == "2026-09-18"
    assert result["portfolio"]["cash"] == 9890.0
    assert result["portfolio"]["equity"] == 9990.0
    assert result["portfolio"]["unrealized_pnl"] == -10.0
    assert "PAPER_ENTRY" in events.read_text(encoding="utf-8")
    assert (tmp_path / "SUMMARY.md").exists()


def test_paper_target_exit_sells_at_bid_and_records_pnl(tmp_path: Path, resolved_config) -> None:
    entry_time = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    portfolio = tmp_path / "portfolio.json"
    events = tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(entry_time),
        resolved_config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=entry_time,
    )
    exit_time = datetime(2026, 8, 24, 15, 10, tzinfo=UTC)
    result = manage_paper_positions(
        _refresh(exit_time, 1.50, 1.55),
        resolved_config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=exit_time,
    )

    assert result["status"] == "EXITED"
    assert result["paper_events"][0]["exit_reason"] == "TAKE_PROFIT"
    assert result["paper_events"][0]["realized_pnl"] == 40.0
    assert result["portfolio"]["equity"] == 10040.0
    assert result["portfolio"]["open_positions"] == 0


def test_winner_trial_enrolls_only_primary_day_entry_on_trial_date(
    tmp_path: Path, resolved_config
) -> None:
    config = _winner_config(resolved_config)
    trial_time = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)
    primary = open_paper_position(
        _decision(),
        _candidate(trial_time),
        config,
        portfolio_path=tmp_path / "paper" / "PORTFOLIO.json",
        event_log_path=tmp_path / "paper" / "EVENTS.jsonl",
        now=trial_time,
    )["position"]
    baseline = open_paper_position(
        _decision(),
        _candidate(trial_time),
        config,
        portfolio_path=tmp_path / "paper_baseline" / "PORTFOLIO.json",
        event_log_path=tmp_path / "paper_baseline" / "EVENTS.jsonl",
        now=trial_time,
    )["position"]
    off_date = open_paper_position(
        _decision(),
        _candidate(trial_time.replace(day=23)),
        config,
        portfolio_path=tmp_path / "off_date" / "PORTFOLIO.json",
        event_log_path=tmp_path / "off_date" / "EVENTS.jsonl",
        now=trial_time.replace(day=23),
    )["position"]

    assert primary["winner_management"] == {
        "enabled": True,
        "checkpoint_reached": False,
        "giveback_percent": 10.0,
        "min_profit_percent": 10.0,
        "original_stop_price": primary["stop_price"],
        "trailing_floor": primary["stop_price"],
    }
    assert "winner_management" not in baseline
    assert "winner_management" not in off_date


def test_winner_trial_trailing_floor_is_monotonic(tmp_path: Path, resolved_config) -> None:
    config = _winner_config(resolved_config)
    entry = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)
    portfolio, events = tmp_path / "paper" / "PORTFOLIO.json", tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(entry),
        config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=entry,
    )

    def mark(at: datetime, bid: float):
        refresh = _refresh(at, bid, bid + 0.01)
        refresh["continuation_evidence"] = _continuation(at)
        return manage_paper_positions(
            refresh, config, portfolio_path=portfolio, event_log_path=events, now=at
        )

    checkpoint = mark(entry.replace(minute=5), 1.50)
    assert checkpoint["status"] == "MONITORED"
    checkpoint_management = checkpoint["open_positions"][0]["winner_management"]
    assert checkpoint_management["trailing_floor"] == 1.35
    assert checkpoint_management["checkpoint_reached"] is True
    assert checkpoint_management["last_evidence"]["status"] == "INTACT"
    high = mark(entry.replace(minute=10), 2.00)
    assert high["open_positions"][0]["winner_management"]["trailing_floor"] == 1.8
    pullback = mark(entry.replace(minute=15), 1.85)
    assert pullback["open_positions"][0]["winner_management"]["trailing_floor"] == 1.8
    exited = mark(entry.replace(minute=20), 1.79)
    assert exited["paper_events"][0]["exit_reason"] == "TRAILING_PROFIT"


@pytest.mark.parametrize("evidence", [None, "stale"])
def test_winner_checkpoint_exits_when_continuation_unavailable(
    tmp_path: Path, resolved_config, evidence
) -> None:
    config = _winner_config(resolved_config)
    entry = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)
    now = entry.replace(minute=5)
    portfolio, events = tmp_path / "paper" / "PORTFOLIO.json", tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(entry),
        config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=entry,
    )
    refresh = _refresh(now, 1.50, 1.51)
    if evidence == "stale":
        refresh["continuation_evidence"] = _continuation(entry)

    result = manage_paper_positions(
        refresh, config, portfolio_path=portfolio, event_log_path=events, now=now
    )

    event = result["paper_events"][0]
    assert event["exit_reason"] == "CONTINUATION_UNAVAILABLE"
    assert event["winner_management"]["checkpoint_reached"] is True


def test_winner_broken_thesis_exits_and_day_deadline_still_precedes_evidence(
    tmp_path: Path, resolved_config
) -> None:
    config = _winner_config(resolved_config)
    entry = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)

    def opened(name: str):
        path = tmp_path / name / "paper" / "PORTFOLIO.json"
        events = tmp_path / name / "events.jsonl"
        open_paper_position(
            _decision(),
            _candidate(entry),
            config,
            portfolio_path=path,
            event_log_path=events,
            now=entry,
        )
        return path, events

    thesis_path, thesis_events = opened("thesis")
    now = entry.replace(minute=5)
    broken = _refresh(now, 1.50, 1.51)
    broken["continuation_evidence"] = _continuation(now, "BROKEN")
    thesis = manage_paper_positions(
        broken, config, portfolio_path=thesis_path, event_log_path=thesis_events, now=now
    )
    assert thesis["paper_events"][0]["exit_reason"] == "THESIS_EXIT"

    deadline_path, deadline_events = opened("deadline")
    after_close = datetime(2026, 9, 24, 19, 46, tzinfo=UTC)
    late = _refresh(after_close, 1.50, 1.51)
    deadline = manage_paper_positions(
        late,
        config,
        portfolio_path=deadline_path,
        event_log_path=deadline_events,
        now=after_close,
    )
    assert deadline["paper_events"][0]["exit_reason"] == "DAY_TRADE_TIME_EXIT"


def test_winner_trial_disables_assumed_historical_target_fill(
    tmp_path: Path, resolved_config
) -> None:
    config = _winner_config(resolved_config)
    entry = datetime(2026, 9, 24, 15, 0, tzinfo=UTC)
    now = entry.replace(minute=3)
    portfolio, events = tmp_path / "paper" / "PORTFOLIO.json", tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(entry),
        config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=entry,
    )
    refresh = _refresh(now, 1.20, 1.21)
    refresh["tp_history"] = {
        "contract-1": {
            "status": "OK",
            "results": [
                {
                    "instrument_id": "contract-1",
                    "interval": "minute",
                    "bars": [
                        {
                            "begins_at": entry.replace(minute=1).isoformat(),
                            "high_price": "2.00",
                            "low_price": "1.10",
                        }
                    ],
                }
            ],
        }
    }

    result = manage_paper_positions(
        refresh, config, portfolio_path=portfolio, event_log_path=events, now=now
    )

    assert result["status"] == "MONITORED"
    assert result["paper_events"] == []


def test_second_paper_position_is_blocked_by_same_risk_gate(
    tmp_path: Path,
) -> None:
    small_config = load_config(
        Path(__file__).parent / "fixtures" / "CONFIG.small-account-proposal-test-only.md"
    )
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    portfolio = tmp_path / "portfolio.json"
    events = tmp_path / "events.jsonl"
    open_paper_position(
        _decision(),
        _candidate(now),
        small_config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=now,
    )
    second_candidate = {**_candidate(now), "candidate_id": "contract-2", "symbol": "QQQ"}
    second_decision = {**_decision(), "candidate_id": "contract-2"}
    result = open_paper_position(
        second_decision,
        second_candidate,
        small_config,
        portfolio_path=portfolio,
        event_log_path=events,
        now=now,
    )

    assert result["status"] == "BLOCKED"
    assert "portfolio_premium_limit_exceeded" in result["reasons"]
    assert "max_new_positions_per_day_exceeded" not in result["reasons"]


def test_load_initializes_empty_portfolio(tmp_path: Path) -> None:
    now = datetime(2026, 8, 24, 15, 0, tzinfo=UTC)
    state = load_paper_portfolio(tmp_path / "missing.json", starting_cash=369, now=now)
    assert state["cash"] == 369
    assert state["open_positions"] == []


def test_paper_entry_is_blocked_during_opening_wait(tmp_path: Path, resolved_config) -> None:
    now = datetime(2026, 8, 24, 13, 30, tzinfo=UTC)
    result = open_paper_position(
        _decision(),
        _candidate(now),
        resolved_config,
        portfolio_path=tmp_path / "portfolio.json",
        event_log_path=tmp_path / "events.jsonl",
        now=now,
    )

    assert result["status"] == "BLOCKED"
    assert result["reasons"] == ["day_entry_window_closed"]


def test_late_day_blocks_day_entry_but_allows_swing(tmp_path: Path, resolved_config) -> None:
    now = datetime(2026, 8, 24, 19, 40, tzinfo=UTC)
    day = open_paper_position(
        _decision(),
        _candidate(now),
        resolved_config,
        portfolio_path=tmp_path / "day-portfolio.json",
        event_log_path=tmp_path / "day-events.jsonl",
        now=now,
    )
    assert day["status"] == "BLOCKED"
    assert day["reasons"] == ["day_entry_window_closed"]

    swing_decision = {
        **_decision(),
        "trade_style": "SWING",
        "hold_deadline": "2026-08-25T19:00:00+00:00",
    }
    swing = open_paper_position(
        swing_decision,
        _candidate(now),
        resolved_config,
        portfolio_path=tmp_path / "swing-portfolio.json",
        event_log_path=tmp_path / "swing-events.jsonl",
        now=now,
    )
    assert swing["status"] == "OPENED"
