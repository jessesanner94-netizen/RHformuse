"""End-to-end paper-ledger checks using the public adapter's string quote shape."""

import asyncio
from datetime import UTC, datetime, timedelta

from tools.crypto_market_data import fetch_quote
from tools.crypto_paper import CryptoPaperStore

NOW = datetime(2026, 9, 20, 12, tzinfo=UTC)
SETTINGS = {
    "CRYPTO_PAPER_STARTING_CASH": 369,
    "CRYPTO_MAX_POSITION_DOLLARS": 50,
    "CRYPTO_STOP_LOSS_PERCENT": 1,
    "CRYPTO_TAKE_PROFIT_PERCENT": 2,
    "CRYPTO_MAX_DAILY_LOSS_DOLLARS": 5,
    "CRYPTO_MAX_ENTRIES_PER_DAY": 3,
    "CRYPTO_MAX_HOLD_MINUTES": 240,
    "CRYPTO_MAX_SPREAD_PERCENT": 0.5,
    "CRYPTO_PAPER_FEE_PERCENT_SIDE": 0.25,
    "CRYPTO_PAPER_SLIPPAGE_BPS_SIDE": 5,
    "CRYPTO_STOP_AFTER_NET_GREEN": True,
}
BUY = {
    "action": "BUY",
    "symbol": "ETH-USD",
    "thesis": "Qualified paper continuation",
    "invalidation": "Stop level breached",
}


def quote(bid: float, ask: float, at: datetime) -> dict:
    async def transport(_url):
        return {
            "bid": str(bid),
            "ask": str(ask),
            "price": str((bid + ask) / 2),
            "time": at.isoformat(),
        }

    return asyncio.run(fetch_quote(now=at, transport=transport))


def test_public_quote_opens_and_stop_exits_without_model_or_broker(tmp_path):
    store = CryptoPaperStore(tmp_path / "crypto.sqlite3", SETTINGS)
    initial = quote(2000, 2002, NOW)
    assert store.monitor(initial, NOW)["status"] == "FLAT"

    opened = store.buy(initial, BUY, NOW, deadline=NOW + timedelta(hours=4))
    assert opened["status"] == "PAPER_BUY"
    position = opened["position"]
    assert position["total_entry_cost"] == 50 * 1.0025
    assert position["deadline"] == (NOW + timedelta(hours=4)).isoformat()

    later = NOW + timedelta(minutes=1)
    exit_quote = quote(position["stop"] - 1, position["stop"], later)
    exited = store.monitor(exit_quote, later)
    assert exited["status"] == "PAPER_EXIT"
    assert exited["reason"] == "STOP"
    assert exited["model_required"] is False
    assert store.read()["position"] is None
    assert store.read()["cash"] < SETTINGS["CRYPTO_PAPER_STARTING_CASH"]


def test_profitable_target_closes_and_stops_new_paper_entries(tmp_path):
    store = CryptoPaperStore(tmp_path / "crypto.sqlite3", SETTINGS)
    initial = quote(2000, 2002, NOW)
    position = store.buy(initial, BUY, NOW, deadline=NOW + timedelta(hours=4))["position"]
    later = NOW + timedelta(minutes=1)
    target_quote = quote(position["target"] + 1, position["target"] + 2, later)
    exited = store.monitor(target_quote, later)
    assert exited["status"] == "PAPER_EXIT"
    assert exited["reason"] == "TARGET"
    assert store.read()["day"]["net_green"] is True

    next_quote = quote(2000, 2002, later)
    blocked = store.buy(next_quote, BUY, later, deadline=later + timedelta(hours=4))
    assert blocked == {"status": "BLOCKED", "reason": "crypto_day_net_green"}
