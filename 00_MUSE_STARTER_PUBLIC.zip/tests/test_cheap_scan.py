from __future__ import annotations

from pathlib import Path

from tools.cheap_scan import evaluate_candidate, scan_candidates
from tools.config import load_config

ROOT = Path(__file__).resolve().parents[1]


def test_qualified_candidate_passes_configured_gates(base_candidate, resolved_config) -> None:
    result = evaluate_candidate(base_candidate, resolved_config)
    assert result.status == "QUALIFIED"
    assert result.reasons == ()
    assert result.metrics["spread_percent"] == 8.0


def test_stale_quote_and_wide_spread_are_rejected(base_candidate, resolved_config) -> None:
    candidate = {**base_candidate, "quote_is_fresh": False, "ask": 6.0}
    result = evaluate_candidate(candidate, resolved_config)
    assert result.status == "REJECTED"
    assert "freshness_unverified" in result.reasons
    assert "spread_too_wide" in result.reasons


def test_approved_production_thresholds_qualify_synthetic_candidate(base_candidate) -> None:
    result = evaluate_candidate(base_candidate, load_config(ROOT / "CONFIG.md"))
    assert result.status == "QUALIFIED"
    assert result.reasons == ()


def test_zero_candidate_summary_does_not_escalate(resolved_config) -> None:
    result = scan_candidates([], resolved_config)
    assert result["status"] == "ZERO_QUALIFIED"
    assert result["counts"]["qualified"] == 0


def test_duplicate_candidate_identity_fails_closed(base_candidate, resolved_config) -> None:
    result = scan_candidates([base_candidate, dict(base_candidate)], resolved_config)
    assert result["status"] == "INSUFFICIENT_DATA"
    assert result["duplicate_candidate_ids"] == ["spy-fixture-contract"]
    assert result["counts"]["qualified"] == 0
