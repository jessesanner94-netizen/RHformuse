import asyncio
import os
import time
from types import SimpleNamespace
from urllib.parse import parse_qs

import pytest
from mcp.shared.auth import OAuthClientMetadata

from tools.robinhood_mcp import (
    CALLBACK_URL,
    ROBINHOOD_MCP_URL,
    ROBINHOOD_OAUTH_TOKEN_URL,
    TOKEN_CREDENTIAL,
    CredentialStorage,
    _mask_account,
    _near_money_instruments,
    _persisted_token_expiry,
    _PersistedExpiryOAuthClientProvider,
    _select_agentic_account,
)


def test_selects_only_accessible_agentic_account() -> None:
    selected = _select_agentic_account(
        [
            {"account_number": "1111", "agentic_allowed": False},
            {"account_number": "2222", "agentic_allowed": True},
        ]
    )

    assert selected["account_number"] == "2222"


def test_account_selection_fails_closed() -> None:
    with pytest.raises(RuntimeError, match="exactly one"):
        _select_agentic_account([])


def test_masks_account_number() -> None:
    assert _mask_account("123456789") == "••••6789"


def test_near_money_contract_selection_is_bounded_per_expiration_and_type() -> None:
    instruments = [
        {
            "id": f"call-{strike}",
            "chain_symbol": "SPY",
            "expiration_date": "2026-09-18",
            "type": "call",
            "strike_price": str(strike),
        }
        for strike in range(80, 121)
    ]
    selected = _near_money_instruments(
        instruments,
        [{"quote": {"symbol": "SPY", "last_trade_price": "100"}}],
        per_expiration_type=5,
    )

    assert len(selected) == 5
    assert {float(item["strike_price"]) for item in selected} == {98, 99, 100, 101, 102}


def test_persisted_token_expiry_uses_encrypted_file_write_time(tmp_path) -> None:
    storage = CredentialStorage(tmp_path)
    token_path = tmp_path / TOKEN_CREDENTIAL
    if os.name != "nt":
        token_path = storage._path(TOKEN_CREDENTIAL)
    token_path.write_bytes(b"encrypted-token-placeholder")
    if os.name != "nt":
        token_path.chmod(0o600)
    issued_at = time.time() - 600
    os.utime(token_path, (issued_at, issued_at))

    expiry = _persisted_token_expiry(
        storage,
        SimpleNamespace(expires_in=300),
        safety_seconds=60,
    )

    assert expiry == pytest.approx(issued_at + 240)
    assert expiry < time.time()


def test_persisted_token_expiry_fails_closed_without_duration(tmp_path) -> None:
    storage = CredentialStorage(tmp_path)
    token_path = storage._path(TOKEN_CREDENTIAL)
    token_path.write_bytes(b"encrypted-token-placeholder")
    if os.name != "nt":
        token_path.chmod(0o600)

    assert _persisted_token_expiry(storage, SimpleNamespace(expires_in=None)) is None


def test_refresh_uses_robinhood_advertised_token_endpoint_before_discovery(tmp_path) -> None:
    provider = _PersistedExpiryOAuthClientProvider(
        ROBINHOOD_MCP_URL,
        OAuthClientMetadata(
            redirect_uris=[CALLBACK_URL],
            token_endpoint_auth_method="none",
            grant_types=["authorization_code", "refresh_token"],
            response_types=["code"],
            scope="internal",
            client_name="test",
        ),
        CredentialStorage(tmp_path),
    )

    assert provider._get_token_endpoint() == ROBINHOOD_OAUTH_TOKEN_URL


def test_refresh_omits_resource_parameter_rejected_by_robinhood(tmp_path) -> None:
    provider = _PersistedExpiryOAuthClientProvider(
        ROBINHOOD_MCP_URL,
        OAuthClientMetadata(
            redirect_uris=[CALLBACK_URL],
            token_endpoint_auth_method="none",
            grant_types=["authorization_code", "refresh_token"],
            response_types=["code"],
            scope="internal",
            client_name="test",
        ),
        CredentialStorage(tmp_path),
    )
    provider.context.current_tokens = SimpleNamespace(refresh_token="refresh-token")
    provider.context.client_info = SimpleNamespace(
        client_id="client-id",
        client_secret=None,
        token_endpoint_auth_method="none",
    )
    provider.context.protocol_version = "2025-06-18"

    refresh = asyncio.run(provider._refresh_token())
    fields = parse_qs(refresh.content.decode("utf-8"))

    assert str(refresh.url) == ROBINHOOD_OAUTH_TOKEN_URL
    assert fields == {
        "grant_type": ["refresh_token"],
        "refresh_token": ["refresh-token"],
        "client_id": ["client-id"],
    }
    assert "resource" not in fields


@pytest.mark.parametrize("reader", ["fetch_snapshot", "fetch_quote_refresh"])
def test_monitor_read_reconnects_once(monkeypatch, reader):
    import anyio

    import tools.robinhood_mcp as bridge

    calls, sleeps = [], []

    async def session(action, requests=None):
        calls.append(action)
        if len(calls) == 1:
            raise ExceptionGroup("outer", [ExceptionGroup("inner", [anyio.BrokenResourceError()])])
        return {"status": "OK"}

    async def sleep(seconds):
        sleeps.append(seconds)

    monkeypatch.setattr(bridge, "_with_session", session)
    monkeypatch.setattr(bridge.asyncio, "sleep", sleep)
    fn = getattr(bridge, reader)
    result = asyncio.run(fn([]) if reader == "fetch_quote_refresh" else fn())
    assert result == {"status": "OK"}
    assert len(calls) == 2
    assert sleeps == [2]


@pytest.mark.parametrize(
    "error,attempts", [(ConnectionError("offline"), 2), (ValueError("bad data"), 1)]
)
def test_monitor_retry_is_bounded(monkeypatch, error, attempts):
    import tools.robinhood_mcp as bridge

    calls = []

    async def session(*args):
        calls.append(1)
        raise error

    async def sleep(seconds):
        pass

    monkeypatch.setattr(bridge, "_with_session", session)
    monkeypatch.setattr(bridge.asyncio, "sleep", sleep)
    with pytest.raises(type(error)):
        asyncio.run(bridge.fetch_quote_refresh([]))
    assert len(calls) == attempts


def test_order_submission_never_retried(monkeypatch):
    import tools.robinhood_mcp as bridge

    calls = []

    async def session(*args):
        calls.append(1)
        raise ConnectionError("uncertain submission")

    monkeypatch.setattr(bridge, "_with_session", session)
    with pytest.raises(ConnectionError):
        asyncio.run(bridge.place_live_option_order({}))
    assert len(calls) == 1


def test_fresh_snapshots_recreate_client_auth_session_and_all_broker_reads(monkeypatch):
    from contextlib import asynccontextmanager

    import mcp
    import mcp.client.streamable_http

    import tools.robinhood_mcp as bridge

    calls, auths, sessions, clients = [], [], [], []

    @asynccontextmanager
    async def transport(url, *, http_client, terminate_on_close):
        assert terminate_on_close is False
        auths.append(http_client.auth)
        clients.append(http_client)
        yield (None, None)

    class Session:
        def __init__(self, *args):
            sessions.append(self)

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def initialize(self):
            calls.append("initialize")

        async def call_tool(self, name, arguments):
            calls.append((name, arguments))
            data = {
                "get_accounts": {
                    "accounts": [{"account_number": "synthetic", "agentic_allowed": True}]
                },
                "get_portfolio": {"total_value": "400"},
                "get_option_positions": {"positions": []},
                "get_option_orders": {"orders": []},
            }
            return data[name]

    monkeypatch.setattr(mcp, "ClientSession", Session)
    monkeypatch.setattr(mcp.client.streamable_http, "streamable_http_client", transport)
    monkeypatch.setattr(bridge, "_tool_payload", lambda response, name: response)
    monkeypatch.setattr(bridge, "_data", lambda response: response)

    async def scenario():
        for _ in range(2):
            value = await bridge._with_session("snapshot")
            assert value["positions"] == [] and value["open_option_orders"] == []
            assert value["portfolio"]["total_value"] == "400"
        assert len(sessions) == 2 and auths[0] is not auths[1]
        assert clients[0] is not clients[1]
        assert all(client.is_closed for client in clients)
        assert calls.count("initialize") == 2
        tool_calls = [row for row in calls if isinstance(row, tuple)]
        assert len(tool_calls) == 14
        assert sum(name == "get_option_orders" for name, _ in tool_calls) == 8

    asyncio.run(scenario())
