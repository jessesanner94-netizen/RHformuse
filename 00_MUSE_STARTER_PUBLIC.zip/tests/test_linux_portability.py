"""Offline Linux checks for private OAuth storage and platform launch paths."""

import os
import stat
import subprocess
import time

import pytest

from tools.robinhood_mcp import CLIENT_CREDENTIAL, TOKEN_CREDENTIAL, CredentialStorage
from tools.vibe_snapshot import fetch_vibe_snapshot
from tools.windows_notify import send_notification

pytestmark = pytest.mark.skipif(os.name == "nt", reason="Linux storage checks")


def test_linux_oauth_storage_is_private_atomic_and_uses_token_write_time(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))
    storage = CredentialStorage()
    assert storage._read(TOKEN_CREDENTIAL) is None
    storage._write(TOKEN_CREDENTIAL, '{"access_token":"test-only"}')
    storage._write(CLIENT_CREDENTIAL, '{"client_id":"test-only"}')
    token = storage._path(TOKEN_CREDENTIAL)
    client = storage._path(CLIENT_CREDENTIAL)
    assert token.read_text() == '{"access_token":"test-only"}'
    assert client.read_text() == '{"client_id":"test-only"}'
    assert stat.S_IMODE(storage.directory.stat().st_mode) == 0o700
    assert stat.S_IMODE(token.stat().st_mode) == 0o600
    assert stat.S_IMODE(client.stat().st_mode) == 0o600
    assert storage.token_saved_at() == pytest.approx(token.stat().st_mtime)
    first_time = storage.token_saved_at()
    time.sleep(0.01)
    storage._write(TOKEN_CREDENTIAL, '{"access_token":"refreshed-test-only"}')
    assert storage.token_saved_at() > first_time
    assert sorted(path.name for path in storage.directory.iterdir()) == [client.name, token.name]


def test_linux_oauth_storage_rejects_exposed_file_and_directory(tmp_path):
    directory = tmp_path / "credentials"
    storage = CredentialStorage(directory)
    storage._write(TOKEN_CREDENTIAL, "test-only")
    token = storage._path(TOKEN_CREDENTIAL)
    token.chmod(0o644)
    with pytest.raises(PermissionError):
        storage._read(TOKEN_CREDENTIAL)
    with pytest.raises(PermissionError):
        storage._write(TOKEN_CREDENTIAL, "replacement")
    token.chmod(0o600)
    directory.chmod(0o755)
    with pytest.raises(PermissionError):
        storage._read(TOKEN_CREDENTIAL)


def test_vibe_snapshot_uses_native_interpreter(tmp_path, monkeypatch):
    interpreter = tmp_path / ".vibe-venv" / "bin" / "python"
    interpreter.parent.mkdir(parents=True)
    interpreter.write_text("test-only")
    worker = tmp_path / "tools" / "vibe_snapshot_worker.py"
    worker.parent.mkdir()
    worker.write_text("test-only")
    commands = []

    def runner(command, **kwargs):
        commands.append(command)
        return subprocess.CompletedProcess(command, 0, '{"status":"OK"}\n', "")

    monkeypatch.setattr("tools.vibe_snapshot.subprocess.run", runner)
    assert fetch_vibe_snapshot("SPY", project_root=tmp_path)["status"] == "OK"
    assert commands[0][0] == str(interpreter)


def test_linux_notification_skips_toast_and_keeps_phone(tmp_path):
    sent = []

    def forbidden_runner(*args, **kwargs):
        raise AssertionError("PowerShell must not run on Linux")

    def phone(title, message):
        sent.append((title, message))
        return {"status": "SENT"}

    result = send_notification(
        {"status": "ERROR", "error": "synthetic offline failure"},
        project_root=tmp_path,
        execute=True,
        runner=forbidden_runner,
        ntfy_sender=phone,
    )
    assert result["status"] == "SENT"
    assert result["channels"]["windows"]["status"] == "SKIPPED"
    assert len(sent) == 1
