# Robinhood Trading Agent — Starter Pack

This repository is the persistent brain and operating policy for a Codex-based options trading agent.

## Core architecture

- **Codex** = orchestrator and judgment layer.
- **Robinhood MCP** = live account/quote/order source of truth and the only execution authority.
- **Vibe-Trading** = research, screening, technicals, fundamentals, factors, backtests, and quant tools.
- **Unusual Whales (UW)** = options-flow, GEX, dark-pool, premium, and related options intelligence.

Current user-approved sizing: one contract per position, $50–$250 premium per position, at most
three new positions per day, and fresh broker buying-power checks. No separate simultaneous-position
count or aggregate premium cap: `UNLIMITED` explicitly disables only those two caps in `CONFIG.md`.
Daily-loss, contract-quality, event, and exit rules remain active. Total cash exposure can be higher
than under the former $150 combined cap.
- **skfolio + Python** = deterministic portfolio/risk math.
- **Agent Reach / web/news tools** = social, X/Twitter, Reddit, RSS, and broad discovery when available.
- **Project files** = persistent strategy, risk, memory, cost controls, and trade history.

## Safety default

The starter is fail-closed by default. This checkout is currently in user-approved paper mode with
live execution disabled in `CONFIG.md`; no scheduled result can place a Robinhood order.

## First build order

1. Create/open this repository as the Codex project.
2. Connect Robinhood MCP.
3. Install/connect Vibe-Trading.
4. Install skfolio.
5. Make the cheap scanner and risk/cost utilities.
6. Test the complete workflow manually with no live orders.
7. Connect Agent Reach or equivalent social/news tooling if available.
8. Prepare Unusual Whales, then activate its trial only when the rest of the system is ready.
9. Run the UW A/B attribution test.
10. Start with shadow/small-capital testing.
11. Add automation/scheduling last, after manual runs are reliable.

See `PLAN.md` for the full implementation sequence.

## Current implementation

### Isolated paper and replay research — 2026-10-19

[The options experiment lab](research/options_lab/README.md) freezes the current
strategy into a dormant, independent research baseline. It reuses the production
decision/risk and paper-account engines with recorded point-in-time inputs, supports
separate replay and persistent paper runs, and reports costs and data gaps. No
market feed, trading process or schedule is activated. Existing sparse history is
insufficient for a complete independent historical options backtest.

### Systematic strategy research — 2026-09-10

Use [the research workflow](research/systematic/README.md) for Awesome Systematic
Trading discovery, QuantConnect implementation references, and original-paper
verification. The [initial shortlist](research/systematic/SHORTLIST.md) prioritizes
SPY intraday continuation. This is a documented research process; no candidate has
been activated or independently validated for options trading.

### Paper repairs — 2026-09-05

The approved repair normalizes watchlist DAY/SWING eligibility before Luna, searches the nearest
two permitted expirations plus a nearby SWING window, and preserves both option directions in the
affordable shortlist. Existing liquidity/Greek gates remain active. Current effective entry size
also reserves loss to stops and estimated costs against the remaining daily loss budget.

The current strategy is still technical confluence followed by Luna's judgment: intraday trend,
opening-range/VWAP structure, higher-timeframe context, compressed news/social, and contract/risk
quality. It is not simply buying the cheapest contract, and it has not established a consistent
profitable edge. Selection of a simpler explicit entry strategy remains a separate experiment.

After scheduled runs, `state/evaluation/SUMMARY.md` shows the daily candidate funnel, rejection
reasons, actual primary paper entries, separate DAY-control entries, and matched completed DAY
outcomes. `METRICS.json` holds the structured totals and `PAIRS.jsonl` links each comparison to
both paper ledgers. The control uses no extra model call and shares the post-decision quote, risk
rules, $0.05 fee/$1 slippage estimates per side, and hard exits. AI/data costs are explicitly unknown
until entered in `state/evaluation/COSTS.jsonl` with the existing cost-tracker CLI.

Holiday/early-close handling uses the regular underlying-session calendar. A 13:00 close means
12:30 DAY entry cutoff and 12:45 DAY exit deadline. The October 9 paper monitor
targets 10-second held-option checks; disabled live monitoring retains two minutes.
Paper daily P&L uses the day's change in equity, including overnight gaps; it does not recount
yesterday's unrealized loss. Main and control cash, limits, fills and trade counts are separate.

Run the fully offline workflow checks with
`uv run python -m pytest tests/test_paper_repair_integration.py`.
Quotes and the model boundary are synthetic fixtures;
these tests cannot establish real-market performance. See
`proposals/PAPER_REPAIRS_2026-09-05.md` for the repair scope and validation record.

Phase 3's first deterministic tool set is implemented under `tools/`:

- `cheap_scan.py` applies only user-configured option/liquidity thresholds and fails closed on
  unresolved settings, stale data, ambiguous candidate identity, or malformed quotes.
- `portfolio_risk.py` enforces daily, position, buying-power, premium, and earnings limits and uses
  skfolio for historical CVaR when a return matrix is supplied.
- `cost_tracker.py` calculates economic profit and AI/data efficiency, records UW attribution, and
  previews ledger writes unless `--commit` is explicit.
- `state_manager.py` reconciles fresh broker snapshots with `state/POSITIONS.md` and provides
  hash-guarded atomic JSON updates that also default to preview mode.
- `unusual_whales.py` is a GET-only, endpoint-whitelisted UW client. It reads `UW_API_KEY` only
  from the environment, never accepts the token as a CLI argument, and reports remaining quota
  headers when UW supplies them.
- `dry_run.py` enforces the run sequence and has no order-placement or cancellation interface.
- `position_monitor.py` evaluates exit/data-integrity triggers without calling a model or broker.
- `robinhood_mcp.py` obtains read-only broker snapshots directly through OAuth/MCP without GPT.
- `codex_trigger.py` runs one isolated Luna/high decision with a compact policy, read-only sandbox,
  no project MCP configuration, bounded transcript logging, and a timeout.
- `decision_context.py` ranks one contract and reduces account/risk, four technical timeframes,
  news/social sentiment, catalysts, earnings, and UW flow into a bounded decision packet. It also
  enforces the daily model-call budget and caches unchanged `PASS`/`WAIT` plus still-valid `BUY`
  decisions so a broker retry does not spend another model call. At the daily ceiling, opportunity
  cycles skip discovery and sleep silently until the next Eastern day while position monitoring
  stays active.
- `vibe_snapshot.py` launches Vibe's own Python runtime to calculate daily, 4-hour, 15-minute, and
  5-minute evidence without sending raw bars to an LLM.
- `live_monitor.py` adapts fresh Robinhood snapshots and project position memory to the deterministic
  monitor without a model or broker mutation.
- `news_delta.py` hashes/deduplicates position-symbol RSS items and wakes Luna only for new items.
- `option_discovery.py` can use UW for discovery when enabled, then Robinhood for exact live contract liquidity and
  Greek/price verification before any model can wake; aggregate ticker option volume is diversified
  by symbol before exact-contract ranking.
- `market_movers.py` adds Robinhood's liquid Daily Movers gainers/losers when broad discovery is enabled
  breadth source and resolves a bounded near-money chain set through the shared contract gate.
- `option_style.py` applies distinct DAY and SWING DTE, delta, normalized gamma, and theta-decay
  limits while carrying vega, rho, and IV into model and paper-fill review.
- `market_intelligence.py` deduplicates US-market RSS news and capability-gates Agent Reach social
  backends; unavailable X/Reddit access is recorded explicitly rather than guessed.
- `news_option_discovery.py` turns Luna-escalated headline symbols into a bounded live Robinhood
  chain search and applies the same quote freshness, volume/OI, spread, style-aware Greek/DTE, and
  premium gates.
- `watchlist_discovery.py` resolves exactly the configured fixed symbols without invoking movers or
  paid-flow discovery; the current list is SPY and QQQ.
- `paper_trading.py` maintains a persistent $369 shadow account, buys at the refreshed ask, marks
  and sells at the refreshed bid, and applies the approved risk/stop/target/time-exit rules.
- `live_trading.py` persists idempotent review/placement state, submits one-contract ask-limit
  entries only after exact Robinhood review, and manages deterministic market exits at the approved
  stop, target, or deadline without automatic cancellation/repricing. Equity freshness uses
  Robinhood's matching venue trade timestamps, while option freshness uses `updated_at`.
- `scheduled_cycle.py` performs the full Python gate and makes at most one isolated Luna/high final
  call for the single best candidate. There is no routine Luna-to-Sol cascade or model browsing.

The production small-account policy remains recorded, but live mode is paused. The scheduled tasks
now run the SPY/QQQ paper experiment. Scheduled model sandboxes cannot access Robinhood; Python
collects and compresses the read-only contract/market evidence and owns simulated fills/exits.

## Local setup and verification

```powershell
uv sync --group dev
uv run ruff check .
uv run pytest
```

Run the included zero-candidate fixture:

```powershell
uv run python -m tools.dry_run `
  --config tests/fixtures/CONFIG.resolved-test-only.md `
  --input tests/fixtures/dry_run_zero_candidates.json
```

Run against the production configuration to confirm unresolved settings fail closed:

```powershell
uv run python -m tools.dry_run --input tests/fixtures/dry_run_zero_candidates.json
```

No fixture, utility, or dry-run command can place or cancel a Robinhood order.

## Installed live schedule

Windows Task Scheduler runs the standalone CLI under the current logged-in Windows user:

- positions: a paper-only resident loop targets 10-second checks; the existing
  two-minute task trigger provides restart opportunities, 9:30 a.m.–4:00 p.m. ET
- combined broad news/social and opportunities: every 10 minutes, 9:30 a.m.–4:00 p.m. ET

The computer must be connected and the Windows user must remain logged in; the tasks can wake the
PC from sleep. The Codex desktop window does not have to stay open. Python performs every routine
poll and manages live stops/targets. Scheduled PowerShell launchers are hidden. Once the daily
model-call ceiling is reached, the recurring opportunity task disables itself; a separate hidden
weekday reset task re-enables it at 9:25 a.m. ET. The position task stays active. The
combined cycle scans news from 9:30, but deterministic
gates prohibit a new entry before 9:50. Day entries stop at
3:30 p.m.; an exact contract eligible for `SWING` may still be entered through 3:50 p.m.
Python wakes Luna/high only for a compact trade-ready candidate or a qualitative position trigger,
with a hard maximum of thirteen total model calls per trading day. A cached `PASS` on the same
contract is held until Python detects a material directional, eligibility, risk, or event change;
unchanged `WAIT` and a
still-valid unchanged `BUY` are cached; operational/data errors never wake a model. Scheduled model reviews have no
broker, research, browser, or social tools. Live submissions/fills/exits, material decisions, data
failures, and route failures raise both
a Windows tray notification and, when `NTFY_TOPIC` is configured, a free hosted ntfy phone push;
alerts lead with the action and exact contract rather than raw JSON. Quiet and Luna-ignored events
remain silent. All phone pushes use normal ntfy priority (3), including errors, fills, and
cancellations; the sender never requests high/urgent priority or repeating urgent alarms.
An exceptional cancellation alert is a request for the
user to cancel the identified order directly in the Robinhood phone app. The system does not call a
broker cancellation tool automatically.

The ntfy topic is stored as a Windows user environment variable rather than in this repository.
Because an anonymous hosted topic acts as its own access secret, use a long random topic and keep
[account details redacted]

Live state is visible in `state/live/SUMMARY.md`; every live review/submission/fill/exit is appended
to `state/live/EVENTS.jsonl`. Full scheduled/model results are appended to dated files in
`state/logs/`, with a compact timeline in `state/logs/ACTIVITY.md`.

Inspect or remove the tasks:

```powershell
Get-ScheduledTask -TaskName "RobinhoodAgentic-*"
powershell -ExecutionPolicy Bypass -File automation\install_tasks.ps1 -Remove
```

## Unusual Whales trial setup

The project-scoped remote MCP entry and deterministic REST client both reference the
`UW_API_KEY` environment variable. Never paste the key into chat or commit it to this repository.
Set it from a local PowerShell terminal without putting the secret in command history:

```powershell
$uwKey = Read-Host "Paste UW API key" -MaskInput
[Environment]::SetEnvironmentVariable("UW_API_KEY", $uwKey, "User")
Remove-Variable uwKey
```

Fully quit and reopen Codex afterward. Check local configuration without making an API request:

```powershell
uv run python -m tools.unusual_whales status
```

During `UW_TRIAL_MODE`, write the pre-UW decision and conviction before any UW query, then record
the post-UW result and what changed. Trial urgency never relaxes setup or risk gates.
