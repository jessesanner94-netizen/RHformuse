# Build Plan

## Target Version 1

A Codex-led day/swing options agent with a cheap first-stage scanner, persistent memory, live Robinhood execution, Vibe research, skfolio risk math, news/social discovery, and optional Unusual Whales flow confirmation.

## Phase 1 — Repository and rules

- Use this repository as the Codex project.
- Confirm Codex reads the root `AGENTS.md`.
- Fill the required `TODO` values in `CONFIG.md` before live trading.
- Keep live execution disabled.

## Phase 2 — Tooling

### Robinhood
Connect Robinhood MCP. It is the source of truth for account state, positions, quotes, chains, order review, and live execution.

### Vibe-Trading
Install/connect Vibe as the main research/quant layer. Prefer its available tools/skills over reinventing finance calculations with LLM prose.

### skfolio
Install as a deterministic Python dependency for portfolio/risk analysis. Use it for portfolio-level risk, concentration, covariance/correlation, CVaR-style analysis, and allocation constraints. It is not the sole options-risk engine.

### Agent Reach / social-news tooling
If Agent Reach is installed and usable, connect it for X/Twitter, Reddit, RSS, and broader discovery. Otherwise use the best available web/news/social tools.

### Unusual Whales
The user activated a one-week API trial on 2026-08-23. Complete and test the read-only integration
immediately, but do not use trial urgency to skip Robinhood connectivity, manual dry runs, or hard
risk gates. Query UW for actual candidates only after recording the pre-UW decision.

## Phase 3 — Small deterministic tools

Have Codex build and test:

- `tools/cheap_scan.py` — rejects weak/liquidity-poor setups before deep LLM reasoning and returns compact candidates.
- `tools/portfolio_risk.py` — uses skfolio + option-specific hard rules.
- `tools/cost_tracker.py` — tracks incremental Codex/API/data cost and economic efficiency.
- `tools/state_manager.py` — safely reconciles/updates persistent state.
- `tools/position_monitor.py` — evaluates position and data-integrity triggers without invoking GPT.
- `tools/robinhood_mcp.py` — performs read-only, model-free Robinhood MCP snapshots for the monitor.

## Phase 4 — Manual dry runs

Run the complete workflow manually many times with live reads and order previews allowed but live placement prohibited.

Test zero-candidate runs, strong candidates, conflicting signals, open-position management, earnings risk, social rumors, stale/missing data, risk-limit states, and Robinhood/project-memory mismatches.

The system must fail closed.

## Phase 5 — Unusual Whales trial

Only after the system is operational:

1. Produce a **pre-UW** decision without seeing UW.
2. Record it.
3. Query UW.
4. Produce a **post-UW** decision.
5. Record what changed and why.
6. Keep a shadow comparison where practical.

Evaluate UW on incremental value, not whether the account happened to be profitable.

## Phase 6 — Small-capital live testing

After user approval, complete risk settings, enable live execution, start at the smallest practical size, and maintain decision/journal/cost attribution.

## Phase 7 — Automation

Add automation only after manual behavior is reliable. Use `prompts/SCHEDULED_RUN_PROMPT.md` as the run instruction and choose cadence based on what the current Codex automation surface supports, measured usage, opportunity frequency, and economic value.

## Later, only if justified

- Kronos as an experimental forecast input after out-of-sample validation.
- NautilusTrader if the project graduates to an always-running event-driven engine.
- More complex multi-leg options after execution support and risk handling are verified.

## Implementation status — 2026-08-23

- Repository staged as the active Codex project; all governing policy and local skill files loaded.
- Live execution remains disabled; production risk `TODO` values were not guessed or changed.
- skfolio and the isolated Python toolchain are installed via `uv` and locked in `uv.lock`.
- Phase 3 utilities are implemented with dry-run defaults and automated tests.
- Vibe-Trading is installed, project-connected, and its MCP server responds with the expected
  research skills.
- Unusual Whales trial mode is enabled. The user-scoped `UW_API_KEY`, project MCP entry, hosted app,
  and deterministic GET-only REST client are present. A live Market Tide smoke test returned
  five-minute data for the latest completed session (2026-08-21).
- Phase 4 has started with offline/manual fixtures covering zero candidates, qualified candidates,
  stale/missing data, hard-risk failures, and broker/project-memory mismatch.
[account details redacted]
  Agentic account, Level 3 options, and no open positions/orders.
- A direct read-only Robinhood OAuth bridge and deterministic position monitor are implemented so
  routine polling can consume zero model tokens. Standalone OAuth and a browser-free live snapshot
  are verified; snapshot-to-position-plan assembly and Windows scheduling remain before automation
  is complete.
- The official standalone Codex CLI is installed and authenticated. Scheduled final decisions now
  use an isolated `gpt-5.6-luna`/high agent with one compact Python-built packet, no research tools,
  a thirteen-call daily ceiling, a material-state cache for same-contract `PASS` decisions, and
  cached `WAIT` plus still-valid `BUY` outcomes.
- The user approved `proposals/SMALL_ACCOUNT_POLICY.md`; its production limits are now resolved in
  `CONFIG.md`. Live execution is approved in configuration, and both Windows tasks were restarted
  after the 2026-08-26 pre-order fix passed its scheduler-context verification.
- The live snapshot-to-position adapter, model-free RSS delta monitor, UW-to-Robinhood contract
  discovery gate, compact Luna decision router, and Windows launchers are implemented. The full
  suite passes 108 tests and lint.
- Persistent paper trading is implemented with conservative refreshed ask-entry/bid-exit fills,
  the approved $369 small-account gates, deterministic two-minute management, structured Sol
  decisions, automatic stops/targets/time exits, P&L summaries, and append-only fill/event logs.
- The final dry-run schedule uses two tasks: position/paper management every 2 minutes and combined
  broad news/social/opportunity discovery every 10 minutes from 9:30–16:00. New-entry gates remain
  9:50–15:30. Triggered models run ephemerally; no-change cycles use no model. Paper fills/exits,
  material decisions, and failures produce Windows notifications and persistent activity records.
- Broad US-market RSS passed a live non-committing smoke. Agent Reach is installed and checked, but
  X/Twitter and Reddit currently have no authenticated backend, so social is explicitly marked
  unavailable until manual setup is completed.
- News is now a direct opportunity source: Luna-escalated headline symbols are resolved through a
  bounded live Robinhood chain query, passed through the normal liquidity/premium gate, and supplied
  to Sol as selectable paper contracts. A live NVDA read-only smoke resolved one chain, 150 active
  instruments, 130 quotes, and fresh underlying/fundamental data without any order interface.

## Live activation status — 2026-08-24

- The user explicitly approved fully unattended one-contract live execution. `CONFIG.md` now has
  `LIVE_EXECUTION_ENABLED: true`, paper mode off, standing unattended authorization, software polling
  stops, and automatic cancellation disabled.
- The executor persists idempotency state before placement, automatically runs and exactly compares
  Robinhood's pre-trade review, fails closed on every broker alert/mismatch, and never exposes a
  cancellation/repricing path.
- Entries use a fresh-ask GFD limit. Stops, the 30% target, and time exits are deterministic Python
  controls calculated from the actual fill and polled every two minutes; exits use reviewed market
  sell-to-close orders. Sol may recommend an earlier thesis/news exit but cannot loosen hard exits.
- Live submissions/fills/exits update `state/live/`, `state/POSITIONS.md`, `state/DAILY_STATE.md`, and
  the append-only journals, and produce material Windows notifications.
- A real Robinhood review-only smoke passed with an exact request match and empty alerts. A live-mode
[account details redacted]
- The full deterministic suite passes 94 tests and lint. Both Windows tasks are ready for 2026-08-25
  09:30 ET; wake-to-run is enabled and the Windows user must remain logged in.
