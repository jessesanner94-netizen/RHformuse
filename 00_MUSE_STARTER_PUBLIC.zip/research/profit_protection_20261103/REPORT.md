# Profit Protection Replay — 2026-11-03

## Scope

This is a research-only replay of the fixed stop/target exit and several profit-protection ideas. It does not change the live bot, paper bot, configuration, or strategy files.

The replay uses nine archived paper trade episodes from October 22 through November 3, with Robinhood monitor bid snapshots for the option contracts and Alpaca SIP one-minute SPY bars. The 3-minute bars are aggregated from those one-minute bars. The nine baseline simulations reproduce the paper event log's realized net P&L exactly: **-$106.90** across **3 winners and 6 losers**. This confirms the quote paths and fee arithmetic for the tested exits.

The baseline keeps the current 25% option-premium stop and 30% target. Protective rules arm after the option's observed bid reaches +10%, +15%, or +20% from the ask fill. Once armed, the rule adds a fee-adjusted breakeven floor; trailing variants raise that floor to 10%, 15%, or 20% below the best observed bid. Indicator variants keep the breakeven floor and exit on the first observed bid after a fully closed SPY bar shows adverse direction.

Indicators tested on both 1-minute and 3-minute bars:

- EMA 9/21 trend state
- RSI 14 relative to 50
- Supertrend (ATR 10, multiplier 3)
- Price relative to session VWAP

For calls, adverse states are EMA 9 below EMA 21, RSI below 50, bearish Supertrend, or SPY below VWAP. The direction is reversed for puts. One contract is assumed, with entry at the recorded ask, exits at the observed bid, and $1.05 estimated fees on each side. The breakeven floor is rounded up to the next $0.01 premium tick.

## Today's live SPY call

The live state records one SPY 765 call expiring November 5: entry **$1.54** at 10:50:53 ET, best observed bid **$1.86** (about +20.8% before fees), and stop exit **$1.15** at 2:55:21 ET, for **-$41.10** net. The 30% target was $2.002 and was not reached.

The paper monitor captured 1,509 quotes for this same option contract. Replaying the live fill against that quote path gives these illustrative exits:

| Rule | Hypothetical exit (ET) | Bid | Estimated net P&L |
|---|---:|---:|---:|
| Actual fixed stop | 2:55:21 pm | $1.15 | -$41.10 |
| Net breakeven floor, armed at +10% or +15% | 11:21:31 am | $1.57 | +$0.90 |
| 10% trailing giveback, armed at +10% or +15% | 11:18:40 am | $1.61 | +$4.90 |
| 1-minute RSI 14/50, armed at +10% | 11:19:00 am | $1.67 | +$10.90 |
| 3-minute Supertrend 10/3, armed at +10% | 10:59:37 am | $1.73 | +$16.90 |
| Net breakeven floor, armed at +20% | 1:54:16 pm | $1.55 | -$1.10 |

These are sampled-quote replays, not guaranteed fills. In particular, a stop intended to lock breakeven can fill below its threshold when the bid moves between observations. Using the paper fill of $1.56 on the same contract, the observed $1.57 bid would still have been about **-$1.10 net** after the modeled round-trip fees. The actual live fill was lower, so that same bid is modeled at +$0.90.

The 20% activation was late: the live option only just exceeded it near its peak. The paper fill of $1.56 never reached +20% at all, despite this contract later reaching $1.86. That difference shows how a small entry-fill difference can change whether a threshold activates.

## Results across the nine paper episodes

| Exit rule | Net P&L | Change vs fixed exits | Winners | Baseline losers at/above breakeven |
|---|---:|---:|---:|---:|
| Fixed 25% stop / 30% target | -$106.90 | — | 3/9 (33.3%) | 0 |
| Breakeven floor after +10% | -$65.90 | +$41.00 | 3/9 (33.3%) | 1 |
| 10% trailing giveback after +10% | -$56.90 | +$50.00 | 4/9 (44.4%) | 2 |
| 15% trailing giveback after +10% | -$65.90 | +$41.00 | 3/9 (33.3%) | 1 |
| RSI 14/50 on 1-minute bars after +10% | -$55.90 | +$51.00 | 4/9 (44.4%) | 2 |
| EMA 9/21 on 3-minute bars after +10% | -$52.90 | +$54.00 | 3/9 (33.3%) | 1 |
| Supertrend 10/3 on 3-minute bars after +10% | -$36.90 | +$70.00 | 4/9 (44.4%) | 2 |
| Supertrend 10/3 on 1-minute bars after +15% | **-$22.90** | **+$84.00** | 4/9 (44.4%) | 1 |

The best result in this small sample still loses money. Profit protection reduced the losses, but it also exited a baseline winner early: for example, the +10% breakeven and trailing rules closed the October 26 call around its entry price before it reached its 30% target. The top Supertrend result likewise cut that winner from about +$32.90 to +$17.90 net. This is the central tradeoff: retaining less of a winning trade's giveback can also discard part of its eventual gain.

No indicator or threshold is selected as a production rule from these nine trades. The sample is too small, covers one underlying over a short window, and includes paper runs from different research experiment copies. It is useful for narrowing ideas, not for claiming an edge.

## Data and limits

- Option bid snapshots: archived paper-monitor `MONITOR.jsonl` records, deduplicated by contract and entry time across three forward research runs.
- Underlying prices: 3,448 SPY one-minute regular-session bars from Alpaca SIP, covering the nine trade dates.
- Quote sample frequency is about every 10 seconds, not a complete option trade tape. A stop can cross between samples.
- Robinhood historical option bars were unavailable in the saved monitoring requests; actual observed bid snapshots are used instead.
- Indicator signals only use completed candles and are executed at the next available option bid snapshot. Slippage, order latency, market impact, and partial fills beyond the observed bid are not modeled.
- Vibe's available vectorized backtester accepts equity/crypto data sources, not these saved option-contract quote paths. A direct quote replay was used to measure option P&L rather than substitute SPY share returns.

## Reproduction files

- `run_backtest.py` — replay and indicator logic
- `variant_summary.csv` — aggregate exit-rule comparison
- `trade_details.csv` — one row per strategy and trade
- `baseline_audit.csv` — replay-versus-recorded baseline check
- `results.json` — run metadata and the separate November 3 live-entry replay
- `data/spy_rth_1m.csv.gz` — underlying one-minute data used in the replay
