#!/usr/bin/env python3
"""Research-only replay of sampled paper option quote paths and profit exits."""

from __future__ import annotations

import bisect
import csv
import gzip
import json
import math
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BAR_FILE = OUT / "data" / "spy_rth_1m.csv.gz"
EXPERIMENTS = [
    "rsi_priority_20261022",
    "session_expiry_20261025",
    "volatility_labels_20261031",
]
FEE_PER_SIDE = 1.05
CONTRACT_MULTIPLIER = 100
TICK = 0.01


def parse_dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def read_jsonl(path: Path):
    with path.open() as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def load_quotes():
    quotes_by_contract = defaultdict(list)
    entries = {}
    exits = {}
    for experiment in EXPERIMENTS:
        base = ROOT / "research" / "options_lab" / "experiments" / experiment / "forward"
        monitor = base / "MONITOR.jsonl"
        events = base / "accounts" / "paper" / "state" / "options" / "python_jev_green_lock_20261009" / "paper" / "EVENTS.jsonl"
        for row in read_jsonl(monitor):
            seen_at = row.get("as_of")
            if not seen_at:
                continue
            for item in row.get("quote_refresh", {}).get("option_quotes", []):
                quote = item.get("quote", {})
                contract = quote.get("instrument_id") or item.get("close", {}).get("instrument_id")
                bid = quote.get("bid_price")
                if contract and bid not in (None, ""):
                    quotes_by_contract[contract].append({
                        "timestamp": seen_at,
                        "bid": float(bid),
                        "ask": float(quote["ask_price"]) if quote.get("ask_price") not in (None, "") else None,
                    })
        for event in read_jsonl(events):
            if event.get("event") == "PAPER_ENTRY":
                entries[event["paper_id"]] = event
            elif event.get("event") == "PAPER_EXIT":
                exits[event["paper_id"]] = event

    candidates = {}
    for paper_id, entry in entries.items():
        exit_event = exits.get(paper_id)
        if not exit_event:
            continue
        contract = entry.get("contract_identifier")
        start = parse_dt(entry["timestamp"])
        end = parse_dt(exit_event["timestamp"])
        tape = [q for q in quotes_by_contract.get(contract, []) if start <= parse_dt(q["timestamp"]) <= end]
        tape.sort(key=lambda q: q["timestamp"])
        trade = {
            "paper_id": paper_id,
            "contract": contract,
            "symbol": entry.get("symbol"),
            "option_type": entry.get("option_type"),
            "strike": entry.get("strike"),
            "expiration": entry.get("expiration"),
            "quantity": int(entry.get("quantity", 1)),
            "entry_at": entry["timestamp"],
            "entry_price": float(entry["fill_price"]),
            "exit_at": exit_event["timestamp"],
            "exit_price": float(exit_event["fill_price"]),
            "exit_reason": exit_event.get("exit_reason", "UNKNOWN"),
            "reported_net_pnl": float(exit_event.get("realized_pnl", 0.0)),
            "stop": float(entry.get("net_reward_risk", {}).get("stop_price", float(entry["fill_price"]) * 0.75)),
            "target": float(entry.get("net_reward_risk", {}).get("take_profit_price", float(entry["fill_price"]) * 1.30)),
            "quotes": tape,
        }
        key = (contract, entry["timestamp"])
        if key not in candidates or len(tape) > len(candidates[key]["quotes"]):
            candidates[key] = trade
    return sorted(candidates.values(), key=lambda t: t["entry_at"])


def load_bars():
    by_day = defaultdict(list)
    with gzip.open(BAR_FILE, "rt", newline="") as f:
        for row in csv.DictReader(f):
            ts = parse_dt(row["timestamp"])
            by_day[ts.date().isoformat()].append({
                "ts": ts,
                "open": float(row["open"]),
                "high": float(row["high"]),
                "low": float(row["low"]),
                "close": float(row["close"]),
                "volume": float(row["volume"]),
            })
    for bars in by_day.values():
        bars.sort(key=lambda b: b["ts"])
    return by_day


def resample_three_minutes(bars):
    out = []
    for i in range(0, len(bars) - 2, 3):
        block = bars[i:i + 3]
        if len(block) != 3:
            continue
        out.append({
            "ts": block[0]["ts"],
            "close_ts": block[-1]["ts"] + timedelta(minutes=1),
            "open": block[0]["open"],
            "high": max(x["high"] for x in block),
            "low": min(x["low"] for x in block),
            "close": block[-1]["close"],
            "volume": sum(x["volume"] for x in block),
        })
    return out


def indicator_states(bars):
    n = len(bars)
    closes = [b["close"] for b in bars]
    ema9, ema21 = [], []
    for period, target in ((9, ema9), (21, ema21)):
        alpha = 2.0 / (period + 1.0)
        value = None
        for price in closes:
            value = price if value is None else alpha * price + (1.0 - alpha) * value
            target.append(value)

    rsi = [None] * n
    gains, losses = [], []
    for i in range(1, n):
        change = closes[i] - closes[i - 1]
        gains.append(max(change, 0.0))
        losses.append(max(-change, 0.0))
        if i == 14:
            avg_gain = sum(gains) / 14.0
            avg_loss = sum(losses) / 14.0
        elif i > 14:
            avg_gain = (avg_gain * 13.0 + gains[-1]) / 14.0
            avg_loss = (avg_loss * 13.0 + losses[-1]) / 14.0
        else:
            continue
        rsi[i] = 100.0 if avg_loss == 0 else 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)

    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["high"] - b["low"])
        else:
            prev = closes[i - 1]
            trs.append(max(b["high"] - b["low"], abs(b["high"] - prev), abs(b["low"] - prev)))
    atr = [None] * n
    if n >= 10:
        atr[9] = sum(trs[:10]) / 10.0
        for i in range(10, n):
            atr[i] = (atr[i - 1] * 9.0 + trs[i]) / 10.0
    supertrend = [None] * n
    final_upper = [None] * n
    final_lower = [None] * n
    for i in range(n):
        if atr[i] is None:
            continue
        midpoint = (bars[i]["high"] + bars[i]["low"]) / 2.0
        upper = midpoint + 3.0 * atr[i]
        lower = midpoint - 3.0 * atr[i]
        if i == 9:
            final_upper[i], final_lower[i] = upper, lower
            supertrend[i] = 1 if closes[i] >= midpoint else -1
            continue
        prev_upper, prev_lower = final_upper[i - 1], final_lower[i - 1]
        prev_close = closes[i - 1]
        final_upper[i] = upper if upper < prev_upper or prev_close > prev_upper else prev_upper
        final_lower[i] = lower if lower > prev_lower or prev_close < prev_lower else prev_lower
        prev_direction = supertrend[i - 1]
        if prev_direction == -1 and closes[i] > final_upper[i]:
            supertrend[i] = 1
        elif prev_direction == 1 and closes[i] < final_lower[i]:
            supertrend[i] = -1
        else:
            supertrend[i] = prev_direction

    cum_pv = cum_volume = 0.0
    vwap = []
    for b in bars:
        typical = (b["high"] + b["low"] + b["close"]) / 3.0
        cum_pv += typical * b["volume"]
        cum_volume += b["volume"]
        vwap.append(cum_pv / cum_volume if cum_volume else typical)

    states = {}
    for i, b in enumerate(bars):
        close_ts = b.get("close_ts", b["ts"] + timedelta(minutes=1))
        states[close_ts] = {
            "EMA_9_21": (ema9[i] < ema21[i], ema9[i] > ema21[i]),
            "RSI14_50": (rsi[i] is not None and rsi[i] < 50.0, rsi[i] is not None and rsi[i] > 50.0),
            "SUPERTREND_10_3": (supertrend[i] == -1, supertrend[i] == 1),
            "VWAP": (closes[i] < vwap[i], closes[i] > vwap[i]),
        }
    return states


def make_timeline(states):
    times = sorted(states)
    return times, [states[t] for t in times]


def adverse_state(timeline, at, indicator, option_type):
    times, values = timeline
    index = bisect.bisect_right(times, at) - 1
    if index < 0:
        return False
    call_adverse, put_adverse = values[index][indicator]
    return call_adverse if option_type == "CALL" else put_adverse


def net_be_price(entry):
    raw = entry + 2.0 * FEE_PER_SIDE / CONTRACT_MULTIPLIER
    return math.ceil((raw - 1e-10) / TICK) * TICK


def pnl(entry, exit_price, quantity):
    return (exit_price - entry) * CONTRACT_MULTIPLIER * quantity - 2.0 * FEE_PER_SIDE * quantity


def simulate(trade, timelines, activation=None, trail=None, indicator=None, entry_override=None, stop_override=None, target_override=None, fallback=None):
    entry = float(entry_override if entry_override is not None else trade["entry_price"])
    quantity = int(trade.get("quantity", 1))
    stop = float(stop_override if stop_override is not None else trade["stop"])
    target = float(target_override if target_override is not None else trade["target"])
    high_water = entry
    armed = False
    for quote in trade["quotes"]:
        at = parse_dt(quote["timestamp"])
        bid = quote["bid"]
        if bid <= 0:
            continue
        if bid >= target:
            return {"exit_at": quote["timestamp"], "exit_price": bid, "reason": "TAKE_PROFIT", "pnl": pnl(entry, bid, quantity), "triggered": False}
        high_water = max(high_water, bid)
        if activation is None:
            if bid <= stop:
                return {"exit_at": quote["timestamp"], "exit_price": bid, "reason": "BASE_STOP", "pnl": pnl(entry, bid, quantity), "triggered": False}
            continue
        if high_water >= entry * (1.0 + activation):
            armed = True
        if armed:
            protective_floor = net_be_price(entry)
            protective_reason = "NET_BE"
            if trail is not None:
                protective_floor = max(protective_floor, high_water * (1.0 - trail))
                protective_reason = "TRAIL_" + str(int(trail * 100))
            if bid <= protective_floor:
                return {"exit_at": quote["timestamp"], "exit_price": bid, "reason": protective_reason, "pnl": pnl(entry, bid, quantity), "triggered": True}
            if indicator:
                timeline = timelines.get((at.date().isoformat(), indicator["timeframe"]))
                if timeline and adverse_state(timeline, at, indicator["name"], trade["option_type"]):
                    return {"exit_at": quote["timestamp"], "exit_price": bid, "reason": indicator["name"] + "_" + indicator["timeframe"], "pnl": pnl(entry, bid, quantity), "triggered": True}
        elif bid <= stop:
            return {"exit_at": quote["timestamp"], "exit_price": bid, "reason": "BASE_STOP", "pnl": pnl(entry, bid, quantity), "triggered": False}

    end = fallback or {"exit_at": trade["exit_at"], "exit_price": trade["exit_price"], "reason": trade["exit_reason"]}
    return {"exit_at": end["exit_at"], "exit_price": float(end["exit_price"]), "reason": end["reason"], "pnl": pnl(entry, float(end["exit_price"]), quantity), "triggered": False}


def summarize(results, label):
    values = [r["pnl"] for r in results]
    baseline_losses = sum(r["baseline_pnl"] < 0 for r in results)
    loss_to_win = sum(r["baseline_pnl"] < 0 <= r["pnl"] for r in results)
    return {
        "variant": label,
        "trades": len(results),
        "wins": sum(x > 0 for x in values),
        "win_rate_pct": round(100.0 * sum(x > 0 for x in values) / len(values), 1) if values else 0.0,
        "net_pnl": round(sum(values), 2),
        "delta_vs_baseline": round(sum(values) - sum(r["baseline_pnl"] for r in results), 2),
        "protective_exits": sum(r["triggered"] for r in results),
        "baseline_losers_to_nonnegative": loss_to_win,
        "avg_pnl": round(sum(values) / len(values), 2) if values else 0.0,
    }


def main():
    trades = load_quotes()
    bars_by_day = load_bars()
    timelines = {}
    for day, bars in bars_by_day.items():
        timelines[(day, "1m")] = make_timeline(indicator_states(bars))
        timelines[(day, "3m")] = make_timeline(indicator_states(resample_three_minutes(bars)))

    # Keep only complete, adequately sampled trade paths and document excluded episodes.
    usable = [t for t in trades if len(t["quotes"]) >= 20]
    variants = [("BASELINE", None, None, None)]
    for activation in (0.10, 0.15, 0.20):
        variants.append((f"NET_BE_{int(activation*100)}", activation, None, None))
    for activation in (0.10, 0.15, 0.20):
        for giveback in (0.10, 0.15, 0.20):
            variants.append((f"TRAIL_{int(activation*100)}_GIVEBACK_{int(giveback*100)}", activation, giveback, None))
    indicators = ["EMA_9_21", "RSI14_50", "SUPERTREND_10_3", "VWAP"]
    for activation in (0.10, 0.15, 0.20):
        for timeframe in ("1m", "3m"):
            for name in indicators:
                variants.append((f"{name}_{timeframe}_AFTER_{int(activation*100)}", activation, None, {"name": name, "timeframe": timeframe}))

    summaries = []
    detail_rows = []
    results_by_variant = {}
    for label, activation, trail, indicator in variants:
        results = []
        for trade in usable:
            result = simulate(trade, timelines, activation, trail, indicator)
            base_pnl = trade["reported_net_pnl"]
            results.append({**result, "baseline_pnl": base_pnl})
            detail_rows.append({
                "variant": label,
                "paper_id": trade["paper_id"],
                "entry_at": trade["entry_at"],
                "option_type": trade["option_type"],
                "entry_price": trade["entry_price"],
                "max_bid": max((q["bid"] for q in trade["quotes"]), default=None),
                "quote_samples": len(trade["quotes"]),
                "baseline_reason": trade["exit_reason"],
                "baseline_net_pnl": base_pnl,
                "sim_exit_at": result["exit_at"],
                "sim_exit_price": round(result["exit_price"], 4),
                "sim_reason": result["reason"],
                "sim_net_pnl": round(result["pnl"], 2),
                "protective_triggered": result["triggered"],
            })
        results_by_variant[label] = results
        summaries.append(summarize(results, label))

    baseline_sim = results_by_variant["BASELINE"]
    baseline_audit = []
    for trade, result in zip(usable, baseline_sim):
        baseline_audit.append({
            "paper_id": trade["paper_id"],
            "event_exit": trade["exit_price"],
            "replay_exit": result["exit_price"],
            "event_net": trade["reported_net_pnl"],
            "replay_net": result["pnl"],
            "quote_samples": len(trade["quotes"]),
        })

    summaries.sort(key=lambda x: (x["net_pnl"], x["win_rate_pct"]), reverse=True)
    for filename, rows in (("variant_summary.csv", summaries), ("trade_details.csv", detail_rows), ("baseline_audit.csv", baseline_audit)):
        if not rows:
            continue
        with (OUT / filename).open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    # Replay the actual Nov. 3 live entry separately: its actual premium fill and stop differ slightly from paper.
    live_trade = next((t for t in trades if t["entry_at"].startswith("2026-11-03")), None)
    live_result = None
    if live_trade:
        state_path = ROOT / "state" / "options" / "python_jev_green_lock_20261009" / "live" / "STATE.json"
        live_state = json.loads(state_path.read_text())
        live_position = next(p for p in live_state.get("recent_closed_positions", []) if p.get("entry_at", "").startswith("2026-11-03"))
        live_trade = {**live_trade, "quotes": [q for q in live_trade["quotes"] if parse_dt(q["timestamp"]) >= parse_dt(live_position["entry_at"])]}
        live_fallback = {"exit_at": live_position["exit_at"], "exit_price": live_position["exit_price"], "reason": "LIVE_" + live_position["exit_reason"]}
        live_result = {}
        live_stop, live_target, live_entry = live_position["stop_price"], live_position["take_profit_price"], live_position["entry_price"]
        for activation in (0.10, 0.15, 0.20):
            key = f"NET_BE_{int(activation*100)}"
            live_result[key] = simulate(live_trade, timelines, activation, entry_override=live_entry, stop_override=live_stop, target_override=live_target, fallback=live_fallback)
            for giveback in (0.10, 0.15, 0.20):
                key = f"TRAIL_{int(activation*100)}_GIVEBACK_{int(giveback*100)}"
                live_result[key] = simulate(live_trade, timelines, activation, giveback, entry_override=live_entry, stop_override=live_stop, target_override=live_target, fallback=live_fallback)
            for timeframe in ("1m", "3m"):
                for name in indicators:
                    key = f"{name}_{timeframe}_AFTER_{int(activation*100)}"
                    live_result[key] = simulate(live_trade, timelines, activation, indicator={"name": name, "timeframe": timeframe}, entry_override=live_entry, stop_override=live_stop, target_override=live_target, fallback=live_fallback)

    meta = {
        "paper_trade_count_total": len(trades),
        "paper_trade_count_with_20plus_quotes": len(usable),
        "quote_count_by_trade": {t["paper_id"]: len(t["quotes"]) for t in trades},
        "indicator_days": sorted(bars_by_day),
        "minute_bars": sum(len(x) for x in bars_by_day.values()),
        "three_minute_bars": sum(len(resample_three_minutes(x)) for x in bars_by_day.values()),
        "baseline_actual_net_total": round(sum(t["reported_net_pnl"] for t in usable), 2),
        "baseline_replay_net_total": round(sum(x["pnl"] for x in baseline_sim), 2),
        "baseline_audit": baseline_audit,
        "live_nov3_replay": live_result,
        "top_12_variants_by_net_pnl": summaries[:12],
        "limitations": [
            "Small, recent, single-underlying sample; exploratory only.",
            "Option prices are sampled bid quotes from paper monitoring, not a complete exchange trade tape.",
            "Historical option bars were unavailable from the Robinhood historical endpoint; the logged quote snapshots are used instead.",
            "Indicator exits use the first sampled option bid after a fully closed underlying candle signals; no additional latency or market impact is modeled.",
            "3-minute bars are aligned to the regular-session open and aggregated from 1-minute bars.",
        ],
    }
    (OUT / "results.json").write_text(json.dumps(meta, indent=2) + "\n")
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
