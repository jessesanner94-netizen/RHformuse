# Backtesting Chat Prompt: Profit Protection and Stop Management

Copy the prompt below into a new project chat dedicated to backtesting. It is research-only: do not change the live or paper bot.

---

## Prompt

I want this chat to focus only on careful backtesting of exit management for our Robinhood options strategy. The goal is to study whether we can keep trades that have made a meaningful open profit from turning into losses, while preserving enough room for strong winners to reach the existing take-profit. This is an experiment, not authorization to change any running bot or strategy setting.

### Project and strategy context

This project uses a multi-stage options workflow. Python performs the deterministic scanning, eligibility and risk checks, and final selection. JEV may rank candidates, but it does not have authority to veto a trade. For this study, hold the existing entries and direction decisions constant. We are studying exits only.

The current trade management baseline is generally a **+30% option-premium take-profit** and **-25% stop-loss** from entry. Verify the current implementation and cost policy from the repository before treating those values as authoritative. We generally want at least a **1:1 reward-to-risk ratio**, preferably calculated after fees and realistic execution assumptions. A nominal +30% target against a -25% stop is a 1.2:1 gross ratio, but fees, spread, and slippage can reduce the realized ratio.

The idea to test is:

1. Keep the current initial stop active from entry.
2. If the option's executable value reaches a defined profit activation level, test using a confirmed indicator reversal to exit before the ordinary +30% target gives back too much.
3. Compare indicator exits with protective profit floors, including a net breakeven floor and modest locked-profit floors, to see whether the indicator alone can still allow a winner to become a loser.
4. Separately compare tighter initial stops with the current stop.

The user's main indicator ideas are **1-minute Supertrend** and **1-minute Ichimoku**, with **3-minute versions** included for comparison. The Ichimoku idea is a fully confirmed reversal against the position, not a mere touch: the baseline/cloud relationship or leading spans should cross against the trade and separate by a configurable amount. Test a small, predeclared set of sensible definitions and thresholds, and explain them in plain language before interpreting results.

### Important facts from the prior replay

Read `research/profit_protection_20261103/REPORT.md` and its supporting files before doing more work. That prior replay is useful starting evidence, not a production recommendation:

- It replayed **nine archived paper-trading episodes**, from October 22 through November 3, not the complete live-bot history. Its baseline was 3 winners and 6 losers (3/9, 33.3%) and -$106.90 net. This result does **not** establish the live bot's win rate.
- The prior sample covered one underlying over a short period and included different paper experiment copies. Its best tested variant was still negative. Do not promote a rule based on that small sample.
- The November 3 live SPY 765 call expiring November 5 entered at $1.54. Its best observed option bid was $1.86, or about **+20.8%** before fees. The +30% target was $2.002. Therefore, based on the quote path already reviewed, this trade **did not reach +25%** and a rule that activates at +25% would not have triggered. Do not describe it as an example of a +25%-activated signal unless new verified quote data changes this fact.
- The prior replay tested some 1-minute and 3-minute EMA, RSI, Supertrend, and VWAP exits, mostly activated at +10%, +15%, or +20%; it did not establish the proposed +25% Ichimoku/Supertrend rule.
- Relevant starting artifacts: `research/profit_protection_20261103/run_backtest.py`, `variant_summary.csv`, `trade_details.csv`, `baseline_audit.csv`, `results.json`, and `data/spy_rth_1m.csv.gz`.

### First task: reconcile the win-rate discrepancy

Before making new performance claims, calculate the live bot's actual closed-trade win rate from canonical records. The user believes the live bot is around 50%, while the prior report showed 3/9. Resolve the apparent difference with separate, auditable counts:

- Live bot versus each paper bot and each research experiment copy.
- Strategy/configuration epochs and date ranges.
- Unique closed positions/trades, not individual fills, quote samples, or duplicate monitor rows.
- Net realized P&L after the appropriate fees, with partial exits handled consistently.
- Wins, losses, and breakeven trades, with the exact definition and denominator stated.
- Open trades reported separately, not silently counted as wins or losses.

Start with the canonical live state and journal, including `state/live/STATE.json`, `journal/TRADES.md`, and `state/DAILY_STATE.md`; inspect other authoritative records as needed. Reconcile discrepancies between records instead of selecting whichever number looks most plausible. Explicitly explain that the prior 3/9 result was the archived-paper backtest sample if that remains what the files show. Do not assume the user's estimated live win rate is exact; verify it.

### Backtest plan

Use identical historical entries across exit variants so every comparison is paired. Do not change entries, direction, candidate selection, sizing, or trade dates to make an exit rule look better. Include all eligible trades in the selected dataset and show exclusions with reasons.

#### A. Validate and document the baseline

- Reproduce the recorded baseline P&L from the raw trade/quote records before adding variants.
- State which records provide entry time, fill price, contract, bid/ask path, stop/target, exit, and fees.
- Reconcile each reproduced baseline trade against its recorded outcome. Investigate any mismatch before relying on variant results.
- Clearly label live executions, paper executions, and simulated replay rows. Never mix their denominators or present paper performance as live performance.

#### B. Initial-stop sensitivity

Compare the current stop with a small, predeclared tighter-stop grid, for example **-25%, -20%, -15%, and -10%** from entry, retaining the current +30% target initially. Verify the actual configured stop before fixing this grid. For every stop/target pair, report the net reward-to-risk ratio after fees and modeled spread/slippage; flag any pair that falls below the user's usual 1:1 minimum. Also show if a tighter stop increases stop-outs before a later recovery or target.

Do not recommend a stop solely because it raises win rate. Compare net expectancy, average win/loss, profit factor, drawdown, total net P&L, and the distribution of outcomes.

#### C. Profit-protection activation and floor sensitivity

Test the proposed **+25% open-profit activation**. Also test a small sensitivity set around it, such as +20% and +25%, only if the available sample supports a meaningful comparison. Keep the current +30% take-profit as the hard target/fallback unless testing a clearly labeled alternative.

For each eligible indicator rule, compare at least these management variants:

1. **Indicator exit only:** after activation, exit when a confirmed adverse indicator signal occurs; retain the existing initial stop and +30% target.
2. **Indicator plus net breakeven floor:** after activation, do not intentionally allow a loss at the planned threshold; model a floor that covers entry and round-trip costs.
3. **Indicator plus locked-profit floor:** after activation, test one or two modest net-profit floors (for example +5% and +10% of entry premium) to measure the tradeoff between protecting a gain and being stopped by ordinary noise.
4. **Trailing reference comparison:** include one reasonable trailing-giveback rule as a comparator, since prior work tested trailing exits and the requested idea is to compare indicators with that approach.

Be precise about what a “floor” means. A threshold is not a guaranteed fill: if the option bid gaps through it between observations, use the next executable bid and report the shortfall. Do not claim that a stop can guarantee a non-losing exit in a fast market.

#### D. Indicators and timeframes

At minimum test **1-minute and 3-minute** completed underlying candles for:

- **Supertrend:** begin with the prior replay's ATR 10 / multiplier 3 settings for comparability; include only a small, justified sensitivity if sample size permits.
- **Ichimoku:** begin with standard 9/26/52 periods unless repository conventions specify otherwise. Define separate, understandable signal variants rather than treating “Ichimoku flip” as one ambiguous rule. Candidate definitions may include a confirmed Tenkan/Kijun cross against the option direction, a confirmed price/Kijun cross, and a confirmed Senkou Span A/B cloud twist against the direction with a minimum separation threshold.

For the Ichimoku leading spans, test a small threshold grid expressed in a scale-aware way (for example basis points of underlying price or a fraction of ATR) and state the chosen values before viewing comparative results. Require completed-bar confirmation; where appropriate, compare one-bar and two-bar confirmation. A mere touch or a single transient cross should not count if the rule is defined as requiring separation.

Calculate Senkou spans only from information available at that time. Ichimoku plots leading spans forward visually; do not use future values or a forward-shifted chart location in a way that leaks future data into the signal. All indicators must use completed candles, and an exit may occur only at the next available option quote after the signal is knowable.

You may include previously tested EMA 9/21, RSI 14/50, and VWAP as reference comparators if they can be reproduced cleanly. Keep the main focus on Supertrend and Ichimoku and avoid a large parameter search that overfits the small sample.

### Data and execution assumptions

Use historical quotes for the **same option contracts** wherever possible. For long calls/puts, model entry from the actual fill (or the recorded ask if no fill exists) and exits using the next available executable bid. Preserve timestamps, quote freshness, and market-session boundaries. Use conservative, explicitly stated assumptions for fees, slippage, latency, and fills; verify costs against project policy and recorded executions rather than blindly copying a prior estimate.

The prior monitor archive has option bid snapshots sampled about every 10 seconds, not a complete trade tape. Treat resulting stop/indicator fills as sampled-quote estimates. State that a threshold may be crossed between observations. Do not substitute SPY share returns for option-contract P&L. Underlying 1-minute/3-minute candles can determine indicator signals, but option quote paths must determine option exits and returns.

If a trade lacks its option quote path, exact contract, clean entry fill, or required underlying candles, mark it unavailable and explain why. Do not invent expired-option prices or infer an option's exact return from the underlying. If the complete historical live option data is unavailable, say which research is still possible and keep live-trade audit separate from paper quote-path backtesting.

Prevent lookahead and survivorship bias: use only data available by each decision timestamp, preserve the original selected trades, and do not pick thresholds after inspecting all outcomes. If the data volume permits, use chronological development/test splits or walk-forward evaluation. Show sample sizes and uncertainty; do not imply statistical confidence from a handful of trades.

### Required result tables and interpretation

For every variant, report at least:

- Trade count and data coverage.
- Wins, losses, breakevens, and win rate with denominator.
- Total and average net P&L after costs; average win and average loss.
- Expectancy per trade, profit factor, and maximum drawdown (include mark-to-market drawdown while trades are open when data permits).
- Realized reward-to-risk and whether the 1:1 minimum is met after costs.
- How many baseline losers became breakeven/profitable, and how many baseline winners were cut short.
- Exit reason, activation time/price, signal time, executable exit quote, and threshold overshoot for each trade.
- Paired change in P&L versus the unchanged baseline, both by trade and in aggregate.

Show live and paper results separately. Show overall results and a per-trade table so the user can see exactly which trades changed and why. Discuss whether results depend on one outlier, one date, one paper experiment, or one indicator timeframe. Prefer robust behavior across trades and dates over the best single aggregate number.

### Operating boundaries

- Read the project `AGENTS.md` and required strategy, risk, execution, data-source, state, and skill files before using project or market tools. Read `state/LESSONS.md` for this strategy evaluation.
- This work is **backtesting and research only**. Do not place orders, change a live or paper bot, edit its configuration, alter core policy, stop/start services, or write simulated results into the live ledger.
- Write code, data extracts, and reports only in an isolated research directory. Do not change production strategy files. Any proposed production change must be presented separately with evidence and wait for explicit user approval.
- Use the available historical market-data/backtesting tools where they fit, but verify that they support the actual option quote paths. Prefer a transparent option-quote replay over an equity-only backtester that cannot represent the contracts.
- Do not ask for approval to perform the research described here; it is already authorized. Ask only if an essential data definition cannot be resolved from the repository, and continue independent read-only work meanwhile.

### Final deliverables

1. A concise report explaining the win-rate reconciliation, data provenance, assumptions, test design, results, limitations, and what the evidence does or does not support.
2. A CSV or equivalent row-level comparison of every trade under each exit rule.
3. A machine-readable aggregate summary and reproducible script/notebook in the isolated research directory.
4. A clear statement that no bot behavior was changed.
5. A short, evidence-based recommendation for what to test next. Do not call a rule production-ready based on a tiny sample, and do not modify the bot as part of this task.

Start by inspecting the existing report and source records, then reconcile the live win-rate denominator and verify the baseline before extending the backtest.

---
