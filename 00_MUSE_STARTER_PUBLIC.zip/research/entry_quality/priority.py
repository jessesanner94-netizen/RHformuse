"""User-approved paper RSI priority. It never creates qualification or edits JEV scores."""

RSI_PRIORITY_POLICY = {
    "mode": "SUPPORT_THEN_NEUTRAL_THEN_OPPOSE_THEN_JEV",
    "divergence_required": False,
    "hard_gate_override": False,
    "unavailable_or_conflicting_evidence": "NEUTRAL",
    "weights_are_calibrated_probabilities": False,
}


def rsi_priority(candidate, review):
    """Return +1/0/-1 before the unchanged JEV ranking, using confirmed evidence only."""
    if review.get("status") != "OK":
        return 0
    side = str(candidate.get("option_type", "")).upper()
    if side not in {"CALL", "PUT"}:
        return 0
    kinds = {item.get("kind") for item in review.get("latest_confirmed_divergences", [])}
    bullish = bool(kinds & {"regular_bullish", "hidden_bullish"})
    bearish = bool(kinds & {"regular_bearish", "hidden_bearish"})
    if bullish == bearish:
        return 0
    supported = bullish if side == "CALL" else bearish
    return 1 if supported else -1
