"""Point-in-time RSI divergence context; UNVALIDATED paper research, never an entry gate.

Price extrema use strict left/right neighbors. RSI is sampled at each price pivot's
close, not independently pivoted. Each kind retains only its latest confirmed pair.
"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from datetime import datetime
from statistics import mean
from typing import Any

from research.options_lab.event_tape import ET, number, timestamp, validate

SOURCE = "yahoo"
VENUE = "CONSOLIDATED_UNVERIFIED"
DEFAULT_PERIOD = 14
DEFAULT_PIVOT_LEFT = 2
DEFAULT_PIVOT_RIGHT = 2
DEFAULT_MAX_BAR_AGE_SECONDS = 90
DEFAULT_MAX_PIVOT_AGE_SECONDS = 300


def _integer(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{name} must be a positive integer")


def rsi_values(closes: Sequence[float], period: int = DEFAULT_PERIOD) -> list[float | None]:
    """Wilder RSI: first period-change arithmetic mean, then Wilder smoothing.

    The initial `period` outputs are None. Flat history is 50; all gains 100;
    all losses 0. No rounding or independently chosen oscillator pivots.
    """
    _integer(period, "period")
    prices = [number(c) for c in closes]
    values: list[float | None] = [None] * len(prices)
    if len(prices) <= period:
        return values
    changes = [b - a for a, b in zip(prices, prices[1:], strict=False)]
    gains = [max(c, 0) for c in changes]
    losses = [max(-c, 0) for c in changes]
    gain, loss = mean(gains[:period]), mean(losses[:period])
    for index in range(period, len(prices)):
        if index > period:
            gain += (gains[index - 1] - gain) / period
            loss += (losses[index - 1] - loss) / period
        if gain == loss == 0:
            value = 50.0
        elif gain >= loss:
            value = 100 / (1 + loss / gain)
        else:
            value = 100 - 100 / (1 + gain / loss)
        if not math.isfinite(value):
            raise ValueError("nonfinite RSI calculation")
        values[index] = value
    return values


def classify_pair(
    kind: str, first_price: float, second_price: float, first_rsi: float, second_rsi: float
) -> str | None:
    """Strict textbook pair inequalities; no magnitude/profitability threshold inferred."""
    if kind not in {"high", "low"}:
        raise ValueError("kind must be high or low")
    a, b = number(first_price), number(second_price)
    x, y = number(first_rsi, positive=False), number(second_rsi, positive=False)
    if x > 100 or y > 100:
        raise ValueError("RSI must be within [0, 100]")
    if kind == "high":
        if b > a and y < x:
            return "regular_bearish"
        if b < a and y > x:
            return "hidden_bearish"
    else:
        if b < a and y > x:
            return "regular_bullish"
        if b > a and y < x:
            return "hidden_bullish"
    return None


def divergence_review(
    rows: Sequence[Mapping[str, Any]],
    symbol: str,
    as_of: datetime,
    *,
    period: int = DEFAULT_PERIOD,
    pivot_left: int = DEFAULT_PIVOT_LEFT,
    pivot_right: int = DEFAULT_PIVOT_RIGHT,
    max_bar_age_seconds: float = DEFAULT_MAX_BAR_AGE_SECONDS,
    max_pivot_age_seconds: float = DEFAULT_MAX_PIVOT_AGE_SECONDS,
) -> dict[str, Any]:
    """Review same-session completed one-minute candles known at `as_of`.

    Invalid arguments raise ValueError; absent/invalid market evidence returns
    UNAVAILABLE. OK with an empty signal list explicitly means no observed divergence.
    A signal timestamp is its knowledge time, never either historical pivot time.
    """
    if not isinstance(as_of, datetime) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError("as_of must be timezone-aware")
    if not isinstance(symbol, str) or not symbol.strip():
        raise ValueError("symbol required")
    for name, value in (
        ("period", period),
        ("pivot_left", pivot_left),
        ("pivot_right", pivot_right),
    ):
        _integer(value, name)
    number(max_bar_age_seconds)
    number(max_pivot_age_seconds)
    symbol = symbol.strip().upper()
    evidence = {
        "mode": "UNVALIDATED_PAPER_RESEARCH_CONTEXT",
        "source": SOURCE,
        "venue": VENUE,
        "coverage": "UNVERIFIED_FEED_COVERAGE",
        "symbol": symbol,
        "as_of": as_of.isoformat(),
        "period": period,
        "pivot_left": pivot_left,
        "pivot_right": pivot_right,
        "max_bar_age_seconds": max_bar_age_seconds,
        "max_pivot_age_seconds": max_pivot_age_seconds,
        "orders_placed": 0,
        "entry_gate": False,
        "rsi_method": "Wilder; flat=50; no loss=100; no gain=0",
    }

    def result(status, reason, signals=None):
        return {
            "status": status,
            "reasons": [reason],
            "latest_confirmed_divergences": signals or [],
            "evidence": evidence,
        }

    try:
        bars, gaps = [], []
        session = as_of.astimezone(ET).date()
        for row in rows:
            if (
                row.get("symbol", "").upper() != symbol
                or row.get("source") != SOURCE
                or (row.get("venue") != VENUE or row.get("kind") not in {"bar", "gap"})
            ):
                continue
            if timestamp(row["event_at"]) > as_of or timestamp(row["available_at"]) > as_of:
                continue
            if row["kind"] == "bar" and timestamp(row["event_at"]).astimezone(ET).date() != session:
                continue
            row = validate(row)
            if row["kind"] == "gap":
                gaps.append(row)
                continue
            b = row["payload"]
            begin, end = timestamp(b["start_at"]), timestamp(b["end_at"])
            if begin.astimezone(ET).date() != session or end.astimezone(ET).date() != session:
                continue
            if (end - begin).total_seconds() != 60:
                raise ValueError("requires completed one-minute bars")
            number(b.get("volume"))
            for item in (row, b):
                if any(
                    item.get(key) not in (None, False)
                    for key in ("synthetic", "is_synthetic", "interpolated")
                ):
                    raise ValueError("synthetic or interpolated candle")
            bars.append(row)
        # First available identical copy wins. Conflicting revisions never silently replace a bar.
        unique = {}
        for row in sorted(bars, key=lambda r: timestamp(r["available_at"])):
            key = timestamp(row["payload"]["start_at"])
            if key in unique and unique[key]["payload"] != row["payload"]:
                raise ValueError("conflicting duplicate candle")
            unique.setdefault(key, row)
        bars = [unique[k] for k in sorted(unique)]
        evidence["completed_bars"] = len(bars)
        if len(bars) < period + 1:
            return result("UNAVAILABLE", "RSI_warmup_incomplete")
        for a, b in zip(bars, bars[1:], strict=False):
            if timestamp(a["payload"]["end_at"]) != timestamp(b["payload"]["start_at"]):
                raise ValueError("nonconsecutive_candles")
        first = timestamp(bars[0]["payload"]["start_at"])
        last = timestamp(bars[-1]["payload"]["end_at"])
        age = (as_of - last).total_seconds()
        evidence.update(latest_bar_end_at=last.isoformat(), latest_bar_age_seconds=age)
        if age > max_bar_age_seconds:
            return result("UNAVAILABLE", "stale_latest_candle")
        gap_versions, gap_knowledge = {}, {}
        for row in sorted(gaps, key=lambda r: timestamp(r["available_at"])):
            key = row["payload"]["gap_key"]
            gap_versions[key] = row["payload"]
            gap_knowledge[key] = timestamp(row["available_at"])
        recovered = 0
        for gap in gap_versions.values():
            begin = timestamp(gap["start_at"])
            end = timestamp(gap["end_at"]) if gap.get("end_at") is not None else None
            if begin >= as_of or (end is not None and end <= first):
                continue
            # Consecutive observed bars above prove reconstruction only through `last`.
            # A transport recovery marker alone cannot prove an ongoing/uncovered interval.
            if end is None or end > last:
                return result("UNAVAILABLE", "ongoing_or_unreconstructed_data_gap")
            recovered += 1
        evidence["reconstructed_closed_transport_gaps"] = recovered
        rsi = rsi_values([b["payload"]["close"] for b in bars], period)
        evidence["latest_rsi"] = rsi[-1]
        pivots = {"high": [], "low": []}
        for i in range(max(period, pivot_left), len(bars) - pivot_right):
            for kind in pivots:
                price = bars[i]["payload"][kind]
                others = [
                    bars[j]["payload"][kind]
                    for j in range(i - pivot_left, i + pivot_right + 1)
                    if j != i
                ]
                if all(price > x if kind == "high" else price < x for x in others):
                    pivots[kind].append(i)
        latest = {}
        recent_pairs = 0
        for kind, indices in pivots.items():
            for a, b in zip(indices, indices[1:], strict=False):
                # A late download cannot make a session-old price pivot a fresh signal.
                if (
                    as_of - timestamp(bars[b]["payload"]["end_at"])
                ).total_seconds() > max_pivot_age_seconds:
                    continue
                recent_pairs += 1
                label = classify_pair(
                    kind, bars[a]["payload"][kind], bars[b]["payload"][kind], rsi[a], rsi[b]
                )
                if label is None:
                    continue
                right = b + pivot_right
                known = max(timestamp(row["available_at"]) for row in bars[: right + 1])
                confirm_end = timestamp(bars[right]["payload"]["end_at"])
                for key, gap in gap_versions.items():
                    if timestamp(gap["start_at"]) < confirm_end and (
                        gap.get("end_at") is not None and timestamp(gap["end_at"]) > first
                    ):
                        known = max(known, gap_knowledge[key])
                points = [
                    {
                        "bar_end_at": bars[i]["payload"]["end_at"],
                        "event_id": bars[i]["event_id"],
                        "price": bars[i]["payload"][kind],
                        "rsi_at_close": rsi[i],
                    }
                    for i in (a, b)
                ]
                latest[label] = {
                    "kind": label,
                    "price_pivot_kind": kind,
                    "first_pivot": points[0],
                    "second_pivot": points[1],
                    "confirmed_at": bars[right]["payload"]["end_at"],
                    "available_at": known.isoformat(),
                    "signal_at": known.isoformat(),
                }
        signals = sorted(latest.values(), key=lambda s: (s["available_at"], s["kind"]))
        evidence.update(
            confirmed_pivot_counts={k: len(v) for k, v in pivots.items()},
            recent_confirmed_pairs=recent_pairs,
        )
        return result(
            "OK",
            "confirmed_divergence_observed" if signals else "no_recent_confirmed_divergence",
            signals,
        )
    except (ValueError, KeyError, TypeError, AttributeError, OverflowError) as exc:
        return result("UNAVAILABLE", f"invalid_or_missing_evidence:{exc}")
