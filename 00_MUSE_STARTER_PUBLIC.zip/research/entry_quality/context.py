"""Entry measurements for the single paper bot; no trade or wait authority."""

import math
from collections.abc import Mapping
from datetime import datetime


def _number(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def entry_measurements(candidate: Mapping, quote: Mapping, technical: Mapping, now: datetime):
    qualified, refreshed, bid = (
        _number(candidate.get("ask")),
        _number(quote.get("ask_price")),
        _number(quote.get("bid_price")),
    )
    result = {
        "mode": "MEASUREMENT_ONLY",
        "changes_entry_decision": False,
        "qualified_ask": qualified,
        "refreshed_ask": refreshed,
        "refreshed_bid": bid,
        "one_contract_ask_change_dollars": None,
        "ask_change_percent": None,
        "no_chase_reference_would_wait": None,
        "interpretation": "Earlier ask is a reference observation, not an attainable fill.",
        "as_of": now.isoformat(),
    }
    if qualified is not None and qualified > 0 and refreshed is not None and refreshed >= 0:
        result.update(
            one_contract_ask_change_dollars=round((refreshed - qualified) * 100, 4),
            ask_change_percent=round((refreshed / qualified - 1) * 100, 4),
            no_chase_reference_would_wait=refreshed > qualified,
        )
    timing = technical.get("intraday_structure", {}).get("entry_timing", {})
    result["completed_candle_context"] = {
        k: timing.get(k)
        for k in (
            "status",
            "completed_bar_at",
            "session_vwap",
            "vwap_distance_percent",
            "distance_from_session_high_percent",
            "distance_from_session_low_percent",
            "bearish_confirmation_levels",
            "bullish_confirmation_levels",
        )
    }
    return result
