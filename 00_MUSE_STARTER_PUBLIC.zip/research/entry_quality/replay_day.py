"""Offline, observation-conditioned replay of archived forward paper evidence.

This module never constructs a SessionTape on an archive, invokes data clients,
calls models, sends notifications, or edits an active account. Missing evidence
remains missing; simulated outcomes cannot describe opportunities never archived.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
from collections import Counter
from datetime import UTC, date, datetime, timedelta
from functools import partial
from pathlib import Path
from typing import Any

from research.entry_quality.rsi_divergence import divergence_review
from research.options_lab.book_ranking import book_signal, candidate_components, ranking_audit
from research.options_lab.depth_exits import close_depth_exit, depth_exit_review
from research.options_lab.event_tape import ET, number, timestamp
from research.options_lab.forward import POLICY, code_hashes, experiment_policy, review_news
from research.options_lab.zone_signals import zone_review
from tools.cheap_scan import evaluate_candidate
from tools.config import load_config
from tools.decision_context import build_decision_packet
from tools.economic_calendar import economic_context
from tools.market_calendar import entry_allowed, session_hours
from tools.option_style import annotate_option_styles
from tools.options_lab import _fresh, _jev_rank, _validate_config, _write, load_experiment
from tools.options_strategy import entry_locked, ledger_directory
from tools.paper_runner import _refresh_map, apply_paper_decision
from tools.paper_trading import (
    _append_event,
    close_paper_position,
    ensure_paper_portfolio,
    manage_paper_positions,
    paper_summary,
)
from tools.scheduled_cycle import _route_compact_decision_impl


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def recorded_entry_quotes(cycle: dict, now: datetime) -> tuple[dict, list[dict]]:
    """First observed baseline quote per contract, then first other observation.

    The entire opportunity record is known only at cycle.as_of. Quote receipt and
    provider timestamps must both precede that boundary; no cheapest-price search.
    """
    eligible = []
    for observation in cycle.get("final_quotes", []):
        try:
            available = timestamp(observation["available_at"])
            if available > now:
                continue
            eligible.append((observation.get("arm") != "baseline", available, observation))
        except (KeyError, TypeError, ValueError):
            continue
    quotes, provenance = {}, []
    for _, available, observation in sorted(eligible, key=lambda v: (v[0], v[1])):
        for identifier, quote in _refresh_map(observation.get("refresh", {})).items():
            try:
                if identifier in quotes or timestamp(quote["updated_at"]) > available:
                    continue
            except (KeyError, TypeError, ValueError):
                continue
            quotes[identifier] = dict(quote)
            provenance.append({"contract_identifier": identifier, "arm": observation.get("arm"),
                               "available_at": available.isoformat(),
                               "provider_updated_at": quote["updated_at"]})
    return {"option_quotes": list(quotes.values())}, provenance


class ReadOnlyEvidence:
    def __init__(self, sources: list[Path], *, book_history_seconds=300):
        self.book_history_seconds = max(number(book_history_seconds),
                                        POLICY["depth_exits"]["history_seconds"])
        self.databases = [s / "SESSION_TAPE.sqlite3" for s in sources
                          if (s / "SESSION_TAPE.sqlite3").exists()]

    def observations(self, symbol: str, now: datetime) -> list[dict]:
        rows = {}
        hours = session_hours(now.astimezone(ET).date())
        for database in self.databases:
            uri = database.resolve().as_uri() + "?mode=ro"
            with sqlite3.connect(uri, uri=True) as con:
                records = con.execute(
                    "SELECT record FROM events WHERE session=? AND symbol=? "
                    "AND available_epoch<=? AND event_epoch<=? AND (kind IN ('bar','gap') "
                    "OR (kind='book' AND event_epoch>=?) OR (kind='news' AND event_epoch>=?)) "
                    "ORDER BY available_epoch,event_epoch,event_id", (
                        now.astimezone(ET).date().isoformat(), symbol, now.timestamp(),
                        now.timestamp(),
                        (now-timedelta(seconds=self.book_history_seconds)).timestamp(),
                        (now - timedelta(seconds=POLICY["reaction"]["max_news_age_seconds"])
                         ).timestamp(),
                    ))
                for (record,) in records:
                    row = json.loads(record)
                    # Also fence embedded records, rather than trusting SQLite index columns.
                    if timestamp(row["available_at"]) <= now and timestamp(row["event_at"]) <= now:
                        if row["kind"] == "bar" and (hours is None or not (
                            hours[0] <= timestamp(row["payload"]["start_at"])
                            < timestamp(row["payload"]["end_at"]) <= hours[1]
                        )):
                            continue
                        rows[_digest([row["source"], row["venue"], row["symbol"], row["kind"],
                                      row["event_id"], row["event_at"], row["payload"]])] = row
        return sorted(rows.values(), key=lambda r: (
            timestamp(r["available_at"]), timestamp(r["event_at"]), r["event_id"]))


def archived_news_health(cycle: dict, now: datetime) -> dict:
    """A successful contemporaneous archived review proves its feed check passed.

    This is explicitly an inference from that review, not reconstructed poll logs.
    No review means no basis to assume a healthy historical news feed.
    """
    for name in ("paper", "combined", "news_reaction"):
        result = cycle.get("results", {}).get(name, {})
        reviews = result.get("addition_reviews", []) + [
            item.get("review", {}) for item in result.get("news_reviews", [])]
        for review in reversed(reviews):
            news = review.get("news", {})
            if news.get("status") in {"ALLOW", "BLOCK"} and news.get("action") != (
                "PAUSE_NEWS_FEED_UNAVAILABLE"
            ):
                return {"status": "OK", "as_of": now.isoformat(),
                        "basis": "contemporaneous_archived_successful_news_review",
                        "source_account": name}
    return {"status": "UNAVAILABLE", "as_of": now.isoformat(),
            "basis": "historical_news_poll_health_not_archived"}


def _paths(run, config):
    ledger = ledger_directory(run, config, "paper")
    return {"portfolio_path": ledger / "PORTFOLIO.json", "event_log_path": ledger / "EVENTS.jsonl"}


def _review(evidence, symbol, side, now, health, policy=None):
    policy = policy or POLICY
    rows = evidence.observations(symbol, now)
    recent = _entry_rows(rows, now)
    news = review_news(recent, symbol, side, now, policy, health)
    zones = zone_review(recent, symbol, side, now, liquidity=False, supply_demand=True,
                        policy=policy["zones"])
    statuses = {news["status"], zones["status"]}
    return {"status": "UNAVAILABLE" if "UNAVAILABLE" in statuses else
            "BLOCK" if "BLOCK" in statuses else "ALLOW", "news": news, "zones": zones,
            "rsi_divergence": divergence_review(rows, symbol, now)}


def _entry_rows(rows, now):
    """Match ForwardExperiment.review's entry horizon; keep every gap revision.

    RSI separately consumes the full regular-session bar history. A closed gap is
    never deleted here: zone_review requires real completed-bar coverage to recover it.
    """
    zones = POLICY["zones"]
    horizon = max(zones["zone_max_age_seconds"]
                  + (zones["displacement_lookback_bars"] + 1) * 60,
                  zones["liquidity_window_seconds"], POLICY["reaction"]["max_news_age_seconds"])
    return [r for r in rows if r["kind"] == "gap" or timestamp(r["event_at"]) >= now - timedelta(
        seconds=zones["liquidity_window_seconds"] if r["kind"] == "book" else horizon)]


def _recorded_jev(value, now):
    observed = value.get("available_at") or value.get("as_of")
    if _jev_rank(value) is None or not _fresh(observed, now, 240) or (
        value.get("as_of") is not None and not _fresh(value["as_of"], now, 240)
    ):
        return None
    return value


def _candidate_freshness(candidate, now):
    # Forward archives retain the scanner's explicit verified freshness flag and
    # option provider timestamp. They do not always retain a separate underlying
    # timestamp; do not invent one or impose a gate production did not apply.
    valid = candidate.get("quote_is_fresh") is True and _fresh(
        candidate.get("quote_updated_at"), now, 180)
    underlying = candidate.get("underlying_quote_updated_at")
    if underlying is not None:
        valid = valid and _fresh(underlying, now, 240)
    return valid, ("explicit_option_and_underlying_timestamps" if underlying is not None else
                   "archived_scanner_freshness_flag_and_actual_option_timestamp")


async def _opportunity(cycle, config, run, now, evidence, monitor, policy=None):
    """Same scanner/router/accounting calls as options_lab._step with research DI."""
    policy = policy or POLICY

    result = {"as_of": now.isoformat(), "kind": "opportunity", "data_issues": [],
              "orders_placed": 0, "model_calls": 0}
    issues = result["data_issues"]
    refresh, quote_sources = recorded_entry_quotes(cycle, now)
    result["quote_provenance"] = quote_sources
    result["news_health"] = archived_news_health(cycle, now)
    if monitor.get("attention") or entry_locked(monitor["portfolio"]):
        result["skip_reason"] = "position_data_unavailable" if monitor.get("attention") else (
            "daily_green_lock_active")
        return result
    calendar = cycle.get("economic_calendar")
    if not isinstance(calendar, dict) or not _fresh(calendar.get("fetched_at"), now, 86400 * 8):
        issues.append("economic_calendar_missing_stale_or_future")
    else:
        _write(run / "state" / "economic_calendar.json", calendar)
    macro = economic_context(now, config, project_root=run)
    if macro["status"] not in {"OK", "DISABLED"}:
        issues.append("economic_calendar_unavailable")
    if issues or not entry_allowed(now, config, "DAY"):
        result["skip_reason"] = "session_or_economic_calendar_gate"
        return result
    from research.options_lab.session_expiry import paper_entry_config

    config = paper_entry_config(config, now)
    result["expiry_eligibility"] = config.evidence()
    candidates, rejected = [], []
    result["candidate_freshness_basis"] = {}
    for original in cycle.get("discovery", {}).get("qualified_candidates", []):
        candidate = dict(original)
        if candidate.get("symbol") not in config.watchlist_symbols():
            rejected.append({"candidate_id": candidate.get("candidate_id"),
                             "reasons": ["outside_experiment_universe"]})
            continue
        candidate["quote_is_fresh"], basis = _candidate_freshness(candidate, now)
        result["candidate_freshness_basis"][candidate["candidate_id"]] = basis
        try:
            candidate["dte"] = (date.fromisoformat(candidate["expiration"])
                                - now.astimezone(ET).date()).days
        except (ValueError, KeyError, TypeError):
            candidate["dte"] = None
        expiry = config.review(candidate, now)
        if expiry["status"] != "ALLOW":
            rejected.append(expiry)
            continue
        candidate = annotate_option_styles(candidate, config)
        candidate["entry_eligible_trade_styles"] = [
            s for s in candidate["eligible_trade_styles"] if entry_allowed(now, config, s)]
        gate = evaluate_candidate(candidate, config)
        if gate.status == "QUALIFIED":
            candidates.append(candidate)
        else:
            rejected.append(gate.as_dict())
            if gate.status == "INSUFFICIENT_DATA":
                issues.append("candidate_data_unavailable")
    result["scanner_rejections"] = rejected
    def technical(symbol, **kwargs):
        value = cycle.get("technical", {}).get(symbol, {})
        if value.get("status") != "OK" or not _fresh(value.get("as_of"), now, 600):
            issues.append("technical_evidence_missing_or_stale")
            return {"status": "UNAVAILABLE"}
        return value
    def jev(packet, *args, **kwargs):
        value = cycle.get("jev", {}).get(packet["candidate"]["candidate_id"], {})
        if _recorded_jev(value, now) is None:
            issues.append("jev_evidence_missing_or_stale")
            return {"status": "UNAVAILABLE"}
        return value
    observed = {symbol:evidence.observations(symbol, now)
                for symbol in {c["symbol"] for c in candidates}}
    rsi = {symbol:divergence_review(rows, symbol, now) for symbol,rows in observed.items()}
    books = {symbol:book_signal(rows, symbol, now, policy=policy["book_ranking"],
                               wall_policy=policy["zones"]) for symbol,rows in observed.items()}
    components = {c["candidate_id"]:candidate_components(c,rsi[c["symbol"]],books[c["symbol"]],
                                  policy=policy["book_ranking"]) for c in candidates}
    result["rsi_priority_evidence"] = rsi
    result["book_ranking_evidence"] = books
    result["candidate_ranking_components"] = components
    result["ranking_as_of"] = now.isoformat()
    event = {"option_discovery": {"qualified_candidates": candidates},
             "paper_portfolio": monitor, "market_intelligence": {},
             "orderbooks": cycle.get("orderbooks", {"summaries": {}})}
    routing = await _route_compact_decision_impl(
        event, config=config, project_root=run, execute_models=True, now=now,
        packet_builder=partial(build_decision_packet, technical_fetcher=technical,
                               uw_fetcher=lambda *args: {"status": "DISABLED"}),
        jev_evaluator=jev,
        candidate_priority=lambda c: components[c["candidate_id"]]["total_priority"])
    routing.pop("_jev_pending", None)
    result["routing"] = routing
    result["entry_ranking"] = ranking_audit(routing, components)
    reviews = []
    async def guarded_quotes(requests):
        for request in requests:
            candidate = next((c for c in candidates
                              if c["candidate_id"] == request["option_id"]), None)
            if candidate is None:
                issues.append("selected_contract_not_archived")
                return {"option_quotes": []}
            review = _review(evidence, candidate["symbol"], candidate["option_type"],
                             now, result["news_health"], policy=policy)
            reviews.append(review)
            if review["status"] != "ALLOW":
                if review["status"] == "UNAVAILABLE":
                    issues.append("addition_evidence_unavailable")
                return {"option_quotes": []}
            if request["option_id"] not in _refresh_map(refresh):
                issues.append("final_selected_option_quote_not_archived")
        return refresh
    result["entry"] = await apply_paper_decision(
        routing, event, config, project_root=run, now=now, quote_fetcher=guarded_quotes)
    if any(any(word in reason for word in ("missing", "stale", "invalid"))
           for reason in result["entry"].get("reasons", [])):
        issues.append("final_entry_data_unavailable")
    result["addition_reviews"] = reviews
    return result


def _load_events(sources, day, as_of):
    events, provenance, seen = [], [], set()
    for source in sources:
        for kind, filename in (("opportunity", "OPPORTUNITIES.jsonl"),
                               ("monitor", "MONITOR.jsonl")):
            path = source / filename
            if not path.exists():
                continue
            provenance.append({"path": str(path.resolve()), "sha256": _file_hash(path)})
            for line_number, line in enumerate(path.read_text().splitlines(), 1):
                if not line.strip():
                    continue
                row = json.loads(line)
                at = timestamp(row["as_of"])
                if at > as_of or at.astimezone(ET).date() != day:
                    continue
                identity = _digest([kind, row["as_of"], row.get("discovery") if
                                    kind == "opportunity" else _refresh_map(
                                        row.get("quote_refresh", {}))])
                if identity not in seen:
                    seen.add(identity)
                    events.append((at, kind, row, {"path": str(path.resolve()),
                                                   "line": line_number}))
        database = source / "SESSION_TAPE.sqlite3"
        if database.exists():
            provenance.append({"path": str(database.resolve()), "sha256": _file_hash(database),
                               "read_mode": "sqlite_uri_mode_ro"})
    return sorted(events, key=lambda v: (v[0], v[1] != "monitor")), provenance


async def _run(config, run, events, evidence, session_date, policy=None):
    policy = policy or POLICY
    hours = session_hours(session_date)
    if hours is None:
        raise ValueError("requested date has no NYSE regular session")
    paths = _paths(run, config)
    ensure_paper_portfolio(config, **paths, now=hours[0])
    cycles = []
    previous_at = None
    previously_held = False
    for now, kind, archived, source in events:
        refresh = (recorded_entry_quotes(archived, now)[0] if kind == "opportunity" else
                   archived.get("quote_refresh", {"option_quotes": []}))
        # Filter future provider timestamps even if an enclosing monitor row claims
        # an earlier availability. Missing/stale data is handled by shared accounting.
        normalized = []
        for quote in _refresh_map(refresh).values():
            try:
                if timestamp(quote["updated_at"]) <= now:
                    normalized.append(dict(quote))
            except (KeyError, ValueError, TypeError):
                pass
        monitor = manage_paper_positions({"option_quotes": normalized}, config, **paths, now=now)
        issues = [a["code"] for a in monitor.get("attention", [])]
        if previously_held and previous_at is not None and (now - previous_at).total_seconds() > (
            float(config.get("PAPER_OPEN_POSITION_POLL_SECONDS", 10)) * 1.5
        ):
            issues.append("archived_monitoring_gap_while_held")
        if refresh.get("error_type"):
            issues.append("archived_quote_refresh_failure")
        result = {"kind": kind, "as_of": now.isoformat(), "source_record": source,
                  "monitor": monitor, "data_issues": issues, "orders_placed": 0,
                  "model_calls": 0}
        # Protective management always precedes optional depth/news exits.
        held_rows = {p["symbol"]: evidence.observations(p["symbol"], now)
                     for p in monitor.get("open_positions", [])}
        depth_reviews = []
        for position in monitor.get("open_positions", []):
            quote = _refresh_map({"option_quotes": normalized}).get(
                position["contract_identifier"], {})
            depth = depth_exit_review(held_rows[position["symbol"]], position, quote, now,
                                      policy=policy["depth_exits"])
            row = {"paper_id": position["paper_id"], "review": depth}
            if depth["status"] == "UNAVAILABLE":
                issues.append("depth_exit_evidence_unavailable_while_held")
            if depth["status"] == "OK" and depth["action"] != "HOLD":
                row["exit"] = close_depth_exit(depth, position, quote, config=config,
                                                paths=paths, now=now)
            depth_reviews.append(row)
        result["depth_exit_reviews"] = depth_reviews
        if any(r.get("exit", {}).get("closed") for r in depth_reviews):
            current_state = ensure_paper_portfolio(config, **paths, now=now)
            monitor = {**monitor, "portfolio": paper_summary(current_state),
                       "open_positions": current_state["open_positions"]}
            result["monitor_after_depth_exits"] = monitor
        health = archived_news_health(archived, now)
        news_exits = []
        for position in monitor.get("open_positions", []):
            news = review_news(held_rows[position["symbol"]],
                               position["symbol"], position["option_type"], now, policy, health)
            if news.get("status") == "UNAVAILABLE":
                issues.append("historical_news_health_unavailable_while_held")
            if news.get("action") == "EXIT_REVIEW":
                quote = _refresh_map({"option_quotes": normalized}).get(
                    position["contract_identifier"], {})
                try:
                    bid, ask = float(quote["bid_price"]), float(quote["ask_price"])
                    if not (0 <= bid <= ask) or not _fresh(quote["updated_at"], now, 20):
                        raise ValueError("stale/invalid exit quote")
                    news_exits.append(close_paper_position(
                        position["paper_id"], bid=bid, quote_updated_at=quote["updated_at"],
                        reason="PAPER_NEWS_REACTION", config=config, **paths, now=now))
                except (KeyError, ValueError, TypeError):
                    issues.append("news_exit_fresh_quote_unavailable")
        result["news_exits"] = news_exits
        if any(exit_result.get("closed") for exit_result in news_exits):
            current_state = ensure_paper_portfolio(config, **paths, now=now)
            monitor = {**monitor, "portfolio": paper_summary(current_state),
                       "open_positions": current_state["open_positions"]}
            result["monitor_after_news_exits"] = monitor
        if kind == "opportunity":
            opportunity = await _opportunity(archived, config, run, now, evidence, monitor,
                                             policy=policy)
            opportunity["data_issues"] = issues + opportunity["data_issues"]
            result.update(opportunity)
        _append_event(run / "CYCLES.jsonl", result)
        cycles.append(result)
        previously_held = bool(monitor.get("open_positions")) or bool(
            result.get("entry", {}).get("opened"))
        if any(exit_result.get("closed") for exit_result in news_exits):
            state_after_exit = ensure_paper_portfolio(config, **paths, now=now)
            previously_held = bool(state_after_exit["open_positions"])
        previous_at = now
    return cycles


def replay_recorded_day(experiment: Path, sources: list[Path], output: Path,
                        session_date: date, as_of: datetime) -> dict[str, Any]:
    if as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError("as_of must be timezone-aware")
    experiment, output = experiment.resolve(), output.resolve()
    sources = [Path(s).resolve() for s in sources]
    if not sources or output.exists() or any(output.is_relative_to(s) or
            s.is_relative_to(output) for s in [experiment, *sources]):
        raise ValueError("output must be new and isolated outside experiment/source archives")
    config, manifest = load_experiment(experiment)
    _validate_config(config)
    research_metadata = experiment / "forward" / "EXPERIMENT.json"
    research_metadata_hash = None
    policy = POLICY
    if research_metadata.exists():
        frozen_research = json.loads(research_metadata.read_text())
        if frozen_research["research_code_sha256"] != code_hashes():
            raise ValueError("frozen research code differs from current replay/forward code")
        policy = experiment_policy(frozen_research["policy"])
        if manifest.get("forward_metadata_sha256") is not None and (
            manifest["forward_metadata_sha256"] != _file_hash(research_metadata)
        ):
            raise ValueError("frozen paper metadata changed")
        for relative, expected in frozen_research["research_code_sha256"].items():
            if _file_hash(experiment / "source" / relative) != expected:
                raise ValueError(f"archived research source changed: {relative}")
        research_metadata_hash = _file_hash(research_metadata)
    if float(config.get("PAPER_STARTING_CASH")) != 369:
        raise ValueError("requested replay requires a single fresh $369 simulated account")
    events, provenance = _load_events(sources, session_date, as_of.astimezone(UTC))
    output.mkdir(parents=True)
    (output / "CONFIG.md").write_bytes((experiment / "CONFIG.md").read_bytes())
    # Production calendar gates resolve relative to config.source. Bind the same
    # frozen values to the replay copy so they consume its archived calendar,
    # never an experiment/active account's unrelated current cache.
    config = load_config(output / "CONFIG.md")
    evidence = ReadOnlyEvidence(
        sources, book_history_seconds=policy["book_ranking"]["history_seconds"])
    cycles = asyncio.run(_run(config, output, events, evidence,
                             session_date, policy=policy))
    state = json.loads(_paths(output, config)["portfolio_path"].read_text())
    issues = Counter(i for row in cycles for i in row["data_issues"])
    opportunities = [r for r in cycles if r["kind"] == "opportunity"]
    if not opportunities:
        issues["no_archived_opportunities_before_as_of"] += 1
    if state["open_positions"]:
        issues["open_positions_not_forcibly_closed"] += 1
    log = _paths(output, config)["event_log_path"]
    trades = [json.loads(line) for line in log.read_text().splitlines()
              if line.strip()] if log.exists() else []
    report = {
        "schema_version": 1, "mode": "OFFLINE_SAME_DAY_OBSERVATION_REPLAY",
        "status": "INSUFFICIENT_DATA" if issues else "CONDITIONAL_REPLAY_COMPLETE",
        "session_date": session_date.isoformat(), "as_of": as_of.isoformat(),
        "experiment": str(experiment), "output": str(output), "accounts": 1,
        "starting_cash": 369, "history_carried": False, "orders_placed": 0, "model_calls": 0,
        "depth_exit_policy": policy["depth_exits"],
        "book_ranking_policy": policy["book_ranking"],
        "source_files": provenance, "config_sha256": _file_hash(experiment / "CONFIG.md"),
        "frozen_manifest_sha256": _file_hash(experiment / "MANIFEST.json"),
        "frozen_research_metadata_sha256": research_metadata_hash,
        "strategy_epoch": manifest.get("strategy_epoch"),
        "coverage": {"opportunity_cycles": len(opportunities), "monitor_cycles":
                     len(cycles) - len(opportunities), "first_opportunity_at":
                     opportunities[0]["as_of"] if opportunities else None,
                     "last_opportunity_at": opportunities[-1]["as_of"] if opportunities else None,
                     "scope": "conditional_on_supplied_opportunities_and_recorded_quotes_only"},
        "performance": paper_summary(state), "net_pnl": None if issues else state["realized_pnl"],
        "trades_and_account_events": trades, "data_quality": dict(issues),
        "entry_outcomes": dict(Counter(r.get("skip_reason") or
                               r.get("entry", {}).get("status", "NO_ENTRY")
                               for r in opportunities)),
        "limitations": [
            "Candidate coverage ends at supplied opportunity cycles; no full-day edge claim.",
            "No interpolation, future quotes, best-price selection or forced fills/exits.",
            "News health inferred only from contemporaneous archived successful reviews.",
            "Missing optional-exit evidence makes counterfactual P&L incomplete, not zero profit.",
            "RSI gives relative priority; all original gates and research vetoes still apply.",
            "Depth exits test displayed pressure plus price, not executed buy/sell volume.",
            "Replay ledger and P&L never replace the active paper account.",
        ],
    }
    _write(output / "REPORT.json", report)
    return report
