# Early regime probabilities and a separate range strategy

This package is offline research requested November 1, 2026. It audits the current
live strategy's recorded fills, compares two fixed early-session forecasting
models with a prior-frequency baseline, and implements an independent range
reclaim candidate. It has no order adapter and changes no running service, paper
account, live setting or core policy.

`PROTOCOL.json` was sealed in `INITIAL_STATE.json` before model scoring. Features
and models are fixed; selection uses 2024 only, followed by annual refits and
2025/2026 evaluation. Both ETFs share date boundaries. MIXED and UNCERTAIN remain
explicit. The prior heuristic's previously examined 2025 outcomes mean this year
is a temporal evaluation, not a completely untouched research holdout.

The forecast clocks are 09:25:15, 09:50:15 and 10:00:15 Eastern. Preopen estimates
use prior sessions only; the primary 09:50 estimate has the first 20 completed
minutes. Five-minute outcome bars begin strictly after the decision. Completed
bars are assumed available at end + 1 second, with a 60-second sensitivity.
Historical receipt/revision archives are unavailable. VWAP is a bar-based typical
price and volume approximation, consistently applied to all years.

Source coverage matters: 2022–2025 reuse the archived SIP observations. Intermittent
SIP tool failures left part of 2026 unavailable; missing sessions remain in the
coverage audit and cannot pass confirmation. Separately archived October Yahoo
bars support retrospective live attribution only. Their naive timestamps are
explicitly interpreted in the exchange timezone and are not relabeled as SIP.

The current-epoch live audit reconciles closed positions to exit events and
broker-fill accounting. Other strategy epochs are excluded. It reports gross fills
and net after stored modeled costs separately. Whole-day and later-window labels
are hindsight attribution, not an actionable filter or a counterfactual backtest.
Most short holding windows cannot satisfy the 30-minute label definition. The
small live sample cannot establish a stable regime effect.

The separate range hypothesis buys a call after a completed lower-range sweep and
reclaim toward frozen signal-time VWAP, or a put after the symmetric upper-range
rejection. Prior reversals, positive room and underlying reward/risk are required.
`available_candidate` enforces the decision-time fence and gaps. This reversal is
separate from the baseline continuation signal. An eventual options paper adapter
must retain the original one-contract size, 25% premium stop, 30% premium target,
cash/daily-loss/entry limits, green lock, exact contract/Greek/liquidity/quote/event
gates, costs and deadline. The research candidate cannot bypass those gates or
place a trade.

The range replay is an **underlying opportunity diagnostic**, not option P&L or
the live bot's strategy. It uses a boundary open strictly after the decision,
conservative stop-first ambiguous bars, adverse opening gaps, bounded holding
times, overlapping-position tracking and a shared three-entry daily limit in
each arm. It reports fixed underlying costs of 2/5 bps. Drawdown uses five-minute
adverse marks and closes in equal-unit bps; it is not exact intrabar or cash-account
equity. No historical option quote, IV, chain, cash or executable fill is invented.

Run from the repository root, using a fresh output directory:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python \
  -m research.regime_research.run \
  --output research/regime_research/results_reproduction

.venv/bin/python -m pytest tests/test_regime_research.py tests/test_regime_backtest.py
```

Results and limitations: [November 1 report](results_20261101/REPORT.md).
`FORECASTS.csv` preserves probabilities, strong/uncertain decisions, model training
cutoffs and receipt-delay variants. `DATASET.csv` and `COVERAGE.csv` retain missing
outcomes and feature failures. The report links source manifests, live attribution,
range opportunities and verification. No candidate is automatically promoted.
