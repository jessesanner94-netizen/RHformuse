"""Bounded stdin-only data transport. No credentials, network, or executable input."""

import gzip
import json
import re
import sys
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent / "data_2026"
    root.mkdir(exist_ok=True)
    import termios

    settings = termios.tcgetattr(sys.stdin)
    mode = termios.tcgetattr(sys.stdin)
    mode[3] &= ~(termios.ECHO | termios.ICANON)
    termios.tcsetattr(sys.stdin, termios.TCSANOW, mode)
    print("READY", flush=True)
    try:
        for raw in sys.stdin.buffer:
            try:
                if len(raw) > 3_000_000:
                    raise ValueError("oversized packet")
                packet = json.loads(raw)
                if packet.get("command") == "close":
                    break
                name = packet.pop("name")
                if not re.fullmatch(r"(?:1m|5m)_2026-\d{2}-\d{2}_2026-\d{2}-\d{2}", name):
                    raise ValueError("invalid name")
                response = packet["response"]
                req = response["request"]
                if req["feed"] != "sip" or req["timeframe"] not in {"1Min", "5Min"}:
                    raise ValueError("invalid source")
                if packet["source_counts"]["records"] >= req["limit"]:
                    raise ValueError("possibly truncated query")
                count = sum(len(b) for b in response["bars"].values())
                if count != response["counts"]["records"]:
                    raise ValueError("wrong row count")
                target = root / (name + ".json.gz")
                if target.exists():
                    raise ValueError("archive exists")
                with gzip.open(target, "wt") as f:
                    json.dump(packet, f, separators=(",", ":"))
                print(json.dumps({"saved": name, "rows": count}), flush=True)
            except Exception as exc:
                print(json.dumps({"error": str(exc)[:150]}), flush=True)
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSANOW, settings)


if __name__ == "__main__":
    main()
