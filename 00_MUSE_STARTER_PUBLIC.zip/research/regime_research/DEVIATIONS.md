# Declared-method clarifications and data availability

Recorded before the first forecast/range results were inspected on November 1:

- The declared 2026 SIP confirmation cannot be treated as complete. Historical
  requests repeatedly returned internal tool errors. Available SIP files and all
  expected missing dates remain explicit. Incomplete confirmation fails the
  eligibility check independently of model metrics.
- A complete October 12–30 five-minute Yahoo fallback was retrieved for the live
  audit. It is stored separately with truthful provenance and a disclosed exchange
  timezone assumption. It never substitutes for missing SIP forecast observations.
- The protocol's phrase “minute-mark drawdown” for the range diagnostic is
  implemented as five-minute close/adverse bar marks, not a one-minute or exact
[account details redacted]
  with no option cash, quote or execution reconstruction. The report names this
  limitation explicitly.
- A read-only Robinhood snapshot attempt failed with an MCP task-group error.
  The offline audit uses persistent fill/state evidence, which was flat at the
  last recorded session. It does not claim fresh broker reconciliation, and no
  order or order review was attempted.

These limitations do not relax the fixed model, threshold, training-date or
promotion requirements. No core policy or strategy setting was changed.
