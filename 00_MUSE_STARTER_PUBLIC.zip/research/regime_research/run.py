"""Run the sealed offline study. No network calls, orders, or running-bot changes."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np
import pandas as pd

from .audit import audit_live
from .data import HERE, ROOT, SYMBOLS, build_dataset, load, window
from .model import run_models
from .range_strategy import available_candidate, simulate_path


def protect():
    initial = json.loads((HERE / "INITIAL_STATE.json").read_text())
    if (
        hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest()
        != initial["protocol_sha256"]
    ):
        raise ValueError("sealed protocol changed")
    changed = [
        p
        for p, digest in initial["protected_files"].items()
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != digest
    ]
    if changed:
        raise ValueError("protected files changed: " + str(changed))
    return {
        "protected_files_checked": len(initial["protected_files"]),
        "changed": [],
        "protocol_sha256": initial["protocol_sha256"],
    }


def bar_mark_drawdown(trades, cost):
    """Equal-unit diagnostic, adverse 5m marks followed by closes; not cash equity."""
    events = []
    for i, trade in enumerate(trades):
        events.append((trade["entry_at"], 0, i, "entry", -cost / 2))
        for m in trade["marks"]:
            events.append((m["at"], 1, i, "mark", m["adverse_bps"] - cost / 2))
            events.append((m["at"], 2, i, "mark", m["close_bps"] - cost / 2))
        events.append((trade["exit_at"], -1, i, "exit", trade["gross_bps"] - cost))
    realized, high, drawdown = 0.0, 0.0, 0.0
    held = {}
    for _, _, i, kind, value in sorted(events):
        if kind == "exit":
            held.pop(i, None)
            realized += value
        else:
            held[i] = value
        equity = realized + sum(held.values())
        high = max(high, equity)
        drawdown = max(drawdown, high - equity)
    return float(drawdown)


def range_stats(trades):
    if not trades:
        return {"trades": 0}
    result = {
        "trades": len(trades),
        "dates": len({t["date"] for t in trades}),
        "cost_scenarios": {},
    }
    for cost in (2, 5):
        net = np.array([t["gross_bps"] - cost for t in trades])
        result["cost_scenarios"][str(cost)] = {
            "mean_net_bps_per_signal": float(net.mean()),
            "win_rate": float(np.mean(net > 0)),
            "sum_equal_unit_net_bps": float(net.sum()),
            "bar_mark_equal_unit_drawdown_bps": bar_mark_drawdown(trades, cost),
        }
    return result


def range_replay(sessions, data, predictions, output):
    days = sorted(sessions)
    selected = predictions[
        (predictions.clock == "09:50:15")
        & (predictions.target == "REMAINDER")
        & (predictions.delay_seconds == 1)
    ]
    probabilities = {
        (r.date, r.symbol): (r.p_CHOPPY, r.strong_signal) for r in selected.itertuples()
    }
    opportunities, missing = [], []
    for index, day in enumerate(days):
        if day < "2024-01-01":
            continue
        opened, closed = sessions[day]
        for symbol in SYMBOLS:
            current = data[(day, symbol)]
            history = [window(data[(d, symbol)], *sessions[d]) for d in days[index - 20 : index]]
            if (
                len(history) < 20
                or any(x is None for x in history)
                or window(current, opened, closed) is None
            ):
                missing.append(
                    {"date": day, "symbol": symbol, "reason": "missing_current_or_prior_session"}
                )
                continue
            # Prior-session mean true range, in current price units. Never today's future range.
            tr = []
            for bars in history:
                prior_close = bars[0]["open"]
                for b in bars:
                    tr.append(
                        max(
                            b["high"] - b["low"],
                            abs(b["high"] - prior_close),
                            abs(b["low"] - prior_close),
                        )
                        / prior_close
                    )
                    prior_close = b["close"]
            mean_range = float(np.mean(tr)) * current[opened]["open"]
            for j in range(6, int((closed - opened).total_seconds() / 300) - 4):
                decision = opened + timedelta(minutes=j * 5, seconds=15)
                signal = available_candidate(current, opened, decision, mean_range)
                if signal is None:
                    continue
                # The boundary open has already occurred by :15. Enter at the following open.
                entry_at = opened + timedelta(minutes=(j + 1) * 5)
                if entry_at >= closed - timedelta(minutes=30):
                    continue
                path = simulate_path(signal, current, entry_at, closed)
                if path is None:
                    continue
                prob, strong = probabilities.get((day, symbol), (None, "UNCERTAIN"))
                opportunities.append(
                    {
                        "date": day,
                        "symbol": symbol,
                        "signal_at": decision.isoformat(),
                        "entry_at": entry_at.isoformat(),
                        "p_chop": prob,
                        "forecast_signal": strong,
                        **signal,
                        **path,
                    }
                )
    pd.DataFrame(missing).to_csv(output / "RANGE_UNAVAILABLE.csv", index=False)
    all_trades = []
    for arm in ("ALL", "CHOP_OBSERVED", "CHOP_FORECAST"):
        busy, counts = {}, defaultdict(int)
        for t in sorted(opportunities, key=lambda r: (r["entry_at"], r["symbol"])):
            if counts[t["date"]] >= 3 or busy.get((t["date"], t["symbol"]), "") > t["entry_at"]:
                continue
            if arm == "CHOP_OBSERVED" and not t["observed_chop"]:
                continue
            if arm == "CHOP_FORECAST" and t["forecast_signal"] != "CHOPPY":
                continue
            counts[t["date"]] += 1
            busy[t["date"], t["symbol"]] = t["exit_at"]
            all_trades.append({"arm": arm, **t})
    export = [{k: v for k, v in t.items() if k != "marks"} for t in all_trades]
    pd.DataFrame(export).to_csv(output / "RANGE_SIGNALS.csv", index=False)
    summary = {
        "status": "UNDERLYING_OPPORTUNITY_DIAGNOSTIC_ONLY",
        "option_pnl_available": False,
        "unavailable_symbol_sessions": len(missing),
        "opportunities": len(opportunities),
        "by_year_arm": {},
        "limitations": [
            "No option chains, Greeks, IV, spread, cash, JEV, calendar blackouts or option "
            "fills reconstructed",
            "2/5bps costs apply to the underlying diagnostic, not the options strategy",
            "Equal-unit aggregate and bar-mark drawdown are not account returns or exact "
            "intrabar equity",
            "2024 influenced model selection; 2026 data are incomplete; no deployment evidence",
        ],
    }
    for year in (2024, 2025, 2026):
        for arm in ("ALL", "CHOP_OBSERVED", "CHOP_FORECAST"):
            summary["by_year_arm"][f"{year}|{arm}"] = range_stats(
                [t for t in all_trades if t["date"].startswith(str(year)) and t["arm"] == arm]
            )
    (output / "RANGE_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def pct(value):
    return "—" if value is None else f"{value * 100:.1f}%"


def render(output, audit, forecast, ranges, coverage):
    lines = [
        "# Regime forecasting and the live bot's chop hypothesis",
        "",
        "Research dated November 1, 2026. No running bot, live strategy or core risk "
        "setting was changed.",
        "",
        "## What the actual live trades show",
        "",
        f"Current strategy epoch: {audit['all_trades']['trades']} closed trades on "
        f"{audit['dates_with_trades']} dates. "
        f"Broker-fill gross P&L ${audit['all_trades']['broker_fill_gross_pnl']:.2f}; after "
        f"stored modeled costs "
        f"${audit['all_trades']['modeled_net_pnl']:.2f}. This is a small observational "
        f"sample, not a strategy backtest.",
        "",
        "| Retrospective definition | Regime | Trades | Net P&L after modeled costs | "
        "Expectancy | Win rate |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for definition, groups in audit["by_definition"].items():
        for c, m in groups.items():
            if m["trades"]:
                lines.append(
                    f"| {definition} | {c} | {m['trades']} | ${m['modeled_net_pnl']:.2f} | "
                    f"${m['expectancy_dollars']:.2f} | {pct(m['win_rate'])} |"
                )
    lines += [
        "",
        "Full-session, entry-forward and next-hour labels use later prices and are "
        "retrospective attribution only. "
        "A trade may win in a short directional segment of an otherwise choppy day, or "
        "lose before a later trend begins. "
        "Most holding windows are too short for the declared 30-minute outcome and remain UNKNOWN. "
        "The hypothesis is not established by 13 trades. Gross fills are real recorded "
        "fills; modeled net costs are not verified broker fees. "
        "Older epochs are excluded. Live drawdown here uses closed trades and cannot "
        "replace account mark-to-market.",
        "",
        "## Fixed early-probability experiment",
        "",
        f"Selected family: **{forecast['selected_model']}**, chosen solely by 2024 primary "
        f"09:50 remainder multiclass Brier loss. "
        "Two fixed learned models and a training-frequency prior were compared. No "
        "parameter or signal-threshold search. "
        "Annual refits use only earlier years, and both symbols share the same date split. "
        "2025 is a temporal test, but its outcomes were previously inspected for the old "
        "heuristic; it is not a pristine research holdout.",
        "",
        "Features: prior-session path/range, 5/20-session return, historical range, "
        "opening gap, early return/range/efficiency, "
        "bar-based session VWAP crossings, early volume versus prior sessions, and the "
        "peer ETF's completed early return. "
        "Preopen predictions use prior sessions only. Scheduled event dates are not "
        "inferred from prices or folded into these features.",
        "",
        "| 09:50 remaining-session test | N | Brier skill vs prior | Argmax accuracy | "
        "Prior accuracy | Strong trend signals / precision / recall | Strong chop signals "
        "/ precision / recall |",
        "|---|---:|---:|---:|---:|---|---|",
    ]
    for year in (2024, 2025, 2026):
        m = forecast["by_year_clock_target_delay"].get(f"{year}|09:50:15|REMAINDER|1")
        if not m or not m["n"]:
            continue
        t, c = m["classes"]["TREND"], m["classes"]["CHOPPY"]
        lines.append(
            f"| {year} | {m['n']} | {pct(m['brier_skill'])} | {pct(m['accuracy'])} | "
            f"{pct(m['baseline_accuracy'])} | {t['strong_signals']} / "
            f"{pct(t['precision'])} / {pct(t['recall'])} | {c['strong_signals']} / "
            f"{pct(c['precision'])} / {pct(c['recall'])} |"
        )
    lines += [
        "",
        "Brier skill above zero means probability forecasts improve on the "
        "same-training-history prior; it does not establish profitability. "
        "A strong trend/chop signal requires probability at least 0.50 and a 0.10 lead "
        "over the next class; otherwise UNCERTAIN. "
        "The numeric probabilities are model estimates, not proven calibrated confidence. "
        "Full reliability bins, AUC, coverage, recall, "
        "date-block 95% intervals, preopen/10:00 diagnostics, next-hour targets and "
        "60-second delays are in FORECAST_SUMMARY.json.",
        "",
        f"Forward-research eligibility: **{forecast['forward_research_eligible']}**. "
        f"Passing would only permit later forward validation, not automatic activation.",
        "",
    ]
    for year, checks in forecast["promotion_checks"].items():
        lines.append(f"- {year}: {'PASS' if checks['passed'] else '; '.join(checks['failures'])}.")
    for year in (2022, 2023, 2024, 2025, 2026):
        subset = [r for r in coverage if r["date"].startswith(str(year))]
        lines.append(
            f"- {year} coverage: {sum(r['complete'] for r in subset)} complete / "
            f"{len(subset)} expected symbol-sessions."
        )
    lines += [
        "",
        "2026 SIP acquisition stopped after repeated data-service errors. Missing and "
        "unfetched dates remain explicit and are never filled with another venue. "
        "October Yahoo bars are stored separately and used only for the descriptive live audit. "
        "Historical bars are finalized; actual receipt/revision history is unavailable. "
        "Availability is modeled at bar end + 1 second, "
        "with a 60-second feature sensitivity. Any claimed signal must also work on the "
        "eventual forward feed.",
        "",
        "## Separate range strategy candidate",
        "",
        "The new pure script tests a first-30-minute range sweep and reclaim toward "
        "signal-time VWAP, after earlier VWAP reversals. "
        "Calls and puts reverse symmetrically. A fixed historical-range buffer defines "
        "underlying invalidation. "
        "The original continuation direction filter cannot validate this reversal; a "
        "future paper adapter must use this separate signal "
        "while retaining contract/Greek/event/quote/cash/daily-risk gates, one contract "
        "and the original 25%/30% premium stop/target. "
        "Missing data gives no candidate. There is no broker or options execution path in "
        "this research package.",
        "",
        "The replay enters at the first boundary open strictly after the decision's :15 "
        "availability allowance, freezes the VWAP target, "
        "takes the stop first on an ambiguous bar, handles adverse opening gaps and "
        "overlapping symbols, limits entries to three/day, "
        "and closes within 60 minutes or 15 minutes before the session close. Results "
        "below are **underlying opportunity diagnostics**, "
        "not a replication of live entries or option P&L. Costs are hypothetical "
        "underlying round-trip bps. "
        "Drawdown uses five-minute adverse marks and closes in equal-unit bps; it is not "
        "cash-account equity or exact intrabar chronology.",
        "",
        "| Year / arm | Signals | Mean net bps at 2bps cost | Mean net bps at 5bps cost | "
        "Win rate at 5bps |",
        "|---|---:|---:|---:|---:|",
    ]
    for key, m in ranges["by_year_arm"].items():
        display_key = key.replace("|", " / ")
        if m["trades"]:
            a, b = m["cost_scenarios"]["2"], m["cost_scenarios"]["5"]
            lines.append(
                f"| {display_key} | {m['trades']} | {a['mean_net_bps_per_signal']:.2f} | "
                f"{b['mean_net_bps_per_signal']:.2f} | {pct(b['win_rate'])} |"
            )
        else:
            lines.append(f"| {display_key} | 0 | — | — | — |")
    lines += [
        "",
        "ALL accepts the fixed setup, CHOP_OBSERVED also requires recent low path "
        "efficiency, and CHOP_FORECAST requires a strong "
        "09:50 chop forecast. Each arm has its own overlapping-position and entry-count "
        "simulation. None uses the later regime to select trades. "
        "The rule is a bounded hypothesis, not an optimized winner. Sparse or negative "
        "results are retained.",
        "",
        "## Decision and evidence",
        "",
        "Keep the baseline paper account and live bot unchanged. The scripts and "
        "diagnostics are complete; "
        "a reliable predictor and a profitable options range strategy are not established. "
        "No automatic regime switch is enabled. "
        "Further development needs complete fresh confirmation data and prospective "
        "exact-option quote/fill evidence against an unchanged baseline. "
        "Standing aside is a valid chop response; a second strategy must earn its place "
        "after costs rather than trade every session.",
        "",
        "Files: PROTOCOL.json and INITIAL_STATE.json in the parent directory; "
        "DATA_MANIFEST.json, COVERAGE.csv, DATASET.csv, "
        "FORECASTS.csv, FORECAST_SUMMARY.json, LIVE_TRADES_BY_REGIME.csv, LIVE_DAILY.csv, "
        "LIVE_AUDIT.json, "
        "RANGE_SIGNALS.csv, RANGE_UNAVAILABLE.csv, RANGE_SUMMARY.json and VALIDATION.json "
        "alongside this report.",
        "",
        "Methods references: [scikit-learn temporal "
        "evaluation](https://scikit-learn.org/stable/modules/cross_validation.html"
        "#time-series-split), "
        "[probability "
        "scoring](https://scikit-learn.org/stable/modules/model_evaluation.html#brier-score-loss), "
        "[Alpaca historical bars](https://docs.alpaca.markets/us/reference/stockbars).",
        "",
    ]
    validation_lines = [
        "| 2024 validation family | Multiclass Brier loss | Chop AUC | Trend AUC |",
        "|---|---:|---:|---:|",
    ]
    for name, m in forecast["validation_candidates"].items():
        validation_lines.append(
            f"| {name} | {m['brier']:.5f} | {m['classes']['CHOPPY']['auc']:.3f} | "
            f"{m['classes']['TREND']['auc']:.3f} |"
        )
    validation_lines += [
        "",
        "Lower Brier loss is better; AUC 0.5 is chance ranking. The learned families "
        "did not improve on the prior in the declared validation. The frozen selection "
        "therefore remains the prior, rather than manufacturing confident labels.",
        "",
    ]
    insert_at = next(i for i, line in enumerate(lines) if line.startswith("Features:"))
    lines[insert_at:insert_at] = validation_lines
    (output / "REPORT.md").write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    checks = protect()
    args.output.mkdir(parents=True, exist_ok=False)
    sessions, data, _, coverage, manifest = load()
    pd.DataFrame(coverage).to_csv(args.output / "COVERAGE.csv", index=False)
    (args.output / "DATA_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("Loaded historical bars and coverage", flush=True)
    frame = build_dataset(sessions, data)
    frame.to_csv(args.output / "DATASET.csv", index=False)
    print("Built strictly as-of dataset", len(frame), flush=True)
    audit = audit_live(args.output)
    print("Live audit reconciled", audit["all_trades"], flush=True)
    predictions, forecast = run_models(frame, args.output)
    print("Forecast comparison completed", forecast["selected_model"], flush=True)
    # A complete-calendar confirmation is required; partial-year availability cannot pass.
    complete_2026 = all(r["complete"] for r in coverage if r["date"].startswith("2026"))
    if not complete_2026:
        forecast["promotion_checks"]["2026"]["passed"] = False
        forecast["promotion_checks"]["2026"]["failures"].append("incomplete 2026 calendar coverage")
        forecast["forward_research_eligible"] = False
    (args.output / "FORECAST_SUMMARY.json").write_text(json.dumps(forecast, indent=2) + "\n")
    ranges = range_replay(sessions, data, predictions, args.output)
    render(args.output, audit, forecast, ranges, coverage)
    checks.update(protect())
    checks.update(
        {
            "status": "RESEARCH_COMPLETE_NO_PROMOTION",
            "orders": 0,
            "services_changed": False,
            "models_forward_research_eligible": forecast["forward_research_eligible"],
            "complete_2026_confirmation": complete_2026,
            "source_sha256": {
                str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in HERE.glob("*.py")
            },
        }
    )
    (args.output / "VALIDATION.json").write_text(json.dumps(checks, indent=2) + "\n")
    print("Study complete", args.output, flush=True)


if __name__ == "__main__":
    main()
