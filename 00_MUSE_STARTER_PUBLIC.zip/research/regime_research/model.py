"""Small, fixed model comparison with calendar splits and an explicit abstention."""

from __future__ import annotations

import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, log_loss, roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .data import CLASSES, FEATURES


def estimator(name):
    if name == "logistic":
        return make_pipeline(StandardScaler(), LogisticRegression(C=0.1, max_iter=1000))
    if name == "boosting":
        return HistGradientBoostingClassifier(
            max_iter=100,
            learning_rate=0.05,
            max_leaf_nodes=7,
            min_samples_leaf=40,
            l2_regularization=5.0,
            early_stopping=False,
            random_state=20261101,
        )
    raise ValueError("unknown model")


def eligible_training(frame, year, clock, target):
    return frame[
        (frame.date < f"{year}-01-01")
        & (frame.clock == clock)
        & (frame.target == target)
        & (frame.feature_status == "OK")
        & frame.outcome.isin(CLASSES)
    ]


def fit_bundle(frame, year, clock, target, name):
    train = eligible_training(frame, year, clock, target)
    if len(train) < 500 or train.outcome.nunique() != 3:
        raise ValueError("insufficient chronological training history")
    prior = np.array([(train.outcome == c).mean() for c in CLASSES])
    model = None if name == "prior" else estimator(name).fit(train[FEATURES], train.outcome)
    return {
        "model": model,
        "name": name,
        "prior": prior,
        "clock": clock,
        "target": target,
        "trained_through": train.date.max(),
        "training_rows": len(train),
        "features": FEATURES,
    }


def probabilities(bundle, features):
    if list(features.columns) != FEATURES or not np.isfinite(features.to_numpy()).all():
        raise ValueError("invalid feature input")
    model = bundle["model"]
    if model is None:
        return np.tile(bundle["prior"], (len(features), 1))
    prob = model.predict_proba(features)
    return prob[:, [list(model.classes_).index(c) for c in CLASSES]]


def strong_labels(prob):
    result = []
    for p in prob:
        order = np.argsort(p)
        top = order[-1]
        result.append(
            CLASSES[top]
            if CLASSES[top] != "MIXED" and p[top] >= 0.5 and p[top] - p[order[-2]] >= 0.1
            else "UNCERTAIN"
        )
    return result


def predict_frame(bundle, test, delayed=False):
    if len(test) and test.date.min() <= bundle["trained_through"]:
        raise ValueError("training overlaps prediction dates")
    status = "delay_feature_status" if delayed else "feature_status"
    features = ["delay_" + k for k in FEATURES] if delayed else FEATURES
    test = test[test[status] == "OK"].copy()
    if test.empty:
        return test
    p = probabilities(bundle, test[features].set_axis(FEATURES, axis=1))
    for j, c in enumerate(CLASSES):
        test["p_" + c] = p[:, j]
        test["baseline_" + c] = bundle["prior"][j]
    test["prediction"] = [CLASSES[i] for i in p.argmax(axis=1)]
    test["strong_signal"] = strong_labels(p)
    test["model"] = bundle["name"]
    test["trained_through"] = bundle["trained_through"]
    test["training_rows"] = bundle["training_rows"]
    test["delay_seconds"] = 60 if delayed else 1
    return test


def bootstrap(frame, value=None):
    actual = frame.outcome.to_numpy()
    p = frame[["p_" + c for c in CLASSES]].to_numpy()
    q = frame[["baseline_" + c for c in CLASSES]].to_numpy()
    truth = np.array([[c == a for c in CLASSES] for a in actual])
    temp = pd.DataFrame(
        {
            "date": frame.date.to_numpy(),
            "n": 1,
            "loss": np.sum((p - truth) ** 2, axis=1),
            "baseline_loss": np.sum((q - truth) ** 2, axis=1),
        }
    )
    if value:
        predicted = frame.strong_signal.to_numpy() == value
        temp["predicted"] = predicted.astype(int)
        temp["actual"] = (actual == value).astype(int)
        temp["correct"] = ((actual == value) & predicted).astype(int)
    matrix = temp.groupby("date", sort=True).sum().to_numpy()
    index = {c: i for i, c in enumerate(temp.columns[1:])}
    rng = np.random.default_rng(20261101)
    numbers = []
    for _ in range(1000):
        summed = matrix[rng.integers(len(matrix), size=len(matrix))].sum(axis=0)
        if value:
            if summed[index["predicted"]]:
                numbers.append(
                    summed[index["correct"]] / summed[index["predicted"]]
                    - summed[index["actual"]] / summed[index["n"]]
                )
        else:
            numbers.append(1 - summed[index["loss"]] / summed[index["baseline_loss"]])
    return np.quantile(numbers, [0.025, 0.975]).tolist() if numbers else None


def metrics(frame, intervals=False):
    frame = frame[frame.outcome.isin(CLASSES)]
    if frame.empty:
        return {"n": 0}
    p = frame[["p_" + c for c in CLASSES]].to_numpy()
    q = frame[["baseline_" + c for c in CLASSES]].to_numpy()
    actual = frame.outcome.to_numpy()
    truth = np.array([[c == a for c in CLASSES] for a in actual])
    loss = np.mean(np.sum((p - truth) ** 2, axis=1))
    prior_loss = np.mean(np.sum((q - truth) ** 2, axis=1))
    result = {
        "n": len(frame),
        "dates": frame.date.nunique(),
        "brier": float(loss),
        "baseline_brier": float(prior_loss),
        "brier_skill": float(1 - loss / prior_loss),
        "accuracy": float((frame.prediction == actual).mean()),
        "baseline_accuracy": float(np.mean(np.array(CLASSES)[q.argmax(axis=1)] == actual)),
        "balanced_accuracy": float(balanced_accuracy_score(actual, frame.prediction)),
        "classes": {},
    }
    # sklearn log_loss sorts label names alphabetically; explicitly supply its order.
    alphabetical = sorted(CLASSES)
    result["log_loss"] = float(
        log_loss(actual, p[:, [CLASSES.index(c) for c in alphabetical]], labels=alphabetical)
    )
    if intervals:
        result["brier_skill_date_bootstrap95"] = bootstrap(frame)
    for c in CLASSES:
        predicted = frame.strong_signal == c
        y = actual == c
        count, correct = int(predicted.sum()), int((y & predicted).sum())
        rate = float(y.mean())
        bins = []
        bin_ids = np.minimum((frame["p_" + c] * 10).astype(int), 9)
        for bin_id in range(10):
            lower = bin_id / 10
            selection = bin_ids == bin_id
            if selection.any():
                bins.append(
                    {
                        "lower": float(lower),
                        "n": int(selection.sum()),
                        "forecast": float(frame.loc[selection, "p_" + c].mean()),
                        "observed": float(np.mean(y[selection])),
                    }
                )
        result["classes"][c] = {
            "base_rate": rate,
            "auc": float(roc_auc_score(y, frame["p_" + c])) if y.any() and not y.all() else None,
            "strong_signals": count,
            "strong_dates": int(frame.loc[predicted, "date"].nunique()),
            "coverage": count / len(frame),
            "correct": correct,
            "precision": correct / count if count else None,
            "recall": correct / int(y.sum()) if y.any() else None,
            "precision_lift": correct / count - rate if count else None,
            "reliability_bins": bins,
            "precision_lift_date_bootstrap95": bootstrap(frame, c) if intervals and count else None,
        }
    return result


def run_models(frame, output):
    primary = frame[(frame.clock == "09:50:15") & (frame.target == "REMAINDER")]
    validation = {}
    for name in ("prior", "logistic", "boosting"):
        bundle = fit_bundle(frame, 2024, "09:50:15", "REMAINDER", name)
        validation[name] = metrics(
            predict_frame(bundle, primary[primary.date.str.startswith("2024")])
        )
    chosen = min(validation, key=lambda name: validation[name]["brier"])
    predictions = []
    bundles = output / "models"
    bundles.mkdir()
    for year in (2024, 2025, 2026):
        for clock in sorted(frame.clock.unique()):
            for target in sorted(frame.target.unique()):
                bundle = fit_bundle(frame, year, clock, target, chosen)
                test = frame[
                    (frame.date.str.startswith(str(year)))
                    & (frame.clock == clock)
                    & (frame.target == target)
                ]
                for delayed in (False, True):
                    predicted = predict_frame(bundle, test, delayed)
                    if not predicted.empty:
                        predictions.append(predicted)
                if year == 2026:
                    joblib.dump(bundle, bundles / f"{clock.replace(':', '')}_{target}.joblib")
    combined = pd.concat(predictions, ignore_index=True)
    combined.to_csv(output / "FORECASTS.csv", index=False)
    summary = {
        "selected_model": chosen,
        "selection_metric": "2024 09:50 remainder Brier",
        "validation_candidates": validation,
        "by_year_clock_target_delay": {},
    }
    for (year, clock, target, delay), group in combined.groupby(
        [combined.date.str[:4], "clock", "target", "delay_seconds"]
    ):
        key = f"{year}|{clock}|{target}|{delay}"
        summary["by_year_clock_target_delay"][key] = metrics(
            group, intervals=(clock == "09:50:15" and target == "REMAINDER" and delay == 1)
        )
    summary["by_symbol_primary"] = {
        f"{year}|{symbol}": metrics(g)
        for (year, symbol), g in combined[
            (combined.clock == "09:50:15")
            & (combined.target == "REMAINDER")
            & (combined.delay_seconds == 1)
        ].groupby([combined.date.str[:4], "symbol"])
    }
    checks = {}
    for year in (2025, 2026):
        m = summary["by_year_clock_target_delay"].get(f"{year}|09:50:15|REMAINDER|1", {"n": 0})
        failures = []
        if not m["n"] or m.get("brier_skill", 0) <= 0:
            failures.append("no positive Brier skill")
        for c in ("TREND", "CHOPPY"):
            cm = m.get("classes", {}).get(c, {})
            ci = cm.get("precision_lift_date_bootstrap95")
            if cm.get("strong_signals", 0) < 50 or cm.get("strong_dates", 0) < 30:
                failures.append(c + " insufficient strong forecast sample")
            if not ci or ci[0] <= 0:
                failures.append(c + " positive lift not established")
        checks[str(year)] = {"passed": not failures, "failures": failures}
    summary["forward_research_eligible"] = all(c["passed"] for c in checks.values())
    summary["promotion_checks"] = checks
    (output / "FORECAST_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
    return combined, summary
