"""Strict session coverage and as-of features shared by offline and future inference."""

from __future__ import annotations

import gzip
import hashlib
import json
import math
from collections import defaultdict
from datetime import UTC, datetime, time, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import pandas_market_calendars as mcal

from research.regime_backtest.evaluate import decode_response, stamp
from tools.market_calendar import EASTERN

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SYMBOLS = ("SPY", "QQQ")
CLASSES = ("TREND", "CHOPPY", "MIXED")
FEATURES = json.loads((HERE / "PROTOCOL.json").read_text())["features"]


def schedule():
    frame = mcal.get_calendar("NYSE").schedule("2022-01-01", "2026-10-30")
    return {
        i.date().isoformat(): (r.market_open.to_pydatetime(), r.market_close.to_pydatetime())
        for i, r in frame.iterrows()
    }


def valid(bar):
    values = [bar[k] for k in ("open", "high", "low", "close", "volume")]
    return all(
        not isinstance(v, bool) and isinstance(v, (int, float)) and math.isfinite(v) for v in values
    ) and (
        0
        < bar["low"]
        <= min(bar["open"], bar["close"])
        <= max(bar["open"], bar["close"])
        <= bar["high"]
        and bar["volume"] >= 0
    )


def path_outcome(bars):
    """Independent five-minute path outcome; no input ever goes to a forecaster."""
    if len(bars) < 6:
        return {"label": "UNKNOWN"}
    values = np.array([bars[0]["open"], *[b["close"] for b in bars]], dtype=float)
    x = np.arange(len(values), dtype=float)
    x -= x.mean()
    centered = values - values.mean()
    sst = centered @ centered
    r2 = float((x @ centered) ** 2 / (x @ x) / sst) if sst else 0.0
    high, low = max(b["high"] for b in bars), min(b["low"] for b in bars)
    width = high - low
    displacement = values[-1] - values[0]
    ratio = abs(displacement) / width if width else 0.0
    location = (values[-1] - low) / width if width else 0.5
    edge = displacement > 0 and location >= 0.8 or displacement < 0 and location <= 0.2
    label = (
        "TREND"
        if r2 >= 0.65 and ratio >= 0.6 and edge
        else "CHOPPY"
        if r2 <= 0.25 and ratio <= 0.35
        else "MIXED"
    )
    return {
        "label": label,
        "r_squared": r2,
        "net_to_range": float(ratio),
        "close_location": float(location),
        "return_bps": float(displacement / values[0] * 10000),
    }


def window(mapping, start, end, minutes=5):
    keys = [
        start + timedelta(minutes=i)
        for i in range(0, int((end - start).total_seconds() / 60), minutes)
    ]
    return [mapping[k] for k in keys] if keys and all(k in mapping for k in keys) else None


def aggregate(mapping, opened, closed):
    result = {}
    for at in (
        opened + timedelta(minutes=i)
        for i in range(0, int((closed - opened).total_seconds() / 60), 5)
    ):
        group = window(mapping, at, at + timedelta(minutes=5), minutes=1)
        if group:
            result[at] = {
                "timestamp": at.isoformat(),
                "open": group[0]["open"],
                "close": group[-1]["close"],
                "high": max(b["high"] for b in group),
                "low": min(b["low"] for b in group),
                "volume": sum(b["volume"] for b in group),
            }
    return result


def load():
    sessions = schedule()
    one_minute, five_minute, audit = defaultdict(dict), defaultdict(dict), defaultdict(dict)
    manifest = []
    paths = sorted((ROOT / "research/regime_backtest/data").glob("*.json.gz"))
    paths += sorted((HERE / "data_2026").glob("*.json.gz"))
    for path in paths:
        with gzip.open(path, "rt") as f:
            packet = json.load(f)
        is_new = path.parent.name == "data_2026"
        if not is_new:
            response = decode_response(packet)
        else:
            response = packet["response"]
            if response["request"]["feed"] != "sip":
                raise ValueError("unexpected source")
            if packet["source_counts"]["records"] >= response["request"]["limit"]:
                raise ValueError("capped query")
            if packet.get("columns"):
                response = {
                    **response,
                    "bars": {
                        s: [dict(zip(packet["columns"], b, strict=True)) for b in bars]
                        for s, bars in response["bars"].items()
                    },
                }
        count = sum(len(bars) for bars in response["bars"].values())
        if count != response["counts"]["records"]:
            raise ValueError("archive count mismatch")
        manifest.append(
            {
                "file": str(path.relative_to(ROOT)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "rows": count,
                "request": response["request"],
                "source_queries": packet.get("source_queries"),
                "source_counts": packet.get("source_counts"),
            }
        )
        for symbol, bars in response["bars"].items():
            if symbol not in SYMBOLS:
                raise ValueError("unexpected symbol")
            for bar in bars:
                at = stamp(bar["timestamp"])
                day = at.astimezone(EASTERN).date().isoformat()
                if day not in sessions or not sessions[day][0] <= at < sessions[day][1]:
                    continue
                if not valid(bar) or at.second or at.microsecond:
                    raise ValueError("invalid historical bar")
                target = (
                    five_minute
                    if response["request"]["timeframe"] == "5Min"
                    else audit
                    if is_new
                    else one_minute
                )
                if at in target[(day, symbol)] and target[(day, symbol)][at] != bar:
                    raise ValueError("conflicting bars")
                target[(day, symbol)][at] = bar
    for (day, symbol), bars in one_minute.items():
        five_minute[(day, symbol)] = aggregate(bars, *sessions[day])
    coverage = []
    for day, (opened, closed) in sessions.items():
        for symbol in SYMBOLS:
            bars = five_minute[(day, symbol)]
            coverage.append(
                {
                    "date": day,
                    "symbol": symbol,
                    "expected_5m": int((closed - opened).total_seconds() / 300),
                    "observed_5m": len(bars),
                    "complete": window(bars, opened, closed) is not None,
                }
            )
    return sessions, five_minute, audit, coverage, manifest


def vwap_series(bars):
    volume = np.array([b["volume"] for b in bars], dtype=float)
    typical = np.array([(b["high"] + b["low"] + b["close"]) / 3 for b in bars])
    totals = np.cumsum(volume)
    return np.divide(
        np.cumsum(typical * volume), totals, out=np.full(len(bars), np.nan), where=totals > 0
    )


def crossings(closes, vwaps):
    signs = np.sign(np.asarray(closes) - np.asarray(vwaps))
    nonzero = signs[signs != 0]
    return int(np.sum(nonzero[1:] != nonzero[:-1]))


def feature_row(days, sessions, data, day, symbol, clock, delay=1):
    """Return features or explicit reason; all history is before the decision."""
    index = days.index(day)
    if index < 20:
        return None, "prior_20_session_warmup"
    previous = [window(data[(d, symbol)], *sessions[d]) for d in days[index - 20 : index]]
    if any(b is None for b in previous):
        return None, "prior_session_gap"
    prior = previous[-1]
    prior_close = prior[-1]["close"]
    stats = path_outcome(prior)
    ranges = [
        (max(b["high"] for b in bars) - min(b["low"] for b in bars)) / bars[0]["open"] * 10000
        for bars in previous
    ]
    f = dict(zip(FEATURES, [0.0] * len(FEATURES), strict=True))
    f.update(
        symbol_qqq=float(symbol == "QQQ"),
        prior_range_bps=ranges[-1],
        prior_net_to_range=stats["net_to_range"],
        prior_r_squared=stats["r_squared"],
        prior_5_session_return=prior_close / previous[-5][0]["open"] - 1,
        prior_20_session_return=prior_close / previous[0][0]["open"] - 1,
        prior_20_session_mean_range_bps=float(np.mean(ranges)),
    )
    opened, _ = sessions[day]
    at = datetime.combine(
        datetime.fromisoformat(day).date(), time.fromisoformat(clock), EASTERN
    ).astimezone(UTC)
    if at < opened:
        return f, "OK"
    available_end = at - timedelta(seconds=delay)
    blocks = max(0, int((available_end - opened).total_seconds() // 300))
    end = opened + timedelta(minutes=5 * blocks)
    early = window(data[(day, symbol)], opened, end)
    peer = "QQQ" if symbol == "SPY" else "SPY"
    peer_early = window(data[(day, peer)], opened, end)
    if not early or not peer_early:
        return None, "early_or_peer_gap"
    opening = early[0]["open"]
    high, low = max(b["high"] for b in early), min(b["low"] for b in early)
    net = early[-1]["close"] - opening
    historical_early_volume = np.mean(
        [sum(b["volume"] for b in bars[:blocks]) for bars in previous]
    )
    if not historical_early_volume:
        return None, "zero_prior_volume"
    f.update(
        open_gap_bps=(opening / prior_close - 1) * 10000,
        early_return_bps=net / opening * 10000,
        early_range_bps=(high - low) / opening * 10000,
        early_net_to_range=abs(net) / (high - low) if high > low else 0,
        early_vwap_crossings=crossings([b["close"] for b in early], vwap_series(early)),
        early_relative_volume=sum(b["volume"] for b in early) / historical_early_volume,
        early_peer_return_bps=(peer_early[-1]["close"] / peer_early[0]["open"] - 1) * 10000,
    )
    return f, "OK"


def build_dataset(sessions, data):
    rows = []
    days = sorted(sessions)
    for day in days:
        opened, closed = sessions[day]
        for symbol in SYMBOLS:
            for clock in ("09:25:15", "09:50:15", "10:00:15"):
                at = datetime.combine(
                    datetime.fromisoformat(day).date(), time.fromisoformat(clock), EASTERN
                ).astimezone(UTC)
                start = (
                    opened
                    if at < opened
                    else at.replace(second=0) + timedelta(minutes=5 - at.minute % 5)
                )
                features, reason = feature_row(days, sessions, data, day, symbol, clock)
                delayed, delay_reason = feature_row(
                    days, sessions, data, day, symbol, clock, delay=60
                )
                for target in ("REMAINDER", "NEXT_60_MINUTES"):
                    end = (
                        closed
                        if target == "REMAINDER"
                        else min(start + timedelta(minutes=60), closed)
                    )
                    bars = window(data[(day, symbol)], start, end)
                    out = path_outcome(bars) if bars else {"label": "UNKNOWN"}
                    rows.append(
                        {
                            "date": day,
                            "symbol": symbol,
                            "clock": clock,
                            "target": target,
                            "forecast_at": at.isoformat(),
                            "outcome_start": start.isoformat(),
                            "outcome_end": end.isoformat(),
                            "outcome": out["label"],
                            "feature_status": reason,
                            "delay_feature_status": delay_reason,
                            **(features or {}),
                            **{"delay_" + k: v for k, v in (delayed or {}).items()},
                        }
                    )
    return pd.DataFrame(rows)
