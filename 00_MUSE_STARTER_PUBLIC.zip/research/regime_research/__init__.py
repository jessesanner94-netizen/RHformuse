"""Offline regime forecasting and range-strategy research; no order authority."""
