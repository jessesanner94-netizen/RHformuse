"""Explicit range-reclaim hypothesis, independent of the continuation bot.

Emits a directional research candidate only. No broker or option execution adapter.
"""

from __future__ import annotations

from datetime import timedelta

import numpy as np

from .data import crossings, vwap_series


def candidate(bars, mean_five_minute_range):
    """All bars must already be complete and available; timestamps checked by caller."""
    if len(bars) < 6 or not np.isfinite(mean_five_minute_range) or mean_five_minute_range <= 0:
        return None
    initial = bars[:6]
    low, high = min(b["low"] for b in initial), max(b["high"] for b in initial)
    latest = bars[-1]
    vwaps = vwap_series(bars)
    vwap = float(vwaps[-1])
    if not np.isfinite(vwap) or high <= low or len(bars) <= 6:
        return None
    if crossings([b["close"] for b in bars[:-1]], vwaps[:-1]) < 2:
        return None
    if latest["low"] < low < latest["close"] < vwap and latest["close"] > latest["open"]:
        direction, stop = 1, low - mean_five_minute_range
    elif latest["high"] > high > latest["close"] > vwap and latest["close"] < latest["open"]:
        direction, stop = -1, high + mean_five_minute_range
    else:
        return None
    reward = direction * (vwap - latest["close"])
    risk = direction * (latest["close"] - stop)
    if risk <= 0 or reward / risk < 1:
        return None
    closes = np.array([b["close"] for b in bars[-6:]])
    travel = np.abs(np.diff(closes)).sum()
    observed_chop = abs(closes[-1] - closes[0]) / travel <= 0.3 if travel else True
    return {
        "direction": direction,
        "option_type": "CALL" if direction == 1 else "PUT",
        "target": vwap,
        "stop": stop,
        "observed_chop": bool(observed_chop),
        "signal_close": latest["close"],
        "underlying_reward_risk": reward / risk,
        "risk_policy": (
            "Original option premium stop/target, contract/cash/event/risk gates "
            "required separately"
        ),
        "status": "RESEARCH_CANDIDATE_ONLY",
    }


def available_candidate(mapping, opened, as_of, prior_mean_range, delay_seconds=1):
    """As-of fence used by replay and future paper integration."""
    eligible = {
        t: b
        for t, b in mapping.items()
        if t >= opened and t + timedelta(minutes=5, seconds=delay_seconds) <= as_of
    }
    expected = int((as_of - timedelta(seconds=delay_seconds) - opened).total_seconds() // 300)
    keys = [opened + timedelta(minutes=5 * i) for i in range(max(0, expected))]
    if not keys or any(t not in eligible for t in keys):
        return None
    return candidate([eligible[t] for t in keys], prior_mean_range)


def simulate_path(signal, mapping, entry_at, close):
    """Underlying diagnostic with next-bar entry and conservative ambiguous ordering."""
    if entry_at not in mapping:
        return None
    direction = signal["direction"]
    entry = mapping[entry_at]["open"]
    stop, target = signal["stop"], signal["target"]
    if direction * (entry - stop) <= 0 or direction * (target - entry) <= 0:
        return None
    if direction * (target - entry) / (direction * (entry - stop)) < 1:
        return None
    end = min(entry_at + timedelta(minutes=60), close - timedelta(minutes=15))
    marks = []
    at = entry_at
    while at < end:
        if at not in mapping:
            return None  # Never invent a price through a gap.
        b = mapping[at]
        stop_hit = b["low"] <= stop if direction == 1 else b["high"] >= stop
        target_hit = b["high"] >= target if direction == 1 else b["low"] <= target
        if stop_hit:
            # Gap through the stop fills at the less favorable open.
            exit_price = min(stop, b["open"]) if direction == 1 else max(stop, b["open"])
            reason = "AMBIGUOUS_STOP_FIRST" if target_hit else "INVALIDATION"
        elif target_hit:
            exit_price, reason = target, "VWAP_TARGET"
        else:
            exit_price, reason = b["close"], "TIME"
        # Adverse intrabar mark before close/exit prevents closed-trade-only drawdown.
        adverse = min(b["low"], exit_price) if direction == 1 else max(b["high"], exit_price)
        marks.append(
            {
                "at": at.isoformat(),
                "adverse_bps": direction * (adverse / entry - 1) * 10000,
                "close_bps": direction * (exit_price / entry - 1) * 10000,
            }
        )
        if stop_hit or target_hit:
            return {
                "entry": entry,
                "exit": exit_price,
                "exit_at": (at + timedelta(minutes=5)).isoformat(),
                "gross_bps": direction * (exit_price / entry - 1) * 10000,
                "reason": reason,
                "marks": marks,
            }
        at += timedelta(minutes=5)
    if not marks:
        return None
    return {
        "entry": entry,
        "exit": exit_price,
        "exit_at": end.isoformat(),
        "gross_bps": direction * (exit_price / entry - 1) * 10000,
        "reason": "TIME",
        "marks": marks,
    }
