"""Retrospective attribution of actual recorded live fills, not a replay."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from datetime import timedelta

import numpy as np
import pandas as pd

from research.regime_backtest.evaluate import stamp
from tools.market_calendar import EASTERN

from .data import HERE, ROOT, path_outcome, schedule, valid, window


def grouped_trade_stats(rows):
    if not rows:
        return {"trades": 0}
    pnl = np.array([r["modeled_net_pnl"] for r in rows])
    cumulative = np.r_[0, pnl.cumsum()]
    return {
        "trades": len(rows),
        "dates": len({r["date"] for r in rows}),
        "broker_fill_gross_pnl": float(sum(r["gross_pnl"] for r in rows)),
        "modeled_net_pnl": float(pnl.sum()),
        "expectancy_dollars": float(pnl.mean()),
        "win_rate": float(np.mean(pnl > 0)),
        "closed_trade_path_drawdown_dollars": float(
            np.max(np.maximum.accumulate(cumulative) - cumulative)
        ),
        "losses": int(sum(pnl < 0)),
        "wins": int(sum(pnl > 0)),
    }


def audit_live(output):
    state_path = ROOT / "state/options/python_jev_green_lock_20261009/live/STATE.json"
    state = json.loads(state_path.read_text())
    trades = state["recent_closed_positions"]
    if len({t["position_id"] for t in trades}) != len(trades):
        raise ValueError("duplicate closed positions")
    events = [json.loads(x) for x in state_path.with_name("EVENTS.jsonl").read_text().splitlines()]
    exits = [e for e in events if e["event"] == "LIVE_EXIT_FILLED"]

    def key(r, event=False):
        return (
            stamp(r["filled_at"] if event else r["exit_at"]),
            r["symbol"],
            r["option_type"],
            r["strike"],
            r["expiration"],
            r["realized_pnl"],
        )

    if Counter(key(t) for t in trades) != Counter(key(e, True) for e in exits):
        raise ValueError("closed state and exit events do not reconcile")
    bars = {}
    files = []
    for path in sorted((HERE / "data_2026").glob("yahoo_*.json")):
        packet = json.loads(path.read_text())
        if packet["provider"] != "vibe/yfinance":
            raise ValueError("audit source mismatch")
        files.append(
            {
                "file": str(path.relative_to(ROOT)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "request": packet["request"],
                "provider": packet["provider"],
                "timestamp_assumption": packet["timestamp_assumption"],
                "rows": sum(len(values) for values in packet["data"].values()),
            }
        )
        for symbol, values in packet["data"].items():
            symbol = symbol.removesuffix(".US")
            for b in values:
                # The connector returns naive exchange-local timestamps. Assumption is disclosed.
                at = stamp(b["trade_date"] + "-04:00")
                if not valid(b):
                    raise ValueError("invalid audit bar")
                bars.setdefault((b["trade_date"][:10], symbol), {})[at] = b
    sessions = schedule()
    rows = []
    for t in sorted(trades, key=lambda r: r["entry_at"]):
        entered, exited = stamp(t["entry_at"]), stamp(t["exit_at"])
        day = entered.astimezone(EASTERN).date().isoformat()
        opened, closed = sessions[day]
        mapping = bars.get((day, t["symbol"]), {})
        start = entered.replace(second=0, microsecond=0) + timedelta(minutes=5 - entered.minute % 5)
        held_end = exited.replace(second=0, microsecond=0) - timedelta(minutes=exited.minute % 5)
        labels = {}
        for name, begin, end in (
            ("full_session", opened, closed),
            ("entry_forward", start, closed),
            ("next_60", start, min(start + timedelta(minutes=60), closed)),
            ("held_window", start, held_end),
        ):
            sample = window(mapping, begin, end) if end > begin else None
            labels[name] = path_outcome(sample)["label"] if sample else "UNKNOWN"
        costs = t.get("entry_cost_estimate", 0) + t.get("exit_cost_estimate", 0)
        gross = (t["exit_price"] - t["entry_price"]) * 100 * t["quantity"]
        if (
            abs(gross - t["gross_realized_pnl"]) > 1e-6
            or abs(gross - costs - t["realized_pnl"]) > 1e-6
        ):
            raise ValueError("fill accounting mismatch")
        rows.append(
            {
                "position_id": t["position_id"],
                "date": day,
                "symbol": t["symbol"],
                "option_type": t["option_type"],
                "entry_at": t["entry_at"],
                "exit_at": t["exit_at"],
                "gross_pnl": t["gross_realized_pnl"],
                "modeled_costs": costs,
                "modeled_net_pnl": t["realized_pnl"],
                "exit_reason": t["exit_reason"],
                "held_complete_5m_blocks": max(0, int((held_end - start).total_seconds() / 300)),
                **labels,
            }
        )
    pd.DataFrame(rows).to_csv(output / "LIVE_TRADES_BY_REGIME.csv", index=False)
    days = []
    first, last = min(r["date"] for r in rows), max(r["date"] for r in rows)
    for day in sessions:
        if not first <= day <= last:
            continue
        selected = [r for r in rows if r["date"] == day]
        days.append(
            {
                "date": day,
                "trade_count": len(selected),
                "gross_pnl": sum(r["gross_pnl"] for r in selected),
                "modeled_net_pnl": sum(r["modeled_net_pnl"] for r in selected),
            }
        )
    pd.DataFrame(days).to_csv(output / "LIVE_DAILY.csv", index=False)
    summary = {
        "strategy_epoch": state["strategy_epoch"],
        "source": "vibe/yfinance 5m, retrospective",
        "source_files": files,
        "closed_state_matches_exit_events": True,
        "state_net_pnl_matches_trades": abs(
            sum(t["realized_pnl"] for t in trades) - state["realized_pnl"]
        )
        < 1e-6,
        "all_trades": grouped_trade_stats(rows),
        "by_definition": {},
        "trading_dates": len(days),
        "dates_with_trades": sum(d["trade_count"] > 0 for d in days),
        "limitations": [
            "13-trade current-strategy sample cannot establish a stable regime effect or causality",
            "Retrospective regimes are not available at entry; cannot use to claim a "
            "profitable gate",
            "5m bars cannot resolve most short holding windows; UNKNOWN retained",
            "Gross uses broker fill prices; net subtracts stored modeled costs, not "
            "verified broker fees",
            "Drawdown is closed-trade path only, not account mark-to-market",
            "Older strategy epochs are excluded rather than pooled",
        ],
    }
    for definition in ("full_session", "entry_forward", "next_60", "held_window"):
        summary["by_definition"][definition] = {
            c: grouped_trade_stats([r for r in rows if r[definition] == c])
            for c in ("TREND", "CHOPPY", "MIXED", "UNKNOWN")
        }
    (output / "LIVE_AUDIT.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary
