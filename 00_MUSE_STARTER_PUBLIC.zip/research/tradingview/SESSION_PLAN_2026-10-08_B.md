# October 8 — frozen follow-up to TVR-0095 baseline

Declared after batch A, before any B results. A's only positive cell is QQQ5m strict: +$170.304451/84 trades/PF1.164643, native MTM drawdown $399.169297. Seven other cells lose. No promotion; the apparent lead could be a regime/sample artifact. All eight full ledgers pass identity/net/commission/time/session/exposure checks.

Use the exact saved95source, RTH standard candles, $10K/95%whole shares. Test twelve cells, no parameter search:

1. QQQ5m strict full available pre-October range, four adverse ticks, .01% commission/side.
2. Same, four ticks and .02% commission/side; combined higher-cost stress, not an isolated fee attribution.
3. QQQ5m strict baseline costs, Jan1–July1 exclusive (actual earliest Apr6).
4. Same, July1–Oct1 exclusive. Reset account for each chronological slice; retrospective development, NOT untouched OOS.
5–8. Original baseline (VWAP outside-cloud=false), remove RSI alone then MACD alone on QQQ5m and SPY5m. All other conditions/costs/dates unchanged.
9–12. Strict95 on SPY1m, SPY5m, QQQ1m, QQQ5m, matched September1–October1 exclusive; history before September1 is indicator warmup. No choosing overlap dates on P&L. This aligns coverage but does not independently prove feed aggregation/tick-fill parity.

Keep dates/costs/input flags independently captured with each cell. Native percent API fields are fractions; display100times values. Preserve all failed results, do not select a direction by deleting trades from the old ledger, and do not infer options returns. October2026 and July–December2025 performance remain untouched.

Native atomic collector reads chart symbol/resolution, selected95input values, report.performance and95table graphics in one page evaluation. First QQQ5m strict atomic metrics exactly matched purpose-built data_get_strategy_results. All collected cells must independently reconcile full trade records, native metrics, fees, three/day/session timing and exposure; no stale/partial report counted.

Following this batch, implement a separate ID for frozen entry protection and optional2R target; do not silently add protection to95. A source-defined original close-based exit is not a deployment-ready risk implementation regardless of profit.
