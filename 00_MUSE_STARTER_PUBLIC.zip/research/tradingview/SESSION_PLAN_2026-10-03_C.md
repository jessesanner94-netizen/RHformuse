# Batch C: divergence reversal timing, frozen before results

Batch B's QQQ84 weak gain fails four-tick and JulSep checks; SPY loses. Do not tune its brackets. Keep ATR14 frozen1/2 bracket, two-close VWAP exit, time/daily/cost/date limits.

New86 removes only EMA27 slope from84 entry. Price must remain above/below27 for calls/puts, matching user entry-only interpretation; RSI-or-MACD regular divergence stays mandatory, and histogram still changes in favorable direction twice.

New87 adds a momentum-phase restriction to86: calls require histogram still below zero but rising twice, puts histogram still above zero but falling twice. This tests weakening opposite momentum rather than chasing established same-direction momentum. Same confirmed pivots and signals; no EMA length or threshold sweep.

Four base5m RTH cells on SPY/QQQ. Maximum16cells if positive candidates justify4tick, reset-account chronological splits and a single near-parameter stress. October reserved. All results retrospective, not untouched OOS. Record Sharpe, Sortino, PF, return, descriptive CAGR, MTM drawdown, counts and exact inputs/full trades. Negative versions preserved; no core changes.
