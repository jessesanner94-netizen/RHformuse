# Experimental indicators

Indicators in this file are research tools, not validated strategies and not live-trading rules.

## TVI-0001 — Volume-Weighted Ichimoku Cloud

Source: `indicators/TVI-0001_volume_weighted_ichimoku_cloud.txt`

The prototype retains Ichimoku's default 9/26/52 lengths and 26-bar forward displacement, but
replaces the classic highest-high/lowest-low midpoint at each horizon with a rolling VWMA of the
selected price source (HLC3 by default):

- Volume conversion line: `VWMA(HLC3, 9)`
- Volume base line: `VWMA(HLC3, 26)`
- Leading span A: average of the volume conversion and volume base lines
- Leading span B: `VWMA(HLC3, 52)`
- Optional lagging span: `VWMA(close, 9)` shifted back 26 bars

The cloud is green when volume span A is above volume span B and red otherwise. Optional gray
lines show the standard Ichimoku cloud for visual comparison. Alert conditions exist for
conversion/base crosses and cloud flips.

This is not a canonical Ichimoku calculation. It intentionally answers a different question:
where has price concentrated after weighting each bar by traded volume? High-volume bars influence
the cloud more strongly, while low-volume price excursions influence it less. On instruments with
missing, synthetic, or non-comparable volume, the result may be misleading.

Status: `PROTOTYPE`. No entry, exit, stop, target, or profitability claim has been attached to it.

## TVI-0002 — Volume-Weighted Extreme Ichimoku

Source: `indicators/TVI-0002_volume_weighted_extreme_ichimoku.txt`

This version preserves Ichimoku's range-extreme construction. For each 9-, 26-, or 52-bar window,
it finds the highest high and lowest low exactly as classic Ichimoku does. Instead of placing the
line at their equal midpoint, it weights those two prices by the total volume of the bars that
established the extremes:

`weighted center = (highest high × high-bar volume + lowest low × low-bar volume) / (high-bar volume + low-bar volume)`

The default volume influence is 100%. An input from 0% to 100% blends between the classic equal
midpoint and the fully volume-weighted center. Conversion and base retain the 9/26 ranges, leading
span A remains their average, leading span B uses the weighted 52-bar range, and both leading spans
retain the 26-bar forward displacement. The traditional close-based lagging span is available but
off by default.

This is closer to Ichimoku than TVI-0001 because recent range extremes still define every line.
However, ordinary candle volume is the total volume of an extreme's bar; it does not prove that
the volume traded exactly at the bar's high or low. A true price-level weighting would require
lower-timeframe or volume-profile data and would be a materially different indicator.

Status: `PROTOTYPE`. No profitability claim. Saved TradingView identity and
native chart attachment verified October 1. The separate TVR-0079 strategy
tested one fixed crossover/ATR-exit interpretation against classic Ichimoku:
all four fully weighted SPY/QQQ 5m/15m cells lost. Indicator remains available
for visual use; this is not a trading endorsement. Results and execution caveats
are in `results/TVR-0079_2026-10-01.md`.
