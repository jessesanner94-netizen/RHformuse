# Session plan 2026-09-28 A — video-derived 9 EMA / VWAP cross

Predeclared before any TVR-0074 result. The attached 33.6-second video shows an SLV 3-minute
chart and an indicator titled `9EMA/VWAP X`. Its visible settings define bullish cross as
`EMA > VWAP`, bearish cross as `EMA < VWAP`, and restrict crosses to 09:30–16:00. The narration
says to enter on the 3-minute chart when the candle breaks through VWAP and to exit when a candle
closes through the EMA. The example entry candle closes above VWAP as the 9 EMA crosses above it.

## Frozen faithful baseline: TVR-0074

- Chart: 3 minutes only.
- Instruments: SPY and QQQ, matching this project's authorized research universe. The video uses
  SLV only as its example; an SLV result would not answer the project's SPY/QQQ question.
- VWAP: regular-session cumulative typical-price VWAP, reset at the 09:30 ET session open.
- EMA: 9-bar EMA of close.
- Long entry: 9 EMA crosses above regular-session VWAP during 09:30–16:00 ET.
- Short entry: 9 EMA crosses below regular-session VWAP during 09:30–16:00 ET.
- Entry timing: signal-bar close, because the video discusses the candle closing over VWAP and
  because intrabar tick history is not available for the full backtest.
- Long exit: a completed candle closes from at/above the 9 EMA to below it.
- Short exit: a completed candle closes from at/below the 9 EMA to above it.
- One open position, no pyramiding, no stop or target invented beyond the described EMA exit.
- No new entry on the 16:00 closing bar; force flat at the end of the regular session so this
  remains a day strategy. This is an explicit safety/interpretation choice because the clip does
  not explain overnight handling.
- Economics: $10,000 initial capital, 95% of equity share sizing, 0.01% commission per side,
  two ticks of adverse slippage per order, `process_orders_on_close=true`.

Record exact Strategy Tester identity, net dollars, profit factor, TradingView mark-to-market
drawdown, win rate, and completed trades. This is an underlying-share proxy, not option P&L.

## Bounded experiment ladder, declared before seeing baseline results

Run these only after TVR-0074 is recorded, without changing their rules around the outcome:

1. **TVR-0075 literal candle-cross interpretation.** Enter when a completed candle crosses and
   closes through VWAP while the 9 EMA is already on the same side. Retain the same EMA exit,
   costs, session, and end-of-day flat rule. This tests the narration rather than the indicator's
   visible EMA/VWAP-cross definition.
2. **TVR-0076 anti-chop confirmation.** Start from TVR-0074, but require the signal direction to
   agree with the last completed 15-minute EMA20/EMA50 trend and skip the first 15 minutes. Retain
   all other rules and costs. This tests one causal refinement: avoiding flat/opening chop.

Use SPY and QQQ at 3 minutes for the three-strategy comparison. Do not promote a candidate that
depends on one ETF, has weak profit relative to drawdown, or has too few trades. Only if a candidate
is positive on both ETFs should it receive doubled-slippage and chronological-window checks. No
live orders, policy changes, scheduler changes, purchases, or claims about options profitability.

## Diagnostic addendum after the frozen three-strategy matrix

The baseline and both predeclared variants lost on both ETFs. Before ending the idea, split the
least-negative variant (TVR-0076) into unchanged long-only TVR-0077 and short-only TVR-0078 controls.
Test QQQ first. Test SPY only for a side that is positive on QQQ. This is a direction attribution
check, not permission to change entries, exits, filters, costs, or sizing after seeing the result.
