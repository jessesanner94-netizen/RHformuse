# TradingView Strategy Research Lab

## Latest completed evaluation — October 8, 2026

October8 completed28 actual native TradingView cells under frozen plansA/B/C: standard Ichimoku9/26/52 plus RTHVWAP, RSI14, MACD12/26/9, confirmed Tenkan pullback. TVR-0095 and0096 REJECTED as robust standalone candidates; no promotion. QQQ5strict95+$170.30/84/PF1.165 losesJulSep-$260.52 and4ticks+doubledfee-$32.76; matched September strict1m/5m bothETFslose. DroppingMACD weak positives95SPY+$82.93/147,QQQ+$60.46/164; RSIremovalidentical5mledgers. FrozenATRstop96+optional2R: noPF1.2cell; noMACDstop-onlySPY+$30.29/169,QQQ+$57.45/183 averages$0.18/$0.31, addingtargetlosesboth. Fullsource.txt/nativecopies/hashmatches/all28ledgers/40audit tests preserved; no independent95/96tick or replay equity parity. Native per-bar equity endpoint unavailable; summaries/ledgers retained. July–December2025 andOctober2026holdoutperformanceunopened. Volumeprofile/POC/value-area/RVOL primary-source consideration documented; defer extra filters due weak economics. Evaluation stopped at the goal's information-value condition, NOT a profitable-production success. Historical top3screening priorities unchanged; no validated winner, no broker/Luna/runtime/core/paper-ledger/scheduler/purchase changes.

Exact editable Pine: strategies/TVR-0095_ichimoku_vwap_tenkan_pullback.txt and strategies/TVR-0096_ichimoku_vwap_frozen_protection.txt. Human reports: results/TVR-0095_2026-10-08.md and results/TVR-0096_2026-10-08.md; full native metrics/trades/settings in matching A/B/C JSONs. RESEARCH_CHECKPOINT.md supersedes earlier next-step/ACTIVE statements retained below as history. Native tests layout currentlySPY5m RTH,0096noMACD+2R (losing last tested cell), studyhnskvF; only research study swapped. Source95preserved, unrelated saved scripts/studies retained.

Research goal's specified hypothesis has been evaluated with a negative result. A materially different research campaign requires new direction; nothing here authorizes production trading or strategy adoption.

This folder is the persistent memory for a dedicated Codex Luna research task. The earlier Luna
setup checks were disposable sessions; they were not a chat you could return to.

## Interact with Luna directly in Codex Desktop

1. Start a new task in the **Robinhood Agentic** project.
2. Select **GPT-5.6 Luna** and **low** reasoning for inexpensive experiment batches. Increase the
   reasoning level only for difficult finalist reviews.
3. Tell the task to work in `research/tradingview` and begin with the prompt below.

```text
You are my TradingView research agent. Work only on research and backtesting—never place or preview
a broker order. Read the repository AGENTS.md and research/tradingview/AGENTS.md, then read the
research README, leaderboard, JSON leaderboard, and experiment log. Continue with one bounded
experiment batch on SPY and QQQ, primarily using 5-minute and 15-minute entries with 1-hour and
4-hour context. Use realistic costs, out-of-sample and walk-forward testing, preserve every Pine
finalist under a new TVR ID as a complete plain-text `.txt` source file, and update the research
files before reporting results.
```

After that, talk to the task normally: ask it to explain a candidate, try a particular idea, compare
two versions, change the next research batch, or show why a strategy was rejected. The durable
memory is in this folder rather than relying on the model to remember an old chat.

Because MCP configuration is loaded when a Codex task starts, use a new task after an MCP config
change.

## Optional PowerShell interface

From PowerShell, start an interactive Luna session rooted directly here:

```powershell
codex -m gpt-5.6-luna -C "C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\research\tradingview"
```

Resume that interactive session later with the Codex session picker:

```powershell
codex resume
```

## Persistent files

- `LEADERBOARD.md` — readable top-ten summary.
- `leaderboard.json` — structured state for future automated research loops.
- `EXPERIMENT_LOG.md` — append-only history, including losing and rejected experiments.
- `LITERATURE_REVIEW_2026-09-16.md` — evidence-ranked published strategies and the frozen next-test queue.
- `INDICATORS.md` — definitions and limitations for experimental, non-strategy indicators.
- `indicators/` — complete versioned Pine indicator sources saved as editable `.txt` files.
- `strategies/` — complete versioned Pine Script source saved outside TradingView as `.txt` files.

The research task may edit these files. It must not silently modify the parent project's approved
trading or risk policy.

October3 batch D: TVR-0088 one entry per divergence QQQ+$26.05/57/PF1.046,SPY-$127.58/68. TVR-0089 adds a post-confirmation VWAP reclaim: QQQ+$38.64/37/PF1.110,SPY-$64.97/49;QQQ4ticks+$24.07, earlier+$63.87/16,later-$26.35/21. Reclaim ages2/3/4 identical, no independent confirmation. Both REJECTED for weak/period-dependent transfer; all nine native ledgers pass net/count/timing/daily-green audit. Complete sources, native saved copies, metrics and evidence: results/TVR-0088_0089_2026-10-03.{md,json}, frozen plan SESSION_PLAN_2026-10-03_D.md. October unopened; research goal ACTIVE; no operational changes.

October3 batch E: hidden-divergence continuation0090 QQQ-$7.44/157,SPY-$205.18/158; earlier momentum0091 QQQ+$57.35/164/PF1.042,SPY-$168.26/159. Full-period Sharpe/Sortino negative; both REJECTED. No PF>=1.2 positive lead, no further parameter tests triggered. Four full native ledgers pass net/count/identity/cost/fill/timing/daily-green checks. QQQ0091 shorts+$219.37/57 versus longs-$162.03/107 is posthoc diagnostic, not validated short-only strategy. Complete sources/native copies/metrics/trades: results/TVR-0090_0091_2026-10-03.{md,json}; frozen planE. Next priority broader historical coverage/defensible validation before more same-sample variants. October unopened; goal ACTIVE; no operational changes.

October3 F/data expansion: found0082–0091 research sources incorrectly shorten July2,2026 to13:00; Alpaca/TradingView/installed NYSE calendar confirm16:00. TVR-0092 corrects calendar only, supports2025/2026earlycloses; nativeQQQ+$38.64/37 andSPY-$64.97/49 exactly match0089 complete ledgers/metrics. REJECTED, no promotion. Prior histories preserved with calendar-defect annotation; old lack ofJuly2trades alone was not enough to assert no effect. Raw/corrected sources/results: SESSION_PLAN_2026-10-03_F.md, results/TVR-0092_2026-10-03.{md,json}.

Historical expansion:14 saved SIPsymbol-months (Jan–Jun2025SPY/QQQ andSep2026SPY/QQQ), explicitrequests/response/hashmanifest; every expectedRTHbar present, zero duplicates/invalids/truncation. Four adversarial completeness tests and scopedRuff pass. NativeQQQ144OHLCmatchbutallvolumesdifferent;Sep30VWAPmaxdifference$0.067/oneclose-sideflip, sofeedsnotinterchangeable. See results/HISTORICAL_DATA_AUDIT_2026-10-03.{md,json}, tools/audit_historical_data.py. July–December2025 performance reserved for frozen finalist; October2026unopened. No broader strategy result yet; no mark-to-market replay engine built/validated. Next implement bounded independent5mreplay using audited data, verify timing/risk/MTM and native overlap before screening more variants. GoalACTIVE; no true blocker, no core/runtime/broker/scheduler changes. Monetary AI/data cost unmeasured; no data purchase.

October 3, batches G/H: TVR-0093 display-only Pine export preserves TVR-0092's complete native ledgers/metrics and exports 9,984 pre-October RTH bars per symbol. Header/count/calendar/fields/hash checks pass. The independent replay matches all 86 trades, prices, quantities, commissions, P&L and native MTM drawdown on SPY/QQQ; indicator differences <=5.1e-9. Thirteen adversarial execution/timing tests and scoped Ruff pass. Continuous-path drawdown is separately retained and slightly larger. 0093 ARCHIVED as diagnostic duplicate, not a winner. Full data, source and parity evidence retained in results/REPLAY_PARITY_2026-10-03.{md,json}, TVR-0093 result and native history manifest. Native last-bar advisory is nonfatal; no trading calculation change.

Predeclared older development transfer, January–June 2025 Alpaca SIP: 0092 SPY+$121.35/47/PF1.296, QQQ+$42.68/53/PF1.061; calendar-corrected hidden/one-change 0094 SPY+$213.85/143/PF1.146, QQQ-$105.04/159/PF0.946. Neither passes both-symbol PF1.2/40trade gate; REJECTED, no validation/cost/parameter tests triggered. Full ledgers pass net/count/time/daily-green/event/cap audits. Daily Sharpe/Sortino explicitly separate from native ratios; descriptive CAGR and both MTM conventions retained. New full94source server compiles cleanly; no94native chart test yet. Older favorable SPY cells do not rescue2026failures or weak/losingQQQ. Results/HISTORICAL_TRANSFER_2026-10-03.{md,json}, frozen planH and tool preserve all outcomes. No holdout performance opened.

Next: predeclare a final-filter test incorporating the existing Python technical qualification, rather than another isolated indicator. Actual DAY score is2*5MtrendScore+15MtrendScore+2*openingRangeBiasScore, direction-adjusted positive at pre-model gate; SMA20/50, MACD sign, RSI55/45, three-bar change and opening-range structure. Any proxy must use completed15M candles, disclose rolling220bar/EMA/RSI/feed differences and omitted contract/risk/events. Research goal ACTIVE, no robust profitable finalist; no broker/model/runtime/core/scheduler changes or data purchases. Monetary compute/data expense remains unmeasured.
