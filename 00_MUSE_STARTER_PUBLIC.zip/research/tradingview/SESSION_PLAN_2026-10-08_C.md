# October 8 — frozen TVR-0096 protection experiment

Declared after95 batches A/B, before96 outcomes.95 original/strict lacks a reliable edge. RSI is redundant in the tested5m baseline, while droppingMACD produces weak positive cells. No promotion.

New full Pine96 is a separate saved copy. Preserve95. Same ordinary Ichimoku/sessionVWAP/confirmed reclaim/Kijun/time exits; strictVWAP=false, RSI=true; $10K/95%whole-share sizing, base .01%per-side fee/two ticks, RTH standard candles, Jan1–Oct1 exclusive (actual loaded5m coverage expectedApr6–Sep30).

Freeze one ATR14 at the confirmed entry signal, rounded upward to at least one tick. Create entry-relative loss order on the same calculation as entry, avoiding a wait for next-bar position_avg_price; never recalculate/widen an active trade's distance. Optional target is exactly2times that frozen tick distance. No calc_on_order_fills or every_tick. Kijun/time market exits remain. Planned risk is not guaranteed realized risk; gaps/slippage can exceed stop. This is not a change to production risk.

Eight5m cells, no parameter grid:
- SPY and QQQ, original MACD=true, frozen stop only.
- SPY and QQQ, original MACD=true, frozen stop plus2R target.
- SPY and QQQ, MACD=false, frozen stop only.
- SPY and QQQ, MACD=false, frozen stop plus2R target.

Retain every outcome. An eligible follow-up must be positive with PF>=1.2 and >=40 trades on BOTH symbols; meaningful average profit must survive4ticks and doubled fees, then retrospective chronology (Jan1–Jul1,Jul1–Oct1). Do not force additional tests if no cell qualifies; record that added information is exhausted for this bounded hypothesis. Holdouts remain unopened.

Audit exact source, native script identity, inputs and property mapping, every trade's fees/net/whole quantity, confirmed entry timing, session flatten/daily cap, bracket distance and exit identifier. Native intrabar exit timestamps are historical bar labels, not tick execution times. Report bounded bar-based exposure (exit-bar start/end relative to entry close), rather than pretending exact intrabar exposure. Native OHLC-path bracket execution is emulator evidence, not tick verified. No live order or production change.

Volume consideration: prior-session POC/value area would require defensible allocation/bin definitions and source consistency; same-clock prior10-session RVOL is the simpler future non-leaking filter. Defer adding either unless this bounded base has economic credibility. Primary sources and limitations are in95 report.

