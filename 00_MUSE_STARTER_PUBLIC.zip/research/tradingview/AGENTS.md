# TradingView Research Task Instructions

These instructions apply in addition to the repository-root `AGENTS.md`.

## Mission

Act as a research and backtesting assistant. Develop, test, compare, and preserve Pine Script
strategies for later human review. Research results never authorize a broker order, a change to live
execution, or a change to the project's core strategy/risk policy.

## Working scope

- Instruments: SPY and QQQ until the user explicitly expands the universe.
- Primary execution timeframes: 5 minutes and 15 minutes.
- One-minute data: use as a noise, fill-sensitivity, and timing stress test; do not optimize around it
  as the sole primary timeframe without strong evidence.
- Context timeframes: 1 hour and 4 hours. Daily data may be used as a regime filter.
- Test long and short signals, but keep assumptions compatible with the project's eventual long-call
  and long-put options use case.
- Use realistic fees, slippage, and bar-close/fill assumptions. State every assumption.

## Required files at the start of a research turn

After following the root instructions, read:

1. `README.md`
2. `LEADERBOARD.md`
3. `leaderboard.json`
4. `EXPERIMENT_LOG.md`

## Tool roles

- Use `tradingview_analysis` for inexpensive data retrieval, indicator calculations, batch strategy
  comparisons, parameter sensitivity, and walk-forward screening.
- Use the desktop-connected TradingView MCP for Pine Editor access, server compilation, visible
  Strategy Tester validation, trade inspection, and mark-to-market equity/drawdown confirmation.
- Confirm tool output. A successful process exit is not proof that the requested chart or test was
  actually completed.

## Research loop

1. Define a bounded experiment batch and its hypothesis before changing parameters.
2. Screen cheaply on both SPY and QQQ where data permits.
3. Reject candidates that depend on tiny samples, one favorable period, or one fragile parameter.
4. Test held-out/out-of-sample performance, walk-forward stability, market regimes, nearby
   parameters, and realistic costs.
5. Convert only genuine finalists to versioned Pine Script.
6. Compile and validate each finalist in TradingView Desktop. Treat TradingView's mark-to-market
   drawdown as authoritative until the headless engine has equivalent open-position equity logic.
7. Update all persistent research files before ending the turn.

Creativity is encouraged across trend, momentum, mean-reversion, volatility, volume, session,
multi-timeframe, entry, exit, and risk filters. Do not perform an unbounded parameter search or
select a winner solely because it has the highest in-sample return.

## Candidate persistence

- Assign permanent IDs in sequence: `TVR-0001`, `TVR-0002`, and so on.
- Save every Pine finalist as `strategies/<ID>_<slug>.txt`. Each `.txt` file must contain the
  complete, directly editable Pine Script source, beginning with its `//@version` declaration.
- Never overwrite an earlier candidate to create a materially different strategy. Create a new ID.
- Append every completed batch to `EXPERIMENT_LOG.md`, including failures and rejected ideas.
- Keep machine-readable results in `leaderboard.json` and the human summary in `LEADERBOARD.md`.
- Keep at most ten active candidates on the leaderboard. Removing one from the top ten does not
  delete its script or experiment history.
- A candidate can be labeled `DEMO`, `SCREENING`, `FINALIST`, `REJECTED`, or `ARCHIVED`. None of
  these labels means approved for live trading.

## Promotion discipline

Rank complete executable strategies, not isolated indicators. Promotion requires positive and
credible out-of-sample evidence, adequate trade count, robustness to nearby parameters and costs,
acceptable mark-to-market drawdown, and no obvious dependence on one symbol or regime. If evidence
is insufficient, say so and leave the candidate in `DEMO` or `SCREENING` rather than inventing a
passing threshold.

## Safety and autonomy

- Never place, preview, modify, or cancel a Robinhood order from this research folder.
- Never enable live execution, edit schedulers, buy a TradingView plan, publish a TradingView
  script, or create a recurring automation unless the user explicitly requests that exact action.
- A request to continue research authorizes the requested bounded research work and corresponding
  updates to this folder, not live trading or policy changes.
