# Frozen experiment: VWAP / EMA27 / momentum

User clarified during the turn: quick Pine chart-strategy screen only. Complete the four base cells; defer split reruns, cost stress and combined-options pipeline validation. User subsequently emphasized this strategy is intended as a final filter after Python qualification. These standalone chart results do not measure that conditional role.

Authorized October 3 in this chat: historical TradingView research on SPY and QQQ, five-minute bars. No production configuration or broker changes.

Two variants, TVR-0082 momentum and TVR-0083 momentum plus confirmed divergence. No parameter search. MACD 12/26/9, RSI14, EMA27. Calls proxy: completed close above RTH HLC3 VWAP and EMA27, EMA rising, MACD histogram rising on two successive changes. Puts proxy: mirrored conditions. Entry on first transition into qualifying state, not every qualifying candle. Divergence variant additionally requires a bullish/bearish RSI OR MACD-line divergence confirmed within 12 bars, using price pivots with three left and three right bars, pivot separation 5–60 bars and same RTH session. Never backdate confirmation to pivot.

EMA27 is entry-only. Exit on completed close across VWAP or 15 minutes before session close. No ETF stop substituted for an option-premium stop. Underlying long/short shares are directional proxies, not executable long-option returns. No claim to test 20% option stop or target without historical option quotes.

RTH-only indicators; enter after 09:50 ET and before close minus30 minutes. One position, no reversals or pyramiding, maximum3 entries per day, latch no-new-entry after realized daily net becomes positive. Existing positions still exit. Close13:00 on July2, November27, December24 2026; ordinary close16:00. Final RTH bar fallback and out-of-date flatten.

[account details redacted]

Historical window January1–September30 2026, subject to available chart coverage; October onward excluded. Four base cells: two variants x two symbols. Four fixed chronological diagnostic cells: each variant/symbol Jan–Jun and Jul–Sep (eight split cells total). Four doubled-slippage cells if any base cell positive. Maximum16 cells. Prior researched periods are retrospective, not untouched OOS; new October dates remain reserved. Record actual history coverage, all losing cells, trade counts, PF, win rate and TradingView MTM drawdown. No promotion on one good cell.
