# Two-hour VWAP / opening-structure research session

- Start: 2026-09-19 12:46:09 UTC. Hard research deadline: 14:46:09 UTC.
- Scope: SPY/QQQ underlying ETF share simulations, primarily 5m/15m. No broker or scheduler work.
- Base settings unless explicitly noted: $10,000 initial capital, 95% of equity per entry,
  0.01% commission per side, two ticks of adverse slippage per order, no pyramiding,
  confirmed-bar-close entries. Four-tick stress is predeclared for any positive lead.
- Status labels will reflect evidence, not the need to fill leaderboard slots. The seven
  existing leaderboard entries are provisional/demo, not approved trading systems.
- Pre-test correction: the initial draft said a 10:00 close could break the completed
  09:30–10:00 range; that is mechanically impossible because the 09:45–10:00 bar belongs
  to that range. The decision is therefore fixed at 10:15 before seeing any results.

## Frozen hypotheses and comparisons

1. Finish TVR-0046 unchanged: a countertrend first 15m candle is rejected by 10:00 through
   its midpoint and current session VWAP. Compare its direction, chronology, and sample size
   to TVR-0045's daily-trend opening rejection. No threshold tuning.
2. TVR-0055: remove TVR-0030's completed-hour EMA filter while preserving its failed-auction,
   VWAP-cross entry and frozen ATR exits. This tests whether the hourly filter helps rather
   than merely reducing trade count. Direct comparison: TVR-0030.
3. TVR-0056: replace TVR-0030's hourly EMA filter with the completed-hour Ichimoku Kijun
   direction (close above/below Kijun), keeping all other rules fixed. The Kijun is a
   predeclared alternative equilibrium/regime measure, not an added filter. Direct
   comparisons: TVR-0030 and TVR-0055.
4. TVR-0057: require a volume impulse on TVR-0030's failed opening-range sweep, with
   sweep-bar volume at least 1.5 times the prior 20-bar average; preserve the baseline
   entry/exits and hourly filter. Hypothesis: a crowded rejection is more decisive.
   Direct comparison: TVR-0030. No volume-multiple search.
5. TVR-0058: post-opening acceptance continuation. At exactly 10:15 ET, follow a close
   outside the completed 09:30–10:00 range and on the same side of session VWAP, only
   with completed-hour trend agreement. Risk to the opening-range midpoint, target 1R,
   flatten after 60 minutes. Direct comparisons: TVR-0016 and TVR-0032; this is a
   different timing/state, not a tuned variant of their observed result.
6. TVR-0059: opening-range breakout-and-retest. After a confirmed 10:00–10:30 ET break
   beyond the frozen first-30m range, enter only on a later bar through 11:00 that tests
   and closes back beyond the broken boundary, with same-side session VWAP and completed
   1H trend. Risk to the retest bar extreme, target 1R, flatten after 60 minutes.
   Direct comparison: TVR-0058's immediate-acceptance entry.

Reject weak/sparse cells early. For a plausible lead, verify exact Pine/chart/tester identity,
cost stress, nearby fixed parameter neighborhood, chronological splits, and mark-to-market
drawdown. Retrospective splits are not untouched out-of-sample tests. If TradingView's
signed-out Desktop session prevents attaching studies, do not invent metrics; continue
safe analysis/source work and record the limitation.
