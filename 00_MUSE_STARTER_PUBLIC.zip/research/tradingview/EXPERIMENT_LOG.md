# TradingView Experiment Log

Append completed experiment batches here. Do not delete losing results: they are research memory.

## 2026-08-30 — Batch 25: failed auction with prior-day range location

- Created, compiled, attached, and exact-identity-verified TVR-0023 as a controlled TVR-0022
  attribution test. It preserves the initial-range rejection, three-bar VWAP-reclaim sequence,
  timing, exits, $10,000 capital, 95% sizing, and costs, but replaces completed 1H trend alignment
  with the opening range lying in the outer 35% of the completed prior-day range. Final compilation
  had zero errors/warnings, and all restored default inputs were verified directly.
- Base matrix: QQQ 15M +1.62%, PF 1.25, 1.16% drawdown over 53 trades; SPY 5M +0.28%, PF 1.40
  over 17; QQQ 5M -0.09%, PF 0.95 over 16; SPY 15M -0.79%, PF 0.85 over 49. Relative to
  TVR-0022, QQQ 15M trade count doubled but payoff quality and drawdown worsened materially.
- The QQQ 15M prior-range threshold was fragile: 0.30/0.35/0.40 returned +0.49%/+1.62%/+1.97%
  with PF 1.07/1.25/1.30. Doubled commission/slippage left only +0.52%, PF 1.07, with drawdown
  rising to 1.54%. QQQ 1M gained 0.25% on three wins, while SPY 1M lost 0.10%, PF 0.49 over six;
  neither sample is adequate.
- Date segmentation exposed regime concentration: QQQ 15M January-April -0.81%, PF 0.75 over 23
  trades; May-June +2.22%, PF 2.57 over 16; July-August +0.27%, PF 1.15 over 14.
- Decision: REJECTED. The larger sample does not compensate for one losing major subperiod,
  threshold sensitivity, near-flat doubled-cost expectancy, and failed timeframe/symbol transfer.
  TVR-0022 remains the better provisional expression of the failed-auction family.
- Lesson/next: prior-day outer-range location is not a credible substitute for TVR-0022's completed
  1H trend agreement. One final controlled TVR-0024 no-context variant should measure the raw
  rejection/reclaim sequence; then stop decomposing this family unless new data materially changes
  the evidence.

## 2026-08-30 — Batch 24: early failed-auction VWAP reclaim

- Created TVR-0022 to test a materially selective reversal sequence: an ATR-buffered extension
  beyond the completed 09:30-10:00 initial range must close back inside, then price must reclaim
  session VWAP within three bars while the last completed 1H close/EMA30 slope agrees. The first
  compile surfaced conditional `ta.crossover`/`ta.crossunder` consistency warnings; both calls were
  made unconditional and the final source compiled with zero errors/warnings. Exact chart/tester
  identity and the restored $10,000/95%/0.01%/two-tick defaults were verified.
- Base matrix: QQQ 15M +2.40%, PF 2.04, 0.72% drawdown over 25 trades; SPY 5M +0.20%, PF 1.32,
  0.46% drawdown over 12; QQQ 5M -0.41%, PF 0.64 over nine; SPY 15M -1.22%, PF 0.62 over 31.
  The lead is therefore concentrated in QQQ 15M rather than transferable across all base cells.
- Bounded QQQ 15M checks were favorable: sweep buffers 0.05/0.10/0.15 ATR returned +2.23%/+2.40%/
  +2.52% with PF 1.80/2.04/2.15; two/three/four-bar reclaim windows returned +1.80%/+2.40%/+2.40%
  with PF 1.78/2.04/2.04. Doubled commission/slippage retained +1.90%, PF 1.75, 0.76% drawdown.
- Available QQQ 15M segments were all positive but tiny: January-April +0.51%, PF 1.90 on seven
  trades; May-June +1.60%, PF 2.94 on nine; July-August +0.31%, PF 1.33 on nine. QQQ 1M gained
  0.07%, PF 2.24 on only two trades; SPY 1M lost 0.17% on two. Neither is meaningful stress evidence.
- Decision: retain as PROVISIONAL rank 3, not a finalist. Stable nearby definitions, doubled-cost
  tolerance, and positive available segments warrant preservation, but 25 trades, failed QQQ 5M/
  SPY 15M transfer, and unusably small 1M samples prevent stronger language.
- Next: isolate whether the useful component is the initial-range failed auction itself or the 1H
  directional filter. Use one controlled TVR-0023 variant that keeps the rejection/reclaim sequence
  but replaces trend alignment with a completed prior-day range-position filter; do not optimize
  TVR-0022's exits around the observed winners.

## 2026-08-30 — Batch 23: continuous 4H trend-strength regime

- Created, compiled, attached, and exact-identity-verified TVR-0021. At a fixed 10:30 decision it
  requires the last completed 4H close and sloped EMA20/50 structure to agree, with EMA separation
  of at least 0.25 completed 4H ATR, completed daily EMA50 confirmation, and session-VWAP agreement.
  The standardized $10,000 capital, 95% sizing, 0.01% commission, two-tick slippage, and date bounds
  were verified directly from the loaded strategy inputs.
- The continuous filter produced usable sample counts but lost in every base cell: SPY 5M -0.43%,
  PF 0.47 over 12 trades; SPY 15M -1.35%, PF 0.68 over 44; QQQ 5M -0.79%, PF 0.58 over 14; and
  QQQ 15M -1.64%, PF 0.75 over 46. Mark-to-market drawdowns ranged from 0.61% to 2.84%.
- Decision: REJECTED without threshold tuning or 1M stress. The broad cross-symbol/timeframe loss
  rules out the baseline hypothesis; changing the 4H strength threshold would be unsupported rescue
  optimization rather than robustness analysis.
- Lesson: completed higher-timeframe trend alignment can define context but is not a sufficient
  intraday entry edge. The next candidate should retain a broad context only if paired with a
  materially selective microstructure trigger, such as an early failed auction and VWAP reclaim,
  rather than another fixed-time regime entry.

## 2026-08-30 — Batch 22: fresh 4H EMA regime transition

- Created, compiled, attached, and identity-verified TVR-0020, which makes one 10:30 decision only
  within two completed 4H bars of an EMA20/50 crossover, with completed daily EMA50 and session-VWAP
  confirmation. Standard $10,000 capital, 95% sizing, costs, and date bounds were verified.
- The strict state was unusably sparse: SPY 5M +0.22% on two winning trades; SPY 15M +0.30% on
  two winning trades; QQQ 15M +0.32%, PF 3.92 on one win and one loss; QQQ 5M -0.16% on one loss.
  There were only seven trades across the entire matrix.
- Decision: REJECTED without widening the crossover-age window or stress testing. The positive
  headline cells are artifacts of one or two outcomes, not evidence of expectancy. Loosening the
  definition after seeing the sparse result would create a different hypothesis and invite overfit.
- Lesson: discrete 4H EMA transitions are too infrequent for the currently available intraday
  history. The next strategy should use a continuous higher-timeframe regime statistic—such as
  4H trend strength or volatility percentile—so the base matrix can contain meaningful samples.

## 2026-08-30 — Batch 21: controlled 13:00 volume-pressure timing variant

- Created, compiled, attached, and identity-verified TVR-0019. It holds every TVR-0018 rule and
  parameter constant except moving the single decision from 11:00 to 13:00, allowing a clean timing
  comparison under the same $10,000 capital, 95% sizing, commission, and slippage assumptions.
- The timeframe pattern reversed but did not improve credibly: SPY 15M +0.42%, PF 1.15 over 42
  trades; QQQ 15M +0.20%, PF 1.04 over 49; SPY 5M -0.22%, PF 0.53 over nine; QQQ 5M -0.04%,
  PF 0.94 over ten.
- Decision: REJECTED without further stress. QQQ 15M is effectively flat after costs, SPY 15M is
  weak, and both target 5M cells lose. Parameter testing would optimize around a baseline that does
  not meet the research gate.
- Lesson: entry timing changes which timeframe looks favorable but does not establish a transferable
  volume-pressure edge. Keep TVR-0018 only as a tiny-sample provisional lead; do not create more
  clock-time variants. Next move to a genuinely distinct 4H/daily regime-transition hypothesis.

## 2026-08-30 — Batch 20: signed volume-pressure VWAP continuation

- Created TVR-0018 as a distinct volume-weighted family. At a fixed 11:00 decision it requires
  signed close-location volume pressure, session-VWAP position, and 1H EMA trend to agree. An initial
  Pine consistency warning was repaired by evaluating both rolling sums unconditionally; the final
  source compiled with zero errors/warnings and exact chart/tester identity and settings were verified.
- Base matrix split sharply by timeframe: QQQ 5M +0.42%, PF 1.44, 0.41% drawdown over 11 trades;
  SPY 5M +0.20%, PF 1.53, 0.19% drawdown over nine; QQQ 15M -1.14%, PF 0.86 over 64; SPY 15M
  -2.07%, PF 0.65 over 64.
- Both 1M tests failed: QQQ -0.20%, PF 0.12 and SPY -0.20%, PF 0, each over four trades. QQQ 5M
  stayed positive at pressure 0.15 (+0.55%, PF 1.41, 17 trades) but turned negative at 0.25
  (-0.06%, PF 0.93, eight). Doubled costs reduced QQQ 5M to +0.17%, PF 1.16 and SPY 5M to
  +0.02%, PF 1.05.
- Available QQQ 5M segmentation was positive but tiny: May–June +0.16%, PF 2.02 on two trades;
  July–August +0.23%, PF 1.30 on nine. No older 5M evidence was available.
- Decision: retain as PROVISIONAL rank 5, not a finalist. Cross-symbol 5M agreement and positive
  available subperiods are worth preserving, but the sample is extremely small, the higher threshold
  fails, 1M/15M transfer fails, and cost tolerance is marginal—especially on SPY.
- Next: determine whether entry timing is the main reason the 5M signal fails on 15M by testing a
  controlled later fixed-time variant, or move to a 4H/daily regime transition if timing merely
  relocates the small sample.

## 2026-08-30 — Batch 19: gap-hold timed continuation

- Created, compiled, attached, and identity-verified TVR-0017 to isolate TVR-0016's gap/trend state
  from its breakout trigger. At 10:30 it enters only if the aligned gap remains unfilled and price
  holds the favorable half of the opening range. Standard sizing, costs, and dates were verified.
- Base results: QQQ 15M +0.23%, PF 1.08 with 1.46% drawdown over 25 trades; SPY 15M -0.32%, PF
  0.87 over 30; SPY 5M -0.30%, PF 0.49 over eight; QQQ 5M -0.71%, PF 0.34 over seven.
- Decision: REJECTED without further stress. The only positive cell is economically negligible
  relative to drawdown and three cells lose; parameter or cost testing would not rescue the failed
  baseline gate.
- Lesson: gap/prior-trend agreement alone does not explain TVR-0016. Its modest QQQ 15M result
  appears dependent on the opening-range breakout confirmation, though TVR-0016 remains too fragile
  for promotion. Next research should move to a distinct family rather than further decomposing this
  weak lead—preferably volume-weighted price structure or a higher-timeframe regime transition.

## 2026-08-30 — Batch 18: gap/trend-aligned opening-range breakout

- Created, compiled, attached, and identity-verified TVR-0016 as a controlled response to prior
  breakout failures. It permits an opening-range break only when a gap of at least 0.15 prior daily
  ATR aligns with the prior five-session trend. Standard $10,000 capital, 95% sizing, 0.01%
  commission, two ticks of slippage, and full date bounds were verified.
- Base matrix: QQQ 15M +0.88%, PF 1.28, 1.02% drawdown over 28 trades; SPY 5M +0.11%, PF 1.24
  over only nine; QQQ 5M -0.26%, PF 0.72; SPY 15M -0.94%, PF 0.66. The cross-timeframe pattern is
  mixed and the SPY lead is too small to carry weight.
- Both 1M stress tests failed on tiny samples: QQQ -0.08%, PF 0 over one trade and SPY -0.09%, PF
  0.23 over three. On QQQ 15M, a nearby 0.10 daily-ATR gap threshold turned negative (-0.44%, PF
  0.90, 34 trades), while 0.20 stayed weakly positive (+0.30%, PF 1.11, 23). Doubled costs left
  only +0.17%, PF 1.05 over 28 trades.
- QQQ 15M date segments were positive but small in January–April (+0.66%, PF 1.48, 14 trades) and
  May–June (+0.30%, PF 1.30, nine), then slightly negative in July–August (-0.04%, PF 0.94, five).
- Decision: retain as PROVISIONAL rank 4, not a finalist. State dependence improved the rejected
  generic breakout family, but threshold fragility, failed 1M tests, mixed symbol/timeframe transfer,
  marginal cost tolerance, and the recent negative segment prevent promotion.
- Next: isolate whether the useful component is gap/trend agreement itself rather than the breakout
  trigger, using a non-breakout first-pullback or time-based continuation entry without reusing the
  failed generic EMA-reclaim definition.

## 2026-08-30 — Batch 17: fixed-noon morning-range position reversal

- Created, compiled, attached, and identity-verified TVR-0015. It makes one fixed noon decision:
  fade price only when it is in the outer 20% of the completed 09:30–12:00 range and displaced at
  least 0.75 ATR from the session open. Standard $10,000 capital, 95% allocation, 0.01% commission,
  two-tick slippage, and date bounds were verified before results were accepted.
- The recurring statistic produced adequate samples but no edge: SPY 5M -1.18%, PF 0.30 over 25
  trades; SPY 15M -1.77%, PF 0.77 over 74; QQQ 5M -0.27%, PF 0.89 over 24; QQQ 15M -4.01%,
  PF 0.62 over 69. Mark-to-market drawdowns ranged from 1.35% to 4.81%.
- Decision: REJECTED without threshold tuning or 1M stress. All four base cells lost after costs,
  and only QQQ 5M approached break-even; that isolated weak cell is insufficient for promotion.
- Lesson: simply fading a displaced noon extreme is not supported. The broader evidence now rejects
  both generic continuation and generic fixed-time mean reversion. The next batch should introduce
  economically motivated state dependence—such as prior-day trend versus opening gap interaction—
  rather than another standalone intraday price-pattern trigger.

## 2026-08-30 — Batch 16: exhaustion close-location reversal

- Created and compiled TVR-0014, a tightly timed reversal that waits for a large 1.5-ATR midday bar
  closing in its outer 15% after a one-ATR directional move, then enters only if the following bar
  reverses through the exhaustion bar's midpoint. Exact chart and Strategy Tester identity plus
  standardized $10,000 capital, 95% sizing, 0.01% commission, and two-tick slippage were verified.
- The setup was sparse and negative: SPY 5M generated zero trades; QQQ 5M lost 0.19% on one trade;
  SPY 15M lost 0.73%, PF 0.30 over eight trades; QQQ 15M lost 0.38%, PF 0.69 over eight.
- Decision: REJECTED without loosening the range, move, or close-location thresholds. Every
  nonempty cell lost and the sample was too small; relaxing conditions after seeing this result
  would be trade-count engineering rather than a controlled robustness test.
- Lesson: single-bar exhaustion events are too rare under a defensible strict definition and did
  not show favorable expectancy. Next test should use a recurring session statistic with enough
  natural observations, such as a volatility-normalized close-location/range-position effect at a
  fixed clock time, while keeping the entry rule distinct from prior level sweeps and breakouts.

## 2026-08-30 — Batch 15: directional-efficiency breakout

- Created TVR-0013 to distinguish smooth directional movement from noisy movement using a 12-bar
  Kaufman-style efficiency ratio, then require an 8-bar breakout in the same direction. This was a
  direct trend-quality test rather than another opening-range, VWAP, or EMA-pullback variant.
- The initial compile correctly exposed an unavailable `ta.sum` namespace call. It was repaired to
  `math.sum`, recompiled with zero errors, attached, and exact strategy identity and all standardized
  $10,000 / 95%-allocation / cost inputs were verified before accepting results.
- The base matrix again failed throughout: SPY 5M -0.79%, PF 0.67 over 42 trades; SPY 15M -1.38%,
  PF 0.75 over 62; QQQ 5M -1.49%, PF 0.61 over 37; QQQ 15M -3.02%, PF 0.64 over 61. Maximum
  mark-to-market drawdowns were 1.13%–3.71%.
- Decision: REJECTED without parameter or 1M stress. All cells were unambiguously negative, so
  tuning the efficiency or breakout thresholds would be unsupported optimization.
- Lesson: smooth recent travel plus a fresh high/low is still a late continuation entry in these
  samples. The next batch should avoid generic breakout/reclaim triggers and test either a tightly
  defined time-of-day reversal with asymmetric exits or a volatility-normalized close-location
  effect.

## 2026-08-30 — Batch 14: cross-ETF relative-strength pullback

- Created TVR-0012 to test whether meaningful session-relative outperformance between QQQ and SPY
  persists after a pullback/reclaim of a 20-bar EMA. The fixed peer series avoids dynamic-symbol
  ambiguity. It compiled with zero errors, attached under the exact intended identity, and exposed
  the verified $10,000 capital, 95% sizing, 0.01% commission, two-tick slippage, and default dates.
- The base matrix failed throughout: SPY 5M -2.05%, PF 0.31 over 36 trades; SPY 15M -2.16%, PF
  0.64 over 56; QQQ 5M -2.56%, PF 0.49 over 39; QQQ 15M -4.25%, PF 0.56 over 60. Maximum
  mark-to-market drawdowns ranged from 2.11% to 4.41%, and win rates were only 25%–36%.
- Decision: REJECTED without parameter tuning or 1M stress. The losses are broad across both
  symbols and target timeframes; changing the relative-strength threshold would be unsupported
  in-sample rescue work rather than robustness testing.
- Operational note: an incorrect positional CLI invocation briefly selected the unrelated ticker
  `CBOE_DLY:SET`. Its zero-trade outputs were discarded. Every accepted result above was preceded
  by exact symbol, timeframe, and `TVR-0012 Relative Strength Pullback` identity verification.
- Lesson: raw cross-ETF relative strength plus a generic EMA reclaim appears to enter late and has
  poor payoff asymmetry. Next test should measure intraday trend quality directly—such as directional
  efficiency or opening-to-current path smoothness—rather than another EMA-pullback definition.

## 2026-08-30 — Batch 13: volatility-gated range fade and prior-day reclaim

- Created TVR-0010 as a controlled TVR-0009 variant with one broad hypothesis: skip sessions whose
  completed morning range exceeds four current ATRs. It compiled with zero errors, attached under
  the exact intended identity, and exposed the expected standardized sizing, costs, and date inputs.
- TVR-0010 contradicted the hypothesis. QQQ 15M returned -2.15%, PF 0.14 over 13 trades; SPY 15M
  -2.20%, PF 0.28 over 27. The filter left only one losing trade in each 5M test. Rejected without
  tuning the cutoff because the broad gate selected a substantially worse subset than TVR-0009.
- Created TVR-0011, a separate range-position hypothesis fading failed ATR-buffered tests of the
  prior day's high/low toward its midpoint. It compiled, attached, and passed exact identity/input
  verification.
- TVR-0011 failed all four cells: QQQ 5M/15M -0.97%/-8.18%, PF 0.74/0.47; SPY 5M/15M
  -1.82%/-5.47%, PF 0.26/0.41. Win rates were only 16%–29%. Rejected without tuning or 1M stress.
- Lessons: the recent TVR-0009 loss is not explained by simply excluding wide morning ranges, and
  generic prior-day sweep/reclaim entries are too frequent and low quality under these exits.
  Keep TVR-0009 unchanged and provisional; do not retrofit the failed gate.
- Next: test an orthogonal relative-strength or intraday trend-quality family rather than another
  simple level sweep/reclaim.

## 2026-08-30 — Batch 12: afternoon failed morning-range extension

- Created, compiled, attached, and identity-verified TVR-0009. It builds the 09:30–12:00 high/low,
  then fades one 13:00–15:00 failed extension toward the morning midpoint with an ATR stop and
  maximum holding time. Inputs verified $10,000 capital, 95% sizing, 0.01% commission, two ticks
  of slippage, and full default date bounds.
- Base matrix: QQQ 15M +2.33%, PF 1.48, 1.55% drawdown over 44 trades; SPY 5M +0.15%, PF 1.15
  over 22 trades; QQQ 5M -0.17%, PF 0.87; SPY 15M -0.68%, PF 0.87. The mixed timeframe transfer
  prevents promotion.
- Nearby failed-break thresholds were stable in the positive cells: QQQ 15M remained positive at
  0.0/0.1/0.2 ATR buffers (PF 1.31/1.48/1.45), and SPY 5M at 0.2 ATR remained PF 1.15. Both 1M
  stress tests failed. Doubled costs retained QQQ 15M at +1.32%, PF 1.24 but turned SPY 5M
  negative, so only the QQQ 15M lead shows meaningful cost tolerance.
- QQQ 15M date segmentation required forced timeframe recalculation after each input update because
  immediate Strategy Tester reads were stale. Verified segments: January–April +1.02%, PF 1.46
  over 25 trades; May–June +1.76%, PF 1.99 over 13; July–August -0.45%, PF 0.50 over six.
- Decision: retain TVR-0009 as PROVISIONAL, not a finalist. It has a stable threshold neighborhood,
  two positive earlier periods, and positive doubled-cost QQQ 15M results, but fails 1M, loses in
  the recent regime, and does not transfer consistently across symbols/timeframes.
- Next: determine whether a simple volatility/regime gate can explain the recent TVR-0009 failure
  without optimizing it away, or move to a relative range-position hypothesis if no broad gate works.

## 2026-08-30 — Batch 11: volatility compression and opening-drive momentum

- Created, compiled, attached, and identity-verified TVR-0007, a Bollinger/Keltner squeeze-release
  strategy requiring relative volume, a local price breakout, and 1H EMA trend confirmation. All
  custom inputs, date bounds, $10,000 capital, 95% sizing, 0.01% commission, and two-tick slippage
  were verified after attachment.
- TVR-0007 failed the base gate: QQQ 5M -0.45%, PF 0.78 over 14 trades; QQQ 15M -0.96%, PF 0.67
  over 17; SPY 5M -0.04%, PF 0.96 over 18; SPY 15M -0.02%, PF 0.99 over 21. Rejected without
  parameter mining or 1M stress because no base cell was positive after costs.
- Created, compiled, attached, and identity-verified TVR-0008, a time-of-day continuation strategy
  that waits for an ATR-sized opening drive and then enters an EMA pullback/reclaim aligned with
  the 1H trend. Its inputs and standardized sizing/cost assumptions were also verified explicitly.
- TVR-0008 failed decisively: QQQ 5M/15M returned -2.43%/-2.90% with PF 0.39/0.50; SPY 5M/15M
  returned -1.34%/-2.28% with PF 0.31/0.51. Win rates were only 24%–28%. Rejected without tuning.
- Lessons: naive compression release did not overcome whipsaw/costs, while the opening-drive
  pullback definition entered continuation too late or after exhaustion. Do not revisit these exact
  definitions without a materially different entry/exit mechanism.
- Next: test a time-of-day mean-reversion or relative-strength/range-position family rather than
  another 1H-EMA momentum variant.

## 2026-08-30 — Batch 10: calendar segmentation and non-VWAP candidate

- Added explicit test-start/test-end inputs to TVR-0002 and compiled the revised source with zero
  errors. TradingView returned zero intraday trades in 2024 and 2025; all available 5M/15M evidence
  is from 2026, so a genuine multi-year walk-forward test is unavailable on the current plan.
- Within 2026, QQQ 15M produced +0.63%, PF 2.99 over five trades in January–April; -0.03%, PF 0
  on one trade in May–June; and +2.04%, PF 14.41 over eight trades in July–August. QQQ 5M history
  was unavailable before May, then produced +0.24%, PF 1.22 over four trades in May–June and
  +0.76%, PF 1.24 over 32 trades in July–August. The direction is encouraging but sample sizes
  remain inadequate for promotion.
- Created and compiled TVR-0006, a non-VWAP Bollinger reversal aligned with the daily EMA-200
  regime. A carried date-window input was detected after initial attachment; all preliminary
  partial-window results were discarded, the inputs were explicitly reset, and the full available
  history was rerun before attribution.
- TVR-0006 full results: QQQ 15M +3.39%, PF 1.28, 1.46% drawdown over 96 trades; QQQ 5M -1.06%,
  PF 0.79; QQQ 1M -0.05%, PF 0.92; SPY 5M/15M both negative. QQQ 15M remained positive at 1.8
  standard deviations but turned negative at 2.2; doubled costs reduced PF to 1.10. Rejected for
  parameter, timeframe, symbol, and execution-cost instability.
- Next: test another non-VWAP family emphasizing volatility compression/expansion or time-of-day
  momentum, while retaining TVR-0002 only as a provisional QQQ lead.

## 2026-08-30 — Batch 9: sizing standardization and parameter stability

- Standardized intraday Pine research to $10,000 initial capital and 95% of equity per position.
  Earlier one-share tests remain useful for profit factor and trade counts, but their dollar returns
  and drawdown percentages are superseded. TVR-0002 through TVR-0005 sources now encode the new
  convention; underlying ETF results still do not simulate option returns.
- TVR-0002 QQQ parameter neighborhood remained positive at entry thresholds 1.0, 1.25, and 1.5
  ATR and opening ranges 15, 30, and 45 minutes on both 5M and 15M. At doubled costs (0.02%
  commission and four ticks slippage), 5M degraded to PF 1.04 while 15M retained PF 5.13 over only
  14 trades. This supports a real but cost-sensitive provisional lead, not promotion.
- Rebased TVR-0002 default results: QQQ 5M +1.00%, PF 1.23, 1.95% maximum drawdown, 36 trades;
  QQQ 15M +2.66%, PF 6.33, 0.72% maximum drawdown, 14 trades; QQQ 1M +0.10%, PF 1.05,
  0.91% maximum drawdown, 40 trades. SPY remained negative on 5M and 15M.
- TVR-0004 failed neighborhood stability. QQQ 5M stayed positive at 1.25 and 1.75 ATR thresholds,
  but QQQ 15M turned negative at both neighbors. Combined with prior SPY and 1M failures, it was
  rejected instead of tuned around the favorable 1.50 ATR default.
- Created TVR-0005, a distinct 1H-trend/session-VWAP reclaim hypothesis. QQQ 5M gained 0.94%
  (PF 1.27, 1.18% drawdown, 37 trades); QQQ 15M gained 0.78% with PF 1.06 and 3.51% drawdown;
  QQQ 1M lost 0.54% with PF 0.37. Both SPY cells lost. TVR-0005 was rejected.
- Next: obtain stronger date/regime segmentation for TVR-0002 and test a non-VWAP hypothesis so
  the research is not dominated by variations of one idea.

## 2026-08-30 — Batch 8: repaired native attachment and intraday matrix

- Repaired the local TradingView MCP smart-compile selector for current Desktop markup. TradingView
  duplicates `Add to chart` text and exposes `Update on chart` through the button title; the old
  selector fell through to Save. Exact chart-study and Strategy Tester identity are now verified.
- TVR-0003 was rejected. SPY 5M: -$31.72, PF 0.67, 179 trades; SPY 15M: -$35.38,
  PF 0.86, 321 trades; QQQ 5M: -$42.89, PF 0.69, 172 trades; QQQ 15M: -$7.94,
  PF 0.97, 284 trades. It lost after costs in every cell.
- TVR-0002 remains provisional. SPY 5M/15M were negative (PF 0.86/0.56). QQQ 5M was
  +$8.01, PF 1.25 over 36 trades; QQQ 15M was +$19.11, PF 6.44 over only 14 trades.
  QQQ 1M stress was approximately flat: +$0.45, PF 1.03 over 40 trades.
- Created TVR-0004, a materially different failed-extension VWAP hypothesis with an explicit ATR
  stop, maximum holding time, entry window, bounded 1H trend distance, and one trade per direction
  per day. QQQ 5M/15M were positive (PF 1.50/1.18 over 35/24 trades), but SPY was negative and
  QQQ 1M stress failed (PF 0.35 over 15 trades). Retained only as a provisional lead.
- All tests model 0.01% commission and two ticks of TradingView slippage per order. They are
  underlying-price tests, not option-return simulations. No candidate is promoted: the available
  intraday sample, trade counts, cross-symbol transfer, 1M robustness, and absence of walk-forward
  evidence are insufficient.
- Next: test nearby non-optimized parameter neighborhoods for TVR-0002/0004, identify stable QQQ
  regions, then seek longer intraday history before any finalist designation.

## 2026-08-30 — Batch 7: saved-script inventory verification

- Objective: determine whether the desktop Pine workflow had silently saved TVR-0002 or TVR-0003
  even though it did not add them to the chart.
- Result: TradingView's authenticated saved-script inventory returned 52 existing scripts; neither
  `TVR-0002 VWAP Opening Range Reversion` nor `TVR-0003 Opening Range ATR Breakout` was present.
- Interpretation: local source injection plus server-side compilation does not establish cloud save,
  chart attachment, or Strategy Tester identity. The two external `.txt` sources remain the
  authoritative preserved artifacts for this project.
- Decision: no cloud save/publish action was taken, no tester metrics were attributed, and both
  candidates remain `SCREENING`.
- Next experiment: repair the TradingView research workflow or use a permitted long-history
  intraday dataset; do not repeat the same compile-only attempt.

## 2026-08-30 — Batch 6: explicit Add-to-chart control diagnostic

- Objective: complete the missing final step for native TVR-0003 Strategy Tester validation.
- Result: Pine Editor panel was confirmed open; TVR-0003 injection and compile succeeded with zero
  errors/warnings. The desktop bridge exposed neither an `Add to chart` nor `Update on chart` control,
  and the TradingView `My scripts` search returned no TVR-0003 match.
- Verification: Strategy Tester continued to identify a different pre-existing ORB study, so no
  tester metrics were assigned to TVR-0003.
- Decision: retain TVR-0003 as `SCREENING`; do not promote or claim native intraday performance.
- Next experiment: use a repaired/clean TradingView session or a permitted long-history intraday
  dataset and independently reconcile script identity before accepting any metrics.

## 2026-08-30 — Batch 5: Pine Editor retry and study-identity verification

- Objective: retry native TradingView attachment for TVR-0003 after the prior Pine Editor failure.
- Result: the Pine Editor panel was already open; TVR-0003 source injection succeeded for 55 lines,
  and the compile/save action reported zero errors and zero warnings.
- Identity check: TradingView did not report the study as added. Searching `My scripts` for the exact
  TVR-0003 title returned no match. Strategy Tester then reported the unrelated pre-existing
  `ORB + Ichimoku + Wickless — v10S Entry-Type Controls FIXED` study, with 11 trades and 0.32% net
  profit on the current chart. Those metrics are explicitly excluded from TVR-0003.
- Decision: TVR-0003 remains `SCREENING`; no intraday performance claim or promotion.
- Lesson: a successful source injection/compile is insufficient evidence of a valid Strategy Tester
  run; study identity must be verified in chart state before accepting metrics.
- Next experiment: use the TradingView UI's explicit Add to chart action or a clean saved-script
  workflow, then verify chart study name/entity before reading 5M/15M/1M results.

## 2026-08-30 — Batch 4: intraday data-availability audit

- Objective: obtain enough native 5M/15M history to independently screen TVR-0002 and TVR-0003,
  then stress them on 1M.
- TradingView desktop data retrieval succeeded for SPY at 5M and returned 300 direct bars. The
  available window is only a few sessions and is not sufficient for credible OOS, walk-forward,
  regime, or parameter-sensitivity analysis. The result was not used as a performance claim.
- The available historical-data connector rejected minute intervals and supports only day/week/
  month/year frequencies. No alternative minute dataset was assumed or substituted.
- Strategy Tester attachment remains unresolved: the clean-tab operation failed, and the Pine
  Editor bridge did not attach TVR-0002 or TVR-0003. Existing Strategy Tester metrics therefore
  remain unrelated to these candidates.
- Decision: no promotion, ranking, or fabricated result. TVR-0002 and TVR-0003 remain `SCREENING`
  with compiled sources preserved.
- Likely issue: current connector capabilities expose only a short live chart bar window while the
  headless backtest engine is limited to 1H/1D. A credible intraday study needs a longer licensed or
  local historical 1M/5M/15M dataset, or a functioning TradingView Strategy Tester attachment.
- Next experiment: diagnose the TradingView Pine Editor/tab bridge and inspect whether the existing
  research project has a permitted local intraday dataset or ingestion utility. If neither exists,
  continue hypothesis development and static validation without promoting performance claims.

## 2026-08-30 — Batch 3: intraday Pine candidate construction and validation

- Objective: convert the next two hypotheses into directly editable Pine sources for native 5M/15M
  testing: VWAP/opening-range reversion and ATR opening-range breakout.
- TVR-0002: session VWAP excursion beyond an ATR-normalized threshold, bullish/bearish rejection
  candle, opening-range completion, and optional 4H EMA slope regime filter; exit on VWAP return or
  session end.
- TVR-0003: 30-minute opening-range break, ATR buffer, relative-volume confirmation, 1H EMA slope
  filter, ATR stop/target, and session-end exit.
- Assumptions encoded: regular session 09:30–15:55, process orders on bar close, 0.01% commission,
  TradingView slippage setting of 2 ticks, no pyramiding. These are underlying-price studies, not
  option-return simulations.
- Static validation: both scripts compiled through TradingView's Pine validation endpoint with zero
  errors and zero warnings.
- Desktop validation: chart was set to SPY 5-minute. The bridge reported the Pine Editor could not
  be opened; its fallback save/compile action succeeded but did not add either study. The subsequent
  Strategy Tester report remained for the pre-existing `Codex Bollinger WF Demo` and showed -0.40%
  net profit, 200 trades, 3% winners, and 39.78% max drawdown. This result is not attributable to
  TVR-0002 or TVR-0003 and is retained only as a diagnostic of study-selection state.
- Decision: persist both scripts as `SCREENING`, not `FINALIST`; no leaderboard promotion and no
  fabricated intraday performance claim.
- Data-quality/overfitting concerns: native 5M/15M history and 1M stress results remain outstanding;
  the desktop bridge must successfully attach each script before TradingView metrics are accepted.
- Next experiment: retry attachment with a clean Pine Editor tab or use TradingView's server-side
  compile/Strategy Tester route, then test each candidate on SPY and QQQ at 5M and 15M plus 1M
  adverse-slippage sensitivity and nearby parameter values.

## 2026-08-30 — Batch 2: cross-symbol hourly baseline screening and walk-forward rejection

- Objective: screen a bounded set of established hypotheses before investing in intraday Pine
  development: Bollinger mean reversion, EMA 20/50 cross, and Keltner breakout.
- Research-library hypothesis source: the supplied `paperswithbacktest/awesome-systematic-trading`
  repository was sampled for systematic momentum/reversal and volatility/trend ideas. Its reported
  statistics were treated as hypothesis prompts only, not as evidence for SPY/QQQ intraday use.
- Instruments/timeframe: SPY and QQQ, hourly bars, 2024-08-29 through 2026-08-28. This was a
  diagnostic context-timeframe screen because the available headless backtest service currently
  exposes 1-hour and daily intervals, not native 5-minute/15-minute strategy backtests.
- Costs/assumptions: $100,000 initial capital, 0.01% commission and 0.02% slippage per side as
  configured in the research call; results are underlying-price backtests, not option returns.
- Initial screen: SPY Bollinger +10.87%, PF 1.56, 63 trades, max DD -5.84%; QQQ Bollinger -0.38%,
  PF 1.01, 57 trades, max DD -11.29%. SPY EMA +10.04%, PF 1.45, 33 trades, max DD -9.63%; QQQ
  EMA +7.41%, PF 1.25, 36 trades, max DD -14.88%. Keltner was approximately flat/weak on both.
  All materially lagged buy-and-hold over this sample.
- Walk-forward: four folds, 70% train / 30% test. SPY Bollinger OOS +3.22% over 19 trades but
  verdict WEAK and robustness 0.48; QQQ Bollinger OOS -5.51% over 14 trades, verdict OVERFITTED.
  SPY EMA OOS -2.91% over 8 trades despite the service label ROBUST, and QQQ EMA OOS -6.69% over
  8 trades, verdict OVERFITTED. The numeric verdict and the negative OOS returns conflict for SPY
  EMA, so the conservative interpretation is rejection pending independent verification.
- Succeeded: the cross-symbol and walk-forward gate prevented promoting attractive-looking
  in-sample/hourly results; Bollinger remains a useful negative control and TVR-0001 remains the
  only persisted candidate.
- Failed: no tested hypothesis demonstrated robust, cross-symbol, out-of-sample edge; the sample
  is also the wrong primary execution timeframe for the user's 5M/15M objective.
- Likely failure reasons: regime dependence, lag, mean-reversion breakdown during persistent
  trends, and insufficiently realistic execution modeling for intraday/option translation.
- Overfitting/data concerns: only two years, limited OOS trade counts, Yahoo-derived bars, and no
  native 5M/15M test in this batch. Hourly results must not be generalized to target execution.
- Decision: do not create a new finalist or add an unverified strategy to the top ten. Preserve all
  numerical results in this append-only log.
- Next experiment: build and validate two explicit intraday Pine candidates on 5M and 15M—(1)
  VWAP/Opening-Range mean reversion gated by 1H/4H trend and volatility regime, and (2) Opening
  Range breakout with ATR/volume confirmation and time-based exits. Test both SPY and QQQ, then
  stress on 1M with adverse slippage and compare nearby parameter values before promotion.

## 2026-08-29 — TVR-0001 infrastructure proof

- Objective: prove the complete analysis-MCP to Pine to TradingView Strategy Tester workflow.
- Instrument/timeframe: SPY, daily bars, 2024-08-29 through 2026-08-28.
- Initial comparison: nine built-in strategies.
- In-sample leader: Donchian, +18.88%; rejected after producing zero out-of-sample trades.
- Walk-forward candidates: Bollinger, EMA, Supertrend, RSI, MACD, and Keltner.
- Demo selection: Bollinger 20/2 long-only because it was the only candidate passing the bounded
  demonstration gate; `MODERATE` robustness 0.74, +5.74% OOS, three OOS trades.
- TradingView validation: +13.69%, profit factor 3.21, 13.00% maximum mark-to-market drawdown,
  11 trades, 81.82% profitable, $336.39 commission.
- Headless comparison: +14.47%, 11 matching trades, 3.69% closed-trade drawdown.
- Finding: closed-trade-only equity materially understated drawdown while positions were open.
- Decision: retain as `DEMO`; do not promote. It is an infrastructure baseline and does not yet
  address the target 5-minute/15-minute day-trading research problem.
- Pine source: `strategies/TVR-0001_bollinger_wf_demo.txt`.

## 2026-09-01 — TVR-0025 Lorentzian Classification futures conversion

- Objective: convert the supplied open-source `Machine Learning: Lorentzian Classification`
  indicator into an executable strategy and run a quick native TradingView screen on the Micro
  E-mini S&P 500 (`CME_MINI:MES1!`) and Micro E-mini Nasdaq-100 (`CME_MINI:MNQ1!`). This was a
  user-authorized futures experiment and did not involve Robinhood or live execution.
- Pine source: `strategies/TVR-0025_lorentzian_classification_futures_strategy.txt`.
- Signal behavior: entries follow the original filtered Lorentzian-classification long/short
  signals; exits follow the original strict/default four-bar and early-opposite-signal logic.
  Dynamic exits are disabled.
- Verified indicator settings: source `close`, 8 neighbors, 2,000 bars back, color compression 1,
  default exits shown, dynamic exits false, trade stats shown, and worst-case estimates true.
- Strategy assumptions: $10,000 initial capital; one contract; no pyramiding; confirmed-bar
  processing; $1.25 commission per contract per order; 2 minimum ticks of slippage per order; 10%
  long/short margin. The original indicator's worst-case setting controls its diagnostic table;
  confirmed-bar strategy orders separately enforce conservative signal timing.
- Native validation: Pine v6 compiled with zero errors after replacing one v5 integer-to-Boolean
  shorthand with an explicit comparison. TradingView attached entity `16tPl5` with exact strategy
  identity `TVR-0025 Lorentzian Classification Futures`. Individual trades were exposed for both
  symbols; summary metrics were read from the matching Strategy Tester report.
- MES 5-minute: net -$190.00 (-1.90%), profit factor 0.755, 63 trades, 39.06% profitable,
  maximum drawdown $312.50 (3.12%), commission $161.25.
- MES 15-minute: net -$705.00 (-7.05%), profit factor 0.492, 52 trades, 41.51% profitable,
  maximum drawdown $972.50 (9.66%), commission $132.50.
- MNQ 5-minute: net -$289.00 (-2.89%), profit factor 0.847, 59 trades, 49.15% profitable,
  maximum drawdown $695.25 (6.90%), commission $147.50.
- MNQ 15-minute: net -$81.50 (-0.82%), profit factor 0.977, 53 trades, 54.72% profitable,
  maximum drawdown $1,318.25 (12.64%), commission $132.50.
- Decision: reject this exact default configuration. All four screens lost money after the encoded
  costs; MNQ 15-minute was closest to breakeven but had the largest dollar/percentage drawdown and
  still failed a profit-factor-above-one gate. Do not add it to the SPY/QQQ top-ten leaderboard and
  do not interpret this quick 2,000-bar screen as deep or out-of-sample validation.
- Next useful experiment: keep the saved source as a negative-control baseline and, only if further
  work is desired, test bounded changes such as a session filter, trend/regime filter, and nearby
  neighbor/kernel settings using explicit train/test periods rather than optimizing on this same
  window.

## 2026-09-05 — TVR-0026/TVR-0027 simple opening-strategy futures screen

- Objective: test two deliberately simple, automatable opening-session hypotheses on the user-authorized
  Micro E-mini S&P 500 (`CME_MINI:MES1!`) and Micro E-mini Nasdaq-100 (`CME_MINI:MNQ1!`) futures.
- Sources: `strategies/TVR-0026_first_five_minute_breakout.txt` and
  `strategies/TVR-0027_fifteen_minute_orb_retest.txt`. Both are complete Pine v6 `.txt` artifacts,
  statically analyzed with zero issues, and compiled natively in TradingView with zero reported errors.
- TVR-0026 hypothesis: the 09:30–09:35 ET candle must have a bounded ATR-normalized range and a
  strong close location (green near its high or red near its low); a later 5-minute close beyond its
  extreme enters, with an opposite-range stop, 1.5R target, one trade per day, and a 15:50 ET flatten.
- TVR-0027 hypothesis: the completed 09:30–09:45 ET opening range must break, then a separate later
  5-minute candle must retest the broken boundary and close back outside; exits use the opposite range,
  1.5R, one trade per day, and a 15:50 ET flatten.
- Shared assumptions: $10,000 initial capital; one futures contract; `$1.25` commission per contract
  per order; 2 ticks slippage per order; 10% margin; confirmed-bar processing; ET session rules.
- Native identity and tester verification: the chart was 5-minute; TradingView chart state reported the
  exact strategy title after each update; `pine errors` returned zero errors; Strategy Tester and trade
  data matched the corresponding title. The available tester window was Jul 12, 2026–Sep 4, 2026.
- TVR-0026 results: MES1! net `-$66.25`, PF `0.000`, max drawdown `$66.25`, `1` trade, commission
  `$2.50`; MNQ1! net `$0.00`, `0` trades, no PF/drawdown evidence. Decision: reject/insufficient sample.
- TVR-0027 results: MES1! net `-$450.00` (`-4.50%`), PF `0.681`, max drawdown `$817.50` (`7.94%`),
  `24` trades, `44%` profitable, commission `$62.50`; MNQ1! net `+$453.50` (`+4.535%`), PF `1.116`,
  max drawdown `$1,472.00` (`12.34%`), `31` trades, `51.61%` profitable, commission `$77.50`.
- Decision: keep TVR-0027 as `SCREENING` because its MNQ result is a modest single-symbol lead with
  a large drawdown and failed MES transfer; do not promote it, optimize it on this same window, or
  treat it as evidence for live trading. TVR-0026 is `REJECTED`.
- Scope/limitations: this was a quick native TradingView screen, not deep backtesting, walk-forward,
  out-of-sample validation, parameter neighborhood testing, or 1-minute stress testing. No Robinhood
  tools, accounts, orders, or live execution were touched. The final TradingView state is left visible
  on MNQ1! 5-minute with TVR-0027 and its Strategy Tester report for inspection.

## 2026-09-05 — Simple high-win-rate batch: TVR-0028 through TVR-0030

- Objective: continue the user-directed simple-strategy search on SPY and QQQ, prioritizing high win
  rate, small mechanically bounded losses, and easy automation. All tests are underlying-ETF research;
  no Robinhood or broker tools were accessed.
- Shared assumptions: $10,000 initial capital, 95% of equity per position, 0.01% commission per side,
  two ticks of slippage per order, bar-close processing, no pyramiding, one trade per day where encoded,
  and regular-session ET timing. Every source is a complete Pine v6 `.txt` file.

### TVR-0028 — RSI2 Trend Pullback

- Hypothesis: an RSI(2) extreme that immediately reverses in the direction of a chart-timeframe EMA200
  should produce frequent small reversion wins with a 0.45 ATR stop, 0.55 ATR target, neutral-RSI/time
  exit, and one trade per day.
- Source: `strategies/TVR-0028_rsi2_trend_pullback.txt`; local static analysis zero issues. Native Pine
  initially rejected a Boolean `na()` check at line 30; it was corrected, then compiled with zero
  errors/warnings and attached as exact study/tester identity `TVR-0028 RSI2 Trend Pullback`.
- SPY 5m: -$121.82, PF 0.412, max DD $150.38, 48 trades, 43.75% wins.
- SPY 15m: -$230.82, PF 0.597, max DD $275.95, 99 trades, 41.41% wins.
- QQQ 5m: -$127.54, PF 0.547, max DD $131.21, 48 trades, 54.17% wins.
- QQQ 15m: -$40.89, PF 0.941, max DD $208.23, 102 trades, 52.94% wins.
- Decision: `REJECTED`. Every base cell lost after costs; the small-target/high-frequency structure did
  not create a sufficiently high hit rate or payoff to cover losses and transaction costs.

### TVR-0029 — Confirmed Gap Fill

- Hypothesis: fade only a moderate 0.15%-0.80% overnight gap after the first 15 minutes and the next
  bar both confirm movement toward the prior RTH close; stop beyond the opening extreme and exit at
  the prior close or noon.
- Source: `strategies/TVR-0029_confirmed_gap_fill.txt`; local static analysis and native Pine compilation
  both completed with zero errors/warnings. Exact chart/tester identity was verified.
- SPY 5m: -$17.20, PF 0, max DD $17.20, one losing trade.
- SPY 15m: -$139.54, PF 0.188, max DD $166.83, 11 trades, 18.18% wins.
- QQQ 5m and 15m: zero trades in the available history.
- Decision: `REJECTED`. The confirmation/reward filter was too sparse, and every nonempty cell lost.

### TVR-0030 — Failed Auction Tight Exit

- Hypothesis: preserve TVR-0022's economically plausible failed-initial-range/VWAP-reclaim entry and
  completed 1H trend filter, but freeze risk at entry and use a 0.50 ATR stop, 0.60 ATR target, and
  eight-bar maximum hold to pursue a higher win rate and smaller losses.
- Source: `strategies/TVR-0030_failed_auction_tight_exit.txt`; local static analysis zero issues. Native
  Pine identified two conditional crossover consistency warnings; both calls were moved to global
  series variables. The repaired source compiled with zero errors/warnings and attached with exact
  study/tester identity `TVR-0030 Failed Auction Tight Exit`.
- Base matrix — SPY 5m: +$22.26 (+0.22%), PF 1.693, max DD $20.55 (0.21%), 12 trades, 66.67% wins;
  SPY 15m: -$47.29, PF 0.803, max DD $120.15, 32 trades, 46.88% wins.
- Base matrix — QQQ 5m: -$62.80, PF 0.287, max DD $92.00, nine trades, 33.33% wins; QQQ 15m:
  +$112.17 (+1.12%), PF 1.610, max DD $73.75 (0.73%), 25 trades, 68% wins.
- One-minute stress: SPY -$8.42, PF 0.273, three trades; QQQ +$0.48, PF 1.082, two trades. These
  samples are too small to establish execution/noise robustness.
- Four-tick slippage: SPY 5m +$18.42, PF 1.541, 12 trades, 66.67% wins; QQQ 15m +$103.21, PF 1.549,
  25 trades, 68% wins.
- Nearby exits: 0.45/0.55 ATR produced SPY 5m +$21.78/PF 1.730 and QQQ 15m +$85.15/PF 1.440;
  0.55/0.65 ATR produced SPY 5m +$10.27/PF 1.244 and QQQ 15m +$138.49/PF 1.792. Both lead cells
  remained positive across the bounded neighborhood.
- QQQ 15m date segments at the default exit: Jan-Apr +$39.61, PF 2.124, seven trades; May-Jun
  +$63.25, PF 1.875, nine trades; Jul-Aug +$8.85, PF 1.116, nine trades. All three were positive,
  but each is a tiny sample and the latest segment is close to flat.
- Decision: add TVR-0030 to the readable/machine leaderboard at provisional rank 4. This is not a
  finalist or deployable strategy: only two of four base cells were positive, the SPY lead has 12
  trades, QQQ 15m has 25, and the 1m checks are unusably small. Its value is that the high-win-rate
  lead survived higher slippage, nearby exits, and coarse date segmentation without becoming negative.
- Next experiment: isolate whether the tight frozen exit or the existing TVR-0022 entry is responsible
  for the improvement, then seek a simple filter that improves the failed SPY 15m/QQQ 5m cells without
  optimizing the already-positive QQQ 15m window.

## 2026-09-06 — TVR-0031 normalized-opening-range attribution test

- Hypothesis: TVR-0030's failed symbol/timeframe cells may come from taking failed-auction signals
  after an opening range that is either too narrow to be meaningful or already consumes most of a
  normal day's movement. Keep every TVR-0030 rule fixed, but require the completed 09:30–10:00 range
  to be between 0.10 and 0.60 of the prior completed daily ATR(14).
- Source: `strategies/TVR-0031_failed_auction_normalized_open.txt`. Local Pine analysis reported zero
  issues. Native Pine compilation reported zero errors/warnings, and the chart plus Strategy Tester
  both exposed the exact identity `TVR-0031 Failed Auction Normalized Open`.
- Shared assumptions: $10,000 initial capital, 95% of equity per position, 0.01% commission per side,
  two ticks of slippage per order, bar-close processing, no pyramiding, one trade per day, and ET
  regular-session timing.
- Base matrix — SPY 5m: +$22.26 (+0.22%), PF 1.693, max DD $20.55, 12 trades, 66.67% wins; SPY
  15m: -$78.16 (-0.78%), PF 0.675, max DD $123.14, 31 trades, 45.16% wins.
- Base matrix — QQQ 5m: -$62.80 (-0.63%), PF 0.287, max DD $92.00, nine trades, 33.33% wins; QQQ
  15m: +$65.89 (+0.66%), PF 1.358, max DD $73.75, 24 trades, 66.67% wins.
- Attribution: both 5m cells were numerically unchanged from TVR-0030. On 15m the filter removed one
  SPY and one QQQ trade, but SPY loss increased from -$47.29 to -$78.16 and QQQ profit fell from
  +$112.17 to +$65.89. It therefore did not explain or repair the transfer problem.
- Supporting validation: TradingView returned individual QQQ 15m orders for the exact strategy.
  Per-bar strategy equity remained unavailable from the internal API (`data_points: 0`); the native
  Strategy Tester maximum drawdown above is retained as the authoritative drawdown summary. The
  screenshot endpoint stalled twice, so no new screenshot artifact is claimed.
- Decision: `REJECTED`. Do not tune the 0.10/0.60 thresholds or run costs, subperiods, or 1m stress
  around a base filter that weakened the only material lead and left the two 5m cells unchanged.
  TVR-0030 remains provisional rank 4.
- Lesson/next: opening-range size is not the missing transfer filter for this family. Stop adding
  filters to TVR-0030 for now; the next batch should test a materially distinct simple setup with a
  larger natural sample, preferably a fixed-time trend/reversal decision whose signal definition is
  invariant across 5m and 15m bars.

## 2026-09-06 — TVR-0032 fixed 11:00 opening-range hold

- Hypothesis: an opening-range break that is still held at exactly 11:00 ET, aligned with the last
  completed 1H close/EMA30 slope, may capture persistent morning order flow more reliably than an
  immediate breakout. A lower and upper prior-daily-ATR distance bound avoids marginal breaks and
  extreme chasing.
- Source: `strategies/TVR-0032_eleven_am_opening_range_hold.txt`. Local Pine analysis found zero
  issues; native Pine compiled with zero errors/warnings. The chart and every accepted Strategy
  Tester result reported exact identity `TVR-0032 11AM Opening Range Hold`.
- Invariance controls: the decision is the bar closing at 11:00 ET, risk is frozen from the last
  completed 15m ATR(14), and the maximum hold is 60 clock minutes. Shared assumptions remained
  $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of slippage, bar-close
  processing, no pyramiding, and one trade per day.
- Base matrix — SPY 5m: -$24.40 (-0.24%), PF 0.570, max DD $37.15, 13 trades, 46.15% wins; SPY
  15m: -$189.89 (-1.90%), PF 0.360, max DD $201.20, 44 trades, 38.64% wins.
- Base matrix — QQQ 5m: -$32.48 (-0.32%), PF 0.518, max DD $44.23, eight trades, 37.50% wins;
  QQQ 15m: +$61.64 (+0.62%), PF 1.250, max DD $108.84, 41 trades, 60.98% wins.
- Decision: `REJECTED`. Three of four cells lost after costs; the one positive cell was modest and
  symbol-specific. The larger 15m samples make the SPY failure especially informative. Do not tune
  distance, exits, or clock time around the isolated QQQ 15m result, and do not run 1m/cost/OOS
  stress on a failed base matrix.
- Lesson/next: a held opening-range break is not a transferable morning-continuation edge. The next
  distinct batch should test a simple reversal after a failed 11:00 opening-range hold rather than
  another continuation variant, using the same fixed-clock and completed-timeframe controls.

## 2026-09-06 — TVR-0033 fixed 11:00 failed-range reversal

- Hypothesis: after a one-sided opening-range breakout between 10:00 and 11:00 ET, a close back
  inside the completed 09:30–10:00 range at exactly 11:00 may identify a failed auction suitable for
  a short reversal. Avoid fading a strong completed 1H trend, and use a nearby range-midpoint/ATR
  target to favor a high hit rate and mechanically bounded loss.
- Source: `strategies/TVR-0033_eleven_am_failed_range_hold.txt`. Local Pine analysis reported zero
  issues; native Pine compiled with zero errors/warnings. The chart and all accepted Strategy Tester
  results exposed exact identity `TVR-0033 11AM Failed Range Hold`.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, bar-close processing, no pyramiding, one trade per day, completed 15m ATR risk, a
  60-minute clock exit, and ET regular-session timing.
- Base matrix — SPY 5m: -$45.87 (-0.46%), PF 0.295, max DD $66.57, eight trades, 25.00% wins;
  SPY 15m: -$148.40 (-1.48%), PF 0.378, max DD $180.35, 22 trades, 31.82% wins.
- Base matrix — QQQ 5m: -$5.85 (-0.06%), PF 0.876, max DD $29.04, seven trades, 57.14% wins;
  QQQ 15m: -$34.10 (-0.34%), PF 0.835, max DD $179.19, 22 trades, 50.00% wins.
- Decision: `REJECTED`. Every base cell lost after realistic costs. The superficially high QQQ 5m
  win rate still produced a loss and came from only seven trades, so it is not a lead. No 1m, higher
  cost, date-segment, or parameter tests were run around a failed base matrix.
- Lesson/next: paired fixed-time continuation and reversal tests both reject a simple 11:00
  opening-range state rule. Move to an orthogonal volatility/state setup rather than tuning more
  opening-range time-window variants.

## 2026-09-06 — TVR-0034 hourly RSI snapback

- Cheap premise screen: `tradingview_analysis.compare_strategies` tested nine standard strategies
  on two years of hourly data with $10,000 capital, 0.1% commission, and 0.05% slippage. Standard
  RSI mean reversion ranked first on both ETFs: SPY +12.71%, PF 1.84, 73.8% wins over 42 trades;
  QQQ +15.72%, PF 1.61, 69.2% wins over 39 trades. The separate screen was used only to select a
  family, not accepted as evidence for the intraday candidate.
- Hypothesis: when the last completed 1H RSI(14) is at a moderate extreme (35/65), the first
  chart-timeframe bar that closes beyond the preceding bar in the reversal direction may capture a
  short snapback with a high hit rate. Restrict entries to 10:00–14:30 ET, one trade per day, and
  freeze a symmetric 0.45 completed-15m-ATR bracket with a 60-minute maximum hold.
- Source: `strategies/TVR-0034_hourly_rsi_snapback.txt`. Local Pine analysis reported zero issues;
  native Pine compiled with zero errors/warnings. The chart and every accepted Strategy Tester
  result exposed exact identity `TVR-0034 Hourly RSI Snapback`.
- Shared Pine assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks
  of slippage, bar-close processing, no pyramiding, one trade per day, and ET session timing.
- Base matrix — SPY 5m: -$73.97 (-0.74%), PF 0.462, max DD $102.45, 24 trades, 41.67% wins;
  SPY 15m: -$59.36 (-0.59%), PF 0.855, max DD $165.03, 72 trades, 51.39% wins.
- Base matrix — QQQ 5m: +$3.37 (+0.03%), PF 1.016, max DD $134.46, 30 trades, 56.67% wins;
  QQQ 15m: -$179.63 (-1.80%), PF 0.754, max DD $349.68, 91 trades, 46.15% wins.
- Decision: `REJECTED`. Three of four cells lost. The only positive result was $3.37 over 30 trades,
  with a drawdown roughly 40 times the net profit, so it is not a credible lead. No 1m, higher-cost,
  subperiod, or nearby-parameter tests were run.
- Lesson/next: a broad hourly RSI edge does not survive this short-horizon intraday translation.
  Do not tune RSI thresholds or brackets around QQQ 5m. Return to a materially distinct volatility
  structure whose risk is defined by the setup itself, such as a two-bar contraction/expansion.

## 2026-09-06 — TVR-0035 completed-15m contraction breakout

- Hypothesis: a completed 15-minute bar whose range contracts to at most 65% of its predecessor
  and 80% of completed 15m ATR may store enough short-term energy for a clean breakout. Trade only
  in the direction of the completed 1H EMA30 trend, use the contraction's opposite edge as the
  stop, require setup risk between 0.15 and 0.70 ATR, target 0.80R, and allow one trade per day.
- Source: `strategies/TVR-0035_completed_15m_contraction_break.txt`. Local Pine analysis reported
  zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester
  identity `TVR-0035 Completed 15m Contraction Break` was verified for every accepted base/1m result.
- Invariance/assumptions: the setup and risk range come from completed 15m bars on every chart;
  only breakout timing changes. $10,000 initial capital, 95% sizing, 0.01% commission per side,
  two ticks of slippage, bar-close processing, no pyramiding, ET 10:00–14:30 entries, a 60-minute
  maximum hold, and a forced session exit.
- Base matrix — SPY 5m: -$57.18 (-0.57%), PF 0.213, max DD $57.18, 14 trades, 35.71% wins;
  SPY 15m: +$16.83 (+0.17%), PF 1.240, max DD $38.53, 21 trades, 57.14% wins.
- Base matrix — QQQ 5m: -$3.59 (-0.04%), PF 0.945, max DD $50.06, 13 trades, 61.54% wins;
  QQQ 15m: +$20.45 (+0.20%), PF 1.165, max DD $70.27, 22 trades, 72.73% wins.
- Four-tick slippage — SPY 15m: +$9.33, PF 1.125, max DD $41.49, 21 trades, 57.14% wins;
  QQQ 15m: +$12.55, PF 1.098, max DD $73.59, 22 trades, 72.73% wins. The sign survived, but
  expectancy became extremely thin.
- One-minute timing/noise stress — SPY: -$24.32, PF 0.139, max DD $28.24, five trades, 20.00%
  wins; QQQ: -$2.40, PF 0.938, max DD $40.43, nine trades, 66.67% wins. Both samples are small and
  both lost.
- Decision: `REJECTED`. The higher 15m hit rate did not translate into adequate expectancy. Both
  5m cells were negative, both 1m stress cells were negative, and doubled-cost 15m PF fell near
  one. Do not tune the contraction ratio, risk bounds, or target multiple around this window.
- Lesson/next: setup-defined risk improved hit rate on QQQ 15m, but simple trend-aligned expansion
  remained too cost-sensitive. The next family should seek a structural destination for the exit
  rather than a small arbitrary R target, while retaining a mechanically bounded stop.

## 2026-09-06 — TVR-0036 two-bar pullback retest

- Hypothesis: in a completed 1H EMA30 trend, two consecutive countertrend chart bars followed by a
  reversal through the latest bar may resume toward the session extreme already established before
  entry. Use the two-bar pullback extreme plus 0.05 completed-15m ATR as the stop; require risk of
  0.15–0.75 ATR, at least 0.75R of room to the session high/low, and no more than 1.50 ATR target
  distance. Permit one trade per day and a 90-minute maximum hold.
- Distinction: unlike rejected TVR-0008, this setup has no opening-drive or chart-EMA requirement
  and uses the pre-entry session extreme as a structural target rather than an arbitrary ATR target.
- Source: `strategies/TVR-0036_two_bar_pullback_retest.txt`. Local Pine analysis reported zero
  issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester identity
  `TVR-0036 Two-Bar Pullback Retest` was verified in every accepted base cell.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, bar-close processing, no pyramiding, one trade per day, 10:00–14:30 ET entries, and a
  forced regular-session exit.
- Base matrix — SPY 5m: -$66.81 (-0.67%), PF 0.187, max DD $77.11, 10 trades, 30.00% wins;
  SPY 15m: -$1.80 (-0.02%), PF 0.921, max DD $16.96, four trades, 25.00% wins.
- Base matrix — QQQ 5m: -$89.63 (-0.90%), PF 0.482, max DD $107.38, 18 trades, 33.33% wins;
  QQQ 15m: +$4.73 (+0.05%), PF 1.228, max DD $23.27, two trades, 50.00% wins.
- Decision: `REJECTED`. Both 5m cells lost decisively, while the 15m cells produced only six total
  observations. The lone positive result is one win and one loss. No 1m, cost, parameter, or date
  stress was justified, and the structural constraints were not loosened after observing sparsity.
- Lesson/next: requiring both a strict pullback pattern and a nearby session-extreme destination
  overfilters 15m without improving 5m quality. The next research batch should use a recurring,
  fixed observation rather than another multi-condition candle sequence.

## 2026-09-06 — TVR-0037 prior close-location morning pullback

- Hypothesis: a prior session that closes in its upper/lower quartile may retain directional
  pressure after a morning pullback. At exactly 10:00 ET, enter only when the first 30 minutes are
  still on the pullback side of the prior close but have recovered through their own midpoint;
  stop beyond the opening extreme and target the prior close. Require 0.15–1.00 completed-15m ATR
  risk and at least 0.60R to the structural target.
- Source: `strategies/TVR-0037_prior_close_location_pullback.txt`. Local Pine analysis found zero
  issues; native Pine compiled with zero errors/warnings. The chart and Strategy Tester exposed
  exact identity `TVR-0037 Prior Close-Location Pullback` on every base cell.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, bar-close processing, no pyramiding, one 10:00 ET decision per day, completed daily and
  15m inputs, a 120-minute maximum hold, and forced session exit.
- Base matrix: SPY 5m zero trades; SPY 15m zero trades; QQQ 5m zero trades; QQQ 15m zero trades.
- Decision: `REJECTED` as overfiltered/unsupported. Exact native results confirm the strategy was
  loaded, but there are no observations from which to estimate expectancy. No parameter loosening,
  1m, cost, subperiod, or neighborhood testing was performed.
- Lesson/next: combining a fixed observation with several structural admission tests can still
  eliminate the sample. The next batch should deliberately target a near-daily observation—such as
  the completed first 15-minute candle—using only one directional context and a simple bounded exit.

## 2026-09-06 — TVR-0038 first-15-minute daily-trend continuation

- Hypothesis: the direction of the completed 09:30–09:45 ET candle may persist when it agrees with
  the prior completed daily regime. Enter once at 09:45 when the opening candle direction matches
  prior daily close versus EMA20; stop at the opening candle midpoint, target 0.65R, and exit after
  60 minutes. The only admission rules are daily direction and a four-tick minimum midpoint risk.
- Source: `strategies/TVR-0038_first_15m_daily_trend_continuation.txt`. Offline Pine analysis found
  zero issues. Native Pine compiled with zero errors/warnings after the five-hour Codex limit reset,
  and chart plus Strategy Tester identity was exactly
  `TVR-0038 First 15m Daily-Trend Continuation` for every accepted result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, confirmed bar-close processing, no pyramiding, one trade per day, and ET session timing.
- Base matrix — SPY 5m: -$90.75 (-0.91%), PF 0.500, max DD $130.93, 27 trades, 44.44% wins; SPY
  15m: -$47.16 (-0.47%), PF 0.917, max DD $171.90, 75 trades, 53.33% wins.
- Base matrix — QQQ 5m: +$21.51 (+0.22%), PF 1.094, max DD $91.89, 23 trades, 60.87% wins; QQQ
  15m: +$193.54 (+1.94%), PF 1.236, max DD $221.24, 67 trades, 55.22% wins.
- Bounded QQQ 15m target neighborhood: 0.55R returned +$169.96/PF 1.207 and 0.75R returned
  +$217.94/PF 1.265, each over the same 67 trades. Four-tick slippage at the default 0.65R retained
  +$164.22/PF 1.196 with $228.14 maximum drawdown.
- QQQ 15m date segments: January–April +$66.43/PF 1.220 over 29 trades; May–June
  +$131.95/PF 1.609 over 19; July–August -$25.49/PF 0.914 over 18. The most recent segment failed.
- One-minute timing/noise stress: SPY -$50.39, PF 0.026 over eight trades and QQQ -$67.26,
  PF 0.163 over five. The available 1m samples are short, but both are decisively adverse.
- Decision: `REJECTED`. Positive QQQ results and stable nearby target/cost checks are outweighed by
  both SPY losses, a weak QQQ 5m PF, the negative recent QQQ 15m segment, and failed 1m execution
  checks. Do not add a second filter or optimize EMA length around this observed window.
- Lesson/next: the first 15-minute direction contains a weak QQQ tendency but not a transferable,
  current-regime edge. The next simple batch should switch the entry mechanism rather than add
  filters—test a first-hour VWAP pullback/reclaim with a fixed observation and structural stop.

## 2026-09-06 — TVR-0039 fixed first-hour VWAP pullback/reclaim

- Hypothesis: directional order flow in the first 30 minutes may resume after a controlled VWAP
  pullback during the next 30 minutes. At 10:30 ET, enter only if the first leg closed directionally
  beyond session VWAP, the pullback window touched VWAP, and price reclaimed it. Use the pullback
  extreme as the stop, a 0.65R target, and a 90-minute maximum hold.
- Distinction: unlike TVR-0005's first generic post-opening reclaim with 1H EMA/relative-volume
  filters and ATR exits, TVR-0039 uses a fixed two-stage first-hour sequence and a structural stop.
- Source: `strategies/TVR-0039_first_hour_vwap_pullback_reclaim.txt`. Offline Pine analysis found
  zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester
  identity `TVR-0039 First-Hour VWAP Pullback Reclaim` was verified in all four base cells.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, confirmed bar-close processing, no pyramiding, one 10:30 ET decision per day, and a
  forced regular-session exit.
- Base matrix — SPY 5m: -$17.93 (-0.18%), PF 0.673, max DD $33.77, seven trades, 57.14% wins;
  SPY 15m: -$237.51 (-2.38%), PF 0.655, max DD $309.20, 68 trades, 54.41% wins.
- Base matrix — QQQ 5m: +$43.90 (+0.44%), PF 1.494, max DD $87.88, nine trades, 66.67% wins;
  QQQ 15m: -$259.52 (-2.60%), PF 0.698, max DD $393.15, 61 trades, 52.46% wins.
- Decision: `REJECTED`. Three cells lost and the two longer-history 15m cells failed decisively.
  The only positive cell contains nine trades, so no parameter, cost, date-segment, or 1m stress
  testing is justified.
- Lesson/next: a fixed morning VWAP touch/reclaim does not improve the broader evidence against
  generic VWAP continuation. Move away from continuation and test a simple first-hour range
  mean-reversion decision with asymmetric small-loss exits and no trend filter.

## 2026-09-06 — TVR-0040 first-hour outer-range mean reversion

- Hypothesis: a 10:30 ET close in the outer fifth of the completed first-hour range may snap back
  toward the midpoint. Enter once without a trend filter, stop two ticks beyond the first-hour
  extreme, target the midpoint, and allow up to 120 minutes.
- Source: `strategies/TVR-0040_first_hour_outer_range_reversion.txt`. Offline Pine analysis found
  zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester
  identity `TVR-0040 First-Hour Outer-Range Reversion` was verified for every base result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, confirmed bar-close processing, no pyramiding, one fixed decision per day, and ET timing.
- Base matrix — SPY 5m: -$71.17 (-0.71%), PF 0.576, max DD $101.66, 27 trades, 18.52% wins;
  SPY 15m: -$135.42 (-1.35%), PF 0.791, max DD $229.98, 82 trades, 29.27% wins.
- Base matrix — QQQ 5m: -$22.19 (-0.22%), PF 0.908, max DD $152.88, 27 trades, 29.63% wins;
  QQQ 15m: -$135.66 (-1.36%), PF 0.862, max DD $211.16, 91 trades, 29.67% wins.
- Decision: `REJECTED`. Every base cell lost and the substantial 15m samples directly contradict
  the high-win-rate premise. No outer-zone, stop, target, cost, date, or 1m tuning was justified.
- Lesson/next: first-hour extremes tend to persist too often for an unconditional midpoint fade.
  The next orthogonal test should use cross-ETF relative divergence at a fixed time, fading only the
  ETF that has materially outrun SPY/QQQ peer performance, with a small frozen ATR bracket.

## 2026-09-06 — TVR-0041 cross-ETF first-hour divergence fade

- Hypothesis: at exactly 10:30 ET, a SPY/QQQ return divergence of at least 0.25 percentage points
  may represent a temporary relative-value dislocation. Fade the outperforming ETF and buy the
  underperforming ETF using a frozen completed-15m-ATR bracket: 0.45 ATR stop, 0.30 ATR target,
  and a 60-minute maximum hold.
- Distinction: this is the fixed-time reversal counterpart to rejected TVR-0012 relative-strength
  continuation. It uses the current ETF's RTH-open return versus its peer and does not require an
  EMA pullback, VWAP event, or trend filter.
- Source: `strategies/TVR-0041_cross_etf_first_hour_divergence_fade.txt`. Offline Pine analysis
  found zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy
  Tester identity `TVR-0041 Cross-ETF First-Hour Divergence Fade` was verified for every result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks
  of slippage, confirmed bar-close processing, no pyramiding, one 10:30 decision per day, and ET
  session timing. Peer daily open is known at the regular-session open; peer intraday close uses
  completed chart-timeframe data without lookahead.
- Base matrix — SPY 5m: -$70.95 (-0.71%), PF 0.317, max DD $71.35, 21 trades, 47.62% wins;
  SPY 15m: -$84.25 (-0.84%), PF 0.781, max DD $132.48, 62 trades, 50.00% wins.
- Base matrix — QQQ 5m: -$27.98 (-0.28%), PF 0.810, max DD $100.48, 21 trades, 52.38% wins;
  QQQ 15m: -$181.39 (-1.81%), PF 0.717, max DD $309.46, 62 trades, 54.84% wins.
- Decision: `REJECTED`. Every base cell lost after costs, and the two longer-history 15m samples
  are materially negative despite 50%–55% win rates. No threshold, cost, date, or 1m stress testing
  was run around a failed base matrix.
- Lesson/next: a first-hour SPY/QQQ divergence did not mean-revert quickly enough to overcome the
  asymmetric small-target structure and costs. Combined with TVR-0012, both simple continuation
  and simple reversal treatments of raw cross-ETF divergence are rejected. Move to a non-relative
  volatility/state hypothesis rather than tuning the divergence threshold.

## 2026-09-06 — TVR-0042 confirmed opening-gap continuation

- Hypothesis: a moderate 0.15%–0.80% overnight gap that is confirmed by the completed first
  15-minute candle may continue briefly after 09:45 ET. Require a directional close location of
  at least 60%, use the opening-range midpoint as a mechanically defined stop, target 0.65R, and
  exit after 45 minutes.
- Distinction: unlike TVR-0029, this follows rather than fades the gap; unlike TVR-0016/0017, it
  does not require a five-day trend or later opening-range breakout/hold. It directly tests the
  user's simple first-candle concept with the overnight gap as the sole directional context.
- Source: `strategies/TVR-0042_confirmed_opening_gap_continuation.txt`. Offline Pine analysis found
  zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester
  identity `TVR-0042 Confirmed Opening-Gap Continuation` was verified for every base result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks
  of slippage, confirmed bar-close processing, no pyramiding, one 09:45 decision per day, completed
  prior-day close, and ET session timing.
- Base matrix — SPY 5m: -$103.88 (-1.04%), PF 0.234, max DD $103.88, 14 trades, 28.57% wins;
  SPY 15m: -$190.72 (-1.91%), PF 0.546, max DD $221.34, 45 trades, 46.67% wins.
- Base matrix — QQQ 5m: -$114.17 (-1.14%), PF 0.336, max DD $131.05, 12 trades, 33.33% wins;
  QQQ 15m: +$29.26 (+0.29%), PF 1.071, max DD $113.05, 36 trades, 55.56% wins.
- Decision: `REJECTED`. Three cells lost decisively. The only positive cell earned less than one
  third of one percent, had PF 1.07, and drew down almost four times its net profit. No threshold,
  target, cost, segment, or 1m stress testing was run around this failed base matrix.
- Lesson/next: first-candle confirmation did not lift gap continuation to the desired hit rate or
  payoff quality. Do not optimize gap thresholds or the 0.65R target. Test a materially different
  state based on prior-day volatility compression rather than another opening-gap variant.

## 2026-09-06 — TVR-0043 prior-day compression opening-range expansion

- Hypothesis: a prior session whose range is no more than 0.75 of its completed daily ATR may store
  energy for a next-session expansion. At exactly 10:15 ET, trade a close outside the completed
  09:30–10:00 range, stop at its midpoint, target 0.75R, and exit after 90 minutes.
- Source: `strategies/TVR-0043_prior_day_compression_or_expansion.txt`. Offline Pine analysis found
  zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester
  identity `TVR-0043 Prior-Day Compression OR Expansion` was verified for every base result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks
  of slippage, confirmed bar-close processing, no pyramiding, one 10:15 decision per day, completed
  prior-day range/ATR inputs, and ET session timing.
- Base matrix — SPY 5m: -$76.04 (-0.76%), PF 0.361, max DD $97.77, eight trades, 50.00% wins;
  SPY 15m: +$27.83 (+0.28%), PF 1.127, max DD $127.98, 24 trades, 62.50% wins.
- Base matrix — QQQ 5m: -$322.62 (-3.23%), PF 0.183, max DD $322.62, 14 trades, 21.43% wins;
  QQQ 15m: -$147.06 (-1.47%), PF 0.694, max DD $344.76, 29 trades, 48.28% wins.
- Decision: `REJECTED`. Three cells lost and both QQQ cells failed sharply. The isolated SPY 15m
  gain is small relative to drawdown and contains 24 trades. No compression threshold, target,
  cost, date, or 1m stress testing was justified.
- Lesson/next: prior-day compression did not make a fixed 10:15 opening-range break transferable.
  Do not tune the compression ratio. Test whether an unusually large first 15-minute candle behaves
  as a short-lived opening shock suitable for structural midpoint reversion.

## 2026-09-06 — TVR-0044 opening-shock midpoint reversion

- Hypothesis: a completed first 15-minute candle spanning 1.00–2.50 of the prior completed 15m
  ATR and closing in its outer quartile may be an opening shock that reverts toward its midpoint.
  Enter once at 09:45 ET, stop 0.10 ATR beyond the shock extreme, target its midpoint, and allow
  90 minutes.
- Source: `strategies/TVR-0044_opening_shock_midpoint_reversion.txt`. Offline Pine analysis found
  zero issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester
  identity `TVR-0044 Opening-Shock Midpoint Reversion` was verified for every accepted result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks
  of slippage, confirmed bar-close processing, no pyramiding, one 09:45 decision per day, completed
  15m ATR, and ET session timing.
- Base matrix — SPY 5m: +$11.00 (+0.11%), PF 1.245, max DD $25.06, 11 trades, 54.55% wins;
  SPY 15m: +$57.73 (+0.58%), PF 1.191, max DD $117.65, 41 trades, 58.54% wins.
- Base matrix — QQQ 5m: +$15.70 (+0.16%), PF 3.563, max DD $13.40, two trades, 50.00% wins;
  QQQ 15m: -$196.10 (-1.96%), PF 0.249, max DD $196.10, 11 trades, 18.18% wins.
- SPY 15m four-tick slippage: +$42.85, PF 1.138, max DD $123.57, 41 trades, 58.54% wins.
- SPY 15m nearby range thresholds 0.90 and 1.10 ATR were numerically unchanged from the default:
  +$57.73, PF 1.191 over 41 trades. Nearby extreme-close fractions 0.70 and 0.80 returned +$84.65/
  PF 1.231 over 50 trades and +$24.63/PF 1.096 over 33 trades, respectively. The neighborhood
  stayed positive but remained modest.
- SPY 15m date segments: January–April -$33.59/PF 0.827 over 23 trades; May–June +$31.54/
  PF 1.549 over eight; July–August +$64.63/PF 2.411 over nine. The full-period gain depends on
  the two later, small positive segments and fails the largest early segment.
- One-minute timing/noise stress: SPY +$4.17 on one winning trade; QQQ zero trades. Neither provides
  usable execution evidence.
- Decision: `REJECTED`. The SPY 15m lead survived costs and nearby thresholds, but failed a major
  date segment and did not transfer to QQQ 15m. Other positive cells are tiny samples. This is a
  regime-specific clue, not a credible candidate, so it does not enter the leaderboard.
- Lesson/next: opening-shock midpoint reversion may have conditional SPY behavior, but the sign
  reversal across ETFs and early-period failure argue against tuning it. Move to a setup whose
  directional context is defined by completed higher-timeframe trend plus intraday rejection,
  while avoiding another opening-range or raw VWAP variant.

## 2026-09-06 — TVR-0045 daily-trend opening rejection

- Hypothesis: when the completed daily close is above/below EMA20, a countertrend first 15-minute
  candle that is rejected through its midpoint during 09:45–10:00 may mark an early failed auction
  and a resumption of the higher-timeframe direction. Enter once at 10:00, stop at the first-candle
  extreme, target 0.65R, and allow 60 minutes.
- Source: `strategies/TVR-0045_daily_trend_opening_rejection.txt`. Offline Pine analysis found zero
  issues; native Pine compiled with zero errors/warnings. Exact chart and Strategy Tester identity
  `TVR-0045 Daily-Trend Opening Rejection` was verified for every accepted result.
- Shared assumptions: $10,000 initial capital, 95% sizing, 0.01% commission per side, two ticks of
  slippage, confirmed bar-close processing, no pyramiding, one trade per day, completed daily data,
  timeframe-invariant 15-minute observation windows, and ET session timing.
- Base matrix — SPY 5m: +$32.59 (+0.33%), PF 2.172, max DD $32.33, six trades, 83.33% wins;
  SPY 15m: +$28.11 (+0.28%), PF 1.123, max DD $156.20, 25 trades, 64.00% wins.
- Base matrix — QQQ 5m: +$57.41 (+0.57%), PF 1.408, max DD $66.23, 11 trades, 63.64% wins;
  QQQ 15m: +$116.39 (+1.16%), PF 1.296, max DD $185.66, 28 trades, 60.71% wins.
- Four-tick slippage — SPY 15m: +$18.27, PF 1.078, max DD $161.60; QQQ 15m: +$104.77,
  PF 1.262, max DD $191.70. Both retained their sign, although SPY expectancy became thin.
- Target neighborhood at 0.55R — SPY 15m +$40.05/PF 1.175; QQQ 15m +$150.35/PF 1.431.
  At 0.75R — SPY 15m +$11.71/PF 1.049; QQQ 15m +$86.05/PF 1.203. The sign survived, but
  SPY's higher-target result was nearly flat.
- Daily-EMA neighborhood — EMA15: SPY 15m +$67.80/PF 1.296 over 26 trades and QQQ 15m
  +$233.24/PF 1.642 over 30. EMA25: SPY 15m +$28.11/PF 1.123 over 25 and QQQ 15m
  +$63.65/PF 1.163 over 27. All remained positive without selecting the best input as a new default.
- Date segmentation — January–April: SPY 15m -$7.49/PF 0.929 over 12 trades and QQQ 15m
  -$46.88/PF 0.780 over 13. May–June: SPY +$14.33/PF 1.151 over eight and QQQ +$77.67/
  PF 1.853 over six. July–August: SPY +$11.58/PF 1.416 over four and QQQ +$74.19/PF 1.828
  over eight. Both ETFs failed the largest early segment; each later cell is small.
- One-minute timing/noise stress — SPY +$4.53 on one winning trade; QQQ -$35.38, PF 0.385,
  max DD $53.96 over four trades with 50.00% wins. These samples do not provide credible execution
  confirmation, and the only nontrivial one is adverse.
- Decision: `REJECTED`. The unusually clean all-positive base matrix and bounded input/cost checks
  are worth preserving, but the edge is concentrated after May, the full-period SPY 15m PF is only
  1.12, and the 1m evidence is sparse/adverse. It does not earn a leaderboard slot.
- Lesson/next: requiring the second 15-minute window to reject the first improved transfer versus
  raw first-candle continuation, but daily EMA context did not stabilize the early-2026 regime.
  The next simple family should retain a fixed-time two-stage pattern while replacing directional
  daily trend with a contemporaneous intraday state such as the first-hour close relative to VWAP
  and opening midpoint, without adding a large filter stack.

## 2026-09-16 — Published-strategy evidence review

- Paused new strategy generation to review original papers and independent replications. Full notes,
  links, evidence ranking, caveats, and the frozen test order are in
  `LITERATURE_REVIEW_2026-09-16.md`.
- Strongest peer-reviewed fit: final-half-hour momentum. Gao et al. (2018) document SPY/ETF
  first-half-hour-to-last-half-hour predictability; Baltussen et al. (2021) document prior-close-
  through-15:30 momentum into the last 30 minutes across more than 60 futures and multiple decades.
- Second peer-reviewed fit: Liu and Tse (2017) find that the overnight return predicts the first
  half hour negatively and the last half hour positively for SPY/US ETFs, in and out of sample.
- The widely circulated SPY noise-area momentum paper reports strong 2007–2024 results, but two
  independent 2026 replications show substantial 2024/2025–2026 decay. It remains worth a faithful
  deep-data replication, not an optimization exercise.
- The QQQ one-minute VWAP working paper has unusually strong headline results but about 22,000
  trades, no credible independent replication located, and large sensitivity to fill assumptions.
  It should be tested only with adequate 1m history and severe cost stress.
- An independent QQQ five-minute ORB replication reproduced the gross result but found break-even
  around $0.022/share slippage and strong 2022 concentration. It is a control, not a lead.
- Research implication: published intraday edges are generally momentum/payoff-asymmetry or
  volatility-regime effects, not high-hit-rate small-target systems. Future promotion must weight
  expectancy and stability above win rate.
- Next: finish TVR-0046 without tuning, then test the two exact closing-momentum rules and the two
  separate overnight-information rules before returning to ad hoc indicator combinations.

## 2026-09-19 — Capped published-strategy baseline session (TVR-0047–TVR-0054)

- Session boundary: eight new candidates, the user-requested cap, were created and tested/attempted
  in about 25 minutes. No ninth candidate, broker action, purchase, publication, automation, or
  parameter search was initiated. All eight complete Pine sources are saved as `.txt` files under
  `strategies/`. Every final source compiled with zero reported errors and was attached with its
  exact TVR name verified in both the chart and Strategy Tester. Temporary cost/date edits to
  TVR-0048 were restored to its saved default source before the next candidate.
- Shared baseline assumptions for TVR-0047–TVR-0050: $10,000 initial capital, 95% equity sizing,
  0.01% commission per side, two ticks of adverse slippage per order, confirmed-bar-close fills,
  and regular-session exits. The 5m chart showed a July–September 2026 visible range, but the
  full executed-trade date span was not independently extracted; 1m exposed August 31–September
  18, 2026. These are short, recent windows and not an
  untouched out-of-sample replication of the published studies. Maximum drawdowns below are
  TradingView's mark-to-market dollar figures; all P&L is underlying-ETF simulation, not options.

### TVR-0047 — Gao first-half-hour signal, 15:30–16:00 exposure

- Source: `strategies/TVR-0047_gao_first_half_hour_last_half_hour.txt`. The 09:30–10:00 return sign
  determines the 15:30 direction; no threshold or filter. SPY 5m: -$96.93, PF 0.665, DD $166.85,
  54 trades. SPY 15m: -$349.90, PF 0.669, DD $472.92, 159 trades. QQQ 5m: -$176.91, PF 0.647,
  DD $190.90, 54 trades. QQQ 15m: -$478.77, PF 0.686, DD $545.59, 158 trades.
- Decision: `REJECTED` for this costed 2026 implementation; four losing cells. A published
  predictive regression is not proof of a costed executable edge in this window.

### TVR-0048 — Baltussen prior-close-to-15:30 signal

- Source: `strategies/TVR-0048_baltussen_prior_close_to_last_half_hour.txt`. Prior completed daily
  close through 15:30 determines the 15:30–16:00 direction. SPY 5m: -$196.53, PF 0.439, DD
  $199.69, 54 trades. SPY 15m: -$479.02, PF 0.573, DD $498.43, 159 trades. QQQ 5m: +$30.34,
  PF 1.078, DD $140.63, 54 trades. QQQ 15m: -$169.53, PF 0.875, DD $348.33, 159 trades.
- The only positive cell, QQQ 5m, fell to +$2.22/PF 1.005/DD $146.09 with four ticks of slippage
  instead of two. Retrospective date splits (not untouched OOS) were July 6–August 14: +$14.83,
  PF 1.055, 30 trades; August 15–September 18: +$15.50, PF 1.129, 24 trades. Neither half is
  convincing relative to costs and drawdown.
- Decision: `REJECTED` as an investable candidate; retain the source/result as a narrow research
  clue, not a leaderboard entry. The original paper studied a broad futures universe, while this
  is a two-ETF translation.

### TVR-0049 and TVR-0050 — Liu–Tse overnight-information legs, kept separate

- Closing continuation source: `strategies/TVR-0049_liu_tse_overnight_gap_close_continuation.txt`.
  Follow the prior-close-to-09:30 gap sign at 15:30; flatten 16:00. SPY 5m: -$102.69, PF 0.661,
  DD $129.01, 54 trades; SPY 15m: -$180.63, PF 0.813, DD $324.29, 159 trades; QQQ 5m:
  -$234.07, PF 0.542, DD $333.15, 54 trades; QQQ 15m: -$43.09, PF 0.967, DD $371.26,
  159 trades. `REJECTED` in the available costed window.
- Opening reversal source: `strategies/TVR-0050_liu_tse_overnight_gap_open_fade.txt`. Fade the
  gap after the first completed bar and exit at 10:00. This is an executable delay, entering at
  09:31 on 1m or 09:35 on 5m, **not** a literal 09:30 fill. SPY 5m: -$149.14, PF 0.648,
  DD $234.88, 54 trades; SPY 1m: -$113.73, PF 0.244, DD $114.38, 14 trades; QQQ 5m:
  -$128.56, PF 0.849, DD $199.18, 54 trades; QQQ 1m: -$12.43, PF 0.912, DD $83.39,
  14 trades. `REJECTED` as tested. One-minute trade counts are too small for a broad claim.

### TVR-0051 — published QQQ one-minute VWAP flip

- Source: `strategies/TVR-0051_qqq_one_minute_vwap_flip.txt`. Follow every confirmed 1m close
  above/below regular-session VWAP, reverse when the close changes side, and flatten at 16:00.
  Position sizing is 100% of $10,000 equity, as in the paper; our 0.01% commission and two-tick
  slippage are deliberately more adverse than its $0.0005/share and zero-slippage assumptions.
  QQQ: -$993.63, PF 0.340, DD $1,044.99, 267 trades; SPY transfer: -$748.17, PF 0.313,
  DD $821.86, 273 trades. The 1m window was August 31–September 18 only.
- Decision: `REJECTED` under the tested costs/window. Hundreds of flips are not hundreds of
  independent market days; the limited history cannot test the paper's 2018–2023 claim.

### TVR-0052 — published QQQ first-five-minute direction ORB

- Source: `strategies/TVR-0052_first_five_minute_direction_orb.txt`. At 09:35, follow the first
  five-minute candle's direction, stop at its opposite extreme, target 10R or close at 16:00,
  risk 1% of equity to the initial stop with a 4x notional cap. This is the published QQQ ORB
  baseline rule, not a later optimized ATR-stop variant. $10,000 initial capital and the common
  two-tick/0.01% costs replace the paper's $25,000/zero-slippage/$0.0005-share assumptions.
  QQQ 5m: -$873.18, PF 0.732, DD $1,077.77, 56 trades; SPY transfer: -$1,148.22,
  PF 0.550, DD $1,172.60, 65 trades. TradingView bar-level stop/target fill ordering remains
  a modeling limitation. `REJECTED` for this window, without tuning the stop or target.

### TVR-0053 and TVR-0054 — noise-area paper rule and one resolution screen

- Faithful one-minute rule source: `strategies/TVR-0053_spy_noise_area_minute_baseline.txt`.
  It uses the prior 14 sessions' **same-minute** absolute session-open-to-minute-close moves, gap-adjusted
  bands, 30-minute decisions, current-band/VWAP exits, 2% daily volatility target capped at 4x,
  and end-of-day flattening. The final source compiled and exact chart/tester identity passed,
  but SPY and QQQ each returned **zero trades** because the exposed 1m history does not leave a
  usable post-warm-up sample. Status `SCREENING` / data-insufficient, not a negative backtest.
- Predeclared resolution-only screen source:
  `strategies/TVR-0054_five_minute_noise_area_screen.txt`. It keeps 14 prior sessions at each
  *five-minute* slot and half-hour decisions, but aggregates VWAP/price bars; it is **not** a
  replication of the one-minute paper. The corrected final source (band/VWAP exit priority)
  compiled and exact chart/tester identity passed. SPY 5m: -$720.74, PF 0.518, DD $1,008.06,
  43 trades; QQQ 5m: -$76.78, PF 0.918, DD $408.39, 24 trades. Status `REJECTED` as a screen.

### Session conclusion and remaining queue

- No candidate earned a new leaderboard slot. The existing seven listed research candidates
  retain their prior provisional/demo status; none is approved for trading. The apparent QQQ 5m
  +$30.34 on TVR-0048 is only 0.30% of initial capital, smaller than its $140.63 drawdown and
  almost erased by two extra ticks; do not call it a successful strategy.
- Exact one-minute noise-area replication still needs a materially longer, quality-checked
  1m history and a genuinely untouched later period. All eight new tests lack a convincing
  out-of-sample evaluation. TVR-0046's previously queued matrix also remains unfinished;
  it was not silently counted as completed. No further candidates were started because the
  user-set eight-candidate cap was reached.
- Source rules verified against the authors' papers:
  [SPY noise-area](https://concretumgroup.com/wp-content/uploads/2026/02/Beat-the-Market.pdf),
  [QQQ one-minute VWAP](https://concretumgroup.com/wp-content/uploads/2026/02/Volume-Weighted-Average-Price.pdf),
  and [QQQ five-minute ORB](https://concretumgroup.com/wp-content/uploads/2026/02/Can-Day-Trading-Really-Be-Profitable.pdf).

## 2026-09-19 — Two-hour VWAP/opening-structure session, TVR-0046 completion

- Frozen session plan: `SESSION_PLAN_2026-09-19_B.md`. Research clock began 12:46:09 UTC;
  the 120-minute deadline is 14:46:09 UTC. The signed-in desktop's `tests` layout was
  used after the existing `ETFs` layout hit the plan's five-indicator limit. The prior
  TVR-0027 study was removed from the `tests` chart before testing so Strategy Tester
  identity could not silently refer to it. No plan upgrade or broker action occurred.
- Source: `strategies/TVR-0046_opening_reversal_vwap_confirmation.txt` (unchanged
  saved version). Pine compiled without reported errors. The chart and Strategy Tester
  both named `TVR-0046 Opening Reversal VWAP Confirmation` for every accepted cell.
  Underlying ETF share simulation: $10,000 start, 95% equity sizing, 0.01% commission
  per side, two ticks slippage per order, no pyramiding, bar-close processing.
- Native base matrix: SPY 5m +$11.07 (+0.11%), PF 1.161, mark-to-market DD $60.67,
  12 trades, 66.7% wins, +$0.92/trade; SPY 15m -$7.36 (-0.07%), PF 0.981,
  DD $151.09, 41 trades, 58.5% wins, -$0.18/trade. QQQ 5m +$92.89 (+0.93%),
  PF 1.664, DD $101.52, 15 trades, 66.7% wins, +$6.19/trade. QQQ 15m +$95.58
  (+0.96%), PF 1.144, DD $234.04, 46 trades, 56.5% wins, +$2.08/trade.
- Four-tick slippage stress: QQQ 5m +$87.67, PF 1.615, DD $104.38, 15 trades;
  QQQ 15m +$77.02, PF 1.114, DD $241.40, 46 trades. The temporary edit was
  restored to the saved two-tick source, recompiled, and QQQ 15m rechecked at its
  original +$95.58/PF 1.144. QQQ 15m tester displayed Feb 2–Sep 18, 2026;
  exact 5m trade dates and an untouched out-of-sample period were not verified.
- Decision: `REJECTED` as an investable candidate, with the source retained. The
  QQQ 5m lead has only 15 trades; the longer QQQ 15m cell earns less than half its
  drawdown with PF 1.14; SPY 15m loses. Compared with TVR-0045's preexisting
  QQQ 15m +$116.39/PF 1.296/DD $185.66 over 28 trades, adding the VWAP condition
  did not establish a stronger cross-symbol or chronology-stable edge. No rank change.

### TVR-0055 — failed-auction/VWAP reclaim without the hourly EMA filter

- Predeclared controlled ablation of TVR-0030; complete source:
  `strategies/TVR-0055_failed_auction_no_hour_filter.txt`. The opening-range failed sweep,
  close back inside the range, VWAP cross within three bars, one trade/day, frozen 0.50 ATR
  stop, 0.60 ATR target, eight-bar maximum hold, and all baseline costs remained fixed.
  Only the completed-hour EMA alignment gate was removed. Native Pine compilation reported
  no errors; chart and tester both named TVR-0055 for every accepted cell.
- Two-tick base matrix on $10,000, 95% equity sizing, 0.01% commission per side:
  TradingView tester displayed Feb 2–Sep 18, 2026 for both 15m symbols and
  Jul 6–Sep 18, 2026 for both 5m symbols; their unequal histories limit
  direct cross-timeframe comparison.
  QQQ 15m +$360.50 (+3.60%), PF 1.608, mark-to-market DD $124.10, 75 trades,
  61.3% wins; SPY 15m +$192.94 (+1.93%), PF 1.491, DD $107.71, 69 trades,
  60.9% wins. QQQ 5m -$69.55 (-0.70%), PF 0.479, DD $85.69, 17 trades;
  SPY 5m +$6.28 (+0.06%), PF 1.082, DD $33.86, 28 trades.
- Four-tick slippage (same 15m rules): QQQ +$331.76, PF 1.544, DD $128.62,
  75 trades; SPY +$168.16, PF 1.413, DD $110.23, 69 trades. Both remain positive,
  though these are equity-share simulations, not option returns or live-fill guarantees.
- Retrospective independent-capital date windows (not untouched out-of-sample):
  Feb–Apr 2026 QQQ +$91.74/PF 1.415/25 and SPY +$95.95/PF 1.538/28;
  May–Jun QQQ +$234.31/PF 2.412/23 and SPY +$68.65/PF 1.542/20;
  Jul–Sep 19 QQQ +$29.42/PF 1.144/27 and SPY +$27.04/PF 1.335/21.
  The latest QQQ window has a slim edge; splitting/restarting equity means window totals
  need not exactly sum to the full-history compounded result.
- Nearby *target-only* check at 0.55/0.65 ATR around frozen 0.60: QQQ 15m
  +$331.71/PF 1.559 and +$388.36/PF 1.653; SPY 15m +$178.83/PF 1.455 and
  +$179.07/PF 1.438. Trade counts stayed at 75/69 respectively. Baseline source was
  restored in the editor and SPY 15m reverified at +$192.94/PF 1.491.
- Decision: `SCREENING`, not a promoted finalist. The cross-symbol 15m signal survives
  cost and one nearby parameter check, but 5m transfer fails/flat, the recent 15m period
  is weak, these date slices were examined after seeing aggregate results, and there is
  no genuinely untouched future test or independently quality-checked data feed.
- Additional recent-window cost stress (Jul 1–Sep 19 end, four ticks): QQQ 15m
  +$19.24/PF 1.091/DD $97.38/27 and SPY 15m +$20.08/PF 1.237/DD $54.36/21.
  This makes the newest part of the apparent edge especially fragile. The normal
  saved two-sided/two-tick script was restored and reverified afterward.
- Diagnostic side-only runs on the full 15m history (not promoted as new variants):
  QQQ long-only +$277.00/PF 2.178/DD $57.67/42, QQQ short-only +$66.46/PF 1.157/
  DD $156.55/39; SPY long-only +$53.91/PF 1.198/DD $130.34/43, SPY short-only
  +$108.92/PF 1.521/DD $105.80/37. The dominant side differs by symbol.
  Side-only counts/P&L are not additive to two-sided because skipping one side lets
  another signal occur later in a one-trade-per-day system. No side was selected for
  deployment after seeing these results.
- Contemporaneous TVR-0030 baseline rerun with the same desktop data and exact
  study/tester identity: QQQ 15m +$105.63/PF 1.586/DD $73.75/24;
  SPY 15m -$10.90/PF 0.947/DD $101.55/30; QQQ 5m -$12.38/PF 0.671/
  DD $41.58/six; SPY 5m +$33.00/PF 2.170/DD $16.86/14. Removing the hour gate
  improved both full-history 15m cells but not the short-history 5m cells. A source
  diff confirmed the removed hourly series/gate was the only behavioral change.

### TVR-0056 — completed-hour Kijun in place of the EMA gate

- Source: `strategies/TVR-0056_failed_auction_hourly_kijun.txt`. Predeclared one-filter
  replacement on TVR-0030. Pine compiled without errors or warnings and the chart/tester
  both identified TVR-0056. Same $10,000/95%/0.01%-per-side/two-tick assumptions.
- QQQ 15m +$120.51, PF 1.629, MTM DD $73.75, 27 trades; SPY 15m -$20.68,
  PF 0.891, DD $80.21, 30 trades. QQQ 5m -$12.38, PF 0.671, DD $41.58,
  six trades; SPY 5m +$12.80, PF 1.368, DD $19.12, 14 trades.
- Decision: `REJECTED` as a replacement for TVR-0030/TVR-0055. It cuts the sample sharply
  and loses on SPY 15m and QQQ 5m; no cost/parameter escalation warranted.

### TVR-0057 — high-volume failed opening-range sweep

- Source: `strategies/TVR-0057_failed_auction_sweep_volume.txt`. Predeclared gate:
  failed-sweep bar volume at least 1.5 times the prior 20-bar average, with the TVR-0030
  hourly trend, VWAP-reclaim entry, exits, and costs unchanged. Pine compiled without
  errors or warnings; chart/tester identity verified for all four cells.
- QQQ 15m +$141.19, PF 2.061, MTM DD $46.34, 22 trades; SPY 15m -$9.42,
  PF 0.952, DD $110.07, 28 trades. QQQ 5m -$12.38, PF 0.671, DD $41.58,
  six trades; SPY 5m +$43.29, PF 7.624, DD $10.50, only nine trades.
- Decision: `REJECTED` as an investable lead. QQQ 15m and SPY 5m look attractive in
  isolation, but two other cells lose and the favorable 5m cell has nine trades. Do
  not optimize the volume threshold around those sparse observations.

### TVR-0058 — 10:15 post-opening-range/VWAP acceptance

- Source: `strategies/TVR-0058_post_opening_or_vwap_acceptance.txt`. Predeclared 10:15
  close outside the frozen 09:30–10:00 range, same-side RTH VWAP and completed-hour
  EMA trend; opening-range midpoint stop, 1R target, 60-minute maximum hold. Pine
  compiled without errors or warnings; exact chart/tester identity verified.
- QQQ 15m +$24.05, PF 1.053, MTM DD $236.05, 35 trades; SPY 15m +$132.87,
  PF 1.699, DD $73.97, 36 trades. QQQ 5m -$111.13, PF 0.557, DD $197.80,
  12 trades; SPY 5m +$22.58, PF 1.306, DD $73.97, 12 trades. Common capital,
  sizing, commission, and slippage rules applied.
- Decision: `REJECTED` as a robust multi-symbol lead. QQQ 15m barely clears costs
  against nearly ten times its net return in drawdown; QQQ 5m loses and the 5m
  samples are sparse. SPY 15m alone does not justify promotion.

### TVR-0059 — opening-range breakout then boundary retest

- Source: `strategies/TVR-0059_opening_range_breakout_retest.txt`. Predeclared first
  confirmed 10:00–10:30 ET break of the frozen 09:30–10:00 range; a *later* bar through
  11:00 must touch and reclaim the broken boundary with VWAP/completed-hour agreement.
  Stop at retest-bar extreme, 1R target, 60-minute maximum hold. Pine compiled without
  errors or warnings; exact chart/tester identity verified.
- QQQ 15m -$10.89, PF 0.953, MTM DD $86.62, 24 trades; SPY 15m -$70.72,
  PF 0.555, DD $91.55, 23 trades. QQQ 5m -$2.51, PF 0.970, DD $53.62,
  11 trades; SPY 5m -$38.54, PF 0.212, DD $45.63, nine trades.
- Decision: `REJECTED` in all four costed cells. No cost or parameter escalation.

### Batch checkpoint

- All six frozen hypotheses in `SESSION_PLAN_2026-09-19_B.md` have now been attempted
  and, where a native matrix was appropriate, checked on both symbols and both primary
  timeframes. Only TVR-0055 warrants additional research, and it remains `SCREENING`;
  none is approved for live use. The stronger 15m history and the much shorter 5m
  chart histories are not directly comparable as if they contained the same dates.

### Critical order-timing correction: TVR-0060 through TVR-0066

- The preceding checkpoint was **superseded** after an implementation audit. In
  TVR-0046 and TVR-0055–0059 (and their TVR-0030 ancestor), `strategy.exit` was
  inside `if strategy.position_size > 0/< 0` and the scripts did not enable
  `calc_on_order_fills`. Pine's default once-per-bar calculation means the just-filled
  position was not visible to that condition until the next bar close. Thus the
  protective stop/target was not submitted with the entry. The earlier figures remain
  reproducible *delayed-bracket* diagnostics, **not** valid intended-risk backtests.
- For each corrected script, `strategy.exit` now also runs immediately after the
  corresponding `strategy.entry` using the already-frozen stop/target prices; the
  existing subsequent exit update remains. Originals were preserved unchanged;
  complete corrected sources are `strategies/TVR-0060_immediate_bracket_no_hour_filter.txt`
  through `strategies/TVR-0066_immediate_bracket_opening_reversal.txt`. All seven
  corrected sources passed Pine compilation with zero errors/warnings and were
  attached with exact chart/tester identity in each accepted cell. Assumptions remain
  $10,000, 95% equity, 0.01% commission per side, two-tick slippage, bar-close entry.
- Corrected base matrices (QQQ 15m / SPY 15m / QQQ 5m / SPY 5m; dollar net, PF,
  TradingView MTM drawdown, trades):
  - TVR-0060 (TVR-0055 fix): -$34.85 / 0.932 / $130.68 / 75;
    +$72.64 / 1.280 / $51.89 / 69; -$76.96 / 0.365 / $86.04 / 17;
    -$22.88 / 0.695 / $33.67 / 28. TVR-0055's prior +$360.50 QQQ 15m
    and +$192.94 SPY 15m no longer describe the intended bracketed strategy.
  - TVR-0061 (TVR-0030 fix): -$78.01 / 0.599 / $92.86 / 24;
    -$67.86 / 0.593 / $79.68 / 30; -$46.44 / 0.190 / $48.50 / six;
    +$9.01 / 1.307 / $19.50 / 14. The former rank-4 TVR-0030 lead is withdrawn.
  - TVR-0062 (TVR-0056 fix): -$71.98 / 0.657 / $98.17 / 27;
    -$63.01 / 0.602 / $75.96 / 30; -$46.44 / 0.190 / $48.50 / six;
    -$2.56 / 0.928 / $24.15 / 14. All four corrected cells lost.
  - TVR-0063 (TVR-0057 fix): -$70.28 / 0.599 / $85.12 / 22;
    -$67.35 / 0.570 / $88.09 / 28; -$47.09 / 0.187 / $48.50 / six;
    +$12.09 / 1.873 / $11.46 / nine. Three lose; the positive nine-trade
    SPY 5m cell is too sparse.
  - TVR-0064 (TVR-0058 fix): -$10.58 / 0.977 / $236.65 / 35;
    +$132.39 / 1.697 / $73.97 / 36; -$111.13 / 0.557 / $197.80 / 12;
    +$22.58 / 1.306 / $73.97 / 12. SPY 15m is the best corrected single cell,
    but QQQ transfer fails.
  - TVR-0065 (TVR-0059 fix): -$9.70 / 0.949 / $82.82 / 24;
    -$20.26 / 0.790 / $50.38 / 23; -$50.50 / 0.430 / $62.57 / 11;
    -$35.30 / 0.226 / $37.24 / nine. All four corrected cells lost.
  - TVR-0066 (TVR-0046 fix): +$32.75 / 1.059 / $195.97 / 46;
    -$141.02 / 0.635 / $176.55 / 41; +$83.53 / 1.597 / $106.72 / 15;
    -$9.22 / 0.890 / $80.95 / 12. Positive QQQ cells are too small/weak
    versus drawdown and SPY fails.
- TVR-0064 SPY 15m additional checks: four-tick slippage +$116.65, PF 1.587,
  DD $76.37, 36 trades, +$3.24 per trade. Retrospective windows at two ticks:
  Feb–Apr +$115.74/PF 2.927/15; May–Jun -$21.64/PF 0.607/eight;
  Jul–Sep +$37.82/PF 1.513/13. The earliest slice accounts for most of
  the aggregate gain; later samples are sparse. This is `SCREENING` only,
  **not** a finalist or a reason to buy a TradingView plan.
- Rank audit: TVR-0022, TVR-0009, TVR-0016, and TVR-0018 also gate
  stop/target submission on `strategy.position_size` without fill recalculation;
  their old leaderboard P&L is now suspended pending separate corrected retests.
  TVR-0030 is specifically refuted by TVR-0061 and removed from active ranks.
  TVR-0001 (daily no-bracket demo) and TVR-0002 (signal-exit-only research
  script) do not have this exact bracket-delay mechanism, but neither is a
  live-ready intraday system. No current intraday rank is a validated winner.

### Entry-protection retests of four previously ranked scripts: TVR-0067–0070

- The original TVR-0022/0009/0016/0018 sources used an exit based on
  `strategy.position_avg_price` only after `strategy.position_size` became nonzero.
  Their corrected versions submit an initial protective order at the signal-bar
  close using `close ± ATR distance`, then keep the original adaptive exit update
  on subsequent bars. This first-bar protection is a necessary implementation
  translation, not an identical replay of the old result. Originals remain intact.
  Complete sources: `strategies/TVR-0067_entry_protected_early_failed_auction.txt`,
  `strategies/TVR-0068_entry_protected_afternoon_fade.txt`,
  `strategies/TVR-0069_entry_protected_gap_orb.txt`, and
  `strategies/TVR-0070_entry_protected_volume_vwap.txt`. All compiled without
  errors/warnings and passed exact chart/tester identity on the native matrix.
- Corrected base matrix below is QQQ 15m / SPY 15m / QQQ 5m / SPY 5m, with
  net dollars, PF, TradingView MTM drawdown, and completed trades. Costs remain
  $10,000/95% equity/0.01% per side/two ticks.
  - TVR-0067 (TVR-0022 fix): +$250.07/2.325/$55.96/24;
    -$53.07/0.802/$96.62/30; -$96.48/0.000/$96.48/six;
    +$4.21/1.058/$33.43/14. The QQQ 15m lead is narrow; other transfer fails.
  - TVR-0068 (TVR-0009 fix): +$206.42/1.445/$148.08/45;
    -$65.92/0.859/$140.40/54; +$33.19/1.370/$33.62/13;
    -$5.02/0.947/$36.90/21. QQQ-only mixed-resolution lead.
  - TVR-0069 (TVR-0016 fix): -$6.00/0.983/$102.66/27;
    -$84.76/0.665/$84.76/28; -$3.24/0.941/$32.94/five;
    -$4.71/0.908/$34.58/10. All four cells lost; `REJECTED`.
  - TVR-0070 (TVR-0018 fix): +$74.54/1.122/$164.33/57;
    -$130.28/0.749/$241.47/63; +$83.57/2.642/$41.81/10;
    +$18.49/1.471/$21.43/10. The 5m leads have only ten trades
    each, while 15m transfer is poor; no promotion.
- TVR-0067 QQQ 15m four-tick stress remained +$244.37, PF 2.264,
  DD $57.26 over 24 trades. Retrospective two-tick date windows:
  Feb–Apr +$37.30/PF 1.954/five; May–Jun +$179.45/PF 3.852/nine;
  Jul–Sep +$33.31/PF 1.384/10. The latest window is weak and the
  strong middle window dominates; all windows are small and not untouched
  out-of-sample. `SCREENING`, no rank restoration or live approval.
- Further execution caveat for TVR-0067 and other legacy scripts: the source
  has a maximum bar hold but no explicit regular-session forced flatten.
  Depending on chart session settings and entry time, a position could remain
  past the intended day-trading session. An explicitly EOD-flat version and
  trade-timestamp audit are required before considering its QQQ 15m lead.
- Outcome: the corrected QQQ 15m TVR-0067 is the strongest new numerical
  clue, but no robust cross-symbol/timeframe strategy was established.
- TVR-0068 QQQ 15m follow-up: four-tick slippage +$185.96, PF 1.393,
  MTM DD $154.38, 45 trades. Retrospective two-tick windows: Feb–Apr
  +$3.43/PF 1.014/23, May–Jun +$232.25/PF 2.908/13, Jul–Sep
  -$29.26/PF 0.704/nine. Its middle window exceeds the full-history
  profit and the latest window loses; this is not chronology-stable.
  The saved two-tick source was restored and QQQ 15m +$206.42/PF 1.445
  reverified. No rank restoration.

## 2026-09-19 — TVR-0071 EOD-flat implementation audit

- Frozen comparison: `SESSION_PLAN_2026-09-19_C.md`. Complete source:
  `strategies/TVR-0071_eod_flat_early_failed_auction.txt`. Only the EOD
  close condition and a non-trading diagnostic counter were added to TVR-0067.
  The existing signal, same-bar protective order, subsequent exit updates,
  sizing, commission, slippage, and other parameters were unchanged.
- The desktop MCP connected to the signed-in chart. Offline Pine analysis found
  zero issues. Native Pine compilation reported no errors, added the study,
  and exact chart/Strategy Tester identity was checked in each of four cells.
- QQQ 15m: +$250.07, PF 2.325, TradingView MTM DD $55.96, 24 trades;
  SPY 15m: -$53.07, PF 0.802, DD $96.62, 30 trades. These exactly match
  TVR-0067 on the same charts.
- QQQ 5m: -$96.48, PF 0.000, DD $96.48, six trades; SPY 5m: +$4.21,
  PF 1.058, DD $33.43, 14 trades. These also match the corrected baseline.
- The script's `EOD close requests` data-window counter was zero at the end
  of all four tested histories. Thus no observed position survived until the
  new flatten condition on these charts; the unchanged P&L does **not** prove
  the rule would execute correctly during a future late or early-close trade.
- Decision: `SCREENING`, unranked. The EOD guard is a worthwhile implementation
  safeguard but contributed no measured return. The QQQ 15m signal remains a
  narrow, non-OOS ETF-share clue, not a validated option edge. No parameter
  tuning, option-P&L translation, broker action, purchase, or scheduler change.

## 2026-09-19 — TVR-0072 frozen entry bracket

- Frozen hypothesis and matrix: `SESSION_PLAN_2026-09-19_D.md`. Complete source:
  `strategies/TVR-0072_frozen_bracket_early_failed_auction.txt`. Relative to
  TVR-0071, only the post-entry ATR stop/target updates changed: initial
  entry-close ATR levels are now retained until exit. Entries, day flatten,
  capital/sizing, 0.01% commission per side, and two-tick slippage did not change.
- Pine compiled with no reported errors. The MCP `batch_run` wrapper marked four
  iterations successful while each nested result said `Strategy Tester not found`;
  those batch results were discarded. Individual chart/tester calls then returned
  the intended TVR-0072 strategy identity on each symbol/timeframe.
- QQQ 15m: +$248.78, PF 2.301, TradingView MTM DD $56.61, 24 trades
  (TVR-0071 +$250.07, PF 2.325, DD $55.96, 24). SPY 15m: -$86.53,
  PF 0.701, DD $133.08, 30 trades (TVR-0071 -$53.07, PF 0.802,
  DD $96.62, 30).
- QQQ 5m: -$98.43, PF 0.000, DD $98.43, six trades
  (TVR-0071 -$96.48, six). SPY 5m: +$6.01, PF 1.085,
  DD $34.27, 14 trades (TVR-0071 +$4.21, 14).
- Decision: `REJECTED` as an improvement. Freezing exits barely affects the
  narrow QQQ 15m result and worsens SPY 15m materially; QQQ 5m remains all
  losing trades. Keep the source as a reproducible negative control, not a
  promoted strategy. No extra parameter search, OOS claim, option-P&L
  translation, live trade, purchase, or scheduler change.
- QQQ 15m trade-timing audit: the MCP order-list response exposed only the
  newest 20 of 48 orders and no timestamps, so it could not establish
  same-day exits. TradingView Desktop's visible `List of trades` supplied
  entry and exit date/time for all 24 completed trades. Every entry and exit
  occurred on the same displayed date. Entries ranged 10:00–11:45, the
  latest exit was 15:15, and the longest displayed hold was 270 minutes.
  First listed trade was March 10 and last September 11, 2026. Thus the
  observed QQQ 15m sample had no overnight hold; this does not prove the
  EOD rule will execute correctly on future late entries or early closes.

## 2026-09-19 — TVR-0073 corrected completed-hour VWAP reclaim

- Frozen hypothesis and matrix: `SESSION_PLAN_2026-09-19_E.md`. Full source:
  `strategies/TVR-0073_entry_protected_completed_hour_vwap_reclaim.txt`.
  This is a corrected implementation screen of the old TVR-0005 concept,
  not a newly optimized indicator stack. It uses completed hourly EMA20/50
  values, submits a frozen 1.10/1.80 ATR bracket with entry, and requests
  a 15:45 ET flatten. The original VWAP reclaim and 0.80 relative-volume
  threshold were retained. Share sizing/costs: $10,000, 95% equity,
  0.01% commission per side, two-tick slippage.
- The first `pine_set_source` call could not open the closed editor;
  `pine_new(strategy)` opened it, source injection succeeded, and native
  compilation reported zero errors. Individual chart state and Strategy
  Tester identity were verified for all four accepted cells.
- Matrix (net dollars / PF / TradingView mark-to-market drawdown / trades):
  QQQ 15m -$14.75 / 0.982 / $221.40 / 61;
  SPY 15m -$412.32 / 0.517 / $476.75 / 73;
  QQQ 5m -$50.45 / 0.814 / $97.40 / 29;
  SPY 5m -$78.93 / 0.665 / $143.59 / 33.
- Decision: `REJECTED` as an improvement. Every costed cell lost. The
  old TVR-0005 QQQ-positive figures are not a valid immediate-protection,
  completed-hour comparison. Because the corrected source also changes
  hourly signal availability, the P&L difference is not attributed solely
  to the bracket timing. Do not tune volume, EMA, bracket, or entry hour
  around these outcomes. The 5m and 15m chart histories differ; this is
  an underlying ETF-share screen, not historical option bid/ask P&L.

## 2026-09-28 — Supplied-video 9 EMA / VWAP cross: TVR-0074–0078

- Source extraction: the supplied 33.6-second video showed an SLV 3-minute chart and an indicator
  titled `9EMA/VWAP X`. Visible inputs defined bullish `EMA > VWAP`, bearish `EMA < VWAP`, and a
  09:30–16:00 session filter. Narration said to enter when the candle breaks through VWAP and exit
  when a candle closes through the EMA. The on-screen marketing P&L card was not treated as
  performance evidence. Exact interpretation and the bounded experiment ladder were frozen in
  `SESSION_PLAN_2026-09-28_A.md` before the first TradingView result.
- TradingView Desktop was relaunched through its current Windows CDP mechanism. All five saved
  Pine v6 sources compiled natively with no final errors or warnings. Tests used SPY/QQQ 3-minute
  regular-session bars, $10,000 initial capital, 95% equity share sizing, 0.01% commission per
  side, two ticks adverse slippage, bar-close processing, and an explicit end-of-day flatten.
- TVR-0074 faithful visible-indicator interpretation (EMA9 crosses session VWAP; price closes
  through EMA9 to exit): SPY -$459.57, PF 0.323, MTM DD $477.39, 129 trades, 24.03% wins;
  QQQ -$639.18, PF 0.390, DD $651.79, 121 trades, 25.62% wins. `REJECTED`.
- TVR-0075 literal narration interpretation (completed candle crosses VWAP with EMA9 aligned;
  same EMA9 exit): SPY -$362.86, PF 0.375, DD $378.24, 118 trades, 22.03% wins;
  QQQ -$336.53, PF 0.574, DD $348.12, 110 trades, 26.36% wins. `REJECTED`.
- TVR-0076 predeclared anti-chop test (TVR-0074 plus completed 15-minute EMA20/EMA50 direction
  and no entry in the first 15 minutes): SPY -$159.94, PF 0.483, DD $196.43, 62 trades,
  24.19% wins; QQQ -$58.92, PF 0.827, DD $67.37, 57 trades, 31.58% wins. Filtering reduced
  churn and loss but did not create positive expectancy. `REJECTED`.
- Direction attribution on unchanged TVR-0076 rules: TVR-0077 QQQ long-only +$25.42, PF 1.138,
  DD $51.51, 29 trades, 34.48% wins, but SPY long-only -$27.48, PF 0.800, DD $65.99,
  29 trades. TVR-0078 QQQ short-only -$81.00, PF 0.487, DD $99.79, 28 trades.
  The QQQ long result is only $0.88 average per trade, fails SPY transfer, and is too small
  relative to drawdown to retain as a candidate. No doubled-slippage or chronology test was
  permitted by the predeclared gate.
- Outcome: none enters the leaderboard. The simple video idea behaves as a high-churn crossover
  on SPY/QQQ in the available TradingView sample. These are ETF-share simulations, not option
  bid/ask backtests and not evidence about the video's claimed alert-service P&L. No live order,
  scheduler, core policy, purchase, or option-strategy setting changed.

## 2026-09-29 — TVI-0001 Volume-Weighted Ichimoku Cloud prototype

- Created a non-strategy Pine v6 indicator at
  `indicators/TVI-0001_volume_weighted_ichimoku_cloud.txt` and documented its definition in
  `INDICATORS.md`. It retains the 9/26/52 Ichimoku horizons and 26-bar displacement, but replaces
  each classic range midpoint with a rolling volume-weighted price center using HLC3 by default.
- Volume leading span A is the average of the 9-bar and 26-bar VWMAs; volume leading span B is the
  52-bar VWMA. The indicator includes conversion/base lines, a colored displaced cloud, an optional
  volume-weighted lagging span, an optional classic-cloud comparison, relative volume in the data
  window, and alerts for conversion/base crosses and cloud flips.
- Native TradingView server compilation passed with zero errors and zero warnings. Static analysis
  found zero issues. The indicator was attached to QQQ 5m and exposed expected live data-window
  values under the exact `TVI-0001 Volume-Weighted Ichimoku Cloud` identity.
- Status: `PROTOTYPE`. This is not canonical Ichimoku, a strategy, a backtest result, an entry/exit
  rule, or evidence of profitability. No leaderboard, live-trading, scheduler, broker, or core
  policy change was made.

## 2026-10-01 — TVI-0002 saved and TVR-0079 bounded comparison

The range-extreme volume-weighted cloud TVI-0002 was saved separately and its
native chart identity verified. It retains 9/26/52 ranges and 26-bar displacement,
weights endpoint prices by the volumes of their establishing bars, and leaves
the standard close-based lagging span optional/off. This is not a price-level
volume profile or a proven trading edge.

Frozen eight-cell RTH strategy comparison completed: QQQ 5m classic/weighted
+$129.25/-$317.01 (103/123 trades); SPY 5m -$377.71/-$321.43 (102/123);
QQQ 15m -$29.18/-$594.88 (72/136); SPY 15m -$42.84/-$219.52 (64/139).
Costs: $10K, 95% shares, 0.01% per side, two ticks. All weighted cells negative:
REJECTED as a strategy, no leaderboard promotion or conditional rescue tests.
Full raw metrics/settings/history exclusions and independent source-review
caveats are saved in `results/TVR-0079_2026-10-01.json` and matching `.md`.
Source compiled with zero errors/warnings and Tester identity was verified.
Holdout exclusion was source/input verified, not independently trade-date audited.
Early-close last-bar entry/flatten remains a deployment blocker. The original
saved cloud was restored after an MCP saved-identity pitfall; both cloud and
strategy now have verified separate saved identities. No live order or core change.
 
## 2026-10-01 — TVR-0080 instrumented VWAP timing audit

Frozen plan SESSION_PLAN_2026-10-01_B.md; same0071 entries/orders with JanSep
bounds and display-only full trade diagnostics. Eight native RTH cells:
QQQ15 +$247.66/36/DD86.95, SPY15 -$16.96/42/DD127.52,
QQQ5 +$89.21/25/DD123.42, SPY5 +$13.78/31/DD69.62.
QQQ15/5 four-tick costs +$239.17/+$84.96. QQQ15 JanJun +$189.42/25,
JulSep +$59.80/11. $10K/95% shares/.01% per side/two ticks baseline.

Complete timestamp exports reconcile counts/net; no overnight, out-of-window
entry or exit bar close after15:45. Entry/exit times label bars, not precise
intrabar fills: exported bar-close timestamps disambiguate close entries.
Early-close/final-regular-bar exits not exercised; ATR stop can widen original
risk. SCREENING only, no promotion or options-P&L inference. Broader RTH
coverage differs from old mixed-session data; no causal profit lift claimed.

All source, exact inputs/metrics/trades and reproducible PowerShell audit are
in results/TVR-0080_2026-10-01.{md,json}, strategies/TVR-0080_instrumented_failed_auction.txt
and tools/audit_native_trade_tables.ps1. Compiler const-default failure and
double-subtracted diagnostic commission were corrected before accepted export;
initial unrelated Tester metrics excluded. Server compile zeroerrors/warnings;
native last-bar advisory nonfatal. Original user cloud and0079 saved sources
preserved using native copy before edit. Two bounded agents, eight cells,
about15minutes; monetary/subscription usage unmeasured. No broker, scheduler,
purchase or core-policy changes. Next: frozen-risk/early-close-safe VWAP variant.

## October 3 — user-requested quick VWAP / EMA27 / momentum Pine test

Frozen TVR-0082/0083 rules in SESSION_PLAN_2026-10-03_A.md. User narrowed work to quick chart strategy backtest and clarified intended role as final filter after Python options qualification. Four accepted 5m RTH cells, actual March30–September30 coverage: momentum SPY -$787.85/281/PF0.692, QQQ -$1,142.41/285/PF0.707; confirmed RSI-or-MACD divergence SPY -$358.12/78/PF0.345, QQQ -$291.97/62/PF0.603. Both standalone candidates rejected; conditional pipeline role untested. No tuning or promotion.

Entry-only EMA27 plus VWAP and two MACD histogram changes; divergence pivots3/3 confirmed prospectively. VWAP/time exits, three entries/day, daily realized-net-green latch. $10K/95% shares, .01% commission/side, two-tick slippage. Not option P&L. Both complete sources compiled with zero server errors/warnings. Native chart/Tester identity verified; full trades retained, net/counts reconciled, no overnight/out-of-window/late exits or post-green entries. July2 early close exercised in base only. Initial ETH indicator runs and incidental3m state discarded. Existing saved0081 preserved by native copies. Raw results, coverage, assumptions and complete trade ledgers: results/TVR-0082_0083_2026-10-03.{md,json}. Core configuration, options ledgers, broker and scheduler unchanged.

## October3 goal research batches B/C

[account details redacted]

Complete sources/native copies, all metrics including descriptive CAGR, raw performance/inputs and full trade audits retained in results/TVR-0084_0087_2026-10-03.{md,json}; all14counts/net reconcile, no overnight/out-of-window/late/post-green entries. Actual historical coverage March30–Sep30, October reserved. Native OHLC bracket fill ordering not independently tick-verified; no options P&L inference. Asked Sol6.1 question answered with official docs and read-only usage8/20Oct2,3%weekly; no model switch. Goal remains active; next explicit event-entry test predeclared before results. No broker, scheduler, production policy or paper-ledger mutation.

October3 batch D: TVR-0088 one entry per divergence QQQ+$26.05/57/PF1.046,SPY-$127.58/68. TVR-0089 adds a post-confirmation VWAP reclaim: QQQ+$38.64/37/PF1.110,SPY-$64.97/49;QQQ4ticks+$24.07, earlier+$63.87/16,later-$26.35/21. Reclaim ages2/3/4 identical, no independent confirmation. Both REJECTED for weak/period-dependent transfer; all nine native ledgers pass net/count/timing/daily-green audit. Complete sources, native saved copies, metrics and evidence: results/TVR-0088_0089_2026-10-03.{md,json}, frozen plan SESSION_PLAN_2026-10-03_D.md. October unopened; research goal ACTIVE; no operational changes.

October3 batch E: hidden-divergence continuation0090 QQQ-$7.44/157,SPY-$205.18/158; earlier momentum0091 QQQ+$57.35/164/PF1.042,SPY-$168.26/159. Full-period Sharpe/Sortino negative; both REJECTED. No PF>=1.2 positive lead, no further parameter tests triggered. Four full native ledgers pass net/count/identity/cost/fill/timing/daily-green checks. QQQ0091 shorts+$219.37/57 versus longs-$162.03/107 is posthoc diagnostic, not validated short-only strategy. Complete sources/native copies/metrics/trades: results/TVR-0090_0091_2026-10-03.{md,json}; frozen planE. Next priority broader historical coverage/defensible validation before more same-sample variants. October unopened; goal ACTIVE; no operational changes.

October3 F/data expansion: found0082–0091 research sources incorrectly shorten July2,2026 to13:00; Alpaca/TradingView/installed NYSE calendar confirm16:00. TVR-0092 corrects calendar only, supports2025/2026earlycloses; nativeQQQ+$38.64/37 andSPY-$64.97/49 exactly match0089 complete ledgers/metrics. REJECTED, no promotion. Prior histories preserved with calendar-defect annotation; old lack ofJuly2trades alone was not enough to assert no effect. Raw/corrected sources/results: SESSION_PLAN_2026-10-03_F.md, results/TVR-0092_2026-10-03.{md,json}.

Historical expansion:14 saved SIPsymbol-months (Jan–Jun2025SPY/QQQ andSep2026SPY/QQQ), explicitrequests/response/hashmanifest; every expectedRTHbar present, zero duplicates/invalids/truncation. Four adversarial completeness tests and scopedRuff pass. NativeQQQ144OHLCmatchbutallvolumesdifferent;Sep30VWAPmaxdifference$0.067/oneclose-sideflip, sofeedsnotinterchangeable. See results/HISTORICAL_DATA_AUDIT_2026-10-03.{md,json}, tools/audit_historical_data.py. July–December2025 performance reserved for frozen finalist; October2026unopened. No broader strategy result yet; no mark-to-market replay engine built/validated. Next implement bounded independent5mreplay using audited data, verify timing/risk/MTM and native overlap before screening more variants. GoalACTIVE; no true blocker, no core/runtime/broker/scheduler changes. Monetary AI/data cost unmeasured; no data purchase.

October 3, batches G/H: TVR-0093 display-only Pine export preserves TVR-0092's complete native ledgers/metrics and exports 9,984 pre-October RTH bars per symbol. Header/count/calendar/fields/hash checks pass. The independent replay matches all 86 trades, prices, quantities, commissions, P&L and native MTM drawdown on SPY/QQQ; indicator differences <=5.1e-9. Thirteen adversarial execution/timing tests and scoped Ruff pass. Continuous-path drawdown is separately retained and slightly larger. 0093 ARCHIVED as diagnostic duplicate, not a winner. Full data, source and parity evidence retained in results/REPLAY_PARITY_2026-10-03.{md,json}, TVR-0093 result and native history manifest. Native last-bar advisory is nonfatal; no trading calculation change.

Predeclared older development transfer, January–June 2025 Alpaca SIP: 0092 SPY+$121.35/47/PF1.296, QQQ+$42.68/53/PF1.061; calendar-corrected hidden/one-change 0094 SPY+$213.85/143/PF1.146, QQQ-$105.04/159/PF0.946. Neither passes both-symbol PF1.2/40trade gate; REJECTED, no validation/cost/parameter tests triggered. Full ledgers pass net/count/time/daily-green/event/cap audits. Daily Sharpe/Sortino explicitly separate from native ratios; descriptive CAGR and both MTM conventions retained. New full94source server compiles cleanly; no94native chart test yet. Older favorable SPY cells do not rescue2026failures or weak/losingQQQ. Results/HISTORICAL_TRANSFER_2026-10-03.{md,json}, frozen planH and tool preserve all outcomes. No holdout performance opened.

Next: predeclare a final-filter test incorporating the existing Python technical qualification, rather than another isolated indicator. Actual DAY score is2*5MtrendScore+15MtrendScore+2*openingRangeBiasScore, direction-adjusted positive at pre-model gate; SMA20/50, MACD sign, RSI55/45, three-bar change and opening-range structure. Any proxy must use completed15M candles, disclose rolling220bar/EMA/RSI/feed differences and omitted contract/risk/events. Research goal ACTIVE, no robust profitable finalist; no broker/model/runtime/core/scheduler changes or data purchases. Monetary compute/data expense remains unmeasured.


## October 8 — ordinary Ichimoku/VWAP research,28native cells

October8 completed28 actual native TradingView cells under frozen plansA/B/C: standard Ichimoku9/26/52 plus RTHVWAP, RSI14, MACD12/26/9, confirmed Tenkan pullback. TVR-0095 and0096 REJECTED as robust standalone candidates; no promotion. QQQ5strict95+$170.30/84/PF1.165 losesJulSep-$260.52 and4ticks+doubledfee-$32.76; matched September strict1m/5m bothETFslose. DroppingMACD weak positives95SPY+$82.93/147,QQQ+$60.46/164; RSIremovalidentical5mledgers. FrozenATRstop96+optional2R: noPF1.2cell; noMACDstop-onlySPY+$30.29/169,QQQ+$57.45/183 averages$0.18/$0.31, addingtargetlosesboth. Fullsource.txt/nativecopies/hashmatches/all28ledgers/40audit tests preserved; no independent95/96tick or replay equity parity. Native per-bar equity endpoint unavailable; summaries/ledgers retained. July–December2025 andOctober2026holdoutperformanceunopened. Volumeprofile/POC/value-area/RVOL primary-source consideration documented; defer extra filters due weak economics. Evaluation stopped at the goal's information-value condition, NOT a profitable-production success. Historical top3screening priorities unchanged; no validated winner, no broker/Luna/runtime/core/paper-ledger/scheduler/purchase changes.

Exact complete Pine.txt95/96 preserved separately and native source hashes match;95original unchanged after native copy96. User freed indicator slot, replaced only95chart study with96; no unrelated scripts deleted. Source95unprotected Kijun close exit;96 entry-frozen ATR14 tick stop,optional2R with Kijun/time exits retained. 96allows confirmed-close reentry after an earlier intrabar exit on samebar;19-field audit records distance/exitID/comment and derives exposure bounds. Native OHLC emulator, no tick or new-family replay parity. Actual5mApr6–Sep30/124sessions;1mAug31–Sep30/22sessions; matchedSept21sessions. Fees .01%perside/2ticks base,95combinedstress4ticks/.02%, $10K/95%whole shares, actualSPY12–14/QQQ12–16. NoOctoberperformance/overnight/open/gaps/overflow accepted.

Allmetricfields,individualtrades,costs/inputmapping andsourceverification inresults/TVR-0095_2026-10-08_A/B.json andTVR-0096_2026-10-08_C.json; humanreportsTVR-0095_2026-10-08.md,TVR-0096_2026-10-08.md; frozenplansA/B/C. Node24.14.0auditors pass40tests, all28counts/net/fees/calendar/dailycap/quantity audits pass. Nativebarstate.last severity4advisory nonfatal; server0errors/warnings. AtomiccollectorfirstQQQstrict metrics exactpurposebuiltcrosscheck. Native per-bar equity unavailable; summaryMTM/ledgers saved, buyholdcurrentquote outside frozenrange notmatchedbenchmark. Independentreadonly96source review found no protectiontiming/freezingbug; gaps/open/export/exposure limitations handled. No extra lower-tier research agent loops.

AgentReach workflow Exafetchfailed; official TradingView primarywebfallback verifiedstrategy.exitentry-relativeticks,profilePOC/value-area/up-downapproximation andsame-clockRVOL. No copiedproprietaryscripts/configinstall/purchase. Consider simplecompletedprior10sessionssame-clockRVOL, but defervolumeadditionbecause baseline lacks economic credibility. Durablelessonssavedresearch/tradingview/LESSONS.md. Existingtop3weakSCREENINGprioritiesunchanged; do not invent tenwinners. Stop further tuning this bounded hypothesis undergoal'sinformation-valuecondition; negativeevaluation is complete, not profitable-strategy discovery. NoLuna/runtime/corepolicy/paperledger/broker/model/scheduler changes. Monetarycompute/dataexpenseunmeasured.

