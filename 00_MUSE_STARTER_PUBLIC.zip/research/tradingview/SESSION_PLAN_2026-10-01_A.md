# Batch TVR-0079: extreme-volume Ichimoku comparison

Frozen before results on October 1, 2026. Underlying ETF share proxy only.

Hypothesis: weighting the existing Ichimoku range endpoints by the total volumes
of their establishing bars may improve a confirmed conversion/base crossover
relative to classic equal midpoints. This follows the user's TVI-0002 request.
It is a custom formula; extreme-bar volume is not volume executed at that price.

Baseline and experimental arm use identical 9/26/52/26 horizons. Volume influence
0 is classic; 1 is the experimental arm. Enter on a confirmed conversion/base
cross only when close clears both currently displayed cloud spans (historical
span values 26 bars back). One entry per regular session. Entry closes from
09:50 inclusive through 15:30 exclusive Eastern; 60-minute maximum hold;
flatten at 15:45 or the last regular bar. Submit a frozen 1 ATR stop and 1.5 ATR
target alongside entry. ATR length 14. No parameter optimization.

Costs: $10,000 starting capital, 95% equity share sizing, 0.01% commission per
side, two ticks adverse slippage, confirmed bar-close orders, no pyramiding.
These share exposure and ATR exits cannot represent one-contract premium risk.
Actual options remain subject to all project premium/DTE/Greek/liquidity/cost
and daily-loss gates; no options return is inferred.

Evaluation: available regular-session SPY/QQQ 5m and 15m chart history within
January 1 through September 30, 2026. Document actual history coverage. October
1 onward is excluded and reserved as a final holdout. Existing pre-October
research has already been inspected, so chronological slices are validation
diagnostics, not an untouched historical holdout.

Cap: eight base cells (two arms, two symbols, two timeframes). If experimental
arm is positive with at least 20 trades and beats classic on the same cell,
allow at most eight additional checks: four-tick costs, train Jan-June versus
validation July-September, and influence 0.5. No broad rescue search. Reject
poor transfer or chronology; sparse positive cells remain provisional. Reserve
up to 45 minutes for this batch, two bounded agents (Pine implementation and
independent ledger/code audit), no paid data or model API purchases. Report
elapsed time and tool counts where available; dollar/subscription usage unknown.

Save complete source, all accepted raw results, test settings, failures and
resume checkpoint. Preserve separate proxy and options top-three views without
inventing validated winners. No live orders, core-policy or scheduler changes.
