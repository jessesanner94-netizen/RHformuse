# Documented Strategy Research — 2026-09-16

## Purpose

Identify simple, automatable SPY/QQQ hypotheses with credible published or independently replicated
evidence before creating more Pine variants. “Documented” means historically supported under a
stated sample; it does not mean proven profitable in the future. Preference is given to peer-reviewed
research, out-of-sample tests, multiple markets, transaction-cost treatment, and independent
replication.

## Evidence-ranked findings

| Priority | Strategy family | Published evidence | Main limitation | Research decision |
| ---: | --- | --- | --- | --- |
| 1 | Last-half-hour intraday momentum | Gao et al. (2018) find that SPY's first-half-hour return predicts its last-half-hour return in and out of sample over 1993–2013, with stronger effects on high-volatility/high-volume/news days. Baltussen et al. (2021) find that the return from the prior close through 15:30 predicts the final 30 minutes across more than 60 futures from 1974–2020. | Only 30 minutes of exposure; close-period spreads and options execution may consume the edge; the original samples end well before 2026. | Highest-priority exact Pine test: freeze two variants before results—first-30-minute sign and prior-close-to-15:30 sign—enter at 15:30 and flatten at 15:55/close. |
| 2 | Overnight-information reversal/momentum | Liu and Tse (2017) find that the overnight return predicts the first 30 minutes negatively and the last 30 minutes positively for SPY/US ETFs, both in and out of sample over 1999–2014. | Predictive regressions are not the same as a fully specified costed strategy; the middle of the day has no reported relation. | Test two independent, predeclared rules: fade the overnight gap only from 09:30–10:00; follow the same gap only from 15:30–close. Do not combine them until each leg is evaluated separately. |
| 3 | Noise-area intraday momentum | Zarattini, Aziz, and Barbon report 19.6% annualized return, Sharpe 1.33, and 25% drawdown for SPY over 2007–early 2024 after stated costs. The system uses 14-day minute-of-session noise bands, 30-minute checks, VWAP/band exits, end-of-day flattening, and volatility targeting. | Working paper rather than peer-reviewed journal. Two independent 2026 replications reproduce the older result but find sharply weaker 2024–2026 performance; one reports OOS Sharpe 0.39 and another says recent Sharpe is near zero. Hit rate is only about 41%–43%. | Worth faithful replication as a regime benchmark, not optimization. It needs deeper 1-minute history than the current TradingView window exposes; use a separate data backtester or Deep Backtesting before judging it. |
| 4 | One-minute QQQ VWAP trend/flip | Zarattini and Aziz report that a QQQ strategy beginning at 09:31, long above session VWAP and short below it, grew $25,000 to $192,656 over 2018–2023, with Sharpe 2.1 and 9.4% maximum drawdown, net of commissions. | Working paper, no credible independent replication located, about 22,000 trades, and the headline is extraordinarily sensitive to spread/slippage and exact one-minute fills. The authors call it not fully developed. | High-value falsification test, but only with one-minute data and severe spread/slippage stress. A 5m/15m translation would not be a faithful replication. |
| 5 | Timely opening-range breakout | Tsai et al. (2019) report more than 8% annual returns after transaction costs in DJIA, S&P 500, Nasdaq, HSI, and TAIEX index futures over 2003–2013; the best US probe times were within the first five minutes. | Futures rather than SPY/QQQ, older sample, and the best probe time was selected from alternatives. ORB profitability is strongly volatility-regime dependent. | Test only a frozen 5-minute version with an independently specified high-volatility gate; reject if costs or recent-period splits fail. |
| 6 | QQQ first-five-minute direction/ORB | A published working-paper result was independently reproduced at Sharpe 1.06 before slippage. The replication found break-even at roughly $0.022/share slippage; realistic stress reduced Sharpe to 0.23 and CAGR to 2.7%. An NQ pre-open confirmation helped, but 76% of filtered P&L came from 2022. | Edge sits near the spread and is dominated by one regime. The original assumes zero slippage. | Keep as a negative/control benchmark rather than a lead. Do not optimize the stop or target around the observed window. |
| 7 | Daily internal-bar-strength mean reversion | Pagonidis reports next-day equity-ETF mean reversion after closes near the daily high/low, with stronger effects after high-range/high-volume days and in high volatility. | Non-peer-reviewed competition paper, overnight exposure, and not the requested intraday execution horizon. | Possible daily regime filter later; not a primary day-trading strategy tonight. |

## What the evidence says about the desired “high win rate, small losses” profile

The best-supported intraday strategies are not naturally high-win-rate systems. The independently
replicated noise-area momentum strategy reports roughly 41% winners, and the replicated QQQ ORB
exits about 75% of trades at its stop. Their historical expectancy came from asymmetric winners or
specific high-volatility regimes. A high hit rate by itself is therefore not an evidence-backed
design target; profit factor, average win/loss, cost margin, and regime stability must remain primary.

The closest academically grounded path to a higher hit rate is the overnight-gap first-30-minute
reversal, because Liu and Tse document a negative relation between overnight and opening-half-hour
returns. The paper does not establish a standalone high-win-rate strategy, so the rule must be tested
without assuming its success.

## Frozen next-test queue

1. Complete the already compiled TVR-0046 matrix, but do not tune it.
2. Test the Gao rule exactly: first-half-hour direction predicts 15:30–close direction.
3. Test the Baltussen rule exactly: prior-close-to-15:30 direction predicts 15:30–close direction.
4. Test Liu–Tse opening-gap fade and closing-gap continuation as separate strategies.
5. Replicate the QQQ one-minute VWAP rule only when enough one-minute history is available.
6. Treat the noise-area strategy as a separate deep-data replication project; do not approximate its
   minute-of-session bands with a generic ATR or moving average and call it a replication.

Every rule above must use the same SPY/QQQ cost, chronology, nearby-parameter, date-segment, and 1m
stress standards as the existing research. No literature claim earns a leaderboard slot without our
own verified results.

## Follow-up — capped 2026-09-19 baseline session

TVR-0047 through TVR-0054 preserved all five families' executable baselines or attempted
replications. The two final-half-hour momentum signals and two overnight-information legs mostly
lost after costs; only TVR-0048 QQQ 5m gained a fragile $30.34 on $10,000, falling to $2.22 under
four-tick slippage. The published QQQ 1m VWAP flip and QQQ 5m first-candle ORB lost in their
available recent windows. The faithful SPY 1m noise-area script compiled but had zero trades
after its 14-session warm-up; a separately labeled 5m aggregation screen lost and cannot substitute
for a one-minute replication. No result was promoted. Full metrics, source paths, and caveats are
in `EXPERIMENT_LOG.md`; the original frozen queue above remains a record of what was specified
before seeing these results. TVR-0046 remains unfinished.

## Primary and replication sources

- Gao, Han, Li, and Zhou, [Market intraday momentum](https://www.sciencedirect.com/science/article/pii/S0304405X18301351), *Journal of Financial Economics* 129 (2018), 394–414.
- Baltussen, Da, Lammers, and Martens, [Hedging Demand and Market Intraday Momentum](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3760365), *Journal of Financial Economics* 142 (2021), 377–403.
- Liu and Tse, [Overnight returns of stock indexes: Evidence from ETFs and futures](https://www.sciencedirect.com/science/article/pii/S1059056016301563), *International Review of Economics & Finance* 48 (2017), 440–451.
- Zarattini, Aziz, and Barbon, [Beat the Market: An Effective Intraday Momentum Strategy for S&P500 ETF (SPY)](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4824172), Swiss Finance Institute working paper.
- Brusco, [independent SPY/ES noise-area replication](https://github.com/giovannibrusco/zarattini-2024-momentum-spy), including frozen protocols and 2025–2026 decay tests.
- Paz Serpa, [independent out-of-sample SPY replication](https://github.com/PazSheimy/spy-intraday-momentum-oos), May 2024–March 2026.
- Zarattini and Aziz, [Volume Weighted Average Price (VWAP): The Holy Grail for Day Trading Systems](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4631351), working paper.
- Tsai et al., [Assessing the Profitability of Timely Opening Range Breakout on Index Futures Markets](https://doi.org/10.1109/ACCESS.2019.2899177), *IEEE Access* (2019).
- Brusco, [independent QQQ opening-range replication and cost stress](https://github.com/giovannibrusco/zarattini-2023-orb-qqq).
- Pagonidis, [The IBS Effect: Mean Reversion in Equity ETFs](https://www.naaim.org/wp-content/uploads/2014/04/00V_Alexander_Pagonidis_The-IBS-Effect-Mean-Reversion-in-Equity-ETFs-1.pdf), NAAIM Wagner Award paper.
