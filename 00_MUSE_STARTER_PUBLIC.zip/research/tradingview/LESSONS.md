# Evidence-backed research lessons

## October 8 — TVR-0095/0096

- More agreeing indicators did not establish an edge. Across this frozen ordinary-Ichimoku/Tenkan-reclaim family, removing RSI changed neither five-minute baseline ledger; removingMACD changed entries and produced economically tiny profits. This is sample/family-specific, not a claim that RSI or MACD never helps.
- A positive full-sample cell can hide regime failure:95QQQstrict+$170.30/84 became-$260.52/43 inJulSep and-$32.76 under4ticks+.02%fees. Later-period and cost tests outweigh the appealing headline.
- Protective stops are necessary research changes to distinguish from an original close-only exit, not guaranteed performance improvements. Frozen1ATR14 stop/optional2R96 tested all eightcells; nonePF>=1.2. NoMACDstop-only averages pennies pertrade and2RfailsbothETFs. Do not rescue by threshold shopping or deleting losing directions from old ledgers.
- Native chart study slots and Pine source identities are different. Replace a saved research chart study when needed, but use native Make a copy BEFORE injecting a new strategy and re-fetch hashes to prove originals preserved. Save complete Pine.txt outsideTradingView.
- Display displacement must follow actual built-in source convention: Ichimoku26 is plotoffset25, so current displayedcloud uses rawspan[25]. Future projectedspan is not today'scloud. Verified builtin35source, not recalled from memory.
- Intrabar protective exits require exposure bounds and explicit same-bar-close reentry semantics. Native OHLC timestamps are bar labels, not true tick execution. Reject open positions, gaps or truncated exports before interpreting duration/accounting.
- Native buy/hold can include current live quote outside frozen strategy range; do not present it as a matched historical benchmark. Missing per-bar equity export does not justify inventing a curve or claiming new-family independent replay parity.
- Profile POC/value area are volume-at-price statistics, not proof of true buyer/seller aggression. Completed prior-session profiles or same-clock prior-session RVOL can avoid future leakage; bar-direction allocation and feed mismatches remain limitations. Do not add complexity to conceal weak baseline economics.

Evidence: results/TVR-0095_2026-10-08.md and nativeA/B JSONs; results/TVR-0096_2026-10-08.md and nativeC JSON; frozenplansA/B/C; exact strategy.txt files;40passing audit tests. No validated profitable or options strategy inferred.
