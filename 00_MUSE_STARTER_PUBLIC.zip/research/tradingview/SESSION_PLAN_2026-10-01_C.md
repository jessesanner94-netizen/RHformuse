# TVR-0081 — frozen-risk VWAP comparison

Declared October1 before results. Hypothesis: fixed signal-bar ATR protection
removes stop-widening without eliminating the VWAP failed-auction screen's edge.
Baseline is saved TVR0080 RTH matrix, not old mixed-session TVR0072 samples.
All entry rules/horizons/costs/date bounds/18-bar time exits identical. Only
stop/target are frozen from the signal bar and never recalculated while held.
Use identical calendar/bar-close diagnostic export. No new regime filter,
parameter search or optimized exits. Display diagnostics may include initial
levels and a counter for altered/widened stop; they cannot change orders.

Test four base cells: QQQ/SPY15m and5m, Jan1–Sep30,2026, available RTH history.
Capital10K,95%shares,.01%sidecommission,two ticks. October1 onward untouched.
Primary gate: all exported trades reconcile; no overnight/window/late-bar-close
violations; frozen-stop source review passes. Early closes remain separate:
existing15:45/lastbar flatten is NOT proven calendar-safe, and is unchanged to
avoid mixing changes. No options return or live/paper-policy promotion.

Cap eight cells total and30minutes, one Terra implementation plus one Luna
independent validator. If QQQ15 positive>=20 and not materially worse than0080,
allow two-tick JanJun/JulSep slices and four-tick QQQ15/5 stress (at most4 more).
Abandon if broad losses or protection error. No purchases, scheduling, broker
calls, operational paper cycles or core policy changes. Save every outcome,
source, raw trades, baseline delta and checkpoint. Early-close safety will be
a separate declared engineering comparison; do not silently fold it in here.
