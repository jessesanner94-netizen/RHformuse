# Session plan D — frozen exits

Predeclared before the TVR-0072 native result. TVR-0071 currently changes its ATR stop and target on each bar after entry. TVR-0072 will retain the same entry signals, 15:45 ET flatten guard, one-trade-per-day rule, $10,000 capital, 95% equity share sizing, 0.01% commission each side, two-tick slippage, and date range. It will freeze the initial ATR stop and target for the life of each trade. This is an execution-rule robustness check, not a search over exit parameters.

Test QQQ and SPY at 15 and 5 minutes. Record TradingView native net P&L, profit factor, mark-to-market drawdown, trade count, and exact chart/tester identity. Compare directly with TVR-0071. A positive QQQ 15-minute cell alone is insufficient for promotion; look for transfer to SPY and 5-minute charts and later examine chronology before treating it as an edge. ETF-share results cannot be imputed as option returns. No live trades or policy changes.
