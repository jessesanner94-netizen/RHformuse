# Batch G — native-history export and replay parity

Declared before results. TVR-0093 preserves all TVR-0092 trading logic and adds display-only export of pre-October bars and indicator/event values. Hypothesis: the Pine server has the full history used for its strategy report even though the browser's visible series exposes only300 bars. Export up to20,000 bars in bounded200-record table chunks; reject truncation or missing fields. October bars must not enter the export.

Two native5mRTH cellsSPY/QQQ, same2026defaults. Require exact equality of complete trade ledgers and metrics versus0092 before treating exports as unchanged strategy evidence. Keep original cloud copies and chart studies. Export OHLCV, session VWAP, EMA27, ATR14, RSI14, MACD histogram/line, pivot values and confirmed divergence IDs. Indicator exports may assist discrepancy diagnosis; replay signals must be derived independently from bars, not copied from native decisions.

Implement a local independent replay with Pine EMA/RMA warmup, prospective pivots, session reset, fixed bracket protection submitted with entry, bar-close entry, gap-aware bracket fills, commission/slippage, integer share sizing, daily-green and exchange calendar. Intrabar path assumptions must be explicit and tested. Verify no entry-bar retroactive stop, long/short gap loss, stop/target ordering, early closes, pivot confirmation and open-position drawdown. Keep native MTM DD authoritative; do not claim parity until signal/trade/settings comparisons prove it.

No new entry hypothesis, parameter search, older-history profit screen or holdout performance in this parity batch. If export fails, retain evidence and continue with a clearly labeled alternative; no fabricated parity. Research only.

