# Batch D — consume divergence events / require VWAP reclaim

Declared before results. Hypothesis: repeated entries from one still-valid divergence add noise; a subsequent VWAP reclaim may distinguish a reversal that is actually progressing.

- TVR-0088: TVR-0086 rules, but a confirmed bullish/bearish divergence may fund only one entry of that direction. Consume its confirmation bar on entry, reset consumed IDs each session. Retain false-to-true setup trigger.
- TVR-0089: same event consumption, plus a close crossing VWAP in the position direction on or after that divergence confirmation, within the last three bars. Remember crosses only within the current session. Divergence remains valid for twelve bars. Do not backdate either event.
- Fixed controls: EMA27 location entry-only, MACD two histogram moves, RSI14-or-MACD confirmed 3/3 divergence, frozen ATR14 stop1/target2, two-close opposite VWAP exit, calendar/EOD guards, maximum3/day and stop-after-realized-net-green. $10,000,95% equity,0.01% commission/side,2ticks. RTH5m SPY/QQQ, bounds January1–October1 exclusive; actual coverage begins March30. October stays unopened.
- Four base cells only initially. Material positive leads with at least30 trades require four-tick stress, reset-account earlier/later slices, both symbols and nearby reclaim expiry2/4 before consideration. Tiny positive samples remain insufficient; do not rescue failures with arbitrary tuning.
- Retain sources, complete native performance/inputs/trades, identity and timing/net audits. No option-return inference or production changes.

After the four base cells: 0089 QQQ +$38.64/37/PF1.110 improves on0088 +$26.05/57/PF1.046, but both fail SPY and Sharpe/Sortino. Neither is material profitability. Before any additional result, freeze five diagnostic0089QQQ cells: four ticks, January–June, July–September, reclaim age2 and4. Purpose: determine whether even this weak directional improvement survives controls; no promotion without broader evidence. Keep all defaults otherwise and restore afterward.
