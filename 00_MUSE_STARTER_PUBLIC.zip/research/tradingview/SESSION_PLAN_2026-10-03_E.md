# Batch E — hidden divergence continuation, reduced momentum delay

Declared before results; research history search found no prior hidden-divergence test.

Hypothesis: regular reversal divergence combined with VWAP/EMA27 confirmation may enter late. Hidden divergence instead represents a price pullback that holds structure while RSI or MACD retraces further. This is a hypothesis, not a claim of established profitability.

- TVR-0090: TVR-0088 controls, replacing only divergence definition. Calls: successive same-session confirmed pivot lows form a higher price low and lower RSI14 OR MACD12/26 line low. Puts: lower price high and higher RSI OR MACD high. Pivots3/3, separation5–60bars, confirmation valid12bars, one entry per confirmation. Still above/below VWAP and EMA27; two histogram moves toward intended direction; false-to-true setup entry.
- TVR-0091: identical hidden-divergence setup but requires only one histogram change toward intended direction instead of two. Test whether the extra momentum bar delays entry without improving quality.
- Unchanged frozen ATR14 stop1/target2, two-close opposite VWAP exit, RTH5m, EOD/calendar guards,3/day, realized-net-green latch, $10K/95%shares/.01%commission per side/two ticks. Date bounds January1–October1 exclusive; actual history March30–September30; October remains holdout.
- Four base cells SPY/QQQ. Preserve all sources/results. A positive lead with at least30 trades and PF>=1.2 warrants predeclared four-tick/earlier-later/nearby-pivot confirmation2/4 checks. Tiny/weak positives cannot qualify as significant profit. Rejection on cross-symbol/time-period/cost failure; no arbitrary rescue sweep.
- Full native performance, inputs, trades, identity, net/count/timing/daily-green audit; report return, descriptive CAGR, PF, native Sharpe/Sortino and mark-to-market DD. No production or options-P&L claim.
