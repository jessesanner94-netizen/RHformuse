# TradingView Research Leaderboard

Updated: 2026-10-08

## Latest evaluation — no new finalist

October8 completed28 actual native TradingView cells under frozen plansA/B/C: standard Ichimoku9/26/52 plus RTHVWAP, RSI14, MACD12/26/9, confirmed Tenkan pullback. TVR-0095 and0096 REJECTED as robust standalone candidates; no promotion. QQQ5strict95+$170.30/84/PF1.165 losesJulSep-$260.52 and4ticks+doubledfee-$32.76; matched September strict1m/5m bothETFslose. DroppingMACD weak positives95SPY+$82.93/147,QQQ+$60.46/164; RSIremovalidentical5mledgers. FrozenATRstop96+optional2R: noPF1.2cell; noMACDstop-onlySPY+$30.29/169,QQQ+$57.45/183 averages$0.18/$0.31, addingtargetlosesboth. Fullsource.txt/nativecopies/hashmatches/all28ledgers/40audit tests preserved; no independent95/96tick or replay equity parity. Native per-bar equity endpoint unavailable; summaries/ledgers retained. July–December2025 andOctober2026holdoutperformanceunopened. Volumeprofile/POC/value-area/RVOL primary-source consideration documented; defer extra filters due weak economics. Evaluation stopped at the goal's information-value condition, NOT a profitable-production success. Historical top3screening priorities unchanged; no validated winner, no broker/Luna/runtime/core/paper-ledger/scheduler/purchase changes.

Full reproducible reports: results/TVR-0095_2026-10-08.md and results/TVR-0096_2026-10-08.md. Both exact complete.txt sources are in strategies/; all metrics/inputs/individual trades in A/B/C JSONs. Earlier October3 plans/ACTIVE statements below are retained historical context, not the current research instruction.

October 3, batches G/H: TVR-0093 display-only Pine export preserves TVR-0092's complete native ledgers/metrics and exports 9,984 pre-October RTH bars per symbol. Header/count/calendar/fields/hash checks pass. The independent replay matches all 86 trades, prices, quantities, commissions, P&L and native MTM drawdown on SPY/QQQ; indicator differences <=5.1e-9. Thirteen adversarial execution/timing tests and scoped Ruff pass. Continuous-path drawdown is separately retained and slightly larger. 0093 ARCHIVED as diagnostic duplicate, not a winner. Full data, source and parity evidence retained in results/REPLAY_PARITY_2026-10-03.{md,json}, TVR-0093 result and native history manifest. Native last-bar advisory is nonfatal; no trading calculation change.

Predeclared older development transfer, January–June 2025 Alpaca SIP: 0092 SPY+$121.35/47/PF1.296, QQQ+$42.68/53/PF1.061; calendar-corrected hidden/one-change 0094 SPY+$213.85/143/PF1.146, QQQ-$105.04/159/PF0.946. Neither passes both-symbol PF1.2/40trade gate; REJECTED, no validation/cost/parameter tests triggered. Full ledgers pass net/count/time/daily-green/event/cap audits. Daily Sharpe/Sortino explicitly separate from native ratios; descriptive CAGR and both MTM conventions retained. New full94source server compiles cleanly; no94native chart test yet. Older favorable SPY cells do not rescue2026failures or weak/losingQQQ. Results/HISTORICAL_TRANSFER_2026-10-03.{md,json}, frozen planH and tool preserve all outcomes. No holdout performance opened.

Next: predeclare a final-filter test incorporating the existing Python technical qualification, rather than another isolated indicator. Actual DAY score is2*5MtrendScore+15MtrendScore+2*openingRangeBiasScore, direction-adjusted positive at pre-model gate; SMA20/50, MACD sign, RSI55/45, three-bar change and opening-range structure. Any proxy must use completed15M candles, disclose rolling220bar/EMA/RSI/feed differences and omitted contract/risk/events. Research goal ACTIVE, no robust profitable finalist; no broker/model/runtime/core/scheduler changes or data purchases. Monetary compute/data expense remains unmeasured.

October3 F/data expansion: found0082–0091 research sources incorrectly shorten July2,2026 to13:00; Alpaca/TradingView/installed NYSE calendar confirm16:00. TVR-0092 corrects calendar only, supports2025/2026earlycloses; nativeQQQ+$38.64/37 andSPY-$64.97/49 exactly match0089 complete ledgers/metrics. REJECTED, no promotion. Prior histories preserved with calendar-defect annotation; old lack ofJuly2trades alone was not enough to assert no effect. Raw/corrected sources/results: SESSION_PLAN_2026-10-03_F.md, results/TVR-0092_2026-10-03.{md,json}.

Historical expansion:14 saved SIPsymbol-months (Jan–Jun2025SPY/QQQ andSep2026SPY/QQQ), explicitrequests/response/hashmanifest; every expectedRTHbar present, zero duplicates/invalids/truncation. Four adversarial completeness tests and scopedRuff pass. NativeQQQ144OHLCmatchbutallvolumesdifferent;Sep30VWAPmaxdifference$0.067/oneclose-sideflip, sofeedsnotinterchangeable. See results/HISTORICAL_DATA_AUDIT_2026-10-03.{md,json}, tools/audit_historical_data.py. July–December2025 performance reserved for frozen finalist; October2026unopened. No broader strategy result yet; no mark-to-market replay engine built/validated. Next implement bounded independent5mreplay using audited data, verify timing/risk/MTM and native overlap before screening more variants. GoalACTIVE; no true blocker, no core/runtime/broker/scheduler changes. Monetary AI/data cost unmeasured; no data purchase.

October3 batch E: hidden-divergence continuation0090 QQQ-$7.44/157,SPY-$205.18/158; earlier momentum0091 QQQ+$57.35/164/PF1.042,SPY-$168.26/159. Full-period Sharpe/Sortino negative; both REJECTED. No PF>=1.2 positive lead, no further parameter tests triggered. Four full native ledgers pass net/count/identity/cost/fill/timing/daily-green checks. QQQ0091 shorts+$219.37/57 versus longs-$162.03/107 is posthoc diagnostic, not validated short-only strategy. Complete sources/native copies/metrics/trades: results/TVR-0090_0091_2026-10-03.{md,json}; frozen planE. Next priority broader historical coverage/defensible validation before more same-sample variants. October unopened; goal ACTIVE; no operational changes.

October3 batch D: TVR-0088 one entry per divergence QQQ+$26.05/57/PF1.046,SPY-$127.58/68. TVR-0089 adds a post-confirmation VWAP reclaim: QQQ+$38.64/37/PF1.110,SPY-$64.97/49;QQQ4ticks+$24.07, earlier+$63.87/16,later-$26.35/21. Reclaim ages2/3/4 identical, no independent confirmation. Both REJECTED for weak/period-dependent transfer; all nine native ledgers pass net/count/timing/daily-green audit. Complete sources, native saved copies, metrics and evidence: results/TVR-0088_0089_2026-10-03.{md,json}, frozen plan SESSION_PLAN_2026-10-03_D.md. October unopened; research goal ACTIVE; no operational changes.

Goal research B/C: 0084 fixed ATR bracket/two-close VWAP improves QQQ to+$15.34/58, but loses at4ticks and JulSep and fails SPY; 0085 bracket-only loses both. 0086 duplicates0084 because EMA slope is redundant. 0087 weakening-opposite-MACD phase produces SPY+$3.27/11 but QQQ-$64.67/13, negative full-period Sharpe/Sortino. No promotion or robust winner. Full return/PF/Sharpe/Sortino/CAGR/MTM-DD tables and trade audits: results/TVR-0084_0087_2026-10-03.md. Active goal: continue bounded research; preserve October as holdout.

October3 quick five-minute VWAP/EMA27/MACD screen: TVR-0082 SPY -$787.85/281trades, QQQ -$1,142.41/285; TVR-0083 confirmed RSI-or-MACD divergence SPY -$358.12/78, QQQ -$291.97/62. All negative after share costs. REJECTED as standalone candidates; no promotion. Intended final-filter role after Python-qualified options remains untested. Actual history March30–September30, not full January coverage. See results/TVR-0082_0083_2026-10-03.md. EMA27 is entry-only; exits VWAP/time.

## Current intraday research priorities — not approved winners

These three are weak screening leads, not a replacement for the historical ranks below.
None has untouched out-of-sample evidence or demonstrated option profitability.

| Priority | Candidate | Best corrected ETF-share cell on $10,000 | Main failure |
| ---: | --- | --- | --- |
| 1 | TVR-0080 Instrumented failed-auction VWAP (0071 family) | RTH QQQ 15m +$247.66, 36 trades, DD $86.95; four ticks +$239.17 | SPY15 loses; moving ATR can widen risk; early-close not exercised; latest slice11 trades |
| 2 | TVR-0064 Failed-auction RTH filter | SPY 15m +$132.39, 36 trades, DD $73.97 | QQQ transfer and May–June slice fail |
| 3 | TVR-0068 Entry-protected afternoon fade | QQQ 15m +$206.42, 45 trades, DD $148.08 | SPY transfer and July–September slice fail |

October 1 TVR-0079 classic versus extreme-volume Ichimoku comparison: all four
fully weighted cells lost. No promotion. Classic QQQ 5m +$129.25/103 trades was
the only positive baseline cell and is not an established edge. Complete matrix,
coverage and caveats: `results/TVR-0079_2026-10-01.json` and
`results/TVR-0079_2026-10-01.md`. TVR-0080 retained the same VWAP trading
logic with complete calendar/bar-close diagnostics and wider RTH coverage:
QQQ5 +$89.21/25, SPY5 +$13.78/31, SPY15 -$16.96/42. QQQ15 splits
Jan–June +$189.42/25 and July–September +$59.80/11 remain retrospective,
not untouched OOS. No overnight or October entries in exported ledgers;
early-close guard and moving-stop risk remain unvalidated for deployment.
See `results/TVR-0080_2026-10-01.md`. No finalist promoted.

This is a provisional top-ten research list, not a live-trading approval list. Ordering weighs
out-of-sample credibility, robustness, trade count, realistic costs, and mark-to-market drawdown
before headline return.

**2026-09-19 execution audit:** Stops/targets in TVR-0022, TVR-0030, TVR-0009,
TVR-0016, and TVR-0018 were submitted a bar late; their previous positive numbers
are not validated risk-controlled backtests. TVR-0030's immediate-bracket correction
(TVR-0061) lost in three of four cells and it was removed from active ranks.
The other four have now been retested as TVR-0067–0070, but none regained an
active rank. TVR-0067 QQQ 15m is the best corrected *single cell* (+$250.07
on $10,000, 24 trades; +$244.37 at four ticks), yet SPY 15m and QQQ 5m lost.
TVR-0064 SPY 15m is +$132.39 over 36 trades but QQQ transfer and one
chronological slice failed. Both are SCREENING only. No active rank is a
live-ready intraday strategy. TVR-0067 also lacks an explicit end-of-day
flatten; its trade timestamps and possible overnight carry need auditing.
TVR-0071 added an EOD guard to TVR-0067: the four tested cells were unchanged
and its EOD-close counter stayed zero. It remains unranked screening evidence,
not an options-P&L result or proof of behavior on future early-close days.
TVR-0072 froze its entry ATR bracket: QQQ 15m stayed near +$249/24 trades,
but SPY 15m worsened to -$86.53 and QQQ 5m lost $98.43. It is rejected as
an improvement and is preserved as a negative control, not ranked.
TVR-0073 corrected the older TVR-0005 VWAP-trend reclaim's protection and
completed-hour timing; all four SPY/QQQ 5m/15m costed cells lost. It is
rejected, with no parameter search or option-profit claim.
Historical sections below are superseded.

The capped 2026-09-19 published-strategy batch (TVR-0047–TVR-0054) added **no** top-ten entry.
The only positive cell was TVR-0048 on QQQ 5m (+$30.34 on $10,000, 54 trades), but three other
symbol/timeframe cells lost and four-tick slippage reduced that cell to +$2.22. TVR-0053's
faithful one-minute noise-area rule had zero post-warm-up trades, so it remains data-insufficient.
Details and complete source paths are in [EXPERIMENT_LOG.md](EXPERIMENT_LOG.md); no existing
leaderboard status was upgraded.

| Rank | ID | Candidate | Symbol | Execution | Context | TradingView result | OOS result | Status |
| ---: | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | TVR-0001 | Bollinger mean-reversion demo | SPY | 1D | None | +13.69%, PF 3.21, DD 13.00%, 11 trades | +5.74%, 3 trades, robustness 0.74 | DEMO — not promoted |
| 2 | TVR-0002 | VWAP opening-range reversion | QQQ lead; SPY failed | 5M/15M | 4H EMA slope | $10K/95% sizing: QQQ +1.00%/+2.66%, PF 1.23/6.33, 36/14 trades; 1M +0.10%, PF 1.05 | Not yet available | PROVISIONAL — stable neighborhood, but too few 15M trades and cost-sensitive 5M |
| — | TVR-0022 | Early failed-auction VWAP reclaim | Former QQQ 15M lead | 5M/15M | Initial range + VWAP + 1H trend | Corrected TVR-0067 QQQ 15m +$250.07/24; SPY 15m -$53.07 | No untouched OOS | SCREENING — no rank, transfer failed |
| — | TVR-0030 | Failed-auction tight exit | Former QQQ 15M lead | 5M/15M | Initial range + VWAP + 1H trend | Corrected TVR-0061: QQQ 15M -$78.01; SPY 15M -$67.86 | No validated OOS | REJECTED — delayed-bracket lead refuted |
| — | TVR-0009 | Afternoon morning-range fade | Former mixed leads | 5M/15M | Morning range | Corrected TVR-0068 QQQ 15m +$206.42/45; SPY 15m -$65.92 | No untouched OOS | SCREENING — no rank, symbol transfer failed |
| — | TVR-0016 | Gap/trend-aligned OR breakout | Former mixed leads | 5M/15M | Prior 5D trend + opening gap | Corrected TVR-0069 lost in all four cells | No validated OOS | REJECTED — delayed-bracket lead refuted |
| — | TVR-0018 | Volume-pressure VWAP timed | Former 5M leads | 5M | Signed volume pressure + VWAP + 1H trend | Corrected TVR-0070 QQQ/SPY 5m +$83.57/+$18.49 over 10 trades each; SPY 15m -$130.28 | No untouched OOS | SCREENING — no rank, 5m sparse |
| — | TVR-0004 | VWAP failed extension | QQQ lead; SPY failed | 5M/15M | 1H trend distance | Default QQQ PF 1.50/1.18; neighboring thresholds made 15M negative | Not applicable | REJECTED — parameter instability, 1M and SPY failures |
| — | TVR-0005 | VWAP trend reclaim | SPY/QQQ | 5M/15M | 1H EMA trend | $10K/95% sizing: QQQ +0.94%/+0.78%, PF 1.27/1.06; 1M -0.54%; SPY negative | Not applicable | REJECTED — weak 15M, failed 1M and SPY transfer |
| — | TVR-0006 | Bollinger regime pullback | SPY/QQQ | 5M/15M | Daily EMA 200 | QQQ 15M +3.39%, PF 1.28, 96 trades; QQQ 5M/1M and SPY negative | Not applicable | REJECTED — parameter, timeframe, symbol, and cost instability |
| — | TVR-0007 | Squeeze release momentum | SPY/QQQ | 5M/15M | 1H EMA trend | All four cells negative; PF 0.67–0.99 | Not applicable | REJECTED — failed base matrix |
| — | TVR-0008 | Opening drive pullback | SPY/QQQ | 5M/15M | 1H EMA trend | All four cells negative; PF 0.31–0.51 | Not applicable | REJECTED — failed base matrix decisively |
| — | TVR-0010 | Morning-range fade volatility gate | SPY/QQQ | 5M/15M | Morning range/ATR | All four cells negative; QQQ 15M PF 0.14 | Not applicable | REJECTED — broad volatility gate selected losing subset |
| — | TVR-0011 | Prior-day level reclaim | SPY/QQQ | 5M/15M | Prior-day range | All four cells negative; PF 0.26–0.74 | Not applicable | REJECTED — failed base matrix decisively |
| — | TVR-0012 | Relative-strength pullback | SPY/QQQ | 5M/15M | Cross-ETF relative return | All four cells negative; returns -2.05% to -4.25%, PF 0.31–0.64 | Not applicable | REJECTED — broad cross-symbol/timeframe failure |
| — | TVR-0013 | Directional-efficiency breakout | SPY/QQQ | 5M/15M | Intraday path efficiency | All four cells negative; returns -0.79% to -3.02%, PF 0.61–0.75 | Not applicable | REJECTED — smooth-path filter did not create continuation edge |
| — | TVR-0014 | Exhaustion close-location reversal | SPY/QQQ | 5M/15M | Large-bar close location | Zero to eight trades per cell; every nonempty cell negative, PF 0–0.69 | Not applicable | REJECTED — sparse and negative |
| — | TVR-0015 | Noon range-position reversal | SPY/QQQ | 5M/15M | Morning range position | All four cells negative; returns -0.27% to -4.01%, PF 0.30–0.89 | Not applicable | REJECTED — recurring noon fade lacked edge |
| — | TVR-0017 | Gap-hold timed continuation | SPY/QQQ | 5M/15M | Prior 5D trend + gap hold | Only QQQ 15M positive at +0.23%, PF 1.08; other cells PF 0.34–0.87 | Not applicable | REJECTED — gap/trend state alone insufficient |
| — | TVR-0019 | Volume-pressure VWAP 13:00 | SPY/QQQ | 5M/15M | Signed volume pressure + VWAP + 1H trend | SPY 15M +0.42%, PF 1.15; QQQ 15M +0.20%, PF 1.04; both 5M negative | Not applicable | REJECTED — later timing relocated but did not strengthen edge |
| — | TVR-0020 | Four-hour regime transition | SPY/QQQ | 5M/15M | Recent 4H EMA cross + daily/VWAP | Only 1–2 trades per cell; three positive cells and one QQQ 5M loss | Not applicable | REJECTED — seven total observations are unusably sparse |
| — | TVR-0021 | Four-hour trend strength | SPY/QQQ | 5M/15M | Completed 4H EMA spread/ATR + daily/VWAP | All four cells negative; returns -0.43% to -1.64%, PF 0.47–0.75 | Not applicable | REJECTED — continuous HTF alignment produced samples but no edge |
| — | TVR-0023 | Failed auction with prior-day location | SPY/QQQ | 5M/15M | Initial range + VWAP + prior-day range position | QQQ 15M +1.62%, PF 1.25 over 53 trades; SPY 5M weakly positive; other cells negative | QQQ 15M: -0.81%, +2.22%, +0.27% | REJECTED — parameter/cost fragility and strong regime concentration |
| — | TVR-0003 | Opening-range ATR breakout | SPY/QQQ | 5M/15M | 1H EMA slope | PF 0.67–0.97; negative in all 4 cells | Not applicable | REJECTED — consistent losses after costs |

## Why TVR-0001 is not a finalist

It is the first end-to-end infrastructure proof, not an intraday candidate. Its three out-of-sample
trades are too few to establish an edge, it has not been tested on QQQ or the target 5-minute and
15-minute execution timeframes, and its headless drawdown understated TradingView's mark-to-market
drawdown. It remains here as a reproducible baseline until stronger candidates replace it.

## Empty slots

Eight slots remain unfilled after the execution audit. A slot is earned by evidence, not filled
to reach a quota. Neither remaining unsuspended entry is a finalist or live-trading approval.

Batch 2 (2026-08-30) screened hourly Bollinger, EMA-cross, and Keltner hypotheses on SPY and QQQ
with costs and walk-forward splits. No new candidate met the evidence standard; all four detailed
walk-forward tests were rejected or retained only as negative controls.

## 2026-09-05 — Futures quick screen

| ID | Candidate | MES1! 5m | MNQ1! 5m | Status |
| --- | --- | --- | --- | --- |
| TVR-0026 | First five-minute breakout | -$66.25, PF 0.00, DD $66.25, 1 trade | $0.00, no trades | REJECTED / insufficient sample |
| TVR-0027 | Fifteen-minute ORB retest | -$450.00, PF 0.681, DD $817.50, 24 trades | +$453.50, PF 1.116, DD $1,472.00, 31 trades | SCREENING — MNQ lead only |

These are native TradingView Strategy Tester results on the available Jul 12–Sep 4, 2026
intraday window, using $10,000 initial capital, one contract, $1.25 commission per contract per
order, two ticks slippage, 10% margin, and forced end-of-day exits. They are not deep, walk-forward,
or out-of-sample evidence and do not justify a paid plan or live trading. The exact source files are
preserved under `strategies/` and the detailed run is in `EXPERIMENT_LOG.md`.

## 2026-09-05 — Simple high-win-rate batch

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0028 | RSI(2) trend pullback | -$121.82 / -$230.82; PF 0.41 / 0.60 | -$127.54 / -$40.89; PF 0.55 / 0.94 | REJECTED — every base cell lost |
| TVR-0029 | Confirmed moderate-gap fill | -$17.20 (1 trade) / -$139.54 (11 trades) | no trades / no trades | REJECTED — sparse and negative |
| TVR-0030 | Failed-auction tight exit | +$22.26, PF 1.69, 66.7% wins / -$47.29, PF 0.80 | -$62.80, PF 0.29 / +$112.17, PF 1.61, 68% wins | PROVISIONAL — bounded lead, not a finalist |

TVR-0030's QQQ 15m result remained positive with four-tick slippage (+$103.21, PF 1.55),
nearby 0.45/0.55 ATR and 0.55/0.65 ATR brackets, and each Jan–Apr, May–Jun, and Jul–Aug
2026 segment. Its 1m checks had only three SPY and two QQQ trades, so they provide no credible
execution-stress evidence. Mixed base-cell transfer and the small samples prevent finalist status.

## 2026-09-06 — Normalized-opening-range attribution test

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0031 | Failed-auction normalized open | +$22.26, PF 1.69 / -$78.16, PF 0.68 | -$62.80, PF 0.29 / +$65.89, PF 1.36 | REJECTED — filter did not improve transfer and weakened the QQQ 15m lead |

TVR-0031 kept TVR-0030's entry and tight frozen exit but required the completed 30-minute opening
range to be 0.10–0.60 of the previous completed daily ATR. The filter left both 5m cells unchanged,
made SPY 15m worse, and reduced QQQ 15m from +$112.17/PF 1.61 over 25 trades to +$65.89/PF 1.36
over 24. The baseline failed, so no threshold tuning, cost stress, date segmentation, or 1m test was
performed. TVR-0030 remains the better provisional expression.

## 2026-09-06 — Fixed 11:00 opening-range hold

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0032 | 11AM opening-range hold | -$24.40, PF 0.57 / -$189.89, PF 0.36 | -$32.48, PF 0.52 / +$61.64, PF 1.25 | REJECTED — three cells lost and the only positive cell was modest |

TVR-0032 used one 11:00 ET close beyond the completed opening range, completed 1H trend agreement,
completed 15m ATR risk, and a 60-minute clock exit so its definition did not depend on chart bar
counts. QQQ 15m produced a more useful 41-trade sample and 61% win rate, but SPY 15m lost 1.90%
over 44 trades and both shorter-history 5m cells lost. No parameter or stress testing was justified.

## 2026-09-06 — Fixed 11:00 failed-range reversal

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0033 | 11AM failed range hold | -$45.87, PF 0.29 / -$148.40, PF 0.38 | -$5.85, PF 0.88 / -$34.10, PF 0.84 | REJECTED — every base cell lost |

TVR-0033 tested the direct reversal counterpart to TVR-0032: a one-sided opening-range probe that
failed back inside by 11:00 ET, while avoiding fades against the completed 1H trend. All four cells
lost after costs. QQQ 5m won 57.14% of seven trades but still lost money, illustrating that hit rate
alone did not overcome payoff and costs. No 1m, cost, subperiod, or parameter tuning was justified.

## 2026-09-06 — Hourly RSI intraday translation

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0034 | Hourly RSI snapback | -$73.97, PF 0.46 / -$59.36, PF 0.86 | +$3.37, PF 1.02 / -$179.63, PF 0.75 | REJECTED — three cells lost; lone positive cell was indistinguishable from noise |

The inexpensive two-year hourly screen first showed standard RSI mean reversion positive on both
ETFs (SPY +12.71%, PF 1.84, 73.8% wins/42 trades; QQQ +15.72%, PF 1.61, 69.2% wins/39 trades)
under its own 0.1% commission and 0.05% slippage assumptions. TVR-0034 translated that premise to
completed 1H RSI extremes plus one intraday reversal bar and a fixed 0.45 ATR bracket. The
translation failed: QQQ 5m made only $3.37 over 30 trades while its drawdown reached $134.46, and
the other three cells lost. No stress or parameter tuning was justified.

## 2026-09-06 — Completed-15m contraction breakout

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0035 | Completed-15m contraction break | -$57.18, PF 0.21 / +$16.83, PF 1.24 | -$3.59, PF 0.95 / +$20.45, PF 1.16 | REJECTED — thin 15m gains, failed 5m transfer and 1m stress |

TVR-0035 used the same completed 15-minute contraction and setup-defined stop on every chart,
aligning breakouts with the completed 1H EMA trend. QQQ 15m reached 72.73% wins over 22 trades,
but earned only $20.45 with PF 1.16; SPY 15m earned $16.83 over 21 trades. Both remained barely
positive with four-tick slippage, while QQQ 1m lost $2.40/PF 0.94 and SPY 1m lost $24.32/PF 0.14.
The weak expectancy and failed shorter-timeframe transfer do not earn a leaderboard slot.

## 2026-09-06 — Two-bar pullback to session-extreme retest

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0036 | Two-bar pullback retest | -$66.81, PF 0.19 / -$1.80, PF 0.92 | -$89.63, PF 0.48 / +$4.73, PF 1.23 | REJECTED — both 5m cells lost and 15m produced only two to four trades |

TVR-0036 required two countertrend candles, a reversal through the last candle, completed 1H trend
agreement, a stop beyond the pullback extreme, and enough room to the already-established session
high/low. The structural destination made 15m evidence unusably sparse: QQQ had two trades and SPY
four. Both 5m cells lost with 30%–33% win rates, so no stress or rule loosening was justified.

## 2026-09-06 — Prior close-location morning pullback

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0037 | Prior close-location pullback | no trades / no trades | no trades / no trades | REJECTED — overfiltered; zero observations in every cell |

TVR-0037 made one invariant 10:00 ET decision: continue a prior-day strong/weak close after a
first-30-minute pullback recovered its midpoint, using the opening extreme as the stop and prior
close as the target. The exact compiled strategy returned zero trades on SPY and QQQ at both 5m
and 15m. The hypothesis is unusable as defined and was not loosened after observing the result.

## 2026-09-06 — First-15-minute daily-trend continuation

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0038 | First-15m daily-trend continuation | -$90.75, PF 0.50 / -$47.16, PF 0.92 | +$21.51, PF 1.09 / +$193.54, PF 1.24 | REJECTED — QQQ lead failed recent-period, 1m, and SPY transfer tests |

TVR-0038 entered at 09:45 ET when the completed first 15-minute candle agreed with the prior
completed daily close versus EMA20. The QQQ 15m lead had 67 trades, survived nearby 0.55R/0.75R
targets and four-tick slippage, but lost in July–August and both 1m checks failed sharply. The
apparently positive QQQ cells therefore do not earn a leaderboard slot.

## 2026-09-06 — Fixed first-hour VWAP pullback/reclaim

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0039 | First-hour VWAP pullback/reclaim | -$17.93, PF 0.67 / -$237.51, PF 0.66 | +$43.90, PF 1.49 / -$259.52, PF 0.70 | REJECTED — three cells lost; sole lead had nine trades |

TVR-0039 separated the morning into a directional first 30 minutes and a 30-minute VWAP pullback,
then made one 10:30 ET reclaim decision with the pullback extreme as its stop. Both 15m cells lost
decisively over 61–68 trades. The nine-trade QQQ 5m result is too small and isolated to retain.

## 2026-09-06 — First-hour outer-range mean reversion

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0040 | First-hour outer-range reversion | -$71.17, PF 0.58 / -$135.42, PF 0.79 | -$22.19, PF 0.91 / -$135.66, PF 0.86 | REJECTED — every base cell lost; win rates 19%–30% |

TVR-0040 faded a 10:30 ET close in the outer fifth of the completed first-hour range, stopped just
beyond the range, and targeted its midpoint. All four cells lost, including 82–91 trade 15m samples;
the simple edge-reversion premise is rejected without threshold or exit tuning.

## 2026-09-06 — Cross-ETF first-hour divergence fade

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0041 | Cross-ETF first-hour divergence fade | -$70.95, PF 0.32 / -$84.25, PF 0.78 | -$27.98, PF 0.81 / -$181.39, PF 0.72 | REJECTED — every base cell lost |

TVR-0041 made one 10:30 ET relative-value decision, fading a chart ETF whose return from the RTH
open differed from its SPY/QQQ peer by at least 0.25 percentage points. It used a frozen completed
15-minute ATR stop/target and a 60-minute maximum hold. All four cells lost, including both 62-trade
15m samples, so no divergence-threshold, exit, cost, date-segment, or 1m tuning was justified.

## 2026-09-06 — Confirmed opening-gap continuation

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0042 | Confirmed opening-gap continuation | -$103.88, PF 0.23 / -$190.72, PF 0.55 | -$114.17, PF 0.34 / +$29.26, PF 1.07 | REJECTED — three cells lost; lone lead was near flat |

TVR-0042 entered at 09:45 ET when a moderate 0.15%–0.80% overnight gap was confirmed by the
completed first 15-minute candle, using its midpoint as the stop and a 0.65R target. Only QQQ 15m
was positive, and its $29.26/PF 1.07 over 36 trades was negligible beside $113.05 drawdown. The
other three cells lost decisively, so no parameter, cost, segment, or 1m testing was justified.

## 2026-09-06 — Prior-day compression opening-range expansion

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0043 | Prior-day compression OR expansion | -$76.04, PF 0.36 / +$27.83, PF 1.13 | -$322.62, PF 0.18 / -$147.06, PF 0.69 | REJECTED — three cells lost; SPY 15m lead was negligible |

TVR-0043 made one 10:15 ET opening-range breakout decision after a prior day whose range was no
more than 0.75 daily ATR. Only SPY 15m was positive, returning $27.83 over 24 trades against
$127.98 drawdown. QQQ failed sharply on both timeframes, so no parameter or stress testing was run.

## 2026-09-06 — Opening-shock midpoint reversion

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0044 | Opening-shock midpoint reversion | +$11.00, PF 1.25 / +$57.73, PF 1.19 | +$15.70, PF 3.56 (2 trades) / -$196.10, PF 0.25 | REJECTED — SPY lead was regime-specific; QQQ 15m failed |

TVR-0044 faded an unusually large completed first 15-minute candle toward its midpoint. SPY 15m
survived doubled slippage and nearby thresholds, but lost in January–April; QQQ 15m lost 1.96% with
only 18.18% wins. The positive 5m and 1m cells contained only one to eleven trades, so the strategy
does not earn a leaderboard slot.

## 2026-09-06 — Daily-trend opening rejection

| ID | Candidate | SPY 5m / 15m | QQQ 5m / 15m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0045 | Daily-trend opening rejection | +$32.59, PF 2.17 (6 trades) / +$28.11, PF 1.12 | +$57.41, PF 1.41 (11 trades) / +$116.39, PF 1.30 | REJECTED — positive base matrix, but both ETFs failed January–April and 1m evidence failed/sparse |

TVR-0045 entered at 10:00 ET when a countertrend first 15-minute candle was rejected through its
midpoint during the next 15 minutes in the direction of the completed daily EMA20 regime. All four
base cells were positive, and both 15m cells survived doubled slippage and nearby target/EMA values.
That headline did not survive chronology: January–April lost on both ETFs, later positive segments
had only four to eight trades, QQQ 1m lost with PF 0.39, and SPY 1m produced one trade. It remains a
useful regime-specific clue but does not earn a leaderboard slot.

## 2026-09-28 — Supplied-video 9 EMA / VWAP cross

| ID | Candidate | SPY 3m | QQQ 3m | Decision |
| --- | --- | --- | --- | --- |
| TVR-0074 | EMA9 / VWAP cross, EMA9 close exit | -$459.57, PF 0.323, DD $477.39, 129 | -$639.18, PF 0.390, DD $651.79, 121 | REJECTED |
| TVR-0075 | Candle / VWAP cross, EMA9-aligned | -$362.86, PF 0.375, DD $378.24, 118 | -$336.53, PF 0.574, DD $348.12, 110 | REJECTED |
| TVR-0076 | EMA/VWAP plus completed-15m trend | -$159.94, PF 0.483, DD $196.43, 62 | -$58.92, PF 0.827, DD $67.37, 57 | REJECTED |
| TVR-0077 | TVR-0076 long-only | -$27.48, PF 0.800, DD $65.99, 29 | +$25.42, PF 1.138, DD $51.51, 29 | REJECTED — failed transfer; negligible edge |
| TVR-0078 | TVR-0076 short-only | not run after QQQ failed | -$81.00, PF 0.487, DD $99.79, 28 | REJECTED |

The video-derived idea produced no promotable candidate under the frozen $10,000/95%-share,
0.01%-per-side commission, two-tick-slippage assumptions. The sole positive cell averaged only
$0.88 per trade and lost on SPY under identical rules. Sources and interpretation are preserved in
`strategies/TVR-0074_video_9ema_vwap_cross.txt` through
`strategies/TVR-0078_video_9ema_vwap_15m_trend_short_only.txt` and
`SESSION_PLAN_2026-09-28_A.md`; none changes the existing leaderboard.




