# TVR-0080 — instrumented VWAP timing audit

Declared before results October 1, 2026. Hypothesis: the strongest corrected
VWAP failed-auction lead may depend on unsafe holding/session assumptions.
This batch tests execution fidelity, not profit optimization.

Baseline TVR-0071, same entries/exits/default parameters, RTH chart. TVR-0080
adds a closed-trade calendar/time diagnostic table and fixed Jan1–Sep30, 2026
entry window. No parameter search. First QQQ/SPY 15m, then both 5m if useful.
Cap eight cells including any corrected variant and cost stress. Reserve
30 minutes; one Terra developer and one Luna independent source/result reviewer.
Serialize chart mutations. No purchases, live orders, operational paper cycles,
core-policy or scheduler changes.

Freeze 0.10 ATR sweep, three-bar reclaim, completed-hour EMA30, ATR14,
0.75 ATR stop/1.50 target, 18-bar max hold; $10K/95% shares, 0.01% per side,
two ticks. Existing bracket moves with ATR after entry: diagnose, do not quietly
freeze/change it in baseline. Holding 18 bars differs across 5m/15m.

Audit calendar timestamps for entries/exits and overnight dates, post-window
entries, last regular-bar exits and early-close risk. Diagnostics must not
affect trading. Preserve original TVR-0071 source and saved user scripts.
October1 onward excluded. Chart history limits must be recorded. New RTH/date
coverage differs from historical mixed-session samples; not direct profit lift.

If unsafe fills/holds found, declare a separate corrected variant before tests.
If no calendar violations and positive >=20 trades, up to remaining cap allows
four-tick costs and predeclared Jan–June/July–Sep slices, never final holdout.
Early closes not exercised remain unverified; no timestamp data means no audit
pass. All outcomes proxy-only; no conversion to options profits.

After four base cells, allocate the remaining four cells to four-tick QQQ 5m
and 15m plus QQQ 15m Jan–June / July–September. SPY 5m's $0.44/trade is
too small to prioritize, SPY 15m loses. This follows the conditional gate;
no parameter rescue. Source-level moving-ATR risk and unexercised early-close
behavior prevent deployment regardless of these follow-up numbers.
