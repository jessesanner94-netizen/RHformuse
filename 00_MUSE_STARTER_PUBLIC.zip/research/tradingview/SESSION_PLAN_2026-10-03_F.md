# Batch F — calendar correction only

Declared before corrected results. Verified Alpaca calendar, TradingView NASDAQ regular-session corrections and installed pandas-market-calendars NYSE all show July2,2026 normal16:00close. Earlier sources0082–0091 mistakenly shortened that session to13:00; retain them as historical evidence and annotate the defect. Old absence of July2 entries does not prove unaffected results because the wrong cutoff may have suppressed entries.

TVR-0092 is0089 with only early-close calendar corrected/extended:2025July3,November28,December24;2026November27,December24. Limit supported years to2025/2026; do not silently assume future calendars. Preserve Jan1–Oct1exclusive2026bounds and all signal/exit/cost settings. Two baseline native5mRTH cellsQQQ/SPY, compare0089same-symbol metrics/complete trades and inspectJuly2. No threshold optimization or broader performance test in this correction batch.

Data expansion separate:January–June2025development,July–December2025performance reserved for frozen finalist,2026knownsamplecontaminateddevelopment,Octoberunopened. NativeICE/NASDAQvolumes differ fromAlpacaSIP:144OHLCmatches,144volumemismatches;September30full-sessionVWAPmaxdifference$0.067 and1above/belowflip. Do not mixfeeds or claimexactreplayparity.
