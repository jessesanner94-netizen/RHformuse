# Batch TVR-0071 — regular-session flatten audit

Frozen before testing. Scope: SPY and QQQ underlying-ETF share simulations on
15-minute bars, with a 5-minute timing check only if available. This is a
signal/implementation screen for the paper long-call/long-put project, **not**
an option P&L backtest.

Hypothesis: the existing TVR-0067 early failed-auction plus VWAP reclaim signal
is only potentially useful for DAY options if exposure ends within the regular
session. Create TVR-0071 by changing TVR-0067 **only** to close any remaining
position at the 15:45 ET bar close or the last regular-session bar, whichever
comes first. Preserve all entry conditions, initial same-bar stop/target
submission, subsequent exit updates, costs, sizing, and other parameters.

Baseline: TVR-0067 on the same QQQ 15m chart reports +$250.07 net, 24 trades,
profit factor 2.325, and $55.96 TradingView mark-to-market drawdown. But it has
no explicit EOD close, so that result may include overnight exposure. Compare
TVR-0071 against TVR-0067 on QQQ 15m and SPY 15m, then inspect trade counts,
profit factor, maximum drawdown, and whether any strategy-close exits occur.
The minimum acceptable implementation result is verified Pine compilation and
exact chart/Strategy Tester identity. A positive cell alone will not promote
the strategy: the old QQQ lead failed symbol/timeframe transfer and has no
untouched out-of-sample period. Do not tune parameters in this batch.

Common proxy assumptions: $10,000 initial capital, 95% equity sizing, 0.01%
commission per side, two ticks adverse slippage per order, confirmed bar-close
orders, no pyramiding. Option fills, DTE, Greeks, premium budget, and spread
cannot be inferred from this ETF-share test and must be validated prospectively
against actual option quotes.
