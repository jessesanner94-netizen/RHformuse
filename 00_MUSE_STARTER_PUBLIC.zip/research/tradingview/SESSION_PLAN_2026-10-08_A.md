# October 8 — separate Ichimoku/VWAP pullback baseline

User goal: ordinary Ichimoku, session VWAP, RSI and MACD; first 1m, then 5m SPY/QQQ. This supersedes the October 3 next-test queue, not the recorded negative results. Research only; no operating policy, options system, broker, purchase or scheduler changes.

## Frozen baseline TVR-0095

- Ichimoku 9/26/52, displacement input 26. TradingView built-in uses inclusive displacement convention (plot offset 25); current displayed cloud therefore uses historical spans at `[25]`. Verify against the built-in indicator before accepting results. No future values or lagging-span entry filter.
- Long: prior same-session close above prior Tenkan; current candle's low <= current Tenkan <= high, confirmed close > Tenkan; close, Tenkan and Kijun above current cloud; Tenkan > Kijun; close > cumulative RTH hlc3 VWAP; RSI14 >50; MACD12/26/9 histogram >0. Short exactly inverse. No extra cloud-color, MACD-zero-line, volume or candle-body filter.
- This operationalizes a touch/reclaim on the same confirmed candle. Intrabar signal sequencing is not observed; only the confirmed OHLC condition is claimed.
- Exit at confirmed close below Kijun (long), above Kijun (short), or 15 minutes before actual session close. No profit target or intrabar protective stop in this ORIGINAL hypothesis. Therefore this baseline is not an acceptable live/options risk-control implementation; frozen protection is a subsequent separate candidate, not silently added.
- RTH standard candles. Entry candle closes >=09:50 and <30 minutes before close; maximum three entries/day, one position, no pyramiding/reversal while held. No stop-after-green rule added to this hypothesis.
[account details redacted]
- Pre-October 2026 development only: requested Jan1–Oct1 exclusive, actual coverage independently recorded. October 2026 and July–December 2025 performance remain reserved. No native October trades. Different timeframe coverage is not a fair timeframe comparison; match overlap dates separately after coverage is observed without selecting on profits.

## First batch, fixed before results

Eight cells in this order: SPY1m baseline/strict, QQQ1m baseline/strict, SPY5m baseline/strict, QQQ5m baseline/strict. Strict changes ONLY requiring VWAP >cloud top for longs / <cloud bottom for shorts.

Capture native identity, actual chart coverage, all input/properties, complete trade ledger and metrics, long/short net/count, commissions and exposure. Reconcile ledger counts/net, assert no out-of-range/overnight/late entries/exits. Invalid identities or partial exports do not count as results.

Pre-result static review hardening: require >=77 loaded bars for complete52+25 cloud history and observed09:30 RTH open for complete session VWAP; block the first partial session. Export per-trade fees, signed share quantity and fill prices, open-trade/gap/overflow flags. Accept exposure only with zero open/overnight trades and no within-session gaps. Audit arrays fail explicitly at99,999 bars; table caps500 trades and overflow invalidates completeness. These correctness checks are not post-result parameter changes.

## Subsequent bounded work (not yet tested)

Compare matched-overlap 1m/5m, remove RSI alone and MACD alone, then separately test frozen 1ATR protection and 2R target with Kijun/time exits. Predeclare exact cells/source IDs before each next batch. Test cost/chronology and simple past-only relative-volume or prior-session profile filters; expand older development coverage with existing audited data if needed. Existing replay parity is for the older divergence family, not yet verified for Ichimoku or 1m.

Do not optimize 1m as sole deployment frame, promote tiny samples, claim 'all agree' predicts profit, or interpret an in-sample lead as options profitability. Keep at most ten genuine research candidates; no forced winner.

## Sources checked

- [TradingView Ichimoku](https://www.tradingview.com/support/solutions/43000589152-ichimoku-cloud/): range-midpoint lines, projected cloud and lagged close; concepts, not proof of edge.
- [TradingView VWAP](https://www.tradingview.com/support/solutions/43000502018-volume-weighted-average-price-vwap/): cumulative typical-price times volume divided by volume; session anchor.
- [TradingView volume profile](https://www.tradingview.com/support/solutions/43000502040-volume-profile-indicators-basic-concepts/): volume at price, POC/value area; lower-timeframe candle-direction up/down classification is not aggressor buy/sell data.
- [LuxAlgo Money Flow Profile](https://www.tradingview.com/script/l2mefDKN-Money-Flow-Profile-LuxAlgo/), [creator page](https://www.luxalgo.com/library/indicator/money-flow-profile/): volume/money-flow rows and sentiment panel. Public script is open-source/free, despite the prompt's generic proprietary warning. No copied source or purchase; a last-bar fixed-range display must not be applied retrospectively to entries.

Agent Reach Exa lookup failed connection negotiation; official/creator web sources used as fallback. No software/config repair required for the trading experiment.
