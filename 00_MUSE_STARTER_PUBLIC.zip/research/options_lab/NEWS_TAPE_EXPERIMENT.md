# News, market depth and tape experiment — October 21, 2026

The implemented component is an **offline research recorder and review-signal
engine** in `event_tape.py`. It preserves session observations and evaluates
timestamped news plus short-bar reactions. It is isolated from production and
does not collect a live feed, classify real headlines, execute paper/live orders,
or establish a profitable strategy. Existing options-lab P&L replay remains a
separate component; review markers do not count as trades or realized returns.

## Clarifications from the workflow review

The $6.50 figure was `(1.275 stop trigger − 1.21 exit fill) × 100`. It is a
mathematical trigger-to-fill reference. A $1.275 executable fill was not
established; neither an entry mistake nor unreasonable $170 sizing follows from
that comparison. The price change's news cause also remains unverified.

News is currently collected and summarized for entry/JEV context. The current
no-Luna position route skips qualitative material-event review, so news collection
does not currently imply explicit news-triggered exits or reversals. This is the
specific behavior proposed for testing.

## What the data audit established

| Input | Current capability | Consequence |
| --- | --- | --- |
| Robinhood equity price book | Resting price/size snapshots; no order IDs, event deltas, venue attribution or executions | Can observe displayed liquidity; cannot prove cancellation, absorption, aggressor buying/selling or spoofing intent |
| Existing local book history | Approximately five-minute SPY sampling, rolling 60-minute retention | Useful coarse context; insufficient for ten-second tape strategies or a durable full-day archive |
| Connected Alpaca historical IEX trades | Tiny read-only sample returned genuine exchange `V` prints with timestamps, prices, sizes and IDs | An available research source for IEX-local volume; not full-market depth, a proven live stream, or provider-labeled aggressor side |
| Default entry timeframe summaries | Latest-row summaries may include developing candles | Audit completion timestamps before attributing a signal to a completed candle |
| Entry-timing context and continuation-only path | Completed intraday candles are explicitly selected | These paths must not be confused with default entry summaries |
| Missing volume | `_frame()` substitutes zero when the volume column is absent | A recorded zero can represent unavailable input; do not treat it as proof that no trading occurred |

The read-only SQLite sample initially contained 12 SPY snapshots over roughly
55 minutes, separated by about 300 seconds. Exact capture bounds/counts and source
hashes are in `NEWS_TAPE_AUDIT_2026-10-21.json`; the operational database continues
to change independently. The existing production retention/cadence were not changed.

## Bookmap concepts translated into testable hypotheses

Bookmap's heatmap represents historical displayed liquidity. Its bubbles represent
executed trades. A bot can analyze those observations without recreating the UI,
but it needs both kinds of data for many of the familiar setups.

| Hypothesis | Required observations | What would invalidate the inference |
| --- | --- | --- |
| Absorption near a predeclared zone | Repeated genuine aggressive executions into a level, limited price progress, persistent/replenishing displayed liquidity | Only a large resting order; missing/guessed aggressor side; sparse snapshots or a feed gap |
| Liquidity withdrawal or stacking | Frequent depth observations/updates, fixed-price history, subsequent price/trade response | A wall disappearing between coarse snapshots; its cause is unknown |
| Failed break and reclaim | A level declared before the test, actual trades beyond it, then a timed reclaim/failure | Drawing the zone after the reversal or labeling all high-volume breaks as stop hunts |
| Break through liquidity and continuation | Executions through/beyond a known level, follow-through and acceptable option liquidity | The offer/bid merely disappearing, stale depth, or no executable option price |

These are research families, not validated entry rules. The current prototype
computes feed-local displayed zones, volume at price and CVD only when aggressor
side is explicitly provider-labeled. It leaves absorption/exhaustion unavailable.
Large resting orders can change or disappear. An ETF's book also does not describe
every constituent, futures market, hidden order or off-exchange execution. News
can first become observable through repricing, pulled liquidity, executions or a
headline; the relative feed delays decide what this bot actually sees first.

Chart-derived supply/demand or order-block zones are a separate hypothesis. Define
their creation, width, expiry, invalidation and retest rules before future prices
are examined. Compare them with zones derived from observed depth and executed
volume. A candle box is not evidence that an institution left an unfilled order.

## Implemented recorder and signal behavior

`SessionTape` accepts explicit JSONL ingestion and keeps full Eastern-session
history without the production collector's one-hour deletion. It retains:

- Source, venue/feed identity, symbol, event identity, original event time, receipt
  time, and availability/classification time, plus the raw normalized payload.
- Separate book, execution, trade-cancel, completed-bar, news and gap records.
  Feed-local trade cancellations take effect only once they are available.
- Point-in-time queries fenced by both event and availability times, idempotent
  duplicates and transactional conflict rejection. Same-event syndication cannot
  renew an old headline's eligibility.
- Explicit verified news corrections through `supersedes_event_id`; conflicting
  unlinked classifications pause review. Gap intervals and recovery versions
  invalidate overlapping bars without erasing earlier valid observations.
- Feed/venue/symbol separation. Unknown aggressor side stays unknown. CVD is null
  if the observed feed volume includes unknown-side executions. Raw print volume
  still depends on provider coverage, conditions and correction normalization.

The news engine consumes **externally verified/classified annotations**. It does
not infer "bad news" through a keyword list or pretend to verify a supplied URL.
An upstream classifier must supply relevance, materiality, novelty, direction,
method/version, and an evidence link before an event is eligible. Unknown,
unverified or irrelevant events cannot become an exit signal.

A relevant eligible event first produces a hypothetical entry pause/review.
Confirmation requires a completed, recent short bar beginning after the verified
classification was available, adequate actual volume and a move in the annotated
direction. The research policy pins one reaction feed and venue explicitly.
Missing volume, a long/developing bar or an overlapping data gap cannot confirm.
Research thresholds are supplied in a separate policy file; no numeric production
threshold or stop/target is changed.

If the confirmation opposes a held CALL/PUT, the result is `EXIT_REVIEW`. An
opposite-side contract is only a candidate for requalification. The result always
has zero orders, no paper fill, and `reversal_authorized: false`. A future paper
adapter must simulate the exit at an available option bid, confirm closure, and
independently recheck the new contract, cash, session, event, exposure, entry count,
green lock and remaining risk budget. An event does not bypass those gates.

## Ten-second target

Measure these separately: publication → receipt; receipt → verified classification;
classification → confirmation availability; classification → decision evaluation;
decision → reviewed/submitted/confirmed exit. The prototype reports the first four
where supplied observations permit it. Actual execution latency stays unknown.

One-second/five-second trade aggregates are compatible with fast confirmation.
Waiting for a completed five-minute candle is not. Current five-minute collection
and RSS delivery cannot support an end-to-end ten-second claim. A dedicated stream
and event loop are needed; data-provider latency, headline verification, classifier
latency and mandatory broker checks can each consume the budget. Track median and
tail latency instead of promising publication-to-fill time. Ordinary protective
stops must continue independently of any news/classification work.

Alpaca documents a real-time trade/quote WebSocket stream, feed entitlements,
trade conditions, corrections and cancellations. Its trade schema has no explicit
aggressor-side field. The connected historical-data tool's successful IEX sample
does not establish that a direct streaming deployment is configured or that SIP,
full depth or an automatic analysis license is included. No feed was purchased,
subscription changed or recurring collection started by this work.

## Run the synthetic demonstration

The example thresholds and events are synthetic fixtures, not selected trading
parameters or performance evidence. From the repository root:

```bash
.venv/bin/python -m research.options_lab.event_tape \
  --db /tmp/synthetic-event-tape.sqlite3 ingest \
  --input research/options_lab/examples/synthetic_news_tape.jsonl

.venv/bin/python -m research.options_lab.event_tape \
  --db /tmp/synthetic-event-tape.sqlite3 evaluate --symbol SPY --held CALL \
  --as-of 2026-10-21T14:00:06Z \
  --policy research/options_lab/examples/synthetic_reaction_policy.json
```

The example proposes an exit review and PUT requalification candidate six
**synthetic timestamp seconds** after classification. That is a replay scenario,
not a measured live service latency or a trade. Reingestion deduplicates records.
Use separate recording databases per real feed/dataset. Ingest bounded batches;
this offline implementation is not a production high-throughput stream collector.

## Evaluation plan and remaining integration

Next integration is an opt-in read-only collector: archive underlying depth and
genuine prints, corrected trade conditions, short bars, news timing, candidate
option bid/ask/Greeks/IV, and rejection/outage evidence. Stream/recording work must
not slow live protective exits. Preserve a frozen unchanged baseline and evaluate
news-only, flow-only, and combined challengers separately using the same observable
data. Include quiet days, false alarms, discarded winners and missed-session
uncertainty, not just selected dramatic headlines or successful trade screenshots.

The existing options lab can supply independent paper cash/risk accounting when
this review-marker stream is connected through a paper-only adapter. That adapter
and automatic live reaction are not implemented here. Without the option quote
path, this module cannot calculate credible strategy P&L, drawdown or missed-winner
P&L. No benchmark gain is invented. Promotion requires forward evidence after
development, explicit live-policy approval and production execution checks.

## Primary sources

- [Bookmap features: liquidity heatmap, volume bubbles and replay](https://bookmap.com/en/features).
- [Bookmap education: layering versus absorption](https://bookmap.com/learning-center/order-flow-phenomena/order-flow-education/layering-and-absorption).
- [Nasdaq TotalView fact sheet: depth on the Nasdaq market](https://nasdaqtrader.com/content/ProductsServices/DataProducts/TotalView/TotalViewFactSheet.pdf).
- [Alpaca real-time stock data: feed entitlements, message schemas and corrections](https://docs.alpaca.markets/us/docs/real-time-stock-pricing-data).
- [Cont, Kukanov and Stoikov: The Price Impact of Order Book Events](https://arxiv.org/abs/1011.6402).
- [Gould and Bonart: Queue Imbalance as a One-Tick-Ahead Price Predictor](https://arxiv.org/abs/1512.03492).

The papers motivate measuring order-book events and imbalance at short horizons;
they do not establish profitable SPY/QQQ options trading after costs and latency.
