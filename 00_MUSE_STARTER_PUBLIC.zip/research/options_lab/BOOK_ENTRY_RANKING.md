# Paper order-book entry ranking — October25, 2026

This is an uncalibrated heuristic for the existing paper bot, not evidence of
profitable predictions. It uses existing displayed Robinhood depth only. Venue
coverage remains `UNSPECIFIED` / unverified; execution prints are unavailable.

## Trace confirmed before editing

The prior active version was `depth_exits_20261023`, identified by CURRENT.json.
`ForwardExperiment.opportunities` runs original discovery and account admission,
then the shared `tools.scheduled_cycle._route_compact_decision_impl`. That router
uses `build_decision_packet` to enforce Python qualification, reviews at most
three eligible contracts with JEV, then chooses with its optional integer
`candidate_priority` followed by JEV's existing score tuple and stable Python order.
Previously the paper callback supplied only raw RSI priority (+1/0/-1).
`apply_paper_decision` still performs final quote/contract/event/time/risk checks.

The old persistent opposing-wall veto lived in `zone_signals._liquidity`, reached
through `ForwardExperiment.review` inside `guarded_quotes` before and after quote
refresh. Both this paper fill check and its replay equivalent now disable the
displayed-liquidity veto branch. The old detector itself is unchanged and reused
only to identify a bounded ranking penalty. Supply/demand and news gates remain.
The production router, JEV implementation and all core tools/policies are unchanged.

## Actual ranking order

Among the router's already-qualified shortlist, maximize:

1. `total_priority = 4 * RSI_direction + book_score`.
2. Existing JEV setup quality, then entry-timing quality, then escalation score.
3. Original Python candidate order for an exact tie.

`RSI_direction` is the existing confirmed supporting/neutral/opposing value
(+1/0/-1). There is no required RSI or book signal. Missing/invalid JEV evidence
retains its existing fail-closed behavior; a valid low score or negative opinion
does not independently veto a candidate. JEV remains ranking-only, with the same
questions, collector context and call limits. No extra model or feed call is added.

Book components, capped together to [-5,+5]:

| Component | Initial contribution |
| --- | ---: |
| Persistent direction aligned with the contract | +4 |
| Persistent direction against the contract | -4 |
| Thin depth / price liquidity gap with confirmed direction | additional +1 or -1 |
| Persistent nearby wall opposing the contract | -1 total, even for multiple walls |
| Unavailable/stale/conflicting book evidence | 0 for every book component |

Thus a positive book can promote a candidate and adverse pressure can demote it.
A qualified sole candidate with a wall penalty can still enter. Neither book nor
RSI creates a new qualification path or revives a rejected candidate.

## Initial observation heuristic

- Existing same-session Robinhood/UNSPECIFIED records, available at/before the
  ranking timestamp; at most300seconds of history, latest book <=30seconds old.
  Conflicting observations, source transport gaps or sampling gaps >30seconds
  make this feature neutral. Identical copies never manufacture persistence.
- Nearest five levels per side. Require the latest three distinct observations
  to span at least18seconds, accommodating roughly10-second polling.
- Each confirming snapshot needs near imbalance `(bid-ask)/(bid+ask)` >=0.40
  with >=1000 bid shares for upward support, or <=-0.40 with >=1000 ask shares
  for downward pressure. The midpoint must move monotonically in that direction
  by at least2basis points over confirmation. CALL rewards upward support;
  PUT rewards downward pressure. The opposite direction subtracts weight.
- Thin depth means current combined near depth <=50% of the median of at least
  six earlier samples. A price liquidity gap is >=2basis points between near
  ask levels for an upward move, or bid levels for a downward move. These can
  amplify a confirmed direction; alone they contribute zero directional score.
- Persistent walls reuse existing thresholds: >=3 observations /20seconds,
  >=1000 shares and >=25% of displayed side depth, within20basis points. Wall
  appearance/disappearance alone is ambiguous and gives no directional score.
  Resting changes are never labeled executed buying/selling, absorption,
  exhaustion or a confirmed breakout.

## Configuration, logs and versioning

All ranking knobs are in `BOOK_RANKING_POLICY` and the frozen paper
`forward/EXPERIMENT.json` under `policy.book_ranking`. Supply a JSON override file
with `forward prepare --book-ranking-policy <path>` when preparing a new version.
For example, `{"rsi_weight":4,"direction_weight":4,"opposing_wall_penalty":1}`.
Unknown fields, invalid numeric settings and feed substitutions are rejected.
Metadata has a manifest hash; do not edit a frozen version's metadata in place.
Other policy fields, including exit rules, cannot change through these overrides.

OPPORTUNITIES.jsonl now records `ranking_as_of`, `book_ranking_evidence`,
`candidate_ranking_components` and per-account `entry_ranking`. Each candidate
has component scores, direction alignment, source/freshness/availability evidence,
combined priority, actual rank, selection flag and selection reason. Preliminary
candidates outside the Python-qualified pool have null rank and are explicitly
marked not ranked. They never enter selection just because they have a book score.
MARKET_CONTEXT.json displays book diagnostics with `entry_veto:false`.

Forward candidates share one ranking timestamp and memoized per-symbol evidence.
Replay applies the same scores, configurable history and neutral book fill
behavior using event AND availability timestamps. No historical fill or prior
outcome is revised. Existing replay limitations for missing option quotes/news
and depth-dependent exits still apply.

The single account is carried forward into `book_rank_20261025`, preserving
cash, P&L, trade history, daily limits, shared research budgets and tape. The
prior version remains archived. Carried trades do not become performance of
this new entry heuristic. Live execution stays disabled in the isolated config;
phone notifications stay disabled. Sunday deployment cannot validate live
market behavior or profitability; forward observations are still needed.
