"""Read-only forward research feeds. No order, model, scheduler or policy interfaces.

Call books every 10s, context every minute and news every 30s externally. Availability
is receipt/classification time, never the historical timestamp of a fetched bar.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import re
import sqlite3
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from typing import Any
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen
from xml.etree import ElementTree

from research.options_lab.event_tape import ET, SessionTape, timestamp, validate
from tools.market_calendar import session_hours
from tools.orderbook import MAX_LEVELS_PER_SIDE, parse_level2_book

FED_RSS = "https://www.federalreserve.gov/feeds/press_monetary.xml"
MACRO_QUERY = ('("Federal Reserve" OR FOMC OR "US inflation" OR "US jobs" OR '
               '"Treasury yields" OR "market-wide trading halt" OR "S&P 500" OR Nasdaq) when:1h')


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _read(url: str) -> bytes:
    request = Request(url, headers={"User-Agent": "Options-Lab-Research/1.0"})
    with urlopen(request, timeout=6) as res:
        if urlparse(res.url).hostname != urlparse(url).hostname:
            raise ValueError("unexpected feed redirect")
        value = res.read(2_000_001)
    if len(value) > 2_000_000:
        raise ValueError("feed response exceeds bound")
    return value


def _yahoo(symbol: str) -> dict:
    return json.loads(_read(f"https://query1.finance.yahoo.com/v8/finance/chart/"
                            f"{quote(symbol, safe='')}?interval=1m&range=1d"))


def _news(channel: str) -> list[dict]:
    if channel == "google_news":
        from tools.market_intelligence import fetch_google_news_query
        return fetch_google_news_query("macro", MACRO_QUERY, timeout=6)
    root = ElementTree.fromstring(_read(FED_RSS))
    return [{"title": n.findtext("title"), "link": n.findtext("link"),
             "published": n.findtext("pubDate"), "source": "Federal Reserve Board",
             "primary_feed": FED_RSS} for n in root.findall("./channel/item")[:100]]


async def _call(fetcher: Callable, *args: Any, timeout: float) -> Any:
    async def invoke():
        if inspect.iscoroutinefunction(fetcher):
            return await fetcher(*args)
        result = await asyncio.to_thread(fetcher, *args)
        return await result if inspect.isawaitable(result) else result
    return await asyncio.wait_for(invoke(), timeout)


def classify_news(item: dict, channel: str) -> dict:
    """Primary publication provenance verifies an announcement, not its market sign.

    Google RSS source labels/aggregator links alone never verify a claim. Material
    means a potential broad-market catalyst requiring review, not proven impact.
    """
    title = item["title"].casefold()
    primary = (channel == "federal_reserve" and item.get("primary_feed") == FED_RSS
               and urlparse(item["link"]).hostname == "www.federalreserve.gov"
               and urlparse(item["link"]).path.startswith("/newsevents/pressreleases/"))
    material = bool(re.search(r"fomc|federal reserve|inflation|consumer price|nonfarm|"
                              r"us jobs|u\.s\. jobs|treasury yield|trading halt|"
                              r"circuit breaker|emergency|monetary policy", title))
    if primary:
        material = bool(re.search(r"fomc statement|implementation note|emergency|"
                                  r"unscheduled|target range|monetary policy", title))
    return {"verified": primary, "material": material, "novel": True,
            "direction": "UNKNOWN", "classification_method": "conservative_rules_v1",
            "verification_basis": "primary_publication_provenance" if primary else
            "unverified_syndicated_report", "semantic_direction_verified": False}


class ForwardFeeds:
    def __init__(self, tape: SessionTape, symbols: list[str], *, book_fetcher=None,
                 bar_fetcher=None, news_fetcher=None, classifier=None, clock=None,
                 timeout_seconds: float = 8.0):
        self.tape = tape
        self.symbols = [s.strip().upper() for s in symbols]
        if not 1 <= len(self.symbols) <= 4 or len(set(self.symbols)) != len(self.symbols) or any(
                not re.fullmatch(r"[A-Z][A-Z0-9.-]{0,14}", s) for s in self.symbols):
            raise ValueError("requires one to four unique equity symbols")
        if not 0 < timeout_seconds <= 8:
            raise ValueError("timeout must be positive and at most eight seconds")
        self.timeout = timeout_seconds
        self.book_fetcher, self.bar_fetcher = book_fetcher, bar_fetcher or _yahoo
        self.news_fetcher, self.classifier = news_fetcher or _news, classifier or classify_news
        self.clock = clock or (lambda: datetime.now(UTC))
        self._write_lock = asyncio.Lock()
        self.gaps: dict[tuple, dict] = {}
        self.articles: dict[tuple, dict] = {}
        self.bar_hashes: dict[tuple, str] = {}
        # Recover only this session's small identity state. Full book archives stay
        # on disk. Bar corrections are detected but first observations stay immutable;
        # replay consumers do not yet implement revised-bar supersession.
        session = self._now().astimezone(ET).date().isoformat()
        placeholders = ",".join("?" for _ in self.symbols)
        with sqlite3.connect(tape.path) as con:
            for (record,) in con.execute(
                "SELECT record FROM events WHERE session=? AND symbol IN ("
                + placeholders + ") AND kind IN ('news','gap','bar') ORDER BY available_epoch",
                (session, *self.symbols),
            ):
                row = json.loads(record)
                if row["symbol"] not in self.symbols:
                    continue
                key = row["source"], row["symbol"]
                if row["kind"] == "gap":
                    if row["payload"].get("end_at") is None:
                        self.gaps[key] = row
                    else:
                        self.gaps.pop(key, None)
                elif row["kind"] == "news":
                    self.articles[(*key, row["payload"]["url"])] = row
                elif row["kind"] == "bar":
                    self.bar_hashes[(*key, row["event_id"])] = _hash(row["payload"])

    def _now(self) -> datetime:
        result = self.clock()
        if result.tzinfo is None:
            raise ValueError("clock needs timezone")
        return result.astimezone(UTC)

    def _row(self, kind, source, venue, symbol, event, received, payload, identity):
        return {"schema_version": 1, "kind": kind, "source": source, "venue": venue,
                "symbol": symbol, "event_id": identity, "event_at": event.isoformat(),
                "received_at": received.isoformat(), "available_at": self._now().isoformat(),
                "payload": payload}

    async def _ingest(self, rows):
        # One SQLite transaction per batch; serialize writers and keep fsync off
        # the event loop so a historical warm-up cannot starve book monitoring.
        async with self._write_lock:
            return await asyncio.to_thread(self.tape.ingest, rows)

    async def _gap(self, source, venue, symbol, reason=None):
        now = self._now()
        key = source, symbol
        prior = self.gaps.get(key)
        if reason is not None and prior is None:
            payload = {"start_at": now.isoformat(), "end_at": None,
                       "gap_key": _hash([source, symbol, now.isoformat()]), "reason": reason}
        elif reason is None and prior is not None:
            if now <= timestamp(prior["payload"]["start_at"]):
                return
            payload = {**prior["payload"], "end_at": now.isoformat()}
        else:
            return
        row = self._row("gap", source, venue, symbol, now, now, payload,
                        payload["gap_key"] + (":open" if reason is not None else ":closed"))
        await self._ingest([row])
        if reason is not None:
            self.gaps[key] = row
        else:
            self.gaps.pop(key, None)

    async def poll_books(self) -> dict:
        fetcher = self.book_fetcher
        if fetcher is None:
            from tools.robinhood_mcp import fetch_equity_price_book
            fetcher = fetch_equity_price_book
        try:
            data = await _call(fetcher, self.symbols, timeout=self.timeout)
            received = self._now()
            books = {b["symbol"]: b for b in data["books"]}
        except Exception as exc:
            books, received = {}, self._now()
            failure = type(exc).__name__
        statuses = {}
        for symbol in self.symbols:
            try:
                provider = books[symbol]
                # Capture a bounded provider-ordered prefix; never sort away a
                # malformed book or claim that the captured prefix is full depth.
                if any(not isinstance(provider.get(side), list) for side in ("bids", "asks")):
                    raise ValueError("provider depth must be lists")
                original = {side: len(provider[side]) for side in ("bids", "asks")}
                raw = {**provider, **{side: provider[side][:MAX_LEVELS_PER_SIDE]
                                     for side in ("bids", "asks")}}
                captured = {side: len(raw[side]) for side in ("bids", "asks")}
                raw["depth_capture"] = {
                    "original_counts": original, "captured_counts": captured,
                    "truncated": original != captured,
                    "policy": "FIRST_1000_PROVIDER_ORDERED_LEVELS_PER_SIDE",
                    "omitted_levels_archived": False,
                }
                book = parse_level2_book(raw, now=received)
                if not book.bids or not book.asks:
                    raise ValueError("empty depth")
                row = self._row("book", "robinhood", "UNSPECIFIED", symbol,
                                book.updated_at, received, raw, "book:" + raw["updated_at"])
                result = await self._ingest([row])
                await self._gap("robinhood", "UNSPECIFIED", symbol)
                statuses[symbol] = {"status": "OK", **result, "updated_at": raw["updated_at"],
                                    "depth_capture": raw["depth_capture"]}
            except Exception as exc:
                reason = locals().get("failure", type(exc).__name__)
                await self._gap("robinhood", "UNSPECIFIED", symbol, reason)
                statuses[symbol] = {"status": "UNAVAILABLE", "reason": reason}
        return {"status": "OK" if all(s["status"] == "OK" for s in statuses.values())
                else "UNAVAILABLE", "as_of": self._now().isoformat(),
                "source": "robinhood", "venue": "UNSPECIFIED", "symbols": statuses}

    async def poll_context(self) -> dict:
        async def one(symbol):
            inserted, skipped, ignored_revisions = 0, 0, 0
            pending, hashes = [], {}
            try:
                data = await _call(self.bar_fetcher, symbol, timeout=self.timeout)
                received = self._now()
                chart = data["chart"]["result"][0]
                if chart.get("meta", {}).get("symbol", symbol).upper() != symbol:
                    raise ValueError("chart symbol mismatch")
                quotes = chart["indicators"]["quote"][0]
                epochs = chart["timestamp"]
                fields = ("open", "high", "low", "close", "volume")
                if not isinstance(epochs, list) or any(
                    not isinstance(quotes.get(k), list) or len(quotes[k]) != len(epochs)
                    for k in fields
                ):
                    raise ValueError("invalid chart arrays")
                hours = await asyncio.to_thread(session_hours, received.astimezone(ET).date())
                if hours is None:
                    return symbol, {"status": "NO_REGULAR_SESSION", "inserted": 0,
                                    "skipped": len(epochs), "ignored_revisions": 0}
                session_open, session_close = hours
                valid = 0
                for index, epoch in enumerate(epochs):
                    if isinstance(epoch, bool) or not isinstance(epoch, (int, float)):
                        raise ValueError("invalid chart timestamp")
                    start = datetime.fromtimestamp(epoch, UTC)
                    end = start + timedelta(seconds=60)
                    if start < session_open or end > session_close or end > received:
                        skipped += 1
                        continue
                    try:
                        payload = {k: quotes[k][index] for k in
                                   ("open", "high", "low", "close", "volume")}
                        if payload["volume"] is None:
                            raise ValueError("missing volume")
                        payload.update(start_at=start.isoformat(), end_at=end.isoformat())
                        identity = "bar:" + start.isoformat()
                        row = self._row("bar", "yahoo", "CONSOLIDATED_UNVERIFIED", symbol,
                                        end, received, payload, identity)
                        validate(row)
                        valid += 1
                        key = "yahoo", symbol, identity
                        digest = _hash(payload)
                        prior_digest = hashes.get(key, self.bar_hashes.get(key))
                        if prior_digest is None:
                            pending.append(row)
                            hashes[key] = digest
                        elif prior_digest != digest:
                            ignored_revisions += 1
                    except (ValueError, KeyError, IndexError, TypeError):
                        skipped += 1
                if not valid:
                    # A successful, structurally valid chart before the first
                    # regular-session minute has completed is normal warmup.
                    # Existing true gaps stay open until a completed bar arrives.
                    if received < session_open + timedelta(seconds=60):
                        return symbol, {"status": "WARMUP", "inserted": 0,
                                        "skipped": skipped, "ignored_revisions": 0,
                                        "first_bar_completes_at": (
                                            session_open + timedelta(seconds=60)).isoformat()}
                    raise ValueError("no complete valid OHLCV bars")
                if pending:
                    inserted = (await self._ingest(pending))["inserted"]
                    self.bar_hashes.update(hashes)
                await self._gap("yahoo", "CONSOLIDATED_UNVERIFIED", symbol)
                return symbol, {"status": "OK", "inserted": inserted, "skipped": skipped,
                                "ignored_revisions": ignored_revisions}
            except Exception as exc:
                reason = type(exc).__name__
                await self._gap("yahoo", "CONSOLIDATED_UNVERIFIED", symbol, reason)
                return symbol, {"status": "UNAVAILABLE", "reason": reason,
                                "inserted": inserted, "skipped": skipped}
        statuses = dict(await asyncio.gather(*(one(s) for s in self.symbols)))
        states = {s["status"] for s in statuses.values()}
        status = ("UNAVAILABLE" if "UNAVAILABLE" in states else "WARMUP" if "WARMUP" in states
                  else "NO_REGULAR_SESSION" if states == {"NO_REGULAR_SESSION"} else "OK")
        return {"status": status, "as_of": self._now().isoformat(), "source": "yahoo",
                "venue": "CONSOLIDATED_UNVERIFIED", "symbols": statuses,
                "bar_revision_policy": "FIRST_OBSERVATION_IMMUTABLE_CORRECTIONS_COUNTED"}

    async def poll_news(self) -> dict:
        async def channel_poll(channel):
            inserted, skipped, unresolved = 0, 0, 0
            pending, articles = [], {}
            try:
                items = await _call(self.news_fetcher, channel, timeout=self.timeout)
                received = self._now()
                if not isinstance(items, list):
                    raise ValueError("news response must be list")
                for item in items:
                    try:
                        publication = parsedate_to_datetime(item["published"])
                        if publication.tzinfo is None or publication > received:
                            raise ValueError("invalid news publication time")
                        if not item["link"].startswith("https://"):
                            raise ValueError("invalid news URL")
                        classification = self.classifier(item, channel)
                        # Broad-query results need either explicit index or macro relevance.
                        if not classification["material"] and not re.search(
                                r"\bSPY\b|\bQQQ\b|S&P 500|Nasdaq|stock market",
                                item["title"], re.I):
                            continue
                        for symbol in self.symbols:
                            key = channel, symbol, item["link"]
                            prior = articles.get(key, self.articles.get(key))
                            raw_digest = _hash([item, classification])
                            if prior and prior["payload"].get("raw_digest") == raw_digest:
                                continue
                            first = (min(publication, timestamp(prior["event_at"]))
                                     if prior else publication)
                            headline_key = _hash([re.sub(
                                r"\s+", " ", item["title"].casefold().strip())])
                            payload = {**classification, "title": item["title"],
                                       "url": item["link"],
                                       "event_key": (prior["payload"]["event_key"] if prior
                                                     else headline_key),
                                       "relevant_symbols": self.symbols, "raw_digest": raw_digest,
                                       "provider_published_at": publication.isoformat(),
                                       "publisher": item.get("source", ""), "raw": item}
                            payload["novelty_basis"] = "first_observation_of_event_key"
                            if prior:
                                payload["supersedes_event_id"] = prior["event_id"]
                            row = self._row("news", channel, "UNSPECIFIED", symbol, first,
                                            received, payload, _hash([key, raw_digest]))
                            validate(row)
                            pending.append(row)
                            articles[key] = row
                            unresolved += int(payload["material"] and not payload["verified"])
                    except (ValueError, KeyError, TypeError, OverflowError):
                        skipped += 1
                if items and skipped == len(items):
                    raise ValueError("all news items invalid")
                if pending:
                    inserted = (await self._ingest(pending))["inserted"]
                    self.articles.update(articles)
                for symbol in self.symbols:
                    await self._gap(channel, "UNSPECIFIED", symbol)
                return channel, {"status": "OK", "inserted": inserted, "skipped": skipped,
                                 "new_unresolved_material": unresolved}
            except Exception as exc:
                reason = type(exc).__name__
                for symbol in self.symbols:
                    await self._gap(channel, "UNSPECIFIED", symbol, reason)
                return channel, {"status": "UNAVAILABLE", "reason": reason}
        channels = dict(await asyncio.gather(*(channel_poll(c) for c in
                        ("google_news", "federal_reserve"))))
        return {"status": "OK" if all(c["status"] == "OK" for c in channels.values())
                else "UNAVAILABLE", "as_of": self._now().isoformat(), "channels": channels}
