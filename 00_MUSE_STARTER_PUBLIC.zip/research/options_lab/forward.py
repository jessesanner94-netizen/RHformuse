"""Isolated forward paper experiment. Broker access is read-only; every fill is simulated.

The production scanner, packet builder, JEV ranker, risk gates and paper accounting are
shared. Paper additions supply veto/exit evidence and confirmed RSI entry priority.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import sqlite3
import time
from datetime import UTC, date, datetime, timedelta
from functools import partial
from pathlib import Path

from research.entry_quality.context import entry_measurements
from research.entry_quality.priority import RSI_PRIORITY_POLICY, rsi_priority
from research.entry_quality.rsi_divergence import divergence_review
from research.options_lab.book_ranking import (
    BOOK_RANKING_POLICY,
    book_policy,
    book_signal,
    candidate_components,
    ranking_audit,
)
from research.options_lab.depth_exits import DEPTH_EXIT_POLICY, close_depth_exit, depth_exit_review
from research.options_lab.event_tape import (
    ReactionPolicy,
    SessionTape,
    news_reaction,
    timestamp,
)
from research.options_lab.session_expiry import EXPIRY_POLICY, paper_entry_config
from research.options_lab.zone_signals import DEFAULT_ZONE_POLICY, zone_review
from tools.config import load_config
from tools.decision_context import build_decision_packet
from tools.economic_calendar import load_calendar
from tools.jev_pipeline import evaluate_candidate
from tools.market_calendar import EASTERN, entry_allowed, session_hours
from tools.market_intelligence import collect_market_intelligence
from tools.options_lab import (
    LAB,
    ROOT,
    _hash,
    _validate_config,
    _write,
    init_experiment,
    load_experiment,
)
from tools.options_strategy import entry_locked, ledger_directory
from tools.paper_runner import _monitor_quote_requests, _refresh_map, apply_paper_decision
from tools.paper_trading import (
    _append_event,
    _exclusive_lock,
    close_paper_position,
    ensure_paper_portfolio,
    manage_paper_positions,
    paper_summary,
)
from tools.robinhood_mcp import fetch_paper_monitor_quotes, fetch_quote_refresh
from tools.scheduled_cycle import (
    _discovery_premium_ceiling,
    _merge_option_discoveries,
    _paper_entry_capacity_reached,
    _route_compact_decision_impl,
    event_account,
)
from tools.vibe_snapshot import fetch_vibe_snapshot
from tools.watchlist_discovery import run_watchlist_option_discovery

ACCOUNTS = {"paper": (True, True, True)}
POLICY = {
    "status": "UNVALIDATED_PAPER_HYPOTHESES",
    "rsi_priority": {**RSI_PRIORITY_POLICY, "mode": "WEIGHTED_RSI_PLUS_BOOK_THEN_JEV"},
    "book_ranking": BOOK_RANKING_POLICY,
    "depth_exits": DEPTH_EXIT_POLICY,
    "expiry_eligibility": EXPIRY_POLICY,
    "monitor_seconds": 10,
    "book_seconds": 10,
    "bar_seconds": 30,
    "news_seconds": 30,
    "opportunity_seconds": 300,
    "news_feed_max_age_seconds": 90,
    "unverified_pause_seconds": 120,
    "reaction": {
        "max_news_age_seconds": 180,
        "max_bar_seconds": 60,
        "min_move_bps": 5,
        "min_volume": 1000,
        "reaction_source": "yahoo",
        "reaction_venue": "CONSOLIDATED_UNVERIFIED",
    },
    "zones": {
        **DEFAULT_ZONE_POLICY,
        "book_source": "robinhood",
        "book_venue": "UNSPECIFIED",
        "bar_source": "yahoo",
        "bar_venue": "CONSOLIDATED_UNVERIFIED",
    },
}


def code_hashes():
    paths = list(LAB.glob("*.py")) + list((ROOT / "research" / "entry_quality").glob("*.py"))
    return {str(p.relative_to(ROOT)): _hash(p) for p in sorted(paths)}


def experiment_policy(value):
    """Only the new paper book-ranking knobs may differ from this version's defaults."""
    if not isinstance(value, dict):
        raise ValueError("research policy must be an object")
    expected = {**POLICY, "book_ranking": book_policy(value.get("book_ranking"))}
    if value != expected:
        raise ValueError("research policy identity changed")
    return expected


def prepare(
    name: str,
    start: date,
    *,
    carry_from: Path | None = None,
    reset_from: Path | None = None,
    book_ranking_policy: dict | None = None,
) -> Path:
    if carry_from is not None and reset_from is not None:
        raise ValueError("choose history carry or a fresh authorized strategy-version reset")
    policy = {**POLICY, "book_ranking": book_policy(book_ranking_policy)}
    experiment = init_experiment(name)
    forward = experiment / "forward"
    forward.mkdir()
    for arm in ACCOUNTS:
        target = forward / "accounts" / arm
        target.mkdir(parents=True)
        shutil.copy2(experiment / "CONFIG.md", target / "CONFIG.md")
    carry = None
    reset = None
    previous = carry_from or reset_from
    if previous is not None:
        source_config = load_config(previous / "CONFIG.md")
        target_config = load_config(experiment / "CONFIG.md")
        if source_config.values != target_config.values:
            raise ValueError("history carry requires unchanged account/risk configuration")
        source_directory = ledger_directory(previous, source_config, "paper")
        state = json.loads((source_directory / "PORTFOLIO.json").read_text())
        if state["open_positions"]:
            raise ValueError("history carry requires a flat source account")
        provenance = {
            "source_account": str(previous.resolve()),
            "portfolio_sha256": _hash(source_directory / "PORTFOLIO.json"),
            "events_sha256": _hash(source_directory / "EVENTS.jsonl"),
            "cash": state["cash"],
            "realized_pnl": state["realized_pnl"],
            "closed_trade_count": state["closed_trade_count"],
        }
        if carry_from is not None:
            destination = ledger_directory(forward / "accounts" / "paper", target_config, "paper")
            shutil.copytree(source_directory, destination)
            carry = {**provenance, "cash_or_history_reset": False}
        else:
            reset = {
                **provenance,
                "cash_or_history_reset": True,
                "new_starting_cash": target_config.get("PAPER_STARTING_CASH"),
                "authorized_at": datetime.now(UTC).isoformat(),
                "reason": "User-authorized reset for a materially revised paper strategy; "
                "prior results retained in the prior version.",
            }
        source_forward = previous.parent.parent
        if (source_forward / "shared").exists():
            shutil.copytree(source_forward / "shared", forward / "shared")
        tape_source = source_forward / "SESSION_TAPE.sqlite3"
        if tape_source.exists():
            with (
                sqlite3.connect(f"file:{tape_source.resolve()}?mode=ro", uri=True) as source_db,
                sqlite3.connect(forward / "SESSION_TAPE.sqlite3") as target_db,
            ):
                source_db.backup(target_db)
            (carry if carry is not None else reset)["session_tape_source"] = str(
                tape_source.resolve()
            )
    metadata = {
        "schema_version": 1,
        "start_date": start.isoformat(),
        "mode": "FORWARD_PAPER_ONLY",
        "accounts": ["paper"],
        "features": {
            "news_reaction": True,
            "liquidity": True,
            "supply_demand": True,
            "rsi_divergence": "STRONG_PRIORITY_NOT_REQUIRED",
            "entry_quality": "MEASURE_ONLY",
            "orderbook_exits": "DISPLAYED_DEPTH_AND_PRICE",
            "orderbook_entry_ranking": "WEIGHTED_RSI_AND_BOOK;NO_DISPLAYED_BOOK_ENTRY_VETO",
            "expiry_eligibility": "CALENDAR_2_TO_45_OR_NEXT_NYSE_SESSION;NO_0DTE",
        },
        "history_carry_forward": carry,
        "paper_strategy_reset": reset,
        "policy": policy,
        "config_sha256": _hash(experiment / "CONFIG.md"),
        "research_code_sha256": code_hashes(),
        "orders_placed": 0,
        "created_at": datetime.now(UTC).isoformat(),
    }
    for relative in metadata["research_code_sha256"]:
        target = experiment / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    _write(forward / "EXPERIMENT.json", metadata)
    manifest = json.loads((experiment / "MANIFEST.json").read_text())
    manifest.update(status="FORWARD_PAPER_PREPARED", mode="FORWARD_PAPER_ONLY")
    manifest["forward_metadata_sha256"] = _hash(forward / "EXPERIMENT.json")
    _write(experiment / "MANIFEST.json", manifest)
    return experiment


def _fresh(value, now, seconds):
    try:
        return 0 <= (now - timestamp(value)).total_seconds() <= seconds
    except (TypeError, ValueError):
        return False


def review_news(rows, symbol, held, now, policy, feed):
    """Known-direction news and a separately labeled primary-news reaction hypothesis.

    Unknown semantic direction remains unknown. An adverse observed price reaction to
    a primary publication can nevertheless trigger a paper exit; causality is not claimed.
    """
    if feed.get("status") != "OK" or not _fresh(
        feed.get("as_of"), now, policy["news_feed_max_age_seconds"]
    ):
        return {"status": "UNAVAILABLE", "action": "PAUSE_NEWS_FEED_UNAVAILABLE"}
    reaction = ReactionPolicy(**policy["reaction"])
    result = news_reaction(rows, symbol=symbol, held=held, as_of=now, policy=reaction)
    result["mode"] = "FORWARD_PAPER_ADDITION"
    result["action"] = result["proposed_action"]
    result["status"] = (
        "ALLOW" if result["action"] in {"NO_EVENT_ACTION", "REQUALIFY_DIRECTION"} else "BLOCK"
    )
    if result["action"] == "EXIT_REVIEW":
        return result
    visible = [
        r
        for r in rows
        if r["symbol"] == symbol
        and timestamp(r["available_at"]) <= now
        and timestamp(r["event_at"]) <= now
    ]
    groups = {}
    for row in visible:
        if row["kind"] == "news":
            groups.setdefault(row["payload"]["event_key"], []).append(row)
    news = []
    for copies in groups.values():
        if not _fresh(min(r["event_at"] for r in copies), now, reaction.max_news_age_seconds):
            continue
        superseded = {r["payload"].get("supersedes_event_id") for r in copies}
        active = [r for r in copies if r["event_id"] not in superseded]
        if (
            len(
                {
                    (
                        r["payload"].get("verified"),
                        r["payload"].get("material"),
                        r["payload"].get("direction"),
                    )
                    for r in active
                }
            )
            > 1
        ):
            return {"status": "BLOCK", "action": "PAUSE_REVIEW_NEWS_REVISION"}
        news.extend(
            r
            for r in active
            if r["payload"].get("material")
            and r["payload"].get("novel")
            and symbol in r["payload"].get("relevant_symbols", [])
        )
    pending_primary = False
    for item in news:
        payload = item["payload"]
        if not payload.get("verified"):
            if _fresh(item["available_at"], now, policy["unverified_pause_seconds"]):
                return {
                    "status": "BLOCK",
                    "action": "PAUSE_UNVERIFIED_MATERIAL_NEWS",
                    "event_id": item["event_id"],
                    "semantic_direction": "UNKNOWN",
                }
            continue
        if payload.get("direction") != "UNKNOWN" or held == "FLAT":
            continue
        # Pin to a genuine primary publication, rather than upgrading an aggregator.
        if payload.get("verification_basis") != "primary_publication_provenance":
            continue
        confirmed = False
        for bar in reversed(
            [
                r
                for r in visible
                if r["kind"] == "bar"
                and r["source"] == reaction.reaction_source
                and r["venue"] == reaction.reaction_venue
            ]
        ):
            b = bar["payload"]
            begin, end = timestamp(b["start_at"]), timestamp(b["end_at"])
            if (
                begin < timestamp(item["available_at"])
                or not _fresh(b["end_at"], now, reaction.max_bar_seconds)
                or (end - begin).total_seconds() > reaction.max_bar_seconds
            ):
                continue
            # Any observed gap overlapping this interval prevents a confirmation.
            gaps = {}
            for row in visible:
                if row["kind"] == "gap" and row["source"] == reaction.reaction_source:
                    gaps[row["payload"]["gap_key"]] = row["payload"]
            if any(
                timestamp(g["start_at"]) <= end
                and (g.get("end_at") is None or timestamp(g["end_at"]) > begin)
                for g in gaps.values()
            ):
                continue
            move = (float(b["close"]) / float(b["open"]) - 1) * 10000
            volume = b.get("volume")
            if not isinstance(volume, (int, float)) or volume < reaction.min_volume:
                continue
            confirmed = abs(move) >= reaction.min_move_bps
            adverse = (
                move <= -reaction.min_move_bps
                if held == "CALL"
                else (move >= reaction.min_move_bps)
            )
            if adverse:
                return {
                    "status": "BLOCK",
                    "action": "EXIT_REVIEW",
                    "signal": "PRIMARY_NEWS_PLUS_OBSERVED_ADVERSE_REACTION",
                    "semantic_direction": "UNKNOWN",
                    "causality": "UNESTABLISHED",
                    "event_id": item["event_id"],
                    "bar_id": bar["event_id"],
                    "observed_move_bps": move,
                    "publication_to_evaluation_seconds": (
                        now - timestamp(item["event_at"])
                    ).total_seconds(),
                    "receipt_to_evaluation_seconds": (
                        now - timestamp(item["received_at"])
                    ).total_seconds(),
                    "reversal_authorized": False,
                }
            if confirmed:
                break
        pending_primary = pending_primary or not confirmed
    if pending_primary:
        return {"status": "BLOCK", "action": "PAUSE_PRIMARY_NEWS_AWAITING_REACTION"}
    return result


class ForwardExperiment:
    def __init__(self, experiment: Path, *, clock=None, quotes=None, fast_quotes=None):
        self.experiment = experiment.resolve()
        if self.experiment.parent != (LAB / "experiments").resolve():
            raise ValueError("forward experiments must be inside the isolated lab")
        self.directory = self.experiment / "forward"
        self.metadata = json.loads((self.directory / "EXPERIMENT.json").read_text())
        self.clock = clock or (lambda: datetime.now(UTC))
        self.quotes = quotes or fetch_quote_refresh
        self.fast_quotes = fast_quotes or fetch_paper_monitor_quotes
        self.policy = self.metadata["policy"]
        self.roots = {name: self.directory / "accounts" / name for name in ACCOUNTS}
        self.configs = {name: load_config(root / "CONFIG.md") for name, root in self.roots.items()}
        for name, config in self.configs.items():
            _validate_config(config)
            if _hash(self.roots[name] / "CONFIG.md") != self.metadata["config_sha256"]:
                raise ValueError("paper account configuration identity changed")
        self.config = self.configs["paper"]
        self.tape = SessionTape(self.directory / "SESSION_TAPE.sqlite3")
        self.health = {}
        self.history = {}
        self.context = {}
        self.opportunity_wake = asyncio.Event()

    def guards(self):
        try:
            load_experiment(self.experiment)
            if code_hashes() != self.metadata["research_code_sha256"]:
                raise ValueError("research code changed; prepare a new experiment")
            experiment_policy(self.metadata["policy"])
            manifest = json.loads((self.experiment / "MANIFEST.json").read_text())
            if manifest.get("forward_metadata_sha256") != _hash(self.directory / "EXPERIMENT.json"):
                raise ValueError("frozen paper metadata changed")
            for root in self.roots.values():
                if _hash(root / "CONFIG.md") != self.metadata["config_sha256"]:
                    raise ValueError("paper account config changed")
            return []
        except (OSError, ValueError, KeyError) as exc:
            return [str(exc)]

    def paths(self, arm):
        directory = ledger_directory(self.roots[arm], self.configs[arm], "paper")
        return {
            "portfolio_path": directory / "PORTFOLIO.json",
            "event_log_path": directory / "EVENTS.jsonl",
        }

    def state(self, arm, now):
        return ensure_paper_portfolio(self.configs[arm], **self.paths(arm), now=now)

    def book_review(self, symbol, now):
        try:
            rows = self.tape.observations(
                symbol,
                as_of=now,
                kinds=["book", "gap"],
                since=now - timedelta(seconds=self.policy["book_ranking"]["history_seconds"]),
            )
            return book_signal(
                rows,
                symbol,
                now,
                policy=self.policy["book_ranking"],
                wall_policy=self.policy["zones"],
            )
        except Exception as exc:
            return {
                "status": "UNAVAILABLE",
                "direction": 0,
                "reason": "book_read_failure:" + type(exc).__name__,
                "evidence": {
                    "as_of": now.isoformat(),
                    "source": "robinhood",
                    "venue": "UNSPECIFIED",
                    "executed_volume_available": False,
                },
            }

    @staticmethod
    def requests(states):
        requests = {}
        for state in states:
            for request in _monitor_quote_requests(state["open_positions"]):
                prior = requests.get(request["option_id"])
                if prior and prior.get("tp_history_start") and request.get("tp_history_start"):
                    request["tp_history_start"] = min(
                        prior["tp_history_start"], request["tp_history_start"]
                    )
                requests[request["option_id"]] = request
        return list(requests.values())

    def review(self, arm, symbol, side, now, *, news_only=False):
        news, liquidity, supply = ACCOUNTS[arm]
        if not any((news, liquidity, supply)):
            return {
                "status": "ALLOW",
                "news": {"status": "DISABLED"},
                "zones": {"status": "DISABLED"},
            }
        if news_only:
            liquidity = supply = False
        horizon = max(
            self.policy["zones"]["zone_max_age_seconds"]
            + (self.policy["zones"]["displacement_lookback_bars"] + 1) * 60,
            self.policy["zones"]["liquidity_window_seconds"],
            self.policy["reaction"]["max_news_age_seconds"],
        )
        if not liquidity and not supply:
            horizon = self.policy["reaction"]["max_news_age_seconds"]
        kinds = ["gap"] + (["bar"] if news or supply else []) + (["news"] if news else [])
        rows = self.tape.observations(
            symbol, as_of=now, since=now - timedelta(seconds=horizon), kinds=kinds
        )
        result = {
            "status": "ALLOW",
            "news": {"status": "DISABLED"},
            "zones": {"status": "DISABLED"},
        }
        if news:
            result["news"] = review_news(
                rows, symbol, side, now, self.policy, self.health.get("news", {})
            )
        if liquidity or supply:
            result["zones"] = zone_review(
                rows,
                symbol,
                side,
                now,
                liquidity=False,  # Displayed depth affects ranking, never the final entry gate.
                supply_demand=supply,
                policy=self.policy["zones"],
            )
        if not news_only:
            result["book_ranking"] = {
                "entry_veto": False,
                "role": "RANKING_ONLY_DIAGNOSTIC",
                "signal": self.book_review(symbol, now),
            }
            result["rsi_divergence"] = divergence_review(
                self.tape.observations(symbol, as_of=now, kinds=["bar", "gap"]), symbol, now
            )
            result["rsi_entry_priority"] = {
                "value": rsi_priority({"option_type": side}, result["rsi_divergence"]),
                "policy": self.policy["rsi_priority"],
            }
        statuses = {result["news"]["status"], result["zones"]["status"]}
        result["status"] = (
            "UNAVAILABLE"
            if "UNAVAILABLE" in statuses
            else ("BLOCK" if "BLOCK" in statuses else "ALLOW")
        )
        return result

    async def market_context(self):
        now = self.clock()

        def calculate():
            return {
                "as_of": now.isoformat(),
                "mode": "ONE_ACCOUNT_MARKET_EVIDENCE",
                "rsi_priority_policy": self.policy["rsi_priority"],
                "symbols": {
                    symbol: {
                        side: self.review("paper", symbol, side, now) for side in ("CALL", "PUT")
                    }
                    for symbol in self.config.watchlist_symbols()
                },
            }

        self.context = await asyncio.to_thread(calculate)
        await asyncio.to_thread(_write, self.directory / "MARKET_CONTEXT.json", self.context)
        return {"status": "OK", "as_of": now.isoformat()}

    def depth_review(self, position, quote, now):
        policy = self.policy["depth_exits"]
        rows = self.tape.observations(
            position["symbol"],
            as_of=now,
            since=now - timedelta(seconds=policy["history_seconds"]),
            kinds=["book", "gap"],
        )
        return depth_exit_review(rows, position, quote, now, policy=policy)

    async def monitor(self):
        now = self.clock()
        states = {arm: self.state(arm, now) for arm in ACCOUNTS}
        requests = self.requests(states.values())
        refresh = {"option_quotes": []}
        if requests:
            try:
                refresh = await asyncio.wait_for(self.fast_quotes(requests), 8)
            except Exception as exc:
                refresh = {"option_quotes": [], "error_type": type(exc).__name__}
        now = self.clock()
        quote_map = _refresh_map(refresh)
        refresh["tp_history"] = self.history
        results = {}
        # Finish every account's original protective management before optional research.
        for arm in ACCOUNTS:
            try:
                monitor = manage_paper_positions(
                    refresh,
                    self.configs[arm],
                    **self.paths(arm),
                    now=now,
                    maximum_quote_age_seconds=20,
                )
                results[arm] = {"monitor": monitor, "news_reviews": [], "depth_exit_reviews": []}
            except Exception as exc:
                results[arm] = {
                    "monitor": {
                        "open_positions": [],
                        "attention": [
                            {"code": "paper_management_error", "error_type": type(exc).__name__}
                        ],
                    },
                    "news_reviews": [],
                    "depth_exit_reviews": [],
                }
        for arm in ACCOUNTS:
            monitor = results[arm]["monitor"]
            reviews = []
            for position in monitor["open_positions"]:
                quote = quote_map.get(position["contract_identifier"], {})
                try:
                    depth = await asyncio.to_thread(self.depth_review, position, quote, now)
                    depth_row = {"paper_id": position["paper_id"], "review": depth}
                    if depth["status"] == "OK" and depth["action"] != "HOLD":
                        depth_row["exit"] = close_depth_exit(
                            depth,
                            position,
                            quote,
                            config=self.configs[arm],
                            paths=self.paths(arm),
                            now=self.clock(),
                        )
                    results[arm]["depth_exit_reviews"].append(depth_row)
                    if depth_row.get("exit", {}).get("closed"):
                        self.opportunity_wake.set()
                        continue
                except Exception as exc:
                    results[arm]["depth_exit_reviews"].append(
                        {
                            "paper_id": position["paper_id"],
                            "status": "UNAVAILABLE",
                            "error_type": type(exc).__name__,
                        }
                    )
                if not ACCOUNTS[arm][0]:
                    continue
                try:
                    review = await asyncio.to_thread(
                        self.review,
                        arm,
                        position["symbol"],
                        position["option_type"],
                        now,
                        news_only=True,
                    )
                except Exception as exc:
                    reviews.append({"status": "UNAVAILABLE", "error_type": type(exc).__name__})
                    continue
                row = {"paper_id": position["paper_id"], "review": review}
                # Zone vetoes never displace the ordinary protective exit policy.
                if review["news"].get("action") == "EXIT_REVIEW":
                    quote = quote_map.get(position["contract_identifier"], {})
                    bid, ask = quote.get("bid_price"), quote.get("ask_price")
                    try:
                        valid = (
                            float(bid) >= 0
                            and float(ask) >= float(bid)
                            and _fresh(quote.get("updated_at"), now, 20)
                        )
                    except (TypeError, ValueError):
                        valid = False
                    if valid:
                        row["exit"] = close_paper_position(
                            position["paper_id"],
                            bid=float(bid),
                            quote_updated_at=quote["updated_at"],
                            reason="PAPER_NEWS_REACTION",
                            config=self.configs[arm],
                            **self.paths(arm),
                            now=now,
                        )
                        row["quote_to_paper_fill_seconds"] = (
                            now - timestamp(quote["updated_at"])
                        ).total_seconds()
                        # Reversal is only a future ordinary candidate; never force a flip.
                        row["reversal"] = "REQUIRES_FRESH_SCANNER_JEV_AND_ALL_ORIGINAL_GATES"
                        if row["exit"].get("closed"):
                            self.opportunity_wake.set()
                    else:
                        row["exit"] = {"closed": False, "reason": "fresh_option_bid_unavailable"}
                reviews.append(row)
            results[arm]["news_reviews"] = reviews
        self.health["monitor"] = {
            "status": "OK"
            if not any(r["monitor"].get("attention") for r in results.values())
            else "ATTENTION",
            "as_of": now.isoformat(),
            "held_contracts": len(requests),
        }
        _append_event(
            self.directory / "MONITOR.jsonl",
            {
                "as_of": now.isoformat(),
                "orders_placed": 0,
                "results": results,
                "quote_refresh": refresh,
            },
        )
        return results

    async def refresh_history(self):
        now = self.clock()
        requests = self.requests(self.state(arm, now) for arm in ACCOUNTS)
        if requests:
            result = await asyncio.wait_for(self.quotes(requests), 20)
            self.history = result.get("tp_history", {})

    async def opportunities(self):
        now = self.clock()
        errors = self.guards()
        if errors:
            return {"status": "BLOCKED", "reasons": errors}
        # Explicitly refresh only this experiment's calendar, never production state.
        calendar = load_calendar(now, self.directory / "shared")
        for root in self.roots.values():
            _write(root / "state" / "economic_calendar.json", calendar)
        if not entry_allowed(now, self.config, "DAY"):
            return {"status": "SKIPPED", "reason": "original_session_or_calendar_gate"}
        try:
            entry_config = paper_entry_config(self.config, now)
        except (ValueError, RuntimeError) as exc:
            return {
                "status": "BLOCKED",
                "reasons": ["paper_expiry_calendar_or_policy_unavailable"],
                "error_type": type(exc).__name__,
            }
        states = {arm: self.state(arm, now) for arm in ACCOUNTS}
        available = [
            s
            for s in states.values()
            if not entry_locked(s)
            and s["day"]["new_positions"] < self.config.get("MAX_NEW_POSITIONS_PER_DAY")
            and not _paper_entry_capacity_reached(
                {"portfolio": paper_summary(s), "open_positions": s["open_positions"]}, self.config
            )
        ]
        if not available:
            return {"status": "SKIPPED", "reason": "paper_account_entry_risk_or_green_lock"}
        discovery = await run_watchlist_option_discovery(
            entry_config,
            state_path=self.directory / "shared" / "watchlist_seen.json",
            premium_ceiling=max(
                _discovery_premium_ceiling(
                    event_account(
                        {},
                        {"portfolio": paper_summary(s), "open_positions": s["open_positions"]},
                        self.config,
                    ),
                    self.config,
                )
                for s in available
            ),
            commit=True,
        )
        expiry_reviews = [
            entry_config.review(c, self.clock()) for c in discovery["qualified_candidates"]
        ]
        discovery["qualified_candidates"] = [
            c
            for c, review in zip(discovery["qualified_candidates"], expiry_reviews, strict=True)
            if review["status"] == "ALLOW"
        ]
        normalized = _merge_option_discoveries({}, discovery, config=entry_config, now=self.clock())
        discovery.update(
            {key: normalized[key] for key in ("status", "wake_luna", "qualified_candidates")}
        )
        technical_cache, jev_cache, rsi_cache, rsi_ranks = {}, {}, {}, {}
        book_cache, rank_components = {}, {}
        ranking_at = None
        final_quotes = []

        def technical(symbol, **kwargs):
            if symbol not in technical_cache:
                technical_cache[symbol] = fetch_vibe_snapshot(symbol, project_root=ROOT)
            return technical_cache[symbol]

        def jev(packet, config, **kwargs):
            key = packet["candidate"]["candidate_id"]
            if key not in jev_cache:
                if len(jev_cache) >= 3:
                    return {"status": "UNAVAILABLE", "reason": "shared_three_contract_research_cap"}
                # Research is memoized for this paper account's bounded shortlist.
                jev_cache[key] = evaluate_candidate(
                    packet,
                    config,
                    project_root=self.directory / "shared",
                    now=self.clock(),
                    book_summary=kwargs.get("book_summary"),
                    calls_remaining=0,
                )
            return jev_cache[key]

        def priority(candidate):
            nonlocal ranking_at
            if ranking_at is None:
                ranking_at = self.clock()
            symbol = candidate["symbol"]
            if symbol not in rsi_cache:
                rsi_cache[symbol] = divergence_review(
                    self.tape.observations(symbol, as_of=ranking_at, kinds=["bar", "gap"]),
                    symbol,
                    ranking_at,
                )
            if symbol not in book_cache:
                book_cache[symbol] = self.book_review(symbol, ranking_at)
            value = rsi_priority(candidate, rsi_cache[symbol])
            rsi_ranks[candidate["candidate_id"]] = value
            record = candidate_components(
                candidate, rsi_cache[symbol], book_cache[symbol], policy=self.policy["book_ranking"]
            )
            rank_components[candidate["candidate_id"]] = record
            return record["total_priority"]

        # Preserve JEV's existing collector/context and call budget. Ranking reuses
        # independent recorded depth without fetching any additional market data.
        from tools.orderbook import collect_orderbooks

        books = await collect_orderbooks(
            list(self.config.watchlist_symbols()), self.directory / "shared" / "orderbook.sqlite3"
        )
        intelligence = collect_market_intelligence(
            self.config, runtime_dir=self.directory / "shared" / "runtime", commit=True
        )
        results = {}
        for arm in ACCOUNTS:
            current = self.clock()
            state = self.state(arm, current)
            if entry_locked(state):
                results[arm] = {"status": "SKIPPED", "reason": "daily_green_lock_active"}
                continue
            account = {"portfolio": paper_summary(state), "open_positions": state["open_positions"]}
            ceiling = _discovery_premium_ceiling(
                event_account({}, account, self.config), self.config
            )
            arm_discovery = {
                **discovery,
                "qualified_candidates": [
                    c
                    for c in discovery["qualified_candidates"]
                    if float(c.get("ask") or 0) * 100 <= ceiling
                ],
            }
            event = {
                "option_discovery": arm_discovery,
                "paper_portfolio": account,
                "market_intelligence": intelligence,
                "orderbooks": books,
            }
            routing = await _route_compact_decision_impl(
                event,
                config=entry_config,
                project_root=self.roots[arm],
                execute_models=True,
                packet_builder=partial(
                    build_decision_packet,
                    technical_fetcher=technical,
                    uw_fetcher=lambda *args: {"status": "DISABLED"},
                ),
                jev_evaluator=jev,
                candidate_priority=priority,
            )
            routing.pop("_jev_pending", None)
            # Log preliminary candidates too, but never add them to the router's pool.
            for candidate in arm_discovery["qualified_candidates"]:
                if candidate["candidate_id"] not in rank_components:
                    priority(candidate)
            audit = ranking_audit(routing, rank_components)
            reviews = []
            diagnostics = []
            final_expiry_reviews = []

            async def guarded_quotes(
                requests,
                selected_arm=arm,
                arm_reviews=reviews,
                entry_diagnostics=diagnostics,
                expiry_reviews=final_expiry_reviews,
            ):
                # Recheck additions AFTER routing/JEV latency, immediately before fill.
                if self.guards():
                    return {"option_quotes": [], "status": "CONFIGURATION_CHANGED"}
                selected = requests[0]
                candidate = next(
                    c
                    for c in discovery["qualified_candidates"]
                    if c["candidate_id"] == selected["option_id"]
                )
                expiry = entry_config.review(candidate, self.clock())
                expiry_reviews.append(expiry)
                if expiry["status"] != "ALLOW":
                    return {"option_quotes": [], "status": "PAPER_EXPIRY_BLOCKED"}
                review = self.review(
                    selected_arm, candidate["symbol"], candidate["option_type"], self.clock()
                )
                arm_reviews.append(review)
                if review["status"] != "ALLOW":
                    return {"option_quotes": [], "status": "RESEARCH_ADDITION_VETO"}
                refresh = await asyncio.wait_for(self.quotes(requests), 8)
                expiry = entry_config.review(candidate, self.clock())
                expiry_reviews.append(expiry)
                if expiry["status"] != "ALLOW":
                    return {"option_quotes": [], "status": "PAPER_EXPIRY_BLOCKED"}
                quote = _refresh_map(refresh).get(selected["option_id"], {})
                entry_diagnostics.append(
                    entry_measurements(
                        candidate, quote, technical_cache.get(candidate["symbol"], {}), self.clock()
                    )
                )
                final_quotes.append(
                    {
                        "arm": selected_arm,
                        "available_at": self.clock().isoformat(),
                        "refresh": refresh,
                    }
                )
                # An article received during a broker call must also be considered.
                review = self.review(
                    selected_arm, candidate["symbol"], candidate["option_type"], self.clock()
                )
                arm_reviews.append(review)
                if review["status"] != "ALLOW":
                    return {"option_quotes": [], "status": "RESEARCH_ADDITION_VETO"}
                return refresh

            entry = await apply_paper_decision(
                routing,
                event,
                entry_config,
                project_root=self.roots[arm],
                quote_fetcher=guarded_quotes,
            )
            results[arm] = {
                "routing": routing,
                "addition_reviews": reviews,
                "entry": entry,
                "entry_quality": diagnostics,
                "entry_ranking": audit,
                "final_expiry_reviews": final_expiry_reviews,
            }
        evidence = {
            "as_of": self.clock().isoformat(),
            "source": "FORWARD_OBSERVATIONS",
            "discovery": discovery,
            "expiry_eligibility": entry_config.evidence(),
            "candidate_expiry_reviews": expiry_reviews,
            "technical": technical_cache,
            "jev": jev_cache,
            "rsi_priority_evidence": rsi_cache,
            "rsi_candidate_priority": rsi_ranks,
            "book_ranking_evidence": book_cache,
            "candidate_ranking_components": rank_components,
            "ranking_as_of": ranking_at.isoformat() if ranking_at else None,
            "orderbooks": books,
            "economic_calendar": calendar,
            "final_quotes": final_quotes,
            "results": results,
            "orders_placed": 0,
            "codex_calls": 0,
        }
        _append_event(self.directory / "OPPORTUNITIES.jsonl", evidence)
        return {"status": "OK", "as_of": evidence["as_of"], "jev_contracts": len(jev_cache)}

    def report(self):
        now = self.clock()
        result = {
            "as_of": now.isoformat(),
            "mode": "FORWARD_PAPER_ONLY",
            "orders_placed": 0,
            "start_date": self.metadata["start_date"],
            "health": self.health,
            "entry_blockers": self.guards(),
            "account": paper_summary(self.state("paper", now)),
            "features": self.metadata["features"],
            "orderbook_exit_policy": self.policy["depth_exits"],
            "orderbook_entry_ranking_policy": self.policy["book_ranking"],
            "expiry_eligibility_policy": self.policy["expiry_eligibility"],
            "market_context_path": str(self.directory / "MARKET_CONTEXT.json"),
            "incremental_ai_data_cost": None,
            "economic_profit": None,
            "limitations": [
                "Unvalidated paper hypotheses; no profitability claim.",
                "Quotes use modeled ask/bid fills and original costs, not actual executions.",
                "One paper account; at most three unique JEV contracts per scan.",
                "News RSS and completed minute bars do not guarantee ten-second reaction.",
                "Depth coverage unspecified; no trade prints, aggressor flow or absorption.",
            ],
        }
        _write(self.directory / "STATUS.json", result)
        return result

    async def run(self):
        from research.options_lab.forward_feeds import ForwardFeeds

        feeds = ForwardFeeds(self.tape, list(self.config.watchlist_symbols()))

        def active():
            now = self.clock()
            local = now.astimezone(EASTERN)
            hours = session_hours(local.date())
            # Capture before entry admission; retain monitoring if any paper position remains.
            return (
                local.date() >= date.fromisoformat(self.metadata["start_date"])
                and hours
                and hours[0] - timedelta(minutes=5) <= now <= hours[1] + timedelta(minutes=10)
            )

        async def loop(name, interval, action, *, in_thread=False):
            while True:
                started = time.monotonic()
                try:
                    if (
                        name == "report"
                        or active()
                        or (
                            name in {"monitor", "history"}
                            and any(
                                self.state(arm, self.clock())["open_positions"] for arm in ACCOUNTS
                            )
                        )
                    ):
                        value = (
                            await asyncio.to_thread(lambda: asyncio.run(action()))
                            if in_thread
                            else await action()
                        )
                        if isinstance(value, dict) and name != "monitor":
                            self.health[name] = {**value, "as_of": self.clock().isoformat()}
                    else:
                        self.health[name] = {
                            "status": "WAITING_FOR_SESSION",
                            "as_of": self.clock().isoformat(),
                        }
                except Exception as exc:
                    self.health[name] = {
                        "status": "ERROR",
                        "error_type": type(exc).__name__,
                        "as_of": self.clock().isoformat(),
                    }
                    _append_event(
                        self.directory / "ERRORS.jsonl", {"task": name, **self.health[name]}
                    )
                elapsed = time.monotonic() - started
                self.health.setdefault(name, {})["cycle_seconds"] = round(elapsed, 3)
                if name == "opportunities":
                    try:
                        # Match the production five-minute opportunity cadence at :15.
                        delay = 300 - ((self.clock().timestamp() - 15) % 300)
                        await asyncio.wait_for(self.opportunity_wake.wait(), max(1, delay))
                        self.opportunity_wake.clear()
                    except TimeoutError:
                        pass
                else:
                    await asyncio.sleep(max(1, interval - elapsed))

        async def report_action():
            self.report()
            return {"status": "OK"}

        with _exclusive_lock(self.directory / "OWNER"):
            await asyncio.gather(
                loop("monitor", 10, self.monitor),
                loop("books", 10, feeds.poll_books),
                loop("news", 30, feeds.poll_news),
                loop("bars", 30, feeds.poll_context),
                loop("context", 60, self.market_context),
                loop("history", 60, self.refresh_history),
                loop("opportunities", 300, self.opportunities, in_thread=True),
                loop("report", 10, report_action),
            )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    initialize = sub.add_parser("prepare")
    initialize.add_argument("--name", required=True)
    initialize.add_argument("--start-date", type=date.fromisoformat, required=True)
    initialize.add_argument("--carry-from", type=Path)
    initialize.add_argument("--reset-from", type=Path)
    initialize.add_argument(
        "--book-ranking-policy",
        type=Path,
        help="JSON overrides for this version's frozen paper ranking policy",
    )
    for mode in ("run", "status", "probe"):
        command = sub.add_parser(mode)
        command.add_argument("--experiment", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        print(
            prepare(
                args.name,
                args.start_date,
                carry_from=args.carry_from,
                reset_from=args.reset_from,
                book_ranking_policy=json.loads(args.book_ranking_policy.read_text())
                if args.book_ranking_policy
                else None,
            )
        )
        return
    bot = ForwardExperiment(args.experiment)
    if args.command == "run":
        asyncio.run(bot.run())
    elif args.command == "probe":
        from research.options_lab.forward_feeds import ForwardFeeds

        async def probe():
            feeds = ForwardFeeds(bot.tape, list(bot.config.watchlist_symbols()))
            results = await asyncio.gather(
                feeds.poll_books(), feeds.poll_context(), feeds.poll_news(), return_exceptions=True
            )
            print(
                json.dumps(
                    {
                        name: value
                        if isinstance(value, dict)
                        else {"status": "ERROR", "error_type": type(value).__name__}
                        for name, value in zip(("books", "bars", "news"), results, strict=True)
                    }
                )
            )

        asyncio.run(probe())
    else:
        print(json.dumps(bot.report(), indent=2))


if __name__ == "__main__":
    main()
