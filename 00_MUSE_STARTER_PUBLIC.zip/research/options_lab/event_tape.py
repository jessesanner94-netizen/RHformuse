"""Offline session recorder and news/reaction research; no execution or network clients."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sqlite3
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from tools.orderbook import book_features, parse_level2_book

ET = ZoneInfo("America/New_York")
KINDS = {"book", "trade", "trade_cancel", "bar", "news", "gap"}


def timestamp(value: Any) -> datetime:
    if not isinstance(value, str):
        raise ValueError("timestamp must be an ISO string")
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("timestamp needs timezone")
    return result.astimezone(UTC)


def number(value: Any, *, positive: bool = True) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("number must be numeric, not bool or string")
    result = float(value)
    if not math.isfinite(result) or (result <= 0 if positive else result < 0):
        raise ValueError("invalid numeric value")
    return result


def validate(row: Mapping[str, Any]) -> dict[str, Any]:
    value = dict(row)
    json.dumps(value, allow_nan=False)
    if value.get("schema_version") != 1 or value.get("kind") not in KINDS:
        raise ValueError("unsupported event schema or kind")
    for key in ("source", "venue", "symbol", "event_id"):
        if not isinstance(value.get(key), str) or not value[key].strip():
            raise ValueError(f"{key} is required")
    value["symbol"] = value["symbol"].upper()
    event, received, available = (timestamp(value.get(k)) for k in
                                  ("event_at", "received_at", "available_at"))
    if not event <= received <= available:
        raise ValueError("event_at <= received_at <= available_at required")
    value["session"] = available.astimezone(ET).date().isoformat()
    payload = value.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    kind = value["kind"]
    if kind == "book":
        if payload.get("symbol") != value["symbol"]:
            raise ValueError("book symbol mismatch")
        if timestamp(payload.get("updated_at")) != event:
            raise ValueError("book event timestamp mismatch")
        parse_level2_book(payload, now=received)
    elif kind == "trade":
        number(payload.get("price"))
        number(payload.get("quantity"))
        if payload.get("aggressor_side", "unknown") not in {"buy", "sell", "unknown"}:
            raise ValueError("invalid aggressor_side")
        if payload.get("aggressor_side", "unknown") != "unknown" and (
            payload.get("side_basis") != "provider"
        ):
            raise ValueError("classified aggressor side requires explicit provider evidence")
    elif kind == "trade_cancel":
        if not isinstance(payload.get("trade_id"), str) or not payload["trade_id"]:
            raise ValueError("trade_cancel requires original trade_id")
    elif kind == "bar":
        start, end = timestamp(payload.get("start_at")), timestamp(payload.get("end_at"))
        if not start < end <= event:
            raise ValueError("bar must be completed at event_at")
        prices = {key: number(payload.get(key)) for key in ("open", "high", "low", "close")}
        if not prices["low"] <= min(prices["open"], prices["close"]) <= max(
            prices["open"], prices["close"]
        ) <= prices["high"]:
            raise ValueError("invalid bar OHLC")
        if payload.get("volume") is not None:
            number(payload["volume"], positive=False)
    elif kind == "news":
        for key in ("event_key", "title", "url", "classification_method"):
            if not isinstance(payload.get(key), str) or not payload[key].strip():
                raise ValueError(f"news needs {key}")
        if not payload["url"].startswith("https://"):
            raise ValueError("news source URL must be https")
        if payload.get("direction") not in {"BULLISH", "BEARISH", "UNKNOWN"}:
            raise ValueError("invalid news direction")
        if any(not isinstance(payload.get(k), bool) for k in ("verified", "material", "novel")):
            raise ValueError("news verification/materiality/novelty must be explicit")
        if not isinstance(payload.get("relevant_symbols"), list) or any(
            not isinstance(s, str) for s in payload["relevant_symbols"]
        ):
            raise ValueError("news requires explicit relevant_symbols")
        if payload.get("supersedes_event_id") is not None and not isinstance(
            payload["supersedes_event_id"], str
        ):
            raise ValueError("news supersedes_event_id must be a string")
    elif kind == "gap":
        start = timestamp(payload.get("start_at"))
        end = timestamp(payload["end_at"]) if payload.get("end_at") is not None else None
        if start > event or (end is not None and not start < end <= event):
            raise ValueError("gap interval must be known at event_at")
        if not isinstance(payload.get("gap_key"), str) or not payload["gap_key"]:
            raise ValueError("gap needs a stable gap_key for recovery updates")
    return value


class SessionTape:
    """Append-only full-session research archive; ingestion is explicitly invoked."""

    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(path) as con:
            con.execute("""CREATE TABLE IF NOT EXISTS events (
                session TEXT, source TEXT, venue TEXT, symbol TEXT, kind TEXT, event_id TEXT,
                event_epoch REAL, available_epoch REAL, identity_hash TEXT, record TEXT,
                PRIMARY KEY(session, source, venue, symbol, kind, event_id))""")
            con.execute("CREATE INDEX IF NOT EXISTS events_asof ON events(session, symbol, "
                        "available_epoch, event_epoch)")

    def ingest(self, rows: Sequence[Mapping[str, Any]]) -> dict[str, int]:
        validated = [validate(row) for row in rows]
        inserted = duplicates = 0
        with sqlite3.connect(self.path) as con:
            for row in validated:
                identity = json.dumps({"event_at": row["event_at"], "payload": row["payload"]},
                                      sort_keys=True, separators=(",", ":"))
                digest = hashlib.sha256(identity.encode()).hexdigest()
                key = tuple(row[k] for k in ("session", "source", "venue", "symbol", "kind",
                                             "event_id"))
                prior = con.execute("SELECT identity_hash FROM events WHERE session=? AND "
                                    "source=? AND venue=? AND symbol=? AND kind=? AND event_id=?",
                                    key).fetchone()
                if prior:
                    if prior[0] != digest:
                        raise ValueError("event identity changed; use an explicit new revision ID")
                    duplicates += 1
                    continue
                con.execute("INSERT INTO events VALUES (?,?,?,?,?,?,?,?,?,?)", (
                    *key, timestamp(row["event_at"]).timestamp(),
                    timestamp(row["available_at"]).timestamp(), digest,
                    json.dumps(row, sort_keys=True, allow_nan=False),
                ))
                inserted += 1
        return {"inserted": inserted, "duplicates": duplicates}

    def observations(self, symbol: str, *, as_of: datetime,
                     since: datetime | None = None,
                     kinds: Sequence[str] | None = None) -> list[dict[str, Any]]:
        if as_of.tzinfo is None:
            raise ValueError("as_of needs timezone")
        selected = tuple(kinds) if kinds is not None else tuple(KINDS)
        if not selected or set(selected) - KINDS:
            raise ValueError("invalid observation kinds")
        with sqlite3.connect(self.path) as con:
            rows = con.execute("SELECT record FROM events WHERE session=? AND symbol=? "
                               "AND available_epoch<=? AND event_epoch<=? "
                               "AND (event_epoch>=? OR kind='gap') "
                               f"AND kind IN ({','.join('?' for _ in selected)}) "
                               "ORDER BY available_epoch,event_epoch,event_id", (
                                   as_of.astimezone(ET).date().isoformat(), symbol.upper(),
                                   as_of.timestamp(), as_of.timestamp(),
                                   since.timestamp() if since is not None else 0,
                                   *selected,
                               )).fetchall()
        return [json.loads(row[0]) for row in rows]


def flow_features(rows: Sequence[Mapping[str, Any]], *, as_of: datetime) -> dict[str, Any]:
    """Separate each feed/venue; displayed liquidity never becomes executed volume."""
    groups = defaultdict(list)
    for row in rows:
        if timestamp(row["available_at"]) <= as_of and timestamp(row["event_at"]) <= as_of:
            groups[(row["symbol"], row["source"], row["venue"])].append(row)
    results = []
    for (symbol, source, venue), observations in groups.items():
        books = [r for r in observations if r["kind"] == "book"]
        cancelled = {r["payload"]["trade_id"] for r in observations
                     if r["kind"] == "trade_cancel"}
        trades = [r for r in observations if r["kind"] == "trade"
                  and r["event_id"] not in cancelled]
        profile = defaultdict(float)
        unknown = signed = 0.0
        for row in trades:
            trade = row["payload"]
            quantity = float(trade["quantity"])
            profile[str(trade["price"])] += quantity
            side = trade.get("aggressor_side", "unknown")
            if side == "unknown":
                unknown += quantity
            else:
                signed += quantity if side == "buy" else -quantity
        result = {"symbol": symbol, "source": source, "venue": venue,
                  "book_snapshots": len(books),
                  "trade_prints": len(trades), "coverage": "UNVERIFIED_FEED_COVERAGE",
                  "gap_events": sum(r["kind"] == "gap" for r in observations),
                  "observed_volume_at_price": dict(profile), "unknown_side_volume": unknown,
                  "known_signed_volume": signed,
                  "cvd": signed if trades and unknown == 0 else None,
                  "absorption": "UNAVAILABLE_UNVALIDATED", "exhaustion": "UNAVAILABLE_UNVALIDATED"}
        if books:
            # Late arrival must not replace a fresher provider book in a replay.
            books.sort(key=lambda r: timestamp(r["event_at"]))
            latest = books[-1]
            age = (as_of - timestamp(latest["event_at"])).total_seconds()
            result["book_age_seconds"] = age
            result["book_status"] = "FRESH" if age <= 30 else "STALE"
            parsed = [parse_level2_book(r["payload"], now=timestamp(r["received_at"]))
                      for r in books]
            current = book_features(parsed[-1])
            result["current_displayed_depth"] = current
            result["max_snapshot_gap_seconds"] = max((
                (b.updated_at - a.updated_at).total_seconds()
                for a, b in zip(parsed, parsed[1:], strict=False)
            ), default=None)
            zones = {}
            for book in parsed:
                for side, levels in (("bid", book.bids), ("ask", book.asks)):
                    for level in levels:
                        zone = zones.setdefault((side, level.price), {
                            "side": side, "price": level.price, "samples": 0,
                            "first_seen": book.updated_at.isoformat(),
                            "max_displayed_quantity": 0,
                        })
                        zone["samples"] += 1
                        zone["last_seen"] = book.updated_at.isoformat()
                        zone["max_displayed_quantity"] = max(
                            zone["max_displayed_quantity"], level.quantity)
            result["displayed_zones"] = sorted(zones.values(), key=lambda z: (
                -z["max_displayed_quantity"], z["side"], z["price"]
            ))[:12]
        results.append(result)
    return {"feeds": results, "meaning": "Feed-local observations; no order intent inferred."}


@dataclass(frozen=True)
class ReactionPolicy:
    """Explicit research parameters, never imported into production policy."""

    max_news_age_seconds: float
    max_bar_seconds: float
    min_move_bps: float
    min_volume: float
    reaction_source: str
    reaction_venue: str

    def __post_init__(self):
        for key in ("max_news_age_seconds", "max_bar_seconds", "min_move_bps", "min_volume"):
            number(getattr(self, key))
        if any(not isinstance(value, str) or not value.strip() for value in
               (self.reaction_source, self.reaction_venue)):
            raise ValueError("pin the reaction source and venue explicitly")


def news_reaction(
    rows: Sequence[Mapping[str, Any]], *, symbol: str, held: str,
    as_of: datetime, policy: ReactionPolicy,
) -> dict[str, Any]:
    if held not in {"CALL", "PUT", "FLAT"}:
        raise ValueError("held must be CALL, PUT or FLAT")
    symbol = symbol.upper()
    rows = [r for r in rows if r["symbol"] == symbol
            and timestamp(r["available_at"]) <= as_of and timestamp(r["event_at"]) <= as_of]
    # A syndicated copy cannot reset first knowledge or create another catalyst.
    groups = defaultdict(list)
    for row in rows:
        if row["kind"] == "news":
            groups[row["payload"]["event_key"]].append(row)
    news = []
    revision_conflict = False
    for copies in groups.values():
        first_publication = min(timestamp(r["event_at"]) for r in copies)
        if not 0 <= (as_of - first_publication).total_seconds() <= policy.max_news_age_seconds:
            continue
        copies.sort(key=lambda r: timestamp(r["available_at"]))
        active = copies
        for index, row in enumerate(copies):
            supersedes = row["payload"].get("supersedes_event_id")
            if supersedes:
                if row["payload"]["verified"] is not True or not any(
                    prior["event_id"] == supersedes for prior in copies[:index]
                ):
                    revision_conflict = True
                    active = []
                    break
                active = copies[index:]
        verified = [r for r in active if r["payload"]["verified"] is True
                    and symbol in r["payload"]["relevant_symbols"]]
        if len({r["payload"]["direction"] for r in verified
                if r["payload"]["direction"] != "UNKNOWN"}) > 1 or len({
                    r["payload"]["material"] for r in verified}) > 1:
            revision_conflict = True
            continue
        eligible = [r for r in active if all(r["payload"].get(k) is True for k in
                    ("verified", "material", "novel")) and
                    symbol in r["payload"]["relevant_symbols"] and
                    r["payload"]["direction"] != "UNKNOWN"]
        if eligible:
            news.append(min(eligible, key=lambda r: timestamp(r["available_at"])))
    result = {"mode": "OFFLINE_SHADOW_RESEARCH", "proposed_action": "NO_EVENT_ACTION",
              "orders_placed": 0, "paper_fill": None, "reversal_authorized": False,
              "policy": asdict(policy)}
    if revision_conflict:
        return {**result, "proposed_action": "PAUSE_REVIEW_NEWS_REVISION"}
    if not news:
        return result
    if len({r["payload"]["direction"] for r in news}) > 1:
        return {**result, "proposed_action": "PAUSE_REVIEW_CONFLICTING_EVENTS"}
    event = max(news, key=lambda r: timestamp(r["available_at"]))
    direction = event["payload"]["direction"]
    desired = "PUT" if direction == "BEARISH" else "CALL"
    result.update(event_key=event["payload"]["event_key"], direction=direction,
                  proposed_action="PAUSE_NEW_ENTRIES_REVIEW_EVENT")
    bars = [r for r in rows if r["kind"] == "bar"
            and r["source"] == policy.reaction_source and r["venue"] == policy.reaction_venue
            and timestamp(r["payload"]["start_at"]) >= timestamp(event["available_at"])
            and 0 < (timestamp(r["payload"]["end_at"]) - timestamp(
                r["payload"]["start_at"])).total_seconds() <= policy.max_bar_seconds
            and (as_of - timestamp(r["payload"]["end_at"])).total_seconds()
            <= policy.max_bar_seconds]
    # A recorded data gap after this event precludes confirmation for its feed.
    gaps = {}
    for row in sorted(rows, key=lambda r: timestamp(r["available_at"])):
        if row["kind"] == "gap":
            gaps[(row["source"], row["venue"], row["payload"]["gap_key"])] = row
    for bar in sorted(bars, key=lambda r: timestamp(r["available_at"]), reverse=True):
        payload = bar["payload"]
        overlap = any(
            row["source"] == bar["source"] and row["venue"] == bar["venue"] and
            timestamp(row["payload"]["start_at"]) < timestamp(payload["end_at"]) and
            (row["payload"].get("end_at") is None or
             timestamp(row["payload"]["end_at"]) > timestamp(payload["start_at"]))
            for row in gaps.values()
        )
        if overlap or payload.get("volume") is None:
            continue
        move = (payload["close"] / payload["open"] - 1) * 10000
        if ((direction == "BEARISH" and move <= -policy.min_move_bps)
            or (direction == "BULLISH" and move >= policy.min_move_bps)) and (
            payload["volume"] >= policy.min_volume
        ):
            observed_delay = (timestamp(bar["available_at"]) - timestamp(
                event["available_at"])).total_seconds()
            result.update(
                proposed_action="EXIT_REVIEW" if held not in {desired, "FLAT"} else
                "REQUALIFY_DIRECTION", opposite_side_candidate=desired,
                confirmation_source=bar["source"], confirmation_venue=bar["venue"],
                confirmation_move_bps=move, event_to_received_seconds=(
                    timestamp(event["received_at"]) - timestamp(event["event_at"])
                ).total_seconds(), received_to_classified_seconds=(
                    timestamp(event["available_at"]) - timestamp(event["received_at"])
                ).total_seconds(), classified_to_confirmation_seconds=observed_delay,
                classified_to_evaluation_seconds=(as_of - timestamp(
                    event["available_at"])).total_seconds(),
                decision_evaluated_within_ten_seconds_from_classification=(as_of - timestamp(
                    event["available_at"])).total_seconds() <= 10,
                confirmation_available_within_ten_seconds_from_classification=observed_delay <= 10,
                execution_latency_seconds=None,
                remaining_gates="Fresh exact option quotes, exit confirmation, risk, "
                "calendar, direction, contract eligibility and current daily entry locks.",
            )
            break
    return result


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    ingest = commands.add_parser("ingest")
    ingest.add_argument("--input", type=Path, required=True)
    evaluate = commands.add_parser("evaluate")
    evaluate.add_argument("--symbol", choices=["SPY", "QQQ"], required=True)
    evaluate.add_argument("--held", choices=["CALL", "PUT", "FLAT"], required=True)
    evaluate.add_argument("--as-of", required=True)
    evaluate.add_argument("--policy", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        store = SessionTape(args.db)
        if args.command == "ingest":
            rows = [json.loads(line) for line in args.input.read_text().splitlines()
                    if line.strip()]
            result = store.ingest(rows)
        else:
            now = timestamp(args.as_of)
            policy = ReactionPolicy(**json.loads(args.policy.read_text()))
            rows = store.observations(args.symbol, as_of=now)
            result = {"flow": flow_features(rows, as_of=now), "news": news_reaction(
                rows, symbol=args.symbol, held=args.held, as_of=now, policy=policy)}
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except (ValueError, TypeError, KeyError, OSError, sqlite3.Error) as exc:
        print(json.dumps({"status": "BLOCKED", "reason": str(exc)}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
