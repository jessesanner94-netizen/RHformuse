# One paper bot, one account

October 22 correction: the user wants one paper clone with additive research
features. The earlier five simulated accounts were an implementation mistake.
Only `options-lab-paper.service` runs, now with one `paper` account under
the version identified by `CURRENT.json`.

The October25 next-session expiration update carries the same paper account
forward again without resetting funds, history or P&L. Contracts expiring on the
next scheduled NYSE session join the existing 2–45 calendar-DTE range; 0DTE stays
blocked. All other gates and book ranking stay unchanged. See
`NEXT_SESSION_EXPIRY.md` for the calendar examples, derived paper config and checks.

The October25 entry-ranking update carries this account forward without resetting
funds or outcomes. The old depth_exits_20261023 frozen evidence and ledgers remain.
Displayed book behavior now contributes positive and negative ranking weight,
combined with RSI before JEV ties. Persistent opposing walls give a bounded
penalty; stale/missing/unavailable depth is neutral and never a new fill veto.
See `BOOK_ENTRY_RANKING.md` for the exact workflow trace, settings and limitations.

The October23 exit update carries the same account forward: at deployment,
[account details redacted]
The portfolio and event log were copied byte-identically; no funds, daily risk
state, research budgets or historical outcomes were reset for this release.
`forward/DEPLOYMENT_VALIDATION.json` preserves source and deployment evidence.
Evaluate the new exit feature only on outcomes after its activation; carried
trades are historical account results, not performance of the new exit rule.

On October22 the user authorized a fresh paper account for a material strategy
revision. That `rsi_priority_20261022` version began with $369 and zero P&L. Its
predecessor `single_paper_20261022` retains its complete ledger: the earlier SPY758 put,
-$43.10 modeled net loss and $325.90 ending cash. Its portfolio and event-log
hashes are preserved in `forward/RESET_VALIDATION.json`. No prior loss is deleted.
The four original comparison accounts also remain retired archives. Their results
are never combined with this account. The live strategy and core policies are unchanged.

For the current eligibility update the user explicitly requires carrying the
existing account forward without resetting its money or P&L. Always preserve the
prior ledger and source identity. Research/data-call budgets, caches and the
recorded session tape carry forward across version changes.

## Additions inside this bot

- News plus observed price/volume reaction, with fresh option-bid paper exits.
- Persistent displayed order-book support/pressure, with direction confirmed by
  midpoint movement; thin depth can amplify confirmed direction. An opposing wall
  only lowers rank. Displayed book data has no standalone entry trigger or veto.
- Confirmed displayed-depth pressure plus a price move can take early profit at
  least20% net after modeled costs, or exit defensively on adverse pressure.
  Original protective exits run first. See `DEPTH_EXITS.md` for the exact hypothesis,
  data requirements and replay semantics. No executed-volume signal is invented.
- Supply/demand zones calculated directly from completed OHLCV arrays. Drawing
  a chart is unnecessary. Zone price ranges come from a base candle preceding
  a completed displacement with increased volume; later closes can invalidate them.
- RSI14 on completed one-minute candles, with regular and hidden bullish/bearish
  divergence detection. A pivot requires two candles on each side. Confirmation
  and availability timestamps are explicit; a signal is never backdated to the
  pivot. Following the user's explicit choice, confirmed supporting divergence
  contributes +4/0/-4 to otherwise-qualified shortlisted candidates. Add the bounded
  book score [-5,+5], then use original JEV scores and stable Python order for ties.
  Divergence is not required. Missing/conflicting RSI is neutral;
  required JEV, risk, data, session and research gates still apply. Raw JEV scores
  are retained. This is a testable priority rule, not a calibrated probability.
- Entry-quality measurements: original qualified ask, refreshed ask, premium
  movement during processing, and completed-candle/VWAP/level context. An earlier
  quote is a reference observation, not a promised attainable fill. No extra bot,
  account or hard-coded entry delay is introduced.

Regular bearish divergence is price making a higher high while RSI makes a
lower high. These patterns are defined, but their profitability for this strategy
has not been established. [Fidelity's RSI guide](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/RSI)
describes price highs/lows unconfirmed by RSI as divergence; it does not establish
this bot's expectancy.

## Bar-data correction

At09:30:23, the first one-minute candle was legitimately unfinished. The old
collector called this an outage; that warmup interval then vetoed supply/demand
entries even after the actual completed candles arrived. A valid preopen or
first-minute response now reports `WARMUP`. Genuine transport/invalid-data failures
still create gaps. Capture uses only the current NYSE regular session, including
calendar early closes.

A recovered transport interval is usable only when actual completed, available
bars cover it. Open outages, absent bars, missing volume and stale data still fail
closed. Applied at the original09:50 evaluation timestamp, the corrected coverage
check recognizes the20 actual completed bars instead of inventing missing data.
This is a retrospective data-validation check, not a rewritten trade or P&L result.

## October22 entry comparison

[account details redacted]
10:03:11ET for$1.17: -$41 gross, -$43.10 with modeled costs. Its qualified quote
had been$1.52; the subsequent6-cent ask change is measurable and does not prove
a$1.52 fill was obtainable when ready.

The live ledger records two earlier rejected submissions, followed by SPY Oct26
$760 PUT filled at10:02:12ET for$1.55 and sold at10:14:52ET for$2.03: +$48 gross,
+$45.90 after the project's modeled costs. Timing and contract strike both changed,
so this is not a controlled estimate of delaying the original $758-put trade.

The new strict one-minute RSI detector finds no confirmed recent divergence at
the live entry timestamp in the recorded Yahoo data. That does not identify the
timeframe/settings on the user's chart or invalidate the visual observation;
confirmation timing and indicator definitions must match before comparing them.

## Status and records

`research/options_lab/CURRENT.json` identifies the active experiment.
`forward/STATUS.json` presents one account; `MARKET_CONTEXT.json` records liquidity,
supply/demand, confirmed RSI evidence and its directional entry priority. Opportunity
records include entry-quality measurements and candidate priority values. The
archived October22 morning observations and ledger remain intact.
Missing/late observations cannot create hypothetical fills.

Retrospective results live separately under `research/entry_quality/replays/`.
[account details redacted]
The October22 archive has seven complete opportunity snapshots, roughly09:50–10:20ET;
it does not provide a full session of candidate discovery. Replay preserves quote
availability, confirmed-candle timing, actual gap records and original costs.

The service retains its10-second monitoring target,30-second news/minute-bar checks,
five-minute original opportunity cadence and existing risk/session/green-lock gates.
RSS/minute bars cannot guarantee10-second news reaction. The service explicitly
unsets `NTFY_TOPIC`, and paper code sends no phone notifications.


The completed October22 recorded-quote replay still selects the758PUT at1.58 and
stops at1.17: -43.10 modeled net. No confirmed RSI divergence exists at entry and
corrected zones allow it. Missing quote/monitor/news-health evidence prevents a
verified complete-day P&L claim; report status is INSUFFICIENT_DATA. Details:
`research/entry_quality/replays/20261022_rsi_priority/RESULTS.md`.
The active forward account is separate. Its restart depth warmup cleared11:26:56ET.
