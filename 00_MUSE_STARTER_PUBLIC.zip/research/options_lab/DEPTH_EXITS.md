# Paper exits from displayed depth pressure

User authorized October23, 2026. Favorable confirmed pressure can take profit
only at **20% net gain on premium paid, after both modeled execution costs**.
Adverse confirmed pressure can close early at a loss, breakeven or a smaller gain.
It never widens or delays the original stop. This is an unvalidated experiment.

The available Robinhood feed supplies displayed resting bids/asks. It does not
supply executed buy/sell volume or verified aggressor-side prints. Depth pressure
plus an observed price move is the explicitly labeled proxy tested here.

## Initial deterministic hypothesis

- Pin the existing Robinhood/UNSPECIFIED source and venue; retain the coverage limit.
- Sum the nearest five levels per side. Compare with the median earlier depth
  from at most180seconds, excluding the latest30seconds from the baseline.
  Require at least six baseline samples spanning60seconds.
- Require at least3x baseline size, at least1000 displayed shares, and at least70%
  of combined near depth on that side. Both of the two latest observations must
  qualify, at least10seconds apart and within30seconds. One snapshot is insufficient.
- Require the midpoint to move at least2basis points in the same direction from
  the last baseline midpoint. Bid/up is favorable to calls and adverse to puts;
  ask/down is favorable to puts and adverse to calls.
- Confirmation must occur after entry. Reject stale, conflicting, future, missing,
  crossed, one-sided or gapped depth. Never substitute another feed or past session.
- Use a fresh bid for the exact held option, timestamped at/after the latest
  confirming book observation and no more than20seconds old. No historical fill.

For a $110 premium and $2.10 round-trip costs,20% net means at least$22 net,
or $134.10 gross proceeds. A $1.34 bid misses the threshold; $1.35 meets it.
Stored entry/exit cost estimates determine each position's actual calculation.
These thresholds are research inputs; their profitability is not established.

## Integration and evidence

Every10-second paper monitoring cycle runs original protective management first.
Only surviving positions receive the optional depth review, followed by the
existing news review. A depth failure cannot interrupt a hard exit or news exit.
Normal30% gross target,25% stop, holding deadline, costs and daily risk/green locks
remain. A conditional early exit can change realized reward/risk; the original
entry gate is a plan at its original target, not a promise of realized reward.

MONITOR.jsonl records `depth_exit_reviews`, the policy, baseline/spike ratios,
price confirmation, quote time, net profit and any simulated exit result. Reasons
are `PAPER_DEPTH_SPIKE_TAKE_PROFIT` or `PAPER_DEPTH_SPIKE_DEFENSIVE_EXIT`. The shared
paper ledger commits costs and the daily green lock. A close wakes ordinary
requalification; it never forces a flip or a new trade.

The offline replay uses the same reviewer and close adapter. Missing required
depth evidence while held makes its result incomplete. Saved outcomes are never
silently reinterpreted using this version. No model, paid feed or extra quote
request is added. One active account and phone-notification suppression remain.
The live bot and core policy files are unchanged.
