"""Paper-only next-session expiration admission; DTE always means calendar days."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta

from tools.config import TradingConfig
from tools.market_calendar import EASTERN, session_hours

EXPIRY_POLICY = {
    "mode": "CALENDAR_RANGE_OR_NEXT_NYSE_SESSION",
    "calendar": "NYSE",
    "regular_min_calendar_dte": 2,
    "max_calendar_dte": 45,
    "same_day_expiry_allowed": False,
    "dte_reporting": "CALENDAR_DAYS_UNCHANGED",
    "scope": "PAPER_DAY_ENTRIES_ONLY",
}


def next_session_date(now: datetime) -> date:
    """First scheduled NYSE session strictly after the current Eastern date."""
    if now.tzinfo is None:
        raise ValueError("expiration admission requires a timezone-aware decision time")
    today = now.astimezone(EASTERN).date()
    # Reuse the entry/deadline calendar, including holidays and special closures.
    for offset in range(1, 32):
        day = today + timedelta(days=offset)
        if session_hours(day) is not None:
            return day
    raise ValueError("next NYSE session unavailable within 31 calendar days")


@dataclass(frozen=True, kw_only=True)
class PaperExpiryConfig(TradingConfig):
    """Keep frozen on-disk values for identity checks; expose two derived DTE floors.

    Only used by the paper opportunity cycle. The floor is 1 only when tomorrow
    really is the next scheduled session. Across closures the original floor of
    2 already includes the next session's calendar DTE. No other getter changes.
    """

    decision_date: date
    next_session: date

    def get(self, name, default=None):
        value = super().get(name, default)
        if name in {"MIN_DTE", "MIN_DAY_TRADE_DTE"}:
            return min(value, (self.next_session - self.decision_date).days)
        return value

    def evidence(self):
        return {
            **EXPIRY_POLICY,
            "decision_date_eastern": self.decision_date.isoformat(),
            "next_session_expiration": self.next_session.isoformat(),
            "next_session_calendar_dte": (self.next_session - self.decision_date).days,
            "effective_min_dte": self.get("MIN_DTE"),
            "effective_min_day_trade_dte": self.get("MIN_DAY_TRADE_DTE"),
        }

    def review(self, candidate, now):
        """Check exact expiry and unchanged calendar DTE, including before a fill."""
        result = {
            "candidate_id": candidate.get("candidate_id"),
            "expiration": candidate.get("expiration"),
            "reported_dte": candidate.get("dte"),
        }
        try:
            if now.tzinfo is None or now.astimezone(EASTERN).date() != self.decision_date:
                raise ValueError("paper_expiry_decision_date_changed")
            expiration = date.fromisoformat(candidate["expiration"])
            dte = (expiration - self.decision_date).days
            result["calendar_dte"] = dte
            if isinstance(candidate.get("dte"), bool) or candidate.get("dte") != dte:
                raise ValueError("paper_expiry_calendar_dte_mismatch")
            if dte <= 0:
                raise ValueError("paper_same_day_or_expired_contract")
            regular = self.values["MIN_DTE"] <= dte <= self.values["MAX_DTE"]
            next_session = expiration == self.next_session and dte <= self.values["MAX_DTE"]
            if not (regular or next_session):
                raise ValueError("paper_expiry_outside_calendar_range_and_next_session")
        except (KeyError, TypeError, ValueError) as exc:
            return {**result, "status": "BLOCK", "reason": str(exc)}
        return {
            **result,
            "status": "ALLOW",
            "next_session_expiry": next_session,
            "eligibility_basis": "REGULAR_CALENDAR_RANGE" if regular else "NEXT_NYSE_SESSION",
        }


def paper_entry_config(config: TradingConfig, now: datetime) -> PaperExpiryConfig:
    """Derive admission for one decision date, without changing the account config."""
    if (
        config.live_execution_enabled
        or not config.paper_trading_enabled
        or config.get("DAY_ONLY_OPTIONS") is not True
        or config.get("ALLOW_0DTE") is not False
        or config.values.get("MIN_DTE") != 2
        or config.values.get("MIN_DAY_TRADE_DTE") != 2
        or config.values.get("MAX_DTE") != 45
    ):
        raise ValueError("next-session admission requires the isolated paper DAY policy")
    return PaperExpiryConfig(
        values=config.values,
        source=config.source,
        decision_date=now.astimezone(EASTERN).date(),
        next_session=next_session_date(now),
    )
