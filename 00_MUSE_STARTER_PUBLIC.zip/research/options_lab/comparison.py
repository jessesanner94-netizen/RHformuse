"""Descriptive forward-paper comparisons, never counterfactual fills or inferred profits."""

import json
from collections import Counter, defaultdict
from pathlib import Path

from research.options_lab.event_tape import ET, timestamp
from tools.paper_trading import _atomic_text_write


def records(path):
    if path.exists():
        with path.open() as handle:
            for line in handle:
                if line.strip():
                    yield json.loads(line)


def summarize(directory: Path, account_paths, summaries):
    accounts, baseline_exits = {}, {}
    for arm, paths in account_paths.items():
        daily, exits = defaultdict(float), []
        for event in records(paths["event_log_path"]):
            if event.get("event") != "PAPER_EXIT":
                continue
            pnl = float(event["realized_pnl"])
            daily[timestamp(event["timestamp"]).astimezone(ET).date().isoformat()] += pnl
            exits.append(event)
            if arm == "baseline":
                baseline_exits[event["paper_id"]] = event
        losses = sum(-float(e["realized_pnl"]) for e in exits if e["realized_pnl"] < 0)
        wins = sum(float(e["realized_pnl"]) for e in exits if e["realized_pnl"] > 0)
        accounts[arm] = {
            **summaries[arm],
            "daily_realized_net_pnl": dict(daily),
            "worst_day_net_pnl": min(daily.values()) if daily else None,
            "win_rate": sum(e["realized_pnl"] > 0 for e in exits) / len(exits) if exits else None,
            "profit_factor": wins / losses if losses else None,
        }
    vetoes = {arm: Counter() for arm in account_paths if arm != "baseline"}
    blocked_baseline_trades = {arm: [] for arm in vetoes}
    research_calls = 0
    for observation in records(directory / "OPPORTUNITIES.jsonl"):
        research_calls += len(observation.get("jev", {}))
        results = observation.get("results", {})
        baseline = results.get("baseline", {}).get("entry", {})
        for arm in vetoes:
            result = results.get(arm, {})
            reviews = result.get("addition_reviews", [])
            for review in reviews[:1]:
                if review.get("status") != "ALLOW":
                    vetoes[arm][review.get("news", {}).get("action", review["status"])] += 1
            if baseline.get("opened") and reviews and reviews[-1].get("status") != "ALLOW":
                paper_id = baseline["position"]["paper_id"]
                exit_event = baseline_exits.get(paper_id)
                blocked_baseline_trades[arm].append(
                    {
                        "baseline_paper_id": paper_id,
                        "as_of": observation["as_of"],
                        "contract_identifier": baseline["position"]["contract_identifier"],
                        "baseline_realized_net_pnl": exit_event["realized_pnl"]
                        if exit_event
                        else None,
                        "baseline_exit_reason": exit_event["exit_reason"] if exit_event else None,
                    }
                )
    result = {
        "mode": "DESCRIPTIVE_FORWARD_PAPER_COMPARISON",
        "accounts": accounts,
        "addition_veto_counts": {a: dict(v) for a, v in vetoes.items()},
        "vetoed_baseline_trades": blocked_baseline_trades,
        "jev_unique_contract_evaluations": research_calls,
        "incremental_ai_data_cost": None,
        "economic_profit": None,
        "interpretation": "Baseline outcomes after an addition veto are observed opportunity "
        "cost references, not hypothetical challenger fills. Independent cash, green locks "
        "and shared research capacity can change later trade availability.",
    }
    _atomic_text_write(directory / "COMPARISON.json", json.dumps(result, indent=2) + "\n")
    lines = [
        "# Forward paper comparison",
        "",
        "All amounts include the configured modeled costs.",
        "",
        "| Account | Realized net | Equity | Closed | Worst day | Max drawdown |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for arm, summary in accounts.items():
        worst = summary["worst_day_net_pnl"]
        lines.append(
            f"| {arm} | ${summary['realized_pnl']:.2f} | ${summary['equity']:.2f} | "
            f"{summary['closed_trades']} | "
            f"{'—' if worst is None else f'${worst:.2f}'} | "
            f"${summary['max_drawdown_dollars']:.2f} |"
        )
    lines.extend(
        [
            "",
            result["interpretation"],
            "",
            "AI/data dollar costs remain unmeasured. No live orders or profitability claim.",
        ]
    )
    _atomic_text_write(directory / "COMPARISON.md", "\n".join(lines) + "\n")
    return result
