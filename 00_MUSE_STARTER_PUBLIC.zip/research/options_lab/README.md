# Isolated options experiment lab

The active October 22 paper integration is described in
[the single paper bot](SINGLE_PAPER_BOT.md). It uses one account with news/reaction,
liquidity, supply/demand and RSI research evidence in a separate Linux user service. The sections
below describe the original offline replay commands, which remain offline.

For the separate offline news/reaction recorder, order-book/trade data audit,
Bookmap-style research hypotheses and synthetic demonstration, see
[the news and tape experiment](NEWS_TAPE_EXPERIMENT.md). It produces review markers
and full-session archives. Its pure signals now feed the separate forward-paper adapter.

This is the dormant paper/replay experiment requested October 19, 2026. Its initial
baseline copies the **current parsed production configuration**, rather than the
older prose describing paused paper mode. The baseline has no strategy-setting
changes. The operational overrides force paper mode, turn live entry authority off,
disable duplicate comparison ledgers, and prohibit calendar network refresh.

Both offline commands below consume explicitly supplied, timestamped observations. `paper`
maintains an account across successive input batches; `replay` starts an independent
account for each run. Neither command calls a broker, JEV, a language model, news,
notifications, or an external data service. The production bot, its settings,
positions and schedules are independent.

The initial baseline is `experiments/live_baseline_20261019/`. Starting research
[account details redacted]
manifest remains `DORMANT`; individual run metadata records completed processing.

## Shared strategy

The lab calls the existing option-style and cheap-scan gates,
`build_decision_packet`, the production deterministic entry router with recorded
technical/JEV providers, `apply_paper_decision`, and the same paper accounting and
position-management engine. It reuses Python direction qualification, JEV ranking
of at most three qualified contracts, the requirement for complete valid rankings,
fresh contract/Greek/liquidity checks, event/session gates, cash and daily planned
risk, one contract, the configured entry count, stop, target and daily green lock.
Existing positions are managed before every opportunity observation.

Inputs never import a prior trade's realized outcome. Buys use the refreshed ask;
marks and normal exits use the bid, plus the configured modeled costs. Missing or
stale quotes cannot create a fill. Gaps do not guarantee a stop price. Optional
historical TP evidence goes through the existing trade-through and stop-ordering
rules, and resulting fills retain their assumed-fill label.

## Commands

Run from the project root, using the existing virtual environment:

```bash
.venv/bin/python -m tools.options_lab status \
  --experiment research/options_lab/experiments/live_baseline_20261019

# Entirely synthetic smoke test; creates a separate run, not a performance claim.
.venv/bin/python -m tools.options_lab replay \
  --experiment research/options_lab/experiments/live_baseline_20261019 \
  --input research/options_lab/examples/synthetic_smoke.jsonl --run synthetic_smoke

# Persistent, manually supplied paper observations; later batches must be newer.
.venv/bin/python -m tools.options_lab paper \
  --experiment research/options_lab/experiments/live_baseline_20261019 \
  --input /absolute/path/to/new_observations.jsonl --run forward_paper
```

`replay` refuses to overwrite a run. `paper` rejects duplicates, older observations,
changed settings and interrupted batches. Interrupted runs are retained for manual
inspection; retrying cannot silently duplicate a fill. No end-of-tape forced sale
is invented. Open positions remain open and make the report incomplete.

Each run contains its frozen `CONFIG.md`, `RUN.json`, archived inputs and hashes,
`CYCLES.jsonl`, paper portfolio/events/summary, `METRICS.json`, and `REPORT.md`.
Reports include net P&L, equity, return, drawdown, win rate, profit factor where
defined, entry skips, and missing/stale data and monitoring gaps. AI/data dollar
costs and economic profit stay unknown. Synthetic inputs remain labeled synthetic.

## Observation tape

The input is JSONL: one schema-version-1 observation per line. Use
`examples/synthetic_smoke.jsonl` as the complete working schema. Every frame needs:

| Field | Meaning |
| --- | --- |
| `schema_version` | `1` |
| `as_of` | Replay processing/availability time, ISO timestamp with timezone |
| `kind` | `opportunity` or `monitor`; monitor frames cannot open positions |
| `source` | Real provenance or an explicit synthetic label |
| `quotes` | Robinhood-adapter-shaped quote refresh, including exact option IDs, bid/ask and quote timestamps; optional `tp_history` |
| `candidates` | Point-in-time discovered option candidates, with exact identity, expiration/strike, prices, volume/OI, Greeks/IV, setup/liquidity evidence and option/underlying quote timestamps |
| `technical` | By-symbol Vibe-worker-shaped evidence, including availability `as_of`, status, style scores, timeframe/session evidence and earnings assessment |
| `jev` | By-contract recorded ranking result, including availability `as_of`, status, and setup/entry-timing/escalation scores |
| `economic_calendar` | The original raw cache snapshot: status, month `period`, `fetched_at`, events, errors and coverage |

Opportunity frames can also contain recorded `market_intelligence`, `orderbooks`,
and `uw` summaries (`SYMBOL:CALL` / `SYMBOL:PUT`, if enabled). Monitor frames need
only the basic frame fields and quote refresh. Technical/JEV evidence requires
explicit timestamps; the lab never calls a service to fill missing evidence.
Calendar snapshots retain the production one-hour validity and blackout checks.
Missing calendar snapshots remove any previous frame's cache and block entry.

Frames must be strictly chronological, with no duplicates, nonfinite numbers,
future observation timestamps or supplied realized-outcome fields. Future scheduled
calendar event dates are valid; their results cannot be included as known evidence.
The tape producer must calculate technicals from data available at `as_of`, use
completed candles, preserve genuine availability/receipt times, and preserve the
actual candidate pool. Timestamp validation cannot prove the provenance of supplied
precomputed indicators or JEV scores. Entry quotes and underlying timestamps are
rechecked; DTE is recalculated from expiration and the Eastern date.

Provide monitor observations at the configured cadence while positions are open
(currently 10 seconds). A gap over 1.5 times that target is flagged, and the next
available valid quote determines any exit. A gap alone adds no new strategy veto.

## Future variants and comparisons

Create a separate experiment with explicit research overrides; never edit the
baseline or production settings. For example, a future research hypothesis can be
recorded in a JSON file and initialized with:

```bash
.venv/bin/python -m tools.options_lab init my_research_variant \
  --overrides /absolute/path/to/research_overrides.json

.venv/bin/python -m tools.options_lab compare \
  research/options_lab/experiments/live_baseline_20261019/runs/my_replay \
  research/options_lab/experiments/my_research_variant/runs/my_replay
```

Comparison reports whether both runs used identical input batches. Each experiment
archives the configuration, source policies, Python tools and dependency lockfiles,
with hashes for integrity checks. A code
or configuration change requires a new experiment; old results stay attributable
to the code that produced them. The manifest records every research override.
The lab supports the current no-Luna, watchlist, DAY options route only.

Recorded JEV scores are conditional evidence: a change to candidate features,
stops/targets, JEV prompts or ranking logic may require newly generated,
point-in-time scores. Reusing scores cannot establish that the changed JEV pipeline
would have made the same decisions. Production policy changes still require the
normal user approval, regardless of any research result.

## What existing history supports

The existing operational logs contain selected decision snapshots and sparse
option observations. They do **not** contain a complete timestamped option bid/ask
archive, all historical candidate pools, or all historical policy versions.
Accordingly, these runs are **snapshot-conditioned strategy replays**, not a
complete independent historical market backtest or a claim of a profitable edge.
Underlying stock candles cannot substitute for option fills, Greeks or IV.

The next data step is to collect a complete observation tape with read-only data
adapters. That collection and any recurring forward-paper schedule are deliberately
not activated in this delivery. Future strategy improvements should be evaluated
on separate development and held-out periods, followed by forward paper evidence,
with costs and data-quality limitations retained.

Validation: `tests/test_options_lab.py` checks strategy/config parity, deterministic
results, bid/ask costs, green-lock/reset, missing data, gaps, final quote economics,
chronology, tamper protection and resumable paper-account isolation. All external
clients are forbidden in those tests.
