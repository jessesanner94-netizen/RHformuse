"""Unvalidated paper exits from displayed depth pressure, never executed volume.

No clients or models. Ordinary protective management must run before this addition.
"""

from datetime import timedelta
from math import isfinite
from statistics import median

from research.options_lab.event_tape import ET, number, timestamp, validate
from research.options_lab.zone_signals import _gaps
from tools.orderbook import parse_level2_book

DEPTH_EXIT_POLICY = {
    "book_source": "robinhood",
    "book_venue": "UNSPECIFIED",
    "history_seconds": 180,
    "book_max_age_seconds": 20,
    "book_max_gap_seconds": 30,
    "baseline_min_samples": 6,
    "baseline_min_seconds": 60,
    "confirmation_samples": 2,
    "confirmation_min_seconds": 10,
    "confirmation_window_seconds": 30,
    "levels_per_side": 5,
    "spike_multiple": 3.0,
    "minimum_displayed_quantity": 1000,
    "directional_depth_share": 0.70,
    "minimum_price_move_bps": 2.0,
    "quote_max_age_seconds": 20,
    "minimum_net_profit_percent": 20.0,
}


def depth_exit_review(rows, position, quote, now, *, policy=None):
    """A same-session persistent depth surge plus price confirmation may exit.

    CALL: bid/up is favorable, ask/down adverse. PUT reverses that mapping.
    A favorable surge needs the user-selected net return; adverse needs no P&L floor.
    """
    p = {**DEPTH_EXIT_POLICY, **(policy or {})}
    evidence = {
        "mode": "UNVALIDATED_DISPLAYED_DEPTH_PRESSURE",
        "executed_volume_available": False,
        "source": p["book_source"],
        "venue": p["book_venue"],
        "coverage": "UNVERIFIED_FEED_COVERAGE",
        "as_of": now.isoformat(),
        "policy": p,
    }

    def result(status, action, reason):
        return {"status": status, "action": action, "reason": reason, "evidence": evidence}

    try:
        if set(p) != set(DEPTH_EXIT_POLICY):
            raise ValueError("unknown_depth_exit_policy")
        for key, value in p.items():
            if key in {"book_source", "book_venue"}:
                if not isinstance(value, str) or not value.strip():
                    raise ValueError("feed_must_be_pinned")
            else:
                number(value)
        for key in ("baseline_min_samples", "confirmation_samples", "levels_per_side"):
            if isinstance(p[key], bool) or not isinstance(p[key], int) or p[key] < 2:
                raise ValueError("invalid_sample_or_depth_count")
        if p["spike_multiple"] <= 1 or not 0.5 < p["directional_depth_share"] < 1:
            raise ValueError("invalid_spike_policy")
        if (
            not p["confirmation_min_seconds"]
            <= p["confirmation_window_seconds"]
            < p["history_seconds"]
        ):
            raise ValueError("invalid_confirmation_window")
        symbol, side = position["symbol"], position["option_type"]
        if side not in {"CALL", "PUT"}:
            raise ValueError("unsupported_position_direction")
        entry_at = timestamp(position["entry_at"])
        if entry_at > now:
            raise ValueError("future_position_entry")
        start = now - timedelta(seconds=p["history_seconds"])
        selected = {}
        for row in rows:
            if (
                row.get("symbol") != symbol
                or row.get("source") != p["book_source"]
                or (row.get("venue") != p["book_venue"] or row.get("kind") not in {"book", "gap"})
            ):
                continue
            at, available = timestamp(row["event_at"]), timestamp(row["available_at"])
            if (
                at > now
                or available > now
                or available.astimezone(ET).date() != (now.astimezone(ET).date())
            ):
                continue
            if row["kind"] == "book" and at < start:
                continue
            row = validate(row)
            key = row["kind"], row["event_id"] if row["kind"] == "gap" else at
            if key in selected and selected[key]["payload"] != row["payload"]:
                raise ValueError("conflicting_observations")
            selected.setdefault(key, row)
        books = sorted(
            (r for r in selected.values() if r["kind"] == "book"),
            key=lambda r: timestamp(r["event_at"]),
        )
        n = p["confirmation_samples"]
        if len(books) < p["baseline_min_samples"] + n:
            return result("UNAVAILABLE", "HOLD", "insufficient_book_history")
        times = [timestamp(r["event_at"]) for r in books]
        if (now - times[-1]).total_seconds() > p["book_max_age_seconds"]:
            return result("UNAVAILABLE", "HOLD", "stale_book")
        if _gaps(list(selected.values()), times[0], now) or any(
            (b - a).total_seconds() > p["book_max_gap_seconds"]
            for a, b in zip(times, times[1:], strict=False)
        ):
            return result("UNAVAILABLE", "HOLD", "book_data_gap")
        baseline = [
            r
            for r in books
            if timestamp(r["event_at"])
            < times[-1] - timedelta(seconds=p["confirmation_window_seconds"])
        ]
        burst = books[-n:]
        if (
            len(baseline) < p["baseline_min_samples"]
            or (timestamp(baseline[-1]["event_at"]) - times[0]).total_seconds()
            < p["baseline_min_seconds"]
        ):
            return result("UNAVAILABLE", "HOLD", "insufficient_baseline_duration")
        if (times[-1] - times[-n]).total_seconds() < p["confirmation_min_seconds"]:
            return result("UNAVAILABLE", "HOLD", "insufficient_confirmation_duration")
        if times[-n] < times[-1] - timedelta(seconds=p["confirmation_window_seconds"]):
            return result("UNAVAILABLE", "HOLD", "confirmation_outside_spike_window")
        if times[-n] < entry_at:
            return result("OK", "HOLD", "spike_confirmation_predates_position")

        def features(row):
            book = parse_level2_book(row["payload"], now=timestamp(row["received_at"]))
            if len(book.bids) < p["levels_per_side"] or len(book.asks) < p["levels_per_side"]:
                raise ValueError("insufficient_two_sided_depth")
            return (
                sum(x.quantity for x in book.bids[: p["levels_per_side"]]),
                sum(x.quantity for x in book.asks[: p["levels_per_side"]]),
                (book.bids[0].price + book.asks[0].price) / 2,
            )

        history = [features(r) for r in baseline]
        observed = [features(r) for r in burst]
        base_bid, base_ask = median(x[0] for x in history), median(x[1] for x in history)
        reference_mid = history[-1][2]
        moves = [(x[2] / reference_mid - 1) * 10000 for x in observed]
        up = all(
            b >= max(p["minimum_displayed_quantity"], base_bid * p["spike_multiple"])
            and b / (b + a) >= p["directional_depth_share"]
            and move >= p["minimum_price_move_bps"]
            for (b, a, _), move in zip(observed, moves, strict=True)
        )
        down = all(
            a >= max(p["minimum_displayed_quantity"], base_ask * p["spike_multiple"])
            and a / (b + a) >= p["directional_depth_share"]
            and move <= -p["minimum_price_move_bps"]
            for (b, a, _), move in zip(observed, moves, strict=True)
        )
        evidence.update(
            baseline_samples=len(baseline),
            confirmation_samples=n,
            baseline_bid_quantity=base_bid,
            baseline_ask_quantity=base_ask,
            bid_spike_multiple=observed[-1][0] / base_bid,
            ask_spike_multiple=observed[-1][1] / base_ask,
            confirmed_price_moves_bps=moves,
            confirmation_started_at=times[-n].isoformat(),
            signal_at=times[-1].isoformat(),
        )
        if not up and not down:
            return result("OK", "HOLD", "no_confirmed_directional_depth_spike")
        favorable = up if side == "CALL" else down
        evidence["pressure_relative_to_position"] = "FAVORABLE" if favorable else "ADVERSE"
        if quote.get("instrument_id") != position["contract_identifier"]:
            raise ValueError("option_contract_mismatch")
        updated = timestamp(quote["updated_at"])
        age = (now - updated).total_seconds()
        if not 0 <= age <= p["quote_max_age_seconds"] or updated < times[-1]:
            return result("UNAVAILABLE", "HOLD", "fresh_post_signal_option_quote_required")
        if isinstance(quote["bid_price"], bool) or isinstance(quote["ask_price"], bool):
            raise ValueError("invalid_option_market")
        bid, ask = float(quote["bid_price"]), float(quote["ask_price"])
        if not isfinite(bid) or not isfinite(ask) or not 0 <= bid <= ask:
            raise ValueError("invalid_option_market")
        quantity = position["quantity"]
        if isinstance(quantity, bool) or not isinstance(quantity, int) or quantity <= 0:
            raise ValueError("invalid_position_quantity")
        premium = number(position["entry_cost"])
        entry_cost = number(position["entry_cost_estimate"], positive=False)
        exit_cost = number(position["exit_cost_estimate"], positive=False)
        net = round(round(bid * quantity * 100, 2) - premium - entry_cost - exit_cost, 2)
        minimum_net = round(premium * p["minimum_net_profit_percent"] / 100, 2)
        evidence.update(
            net_profit_dollars=net,
            net_profit_percent=100 * net / premium,
            minimum_net_profit_dollars=minimum_net,
            option_bid=bid,
            option_quote_updated_at=quote["updated_at"],
        )
        if favorable and net < minimum_net:
            return result("OK", "HOLD", "favorable_spike_below_net_profit_floor")
        return result(
            "OK",
            "TAKE_PROFIT" if favorable else "DEFENSIVE_EXIT",
            "confirmed_favorable_depth_spike" if favorable else "confirmed_adverse_depth_spike",
        )
    except (KeyError, ValueError, TypeError, AttributeError, OverflowError) as exc:
        return result("UNAVAILABLE", "HOLD", f"invalid_or_missing_evidence:{exc}")


def close_depth_exit(review, position, quote, *, config, paths, now):
    """Commit a fresh-bid simulated exit only; never an order or historical fill."""
    from tools.paper_trading import close_paper_position

    if config.live_execution_enabled or not config.paper_trading_enabled:
        return {"closed": False, "reason": "paper_only_exit"}
    if review["status"] != "OK" or review["action"] not in {"TAKE_PROFIT", "DEFENSIVE_EXIT"}:
        return {"closed": False, "reason": "no_depth_exit_signal"}
    try:
        evidence = review["evidence"]
        if quote["instrument_id"] != position["contract_identifier"] or (
            quote["updated_at"] != evidence["option_quote_updated_at"]
            or float(quote["bid_price"]) != evidence["option_bid"]
            or not 0
            <= (now - timestamp(quote["updated_at"])).total_seconds()
            <= (evidence["policy"]["quote_max_age_seconds"])
        ):
            return {"closed": False, "reason": "reviewed_exit_quote_changed_or_stale"}
    except (KeyError, TypeError, ValueError):
        return {"closed": False, "reason": "invalid_exit_review"}
    return close_paper_position(
        position["paper_id"],
        bid=float(quote["bid_price"]),
        quote_updated_at=quote["updated_at"],
        reason="PAPER_DEPTH_SPIKE_" + review["action"],
        config=config,
        **paths,
        now=now,
    )
