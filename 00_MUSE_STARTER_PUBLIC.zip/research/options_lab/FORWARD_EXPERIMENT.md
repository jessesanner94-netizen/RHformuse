# Three additive paper questions — October 22, 2026

**Retired architecture:** the user clarified on October22 that there should be one
paper bot/account, with all additions together. The five-account design below is
retained as historical documentation only. See [the active single paper bot](SINGLE_PAPER_BOT.md).

Deployment verified October 21 at approximately 15:47 ET: the dedicated user
service is enabled, running with zero restarts and waiting for the start-date gate.
User lingering is enabled for logout/reboot continuity. All five accounts have
$369 cash and zero trades; production services remain active. Read-only preflight
passed SPY/QQQ depth, completed bars, both news channels, the economic calendar and
all original technical timeframes. JEV credential presence is confirmed without a
preflight model call. Evidence is under `experiments/additive_20261022/forward/`
in `DEPLOYMENT.json`, `PREFLIGHT_FEEDS.json` and `PREFLIGHT_STRATEGY.json`.

Verification: 95 focused tests passed, followed by 12 final forward checks after
the news-retraction safeguard (96 unique tests); scoped Ruff and systemd unit
validation passed. Synthetic tests are separate from all real observations.

The live bot and its policy remain unchanged. Five independent $369 paper accounts
use the current production Python qualification, JEV ranking, risk/session/event
gates, one-contract sizing, 25% stop, 30% target, modeled costs and daily green lock:

| Account | Question |
|---|---|
| baseline | What does the unchanged strategy do with the shared observations? |
| news_reaction | Does pausing for material news and exiting after a confirmed adverse reaction improve outcomes? |
| liquidity | Does avoiding nearby persistent opposing displayed depth improve entries? |
| supply_demand | Does avoiding opposing zones formed by completed high-volume displacement improve entries? |
| combined | How do the three additions interact? |

These are unvalidated hypotheses, with explicit fixed research parameters in
`forward/EXPERIMENT.json`. Their settings never enter production CONFIG or policy.
No add-on creates a trade without the original strategy's qualification. Missing
required add-on evidence blocks that account's new entry, while ordinary protective
exits keep running. An addition veto applies to the selected original contract;
it does not select an alternative merely to increase trading activity.

## Feed and action boundaries

- Batched Robinhood displayed depth is requested every 10 seconds, preserving the
  session history in SQLite. Capture is the first 1,000 provider-ordered levels per
  side, with original/captured counts. Coverage/venue remain unspecified. Resting
  size cannot establish executed selling, absorption, exhaustion or intent.
- Yahoo supplies completed one-minute OHLCV bars, checked every 30 seconds.
  Developing bars and missing volume cannot confirm reactions/zones. First observed
  completed bars stay immutable; later corrections are counted and disclosed.
- Google macro RSS and the direct Fed monetary-policy RSS are checked every 30
  seconds. Aggregator headlines remain unverified; relevant material reports pause
  entries briefly. Direct Fed publications verify provenance, not market direction.
  This initial feed does not provide comprehensive surprise-news coverage.
- Verified directional news requires a matching price/volume bar before an adverse
  paper exit. A separate, explicitly labeled hypothesis allows a primary publication
  of unknown semantic direction plus an adverse observed reaction to exit. It does
  not claim the news caused the move. News thresholds: within 180 seconds of first
  publication, completed bar at most 60 seconds, move at least 5 bps and at least
  1,000 reported shares. These thresholds are experimental, not established edges.
- News exits use a fresh, noncrossed Robinhood option bid at most 20 seconds old.
  Stops/targets/deadlines run first for all accounts. An exit wakes ordinary
  discovery for possible requalification; an opposite position still needs a new
  scanner/JEV decision, current account risk, green-lock permission and all original
  gates. There is no unconditional flip.

Ten-second monitoring is a target. RSS publication delays and completed minute bars
mean **ten-second news-to-exit is not guaranteed**. The archive separates publication,
receipt, confirmation/evaluation, quote age and simulated fill. There is no trade
print feed or inferred aggressor/CVD signal in this experiment.

## Isolation, cost and comparison

`tools/options_lab.py` freezes the current parsed strategy and source hashes.
Forward research has an additional source archive/hash manifest. Each account has
its own config, ledger, cash, exposure, loss budget and green lock. Only read-only
broker adapters are used. Live execution switches are forced off; no live placement,
review or cancellation function is called. Changing a frozen source/config blocks
new entries; already running protective management retains its loaded risk policy.

All accounts share raw discovery, original technical/news context and JEV market
research, with at most three unique researched contracts per scan. Each account
rechecks its own risk and entry budget. Comparisons are conditional on this shared
shortlist/research capacity, rather than five unrestricted independent searches.
No additional Codex judgment calls run. JEV/data dollar costs remain unmeasured,
and net paper P&L must not be described as economic profit after those costs.

`forward/STATUS.json` records current health and accounts. `COMPARISON.md/json`
records net P&L, equity, drawdown, worst days, wins/profit factor, addition vetoes
and baseline outcomes for vetoed trades. Those outcomes help identify missed winners
and avoided losers; they never invent an alternate fill. `MONITOR.jsonl` includes
all returned held quotes; `OPPORTUNITIES.jsonl` includes candidates, technical/JEV
evidence, final quote observations, gates and account decisions. `SESSION_TAPE.sqlite3`
retains full-session captured depth, bars, news, availability timestamps and gaps.

## Linux launch

The dedicated **user** unit is `options-lab-paper.service`, separate from both live
Robinhood services. It can remain running overnight, with no market requests before
October 22. On NYSE sessions it collects from 09:25 ET, admits entries no earlier
than 09:50 under the original policy, and runs the ordinary opportunity cadence at
five-minute boundaries plus 15 seconds. Calendar holidays/early closes apply.
The ordinary 15-minute pre-close DAY deadline remains; unresolved positions keep
being monitored. Logout survival requires user lingering; boot still requires the
computer and network to be available.

```bash
systemctl --user status options-lab-paper.service
systemctl --user stop options-lab-paper.service
.venv/bin/python -m research.options_lab.forward status \
  --experiment research/options_lab/experiments/additive_20261022
```

The October 19 offline baseline and synthetic validations remain separate and
unchanged. Synthetic tests and preflight probes are not paper trading performance.
