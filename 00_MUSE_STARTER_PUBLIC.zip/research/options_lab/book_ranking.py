"""Uncalibrated paper ranking from displayed depth; no execution/client authority."""

from datetime import timedelta
from statistics import median

from research.entry_quality.priority import rsi_priority
from research.options_lab.event_tape import ET, number, timestamp, validate
from research.options_lab.zone_signals import _gaps, zone_review
from tools.orderbook import parse_level2_book

BOOK_RANKING_POLICY = {
    "enabled": True,
    "book_source": "robinhood",
    "book_venue": "UNSPECIFIED",
    "history_seconds": 300,
    "max_age_seconds": 30,
    "max_gap_seconds": 30,
    "levels_per_side": 5,
    "confirmation_samples": 3,
    "confirmation_seconds": 18,
    "minimum_imbalance": 0.40,
    "minimum_direction_depth": 1000,
    "minimum_midpoint_move_bps": 2.0,
    "baseline_min_samples": 6,
    "thin_depth_ratio": 0.50,
    "price_liquidity_gap_bps": 2.0,
    "rsi_weight": 4,
    "direction_weight": 4,
    "amplifier_weight": 1,
    "opposing_wall_penalty": 1,
    "maximum_absolute_book_score": 5,
}


def book_policy(overrides=None):
    if overrides is not None and (
        not isinstance(overrides, dict) or set(overrides) - BOOK_RANKING_POLICY.keys()
    ):
        raise ValueError("unknown book ranking policy fields")
    p = {**BOOK_RANKING_POLICY, **(overrides or {})}
    if not isinstance(p["enabled"], bool):
        raise ValueError("enabled must be boolean")
    if p["book_source"] != "robinhood" or p["book_venue"] != "UNSPECIFIED":
        raise ValueError("entry ranking uses only the existing labeled Robinhood feed")
    for k, v in p.items():
        if k not in {"enabled", "book_source", "book_venue"}:
            number(v, positive=k not in {"amplifier_weight", "opposing_wall_penalty"})
    for k in (
        "levels_per_side",
        "confirmation_samples",
        "baseline_min_samples",
        "rsi_weight",
        "direction_weight",
        "amplifier_weight",
        "opposing_wall_penalty",
        "maximum_absolute_book_score",
    ):
        if isinstance(p[k], bool) or not isinstance(p[k], int):
            raise ValueError(f"{k} must be an integer")
    if min(p["levels_per_side"], p["confirmation_samples"], p["baseline_min_samples"]) < 2:
        raise ValueError("at least two levels/samples required")
    if not 0 < p["minimum_imbalance"] < 1 or not 0 < p["thin_depth_ratio"] < 1:
        raise ValueError("invalid imbalance/thin-depth threshold")
    if p["confirmation_seconds"] >= p["history_seconds"]:
        raise ValueError("confirmation must fit history")
    return p


def book_signal(rows, symbol, as_of, *, policy=None, wall_policy):
    """One common-time, feed-local observation, reusable for CALL and PUT scoring."""
    p = book_policy(policy)
    evidence = {
        "mode": "UNCALIBRATED_DISPLAYED_DEPTH_RANKING",
        "as_of": as_of.isoformat(),
        "source": p["book_source"],
        "venue": p["book_venue"],
        "coverage": "UNVERIFIED_FEED_COVERAGE",
        "executed_volume_available": False,
        "standalone_entry_trigger": False,
        "policy": p,
    }

    def result(status, reason, direction=0):
        return {"status": status, "reason": reason, "direction": direction, "evidence": evidence}

    if not p["enabled"]:
        return result("DISABLED", "feature_disabled")
    try:
        if as_of.tzinfo is None or as_of.utcoffset() is None:
            raise ValueError("as_of must have timezone")
        selected = {}
        for raw in rows:
            if raw.get("symbol", "").upper() != symbol.upper() or (
                raw.get("source") != p["book_source"]
                or raw.get("venue") != p["book_venue"]
                or raw.get("kind") not in {"book", "gap"}
            ):
                continue
            event, available = timestamp(raw["event_at"]), timestamp(raw["available_at"])
            if (
                event > as_of
                or available > as_of
                or event.astimezone(ET).date() != (as_of.astimezone(ET).date())
                or available.astimezone(ET).date() != as_of.astimezone(ET).date()
            ):
                continue
            if raw["kind"] == "book" and event < as_of - timedelta(seconds=p["history_seconds"]):
                continue
            row = validate(raw)
            key = row["kind"], row["event_id"] if row["kind"] == "gap" else event
            if key in selected and selected[key]["payload"] != row["payload"]:
                raise ValueError("conflicting_book_observations")
            selected.setdefault(key, row)
        rows = list(selected.values())
        books = sorted(
            (r for r in rows if r["kind"] == "book"), key=lambda r: timestamp(r["event_at"])
        )
        if not books:
            return result("UNAVAILABLE", "missing_book_history")
        times = [timestamp(r["event_at"]) for r in books]
        evidence.update(
            latest_event_at=times[-1].isoformat(),
            latest_available_at=books[-1]["available_at"],
            age_seconds=(as_of - times[-1]).total_seconds(),
            samples=len(books),
        )
        if evidence["age_seconds"] > p["max_age_seconds"]:
            return result("UNAVAILABLE", "stale_book")
        if _gaps(rows, times[0], as_of) or any(
            (b - a).total_seconds() > p["max_gap_seconds"]
            for a, b in zip(times, times[1:], strict=False)
        ):
            return result("UNAVAILABLE", "transport_or_sampling_gap")
        n = p["confirmation_samples"]
        if len(books) < n or (times[-1] - times[-n]).total_seconds() < p["confirmation_seconds"]:
            return result("UNAVAILABLE", "insufficient_persistence")
        parsed = [parse_level2_book(r["payload"], now=timestamp(r["received_at"])) for r in books]
        if any(
            len(b.bids) < p["levels_per_side"] or len(b.asks) < p["levels_per_side"] for b in parsed
        ):
            return result("UNAVAILABLE", "insufficient_two_sided_depth")
        depths = [
            (
                sum(x.quantity for x in b.bids[: p["levels_per_side"]]),
                sum(x.quantity for x in b.asks[: p["levels_per_side"]]),
            )
            for b in parsed
        ]
        mids = [(b.bids[0].price + b.asks[0].price) / 2 for b in parsed[-n:]]
        imbalances = [(bid - ask) / (bid + ask) for bid, ask in depths[-n:]]
        move = (mids[-1] / mids[0] - 1) * 10000
        up = (
            all(
                i >= p["minimum_imbalance"] and b >= p["minimum_direction_depth"]
                for i, (b, _) in zip(imbalances, depths[-n:], strict=True)
            )
            and move >= p["minimum_midpoint_move_bps"]
            and all(b >= a for a, b in zip(mids, mids[1:], strict=False))
        )
        down = (
            all(
                i <= -p["minimum_imbalance"] and a >= p["minimum_direction_depth"]
                for i, (_, a) in zip(imbalances, depths[-n:], strict=True)
            )
            and move <= -p["minimum_midpoint_move_bps"]
            and all(b <= a for a, b in zip(mids, mids[1:], strict=False))
        )
        baseline = [b + a for b, a in depths[:-n]]
        depth_ratio = (
            (sum(depths[-1]) / median(baseline))
            if len(baseline) >= p["baseline_min_samples"]
            else None
        )
        price_gaps = {}
        for name, levels in (("bid", parsed[-1].bids), ("ask", parsed[-1].asks)):
            price_gaps[name] = max(
                abs(b.price - a.price) / mids[-1] * 10000
                for a, b in zip(
                    levels[: p["levels_per_side"]], levels[1 : p["levels_per_side"]], strict=False
                )
            )
        # Reuse the original persistent wall detector, including its availability checks.
        effective_wall_policy = {
            **wall_policy,
            "book_max_age_seconds": p["max_age_seconds"],
            "book_max_gap_seconds": p["max_gap_seconds"],
            "liquidity_window_seconds": p["history_seconds"],
        }
        wall = zone_review(
            rows,
            symbol,
            "CALL",
            as_of,
            liquidity=True,
            supply_demand=False,
            policy=effective_wall_policy,
        )["evidence"]["liquidity"]
        if wall["status"] == "UNAVAILABLE" and wall["reasons"] != ["insufficient_book_history"]:
            return result("UNAVAILABLE", "wall_evidence_unavailable")
        walls = wall.get("evidence", {}).get("walls", [])
        opposing = {
            "CALL": any(
                w["side"] == "ask" and w["distance_bps"] <= wall_policy["wall_max_distance_bps"]
                for w in walls
            ),
            "PUT": any(
                w["side"] == "bid" and w["distance_bps"] <= wall_policy["wall_max_distance_bps"]
                for w in walls
            ),
        }
        evidence.update(
            confirmation_started_at=times[-n].isoformat(),
            confirmation_seconds=(times[-1] - times[-n]).total_seconds(),
            midpoint_path=mids,
            midpoint_move_bps=move,
            near_imbalance_path=imbalances,
            near_depth=depths[-n:],
            depth_to_baseline_ratio=depth_ratio,
            thin_depth=depth_ratio is not None and depth_ratio <= p["thin_depth_ratio"],
            price_liquidity_gaps_bps=price_gaps,
            persistent_opposing_wall=opposing,
            wall_status=wall["status"],
            persistent_walls=[{k: v for k, v in w.items() if k != "blocks"} for w in walls],
            persistent_wall_count=len(walls),
            wall_change_alone="AMBIGUOUS_NO_DIRECTION_SCORE",
        )
        return result(
            "OK",
            "persistent_pressure_plus_midpoint"
            if up or down
            else "no_confirmed_directional_signal",
            1 if up else -1 if down else 0,
        )
    except (KeyError, ValueError, TypeError, AttributeError, OverflowError) as exc:
        return result("UNAVAILABLE", f"invalid_or_missing_evidence:{exc}")


def candidate_components(candidate, rsi, book, *, policy=None):
    p = book_policy(policy)
    side = candidate.get("option_type")
    alignment = book.get("direction", 0) * (1 if side == "CALL" else -1 if side == "PUT" else 0)
    available = book.get("status") == "OK" and p["enabled"]
    alignment = alignment if available else 0
    e = book.get("evidence", {})
    amplified = (
        available
        and alignment != 0
        and (
            e.get("thin_depth", False)
            or e.get("price_liquidity_gaps_bps", {}).get(
                "ask" if book["direction"] == 1 else "bid", 0
            )
            >= p["price_liquidity_gap_bps"]
        )
    )
    wall = available and e.get("persistent_opposing_wall", {}).get(side, False)
    direction_score = alignment * p["direction_weight"]
    amplifier_score = alignment * p["amplifier_weight"] if amplified else 0
    wall_score = -p["opposing_wall_penalty"] if wall else 0
    book_score = max(
        -p["maximum_absolute_book_score"],
        min(p["maximum_absolute_book_score"], direction_score + amplifier_score + wall_score),
    )
    rsi_value = rsi_priority(candidate, rsi)
    return {
        "candidate_id": candidate["candidate_id"],
        "symbol": candidate["symbol"],
        "option_type": side,
        "rsi_priority": rsi_value,
        "rsi_score": rsi_value * p["rsi_weight"],
        "book_score": book_score,
        "book_status": book.get("status", "UNAVAILABLE"),
        "book_reason": book.get("reason"),
        "book_evidence": e,
        "direction_alignment": "SUPPORTING"
        if alignment > 0
        else "OPPOSING"
        if alignment < 0
        else "NEUTRAL",
        "components": {
            "persistent_direction": direction_score,
            "move_amplifier": amplifier_score,
            "opposing_wall": wall_score,
        },
        "total_priority": rsi_value * p["rsi_weight"] + book_score,
        "book_entry_veto": False,
    }


def ranking_audit(routing, components):
    """Describe the existing router's actual ordering; never select another candidate."""
    from tools.scheduled_cycle import _jev_rank

    summary = routing.get("jev_ranking", {})
    ids = summary.get("candidate_ids", [])
    jev = routing.get("jev_evaluations", [])
    # The router appends one JEV result per eligible candidate in this same order.
    scores = {key: _jev_rank(value) for key, value in zip(ids, jev, strict=False)}
    complete = bool(ids) and all(key in components and scores.get(key) is not None for key in ids)
    ordered = (
        sorted(
            ids,
            key=lambda key: (components[key]["total_priority"], *scores[key], -ids.index(key)),
            reverse=True,
        )
        if complete
        else []
    )
    chosen = summary.get("selected_candidate_id")
    return {
        "mode": "PAPER_WEIGHTED_RSI_BOOK_THEN_JEV",
        "uncalibrated": True,
        "ranking_order": [
            "weighted_rsi_plus_book",
            "jev_setup_quality",
            "jev_entry_timing_quality",
            "jev_escalation_score",
            "original_python_order",
        ],
        "ranked_candidate_ids": ordered,
        "selected_candidate_id": chosen,
        "selection_reason": "MAX_COMBINED_PRIORITY_THEN_JEV_THEN_STABLE_PYTHON_ORDER"
        if chosen
        else routing.get("decision", {}).get("reason", "NO_SELECTION"),
        "candidates": {
            key: {
                **value,
                "rank": ordered.index(key) + 1 if key in ordered else None,
                "priority_applied": key in summary.get("candidate_priority", {}),
                "candidate_scope": "PYTHON_QUALIFIED_ROUTER_POOL"
                if key in ids
                else "PRELIMINARY_ONLY_NOT_RANKED",
                "selected": key == chosen,
            }
            for key, value in components.items()
        },
    }
