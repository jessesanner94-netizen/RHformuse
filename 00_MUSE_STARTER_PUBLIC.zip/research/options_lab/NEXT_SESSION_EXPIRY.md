# Paper next-session expiration eligibility — October 25, 2026

The one active paper bot admits a contract when its expiration is the next
scheduled NYSE session, or its calendar DTE is in the existing inclusive 2–45
range. Same-day and expired contracts remain blocked. This changes eligibility,
not ranking, sizing, exits or the requirement to qualify. It does not establish
that shorter-dated contracts improve returns.

`CURRENT.json` identifies the active version and its single carried account.
The new frozen version uses the same history, P&L, budget/cache and session tape;
there is no account reset, additional account or shadow runner. The previous
version's frozen source and evidence remain intact.

## Workflow and implementation

Before this change, discovery in `tools.news_option_discovery` queried expirations
starting at today's Eastern date plus `MIN_DTE`. It calculated actual calendar
DTE, annotated DAY eligibility through `tools.option_style` and ran
`tools.cheap_scan`. The paper router then ran original Python direction/event/
risk qualification and bounded JEV ranking. `tools.paper_runner` refreshed the
selected quote, reran scanner/Greek checks, checked unchanged configuration and
called the original locked paper entry/risk/accounting function.

`research/options_lab/session_expiry.py` derives the next date strictly after
the current Eastern date with scheduled hours in the existing
`tools.market_calendar.session_hours` NYSE calendar. That same installed
`pandas_market_calendars` calendar already controls entry windows, holidays,
early closes and DAY exits. No weekday approximation or paid feed is added.

`ForwardExperiment.opportunities` supplies a paper-only `PaperExpiryConfig`
through discovery, the original Python/JEV router and final paper fill.
Its effective `MIN_DTE` and `MIN_DAY_TRADE_DTE` are the smaller of 2 and the
next session's calendar DTE. Thus they are 1 only when tomorrow is a scheduled
session; they stay 2 across longer closures. Every other getter is unchanged.
[account details redacted]
(including the stored minimums of 2), so the existing on-disk configuration-change
check continues to work. The derived behavior is explicit in frozen research
policy, source hashes and opportunity evidence; it never enters a live config.

Exact-date reviews before ranking and before/after the final quote refresh
require positive actual calendar DTE, agreement with the candidate's reported
DTE, and either normal 2–45 eligibility or the next-session expiration. A decision
date change blocks admission rather than trusting yesterday's DTE. Missing or
failed calendar resolution cannot enable the exception. Newly eligible contracts
must pass original Greek limits, premium/spread/volume/OI, direction, event/news/
supply-demand, quote freshness, session/cutoff, cash, daily loss/entry limits,
net reward/risk and green-lock checks. JEV remains ranking-only, with the same
call cap and existing unavailable-data handling.

The book ranking is unchanged: weighted RSI plus bounded book score, then
existing JEV scores and stable Python order. Book data remains supporting
evidence; missing depth is neutral and an opposing wall is a bounded penalty.
Protective monitoring, depth exits and all cost/P&L calculations are unchanged.

Existing read-only replay code shares this admission helper for future authorized
replays. An old archive cannot supply contracts it never recorded. This deployment
does not run a historical performance replay or rewrite any prior result.

## Examples and evidence

| Decision date | Next session expiration | Reported calendar DTE |
| --- | --- | ---: |
| Thursday October 22, 2026 | Friday October 23 | 1 |
| Friday October 23, 2026 | Monday October 26 | 3 |
| Friday September 4, 2026 | Tuesday September 8 (Labor Day closure) | 4 |
| Thursday April 2, 2026 | Monday April 6 (Good Friday closure) | 4 |
| Thursday December 31, 2026 | Monday January 4, 2027 | 4 |

Friday-to-Monday and holiday-gap contracts were already within 2–45 calendar
days and remain eligible. The additional admission is the one-calendar-day
contract when tomorrow is a real session. A Saturday expiration one calendar
day after Friday does not get this exception. Closed-session entry prohibitions
still apply even when the next expiration can be calculated on a weekend.

Opportunity records retain original calendar DTE and add `expiry_eligibility`,
`candidate_expiry_reviews`, and per-account `final_expiry_reviews`. STATUS exposes
the frozen policy. Deployment checks and focused test results are retained in
the active version's `forward/EXPIRY_VALIDATION.json` and `forward/validation/`.
Tests use the installed calendar and synthetic offline quotes, including the
real discovery, Python/JEV and paper fill functions. They are admission/gate
checks, not market performance or guaranteed fills. Calendar accuracy remains
limited by the installed calendar data; no future emergency closure is invented.
