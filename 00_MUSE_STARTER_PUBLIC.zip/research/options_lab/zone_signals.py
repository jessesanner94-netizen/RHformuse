"""Pure, paper-only zone hypotheses. Thresholds below are UNVALIDATED research inputs.

ALLOW means only that these observed vetoes did not fire; it is never entry support.
Displayed books describe resting quantities, not executions, absorption or CVD.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime, timedelta
from statistics import mean
from typing import Any

from research.options_lab.event_tape import ET, number, timestamp, validate
from tools.orderbook import parse_level2_book

DEFAULT_ZONE_POLICY = {
    "book_source": "UNCONFIGURED",
    "book_venue": "UNCONFIGURED",
    "bar_source": "UNCONFIGURED",
    "bar_venue": "UNCONFIGURED",
    "book_max_age_seconds": 30,
    "book_max_gap_seconds": 30,
    "liquidity_window_seconds": 300,
    "wall_min_samples": 3,
    "wall_min_duration_seconds": 20,
    "wall_min_quantity": 1000,
    "wall_min_depth_fraction": 0.25,
    "wall_max_distance_bps": 20,
    "bar_max_age_seconds": 90,
    "bar_max_gap_seconds": 5,
    "bar_max_duration_seconds": 60,
    "displacement_lookback_bars": 5,
    "displacement_volume_multiple": 2,
    "displacement_min_move_bps": 10,
    "displacement_min_range_multiple": 1.5,
    "zone_max_age_seconds": 3600,
    "zone_max_distance_bps": 20,
}


def _policy(values):
    if not isinstance(values, Mapping) or set(values) - DEFAULT_ZONE_POLICY.keys():
        raise ValueError("unknown zone policy fields")
    result = {**DEFAULT_ZONE_POLICY, **values}
    for key, value in result.items():
        if key.endswith(("_source", "_venue")):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{key} must pin a labeled feed")
        else:
            number(value)
    for key in ("wall_min_samples", "displacement_lookback_bars"):
        if not isinstance(result[key], int) or result[key] < 2:
            raise ValueError(f"{key} must be an integer >= 2")
    if result["wall_min_depth_fraction"] > 1:
        raise ValueError("wall_min_depth_fraction must be <= 1")
    if result["wall_min_duration_seconds"] > result["liquidity_window_seconds"]:
        raise ValueError("wall duration exceeds liquidity window")
    if result["displacement_volume_multiple"] <= 1:
        raise ValueError("displacement volume multiple must exceed 1")
    return result


def _result(status, reason, **evidence):
    return {"status": status, "reasons": [reason], "evidence": evidence}


def _gaps(rows, start, end):
    # Recovery revisions close an interval; they do not erase its missing observations.
    latest = {}
    for row in sorted(rows, key=lambda r: timestamp(r["available_at"])):
        if row["kind"] == "gap":
            latest[row["payload"]["gap_key"]] = row["payload"]
    return any(
        timestamp(g["start_at"]) <= end
        and (g.get("end_at") is None or timestamp(g["end_at"]) > start)
        for g in latest.values()
    )


def _uncovered_bar_gaps(rows, bars, as_of):
    """Require actual completed-bar coverage to recover a transport interruption."""
    latest = {}
    for row in sorted(rows, key=lambda r: timestamp(r["available_at"])):
        if row["kind"] == "gap":
            latest[row["payload"]["gap_key"]] = row["payload"]
    start = timestamp(bars[0]["payload"]["start_at"])
    end = timestamp(bars[-1]["payload"]["end_at"])
    recovered = []
    for gap in latest.values():
        begin = max(start, timestamp(gap["start_at"]))
        if gap.get("end_at") is None:
            if begin <= as_of:
                return True, recovered
            continue
        finish = min(end, timestamp(gap["end_at"]))
        if begin >= finish:
            continue
        cursor = begin
        for row in bars:
            b = row["payload"]
            left, right = timestamp(b["start_at"]), timestamp(b["end_at"])
            if left <= cursor < right:
                cursor = right
        if cursor < finish:
            return True, recovered
        recovered.append(gap["gap_key"])
    return False, recovered


def _liquidity(rows, side, as_of, p):
    start = as_of - timedelta(seconds=p["liquidity_window_seconds"])
    books = [r for r in rows if r["kind"] == "book" and timestamp(r["event_at"]) >= start]
    books.sort(key=lambda r: timestamp(r["event_at"]))
    if not books:
        return _result("UNAVAILABLE", "missing_book_history")
    times = [timestamp(r["event_at"]) for r in books]
    if (as_of - times[-1]).total_seconds() > p["book_max_age_seconds"]:
        return _result("UNAVAILABLE", "stale_book")
    if _gaps(rows, times[0], as_of) or any(
        (b - a).total_seconds() > p["book_max_gap_seconds"]
        for a, b in zip(times, times[1:], strict=False)
    ):
        return _result("UNAVAILABLE", "book_data_gap")
    if (
        len(books) < p["wall_min_samples"]
        or (times[-1] - times[0]).total_seconds() < p["wall_min_duration_seconds"]
    ):
        return _result("UNAVAILABLE", "insufficient_book_history")
    parsed = [parse_level2_book(r["payload"], now=timestamp(r["received_at"])) for r in books]
    if any(not b.bids or not b.asks for b in parsed):
        return _result("UNAVAILABLE", "missing_two_sided_depth")
    current = (parsed[-1].bids[0].price + parsed[-1].asks[0].price) / 2
    # Only consecutive qualifying observations ending in the latest book can persist.
    runs = {}
    for book in parsed:
        observed = {}
        for name, levels in (("bid", book.bids), ("ask", book.asks)):
            depth = sum(level.quantity for level in levels)
            for level in levels:
                if level.quantity < p["wall_min_quantity"] or (
                    level.quantity / depth < p["wall_min_depth_fraction"]
                ):
                    continue
                key = name, level.price
                prior = runs.get(key)
                observed[key] = {
                    "side": name,
                    "price": level.price,
                    "first_seen": prior["first_seen"] if prior else book.updated_at,
                    "samples": prior["samples"] + 1 if prior else 1,
                    "last_seen": book.updated_at,
                    "displayed_quantity": level.quantity,
                }
        runs = observed
    walls = []
    for wall in runs.values():
        duration = (wall["last_seen"] - wall["first_seen"]).total_seconds()
        if wall["samples"] < p["wall_min_samples"] or duration < p["wall_min_duration_seconds"]:
            continue
        distance = (wall["price"] / current - 1) * 10000
        opposing = (side == "CALL" and wall["side"] == "ask" and distance >= 0) or (
            side == "PUT" and wall["side"] == "bid" and distance <= 0
        )
        walls.append(
            {
                **wall,
                "first_seen": wall["first_seen"].isoformat(),
                "last_seen": wall["last_seen"].isoformat(),
                "duration_seconds": duration,
                "distance_bps": abs(distance),
                "blocks": opposing and abs(distance) <= p["wall_max_distance_bps"],
            }
        )
    block = any(w["blocks"] for w in walls)
    return _result(
        "BLOCK" if block else "ALLOW",
        "near_opposing_resting_wall" if block else "no_observed_wall_veto",
        current_price=current,
        walls=walls,
        samples=len(books),
        meaning="Displayed resting liquidity only",
    )


def _supply_demand(rows, side, as_of, p):
    bars = sorted(
        [r for r in rows if r["kind"] == "bar"], key=lambda r: timestamp(r["payload"]["end_at"])
    )
    n = p["displacement_lookback_bars"]
    if len(bars) < n + 1:
        return _result("UNAVAILABLE", "insufficient_completed_bars")
    if (as_of - timestamp(bars[-1]["payload"]["end_at"])).total_seconds() > p[
        "bar_max_age_seconds"
    ]:
        return _result("UNAVAILABLE", "stale_bars")
    if any(r["payload"].get("volume") is None for r in bars):
        return _result("UNAVAILABLE", "missing_bar_volume")
    uncovered_gap, recovered = _uncovered_bar_gaps(rows, bars, as_of)
    if uncovered_gap or any(
        (timestamp(b["payload"]["start_at"]) - timestamp(a["payload"]["end_at"])).total_seconds()
        > p["bar_max_gap_seconds"]
        for a, b in zip(bars, bars[1:], strict=False)
    ):
        return _result("UNAVAILABLE", "bar_data_gap")
    if any(
        (timestamp(r["payload"]["end_at"]) - timestamp(r["payload"]["start_at"])).total_seconds()
        > p["bar_max_duration_seconds"]
        for r in bars
    ):
        return _result("UNAVAILABLE", "bar_duration_exceeds_policy")
    if any(
        timestamp(b["payload"]["start_at"]) < timestamp(a["payload"]["end_at"])
        for a, b in zip(bars, bars[1:], strict=False)
    ):
        return _result("UNAVAILABLE", "overlapping_bars")
    zones = []
    for i in range(n, len(bars)):
        row, prior = bars[i], [r["payload"] for r in bars[i - n : i]]
        bar = row["payload"]
        baseline_volume = mean(b["volume"] for b in prior)
        baseline_range = mean(b["high"] - b["low"] for b in prior)
        move = (bar["close"] / bar["open"] - 1) * 10000
        if baseline_volume <= 0 or baseline_range <= 0:
            continue
        if (
            bar["volume"] < baseline_volume * p["displacement_volume_multiple"]
            or abs(move) < p["displacement_min_move_bps"]
            or bar["high"] - bar["low"] < baseline_range * p["displacement_min_range_multiple"]
        ):
            continue
        base = prior[-1]
        kind = "demand" if move > 0 else "supply"
        # A displacement must leave the prior base range in its direction.
        if (move > 0 and bar["close"] <= base["high"]) or (
            move < 0 and bar["close"] >= base["low"]
        ):
            continue
        activated = max(timestamp(r["available_at"]) for r in bars[i - n : i + 1])
        # Include all later closes known now, including late-arriving older bars.
        invalidator = next(
            (
                r
                for r in bars[i + 1 :]
                if (kind == "supply" and r["payload"]["close"] > base["high"])
                or (kind == "demand" and r["payload"]["close"] < base["low"])
            ),
            None,
        )
        age = (as_of - timestamp(bar["end_at"])).total_seconds()
        zones.append(
            {
                "kind": kind,
                "low": base["low"],
                "high": base["high"],
                "base_event_id": bars[i - 1]["event_id"],
                "displacement_event_id": row["event_id"],
                "activated_at": activated.isoformat(),
                "invalidated_by": invalidator["event_id"] if invalidator else None,
                "active": invalidator is None and age <= p["zone_max_age_seconds"],
            }
        )
    current = bars[-1]["payload"]["close"]
    for zone in zones:
        opposing = (side == "CALL" and zone["kind"] == "supply" and current <= zone["high"]) or (
            side == "PUT" and zone["kind"] == "demand" and current >= zone["low"]
        )
        distance = max(zone["low"] - current, current - zone["high"], 0) / current * 10000
        zone.update(
            distance_bps=distance,
            blocks=zone["active"] and opposing and distance <= p["zone_max_distance_bps"],
        )
    block = any(z["blocks"] for z in zones)
    return _result(
        "BLOCK" if block else "ALLOW",
        "near_opposing_supply_demand_zone" if block else "no_observed_supply_demand_veto",
        current_price=current,
        zones=zones,
        completed_bars=len(bars),
        recovered_transport_gaps_covered_by_completed_bars=recovered,
    )


def zone_review(
    rows: Sequence[Mapping[str, Any]],
    symbol: str,
    side: str,
    as_of: datetime,
    *,
    liquidity: bool,
    supply_demand: bool,
    policy: dict,
) -> dict[str, Any]:
    """Review point-in-time feed-local vetoes; never authorize or execute an order.

    Unavailable enabled branches dominate BLOCK/ALLOW. Defaults may be overridden by
    explicit policy fields; invalid policy/arguments raise ValueError, bad data fails closed.
    """
    if not isinstance(as_of, datetime) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError("as_of must be timezone-aware")
    if side not in {"CALL", "PUT"} or not isinstance(symbol, str) or not symbol.strip():
        raise ValueError("symbol and CALL|PUT side required")
    if not isinstance(liquidity, bool) or not isinstance(supply_demand, bool):
        raise ValueError("branch switches must be boolean")
    p = _policy(policy)
    evidence = {
        "mode": "PAPER_ONLY_UNVALIDATED",
        "coverage": "UNVERIFIED_FEED_COVERAGE",
        "policy": p,
        "symbol": symbol.upper(),
        "side": side,
        "as_of": as_of.isoformat(),
        "allow_meaning": "No observed veto; not entry support",
    }
    reasons, statuses = [], []
    for name, enabled, prefix, evaluator in (
        ("liquidity", liquidity, "book", _liquidity),
        ("supply_demand", supply_demand, "bar", _supply_demand),
    ):
        source, venue = p[f"{prefix}_source"], p[f"{prefix}_venue"]
        if not enabled:
            evidence[name] = {"status": "DISABLED"}
            continue
        try:
            if "UNCONFIGURED" in (source, venue):
                raise ValueError("feed_not_pinned")
            selected = []
            for row in rows:
                if (
                    row.get("symbol", "").upper() != symbol.upper()
                    or (row.get("source") != source or row.get("venue") != venue)
                    or row.get("kind") not in {prefix, "gap"}
                ):
                    continue
                if timestamp(row["event_at"]) > as_of or timestamp(row["available_at"]) > as_of:
                    continue
                if (
                    timestamp(row["available_at"]).astimezone(ET).date()
                    != as_of.astimezone(ET).date()
                ):
                    continue
                selected.append(validate(row))
            # Duplicate copies cannot manufacture persistence; conflicting copies fail closed.
            unique = {}
            for row in selected:
                key = (
                    row["kind"],
                    timestamp(row["event_at"]) if row["kind"] != "gap" else row["event_id"],
                )
                if key in unique and unique[key]["payload"] != row["payload"]:
                    raise ValueError("conflicting_observations")
                unique.setdefault(key, row)
            result = evaluator(list(unique.values()), side, as_of, p)
        except (KeyError, ValueError, TypeError, AttributeError) as exc:
            result = _result("UNAVAILABLE", f"invalid_or_missing_evidence:{exc}")
        result["evidence"].update(source=source, venue=venue, coverage="UNVERIFIED_FEED_COVERAGE")
        evidence[name] = result
        statuses.append(result["status"])
        reasons.extend(f"{name}:{r}" for r in result["reasons"])
    status = (
        "UNAVAILABLE" if "UNAVAILABLE" in statuses else "BLOCK" if "BLOCK" in statuses else "ALLOW"
    )
    return {
        "status": status,
        "reasons": reasons or ["zone_branches_disabled"],
        "evidence": evidence,
    }
