# Entry quality, speed, and actual fill accounting — November 6, 2026

## Priority and constraints

The user wants better entries and entry as quickly as possible after a setup qualifies. A fixed waiting period, pullback timer, or added confirmation that delays entry is not the objective. `TODO.txt` now places better entries and speed first, before sizing and runners. The existing execution and risk gates remain unchanged. We are looking for earlier preparation and less avoidable processing time, and for better decisions based on information already available when entry is made.

## P&L correction

[account details redacted]

The $2.10 is the project's *hypothetical execution-cost assumption*: $0.05 fee plus $1.00 slippage per side. It is not a JEV charge and does not establish that the user paid $35.70. Actual fill-to-fill prices already reflect the actual execution prices; subtracting an additional assumed slippage amount is a conservative scenario, not a separate observed cash expense. Actual broker fees were not established from these saved records. Robinhood says stock and ETF options are commission-free with no per-contract fee, while some regulatory or exchange fees may still apply; the user's own confirmations are needed for actual fees. [Robinhood options investing](https://robinhood.com/us/en/support/articles/options-investing/?region=US).

[account details redacted]

## What entry speed can currently be measured

Matched broker entry order and decision records for these 17 closed trades show a median **68.35 seconds** from the end of the selected completed five-minute candle to broker order creation, with a range of 53.16–120.82 seconds. Median broker-order creation to recorded fill was **0.26 seconds**, but one order took 79.16 seconds. See `latency/milestones.csv` and `latency/README.md`. This is only a selected, small sample of filled trades; it does not include all unfilled or missed candidates. The candle's end is not proof of when the provider delivered it or when the full setup first became actionable. Logs do not separately time every internal step, and timestamp semantics/clock skew limit finer attribution. These figures therefore do not establish that a particular component can save a particular number of seconds.

An earlier decision-packet ask was higher than the eventual fill in 11 cases, lower in 3 and equal in 3. That is a description of two separate observations, not evidence that waiting caused a better or worse fill: the packet quote was not the final pre-order quote and the sample excludes missed or unfilled trades. See `price_drift/trade_comparison.csv`. Do not treat the differences as an extra expense or add them to P&L.

## Concrete work under way

1. **Measure stages before changing them.** Record or reconstruct, using UTC and monotonic clocks where available, completed-candle receipt, discovery, eligible-pool creation, JEV ranking, fresh quote/account reads, risk checks, broker review, order submission, acknowledgement and fill. Report actual timing and missing stages; never treat an old candidate quote as the final execution quote.
2. **Test faster preparation without adding a wait.** Assess whether independent book/discovery reads, same-pool JEV evaluations, fresh option/underlying/account reads, or broker-session initialization can be safely overlapped or reused. Measure on bounded offline/mock or approved read-only evidence first. Preserve result ordering, JEV budgets/failure semantics, fresh inputs, position management, risk gates, broker review and submission idempotency. Code review found opportunities to investigate, not a measured performance gain.
3. **Measure entry quality separately.** Compare immediately submitted, fully qualified candidates using point-in-time information already available at the decision, and preserve selected/rejected candidate identities and same-contract bid/ask observations. Include missed/unfilled candidates, costs actually charged when verified, and the account effects of taking or skipping a trade. Do not invent a delayed pullback rule or label P&L from underlying shares as actual option P&L.
4. **Keep actual accounting visible.** Separate broker-fill P&L from estimates and actual fees, and report actual AI/data payments or credit usage only when supported. The existing isolated accounting reconciliation does this without altering the live ledger.

The 2022–2025 underlying confirmation proxies in `research/entry_quality_20261106/` found no robust entry gate. The archived option-path pullback examples are incomplete and conflict with the user's preference for immediate entry. They are not a production recommendation. Further research needs fresh option quote paths for both selected and rejected candidates and a common post-entry horizon.

No production trading code, strategy, configuration, live/paper account, service or order was changed by this work. `TODO.txt` was updated to reflect the user's priority. These results are retrospective and no speedup or profitable entry rule has yet been established.
