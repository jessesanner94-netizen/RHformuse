#!/usr/bin/env python3
"""Reproduce the all-account diagnostic using only recorded quote observations."""
import csv, json, math, hashlib
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime, timedelta, time
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def dt(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
def write(name, rows):
 if not rows: return
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with (HERE/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def valid(q, at):
 try:
  b,a,bs,az=(float(q[k]) for k in ('bid_price','ask_price','bid_size','ask_size'))
  age=(at-dt(q['updated_at'])).total_seconds()
  if not all(math.isfinite(x) for x in (b,a,bs,az,age)) or not(0<b<=a and bs>0 and az>0 and -2<=age<=20): return None
  return b,a,bs,az,round(age,6)
 except (KeyError,ValueError,TypeError): return None

def replay(start, ref, qs, late=False):
 deadline=start+timedelta(minutes=10); low=ref; low_at=start; prev=start; trigger=None
 for q in qs:
  at=q['time']
  if at<=start: continue
  if (at-prev).total_seconds()>30: return {'status':'UNKNOWN_PATH_GAP','reason':'over 30 seconds without an observed quote before signal'}
  if at>deadline: return {'status':'NO_ENTRY','reason':'ten-minute window covered without signal'}
  prev=at
  if q['ask']<low: low=q['ask'];low_at=at
  if low<=ref*.95+1e-10 and at>low_at and q['ask']>=low*1.02-1e-10:
   trigger=q;break
 if trigger is None:
  if prev>=deadline: return {'status':'NO_ENTRY','reason':'ten-minute window covered without signal'}
  return {'status':'UNKNOWN_NO_SIGNAL','reason':'recorded quotes ended before ten-minute watch completed'}
 out={'signal_at':trigger['time'].isoformat(),'signal_ask':trigger['ask'],'low_ask':low,'low_at':low_at.isoformat()}
 entry=trigger
 if late:
  entry=next((q for q in qs if q['time']>trigger['time']),None)
  if entry is None or (entry['time']-trigger['time']).total_seconds()>20:
   return dict(out,status='UNKNOWN_NEXT_ASK',reason='no later valid ask within 20 seconds')
  if entry['time']>deadline:
   return dict(out,status='UNKNOWN_NEXT_ASK',reason='later ask occurs after ten-minute watch')
 out.update(entry_at=entry['time'].isoformat(),entry_ask=entry['ask'],entry_source=entry['source'],stop=round(entry['ask']*.75,5),target=round(entry['ask']*1.30,5),wait_seconds=round((entry['time']-start).total_seconds(),3))
 prev=entry['time']
 for q in qs:
  if q['time']<=entry['time']:continue
  if (q['time']-prev).total_seconds()>30:
   return dict(out,status='CENSORED_GAP',reason='over 30 seconds without an observed quote after entry')
  prev=q['time']
  if q['bid']<=entry['ask']*.75+1e-10 or q['bid']>=entry['ask']*1.30-1e-10:
   p=round(100*(q['bid']-entry['ask']),2)
   return dict(out,status='STOP' if q['bid']<=entry['ask']*.75+1e-10 else 'TARGET',exit_at=q['time'].isoformat(),exit_bid=q['bid'],exit_source=q['source'],hypothetical_price_pnl=p,hypothetical_minus_2_10=round(p-2.1,2))
 return dict(out,status='CENSORED_END',reason='no observed stop or target before quote path ends')

def main():
 raw=list(csv.DictReader((HERE/'inventory/ledger_records.csv').open()))
 # Retain the final snapshot for the first experimental account, and additive's source account.
 def priority(r):
  s=r['source']; return (0 if 'session_expiry_20261025' in s else 1 if 'additive_20261022' in s else 2,s)
 seen=set();rows=[]
 for r in sorted(raw,key=priority):
  key=(r['carried_group'],r['record_sha256']) if r['carried_group'] else None
  if key and key in seen:continue
  if key:seen.add(key)
  rows.append(r)
 assert len(rows)==104 and Counter(x['mode'] for x in rows)=={'live':23,'paper':81}
 positions={}
 for s in {r['source'] for r in rows}:
  for v in json.loads((ROOT/s).read_text()).get('recent_closed_positions',[]):
   positions[(s,str(v.get('paper_id') or v.get('position_id') or v.get('id')))]=v
 for r in rows:
  key=(r['source'],r['paper_id'] or r['position_id'])
  assert key in positions,(key,'position not found')
  assert int(positions[key]['quantity'])==1
 # Join a live reference only from the original broker entry order, before its fill.
 refs=defaultdict(list); event_hashes={}
 for ep in ['state/live/EVENTS.jsonl','state/options/python_jev_green_lock_20261009/live/EVENTS.jsonl']:
  event_hashes[ep]=hashlib.sha256((ROOT/ep).read_bytes()).hexdigest()
  for line in (ROOT/ep).open():
   x=json.loads(line)
   if x.get('event')!='LIVE_ENTRY_REVIEW_OR_SUBMISSION':continue
   result=x.get('result',{});place=result.get('placement',{});req=place.get('request',{});order=place.get('result',{}).get('data',{}).get('order',{})
   try:
    if result['order_id']!=order['id'] or len(req['legs'])!=1 or int(req['quantity'])!=1:continue
    price=float(req['price']);at=dt(order['created_at']);contract=req['legs'][0]['option_id']
    if price<=0:continue
    refs[result['order_id']].append((at,price,contract,ep))
   except (KeyError,ValueError,TypeError):continue
 for r in rows:
  r['original_price_pnl']=round((float(r['exit_price'])-float(r['entry_price']))*100,2)
  if r['mode']=='paper':
   r['reference_time']=r['entry_at'];r['reference_price']=float(r['entry_price']);r['reference_kind']='paper recorded entry ask'
  else:
   candidates={(a,b,c,d) for a,b,c,d in refs[r['entry_order_id']] if c==r['contract_identifier'] and a<=dt(r['entry_at'])}
   if len(candidates)==1:
    a,b,c,d=next(iter(candidates));r['reference_time']=a.isoformat();r['reference_price']=b;r['reference_kind']='original live order limit, not verified ask';r['reference_source']=d
   else:r['reference_kind']='unavailable or ambiguous original order reference'
 relevant={(r['contract_identifier'],r['entry_at'][:10]) for r in rows}
 paths=sorted(ROOT.glob('research/options_lab/experiments/*/forward/MONITOR.jsonl'))
 pool=defaultdict(dict); bad=Counter();hashes={}
 for p in paths:
  h=hashlib.sha256();name=str(p.relative_to(ROOT))
  with p.open('rb') as f:
   for line in f:
    h.update(line)
    try: row=json.loads(line);at=dt(row['as_of'])
    except (ValueError,KeyError,TypeError):continue
    # Conservative fixed regular-session cutoff; do not invent an exit at this time.
    if at.astimezone(ZoneInfo('America/New_York')).time()>time(15,45):continue
    for item in row.get('quote_refresh',{}).get('option_quotes',[]):
     q=item.get('quote') or {};contract=q.get('instrument_id') or (item.get('close') or {}).get('instrument_id');key=(contract,at.date().isoformat())
     if key not in relevant:continue
     values=valid(q,at)
     if values is None:bad[name]+=1;continue
     bid,ask,bs,az,age=values;entry={'time':at,'bid':bid,'ask':ask,'bid_size':bs,'ask_size':az,'age_seconds':age,'source':name}
     old=pool[key].get(at)
     if old is None:pool[key][at]=entry
     elif old is False:pass
     elif (old['bid'],old['ask'],old['bid_size'],old['ask_size'])!=(bid,ask,bs,az):pool[key][at]=False
     else:old['source']=';'.join(sorted(set(old['source'].split(';')+[name])))
  hashes[name]=h.hexdigest()
 quotes=[];collisions=0
 for (contract,date),obs in pool.items():
  for at,q in obs.items():
   if not q:collisions+=1;continue
   quotes.append(dict(contract=contract,date=date,at=at.isoformat(),**{k:v for k,v in q.items() if k!='time'}))
 write('sampled_quotes.csv',quotes)
 outputs=[]
 for r in rows:
  key=(r['contract_identifier'],r['entry_at'][:10]);allqs=sorted((q for q in pool.get(key,{}).values() if q),key=lambda x:x['time'])
  start=dt(r['reference_time']) if r.get('reference_time') else None
  qs=[q for q in allqs if start and q['time']>start]
  r.update(quote_count=len(qs),first_quote_at=qs[0]['time'].isoformat() if qs else '',last_quote_at=qs[-1]['time'].isoformat() if qs else '',quote_sources=';'.join(sorted({p for q in qs for p in q['source'].split(';')})))
  for late in (False,True):
   if not start:result={'status':'UNAVAILABLE_REFERENCE','reason':'no unique original pre-fill order reference'}
   elif not qs:result={'status':'UNAVAILABLE_NO_QUOTES','reason':'no matching valid quotes after decision'}
   else:result=replay(start,float(r['reference_price']),qs,late)
   outputs.append(dict(record_sha256=r['record_sha256'],source=r['source'],mode=r['mode'],entry_at_original=r['entry_at'],symbol=r['symbol'],contract=r['contract_identifier'],original_price_pnl=r['original_price_pnl'],arm='next_quote' if late else 'signal_quote',**result))
 write('all_trades.csv',rows);write('replay_results.csv',outputs)
 summary={'population':dict(Counter(r['mode'] for r in rows)),'references':dict(Counter((r['mode']+' '+r['reference_kind']) for r in rows)),'quotes_by_mode':{m:sum(bool(r['quote_count']) for r in rows if r['mode']==m) for m in ('live','paper')},'results':{f'{m} {arm}':dict(Counter(x['status'] for x in outputs if x['mode']==m and x['arm']==arm)) for m in ('live','paper') for arm in ('signal_quote','next_quote')},'conflicting_timestamps_dropped':collisions,'invalid_matching_quotes':dict(bad),'monitor_sha256':hashes,'live_event_sha256':event_hashes}
 (HERE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
