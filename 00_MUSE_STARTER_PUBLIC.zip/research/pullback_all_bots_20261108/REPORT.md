# Pullback/rebound entry replay across recorded bot trades

Research only — 2026-11-08. **Follow-up:** Saved Robinhood one-minute bars were subsequently found; see `option_bar_followup/REPORT.md`. For the Nov. 4 delayed entry, a saved $1.91 bid implies +$44 at that quote, though it misses the exact 30% threshold by $0.001 per share. Counts describe saved local ledgers, not verified account state or a complete history of rejected signals.

## Population and result

104 account-level closed records: 23 live and 81 paper. Seven exact carried-forward ledger copies were removed; different account controls remain separate. These are not 104 independent market opportunities. Six legacy live trades and many older paper trades lack matching continuous quote records. The earlier paper-only diagnostic contained 12 paper positions; this expanded replay adds three additive-control positions and four live positions with matching quote histories.

| Account | Saved trades | No eligible quote path | No entry within fully observed watch | Signal, outcome unknown | Signal-quote target |
|---|---:|---:|---:|---:|---:|
| Live | 23 | 19 | 2 | 1 | 1 |
| Paper | 81 | 66 | 3 | 9 | 3 |

A signal-quote target assumes an immediate entry at the same recorded ask that confirmed the rebound. For the next-observation sensitivity, only one of the 14 signals has a known target outcome; 13 are censored. The five no-entry records are unchanged. Three additive paper controls share a contract and overlapping observations; the Nov. 4 paper/live results share the same quote path. These rows are not independent samples.

## The 19 trades with matching quote observations

Dollar results are price P&L for one contract, before unverified broker fees; original live figures use actual entry and exit fills. Hypothetical figures use recorded asks and bids, not fills. Dates are UTC, which agrees with the listed trading dates. “Unknown” is not a loss.

| Date | Account | SPY strike/type | Original P&L | Signal quote outcome | Next quote outcome |
|---|---|---|---:|---|---|
| 2026-10-22 | Additive baseline | 758 PUT | $-41.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-22 | Additive news_reaction | 758 PUT | $-40.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-22 | Additive liquidity | 758 PUT | $-39.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-22 | Paper first bot | 754 PUT | $-39.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-23 | Paper first bot | 752 PUT | $-33.00 | Target $+38.00 | Target $+38.00 |
| 2026-10-26 | Paper first bot | 771 CALL | $+35.00 | Target $+35.00 | Unknown: recording ended |
| 2026-10-27 | Paper first bot | 776 CALL | $+42.00 | No entry | No entry |
| 2026-10-28 | Paper first bot | 762 PUT | $-40.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-29 | Paper first bot | 760 PUT | $-34.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-29 | Live | 760 PUT | $-33.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-10-30 | Paper first bot | 753 PUT | $-30.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-11-02 | Paper volatility | 767 CALL | $+50.00 | No entry | No entry |
| 2026-11-02 | Live | 767 CALL | $+50.00 | No entry | No entry |
| 2026-11-03 | Paper volatility | 765 CALL | $-39.00 | No entry | No entry |
| 2026-11-03 | Live | 765 CALL | $-39.00 | No entry | No entry |
| 2026-11-04 | Paper volatility | 773 CALL | $-38.00 | Target $+45.00 | Unknown: recording ended |
| 2026-11-04 | Live | 773 CALL | $-39.00 | Target $+45.00 | Unknown: recording ended |
| 2026-11-04 | Paper first bot | 775 CALL | $-30.00 | Unknown: recording ended | Unknown: recording ended |
| 2026-11-06 | Paper volatility | 749 CALL | $-41.00 | Unknown: quote gap | Unknown: quote gap |

The two paper winners among the three no-entry paper cases made +$42 and +$50 on the original fill-price basis. The +$50 paper trade is the same opportunity as the live +$50 no-entry row. Waiting can miss winning trades.

## Rule and controls

For each paper trade, start from its recorded entry ask. For live records use the original submitted buy-limit price at broker order creation, before its actual fill. A limit is not necessarily the ask, so the live exercise tests a related proxy, not exactly the paper rule. Wait at most ten minutes for the ask to fall 5% below that reference and then rise 2% above its lowest sampled ask on a later observation. The second arm buys at the next saved ask within 20 seconds, provided it is within the watch window. Both arms then look for a bid at a fixed 25% stop or 30% target, computed from the hypothetical ask. The fixed exits enable a comparison; this is not a full reconstruction of each bot’s original exit, order placement, account constraints, time exits or later trades.

Require a valid noncrossed positive bid/ask and positive sizes, provider timestamp no more than 20 seconds old or 2 seconds ahead of the observation timestamp, exact option ID and no greater than 30 seconds between observations. That 2-second allowance admits clock skew and means exact quote availability at the stamped instant is not proven. Each quote is sampled, not a continuous tick tape. Do not bridge large gaps or extrapolate beyond recorded observations. Quote streams were originally collected by paper monitors, including for matching live contracts; this does not mean the live bot monitored or could fill at those exact prices. Saved quotes after the original exit count only if another source actually recorded them. Quotes after 15:45 New York time are excluded conservatively. No time-based exit is invented. A quoted price is not a guaranteed fill; see [Investor.gov on execution](https://www.investor.gov/introduction-investing/investing-basics/how-stock-markets-work/executing-order).

For Nov. 4 SPY 773 call, the paper original was $1.52 to $1.14 (−$38 before fees). The paper signal-price simulation buys at $1.46 and reaches a $1.91 observed bid (+$45); the next saved ask is $1.47, and its eventual outcome is unknown because that path does not reach its recomputed target or stop before the observations end. The separate live trade on the same contract was −$39 before fees and uses the same $1.46/$1.91 hypothetical observations. They are one market episode, not two independent confirmations.

The earlier $42.90 hypothetical and −$40.10 original were each reduced by an assumed $2.10 round-trip cost. That was a scenario, not a verified charge or JEV payment. This replay reports the $45/−$38 price results first, with a separate optional $2.10 sensitivity column in the CSV. The user reports $0 cash paid for JEV so far; no JEV charge has been deducted. Actual broker fees, if any, need separate transaction evidence.

## Data limits and reproduction

The 85 records without valid matching monitored quotes are not failed signals and cannot be replayed. Sparse legacy cycle snapshots lack the required path and displayed sizes. The connected Alpaca interface exposed latest option quotes but no historical option-quote method; access to a complete authenticated historical option bid/ask source was not established. Alpaca documents its free indicative feed as modified, rather than actual OPRA quotes: [historical options data](https://docs.alpaca.markets/us/docs/historical-option-data). Do not infer that a dataset is available, free, or adequate from documentation alone.

Files: `inventory/ledger_records.csv` (raw account inventory and lineage); `all_trades.csv` (104 retained observations); `sampled_quotes.csv` (matching valid source observations); `replay_results.csv` (both assumptions for every retained observation); `summary.json` (counts and source hashes); `PROTOCOL.md` (prespecified rules); `data_probe/FINDINGS.md` (availability). Run `python3 research/pullback_all_bots_20261108/replay.py` and `python3 -m unittest discover -s research/pullback_all_bots_20261108 -p "test_*.py" -v` from the project root. The source archives remain unchanged.

The observations do not establish whether the entry rule improves the bot overall. Additional prospective recording of the same contracts for the full watch and hypothetical holding period, including after an original trade exits, would allow a less censored comparison. Keep live and paper results and shared market episodes identifiable.
