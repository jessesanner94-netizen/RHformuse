#!/usr/bin/env python3
"""Inventory ledger records without merging independent account fills. Run from project root."""
import csv, glob, json, hashlib, os
from collections import defaultdict
from pathlib import Path
out=Path('research/pullback_all_bots_20261108/inventory')
papers=sorted(glob.glob('state/**/PORTFOLIO.json',recursive=True)+glob.glob('research/options_lab/experiments/*/forward/accounts/*/state/options/*/paper/PORTFOLIO.json'))
lives=['state/live/STATE.json','state/options/python_jev_green_lock_20261009/live/STATE.json']
rows=[]; sources=[]
for p in papers+lives:
 x=json.load(open(p)); live=p in lives
 closed=x.get('recent_closed_positions',[]); opened=x.get('positions' if live else 'open_positions',[])
 sources.append(dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest(),closed_reported=x.get('closed_trade_count',len(closed)),closed_records=len(closed),open_records=len(opened),updated_at=x.get('updated_at'),epoch=x.get('strategy_epoch','legacy'),mode='live' if live else 'paper'))
 for status,items in [('closed',closed),('open',opened)]:
  for t in items:
   d={k:t.get(k) for k in ['paper_id','position_id','contract_identifier','symbol','expiration','strike','option_type','entry_at','entry_price','exit_at','exit_price','realized_pnl','entry_order_id']}
   d.update(source=p,mode='live' if live else 'paper',ledger_epoch=x.get('strategy_epoch','legacy'),status=status,record_sha256=hashlib.sha256(json.dumps(t,sort_keys=True,separators=(',',':')).encode()).hexdigest())
   d['identity']=(d['position_id'] or d['entry_order_id']) if live else ((d['paper_id'] or '')+'|'+(d['contract_identifier'] or ''))
   rows.append(d)
by=defaultdict(list)
for r in rows:by[(r['mode'],r['identity'])].append(r['source'])
for r in rows:
 r['shared_identity_count']=len(by[(r['mode'],r['identity'])]);r['shared_identity_sources']=';'.join(by[(r['mode'],r['identity'])])
 # Only named lineage copy groups, requiring identical full position records.
 lineage={'paper-20261022T153044-71372551','paper-20261023T135548-dfdb970b','paper-20261022T135045-eaa16a56'}
 peers=[q for q in rows if q['paper_id']==r['paper_id'] and q['paper_id'] in lineage and q['record_sha256']==r['record_sha256']]
 r['carried_copy_count']=len(peers) if peers else 1
 r['carried_group']=r['paper_id'] if len(peers)>1 else ''

fields=['mode','ledger_epoch','status','identity','shared_identity_count','source','shared_identity_sources','carried_group','carried_copy_count','record_sha256','paper_id','position_id','entry_order_id','contract_identifier','symbol','expiration','strike','option_type','entry_at','entry_price','exit_at','exit_price','realized_pnl']
with (out/'ledger_records.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
with (out/'ledger_sources.json').open('w') as f:json.dump(sources,f,indent=2)
print('records',len(rows),'unique shared identities by mode', {m:len({r['identity'] for r in rows if r['mode']==m and r['status']=='closed'}) for m in ['live','paper']},'open',sum(r['status']=='open' for r in rows))
