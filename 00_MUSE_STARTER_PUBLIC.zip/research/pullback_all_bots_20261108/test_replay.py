import unittest
from datetime import datetime,timedelta,timezone
from replay import replay,valid

T=datetime(2026,11,4,14,tzinfo=timezone.utc)
def q(sec,ask,bid=None):return {'time':T+timedelta(seconds=sec),'ask':ask,'bid':bid if bid is not None else ask-.01,'source':'test'}
class ReplayTests(unittest.TestCase):
 def test_crossed_stale_future_and_size(self):
  x={'bid_price':'1','ask_price':'1.1','bid_size':'1','ask_size':'1','updated_at':T.isoformat()}
  self.assertIsNotNone(valid(x,T))
  for change in ({'bid_price':'1.2'},{'updated_at':(T-timedelta(seconds=21)).isoformat()},{'updated_at':(T+timedelta(seconds=3)).isoformat()},{'ask_size':'0'}):self.assertIsNone(valid(dict(x,**change),T))
 def test_no_lookahead_and_later_rebound(self):
  xs=[q(10,.95),q(20,.94),q(30,.96),q(40,1.3,1.25)]
  r=replay(T,1,xs);self.assertEqual(r['status'],'TARGET');self.assertEqual(r['entry_ask'],.96);self.assertEqual(r['low_ask'],.94)
 def test_censor_and_latency(self):
  xs=[q(10,.95),q(20,.97),q(30,.98)]
  self.assertEqual(replay(T,1,xs)['status'],'CENSORED_END')
  r=replay(T,1,xs,True);self.assertEqual(r['entry_ask'],.98);self.assertEqual(r['status'],'CENSORED_END')
  self.assertEqual(replay(T,1,xs[:2],True)['status'],'UNKNOWN_NEXT_ASK')
 def test_covered_vs_missing(self):
  self.assertEqual(replay(T,1,[q(10,1)])['status'],'UNKNOWN_NO_SIGNAL')
  self.assertEqual(replay(T,1,[q(i,1) for i in range(30,631,30)])['status'],'NO_ENTRY')
  self.assertEqual(replay(T,1,[q(10,1),q(50,1)])['status'],'UNKNOWN_PATH_GAP')
 def test_exit_gap(self):
  self.assertEqual(replay(T,1,[q(10,.95),q(20,.97),q(60,1.4,1.3)])['status'],'CENSORED_GAP')
if __name__=='__main__':unittest.main()
