# Option price-history follow-up

Research-only follow-up to the all-bot pullback/rebound diagnostic. All times below are UTC; Nov. 4 was Eastern Standard Time (UTC−5). No estimated JEV, broker, or slippage charge is subtracted. Historical bars and observed quotes do not guarantee a hypothetical order would execute.

## Correction: saved bars exist

The earlier data probe incorrectly suggested the saved monitoring requests did not contain useful option historical bars. A direct scan found **688 distinct, completed, nonconflicting Robinhood one-minute OHLC bars across 13 instrument/date pairs**, stored in the experiments' `quote_refresh.tp_history` fields. One conflicting instrument/minute was excluded. The observations are repeated in many monitor snapshots; they are not 688 independent contracts. We have not established whether the bars are last trades, marks, or another Robinhood price convention; do not describe the bar high as a confirmed trade or bid. No new authenticated historical retrieval was completed. The saved histories are still limited to periods when monitors fetched them and generally do not establish post-exit coverage.

The extractor validates the instrument UUID, matches each saved contract/date, requires the bar to have completed by its first saved observation, checks OHLC consistency, merges identical observations, and drops conflicts. `saved_bars.csv` records the source and first observation time.

## Nov. 4 SPY 773 call, expiry Nov. 6

The original paper trade entered $1.52 and exited $1.14, a $38 fill-price loss per contract. The live trade was a separate account record in the same contract and market episode.

- The delayed test entered hypothetically at the recorded $1.47 ask, 14:55:30.417 UTC.
- Its exact +30% target is $1.911, and the 25% stop is $1.1025.
- The 15:17 UTC Robinhood option bar has O $1.79, H $1.92, L $1.79, C $1.84. The bar's $1.92 high exceeds $1.911, but the source's exact price convention and a fill at $1.92 are unverified. The existing bot's optional paper trade-through policy uses **high strictly greater than** its cent-rounded target, which here would be $1.92; equality at $1.92 is insufficient under that assumption.
- At 15:17:44.169 UTC the separately recorded quote was **$1.91 bid / $1.92 ask**. In the contiguous 137 sampled observations after the hypothetical entry up to and including that quote, the lowest bid was $1.30 and the largest gap between samples was 10.461 seconds. An assumed exit at the observed $1.91 bid yields **+$44 per contract, or +29.93197%**, before fees, with no JEV charge. This is a quote-based scenario, not an executed fill and not proof the bid never fell below the stop between samples.
- The exact 30% strict quote rule was not observed: $1.91 is $0.001 per share, or $0.10 per contract, below $1.911. Therefore its strict-rule result remains censored, even though a +$44 exit was observable under a different exit decision. A rule permitting this slightly lower target would need separate out-of-sample evaluation; it must not be silently substituted in the original backtest.

The earlier phrase that the recording “ended too soon” hid useful information. The quote record actually continued until 15:49 UTC; it simply never showed a bid meeting that exact target or the stop before it ended. The new finding supports a possible nearly 30% quote-based exit, not the claim that a 30% limit actually filled.

## Broader observations

`observed_bid_paths.csv` records, for all 14 hypothetical next-quote entries, the highest saved bid reached before the first greater-than-30-second observation gap or the first observed strict target/stop. The reported best bid is a hindsight observation and cannot be used as the result of a fixed exit rule. It also is not proof of an actual fill. A few results have the same underlying contract and observation path across separate live/paper or control accounts; they are not independent episodes. `../all_trades.csv` still covers all 104 account records and identifies the 85 without a matching continuous held-monitor quote path.

The older public [TradeRecount historical option lookup](https://traderecount.com/options/) states that it includes expired-contract one-minute bars through October 2, 2026, so it may help investigate some September records, but its documented cutoff cannot cover this November case. The connected Alpaca plugin exposes latest option quotes and stock historical bars, not a historical option-bar method. An attempted direct read-only Robinhood history request did not return an authenticated result during this investigation; there was no saved token for the existing direct MCP client. No new subscription, connection, or account change was made.

## Reproduce

From project root:

```
python3 research/pullback_all_bots_20261108/option_bar_followup/extract_saved_bars.py
python3 research/pullback_all_bots_20261108/option_bar_followup/summarize_paths.py
```

The underlying quote path and original strict assumptions remain in `../sampled_quotes.csv`, `../replay_results.csv`, and `../PROTOCOL.md`. The quote recording has approximately 10-second sampling, so it can miss intraperiod stops and brief bids.
