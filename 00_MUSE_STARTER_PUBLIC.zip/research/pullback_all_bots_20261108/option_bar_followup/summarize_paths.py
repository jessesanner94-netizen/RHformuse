#!/usr/bin/env python3
"""Summarize observed follow-up quotes, not hypothetical executions."""
import csv
from pathlib import Path
from datetime import datetime
from collections import defaultdict
P=Path(__file__).resolve().parent
D=lambda x:datetime.fromisoformat(x.replace('Z','+00:00'))
trades={r['record_sha256']:r for r in csv.DictReader((P.parent/'all_trades.csv').open())}
quotes=defaultdict(list)
for q in csv.DictReader((P.parent/'sampled_quotes.csv').open()):quotes[(q['contract'],q['date'])].append(q)
results=[]
for r in csv.DictReader((P.parent/'replay_results.csv').open()):
 if r['arm']!='next_quote' or not r['entry_at']:continue
 t=trades[r['record_sha256']];entry=D(r['entry_at']);last=entry;seq=[]
 for q in sorted(quotes[(r['contract'],r['entry_at_original'][:10])],key=lambda x:x['at']):
  at=D(q['at'])
  if at<=entry:continue
  if (at-last).total_seconds()>30:break
  seq.append(q);last=at
  if r['exit_at'] and at>=D(r['exit_at']):break
 if not seq:continue
 best=max(seq,key=lambda x:float(x['bid']));entry_price=float(r['entry_ask']);best_bid=float(best['bid'])
 results.append({'date':r['entry_at_original'][:10],'mode':r['mode'],'source':r['source'],'contract':r['contract'],'strike':t['strike'],'option_type':t['option_type'],'hypothetical_entry_time':r['entry_at'],'hypothetical_entry_ask':entry_price,'observed_highest_bid':best_bid,'highest_bid_at':best['at'],'best_observed_bid_pnl_one_contract':round(100*(best_bid-entry_price),2),'best_observed_bid_return_pct':round(100*(best_bid/entry_price-1),4),'sample_count_after_entry':len(seq),'last_contiguous_quote_at':seq[-1]['at'],'original_entry_exit_price_pnl':r['original_price_pnl'],'prior_strict_outcome':r['status']})
with (P/'observed_bid_paths.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=results[0].keys());w.writeheader();w.writerows(results)
print(len(results),'hypothetical next-quote entries summarized; overlapping accounts remain separate.')
