#!/usr/bin/env python3
import json,csv,glob,math
from pathlib import Path
from datetime import datetime,timedelta
from collections import defaultdict,Counter
P=Path(__file__).resolve().parent;ROOT=P.parents[2]
def dt(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
trades=list(csv.DictReader((P.parent/'all_trades.csv').open()))
wanted={(x['contract_identifier'],x['entry_at'][:10]) for x in trades}
records={};conflicts=set();stats=Counter()
for path in sorted(ROOT.glob('research/options_lab/experiments/*/forward/MONITOR.jsonl')):
 source=str(path.relative_to(ROOT))
 with path.open() as f:
  for line in f:
   try:
    r=json.loads(line);at=dt(r['as_of']);hist=r.get('quote_refresh',{}).get('tp_history') or {}
    for contract,entry in hist.items():
     if entry.get('status')!='OK':continue
     for result in entry.get('results',[]):
      if result.get('instrument_id')!=contract:continue
      for bar in result.get('bars',[]):
       stamp=dt(bar['begins_at']);key=(contract,stamp.date().isoformat(),stamp)
       if key[:2] not in wanted or stamp+timedelta(minutes=1)>at:continue
       vals=tuple(float(bar[k]) for k in ('open_price','high_price','low_price','close_price'))
       if not all(math.isfinite(x) and x>=0 for x in vals) or vals[1]<max(vals[0],vals[2],vals[3]) or vals[2]>min(vals[0],vals[1],vals[3]):stats['invalid']+=1;continue
       old=records.get(key);new={'contract':contract,'date':key[1],'begins_at':stamp.isoformat(),'open':vals[0],'high':vals[1],'low':vals[2],'close':vals[3],'source':source,'first_seen_at':at.isoformat(),'occ_symbol':result.get('occ_symbol','')}
       if old and tuple(old[k] for k in ('open','high','low','close'))!=vals:conflicts.add(key)
       elif old:
        old['source']=';'.join(sorted(set(old['source'].split(';')+[source])))
        if at<dt(old['first_seen_at']):old['first_seen_at']=at.isoformat()
       else:records[key]=new
   except (ValueError,TypeError,KeyError):stats['parse_errors']+=1
bars=[v for k,v in sorted(records.items()) if k not in conflicts]
with (P/'saved_bars.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['contract','date','begins_at','open','high','low','close','source','first_seen_at','occ_symbol']);w.writeheader();w.writerows(bars)
print('completed bars',len(bars),'contracts/dates',len({(x['contract'],x['date']) for x in bars}),'conflicting bars dropped',len(conflicts),'other stats',dict(stats))
replays=list(csv.DictReader((P.parent/'replay_results.csv').open()))
for x in replays:
 if x['arm']!='next_quote' or not x['entry_at'] or not x['status'].startswith('CENSORED'):continue
 matching=[b for b in bars if b['contract']==x['contract'] and b['date']==x['entry_at_original'][:10] and dt(b['begins_at'])>=dt(x['entry_at'])]
 hits=[b for b in matching if b['low']<=float(x['stop']) or b['high']>=float(x['target'])]
 if hits:print(x['mode'],x['entry_at_original'][:10],x['symbol'],x['entry_ask'],'stop',x['stop'],'target',x['target'],'first bar',hits[0], 'bar count',len(matching))
