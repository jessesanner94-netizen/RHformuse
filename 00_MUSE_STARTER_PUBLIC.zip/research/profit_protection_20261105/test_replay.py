import importlib.util,unittest
from datetime import datetime,timedelta,timezone
from pathlib import Path
s=importlib.util.spec_from_file_location('research',Path(__file__).with_name('replay.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
class Tests(unittest.TestCase):
 def setUp(self):
  self.t0=datetime(2026,11,4,14,30,tzinfo=timezone.utc)
  self.trade={'paper_id':'p','entry_at':self.t0.isoformat(),'exit_at':(self.t0+timedelta(minutes=60)).isoformat(),'contract':'x','strike':1,'expiration':'2026-11-06','option_type':'CALL','entry_price':1.,'target':1.3,'reported_net_pnl':-27.1,'exit_price':.75,'quotes':[]}
 def q(self,s,b):return {'timestamp':(self.t0+timedelta(seconds=s)).isoformat(),'bid':b}
 def test_tighter_stop_precedes_later_twenty_percent(self):
  self.trade['quotes']=[self.q(1,.89),self.q(2,1.21),self.q(3,.75)]
  v={'name':'test','stop':.10,'tp':.20}
  out=r.simulate(self.trade,v,{})
  self.assertEqual(out['exit_bid'],.89);self.assertEqual(out['later_tp20_seen'],1);self.assertEqual(out['net_pnl'],-13.1)
 def test_breakeven_floor_gaps_through(self):
  self.trade['quotes']=[self.q(1,1.21),self.q(2,1.00)]
  v={'name':'test','stop':.15,'tp':.30,'act':.20,'floor':'BE'}
  out=r.simulate(self.trade,v,{})
  self.assertEqual(out['threshold'],1.03);self.assertEqual(out['net_pnl'],-2.1);self.assertEqual(out['threshold_shortfall'],3.)
 def test_delayed_macd_never_exits_before_receipt_or_same_quote(self):
  self.trade['quotes']=[self.q(1,1.21),self.q(8,1.10),self.q(10,1.09),self.q(11,1.08)]
  v={'name':'test','stop':.15,'tp':.30,'act':.20,'floor':'NONE','indicator':'MACD'}
  data={('2026-11-04','first_bot'):({}, {}, {'CALL':[(self.t0+timedelta(seconds=10),self.t0+timedelta(seconds=5))]}, {'CALL':self.t0}, [])}
  out=r.simulate(self.trade,v,data)
  self.assertEqual(out['exit_bid'],1.08);self.assertEqual(out['exit_reason'],'MACD')
 def test_missing_indicator_data_is_reported(self):
  self.trade['quotes']=[self.q(1,1.21),self.q(2,.8)]
  v={'name':'test','stop':.15,'tp':.30,'act':.20,'floor':'NONE','indicator':'MACD'}
  self.assertEqual(r.simulate(self.trade,v,{})['indicator_bars_available'],0)
 def test_future_bar_cannot_affect_prefix(self):
  bars=[]
  for i in range(100):
   price=100 if i<65 else 100-(i-64)*.2
   bars.append({'ts':self.t0+timedelta(minutes=i),'open':price,'high':price+.1,'low':price-.1,'close':price,'volume':1})
  pre=r.indicators(bars[:80]);whole=r.indicators(bars);cut=self.t0+timedelta(minutes=80,seconds=1)
  for key in set(pre[0])|set(whole[0]):self.assertEqual(pre[0].get(key,[]),[x for x in whole[0].get(key,[]) if x[0]<=cut])
  for key in set(pre[2])|set(whole[2]):self.assertEqual(pre[2].get(key,[]),[x for x in whole[2].get(key,[]) if x[0]<=cut])
 def test_delayed_bars_wait_for_prior_data(self):
  bars=[]
  for i in range(40):
   now=self.t0+timedelta(minutes=i);delay=timedelta(minutes=20) if i==5 else timedelta(minutes=1,seconds=1)
   bars.append({'ts':now,'available_at':now+delay,'open':100,'high':101,'low':99,'close':100,'volume':1})
  records=r.indicators(bars)[4]
  self.assertGreaterEqual(records[6]['at'],bars[5]['available_at'])
if __name__=='__main__':unittest.main()
