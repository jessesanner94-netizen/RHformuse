#!/usr/bin/env python3
"""Explore fixed exits and activated indicators against exact-contract quotes; PROTOCOL.md."""
import bisect,csv,importlib.util,json,math,statistics
from collections import defaultdict
from datetime import timedelta
from pathlib import Path
HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/'profit_protection_20261103'/'exit_research'/'replay.py'
spec=importlib.util.spec_from_file_location('previous',PRIOR);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
dt=old.dt

def write(name,rows):
    if rows:
        with (HERE/name).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def indicators(bars):
    prev_signals,prev_ready=old.signals(bars,1)
    emafast=emaslow=signal=None; atr=None; trs=[]; levels=[]; records=[]; macd={};ready={}; streak=defaultdict(int);nonadverse=defaultdict(bool);was=defaultdict(bool)
    previous=None; availability_map={}; latest_available=None
    for i,b in enumerate(bars):
        if previous and (b['ts']-previous['ts']).total_seconds()!=60: raise ValueError('gapped bars require reset; no valid evaluation')
        close=b['close'];tr=b['high']-b['low'] if previous is None else max(b['high']-b['low'],abs(b['high']-previous['close']),abs(b['low']-previous['close']))
        trs.append(tr)
        if i==13:atr=sum(trs)/14
        elif i>13:atr=(13*atr+tr)/14
        emafast=close if emafast is None else emafast+(2/13)*(close-emafast)
        emaslow=close if emaslow is None else emaslow+(2/27)*(close-emaslow)
        mac=emafast-emaslow;signal=mac if signal is None else signal+(2/10)*(mac-signal); hist=mac-signal
        closed=b['ts']+timedelta(minutes=1); nominal=closed+timedelta(seconds=1)
        available=max(b.get('available_at',nominal),nominal,latest_available or nominal);latest_available=available;availability_map[nominal]=available
        records.append({'at':available,'closed':closed,'close':close,'atr':atr})
        if i>=34:
            for typ in ('CALL','PUT'):
                oriented=hist*(1 if typ=='CALL' else -1); bad=oriented/close < -.0001
                ready.setdefault(typ,available)
                if bad: streak[typ]+=1
                else:streak[typ]=0;nonadverse[typ]=True
                hit=bad and streak[typ]>=2
                if hit and nonadverse[typ] and not was[typ]:macd.setdefault(typ,[]).append((available,bars[i-1]['ts']+timedelta(minutes=1)))
                was[typ]=hit
        previous=b
    prev_signals={k:[(availability_map[a],first-timedelta(seconds=1)) for a,first in vals] for k,vals in prev_signals.items()}
    prev_ready={k:availability_map[val] for k,val in prev_ready.items()}
    return prev_signals,prev_ready,macd,ready,records

def variants():
    out=[]
    for tp,stop in ((30,25),(20,15),(20,20),(30,15),(20,10),(30,10)):
        out.append({'name':f'TP{tp}_STOP{stop}','tp':tp/100,'stop':stop/100})
    for mode in ('BE','P5','TRAIL10'):
        out.append({'name':f'ACT20_{mode}_TP30_STOP15','tp':.30,'stop':.15,'act':.20,'floor':mode})
    for kind in ('SUPER','CLOUD2','MACD','ATR2'):
        for floor in ('NONE','BE'):
            out.append({'name':f'ACT20_{kind}_{floor}_TP30_STOP15','tp':.30,'stop':.15,'act':.20,'floor':floor,'indicator':kind})
    return out

def simulate(t,v,data):
    e=t['entry_price'];q=t['quotes'];stop=e*(1-v['stop']);target=e*(1+v['tp']); high=e;active=None;actbid=None;sigtime=None;threshold=None;indicator_level=None;indicator_close=None; reason=None;out=None;ready=None;history=[];reference=None;trail=None;idx=0
    kind=v.get('indicator'); typ=t['option_type']; bot='volatility' if t['paper_id'] in VOL_IDS else 'first_bot'; data=data.get((t['entry_at'][:10],bot)); available=data is not None
    signals=[];barrecords=[]
    if data and kind:
        ps,pr,mac,mr,barrecords=data
        if kind=='SUPER':signals=ps.get(('super',typ,1),[]);ready=pr.get(('super',typ))
        elif kind=='CLOUD2':signals=ps.get(('cloud2',typ,2),[]);ready=pr.get(('cloud2',typ))
        elif kind=='MACD':signals=mac.get(typ,[]);ready=mr.get(typ)
        elif kind=='ATR2':ready=next((b['at'] for b in barrecords if b['atr'] is not None),None)
    for quote in q:
        at=dt(quote['timestamp']);bid=quote['bid'];high=max(high,bid)
        if bid>=target:reason='TARGET';out=quote;break
        if bid<=stop:reason='STOP';threshold=stop;out=quote;break
        if not v.get('act'):continue
        if active is None and bid>=e*1.2: active=at;actbid=bid
        if active is None:continue
        fl=v.get('floor');threshold=None
        if fl=='BE':threshold=old.ceilcent(e+.021)
        elif fl=='P5':threshold=old.ceilcent(e*1.05+.021)
        elif fl=='TRAIL10':threshold=high*.9
        if threshold is not None and bid<=threshold:reason='TRAIL' if fl=='TRAIL10' else 'PROFIT_FLOOR';out=quote;break
        if kind=='ATR2' and data:
            while idx<len(barrecords) and barrecords[idx]['at']<at:
                b=barrecords[idx];idx+=1
                if b['closed']<=active or b['atr'] is None:continue
                if trail is not None and ((typ=='CALL' and b['close']<=trail) or (typ=='PUT' and b['close']>=trail)):
                    sigtime=b['at'];indicator_level=trail;indicator_close=b['close'];reason='ATR';out=quote;break
                if typ=='CALL':
                    reference=max(reference if reference is not None else b['close'],b['close']); candidate=reference-2*b['atr'];trail=max(trail if trail is not None else candidate,candidate)
                else:
                    reference=min(reference if reference is not None else b['close'],b['close']);candidate=reference+2*b['atr'];trail=min(trail if trail is not None else candidate,candidate)
            if out is not None: break
        elif signals:
            i=bisect.bisect_right(signals,(active,active))
            while i<len(signals) and signals[i][0]<at:
                st,first=signals[i]
                if first>active:sigtime=st;reason=kind;out=quote;break
                i+=1
            if out is not None:break
    if out is None:
        out={'timestamp':t['exit_at'],'bid':t['exit_price']};reason='RECORDED_EXIT_FALLBACK'
    net=round((out['bid']-e)*100-2.1,2); later=[x['bid'] for x in q if dt(x['timestamp'])>dt(out['timestamp'])]
    return {'variant':v['name'],'paper_id':t['paper_id'],'split':'later_check' if t['entry_at'][:10]>='2026-11-04' else 'development','paper_bot':bot,'entry_at':t['entry_at'],'contract':t['contract'],'strike':t['strike'],'expiration':t['expiration'],'option_type':typ,'entry_price':e,'baseline_exit':t['exit_price'],'baseline_net':t['reported_net_pnl'],'quote_count':len(q),'entry_rr':round((e*v['tp']*100-2.1)/(e*v['stop']*100+2.1),4),'entry_rr_eligible':int((e*v['tp']*100-2.1)>=(e*v['stop']*100+2.1)),'activation_at':active.isoformat() if active else '', 'activation_bid':actbid if active else '', 'indicator':kind or '', 'indicator_bars_available':int(available) if kind else '', 'indicator_ready_at':ready.isoformat() if ready else '', 'indicator_ready_at_activation':int(ready<=active) if ready and active else '', 'signal_at':sigtime.isoformat() if sigtime else '', 'atr_underlying_trigger':round(indicator_level,5) if indicator_level is not None else '', 'atr_underlying_close':indicator_close if indicator_close is not None else '', 'exit_at':out['timestamp'],'exit_bid':out['bid'],'exit_reason':reason,'threshold':round(threshold,5) if threshold is not None and reason in ('STOP','PROFIT_FLOOR','TRAIL') else '', 'threshold_shortfall':round(max(0,(threshold-out['bid'])*100),2) if threshold is not None and reason in ('STOP','PROFIT_FLOOR','TRAIL') else '', 'net_pnl':net,'net_pnl_stress_cost':round(net-2,2),'delta_vs_baseline':round(net-t['reported_net_pnl'],2),'later_recorded_target_seen':int(any(x>=t['target'] for x in later)), 'later_tp20_seen':int(any(x>=e*1.2 for x in later)), 'later_recorded_entry_seen':int(any(x>=e for x in later))}

def aggregate(rows,t_by_id):
    ps=[r['net_pnl'] for r in rows];ws=[x for x in ps if x>0];ls=[x for x in ps if x<0]; events=[]
    for r in rows:
        t=t_by_id[r['paper_id']]; en=dt(t['entry_at']);end=dt(r['exit_at']);e=t['entry_price'];ident=t['paper_id']
        events.append((en,0,ident,-1.05))
        events.extend((dt(q['timestamp']),1,ident,(q['bid']-e)*100-2.1) for q in t['quotes'] if en<=dt(q['timestamp'])<end)
        events.append((end,2,ident,r['net_pnl']))
    events.sort();marks={};peak=draw=0
    for _,_,k,val in events:marks[k]=val;total=sum(marks.values());peak=max(peak,total);draw=max(draw,peak-total)
    return {'variant':rows[0]['variant'],'split':rows[0]['split'],'trades':len(ps),'wins':len(ws),'losses':len(ls),'flats':len(ps)-len(ws)-len(ls),'win_rate':round(len(ws)/len(ps),4),'net':round(sum(ps),2),'mean':round(statistics.mean(ps),2),'avg_win':round(statistics.mean(ws),2) if ws else '', 'avg_loss':round(statistics.mean(ls),2) if ls else '', 'profit_factor':round(sum(ws)/-sum(ls),3) if ls else '', 'realized_rr':round(statistics.mean(ws)/-statistics.mean(ls),3) if ws and ls else '', 'sampled_mtm_drawdown':round(draw,2),'delta_vs_baseline':round(sum(x['delta_vs_baseline'] for x in rows),2),'net_stress_cost':round(sum(x['net_pnl_stress_cost'] for x in rows),2),'min_planned_rr':min(x['entry_rr'] for x in rows),'below_1to1':sum(not x['entry_rr_eligible'] for x in rows),'armed':sum(bool(x['activation_at']) for x in rows),'indicator_bars_unavailable':sum(x['indicator_bars_available']==0 for x in rows),'indicator_ready_at_activation':sum(x['indicator_ready_at_activation']==1 for x in rows),'base_loser_to_nonnegative':sum(x['baseline_net']<0<=x['net_pnl'] for x in rows),'base_winner_cut':sum(x['baseline_net']>0 and x['net_pnl']<x['baseline_net'] for x in rows),'stopped_before_later_base_target':sum(x['exit_reason']=='STOP' and x['later_recorded_target_seen'] for x in rows),'stopped_before_later_tp20':sum(x['exit_reason']=='STOP' and x['later_tp20_seen'] for x in rows)}

VOL_IDS=set()
def main():
    global VOL_IDS
    all_t=old.old.load_quotes(); inv=list(csv.DictReader((HERE/'data_inventory'/'inventory.csv').open())); counts={r['paper_id']:int(r['held_valid']) for r in inv if r['experiment'] in ('session_expiry_20261025','volatility_labels_20261031') and r['entry_at'][:10]=='2026-11-04'}
    VOL_IDS={r['paper_id'] for r in inv if r['experiment']=='volatility_labels_20261031'}
    prior=list(csv.DictReader((PRIOR.parent/'coverage.csv').open())); expected={r['paper_id']:int(r['fresh_quotes']) for r in prior};expected.update(counts)
    trades=[t for t in all_t if t['paper_id'] in expected]; assert len(trades)==11 and len({x['paper_id'] for x in trades})==11,(len(trades),expected)
    for t in trades:assert len(t['quotes'])==expected[t['paper_id']],(t['paper_id'],len(t['quotes']),expected[t['paper_id']])
    bars=old.old.load_bars();data={}
    for day,bb in bars.items():
        try:
            values=indicators(bb)
            for bot in ('first_bot','volatility'): data[(day,bot)]=values
        except ValueError:pass
    for bot in ('first_bot','volatility'):
        nov=HERE/f'spy_20261104_{bot}_yahoo_1m.csv'
        if nov.exists():
            vv=[]
            for b in csv.DictReader(nov.open()):vv.append({'ts':dt(b['timestamp']),'available_at':dt(b['available_at']),'open':float(b['open']),'high':float(b['high']),'low':float(b['low']),'close':float(b['close']),'volume':float(b['volume'])})
            try:data[('2026-11-04',bot)]=indicators(vv)
            except ValueError:pass
    rows=[];summ=[];byid={t['paper_id']:t for t in trades}
    for v in variants():
        rr=[simulate(t,v,data) for t in trades]
        if v['name']=='TP30_STOP25':
            for r in rr:assert r['exit_reason']!='RECORDED_EXIT_FALLBACK' and abs(r['net_pnl']-r['baseline_net'])<.001,r
        rows.extend(rr)
        for split in ('development','later_check'):
            summ.append(aggregate([r for r in rr if r['split']==split],byid))
    write('trade_results.csv',rows);write('summary.csv',summ)
    (HERE/'summary.json').write_text(json.dumps({'variants':variants(),'development_trades':9,'later_check_trades':2,'indicator_days':[list(x) for x in sorted(data)],'summaries':summ},indent=2)+'\n')
    print(json.dumps({'trades':len(trades),'indicator_days':[list(x) for x in sorted(data)],'variants':len(variants()),'summary':summ},indent=2))
if __name__=='__main__':main()
