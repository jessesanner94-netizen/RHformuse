# Profit protection and smaller targets — research update, November 5, 2026

## Finding

The replay reveals a real trade-off, not yet a statistically reliable rule. The new November 4 volatility-paper SPY 773 call entered at $1.52. A 10% initial stop would have sold at the first observed $1.32 bid, for −$22.10 after modeled costs. **Later, while the original position was still open, its bid reached $1.89**; a 20% hard target with a 15% stop would have exited at that observed bid for +$34.90. The actual paper position instead continued to its original 25% stop, exiting at $1.14 for −$40.10. This demonstrates in this one case that both holding without profit protection and an overly tight initial stop had an observable cost. The other November 4 paper trade lost under both fixed alternatives.

The +20% target / −15% stop is a reasonable *candidate for further testing*, not an established improvement: its two newer results total +$14.80, but its nine previously inspected results total −$67.90; the two new trades overlap in time and are in separate paper accounts on the same date. They are not independent market sessions or a reliable out-of-sample evaluation. The prior nine trades were already used to examine more than 150 related variants. This study uses a prespecified focused extension, but one later day cannot certify statistical significance, generalizability, or broker fills.

## Data and provenance

The baseline is the configured +30% target / −25% software stop, one contract, with $0.05 modeled fee plus $1.00 modeled slippage per side: $2.10 per round trip. This is a simulation assumption, not verified broker fees or a statement that the fill can be guaranteed. Entries and exact contract IDs come from recorded paper `EVENTS.jsonl`; exits come from contemporaneously sampled same-contract bid quotes in `MONITOR.jsonl`. All 11 baseline exits and recorded P&L independently reproduce the sampled stop/target crossing without fallback. The nine older quotes and entries are the prior study's fixed cohort; the two newer trades come from separate paper bots. The Nov 4 first-bot position had 129 fresh quote observations, and the volatility-bot position had 362. Their maximum gaps were 12.71 and 12.51 seconds. There are no qualifying later quotes in either same-contract monitor after its recorded exit. The additional October 22 shared experiment trade exists, but remains outside the predeclared two-ledger cohort; its copied arms are not treated as independent trades. See `data_inventory/README.md` and `inventory.csv`.

One-minute development candles are the previously downloaded Alpaca SIP regular-session bars with assumed availability one second after close. November 4 uses each bot's archived Yahoo `CONSOLIDATED_UNVERIFIED` session tape. We use the later of actual `available_at`, `received_at`, candle close + one second, and all prior candle availability. This is a different source and availability model from the first nine; it cannot be treated as an identical-feed prospective test. Non-minute-aligned data were excluded, leaving 390 consecutive minute bars in each recorder. See `extract_nov04_bars.py` and the two extracted CSVs. Exits use first available sampled option bid after a completed indicator signal. No extra explicit routing delay beyond the modeled $1 per-side slippage is included; bid sampling is not a trade tape, and fills, slippage, spreads and gaps can differ in practice.

## Rules and results

`PROTOCOL.md` freezes the 17 exploratory rules before scoring the November 4 trades. All strategies retain actual recorded entry, direction, contract and size. Hypothetical monitoring ends at the original recorded exit if no earlier rule has fired. Because the path stops there, we cannot measure later rebound, target or stop behavior after the original exit; no changed re-entry, cash reuse or daily green-lock outcomes are simulated. Per-variant and per-position outputs include gains, losses, average win/loss, expected P&L per trade, profit factor, realized average win/loss, cost-adjusted planned reward:risk, later observed target/entry, and sampled marked drawdown. See `summary.csv`, `summary.json`, and `trade_results.csv`. The drawdown column is a synthetic sum of independent paper-account episodes with marked bids, **not** an actual shared account drawdown.

| Rule | Nine prior trades net | Two Nov 4 trades net | Nov 4 delta vs baseline | Min planned R:R |
|---|---:|---:|---:|---:|
| TP30_STOP25 | $-106.90 | $-72.20 | $+0.00 | 1.049 |
| TP20_STOP15 | $-67.90 | $+14.80 | $+87.00 | 1.078 |
| TP20_STOP20 | $-110.90 | $+6.80 | $+79.00 | 0.831 |
| TP30_STOP15 | $-25.90 | $-45.20 | $+27.00 | 1.672 |
| TP20_STOP10 | $-24.90 | $-36.20 | $+36.00 | 1.533 |
| TP30_STOP10 | $+17.10 | $-36.20 | $+36.00 | 2.378 |
| ACT20_BE_TP30_STOP15 | $-25.90 | $-19.20 | $+53.00 | 1.672 |
| ACT20_P5_TP30_STOP15 | $-25.90 | $-12.20 | $+60.00 | 1.672 |
| ACT20_TRAIL10_TP30_STOP15 | $-25.90 | $-5.20 | $+67.00 | 1.672 |
| ACT20_SUPER_NONE_TP30_STOP15 | $-25.90 | $-45.20 | $+27.00 | 1.672 |
| ACT20_CLOUD2_NONE_TP30_STOP15 | $-25.90 | $-45.20 | $+27.00 | 1.672 |
| ACT20_MACD_NONE_TP30_STOP15 | $-25.90 | $-20.20 | $+52.00 | 1.672 |
| ACT20_ATR2_NONE_TP30_STOP15 | $-25.90 | $-35.20 | $+37.00 | 1.672 |
| ACT20_SUPER_BE_TP30_STOP15 | $-25.90 | $-19.20 | $+53.00 | 1.672 |
| ACT20_CLOUD2_BE_TP30_STOP15 | $-25.90 | $-19.20 | $+53.00 | 1.672 |
| ACT20_MACD_BE_TP30_STOP15 | $-25.90 | $-19.20 | $+53.00 | 1.672 |
| ACT20_ATR2_BE_TP30_STOP15 | $-25.90 | $-19.20 | $+53.00 | 1.672 |

Only the +20% target / −20% stop fails the configured 1:1 *planned* reward:risk gate, for all 11 prices. A +20% target and −15% stop passes the planning gate on all 11; the worst planned ratio was 1.078 after modeled costs. For an illustrative $1.52 entry, trigger-level profit is $30.40 gross, or $28.30 after $2.10 modeled costs; a 15% trigger-level loss is $22.80 gross, or $24.90 after costs, a planned 1.14:1. Those values imply roughly a 46.8% break-even win rate *only if* wins and losses actually fill at those exact target/stop prices and costs are as assumed. Gap-through and target overshoot change that calculation. A 20% target with a 20% stop on that entry has planned net reward $28.30 against risk $32.50, or 0.87:1.

Among the nine older cases, the tighter 15% initial stop caused one previously inspected put to exit before it later reached +20%, while the smaller +20% target cut all three baseline winners short. On November 4, the 10% stop cut off one call before it reached +20%. Compare all 11 row-level exit prices and timestamps before drawing conclusions. With double the modeled slippage component, represented by $4.10 round-trip costs and unchanged sampled prices, the +20/−15 result becomes −$85.90 on the nine older cases and +$10.80 across the two Nov 4 cases. This sensitivity does not model the impact of latency on which quote fills.

### Indicator comparison after +20%

For the Nov 4 $1.52 call, with a 15% initial stop and +30% target, the initial stop had not fired before activation. A net-breakeven trigger exited at $1.55 for +$0.90; a +5%-net trigger exited at $1.62 for +$7.90; a 10%-giveback trail exited at $1.69 for +$14.90. The one-minute Supertrend-only and cloud-only rules did not exit before the tighter 15% stop, which filled at $1.29 for −$25.10. The cloud needed 52 current-session bars and was not ready at activation. The one-minute 12/26/9 MACD histogram crossed by 1 bp for two bars and exited at $1.54 for −$0.10. A one-minute 14-period ATR, used as a 2× ATR underlying-price trail rather than a directional signal, exited at $1.39 for −$15.10. Adding a breakeven trigger protected earlier in this particular recorded path, before those indicator signals.

These are retrospective sampled-quote estimates for one trade, not proof that a trigger will protect a future trade: gaps can skip through a floor. Indicator-only exits offer no non-loss floor. The rules do not stack together; each tested indicator-plus-breakeven variant is a separate matched exit alternative. All hard targets/stops and the first observed activation quote have precedence in the simulator. The +20% target acts immediately upon reaching the activation threshold, so it cannot simultaneously wait for a post-activation indicator while retaining that hard target.

### Interpreting ATR, Ichimoku and order book

ATR measures volatility and does not indicate direction by itself; our hypothesis makes it directional by combining it with a protective underlying-price trail. [Fidelity's ATR guide](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr) describes this distinction. MACD reflects price momentum and can whipsaw; its 12/26/9 construction is detailed in [Fidelity's MACD guide](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/macd). Our Ichimoku uses only leading spans computed at the current bar, never future-shifted values; the 52-bar warmup limits usefulness for early entries.

The project has sampled **displayed resting underlying depth**, not verified executions, aggressor sides or a complete tape. The existing book-pressure experiment had 1,328 recorded reviews over six paper positions; 678 had a valid fresh post-book exact-contract option quote, and 93 were net profitable at the sampled bid. All recorded review actions were HOLD; no confirmed adverse or favorable book exit fired. Some 610 reviews failed the confirmation-duration check and 19 had gaps. The first two older positions had no recorded reviews and should not be labeled as no-signal. See `depth/DIAGNOSTIC.md` for exact definitions and counts. Research on event-level [order-flow imbalance and price changes](https://arxiv.org/abs/1011.6402) supports studying microstructure, but does not show this sampled displayed-book data predicts our future option exits. Quote cancellations, execution prints, missing venues, delay and order routing matter. The diagnostic does not establish a profitable early warning.

## Next step and constraints

Keep live and paper behavior unchanged. The strongest next research task is to collect or obtain a materially larger chronological set of exact-contract bid/ask paths **through a common post-exit horizon**, including timestamps, sizes, bar availability, live fill and actual fee reconciliation, and enough independent days in both SPY and QQQ. Compare +30/−25, +20/−15, +30/−15 and one +20%-armed protected variant without reoptimizing on the evaluation period; preserve the same entry schedule and then separately simulate realistic cash, daily lock and re-entry effects. Evaluate stop-gaps, latency, mark-to-market drawdown, profit factor, expectancy, costs and winner truncation. One later date and multiple searches cannot justify a statistically significant finding; see [Bailey et al. on backtest overfitting](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf).

No production file, configuration, ledger, order, or service was changed. Reproduce the as-of data extraction with `python3 research/profit_protection_20261105/extract_nov04_bars.py`, the replay with `python3 research/profit_protection_20261105/replay.py`, and the tests with `python3 research/profit_protection_20261105/test_replay.py`; regenerate this report with `build_report.py`. Ongoing source archives can change. `INPUT_MANIFEST.json` hashes the extracted data and analysis inputs used for this run.
