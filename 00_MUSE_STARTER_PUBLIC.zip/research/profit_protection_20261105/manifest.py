#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent; ROOT=P.parents[1]
paths=[P/'PROTOCOL.md',P/'replay.py',P/'test_replay.py',P/'extract_nov04_bars.py',P/'spy_20261104_first_bot_yahoo_1m.csv',P/'spy_20261104_volatility_yahoo_1m.csv',P/'data_inventory'/'inventory.csv',P/'depth'/'coverage.json',ROOT/'research/profit_protection_20261103/exit_research/replay.py',ROOT/'research/profit_protection_20261103/run_backtest.py',ROOT/'research/profit_protection_20261103/data/spy_rth_1m.csv.gz',ROOT/'research/profit_protection_20261103/exit_research/coverage.csv']
for name in ('rsi_priority_20261022','session_expiry_20261025','volatility_labels_20261031'):
 b=ROOT/'research/options_lab/experiments'/name/'forward'
 paths += [b/'MONITOR.jsonl',b/'accounts/paper/state/options/python_jev_green_lock_20261009/paper/EVENTS.jsonl']
items=[]
for p in paths:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
 items.append({'path':str(p.relative_to(ROOT)),'sha256':h.hexdigest(),'bytes':p.stat().st_size})
(P/'INPUT_MANIFEST.json').write_text(json.dumps({'files':items},indent=2)+'\n')
