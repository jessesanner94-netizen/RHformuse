#!/usr/bin/env python3
"""Extract completed Yahoo 1m bars and their actual tape availability per recorder."""
import csv,json,sqlite3
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parent
R=P.parents[1]
for label,exp in [('first_bot','session_expiry_20261025'),('volatility','volatility_labels_20261031')]:
    db=R/'research'/'options_lab'/'experiments'/exp/'forward'/'SESSION_TAPE.sqlite3'
    con=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
    rows=con.execute("select record from events where session=? and source='yahoo' and symbol='SPY' and kind='bar'",('2026-11-04',)).fetchall()
    bars={}
    for (raw,) in rows:
        x=json.loads(raw);p=x['payload'];start=datetime.fromisoformat(p['start_at']);end=datetime.fromisoformat(p['end_at']);available=datetime.fromisoformat(x['available_at']);received=datetime.fromisoformat(x['received_at'])
        if start.second or start.microsecond or (end-start).total_seconds()!=60:continue
        if start.hour<14 or (start.hour==14 and start.minute<30) or start.hour>=21:continue
        available=max(available,received,end)
        r={'timestamp':start.isoformat(),'available_at':available.isoformat(),'open':p['open'],'high':p['high'],'low':p['low'],'close':p['close'],'volume':p['volume']}
        old=bars.get(start)
        if old is None or r['available_at']<old['available_at']:bars[start]=r
    vals=[bars[k] for k in sorted(bars)]
    assert len(vals)==390,(label,len(vals))
    with (P/f'spy_20261104_{label}_yahoo_1m.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(vals[0]));w.writeheader();w.writerows(vals)
    print(label,len(vals),vals[0]['available_at'],vals[-1]['available_at'])
