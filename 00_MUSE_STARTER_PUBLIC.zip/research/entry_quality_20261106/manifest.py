#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
files=[P/'build_report.py',P/'underlying_diagnostic/PROTOCOL.md',P/'underlying_diagnostic/diagnostic.py',P/'underlying_diagnostic/test_diagnostic.py',P/'option_timing/PROTOCOL.md',P/'option_timing/timing.py',P/'option_timing/test_timing.py',P/'option_timing/latency_sensitivity.py',P/'option_timing/sampled_quotes.csv',P/'live_audit/audit.py',P/'live_audit/summary.json',ROOT/'research/regime_backtest/results_2022_2025/DATA_MANIFEST.json',ROOT/'research/regime_backtest/evaluate.py']
for exp in ('rsi_priority_20261022','session_expiry_20261025','volatility_labels_20261031'):
 b=ROOT/'research/options_lab/experiments'/exp/'forward';files.append(b/'MONITOR.jsonl')
 if exp!='rsi_priority_20261022':files.append(b/'accounts/paper/state/options/python_jev_green_lock_20261009/paper/PORTFOLIO.json')
items=[]
for f in files:
 h=hashlib.sha256()
 with f.open('rb') as source:
  for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
 items.append({'path':str(f.relative_to(ROOT)),'sha256':h.hexdigest(),'bytes':f.stat().st_size})
(P/'INPUT_MANIFEST.json').write_text(json.dumps({'files':items,'archived_bar_file_hashes':'research/regime_backtest/results_2022_2025/DATA_MANIFEST.json','live_source_hashes':'research/entry_quality_20261106/live_audit/summary.json'},indent=2)+'\n')
