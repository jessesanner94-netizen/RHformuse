#!/usr/bin/env python3
"""Render evidence from frozen entry-quality diagnostics."""
import csv,json
from pathlib import Path
P=Path(__file__).resolve().parent
s=list(csv.DictReader((P/'underlying_diagnostic'/'summary.csv').open()))
table=['| Decision-time filter | Kept / baseline | Mean subsequent underlying move after 2 bp | Uplift vs baseline | 98.75% date-block interval for uplift |','|---|---:|---:|---:|---:|']
for x in s:
 if x['period']=='2024_2025' and x['symbol']=='ALL':
  names={'efficiency':'Five-minute efficiency ≥ 0.60','vwap':'Price aligned with session VWAP','not_extended':'Five-minute move ≤ 2 × minute ATR','efficiency_vwap':'Efficiency and VWAP alignment'}
  table.append(f"| {names[x['filter']]} | {x['pass_count']} / {x['baseline_count']} | {float(x['pass_mean_net2_bps']):+.2f} bp | {float(x['pass_uplift_vs_all_net2_bps']):+.2f} bp | [{float(x['bootstrap_uplift_low_98_75']):+.2f}, {float(x['bootstrap_uplift_high_98_75']):+.2f}] bp |")
text='''# Entry-quality research — November 6, 2026

## What we learned

We have not found an entry rule supported strongly enough to change the bot. The most concrete research direction is to investigate a **pullback followed by reconfirmation**, but the available option paths end too early to establish whether waiting helps across all candidates. In one saved paper trade the idea caught a cheaper entry and an observed target; a delay of one quote snapshot made the later outcome unknown. It also would have skipped two other original winners. This is a reason to collect a fair test, not a validated edge.

## What the live bot actually did

As of the saved November 6 live state, the current strategy epoch has **17 closed positions, 8 wins and 9 losses**, with +$33.00 gross from the recorded fills and **−$2.70 after $35.70 modeled costs**. Actual broker fees were not verified. All 17 entries match an opportunity decision packet and all 17 exits reconcile to broker-fill events. See `live_audit/REPORT.md` and `closed_entries.csv`. These are outcomes of trades actually selected, not an experiment on better entries, and the sample is small. The matching packet includes earlier candidate quotes, technicals and risk context; its quote timestamp can precede the fill and is not evidence about the separately refreshed final quote. Recorded broker state is not a fresh current account reconciliation.

An entry gate that rejects a trade may change the day's later candidates, available cash, risk budget, green lock, and timing. We cannot infer the eventual account P&L by subtracting the losing trades retrospectively. Rejected and unselected candidates generally lack a complete subsequent exact-contract bid/ask path, so the available archives cannot establish whether they would have been profitable.

## Broad, time-respecting underlying diagnostic

We investigated four fixed entry-quality ideas on archived Alpaca SIP one-minute SPY/QQQ bars across all 1,003 NYSE sessions in 2022–2025. The base proxy requires both the last 5-minute and 15-minute underlying moves to point in the same direction at 09:50:15 ET. It is **not** the actual bot: it does not reproduce its technical decisions, selected option contract, JEV ranking, events, Greeks, cash or fills. Each proxy entry uses the 09:51 underlying open; the outcome is the signed underlying move through 10:21, less a hypothetical 2 bp underlying round-trip cost. It is not option P&L. All features precede the decision, finalized historical bars are assumed available one second after close, and missing inputs are never treated as passes. See `underlying_diagnostic/PROTOCOL.md` and `observations.csv`.

The table is the combined 2024–2025 chronological evaluation block. The unfiltered proxy had 726 qualifying symbol-sessions and averaged **−1.34 bp** after the 2 bp assumption. Each filter is compared with those same candidates; the interval resamples whole dates, preserving SPY/QQQ dependence, and uses 98.75% intervals for four simultaneous comparisons. It does not correct for all prior project research. Both 2024 and 2025 history have been used in earlier project studies, so this is not a pristine holdout.

TABLE

Every paired interval includes zero. With a 5 bp underlying cost assumption, even the best-looking pooled filter averaged a negative signed underlying move. The five-minute efficiency filter improved relative to baseline in 2025 but worsened it in 2024; the low-extension filter showed the opposite pattern. The VWAP filter kept about 97% of candidates, so it barely distinguished among this already-aligned proxy sample. These diagnostics do **not** establish that the real bot loses money or that these indicators have no value for options entries; the entry logic and instrument are different.

## Exact-option timing diagnostic

The research also used 12 unique closed positions from two separate paper ledgers through November 6. It independently matched all 12 original exits to first observed stop/target crossings, then compared the original entries with (1) waiting two minutes for the first observed ask, and (2) waiting up to ten minutes for the option ask to fall at least 5% below the original entry and then rebound at least 2% from its observed low. These thresholds were stated before scoring this diagnostic, but the historical trades and many related ideas had already been viewed; there is no untouched test. Results are exploratory, not actual or live fills.

A hypothetical entry uses the sampled ask and the subsequent same-contract sampled bids, with the existing 25% stop / 30% target reset to the new ask and $2.10 modeled round-trip costs. These alternative entries did not re-run all live cash, risk, Greek, news, liquidity, quote and JEV gates; they are conditional. The samples end when the actual paper position was closed. If an alternative position is still open at that point, its outcome is **unknown**. Gaps over 30 seconds also make an outcome unavailable. Separate accounts were kept identifiable; no single-account equity curve was inferred.

| Entry approach | Available evidence from 12 original positions |
|---|---|
| Wait two minutes | 6 observed alternative stop/target outcomes; 5 censored after entry; 1 censored after a quote gap. |
| Pullback and reclaim | 3 observed alternative stop/target outcomes; 5 censored after entry; 1 censored after a quote gap; 3 observed no-entry windows. |

The completed cases are selected by which outcomes happened before recording stopped. Their summed P&L cannot be compared with all original trades. In the 3 observed no-entry windows, the original trades included **two winners** (+$39.90 and +$47.90) and one loser (−$41.10), all after modeled costs. This illustrates the opportunity cost of waiting but does not establish how later alternative candidates would have performed.

For the November 4 SPY 773 call, the original paper entry was $1.52 and its actual recorded modeled P&L was −$40.10. The option ask later reached $1.43 and rebounded to $1.46. Filling hypothetically at that signal ask produces an observed target exit at $1.91, for **+$42.90 modeled net**. But the next saved ask, about 10 seconds later, was $1.47; at that entry the alternative target was not observed before the original monitor stopped, so the outcome is **unknown**, not a win or a loss. This post-result one-observation delay sensitivity left only 1 of 9 triggered pullback entries with an observed completed outcome; 3 were observed no-entry windows and the other 8 triggered entries were censored. The difference demonstrates how sensitive the apparent result is to execution and coverage.

See `option_timing/PROTOCOL.md`, `trade_results.csv`, `latency_sensitivity.csv`, `baseline_coverage.csv` and `sampled_quotes.csv` for the exact paths, exits, gaps and exclusions. Same-quote trigger fills are optimistic about routing latency; the $1-per-side modeled slippage is a project assumption, not a verified broker quote. No exact option return is inferred from underlying price movement.

## Recommended research direction

Keep the current live and paper rules unchanged. The pullback-and-reconfirmation idea merits a properly paired **future observation study**, not activation. Before choosing numbers, record every baseline-qualified candidate and the precise time its signal and option quote were available. Observe the same contract's fresh bid/ask and sizes after the original decision and through a common horizon even if the bot exits or rejects the entry; retain gaps and missed signals. Compare the unchanged route with a small, fixed set of independently specified waits or reconfirmations on later trading dates, and recheck the full option, broker, risk and event gates at each hypothetical action. Explicitly measure missed winners, skipped losses, rejected and later-qualified candidates, latency, costs, sample coverage, and account effects.

The published intraday momentum work on SPY documents a relationship between the first and last half-hour returns, a different horizon and entry rule from ours; it motivates a hypothesis rather than validating our option strategy. [Gao et al., Intraday Momentum](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2552752). Searching increasingly many thresholds on the same record can select a chance result; a later independent evaluation is essential. [Bailey et al., backtest overfitting](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf).

All work was offline research except read-only source lookup; no live or paper bot, configuration, strategy, account ledger, service or order was changed. Reproduction and input hashes are documented in `INPUT_MANIFEST.json`; the source logs are live archives and may change.
'''
(P/'REPORT.md').write_text(text.replace('TABLE','\n'.join(table)))
