# Candidate ID / name

- Status / last reviewed:
- Discovery URL:
- Original paper URL, authors, version/date:
- Implementation URL, commit, license:
- Hypothesis and economic rationale:
- Source instruments, dates, leverage and costs:
- Reported results (source claims; distinguish local results):
- Paper/code discrepancies and evidence limitations:

## Frozen specification (complete before running)

- Universe, timezone, trading calendar and bar timestamps:
- Warmup and signal formula using only available data:
- Entry trigger, execution delay and fill rules:
- Invalidation, stop, target and time exit:
- Sizing, exposure and daily limits:
- Options selection / quote freshness / missing-data policy:
- Departures from original study and active policy:
- Data provider, coverage, adjustments, version/hash and license:
- Development / validation / untouched holdout dates:
- Parameter trials and comparison baselines:
- Predeclared acceptance thresholds and uncertainty method:
- User authorization for run / costs:

## Evidence (leave unavailable until measured)

- Run ID, code/config/data versions and reproducible command:
- Net expectancy, profit factor, win rate, average win/loss:
- Daily Sharpe, mark-to-market drawdown, worst day, sample size:
- Cost sensitivity, regimes, missing-data coverage:
- All variants including failures:
- Forward results and incremental AI/data costs:
- Decision, unresolved limitations and approval record:
