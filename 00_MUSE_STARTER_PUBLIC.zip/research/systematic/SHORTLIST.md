# Initial shortlist — 2026-09-10

These are research candidates, not claims of successful options strategies.

| ID | Candidate | Priority/status | Implementation fit |
|---|---|---|---|
| SYS-001 | SPY volatility-adjusted intraday momentum | First; DISCOVERED | Continuation with noise boundaries and VWAP/band exits. Current fixed option exits are a separate adaptation. |
| SYS-002 | QQQ five-minute opening-range breakout | Second; DEFERRED | Source's early entry conflicts with our 20-minute entry delay and ten-minute scan. No timing changes approved. |
| SYS-003 | First-half-hour / last-half-hour ETF momentum | Third; DEFERRED | QuantConnect example reports negative full-period Sharpe; source-style close exit conflicts with our pre-close exit. |

## SYS-001

Original: Zarattini, Aziz, Barbon,
[Beat the Market](https://concretumgroup.com/wp-content/uploads/2026/02/Beat-the-Market.pdf).
Version previously reviewed: September 22, 2025; original May 10, 2024.
Prior 14 sessions determine time-of-day movement boundaries, adjusted for the
opening gap. Crossings identify direction; current-band/VWAP exits limit exposure.
Freeze exact sampling, sizing and execution rules from the paper before coding.
Study concerns ETF exposure, not long options. QQQ extension is a separate test.
No local replication or historical options quote coverage established.

## SYS-002

Original: Zarattini and Aziz,
[Can Day Trading Really Be Profitable?](https://concretumgroup.com/wp-content/uploads/2026/02/Can-Day-Trading-Really-Be-Profitable.pdf).
Five-minute opening-range approach; ETF/leveraged-ETF research does not establish
option returns. Resolve source leverage, stops and timing before specification.
Keep deferred while SYS-001 is evaluated; do not loosen the active entry window.

## SYS-003

Implementation inspected 2026-09-10:
[QuantConnect Intraday ETF Momentum](https://www.quantconnect.com/research/15348/intraday-etf-momentum/p1).
It attributes the method to Gao, Han, Li and Zhou; original-paper verification
remains pending. The implementation computes morning return relative to yesterday's
close, so this is not simply open-to-10:00 return. Its universe selects SPY/IWM/IYR
for better backtest performance, which introduces selection concerns.
Reported full-period Sharpe is -0.628 for 2015-01-01 through 2020-08-16.
The strategy holds the final half-hour and exits at close. The example is useful
for inspection, not affirmative evidence for our proposed SPY/QQQ options strategy.

## Next concrete deliverable

Complete SYS-001's frozen specification and inventory usable historical underlying
and option quote data. Present the exact experiment, data cost (if any), dates and
acceptance thresholds before requesting permission to run it. No paid data or
backtest/model execution has been initiated by this research setup.
