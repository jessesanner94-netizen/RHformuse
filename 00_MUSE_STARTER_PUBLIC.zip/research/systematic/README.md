# Systematic strategy research workflow

Established 2026-09-10 at the user's request. This is a research process, not an
activated entry strategy. No scheduled research, paid service, model change, or
trading execution is authorized by this document.

## Source order

1. Discover ideas and implementation references in
   [Awesome Systematic Trading](https://github.com/paperswithbacktest/awesome-systematic-trading).
2. Look for inspectable implementations in the
   [QuantConnect Strategy Library](https://www.quantconnect.com/docs/v2/writing-algorithms/strategy-library).
3. Verify the original paper: actual instrument, signal timestamps, entry/exit
   rules, leverage, sample, costs, and reported limitations. Record discrepancies
   between paper and implementation rather than silently choosing one.

Use free public material first. A catalog ranking or published backtest is a lead,
not validation. Awesome's leaderboard selects strong replications, uses different
active windows, and reports gross-of-cost Sharpe ratios.

## Bounded process

Keep at most three active candidates in SHORTLIST.md. Start with SYS-001.
For each candidate, copy CANDIDATE_TEMPLATE.md and complete its source and rules
sections before implementation. Preserve rejected candidates and every tested
variant so selection does not hide failed experiments.

Stages: DISCOVERED -> SOURCE_VERIFIED -> SPEC_FROZEN -> REPRODUCED ->
OPTIONS_VALIDATED -> FORWARD_VALIDATED -> PROPOSED_FOR_APPROVAL.
Use DEFERRED or REJECTED with a reason when appropriate. Missing evidence never
advances a stage. No candidate is currently reproduced or validated locally.

1. Freeze explicit entry, invalidation, exit, sizing and timing rules; record source
   version/commit, dataset provenance, and every intended departure from the paper.
2. Reproduce the underlying strategy first, distinguishing source-replication
   results from results under our constraints. Pin code and data versions.
3. Before looking at outcomes, freeze chronological development/validation/final
   holdout boundaries and parameter trials. Use common dates and walk-forward
   evaluation; do not repeatedly tune against the final holdout.
4. Test the options adaptation using historical contract identities and timestamped
   bid/ask quotes, liquidity and Greeks. Signals use completed bars only; fills use
   subsequent available quotes. Never infer executable fills from option prints or
   substitute ETF returns for option returns. Missing required data means the
   options result is unavailable, not zero-cost or automatically executable.
5. Apply the configured account budget, one-contract sizing, daily risk allowance,
   contract eligibility, calendar and polling cadence. Model ask buys/bid sells,
   fees, adverse slippage, gaps and missing quotes. Report sensitivity to worse costs.
   Keep source-native exits separate from current 25% stop/30% target/time exits.
6. Report net expectancy, profit factor, win rate, average win/loss, trade count,
   exposure, turnover, worst day and mark-to-market drawdown. Calculate annualized
   Sharpe from daily account returns including flat days; document risk-free rate
   and annualization. Show uncertainty and results by period, symbol and regime.
   Flag small samples, correlated observations and multiple-testing selection.
7. Only after an explicit strategy is viable, propose a matched forward comparison
   of rules alone versus model vetoes. Record both avoided losers and missed winners,
   identical opportunity packets, independent cash ledgers and incremental costs.
   Existing DAY control shares discovery and is not an independent strategy backtest.

## Promotion

Require reproducible results, positive held-out expectancy after costs, acceptable
drawdown under a user-agreed threshold, cost sensitivity and forward evidence.
Define numeric acceptance thresholds before running the experiment; do not invent
passing thresholds after seeing results. A high win rate or one missed winner is
insufficient. Present evidence and exact proposed policy changes for approval before
connecting any research candidate to the trading runner.

Backtest execution remains pending the user's permission under their standing
instruction to consult before running experiments. This workflow adds no runner,
dependency, subscription, broker connection or scheduled task.
