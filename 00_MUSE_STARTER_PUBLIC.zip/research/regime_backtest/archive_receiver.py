"""Receive gzip historical-data packets over stdin; data are never executed.

The orchestrator uses this bounded, validated transport to avoid embedding large
datasets in executable file-edit requests. This process has no network access.
"""

import base64
import gzip
import json
import re
import sys
from pathlib import Path

from research.regime_backtest.evaluate import decode_response


def main():
    directory = Path(__file__).resolve().parent / "data"
    settings = None
    if sys.stdin.isatty():
        import termios

        settings = termios.tcgetattr(sys.stdin)
        mode = termios.tcgetattr(sys.stdin)
        mode[3] &= ~(termios.ECHO | termios.ICANON)
        termios.tcsetattr(sys.stdin, termios.TCSANOW, mode)
    print("READY", flush=True)
    try:
        for raw in sys.stdin.buffer:
            try:
                if len(raw) > 2_000_000:
                    raise ValueError("packet too large")
                request = json.loads(raw)
                if request.get("command") == "close":
                    break
                name = request["name"]
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{4}-\d{2}-\d{2}\.json\.gz", name):
                    raise ValueError("invalid archive name")
                target = directory / name
                if target.exists():
                    raise ValueError("archive already exists")
                content = base64.b64decode(request["gzip_b64"], validate=True)
                packet = json.loads(gzip.decompress(content))
                response = decode_response(packet)
                temporary = target.with_suffix(target.suffix + ".tmp")
                temporary.write_bytes(content)
                temporary.replace(target)
                print(
                    json.dumps({"saved": name, "rows": response["counts"]["records"]}), flush=True
                )
            except Exception as exc:
                print(
                    json.dumps({"error": type(exc).__name__, "detail": str(exc)[:120]}), flush=True
                )
    finally:
        if settings is not None:
            termios.tcsetattr(sys.stdin, termios.TCSANOW, settings)


if __name__ == "__main__":
    main()
