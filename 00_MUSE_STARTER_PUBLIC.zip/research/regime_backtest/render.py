"""Write a readable historical validation report from saved numerical results."""

import argparse
import json
from pathlib import Path


def pct(value):
    return "—" if value is None else f"{100 * value:.1f}%"


def summary_row(label, item):
    trend, chop = item["classes"]["TREND"], item["classes"]["CHOPPY"]
    return (
        f"| {label} | {item['outcome_available']} | {pct(trend['precision'])} | "
        f"{pct(trend['recall'])} | {pct(chop['precision'])} | {pct(chop['recall'])} | "
        f"{pct(item['accuracy_all_outcomes'])} | {pct(item['majority_baseline_accuracy'])} |"
    )


def render(directory: Path):
    summary = json.loads((directory / "SUMMARY.json").read_text())
    primary, data = summary["primary"], summary["data"]
    lines = [
        "# Can the existing regime script predict a trend day?",
        "",
        "Historical validation of the unchanged 20-minute label on SPY and QQQ, "
        "January 2022 through December 2025. The primary forecast is 10:00:15 Eastern, "
        "scored against the strictly later path from 10:01 to the actual session close.",
        "",
        "## Main results",
        "",
        "| Sample | Scored symbol-sessions | Trend precision | Trend recall | Chop precision | "
        "Chop recall | Three-class accuracy | Majority-class baseline |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
        summary_row("All years", primary),
    ]
    for year, item in summary["by_year"].items():
        lines.append(
            summary_row(year + (" final chronological block" if year == "2025" else ""), item)
        )
    for symbol, item in summary["by_symbol"].items():
        lines.append(summary_row(symbol, item))
    baseline = summary["prior_session_majority_baseline"]
    lines.extend(
        [
            "",
            "A deployable history-only baseline predicts the most common outcome from earlier "
            "closed sessions for that symbol and forecast clock. Its accuracy is "
            + pct(baseline["accuracy_all_outcomes"])
            + "; balanced accuracy "
            + pct(baseline["balanced_accuracy"])
            + ". The first session has no training history and remains UNKNOWN.",
            "",
            "Precision asks: when the script called TREND or CHOPPY, how often did the "
            "remaining session actually meet that definition? Recall asks: of all sessions that "
            "later qualified, how many did it catch? MIXED and UNKNOWN remain in the test.",
            "",
            "The majority baseline always predicts the most common outcome class within the "
            "same sample. It is a descriptive class-frequency reference, not a deployable "
            "trading strategy or an ex-ante fitted forecast.",
            "",
            "| Signal | Times predicted | Correct | Future-outcome base rate | Precision lift | "
            "Date-block 95% lift interval |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for label in ("TREND", "CHOPPY"):
        item = primary["classes"][label]
        interval = primary["date_block_bootstrap"][label]["lift_95_percentile"]
        ci = (
            "—"
            if interval is None
            else (f"{100 * interval[0]:+.1f} to {100 * interval[1]:+.1f} percentage points")
        )
        lift = item["precision_lift"]
        lift_text = "—" if lift is None else f"{100 * lift:+.1f} pp"
        lines.append(
            f"| {label} | {item['predicted']} | {item['correct']} | "
            f"{pct(item['base_rate'])} | {lift_text} | {ci} |"
        )
    lines.extend(
        [
            "",
            "SPY and QQQ share market conditions. Bootstrap resampling keeps both symbols "
            "on the same date together; the primary interval uses 1,000 date-block resamples.",
            "",
            "## Prediction times",
            "",
            "| Eastern clock | Scored | Known-label coverage | Trend precision | Trend recall | "
            "Chop precision | Chop recall | Accuracy | Majority baseline |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for clock, item in summary["by_time"].items():
        t, c = item["classes"]["TREND"], item["classes"]["CHOPPY"]
        lines.append(
            f"| {clock} | {item['outcome_available']} | "
            f"{pct(item['prediction_coverage'])} | {pct(t['precision'])} | "
            f"{pct(t['recall'])} | {pct(c['precision'])} | {pct(c['recall'])} | "
            f"{pct(item['accuracy_all_outcomes'])} | "
            f"{pct(item['majority_baseline_accuracy'])} |"
        )
    lines.extend(
        [
            "",
            "At 09:50 the script has only 20 completed minute bars, so its 21-bar requirement "
            "normally produces UNKNOWN. Earliest label availability is tested separately at09:51. "
            "Later-time results use their own remaining-session outcomes and cannot be read as "
            "earlier predictions of the entire day.",
            "",
            "## Confusion matrix at10:00",
            "",
            "Rows are later realized session types; columns are the script's earlier labels.",
            "",
            "| Actual later outcome | Predicted TREND | Predicted CHOPPY | Predicted MIXED | "
            "Predicted UNKNOWN |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for actual, row in primary["confusion_actual_rows_predicted_columns"].items():
        lines.append(
            f"| {actual} | "
            + " | ".join(str(row[c]) for c in ("TREND", "CHOPPY", "MIXED", "UNKNOWN"))
            + " |"
        )
    lines.extend(
        [
            "",
            "## Robustness checks",
            "",
            "| Check | Trend precision | Trend recall | Chop precision | Chop recall |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    checks = {
        **{
            "Candle availability delay " + key + "s": item
            for key, item in summary["availability_sensitivity"].items()
        },
        **{
            "Future trend R-squared cutoff " + key: item
            for key, item in summary["outcome_sensitivity"].items()
        },
        **{"Outcome " + key: item for key, item in summary["by_horizon"].items()},
    }
    for label, item in checks.items():
        t, c = item["classes"]["TREND"], item["classes"]["CHOPPY"]
        lines.append(
            f"| {label} | {pct(t['precision'])} | {pct(t['recall'])} | "
            f"{pct(c['precision'])} | {pct(c['recall'])} |"
        )
    lines.extend(
        [
            "",
            "The FULL_SESSION result is descriptive: its outcome includes the morning already "
            "observed by the classifier. The future-only result is the actual forecast test. "
            "No thresholds were optimized on any year;2025 is the final chronological block.",
            "",
            "## Coverage and method",
            "",
            f"- Expected NYSE sessions: {data['market_sessions']}; symbol-session pairs: "
            f"{data['symbol_sessions']}.",
            f"- Complete minute-by-minute symbol-sessions: {data['complete_symbol_sessions']}; "
            f"entirely absent symbol-sessions: {data['missing_entire_symbol_sessions']}.",
            f"- Missing regular-session minutes: {data['missing_minutes']}; invalid rows: "
            f"{data['invalid_rows']}.",
            f"- Archived data files: {data['files']}; archived rows: {data['archived_rows']:,}.",
            "- Price source: [Alpaca historical SIP bars]"
            "(https://docs.alpaca.markets/us/reference/stockbars). Requests, row counts and hashes "
            "are retained in DATA_MANIFEST.json. Session times and DST use the NYSE calendar.",
            "- Predictor code and numeric thresholds are unchanged. An isolated historical import "
            "accepts correctly labeled Alpaca/SIP provenance; it does not rename it Yahoo data.",
            "- Future TREND requires five-minute close-path linearity (R-squared≥0.65), "
            "absolute displacement≥60% of the horizon's high-low range and a close in the terminal "
            "20% consistent with direction. CHOPPY requires R-squared≤0.25 and displacement≤35% "
            "of range. Everything else remains MIXED. This is an explicit research definition, "
            "not a universal market taxonomy.",
            "- Every target starts strictly after the prediction. Whole five-minute blocks plus "
            "the actual final close are scored; missing minutes are never interpolated.",
            "",
            "## Limits",
            "",
            *["- " + line for line in summary["limitations"]],
            "",
            "Live and paper rules, configuration, positions and services were not changed. "
            "The backtest runs in a separate research package so the frozen paper bot's source "
            "guards continue to pass.",
            "",
            "Artifacts: SUMMARY.json, DAILY_PREDICTIONS.csv, COVERAGE.csv, DATA_MANIFEST.json; "
            "the declared protocol and unit-test evidence are in the parent research folder.",
        ]
    )
    (directory / "REPORT.md").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    render(parser.parse_args().directory)
