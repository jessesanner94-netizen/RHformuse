# Historical trend/chop forecast validation

Completed results: [2022–2025 report](results_2022_2025/REPORT.md), with daily
predictions, coverage, provenance and verification in the same directory. The
existing classifier did not establish a reliable forecast of the remaining
session; the live and paper strategies remain unchanged.

This research evaluates the unchanged `research/volatility_paper/regime.py` label
as a forecast. Its original tests established mechanical behavior, not predictive
power. The current task asks whether a morning label distinguishes what the rest
of a market session will become.

The declared protocol is in `PROTOCOL.json`, with its pre-analysis hash and source
identities in `INITIAL_STATE.json`. Four calendar years, 2022–2025, are enumerated
using the NYSE calendar for both SPY and QQQ. The primary forecast is 10:00:15 Eastern;
earlier/later times, outcome definitions and receipt-delay sensitivities are
diagnostics. No parameter fitting or numeric classifier changes are made. All
live and paper strategy code, services and configuration remain unchanged.

## Data and reproducibility

`data/*.json.gz` retains read-only `alpaca_get_stock_bars` SIP observations. Query
timestamps are explicit UTC; relative days/hours/minutes are zero. Weekly requests
use both symbols with a 10,000-row ceiling; a response reaching its ceiling must be
split rather than treated as complete. Returned row counts are checked.

Earlier files retain the original tool response. Later files losslessly encode
OHLCV values as column arrays and retain only 09:30–15:59 Eastern observations;
the actual NYSE session calendar then removes after-close bars on shortened days.
Original response counts, request parameters, retrieval timestamps and provenance
are retained. File hashes are exported with the numerical evaluation. Prices are
not rounded, missing minutes are not filled and source names are not fabricated.
The same classifier is loaded into an isolated research namespace whose only
policy adapter accepts `alpaca/SIP` instead of the paper recorder's Yahoo source.

The data transfer uses bundled Pako gzip code and a validated stdin archive
receiver; earlier archives used bounded base64 file-tool chunks. This changes
serialization only. Capped weekly queries are discarded and recursively split;
each complete subquery's original count/limit is retained and checked separately.
No filtering uses future outcomes, regenerates candles or changes numeric values.

To reproduce, use a new output directory because existing results are protected:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python \
  -m research.regime_backtest.evaluate \
  --output research/regime_backtest/results_reproduction

.venv/bin/python -m research.regime_backtest.render \
  research/regime_backtest/results_reproduction

.venv/bin/python -m pytest tests/test_regime_backtest.py
```

Runs refuse to overwrite prior results. Results include every expected symbol/day,
including missing sessions and UNKNOWN labels; diagnostics retain MIXED outcomes.
`DAILY_PREDICTIONS.csv` records each early prediction and its later realized label.
`COVERAGE.csv` audits every expected minute/day. `SUMMARY.json` includes precision,
recall, confusion matrices, class-frequency baselines, annual/symbol breakdowns,
future-only and full-session comparisons, and date-block bootstrap intervals.
SPY and QQQ are resampled together by date because they are correlated.

## Interpretation

The forecast uses only bars assumed available by its timestamp. Future outcomes
are independently defined using five-minute close-path linearity, displacement
relative to the high-low range and terminal close location. The actual session
close is included even when its final five-minute block is partial. The first
target minute begins strictly after the forecast; full-session labels are clearly
separated as descriptive diagnostics because they include the observation window.

Historical data are revised bars without actual receipt/revision archives. The
base assumption is bar end + 1 second availability, with 30/60 second sensitivities.
These are tests of the stated definitions, not a universally correct definition
of a trend day. A classification result cannot establish option profitability:
no historical option chains/quotes, executions, fees or strategy P&L are simulated.

Primary data documentation:
[Alpaca historical bars](https://docs.alpaca.markets/us/reference/stockbars).
