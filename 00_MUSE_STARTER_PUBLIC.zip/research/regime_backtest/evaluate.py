"""Validate the existing 20-minute regime label against strictly later price paths.

Run: python -m research.regime_backtest.evaluate --data ... --output ...
Consumes archived Alpaca connector responses. Never fetches data or executes trades.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import math
from collections import Counter, defaultdict
from datetime import UTC, date, datetime, time, timedelta
from pathlib import Path

import numpy as np
import pandas_market_calendars as mcal

from tools.market_calendar import EASTERN

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CLASSES = ("TREND", "CHOPPY", "MIXED", "UNKNOWN")


def stamp(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("bar timestamp must include timezone")
    return result.astimezone(UTC)


def historical_classifier():
    """Same code/thresholds, isolated namespace accepting truthful historical provenance."""
    path = ROOT / "research/volatility_paper/regime.py"
    spec = importlib.util.spec_from_file_location("offline_frozen_regime", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.POLICY = {**module.POLICY, "source": "alpaca", "venue": "SIP"}
    return module


def observation(bar, symbol, delay=1):
    start = stamp(bar["timestamp"])
    end = start + timedelta(minutes=1)
    available = end + timedelta(seconds=delay)
    return {
        "schema_version": 1,
        "kind": "bar",
        "symbol": symbol,
        "source": "alpaca",
        "venue": "SIP",
        "event_id": start.isoformat(),
        "event_at": end.isoformat(),
        "received_at": available.isoformat(),
        "available_at": available.isoformat(),
        "payload": {
            **{key: bar[key] for key in ("open", "high", "low", "close", "volume")},
            "start_at": start.isoformat(),
            "end_at": end.isoformat(),
        },
    }


def outcome(bars, *, trend_r2=0.65):
    """Independent 5m linearity/range/terminal-location outcome, never a predictor input."""
    if len(bars) < 30:
        return {"label": "UNKNOWN", "reason": "insufficient_complete_five_minute_blocks"}
    offsets = list(range(5, len(bars) + 1, 5))
    if offsets[-1] != len(bars):
        offsets.append(len(bars))
    values = np.array([float(bars[0]["open"]), *(float(bars[i - 1]["close"]) for i in offsets)])
    x = np.array([0, *offsets], dtype=float)
    centered = values - values.mean()
    sst = float(centered @ centered)
    x -= x.mean()
    explained = float((x @ centered) ** 2 / (x @ x))
    r_squared = min(1.0, max(0.0, explained / sst)) if sst else 0.0
    low, high = min(float(b["low"]) for b in bars), max(float(b["high"]) for b in bars)
    width, displacement = high - low, float(values[-1] - values[0])
    fraction = abs(displacement) / width if width else 0.0
    location = (float(values[-1]) - low) / width if width else 0.5
    edge = (displacement > 0 and location >= 0.8) or (displacement < 0 and location <= 0.2)
    label = (
        "TREND"
        if r_squared >= trend_r2 and fraction >= 0.6 and edge
        else "CHOPPY"
        if r_squared <= 0.25 and fraction <= 0.35
        else "MIXED"
    )
    return {
        "label": label,
        "r_squared": r_squared,
        "net_to_range": fraction,
        "close_location": location,
        "direction": "UP" if displacement > 0 else "DOWN" if displacement < 0 else "FLAT",
        "bars": len(bars),
    }


def interval(mapping, begin, end):
    expected = int((end - begin).total_seconds() // 60)
    keys = [begin + timedelta(minutes=i) for i in range(expected)]
    if not expected or any(k not in mapping for k in keys):
        return None
    return [mapping[k] for k in keys]


def predict(mapping, symbol, at, classifier, *, delay=1):
    # Pass all available bars in the trailing window plus one preceding minute.
    eligible = [
        b for t, b in sorted(mapping.items()) if t + timedelta(minutes=1, seconds=delay) <= at
    ]
    return classifier.classify([observation(b, symbol, delay) for b in eligible[-21:]], symbol, at)


def score_session(mapping, symbol, day, hours, classifier, protocol):
    opened, closed = hours
    full = interval(mapping, opened, closed)
    full_outcome = outcome(full) if full else {"label": "UNKNOWN"}
    times = [
        protocol["primary_forecast_time_eastern"],
        *protocol["diagnostic_forecast_times_eastern"],
    ]
    results = []
    for clock in times:
        at = datetime.combine(day, time.fromisoformat(clock), EASTERN).astimezone(UTC)
        if at >= closed:
            results.append(
                {
                    "date": day.isoformat(),
                    "symbol": symbol,
                    "time": clock,
                    "status": "OUTSIDE_SESSION",
                    "prediction": "UNKNOWN",
                    "future": "UNKNOWN",
                    "full_session": full_outcome["label"],
                }
            )
            continue
        label = predict(mapping, symbol, at, classifier)
        # The 10:00 candle contains 15s before a 10:00:15 prediction. Start at10:01.
        future_start = at.replace(second=0, microsecond=0) + timedelta(minutes=1)
        # Include the actual session close, even when the final 5m block is partial.
        future_end = closed
        remainder = interval(mapping, future_start, future_end)
        target = outcome(remainder) if remainder else {"label": "UNKNOWN"}
        row = {
            "date": day.isoformat(),
            "symbol": symbol,
            "time": clock,
            "forecast_at": at.isoformat(),
            "future_start": future_start.isoformat(),
            "future_end": future_end.isoformat(),
            "status": "OK" if target["label"] != "UNKNOWN" else "OUTCOME_UNAVAILABLE",
            "prediction": label["structure"],
            "volatility": label["volatility"],
            "predicted_direction": label["direction"],
            "prediction_reason": label["reason"],
            "efficiency": label["metrics"].get("efficiency"),
            "future": target["label"],
            "future_direction": target.get("direction"),
            "future_r_squared": target.get("r_squared"),
            "future_net_to_range": target.get("net_to_range"),
            "full_session": full_outcome["label"],
            "full_session_direction": full_outcome.get("direction"),
        }
        for horizon in (30, 60):
            end = future_start + timedelta(minutes=horizon)
            sample = interval(mapping, future_start, end) if end <= closed else None
            later = outcome(sample) if sample else {"label": "UNKNOWN"}
            row["future_" + str(horizon)] = later["label"]
            row["future_" + str(horizon) + "_direction"] = later.get("direction")
        for delay in protocol["sensitivity_availability_delay_seconds"]:
            row["prediction_delay_" + str(delay)] = predict(
                mapping, symbol, at, classifier, delay=delay
            )["structure"]
        for r2 in protocol["future_outcome"]["outcome_definition_sensitivity_trend_r_squared"]:
            row["future_r2_" + str(r2)] = (
                outcome(remainder, trend_r2=r2)["label"] if remainder else ("UNKNOWN")
            )
        results.append(row)
    return results


def wilson(successes, count):
    if not count:
        return None
    z = 1.959963984540054
    p = successes / count
    denominator = 1 + z * z / count
    center = (p + z * z / (2 * count)) / denominator
    radius = z * math.sqrt(p * (1 - p) / count + z * z / (4 * count * count)) / denominator
    return [max(0, center - radius), min(1, center + radius)]


def summarize(rows, *, target="future", prediction="prediction"):
    usable = [
        r
        for r in rows
        if r.get(target, "UNKNOWN") != "UNKNOWN" and r["status"] != "OUTSIDE_SESSION"
    ]
    matrix = {actual: {pred: 0 for pred in CLASSES} for actual in CLASSES[:-1]}
    for row in usable:
        matrix[row[target]][row.get(prediction, "UNKNOWN")] += 1
    total = len(usable)
    known = sum(r.get(prediction, "UNKNOWN") != "UNKNOWN" for r in usable)
    correct = sum(r.get(prediction) == r[target] for r in usable)
    classes = {}
    for value in CLASSES[:-1]:
        actual = sum(r[target] == value for r in usable)
        predicted = sum(r.get(prediction) == value for r in usable)
        tp = matrix[value][value]
        classes[value] = {
            "actual": actual,
            "predicted": predicted,
            "correct": tp,
            "precision": tp / predicted if predicted else None,
            "precision_wilson95": wilson(tp, predicted),
            "recall": tp / actual if actual else None,
            "base_rate": actual / total if total else None,
            "precision_lift": tp / predicted - actual / total if predicted and total else None,
        }
    recalls = [c["recall"] for c in classes.values() if c["recall"] is not None]
    trend_rows = [r for r in usable if r.get(prediction) == "TREND"]
    direction_key = (
        target + "_direction"
        if target in {"future_30", "future_60", "full_session"}
        else "future_direction"
    )
    direction = [r for r in trend_rows if r.get(direction_key) in {"UP", "DOWN"}]
    return {
        "expected_symbol_sessions": len(rows),
        "outcome_available": total,
        "outcome_unavailable": sum(r["status"] != "OUTSIDE_SESSION" for r in rows) - total,
        "outside_session": sum(r["status"] == "OUTSIDE_SESSION" for r in rows),
        "unique_dates": len({r["date"] for r in usable}),
        "known_predictions": known,
        "prediction_coverage": known / total if total else None,
        "accuracy_all_outcomes": correct / total if total else None,
        "accuracy_known_predictions": correct / known if known else None,
        "balanced_accuracy": sum(recalls) / len(recalls) if recalls else None,
        "majority_baseline_accuracy": max((c["actual"] for c in classes.values()), default=0)
        / total
        if total
        else None,
        "confusion_actual_rows_predicted_columns": matrix,
        "classes": classes,
        "trend_signal_future_direction_accuracy": sum(
            r.get("predicted_direction") == r[direction_key] for r in direction
        )
        / len(direction)
        if direction and prediction == "prediction"
        else None,
    }


def bootstrap_lift(rows, value, protocol):
    groups = defaultdict(lambda: np.zeros(4, dtype=float))
    for row in rows:
        if row.get("future") == "UNKNOWN" or row["status"] == "OUTSIDE_SESSION":
            continue
        actual = row["future"] == value
        predicted = row["prediction"] == value
        groups[row["date"]] += (actual and predicted, predicted, actual, 1)
    if not groups:
        return None
    data = np.array(list(groups.values()))
    rng = np.random.default_rng(protocol["bootstrap"]["seed"])
    lifts = []
    for _ in range(protocol["bootstrap"]["replicates"]):
        tp, predicted, actual, total = data[rng.integers(len(data), size=len(data))].sum(axis=0)
        if predicted:
            lifts.append(tp / predicted - actual / total)
    return {
        "replicates_used": len(lifts),
        "unit": "DATE_BLOCK_BOTH_SYMBOLS",
        "lift_95_percentile": np.quantile(lifts, [0.025, 0.975]).tolist() if lifts else None,
    }


def decode_response(envelope):
    response = envelope["response"]
    if response["request"]["feed"] != "sip" or response["request"]["timeframe"] != "1Min":
        raise ValueError("requires original one-minute SIP responses")
    source_queries = envelope.get("source_queries") or [
        {
            "counts": envelope.get("source_counts", response["counts"]),
            "request": response["request"],
        }
    ]
    if any(q["counts"]["records"] >= q["request"]["limit"] for q in source_queries):
        raise ValueError("possible capped response; split the historical query")
    if columns := envelope.get("columns"):
        response = {
            **response,
            "bars": {
                symbol: [dict(zip(columns, row, strict=True)) for row in rows]
                for symbol, rows in response["bars"].items()
            },
        }
    if set(response["bars"]) - {"SPY", "QQQ"}:
        raise ValueError("outside the declared evaluation universe")
    if sum(len(rows) for rows in response["bars"].values()) != response["counts"]["records"]:
        raise ValueError("response count does not match archived rows")
    return response


def prior_majority_baseline(rows):
    """One prediction per symbol/clock/date, trained only on earlier closed sessions."""
    history = defaultdict(Counter)
    for row in sorted(rows, key=lambda r: (r["date"], r["symbol"], r["time"])):
        counts = history[row["symbol"], row["time"]]
        row["prior_session_majority"] = (
            max(CLASSES[:-1], key=lambda c: counts[c]) if sum(counts.values()) else "UNKNOWN"
        )
        row["prior_session_baseline_samples"] = sum(counts.values())
        if row["status"] != "OUTSIDE_SESSION" and row["future"] != "UNKNOWN":
            counts[row["future"]] += 1


def run(data_dir, output):
    protocol = json.loads((HERE / "PROTOCOL.json").read_text())
    initial = json.loads((HERE / "INITIAL_STATE.json").read_text())
    protocol_hash = hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest()
    if protocol_hash != initial["protocol_sha256"]:
        raise ValueError("declared protocol changed")
    classifier_path = ROOT / "research/volatility_paper/regime.py"
    if (
        hashlib.sha256(classifier_path.read_bytes()).hexdigest()
        != initial["protected_files"]["research/volatility_paper/regime.py"]
    ):
        raise ValueError("classifier changed after protocol declaration")
    if output.exists():
        raise FileExistsError("refuse to overwrite prior validation")
    schedule = mcal.get_calendar("NYSE").schedule(
        start_date=protocol["start"],
        end_date=date.fromisoformat(protocol["end_exclusive"]) - timedelta(days=1),
    )
    sessions = {
        idx.date(): (row["market_open"].to_pydatetime(), row["market_close"].to_pydatetime())
        for idx, row in schedule.iterrows()
    }
    classifier = historical_classifier()
    # Identical NYSE calendar, computed once rather than one expensive query per day.
    classifier.session_hours = sessions.get
    results, coverage, files, seen = [], [], [], set()
    for path in sorted(data_dir.glob("*.json.gz")):
        with gzip.open(path, "rt") as handle:
            envelope = json.load(handle)
        response = decode_response(envelope)
        groups = defaultdict(dict)
        invalid, duplicates = Counter(), Counter()
        actual_count = 0
        for symbol, bars in response["bars"].items():
            actual_count += len(bars)
            for bar in bars:
                at = stamp(bar["timestamp"])
                day = at.astimezone(EASTERN).date()
                if day not in sessions or not sessions[day][0] <= at < sessions[day][1]:
                    continue
                key = (symbol, day)
                values = [bar[k] for k in ("open", "high", "low", "close", "volume")]
                valid = all(
                    not isinstance(v, bool) and isinstance(v, (float, int)) and math.isfinite(v)
                    for v in values
                )
                if not valid or not (
                    0
                    < bar["low"]
                    <= min(bar["open"], bar["close"])
                    <= max(bar["open"], bar["close"])
                    <= bar["high"]
                    and bar["volume"] >= 0
                    and at.second == 0
                    and at.microsecond == 0
                ):
                    invalid[key] += 1
                    continue
                if at in groups[key]:
                    duplicates[key] += 1
                    if groups[key][at] != bar:
                        raise ValueError("conflicting historical duplicate")
                groups[key][at] = bar
        if actual_count != response["counts"]["records"]:
            raise ValueError("response count does not match archived rows")
        files.append(
            {
                "file": path.name,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "records": actual_count,
                "request": response["request"],
                "source_queries": envelope.get("source_queries"),
            }
        )
        for (symbol, day), mapping in sorted(groups.items()):
            if (symbol, day) in seen:
                raise ValueError("session crosses archive chunks; merge explicitly before scoring")
            seen.add((symbol, day))
            hours = sessions[day]
            expected = int((hours[1] - hours[0]).total_seconds() // 60)
            coverage.append(
                {
                    "date": day.isoformat(),
                    "symbol": symbol,
                    "expected": expected,
                    "observed": len(mapping),
                    "missing": expected - len(mapping),
                    "invalid": invalid[(symbol, day)],
                    "duplicates": duplicates[(symbol, day)],
                }
            )
            results.extend(score_session(mapping, symbol, day, hours, classifier, protocol))
    for day, hours in sessions.items():
        for symbol in protocol["symbols"]:
            if (symbol, day) not in seen:
                expected = int((hours[1] - hours[0]).total_seconds() // 60)
                coverage.append(
                    {
                        "date": day.isoformat(),
                        "symbol": symbol,
                        "expected": expected,
                        "observed": 0,
                        "missing": expected,
                        "invalid": 0,
                        "duplicates": 0,
                    }
                )
                results.extend(score_session({}, symbol, day, hours, classifier, protocol))
    results.sort(key=lambda r: (r["date"], r["symbol"], r["time"]))
    prior_majority_baseline(results)
    primary = [r for r in results if r["time"] == protocol["primary_forecast_time_eastern"]]
    primary_summary = summarize(primary)
    primary_summary["date_block_bootstrap"] = {
        value: bootstrap_lift(primary, value, protocol) for value in ("TREND", "CHOPPY")
    }
    summary = {
        "mode": "FIXED_HEURISTIC_HISTORICAL_FORECAST_VALIDATION",
        "protocol": protocol,
        "protocol_sha256": protocol_hash,
        "evaluator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "classifier_sha256": hashlib.sha256(
            (ROOT / "research/volatility_paper/regime.py").read_bytes()
        ).hexdigest(),
        "data": {
            "files": len(files),
            "archived_rows": sum(f["records"] for f in files),
            "market_sessions": len(sessions),
            "symbol_sessions": len(coverage),
            "complete_symbol_sessions": sum(c["missing"] == 0 for c in coverage),
            "missing_minutes": sum(c["missing"] for c in coverage),
            "missing_entire_symbol_sessions": sum(c["observed"] == 0 for c in coverage),
            "invalid_rows": sum(c["invalid"] for c in coverage),
        },
        "primary": primary_summary,
        "prior_session_majority_baseline": summarize(primary, prediction="prior_session_majority"),
        "by_time": {
            clock: summarize([r for r in results if r["time"] == clock])
            for clock in sorted({r["time"] for r in results})
        },
        "by_symbol": {
            s: summarize([r for r in primary if r["symbol"] == s]) for s in protocol["symbols"]
        },
        "by_year": {
            y: summarize([r for r in primary if r["date"].startswith(y)])
            for y in sorted({r["date"][:4] for r in primary})
        },
        "by_year_symbol": {
            y + "_" + s: summarize(
                [r for r in primary if r["date"].startswith(y) and r["symbol"] == s]
            )
            for y in sorted({r["date"][:4] for r in primary})
            for s in protocol["symbols"]
        },
        "outcome_sensitivity": {
            str(r2): summarize(primary, target="future_r2_" + str(r2))
            for r2 in protocol["future_outcome"]["outcome_definition_sensitivity_trend_r_squared"]
        },
        "availability_sensitivity": {
            str(delay): summarize(primary, prediction="prediction_delay_" + str(delay))
            for delay in protocol["sensitivity_availability_delay_seconds"]
        },
        "by_horizon": {
            target: summarize(primary, target=target)
            for target in ("future_30", "future_60", "full_session")
        },
        "trading_pnl": None,
        "live_or_paper_strategy_changed": False,
        "limitations": [
            "Historical revised bars with assumed end+1s availability; no archived real receipts.",
            "SIP historical tape differs from the paper recorder's Yahoo feed.",
            "TREND/CHOPPY have no unique ground truth; outcomes use explicit heuristics.",
            "Full-session labels include the observation window and are descriptive diagnostics.",
            "2025 is the final chronological block; no thresholds were fitted on any block.",
            "Pooled symbols share market days; uncertainty resamples dates together.",
            "No option quotes/fills, costs or strategy P&L were backtested.",
        ],
    }
    output.mkdir(parents=True)
    for name, rows in (("DAILY_PREDICTIONS.csv", results), ("COVERAGE.csv", coverage)):
        fields = sorted({key for row in rows for key in row})
        with (output / name).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    (output / "DATA_MANIFEST.json").write_text(json.dumps(files, indent=2) + "\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=HERE / "data")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary = run(args.data, args.output)
    print(json.dumps({"data": summary["data"], "primary": summary["primary"]}, indent=2))


if __name__ == "__main__":
    main()
