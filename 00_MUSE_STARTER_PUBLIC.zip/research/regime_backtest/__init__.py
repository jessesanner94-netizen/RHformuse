"""Offline historical forecast validation; no strategy or service mutations."""
