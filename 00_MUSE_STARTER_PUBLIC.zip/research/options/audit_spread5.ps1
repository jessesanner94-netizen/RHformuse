# Read-only entry-spread analysis for Batch O-002 in EXPERIMENT_LOG.md.
# Run: pwsh -NoProfile -File research/options/audit_spread5.ps1
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$exitByLedger = @{ primary = @{}; control = @{} }
$eventPaths = @{
    primary = 'state/paper/EVENTS.jsonl'
    control = 'state/paper_baseline/EVENTS.jsonl'
}
foreach ($ledger in @('primary', 'control')) {
    Get-Content (Join-Path $projectRoot $eventPaths[$ledger]) | ForEach-Object {
        $event = $_ | ConvertFrom-Json -DateKind String
        if ($event.event -eq 'PAPER_EXIT') { $exitByLedger[$ledger][$event.paper_id] = $event }
    }
}

$rows = [System.Collections.Generic.List[object]]::new()
foreach ($logFile in (Get-ChildItem (Join-Path $projectRoot 'state/logs/2026-09-*.jsonl'))) {
    foreach ($line in (Get-Content -LiteralPath $logFile.FullName)) {
        $record = $line | ConvertFrom-Json -DateKind String
        foreach ($ledger in @('primary', 'control')) {
            $decision = if ($ledger -eq 'primary') { $record.result.paper_decision } else { $record.result.baseline_decision }
            if (-not $decision -or $decision.opened -ne $true -or $decision.event.event -ne 'PAPER_ENTRY') { continue }
            $entry = $decision.event
            $position = $decision.position
            if (-not $position -or $position.paper_id -ne $entry.paper_id -or $position.contract_identifier -ne $entry.contract_identifier) {
                throw "Entry/position mismatch: $ledger $($entry.paper_id)"
            }
            if ($entry.symbol -notin @('SPY', 'QQQ') -or $entry.trade_style -ne 'DAY') {
                throw "Unexpected entry universe/style: $ledger $($entry.paper_id)"
            }
            $bid = [double]$position.last_bid
            $ask = [double]$position.last_ask
            if ($bid -le 0 -or $ask -le 0 -or $bid -gt $ask -or [math]::Abs($ask - [double]$entry.fill_price) -gt 0.000001) {
                throw "Invalid final fill quote: $ledger $($entry.paper_id)"
            }
            $entryAt = [datetimeoffset]::Parse([string]$entry.timestamp)
            $fillSnapshotAt = [datetimeoffset]::Parse([string]$decision.fill_quote_snapshot_as_of)
            $quoteAt = [datetimeoffset]::Parse([string]$position.last_quote_at)
            $ageSeconds = ($entryAt - $quoteAt).TotalSeconds
            $fillAgeSeconds = ($entryAt - $fillSnapshotAt).TotalSeconds
            if ($fillAgeSeconds -lt 0 -or $fillAgeSeconds -gt 180 -or $ageSeconds -lt -2 -or $ageSeconds -gt 180) {
                throw "Stale/future entry quote: $ledger $($entry.paper_id): $ageSeconds seconds"
            }
            $exit = $exitByLedger[$ledger][$entry.paper_id]
            if (-not $exit) { throw "Missing exit: $ledger $($entry.paper_id)" }
            $spread = 100 * ($ask - $bid) / (($ask + $bid) / 2)
            $rows.Add([pscustomobject]@{
                ledger = $ledger
                paper_id = $entry.paper_id
                date = $entryAt.ToString('yyyy-MM-dd')
                symbol = $entry.symbol
                option_type = $entry.option_type
                entry_ask = $ask
                entry_bid = $bid
                quote_age_seconds = [math]::Round($ageSeconds, 3)
                spread_percent = [math]::Round($spread, 4)
                group = if ($spread -le 5) { 'AT_MOST_5' } else { 'OVER_5' }
                realized_pnl = [double]$exit.realized_pnl
                assumed_tp = $exit.exit_reason -match 'ASSUMED|USER_APPROVED'
            })
        }
    }
}

foreach ($ledger in @('primary', 'control')) {
    $expected = $exitByLedger[$ledger].Count
    $actual = @($rows | Where-Object ledger -eq $ledger).Count
    if ($actual -ne $expected) { throw "Missing or duplicate entries: $ledger expected $expected found $actual" }
}

$rows | Sort-Object ledger, date, paper_id |
    Format-Table ledger, date, symbol, option_type, entry_ask, entry_bid, spread_percent, group, realized_pnl, assumed_tp -AutoSize

foreach ($ledger in @('primary', 'control')) {
    foreach ($groupName in @('AT_MOST_5', 'OVER_5')) {
        $group = @($rows | Where-Object { $_.ledger -eq $ledger -and $_.group -eq $groupName } | Sort-Object date, paper_id)
        $pnl = ($group | Measure-Object realized_pnl -Sum).Sum
        $equity = 0.0
        $peak = 0.0
        $maxClosedDrawdown = 0.0
        foreach ($trade in $group) {
            $equity += $trade.realized_pnl
            if ($equity -gt $peak) { $peak = $equity }
            $drawdown = $peak - $equity
            if ($drawdown -gt $maxClosedDrawdown) { $maxClosedDrawdown = $drawdown }
        }
        [pscustomobject]@{
            ledger = $ledger
            spread_group = $groupName
            trades = $group.Count
            net_pnl = [math]::Round($pnl, 2)
            net_per_trade = if ($group.Count) { [math]::Round($pnl / $group.Count, 2) } else { $null }
            assumed_tp_trades = @($group | Where-Object assumed_tp).Count
            selected_closed_trade_drawdown = [math]::Round($maxClosedDrawdown, 2)
        } | Format-List
    }
}
