# Options workflow review — October 21, 2026

Research and proposals only. Production configuration, strategy, risk rules,
execution code, schedules and operational position/trade ledgers were not changed.
The companion JSON records descriptive calculations and source SHA256 hashes.

## Findings from the actual records

| Account / rule set | Closed trades | Win rate | Recorded P&L after modeled costs |
| --- | ---: | ---: | ---: |
| Current live epoch, October 12–21 | 6 | 50.0% | +$11.40 |
| Earlier DAY paper control, September 8–October 8 | 36 | 55.6% | +$70.40 |
| Earlier primary paper with model judgment, September 8–October 8 | 28 | 42.9% | −$176.80 |
| October 9 deterministic paper epoch | 1 | 0% | −$45.10 |
| Earlier isolated green-lock comparator | 1 | 0% | −$26.10 |

These are independent accounts with different selection/rule histories. Do not
pool them into a single strategy return or infer that removing model judgment
caused the control's advantage: selections, cash paths and the shared review
funnel differ. Historical policy changes prevent treating the entire month as
one unchanged prospective test of today's strategy.

Current live recorded gross fill P&L is +$24.00. Its ledger subtracts $2.10 modeled
round-trip execution costs per closed trade, giving +$11.40. Modeled slippage is
an accounting assumption even though recorded broker execution prices are used;
this is not a verified statement of actual brokerage fees or current account gain.
The six observed trades average +$44.23 on wins and −$40.43 on losses. Their
descriptive break-even win frequency is approximately 47.76%, and sample mean
P&L is +$1.90/trade. None is a reliable estimate of future expectancy. A simple
95% Wilson interval around 3 wins/6 trades is approximately 18.8–81.2%; it also
assumes comparable independent Bernoulli trials, which market trades may violate.

The earlier stop-after-green calculation saved October 9 reports +$147.00 over
20 retained fixed-record trades, versus +$70.40 over the original 36. That result
motivates a hypothesis; it is a retrospective selection of recorded entries/exits,
including assumed paper targets, without recomputing discovery/cash-dependent
opportunities. It is not a separate month of prospective current-strategy returns.
Thirteen of the control's 36 exits were assumed historical limit target fills.

## Today's loss: what can actually be established

Recorded broker fills: SPY October 26 $777 CALL, one contract, entry 09:51:09 ET
at $1.70, exit 10:05:57 ET at $1.21. Gross loss $49.00; modeled net loss $51.10.
Configured stop $1.275, target $2.21. Price loss was 28.82%, versus the 25% stop
trigger. The mathematical trigger-to-fill difference was $6.50. A fill at the
trigger was not established as available or achievable; that comparison does not
establish poor execution, an entry mistake or unreasonable $170 sizing.
Planned stopped-out loss including modeled costs was $44.60, leaving only $0.40
inside the $45 daily planned-loss budget. Actual loss exceeded that budget by $6.10.
This does not establish a sizing-gate violation: the budget is prospective and
software stops do not cap realized losses.

The 10:05 opportunity snapshot still showed a $1.35 bid. The later exit state
recorded a $1.23 bid and a $1.21 fill. About $4.50 of the stop-to-fill difference
therefore lies between the configured trigger and the recorded $1.23 observation,
with $2.00 between that bid and the fill. Those observations are not an executable
quote-path reconstruction or a causal attribution. The fast-monitor action poll
started at 10:05:47.796 ET and finished at 10:05:57.733 ET, including review and
submission. A separate snapshot timeout occurred around 10:01 ET while exposed.
We cannot attribute the entire $6.50 difference to that timeout, polling latency,
order review, market movement or a news item from these sparse observations.

Successful QUIET/MONITORED polls overwrite the current heartbeat but are omitted
from the historical monitor JSONL. Only five monitor events are retained for
October 21 at this review. That prevents a complete reconstruction of every
successful quote observation and the first stop crossing.

No verified timestamped market-moving headline was established for the trade's
09:51–10:06 ET window. News causality remains unconfirmed. Latest-headline searches
after the trade cannot substitute for what the bot could have known beforehand.

## News handling has a specific, observable weakness

Today's decision packet contained a single neutral JBT Marel earnings-schedule
headline. It supplies little relevant context for SPY. The current headline
summarizer allows a first unmatched item and uses phrase matching for sentiment;
deduplicating an RSS feed does not establish economic relevance or novelty.

The current no-Luna position route returns
`deterministic_position_monitor_no_luna` before qualitative thesis/event review.
News sentiment is available as a JEV ranking feature, but there is no explicit
material-news entry veto or news-triggered position-review policy in that route.
Scheduled macro blackouts remain active, and they cover a defined release list;
they are not a comprehensive detector of speeches or unscheduled announcements.

## Recommended order of work

### 1. Measure availability and stop execution accurately

Preserve the recent Linux connection-baseline repair. Add an external stale-
heartbeat check, automatic boot/service recovery checks, and a premarket readiness
status covering authorization, broker response time, calendar and monitor health.
An external observer must distinguish no-entry policy from outages; it should
not place orders or automatically create another execution owner. Verify existing
Linux/systemd recovery behavior before adding infrastructure already present.

Record readiness at the intended opening time, ready minutes, exposed quote gaps,
and time from trigger observation through review/submission/fill. Keep successful
held-position quote observations in a bounded local archive. Use measured tail
execution losses to test a more conservative risk reserve in paper. Do not set a
new risk threshold from today's single trade or assume a stop can guarantee a cap.

Investigate broker-held protective orders only after checking the actual API and
option-order capabilities, trigger definitions, OCO/duplicate-order behavior and
reconciliation. No support or safety of such orders is established by this review.

October 14 has no dated local opportunity log; that alone cannot prove a Windows
reboot. October 16's live entry was 10:51 ET, consistent with a late start but not
proof of its cause. October 20's persisted pause documents sustained broker
timeouts and a user-directed stop on Linux. Keep these incidents separate. Missed
sessions have unknown trade outcomes; assign neither hypothetical wins nor losses.

### 2. Complete the experimental data recorder

The dormant lab currently consumes supplied observations and has no active feed.
Create a read-only collector for candidate pools (including rejections), exact
option bid/ask, spread, Greeks/IV, underlying prices, source/receipt timestamps,
technical inputs, calendar/news state, JEV evidence and data outages. Record option
quotes at the monitoring cadence while exposed, with compression/retention limits
and bounded provider requests. Collection must not delay protective execution.

Freeze a fresh baseline against the current code. Retain the original October 19
source archive; the lab's integrity gate should keep refusing a changed code base.
Use independent cash/account state for any challenger and the same observation
stream. Log publication time, first-seen time, validation time and hypothetical
action time so hindsight and vendor latency remain measurable.

### 3. Test material-news safety in shadow mode

First challenger: current baseline plus a material-event safety policy. Classify
verified, new macro/policy/geopolitical events, index-relevant large constituents,
and relevant earnings/guidance separately. Deduplicate syndication and updated
articles, map exposure to SPY/QQQ, and retain an explicit unknown state.

Initially record hypothetical entry pauses and re-evaluations of held positions;
keep stop/target/deadline exits independent. A fresh opposing headline should not
automatically reverse an option position. Track prevented losses, forfeited wins,
false alarms, feed/classifier latency, trade count, net P&L and drawdown. Any exit
challenger needs a genuinely available subsequent bid and the ordinary costs.
Use a cheap relevance gate and at most one bounded review per new material event,
with fixed classifier/prompt versions and a separate experiment cost budget.

Headline-direction trading is a later, separate hypothesis. Faster collection
does not itself establish a speed advantage or a profitable news strategy.

### 4. Audit technical input semantics, then isolate option-selection hypotheses

The default entry worker's timeframe summaries use the latest row. Filtering to
completed 5M/15M candles currently happens only when `intraday_only=True`, used for
continuation evidence. Today's 5M/15M/4H summaries had the same latest close and
zero relative volume, while the separate completed-bar context had a different
close. This warrants a developing-bar/missing-volume audit. It does not establish
that completed-only entries would have won today. Retain developing data as such,
and test a completed-only challenger without silently changing the baseline.

Subsequent hypotheses can hold the underlying signal fixed while comparing
liquid contract choice by DTE, delta/gamma exposure, spread, IV and net payoff.
Attribute realized loss to underlying direction, quote spread, option repricing
and execution where data permits. A spot-chart win does not establish an option
profit. Avoid selecting a more expensive contract that fails the unchanged cash
or prospective risk budget. Do not expand the live instrument universe, add
spreads or change stop/target settings as part of this review.

## Experiment discipline

Start with one frozen baseline and one news-safety challenger after recording is
available. Run diagnostics for technical-input quality independently. Specify
rules and evaluation windows before inspecting their outcomes. Historical data
used to choose a rule is development evidence; later data is the held-out test.
Compare both trades and trading days, outage coverage, realistic execution costs,
worst days and uncertainty. A month or an arbitrary trade-count threshold is not
automatic proof of an edge. Do not keep adding filters until the same month looks
perfect, and do not retune a rule solely to remove October 21's loss.

## External research and tool boundaries

- [FINRA: Stop Orders—Factors to Consider During Volatile Markets](https://www.finra.org/investors/insights/stop-orders-factors-consider-during-volatile-markets)
  explains the distinction between trigger and execution price, and the nonfill
  risk of stop-limit orders. Its discussion is about stocks; it does not establish
  which protective option orders this brokerage API supports.
- [Aït-Sahalia, Li and Li: So Many Jumps, So Few News, NBER w32746](https://www.nber.org/papers/w32746)
  reports that relevant news often leads quickly to jumps, while most jumps lack
  identifiable public news. This supports testing event risk and retaining an
  unexplained state; it does not validate this bot or a tradeable speed advantage.
- Vibe-Trading's event-driven documentation and live SPY-related headline tool
  were inspected. Daily-date example weights/decay defaults were not adopted for
  an intraday options experiment. Retrieved latest headlines did not establish
  an event causing today's stop.
- A fresh read-only Robinhood request failed because this chat requires explicit
  OAuth reauthorization. No repeated auth, browser sign-in or order operation was
  attempted. The latest local position memory says flat at 12:05 ET; that is not
  a fresh independent account confirmation or proof of a problem in the live
  service's separate credential environment.

Source calculations: `WORKFLOW_REVIEW_2026-10-21.json`. No live strategy change is
recommended for immediate activation from this descriptive audit alone.
