# Read-only retrospective sensitivity for EXPERIMENT_LOG.md batch O-001.
# Run from any directory: pwsh -NoProfile -File research/options/audit_stop20.ps1
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$entries = @{ primary = @{}; control = @{} }
$exits = @{ primary = @{}; control = @{} }
$quotes = @{ primary = @{}; control = @{} }

foreach ($ledger in @('primary', 'control')) {
    $eventFile = if ($ledger -eq 'primary') { 'state/paper/EVENTS.jsonl' } else { 'state/paper_baseline/EVENTS.jsonl' }
    Get-Content (Join-Path $projectRoot $eventFile) | ForEach-Object {
        $event = $_ | ConvertFrom-Json
        if ($event.event -eq 'PAPER_ENTRY') { $entries[$ledger][$event.paper_id] = $event }
        if ($event.event -eq 'PAPER_EXIT') { $exits[$ledger][$event.paper_id] = $event }
    }
}

Get-ChildItem (Join-Path $projectRoot 'state/logs/2026-09-*.jsonl') | ForEach-Object {
    Get-Content -LiteralPath $_.FullName | ForEach-Object {
        $record = $_ | ConvertFrom-Json
        foreach ($ledger in @('primary', 'control')) {
            $section = if ($ledger -eq 'primary') { $record.result.paper } else { $record.result.baseline }
            if (-not $section -or -not $section.open_positions) { continue }
            $cycleAt = [datetimeoffset]::Parse([string]$record.result.run_at)
            foreach ($position in $section.open_positions) {
                if (-not $position.paper_id -or $null -eq $position.last_bid -or -not $position.last_quote_at) { continue }
                $quoteAt = [datetimeoffset]::Parse([string]$position.last_quote_at)
                $age = ($cycleAt - $quoteAt).TotalSeconds
                if ($age -lt 0 -or $age -gt 180) { continue }
                if (-not $quotes[$ledger].ContainsKey($position.paper_id)) {
                    $quotes[$ledger][$position.paper_id] = [System.Collections.Generic.List[object]]::new()
                }
                $quotes[$ledger][$position.paper_id].Add([pscustomobject]@{
                    time = $quoteAt
                    bid = [double]$position.last_bid
                })
            }
        }
    }
}

$results = [System.Collections.Generic.List[object]]::new()
foreach ($ledger in @('primary', 'control')) {
    foreach ($paperId in $exits[$ledger].Keys) {
        $entry = $entries[$ledger][$paperId]
        $exit = $exits[$ledger][$paperId]
        if (-not $entry) { throw "Missing entry: $ledger $paperId" }
        $entryAt = [datetimeoffset]::Parse([string]$entry.timestamp)
        $exitAt = [datetimeoffset]::Parse([string]$exit.timestamp)
        $observed = @($quotes[$ledger][$paperId] | Where-Object {
            $_.time -gt $entryAt -and $_.time -lt $exitAt
        } | Sort-Object time)
        $trigger = $observed | Where-Object { $_.bid -le ([double]$entry.fill_price * 0.80) } | Select-Object -First 1
        $assumedExit = $exit.exit_reason -match 'ASSUMED|USER_APPROVED'
        $status = if ($assumedExit) { 'CENSORED_ASSUMED_TP' } elseif ($trigger) { 'EARLIER_STOP_OBSERVED' } else { 'NO_EARLIER_STOP_OBSERVED' }
        $alternative = if ($status -eq 'EARLIER_STOP_OBSERVED') {
            [math]::Round((([double]$trigger.bid - [double]$entry.fill_price) * 100 - 2.10), 2)
        } elseif ($status -eq 'NO_EARLIER_STOP_OBSERVED') {
            [double]$exit.realized_pnl
        } else { $null }
        $results.Add([pscustomobject]@{
            ledger = $ledger
            paper_id = $paperId
            entry = [double]$entry.fill_price
            actual_exit = $exit.exit_reason
            actual_pnl = [double]$exit.realized_pnl
            quote_count = $observed.Count
            status = $status
            trigger_at = if ($trigger) { $trigger.time.ToString('o') } else { $null }
            trigger_bid = if ($trigger) { $trigger.bid } else { $null }
            stop20_pnl = $alternative
            delta = if ($null -ne $alternative) { [math]::Round($alternative - [double]$exit.realized_pnl, 2) } else { $null }
        })
    }
}

$results | Sort-Object ledger, paper_id | Format-Table ledger, paper_id, actual_exit, actual_pnl, quote_count, status, trigger_bid, stop20_pnl, delta -AutoSize
foreach ($ledger in @('primary', 'control')) {
    $group = @($results | Where-Object { $_.ledger -eq $ledger })
    $eligible = @($group | Where-Object { $_.status -ne 'CENSORED_ASSUMED_TP' })
    $actual = ($eligible | Measure-Object actual_pnl -Sum).Sum
    $alternative = ($eligible | Measure-Object stop20_pnl -Sum).Sum
    [pscustomobject]@{
        ledger = $ledger
        total_trades = $group.Count
        uncensored_trades = $eligible.Count
        observed_earlier_stops = @($eligible | Where-Object status -eq 'EARLIER_STOP_OBSERVED').Count
        uncensored_actual_net = [math]::Round($actual, 2)
        uncensored_stop20_net = [math]::Round($alternative, 2)
        difference = [math]::Round($alternative - $actual, 2)
    } | Format-List
}
