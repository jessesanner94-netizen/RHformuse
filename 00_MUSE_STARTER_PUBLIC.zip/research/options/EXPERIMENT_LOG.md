# SPY/QQQ long-option research — paper only

## 2026-09-19 — Batch O-001, frozen before counterfactual calculation

Objective: determine whether a simpler, cheaper DAY decision rule or a tighter
exit deserves a **prospective** test. This batch uses the existing September 8–18
paper ledgers and their timestamped option bid/ask observations. It does not
change the running strategy, core policy, scheduler, or broker account.

### Evidence audit

- Primary: 11 closed, -$80.10 net after configured estimated execution costs.
- Deterministic DAY control: 13 closed, -$1.30 net on an independent paper ledger.
- Of 31 candidate-pair records, both ledgers opened eight trades and each made
  -$24.80 on that identical subset. Five Luna-vetoed control entries made a
  combined +$23.50. Three primary-only entries made -$55.30; the control was
  independently blocked, so these are **not** simultaneous matched trades.
- Four of the primary's eleven exits are assumed take-profit fills, including
  one user-approved retrospective fill. These are not broker-confirmed executions.
- AI/data cost is not recorded; economic profit is unknown.

### Frozen hypothesis and method

O-001 tests one exit change only: a 20% premium stop versus the configured 25%
stop, with the same entries and all other exit rules unchanged. The 20% level is
a risk-reduction hypothesis, **not** a tuned optimum. Reconstruct the first
post-entry option **bid** at or below 80% of entry ask from snapshots logged by
the paper position monitor. Require the quote timestamp to be after entry and
before the recorded exit and no more than three minutes old at the log cycle.
Alternative proceeds use that actual bid and the same $2.10 estimated round-trip
cost. If no earlier 20% trigger is observed, retain the recorded outcome. Treat
assumed-take-profit exits as censored when order relative to an earlier stop
cannot be verified; do not call them a 20%-stop win. Report coverage and results
for the primary and control separately. This is retrospective sensitivity on
selected positions, **not** an out-of-sample strategy backtest.

If the quote evidence is too incomplete or the comparison is adverse, do not
promote the stop. Regardless of this result, the next prospective decision test
should compare the existing Luna veto to a simple Python-qualified DAY control
on the same candidate and synchronized risk/capacity; the current independent
ledger cannot cleanly identify causal lift from Luna. No policy change without
user approval.

### O-001 result — retrospective, not promoted

The reproducible read-only calculation is `audit_stop20.ps1`. It finds a fresh
pre-exit bid snapshot at the 20% threshold for six of seven uncensored primary
trades and three of ten uncensored control trades. On those uncensored subsets,
the 20% rule changes net results from -$183.70 to -$148.70 (primary, +$35.00)
and from -$83.00 to -$63.00 (control, +$20.00). Four primary and three control
trades are censored because their exits used assumed take-profit fills; the
relative order of a hypothetical earlier stop and those assumed fills is not
established. Quote snapshots are sampled roughly every two minutes, so fills
between polls are also unknown. The complete ledger P&L is still -$80.10 and
-$1.30; the subset sensitivity must **not** replace it. Decision: retain 20%
only as a prospective hypothesis, with no config or stop-policy change.

### Data limitation

The project stores live bid/ask snapshots while paper positions are open, not a
complete historical option quote tape across all SPY/QQQ strikes and times.
Robinhood's historical option endpoint provides OHLC, not historical bid/ask.
Thus these records permit narrow exit counterfactuals but cannot validate new
entry signals, fill queues, or a long historical options strategy. TradingView
ETF-share backtests are a separate proxy and must not be labeled options P&L.

## 2026-09-19 — Batch O-002, frozen before entry-spread analysis

Hypothesis: on Python-qualified SPY/QQQ DAY contracts, a final entry bid/ask
spread no greater than **5% of midpoint** may improve net expectancy relative
to the currently permitted 10% maximum by avoiding expensive contracts. This
is one predeclared filter, not a search over thresholds. Preserve the recorded
entry/exit fill policy, costs, 25% stop, 30% target, eligibility, and risk
limits. Compare the 5%-eligible and >5% groups separately within the primary
and deterministic DAY-control ledgers; do **not** simulate a new capital path
by summing a selected subset. Include trade count, net result, and a
closed-trade-equity drawdown diagnostic. Join each PAPER_ENTRY to its same-cycle
open-position snapshot using paper_id; calculate `(ask-bid)/midpoint*100` from
the final refreshed bid/ask. Reject missing, stale, or mismatched snapshots.

This is a retrospective, selected-trade screen on seven observed market days,
not an out-of-sample test. A spread filter that looks good here would need a
prospective shadow comparison before any core-policy change. Assumed take-
profit fills and unmeasured AI/data cost remain unresolved.

Pre-result timestamp repair: the first entry's same-cycle `position` quote is
timestamped 0.36 seconds *after* its PAPER_ENTRY event, while the separately
recorded `fill_quote_snapshot_as_of` precedes the event by 0.004 seconds.
Therefore the position bid/ask is a near-entry spread proxy, not provably the
exact fill quote. Require the fill snapshot to precede the entry by at most
three minutes, the position quote to be within two seconds after entry or
three minutes before it, and the position ask to equal the recorded fill ask.
Any entry failing this check is excluded/reported, not silently treated as
having an exact spread.

### O-002 result — no effect, rejected as an improvement

`audit_spread5.ps1` matched every closed entry to its same-cycle position
snapshot and exit: 11 primary, 13 control. Near-entry spreads ranged from
0.62% to 1.39% of midpoint. All 24 trades satisfied 5%, so this stricter
filter would reject **zero** recorded fills and leave the observed -$80.10
primary and -$1.30 control net P&L unchanged. Four primary and three control
exits remain assumed TP outcomes. The script's subset closed-trade drawdown
diagnostic is not the ledger's mark-to-market drawdown; use the ledger values
($109.05 primary, $104.30 control) for risk reporting. No policy change.

## 2026-09-19 — Batch O-003, frozen before delta analysis

Hypothesis: the small-account selector may be buying low-delta contracts that
need more underlying movement to overcome decay. Compare a simple **entry
absolute delta >=0.30** rule with the existing 0.20 DAY minimum, retaining
the same symbol, entry, stop, target, costs, and all other gates. Read delta
from the actual paper entry position's saved `entry_greeks`, not a later quote.
Report the count and net result of the >=0.30 and <0.30 groups separately
for both ledgers, plus entry premium distribution and the currently effective
planned-loss premium ceiling. This is a retrospective selected-trade screen,
not a re-run of contract discovery or a new capital path. If few or no actual
trades meet the rule, report insufficient data and do not relax or retune the
threshold. It cannot establish an option edge without prospective/OOS data.

### O-003 result — no testable higher-delta group

`audit_delta30.ps1` matched all 24 entry positions to their saved entry
Greeks. Every fill had absolute delta below 0.30: 11 primary trades, entry
premiums $77–$163 (mean $110.36), and 13 control trades, premiums $80–$147
(mean $115.23). Thus the predeclared >=0.30 rule would have rejected all
observed fills. There is **zero** outcome evidence for a higher-delta strategy;
do not describe an all-cash counterfactual as superior performance. The
observed fill set cannot tell us whether higher-delta contracts were available
and affordable at those timestamps without auditing the separate retained
discovery shortlists. All primary fills were DAY, so the primary/control difference is
model selection and separate-ledger capacity, not realized SWING exposure.

At the persisted flat balances, the next flat day's planned-loss budget alone
would cap primary premium near $136.05 and control premium near $171.60 before
tick rounding, other gates, or daily losses. This makes higher-delta SPY/QQQ
contracts potentially hard to afford, but their exact historical quotes are
not yet established from the entry snapshots alone. Decision: no delta-gate
change. Do not add a model call just to collect this comparison.

## 2026-09-19 — Batch O-004, frozen before shortlist feasibility audit

The run logs retain `result.event.option_discovery.contract_discovery` and a
smaller final `qualified_candidates` list. Audit every market-day opportunity
cycle in the paper period. Deduplicate by observation timestamp, symbol,
contract ID, and quote timestamp. Count the final affordable DAY-qualified
shortlist, its absolute-delta distribution, and how often any >=0.30 contract
coexisted with a selected <0.30 entry on the same cycle. Compare its ask with
the recorded effective premium limit and current spread/liquidity/Greek gates.
This is an **availability** audit only: unselected contracts have no subsequent
bid/ask path or realized P&L, so no performance counterfactual will be claimed.

### O-004 result — shortlist cannot answer affordability completely

`audit_shortlist_delta30.ps1` found 101 opportunity cycles with a nonempty
final shortlist. After quote freshness, current DAY eligibility, spread,
volume/OI, and recorded discovery premium-limit checks, 141 deduplicated
candidate observations remained. Their absolute deltas ranged 0.200–0.284
(mean 0.232); none reached 0.30. The 16 cycles with an actual low-delta
paper entry had zero same-symbol/type >=0.30 alternatives **in that saved
shortlist**. This is availability evidence, not P&L evidence.

The code audit limits the inference: `news_option_discovery.py` sorts all
premium-passing contracts by spread, then takes at most one per
symbol/type/style group. In these 101 cycles, funnel totals report 257
premium-passing contracts but only 142 pre-routing shortlisted contracts;
46 cycles had more premium-passing contracts than shortlist slots. Individual
quotes/Greeks for the discarded, premium-passing contracts are not retained
in the logs. Higher-delta affordability is therefore still **unresolved**,
not disproved. Next, capture a compact highest-delta affordable DAY contract
per symbol/type before diversification, without changing selection or using
an extra model call. Future observations only; no historical outcomes will
be imputed.

### Prospective O-004 data-capture repair

`tools/news_option_discovery.py` now adds `day_delta_audit` to the discovery
result, before symbol/type/style shortlist diversification. It records one
highest-absolute-delta contract quote and the eligible-contract count per
symbol/type after the existing tradability and effective-premium gates. The
record includes contract identity, expiration, strike, bid/ask, delta,
volume/OI, and quote timestamp. Selection order, the shortlist, model-call
count, risk checks, and paper/live order behavior are unchanged. This will
resolve *future* availability questions only; it supplies no subsequent quote
path or historical P&L for the unselected contract. A two-contract regression
fixture proves the better-spread low-delta contract stays shortlisted while
the excluded high-delta quote is retained in the audit. Sixteen relevant
discovery/runner tests and focused Ruff checks passed. The full suite was
also run: 264 passed, eight failed. One failure expects the old ten-minute
scan cadence although current `CONFIG.md` says five; the other seven are in
older production-config/calendar paper integration tests. Those tests do not
validate this new audit field and were not edited here. In particular, the
macro-calendar/entry-path failures remain unresolved, so the whole suite is
not green. No scheduled task or trading cycle was run to create an
observation.

## 2026-10-01 — Read-only forward-ledger audit

Snapshot 19:58 UTC: primary 19 closed / -$141.90 / DD $168.75; independent
DAY control 26 closed / -$14.60 / DD $138.85. No open paper positions.
Of 57 paired observations, 24 have closed control trades: 14 true both-ledger
executions aggregate -$52.40 each, ten control-only PASS/WATCH rows +$18.00.
Matched difference -$18.00 is capacity/timing/risk-confounded, not causal lift.
Six primary and seven control assumed-target fills remain unconfirmed; AI/data
expense is missing. No positive option strategy or third candidate promoted.
Full reconciliation: AUDIT_2026-10-01.md; current LEADERBOARD.md updated.
No trade, scheduler, policy or retrospective paper outcome changed.
