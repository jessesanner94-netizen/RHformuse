# Read-only shortlist availability audit for Batch O-004 in EXPERIMENT_LOG.md.
# Run: pwsh -NoProfile -File research/options/audit_shortlist_delta30.ps1
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$seen = [System.Collections.Generic.HashSet[string]]::new()
$observations = [System.Collections.Generic.List[object]]::new()
$entryCycles = [System.Collections.Generic.List[object]]::new()
$cyclesWithShortlist = 0

foreach ($logFile in (Get-ChildItem (Join-Path $projectRoot 'state/logs/2026-09-*.jsonl'))) {
    foreach ($line in (Get-Content -LiteralPath $logFile.FullName)) {
        $record = $line | ConvertFrom-Json -DateKind String
        if ($record.cycle -ne 'opportunities') { continue }
        $discovery = $record.result.event.option_discovery
        if (-not $discovery) { continue }
        $candidates = @($discovery.qualified_candidates | Where-Object { $null -ne $_ })
        if ($candidates.Count -eq 0) { continue }
        $cyclesWithShortlist++
        $limit = [double]$discovery.contract_discovery.premium_limit
        $cycleAt = [datetimeoffset]::Parse([string]$record.timestamp)
        $valid = [System.Collections.Generic.List[object]]::new()
        foreach ($candidate in $candidates) {
            if (@($candidate.entry_eligible_trade_styles) -notcontains 'DAY') { continue }
            if ($candidate.quote_is_fresh -ne $true -or $candidate.setup_qualified -ne $true) { continue }
            $quoteAt = [datetimeoffset]::Parse([string]$candidate.quote_updated_at)
            $age = ($cycleAt - $quoteAt).TotalSeconds
            if ($age -lt 0 -or $age -gt 180) { continue }
            $bid = [double]$candidate.bid
            $ask = [double]$candidate.ask
            $premium = 100 * $ask
            $spread = 100 * ($ask - $bid) / (($ask + $bid) / 2)
            if ($bid -le 0 -or $ask -lt $bid -or $premium -gt $limit + 0.000001) { continue }
            if ($spread -gt 10 -or [double]$candidate.option_volume -lt 100 -or [double]$candidate.option_open_interest -lt 500) { continue }
            $delta = [math]::Abs([double]$candidate.delta)
            if ($delta -lt 0.20 -or $delta -gt 0.80) { continue }
            $item = [pscustomobject]@{
                cycle_at = [string]$record.timestamp
                date = $cycleAt.ToString('yyyy-MM-dd')
                candidate_id = [string]$candidate.candidate_id
                symbol = [string]$candidate.symbol
                option_type = [string]$candidate.option_type
                expiration = [string]$candidate.expiration
                quote_at = [string]$candidate.quote_updated_at
                abs_delta = $delta
                premium = $premium
                spread_percent = $spread
                premium_limit = $limit
            }
            $valid.Add($item)
            $key = "$($item.cycle_at)|$($item.symbol)|$($item.candidate_id)|$($item.quote_at)"
            if ($seen.Add($key)) { $observations.Add($item) }
        }

        $selected = if ($record.result.paper_decision.opened -eq $true) {
            $record.result.paper_decision.position
        } elseif ($record.result.baseline_decision.opened -eq $true) {
            $record.result.baseline_decision.position
        } else { $null }
        if ($selected -and [double]$selected.entry_greeks.abs_delta -lt 0.30) {
            $sameDirection = @($valid | Where-Object {
                $_.symbol -eq $selected.symbol -and $_.option_type -eq $selected.option_type -and
                $_.candidate_id -ne $selected.contract_identifier -and $_.abs_delta -ge 0.30
            })
            $sameExpiry = @($sameDirection | Where-Object { $_.expiration -eq $selected.expiration })
            $entryCycles.Add([pscustomobject]@{
                date = $cycleAt.ToString('yyyy-MM-dd')
                selected_symbol = $selected.symbol
                selected_type = $selected.option_type
                selected_delta = [math]::Round([double]$selected.entry_greeks.abs_delta, 3)
                shortlisted = $valid.Count
                higher_delta_any_symbol = @($valid | Where-Object abs_delta -ge 0.30).Count
                higher_delta_same_direction = $sameDirection.Count
                higher_delta_same_expiry = $sameExpiry.Count
                cheapest_same_direction_premium = if ($sameDirection.Count) { [math]::Round(($sameDirection | Measure-Object premium -Minimum).Minimum, 2) } else { $null }
                discovery_premium_limit = $limit
            })
        }
    }
}

"Opportunity cycles with nonempty final shortlist: $cyclesWithShortlist"
"Deduplicated fresh affordable DAY observations: $($observations.Count)"
$high = @($observations | Where-Object abs_delta -ge 0.30)
"Observations with absolute delta >=0.30: $($high.Count)"
if ($observations.Count) {
    $d = $observations | Measure-Object abs_delta -Minimum -Maximum -Average
    "Delta distribution (min/mean/max): $([math]::Round($d.Minimum, 3)) / $([math]::Round($d.Average, 3)) / $([math]::Round($d.Maximum, 3))"
}
"Low-delta actual-entry cycles: $($entryCycles.Count)"
"Cycles with same-symbol/type affordable >=0.30 alternative: $(@($entryCycles | Where-Object higher_delta_same_direction -gt 0).Count)"
"Cycles with same-expiry affordable >=0.30 alternative: $(@($entryCycles | Where-Object higher_delta_same_expiry -gt 0).Count)"
$entryCycles | Format-Table -AutoSize
if ($high.Count) {
    "Higher-delta shortlisted observations (first 20):"
    $high | Select-Object -First 20 date, symbol, option_type, expiration, abs_delta, premium, spread_percent, premium_limit |
        Format-Table -AutoSize
}
