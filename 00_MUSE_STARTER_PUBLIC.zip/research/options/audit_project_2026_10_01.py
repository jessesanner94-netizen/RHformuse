"""Read historical project evidence; write a separate audit JSON, never runtime state.

Usage: .venv/Scripts/python.exe research/options/audit_project_2026_10_01.py
All SQLite connections are explicitly read-only. No network, model or trading calls.
"""

from __future__ import annotations

import collections
import hashlib
import json
import sqlite3
import statistics
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[2]
EASTERN = ZoneInfo("America/New_York")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_rows(path):
    return [
        json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()
    ]


def date_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def day(value):
    return date_time(value).astimezone(EASTERN).date().isoformat()


def stats(trades):
    pnls = [x["pnl"] for x in trades]
    wins, losses = [x for x in pnls if x > 0], [x for x in pnls if x < 0]
    return {
        "count": len(pnls),
        "net": round(sum(pnls), 2),
        "win_count": len(wins),
        "win_rate": len(wins) / len(pnls) if pnls else None,
        "expectancy": round(statistics.mean(pnls), 4) if pnls else None,
        "average_win": round(statistics.mean(wins), 4) if wins else None,
        "average_loss": round(statistics.mean(losses), 4) if losses else None,
        "profit_factor": sum(wins) / -sum(losses) if losses else None,
    }


def replay(rows, cutoff=None):
    """Latch on retained realized net > 0; keep management of existing positions."""
    kept, skipped, stopped = set(), [], set()
    actual, retained = collections.defaultdict(float), collections.defaultdict(float)
    latches = {}
    for row in sorted(rows, key=lambda x: date_time(x["timestamp"])):
        d, kind = day(row["timestamp"]), row.get("event")
        if cutoff and d < cutoff:
            continue
        if kind == "PAPER_ENTRY":
            if d in stopped:
                skipped.append(row["paper_id"])
            else:
                kept.add(row["paper_id"])
        elif kind == "PAPER_EXIT":
            actual[d] += row["realized_pnl"]
            if row["paper_id"] in kept:
                retained[d] += row["realized_pnl"]
                if retained[d] > 0:
                    stopped.add(d)
                    latches.setdefault(d, row["timestamp"])
    return {
        "actual": round(sum(actual.values()), 2),
        "replay": round(sum(retained.values()), 2),
        "improvement": round(sum(retained.values()) - sum(actual.values()), 2),
        "kept_count": len(kept),
        "skipped_count": len(skipped),
        "skipped_ids": skipped,
        "latches": latches,
        "daily": {
            d: {"actual": round(actual[d], 2), "replay": round(retained[d], 2)}
            for d in sorted(actual)
        },
        "method": (
            "Fixed recorded trades/costs; no substitute trades, resizing, "
            "or capital/risk-path resimulation."
        ),
    }


def error_category(decision):
    value = str(decision.get("error", "")) + str(decision.get("reason", ""))
    if "not supported" in value or ("gpt-6-luna" in value and "ChatGPT" in value):
        return "model_auth_compatibility"
    if "invalid_json_schema" in value:
        return "provider_schema"
    if "timed out" in value.lower() or "timeout" in value.lower():
        return "timeout"
    if "validation" in value.lower() or "schema" in value.lower():
        return "validation_or_schema"
    return "other_or_unspecified"


def main():
    report = {
        "scope": (
            "Historical audit, paper performance through October 1, 2026; "
            "no operational mutation."
        )
    }
    ledgers, events, observations, entry_snapshots = {}, {}, {}, {}
    for name in ("paper", "paper_baseline"):
        p = ROOT / "state" / name
        state, rows = read_json(p / "PORTFOLIO.json"), read_rows(p / "EVENTS.jsonl")
        if day(state["updated_at"]) > "2026-10-01":
            raise ValueError("This dated audit requires option portfolios through October 1.")
        entries = {x["paper_id"]: x for x in rows if x.get("event") == "PAPER_ENTRY"}
        exits = [x for x in rows if x.get("event") == "PAPER_EXIT"]
        assert len(entries) == len([x for x in rows if x.get("event") == "PAPER_ENTRY"])
        assert len({x["paper_id"] for x in exits}) == len(exits) == state["closed_trade_count"]
        trades = []
        for x in exits:
            e = entries[x["paper_id"]]
            trade = {
                "id": x["paper_id"],
                "entry_at": e["timestamp"],
                "exit_at": x["timestamp"],
                "date": day(e["timestamp"]),
                "symbol": e["symbol"],
                "direction": e["option_type"],
                "premium": round(e["fill_price"] * 100, 2),
                "entry_price": e["fill_price"],
                "exit_price": x["fill_price"],
                "pnl": x["realized_pnl"],
                "reason": x["exit_reason"],
                "assumed": "ASSUMED" in x["exit_reason"] or x.get("fill_assumed") is True,
                "style": e["trade_style"],
                "confidence": (e.get("decision") or {}).get("confidence"),
                "hold_minutes": (
                    date_time(x["timestamp"]) - date_time(e["timestamp"])
                ).total_seconds()
                / 60,
            }
            trades.append(trade)
        assert round(sum(x["pnl"] for x in trades), 2) == state["realized_pnl"]
        assert round(state["starting_cash"] + state["realized_pnl"] - state["cash"], 2) == 0
        ledgers[name] = {
            "stats": stats(trades),
            "equity": state["equity"],
            "max_drawdown": state["max_drawdown_dollars"],
            "estimated_execution_costs": state["estimated_execution_costs"],
            "open_count": len(state["open_positions"]),
            "before_estimated_execution_costs": round(
                state["realized_pnl"] + state["estimated_execution_costs"], 2
            ),
            "assumed": stats([x for x in trades if x["assumed"]]),
            "unassumed": stats([x for x in trades if not x["assumed"]]),
            "by_symbol_direction": {
                f"{s}_{t}": stats([x for x in trades if x["symbol"] == s and x["direction"] == t])
                for s, t in sorted({(x["symbol"], x["direction"]) for x in trades})
            },
            "by_policy_period": {
                label: stats([x for x in trades if lo <= x["date"] <= hi])
                for label, lo, hi in [
                    ("pre_JEV", "2026-09-08", "2026-09-18"),
                    ("JEV_DAY_only_transition", "2026-09-22", "2026-09-23"),
                    ("winner_trial", "2026-09-24", "2026-09-24"),
                    ("post_trial", "2026-09-25", "2026-10-01"),
                ]
            },
            "stop_after_green": replay(rows),
            "stop_after_green_since_Sept24": replay(rows, "2026-09-24"),
            "trades": trades,
            "effective_next_flat_day_premium_ceiling": round(
                (min(45, state["equity"] * 0.125) - 2.10) / 0.25, 2
            ),
        }
        events[name] = rows
        observations[name] = collections.defaultdict(list)
        entry_snapshots[name] = {}

    daily = {}
    totals, final_actions, decision_status, errors = (collections.Counter() for _ in range(4))
    source_manifest, delta_audit, model_rows = [], [], []
    for path in sorted((ROOT / "state/logs").glob("????-??-??.jsonl")):
        if path.stem > "2026-10-01":
            continue
        data = path.read_bytes()
        source_manifest.append(
            {
                "path": str(path.relative_to(ROOT)),
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        )
        counter, rejects, statuses = (
            collections.Counter(),
            collections.Counter(),
            collections.Counter(),
        )
        malformed = 0
        first, last = None, None
        for line in data.decode("utf-8").splitlines():
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                malformed += 1
                continue
            first = first or row.get("timestamp")
            last = row.get("timestamp")
            result, cycle = row.get("result") or {}, row.get("cycle", "unknown")
            counter[cycle + "_rows"] += 1
            statuses[str(result.get("status", "structured"))] += 1
            funnel = result.get("funnel") or {}
            if cycle == "opportunities":
                for k, v in funnel.items():
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        counter[k] += v
                rejects.update(funnel.get("rejections") or {})
            routing = result.get("routing") or {}
            dec = routing.get("decision") or {}
            packet = routing.get("decision_packet") or {}
            if dec.get("codex_invoked") is True:
                status = dec.get("status", "UNKNOWN")
                decision_status[status] += 1
                counter["logged_final_model_calls"] += 1
                counter["reported_final_tokens"] += int(dec.get("reported_tokens") or 0)
                verdict = routing.get("decision_verdict") or {}
                if not verdict and dec.get("output"):
                    try:
                        verdict = json.loads(dec["output"])
                    except (json.JSONDecodeError, TypeError):
                        verdict = {}
                action = verdict.get("action", "UNPARSED")
                if status == "COMPLETED":
                    final_actions[action] += 1
                else:
                    errors[error_category(dec)] += 1
                model_rows.append(
                    {
                        "at": row.get("timestamp"),
                        "status": status,
                        "action": action,
                        "model": dec.get("model"),
                        "tokens": dec.get("reported_tokens"),
                        "candidate_id": (packet.get("candidate") or {}).get("candidate_id"),
                    }
                )
            discovery = ((result.get("event") or {}).get("option_discovery") or {}).get(
                "contract_discovery"
            ) or {}
            for item in discovery.get("day_delta_audit") or []:
                quote = item.get("highest_delta_quote") or {}
                if quote:
                    delta_audit.append(
                        {
                            "at": row.get("timestamp"),
                            "symbol": item.get("symbol"),
                            "direction": item.get("option_type"),
                            **quote,
                        }
                    )
            for name, keys in [
                ("paper", ("paper", "paper_decision")),
                ("paper_baseline", ("baseline", "baseline_decision")),
            ]:
                for key in keys:
                    section = result.get(key) or {}
                    positions = list(section.get("open_positions") or [])
                    if isinstance(section.get("position"), dict):
                        positions.append(section["position"])
                    for pos in positions:
                        pid = pos.get("paper_id")
                        if not pid:
                            continue
                        if "entry_greeks" in pos:
                            entry_snapshots[name].setdefault(pid, pos)
                        qt = pos.get("last_quote_at")
                        try:
                            age = (date_time(row["timestamp"]) - date_time(qt)).total_seconds()
                            if (
                                key in ("paper", "baseline")
                                and 0 <= age <= 180
                                and pos.get("last_bid") is not None
                            ):
                                observations[name][pid].append(
                                    (date_time(qt), float(pos["last_bid"]))
                                )
                        except (ValueError, TypeError, KeyError):
                            pass
        daily[path.stem] = {
            "counts": dict(counter),
            "rejections": dict(rejects),
            "statuses": dict(statuses),
            "malformed_lines": malformed,
            "first_at": first,
            "last_at": last,
        }
        totals.update(counter)
        totals["malformed_lines"] += malformed

    for name, ledger in ledgers.items():
        stops, censored, uncensored = [], [], []
        deltas, theta, spreads, cover = [], [], [], 0
        for trade in ledger["trades"]:
            pos = entry_snapshots[name].get(trade["id"])
            if pos:
                cover += 1
                greeks = pos.get("entry_greeks") or {}
                if greeks.get("delta") is not None:
                    deltas.append(abs(float(greeks["delta"])))
                if greeks.get("theta_percent_of_premium_per_day") is not None:
                    theta.append(float(greeks["theta_percent_of_premium_per_day"]))
                bid, ask = pos.get("last_bid"), pos.get("last_ask")
                if bid is not None and ask and abs(float(ask) - trade["entry_price"]) < 0.00001:
                    spreads.append(
                        (float(ask) - float(bid)) / ((float(ask) + float(bid)) / 2) * 100
                    )
            if trade["reason"] == "STOP_LOSS":
                planned = trade["premium"] * 0.25 + 2.10
                stops.append(
                    {
                        "id": trade["id"],
                        "planned_loss": round(planned, 2),
                        "actual_loss": -trade["pnl"],
                        "overshoot": round(-trade["pnl"] - planned, 2),
                        "net_loss_percent": round(-trade["pnl"] / trade["premium"] * 100, 2),
                    }
                )
            if trade["assumed"]:
                censored.append(trade["id"])
                continue
            quotes = sorted(set(observations[name].get(trade["id"], [])))
            eligible = [
                (at, bid)
                for at, bid in quotes
                if date_time(trade["entry_at"]) < at < date_time(trade["exit_at"])
            ]
            first20 = next(
                ((at, bid) for at, bid in eligible if bid <= trade["entry_price"] * 0.80), None
            )
            alt = (
                round((first20[1] - trade["entry_price"]) * 100 - 2.10, 2)
                if first20
                else trade["pnl"]
            )
            uncensored.append(
                {
                    "id": trade["id"],
                    "pnl": trade["pnl"],
                    "alternative": alt,
                    "quotes": len(eligible),
                    "earlier_stop20_observed": bool(first20),
                    "first_trigger_at": first20[0].isoformat() if first20 else None,
                }
            )
        ledger["entry_evidence"] = {
            "matched": cover,
            "delta_min": min(deltas) if deltas else None,
            "delta_max": max(deltas) if deltas else None,
            "delta_at_least_030": sum(d >= 0.30 for d in deltas),
            "theta_mean": statistics.mean(theta) if theta else None,
            "spread_proxy_count": len(spreads),
            "spread_proxy_max": max(spreads) if spreads else None,
        }
        ledger["stop_overshoot"] = {
            "rows": stops,
            "total": round(sum(x["overshoot"] for x in stops), 2),
        }
        ledger["stop20_sensitivity"] = {
            "censored_ids": censored,
            "uncensored_rows": uncensored,
            "actual_uncensored_net": round(sum(x["pnl"] for x in uncensored), 2),
            "alternative_uncensored_net": round(sum(x["alternative"] for x in uncensored), 2),
            "method": (
                "First valid observed pre-exit bid <= 80% of ask; "
                "actual sampled bid, $2.10 costs. Assumed TP exits censored."
            ),
        }
    report["options"] = ledgers
    report["logs"] = {
        "file_count": len(source_manifest),
        "totals": dict(totals),
        "daily": daily,
        "final_decision_status": dict(decision_status),
        "final_actions": dict(final_actions),
        "final_failures": dict(errors),
        "model_rows": model_rows,
        "source_manifest": source_manifest,
        "day_delta_audit": {
            "rows": len(delta_audit),
            "delta_at_least_030": sum(abs(x.get("delta") or 0) >= 0.3 for x in delta_audit),
            "max": max((abs(x.get("delta") or 0) for x in delta_audit), default=None),
        },
    }

    pairs = read_rows(ROOT / "state/evaluation/PAIRS.jsonl")
    exits = {
        name: {
            x["paper_id"]: x["realized_pnl"] for x in events[name] if x.get("event") == "PAPER_EXIT"
        }
        for name in events
    }
    matched, groups = [], collections.defaultdict(list)
    for p in pairs:
        b, a = p.get("baseline_paper_id"), p.get("primary_paper_id")
        if b not in exits["paper_baseline"] or (
            p["model_action"] == "BUY" and a not in exits["paper"]
        ):
            continue
        item = {
            "at": p["timestamp"],
            "action": p["model_action"],
            "primary_id": a,
            "baseline_id": b,
            "primary_pnl": exits["paper"].get(a, 0),
            "control_pnl": exits["paper_baseline"][b],
        }
        matched.append(item)
        groups[p["model_action"]].append(item)
    report["comparison"] = {
        "observations": len(pairs),
        "completed_control_rows": len(matched),
        "unique_primary_trades": len({x["primary_id"] for x in matched if x["primary_id"]}),
        "unique_control_trades": len({x["baseline_id"] for x in matched}),
        "by_action": {
            a: {
                "rows": len(v),
                "primary_net": round(sum(x["primary_pnl"] for x in v), 2),
                "control_net": round(sum(x["control_pnl"] for x in v), 2),
            }
            for a, v in groups.items()
        },
        "rows": matched,
    }
    databases = {}
    for path in sorted((ROOT / "state/research").glob("*.sqlite3")):
        con = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        tables = [
            x[0]
            for x in con.execute(
                "select name from sqlite_master where type='table' and name not like 'sqlite_%'"
            )
        ]
        databases[path.name] = {
            "integrity": con.execute("pragma quick_check").fetchone()[0],
            "tables": {
                t: con.execute('select count(*) from "' + t + '"').fetchone()[0] for t in tables
            },
        }
        if path.name == "crypto_paper.sqlite3":
            account = json.loads(con.execute("select body from account").fetchone()[0])
            trades = [
                {"at": at, "kind": kind, "body": json.loads(body)}
                for at, kind, body in con.execute(
                    "select at,kind,body from events "
                    "where kind in ('paper_entry','paper_exit') order by id"
                )
            ]
            report["crypto"] = {
                "account": account,
                "trade_events": trades,
                "realized_closed_net": sum(
                    x["body"]["net_pnl"] for x in trades if x["kind"] == "paper_exit"
                ),
                "last_observation_at": con.execute("select max(at) from events").fetchone()[0],
                "event_counts": dict(con.execute("select kind,count(*) from events group by kind")),
            }
        if path.name == "jev.sqlite3":
            report["jev"] = {
                "observations": databases[path.name]["tables"]["observations"],
                "attached_outcomes": databases[path.name]["tables"]["outcomes"],
                "latest_observation": con.execute("select max(as_of) from observations").fetchone()[
                    0
                ],
            }
        if path.name == "watches.sqlite3":
            report["watches"] = {
                "statuses": dict(
                    con.execute("select status,count(*) from watches group by status")
                ),
                "terminal_reasons": dict(
                    con.execute(
                        "select coalesce(terminal_reason,'none'),count(*) "
                        "from watches group by terminal_reason"
                    )
                ),
            }
        con.close()
    report["sqlite"] = databases
    research = read_json(ROOT / "research/tradingview/leaderboard.json")
    report["proxy_research"] = {
        "candidates": len(research["candidates"]),
        "status_counts": dict(collections.Counter(x.get("status") for x in research["candidates"])),
        "priorities": research.get("top_three_research_priorities"),
        "validated_winners": research.get("top_three_are_validated_winners"),
    }
    report["cost_ledger_exists"] = (ROOT / "state/evaluation/COSTS.jsonl").exists()
    report["ledger_source_hashes"] = {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in [
            ROOT / "CONFIG.md",
            ROOT / "state/paper/PORTFOLIO.json",
            ROOT / "state/paper/EVENTS.jsonl",
            ROOT / "state/paper_baseline/PORTFOLIO.json",
            ROOT / "state/paper_baseline/EVENTS.jsonl",
            ROOT / "state/evaluation/PAIRS.jsonl",
        ]
    }
    out = ROOT / "docs/PROJECT_AUDIT_2026-10-01.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    brief = {
        "options": {
            n: {
                k: v
                for k, v in ledger.items()
                if k in ("stats", "entry_evidence", "equity", "max_drawdown")
            }
            for n, ledger in ledgers.items()
        },
        "logs": {
            k: v
            for k, v in report["logs"].items()
            if k not in ("daily", "model_rows", "source_manifest")
        },
        "comparison": {k: v for k, v in report["comparison"].items() if k != "rows"},
        "crypto": {
            k: v for k, v in report["crypto"].items() if k not in ("account", "trade_events")
        },
        "jev": report["jev"],
        "watches": report["watches"],
        "proxy_research": report["proxy_research"],
    }
    print(json.dumps(brief, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
