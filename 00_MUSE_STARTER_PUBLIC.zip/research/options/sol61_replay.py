"""Isolated historical decision replay; no trading imports or production writes."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import tempfile
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import suppress
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from jsonschema import Draft202012Validator, ValidationError

MODEL = "gpt-6.1-sol"
EFFORT = "high"  # Same effort as the historical Luna calls; change only the model.
EASTERN = ZoneInfo("America/New_York")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def read_rows(path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8-sig").splitlines() if x]


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def collect(root, start, end):
    """Only exact logged packets go to the model. Outcomes stay in a separate file."""
    items, sources, days, seen = [], {}, [], set()
    outcomes = {}
    for ledger in ("paper_baseline", "paper"):
        path = root / "state" / ledger / "EVENTS.jsonl"
        sources[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
        events = read_rows(path)
        entries = {x["paper_id"]: x for x in events if x.get("event") == "PAPER_ENTRY"}
        for exit_event in events:
            if exit_event.get("event") != "PAPER_EXIT":
                continue
            entry = entries.get(exit_event["paper_id"])
            if entry:
                outcomes[(ledger, entry["paper_id"])] = {
                    "ledger": ledger,
                    "entry": entry,
                    "exit": exit_event,
                }
    for path in sorted((root / "state/logs").glob("2026-*.jsonl")):
        if not start <= path.stem <= end:
            continue
        days.append(path.stem)
        sources[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
        for line_number, row in enumerate(read_rows(path), 1):
            result = row.get("result") or {}
            route = result.get("routing") or {}
            packet = route.get("decision_packet")
            decision = route.get("decision") or {}
            if (
                not packet
                or not packet.get("candidate")
                or not decision.get("codex_invoked")
                or decision.get("cached")
            ):
                continue
            key = digest(packet)
            if key in seen:
                continue
            seen.add(key)
            historical = None
            if decision.get("status") == "COMPLETED":
                historical = json.loads(decision["output"])
            matches = {}
            for ledger, field in (
                ("paper_baseline", "baseline_decision"),
                ("paper", "paper_decision"),
            ):
                entry_result = result.get(field) or {}
                paper_id = (entry_result.get("position") or {}).get("paper_id")
                match = outcomes.get((ledger, paper_id))
                if match:
                    # Never match by ticker/contract alone: repeated reviews have different fills.
                    if match["entry"]["contract_identifier"] != packet["candidate"]["candidate_id"]:
                        raise ValueError("outcome contract mismatch")
                    matches[ledger] = match
            items.append(
                {
                    "id": key,
                    "packet": packet,
                    "source": f"{path.relative_to(root)}:{line_number}",
                    "historical_action": (historical or {}).get("action", "ERROR"),
                    "historical_model": decision.get("model"),
                    "historical_status": decision.get("status"),
                    "jev_ranked": bool(route.get("jev_evaluations")),
                    "outcomes": matches,
                }
            )
    return items, {
        "start": start,
        "end": end,
        "log_days": days,
        "sources": sources,
        "packet_count": len(items),
        "jev_ranked_packets": sum(x["jev_ranked"] for x in items),
        "historical_actions": dict(Counter(x["historical_action"] for x in items)),
        "historical_models": dict(Counter(x["historical_model"] for x in items)),
        "control_outcome_count": sum("paper_baseline" in x["outcomes"] for x in items),
        "either_outcome_count": sum(bool(x["outcomes"]) for x in items),
    }


def model_prompt(packet, policy, instructions):
    return (
        policy + "\n\n" + instructions + "\n\n"
        "Historical research replay. Treat packet.as_of as the current time. Use only this "
        "packet. Do not use remembered later events. No tools or outside research. Do not "
        "invent missing fields or outcomes. Preserve supplied historical gates/exits. "
        "Your recommendation will never execute an order. Return only the schema JSON.\n\n"
        + json.dumps({"wake_decision": True, "decision_packet": packet}, sort_keys=True)
    )


def replay_one(item, output, policies, executable):
    record_path = output / "decisions" / (item["id"] + ".json")
    if record_path.exists():
        record = json.loads(record_path.read_text())
        if record["packet_hash"] != item["id"] or record["model"] != MODEL:
            raise ValueError("incompatible saved decision")
        return record
    watch = "watch_observations" in item["packet"]
    policy, instructions, schema = policies[watch]
    prompt = model_prompt(item["packet"], policy, instructions)
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="Sol61PacketReplay-") as directory:
        workspace = Path(directory)
        schema_path = workspace / "decision.schema.json"
        write_json(schema_path, schema)
        command = [
            executable,
            "exec",
            "--ignore-user-config",
            "--ephemeral",
            "--skip-git-repo-check",
            "--model",
            MODEL,
            "--sandbox",
            "read-only",
            "--cd",
            str(workspace),
            "--output-schema",
            str(schema_path),
            "--json",
            "-c",
            f'model_reasoning_effort="{EFFORT}"',
            "-c",
            'web_search="disabled"',
        ]
        for feature in (
            "shell_tool",
            "unified_exec",
            "multi_agent",
            "apps",
            "plugins",
            "hooks",
            "browser_use",
            "computer_use",
            "image_generation",
            "skill_search",
            "memories",
        ):
            command.extend(["--disable", feature])
        command.append("-")
        completed = subprocess.run(
            command,
            input=prompt,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=240,
            check=False,
        )
    events = []
    for line in completed.stdout.splitlines():
        with suppress(ValueError):
            events.append(json.loads(line))
    messages = [
        x["item"]["text"]
        for x in events
        if x.get("type") == "item.completed" and x.get("item", {}).get("type") == "agent_message"
    ]
    tool_events = [
        x
        for x in events
        if x.get("type") == "item.completed"
        and x.get("item", {}).get("type") not in {"agent_message", "reasoning"}
    ]
    usage = next(
        (x.get("usage") for x in reversed(events) if x.get("type") == "turn.completed"), None
    )
    verdict, error = None, None
    try:
        if completed.returncode or tool_events:
            raise ValueError("CLI failure or unexpected tool use")
        verdict = json.loads(messages[-1])
        Draft202012Validator(schema).validate(verdict)
        if verdict["candidate_id"] != item["packet"]["candidate"]["candidate_id"]:
            raise ValueError("candidate ID mismatch")
        if verdict["action"] not in {"BUY", "PASS", "WAIT", "WATCH"}:
            raise ValueError("unsupported entry verdict")
        if (
            verdict["action"] != "PASS"
            and verdict["trade_style"] not in item["packet"]["candidate"]["eligible_styles"]
        ):
            raise ValueError("ineligible trade style")
    except (ValueError, IndexError, ValidationError) as exc:
        error = str(exc)[:1000]
    record = {
        "packet_hash": item["id"],
        "model": MODEL,
        "reasoning_effort": EFFORT,
        "prompt_hash": hashlib.sha256(prompt.encode()).hexdigest(),
        "prompt_characters": len(prompt),
        "status": "ERROR" if error else "COMPLETED",
        "decision": verdict,
        "error": error,
        "usage": usage,
        "duration_seconds": round(time.monotonic() - started, 2),
        "cli_returncode": completed.returncode,
        "unexpected_tool_events": tool_events,
        "stderr_tail": completed.stderr[-1800:] if error else None,
        "cli_errors": [x for x in events if x.get("type") in {"error", "turn.failed"}],
    }
    write_json(record_path, record)
    return record


def select_fixed_outcomes(trades, green_lock=False):
    """Selection sensitivity only. Exits commit before a same-time new entry."""
    events = []
    for index, trade in enumerate(trades):
        for kind in ("entry", "exit"):
            events.append(
                (
                    datetime.fromisoformat(trade[kind]["timestamp"]),
                    1 if kind == "entry" else 0,
                    index,
                    kind,
                )
            )
    accepted, rejected, pnl, locked = set(), set(), Counter(), set()
    for at, _, index, kind in sorted(events):
        day = at.astimezone(EASTERN).date().isoformat()
        if kind == "entry":
            (rejected if green_lock and day in locked else accepted).add(index)
        elif index in accepted:
            pnl[day] += round(trades[index]["exit"]["realized_pnl"] * 100)
            if pnl[day] > 0:
                locked.add(day)
    selected = [trades[i] for i in accepted]
    selected.sort(key=lambda t: t["exit"]["timestamp"])
    values = [round(t["exit"]["realized_pnl"] * 100) for t in selected]
    equity = peak = drawdown = 0
    for value in values:
        equity += value
        peak = max(peak, equity)
        drawdown = max(drawdown, peak - equity)
    return {
        "trades": len(values),
        "wins": sum(x > 0 for x in values),
        "losses": sum(x < 0 for x in values),
        "net_pnl_dollars": sum(values) / 100,
        "closed_trade_drawdown_dollars": drawdown / 100,
        "green_lock_skipped": len(rejected),
        "paper_ids": [t["entry"]["paper_id"] for t in selected],
    }


def summarize(items, decisions):
    valid = {x["packet_hash"]: x for x in decisions if x["status"] == "COMPLETED"}
    groups, action_counts, matrix = {}, Counter(), Counter()
    for item in items:
        replay = valid.get(item["id"])
        if replay:
            action = replay["decision"]["action"]
            action_counts[action] += 1
            matrix[f"{item['historical_action']}->{action}"] += 1
    for scope in ("control_only", "either_ledger", "jev_control_only") if valid else ():
        eligible = [
            x
            for x in items
            if x["id"] in valid
            and (
                bool(x["outcomes"])
                if scope == "either_ledger"
                else "paper_baseline" in x["outcomes"]
                and (scope != "jev_control_only" or x.get("jev_ranked", False))
            )
        ]
        for method in ("python_control", "historical_luna", "sol61"):
            trades = []
            for item in eligible:
                action = (
                    valid[item["id"]]["decision"]["action"]
                    if method == "sol61"
                    else item["historical_action"]
                )
                if method != "python_control" and action != "BUY":
                    continue
                trades.append(item["outcomes"].get("paper_baseline") or item["outcomes"]["paper"])
            groups[f"{scope}:{method}"] = select_fixed_outcomes(trades)
            groups[f"{scope}:{method}:green"] = select_fixed_outcomes(trades, True)
    usage = Counter()
    for result in decisions:
        usage.update(result.get("usage") or {})
    # Standard API equivalent ONLY, never a measured Codex credit/dollar charge.
    input_tokens = usage["input_tokens"] - usage["cached_input_tokens"]
    api_equivalent = (
        input_tokens * 2 + usage["cached_input_tokens"] * 0.1 + usage["output_tokens"] * 10
    ) / 1_000_000
    return {
        "completed": len(valid),
        "attempts_saved": len(decisions),
        "actions": dict(action_counts),
        "action_matrix": dict(matrix),
        "comparisons": groups,
        "usage": dict(usage),
        "standard_api_equivalent_dollars": round(api_equivalent, 4) if usage else None,
        "measured_codex_dollar_cost": None,
        "sol_buy_without_recorded_outcome": sum(
            x["id"] in valid and not x["outcomes"] and valid[x["id"]]["decision"]["action"] == "BUY"
            for x in items
        ),
    }


def validated_app_decisions(output, items):
    """Never silently promote wrong-contract/style or invalid WATCH outputs."""
    decisions = []
    for item in items:
        path = output / "app_decisions" / (item["id"] + ".json")
        if not path.exists():
            continue
        record = json.loads(path.read_text(encoding="utf-8"))
        if record["model"] != MODEL or record["packet_hash"] != item["id"]:
            raise ValueError("app model or packet identity mismatch")
        if record["status"] == "COMPLETED":
            watch = "watch_observations" in item["packet"]
            policy = json.loads((output / f"policy_{watch}.json").read_text())
            verdict = record["decision"]
            try:
                Draft202012Validator(policy["schema"]).validate(verdict)
                if verdict["candidate_id"] != item["packet"]["candidate"]["candidate_id"]:
                    raise ValueError("candidate mismatch")
                if verdict["action"] not in {"BUY", "PASS", "WATCH", "WAIT"}:
                    raise ValueError("unsupported action")
                eligible_styles = item["packet"]["candidate"]["eligible_styles"]
                if verdict["action"] != "PASS" and verdict["trade_style"] not in eligible_styles:
                    raise ValueError("ineligible style")
                if verdict["action"] in {"WATCH", "WAIT"} and verdict.get("watch_conditions"):
                    conditions = verdict["watch_conditions"]
                    if not conditions["wake_all"]:
                        raise ValueError("empty watch wake")
                    observations = item["packet"].get("watch_observations", {})
                    for condition in conditions["wake_all"] + conditions["invalidate_any"]:
                        if condition["field"] not in observations:
                            raise ValueError("unavailable watch observation")
                    limit = item["packet"].get("watch_limits", {}).get("latest_expires_at")
                    if limit and datetime.fromisoformat(
                        conditions["expires_at"]
                    ) > datetime.fromisoformat(limit):
                        raise ValueError("watch exceeds supplied limit")
            except (ValueError, ValidationError) as exc:
                record = record | {"status": "ERROR", "validation_error": str(exc)[:1000]}
        decisions.append(record)
    return decisions


def write_report(output, items, manifest, report, decisions):
    valid = {x["packet_hash"]: x for x in decisions if x["status"] == "COMPLETED"}
    fields = [
        "as_of",
        "symbol",
        "option_type",
        "strike",
        "candidate_id",
        "historical_action",
        "sol_action",
        "jev_ranked",
        "outcome_ledger",
        "recorded_net_pnl",
        "sol_reason",
    ]
    with (output / "decisions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for item in items:
            candidate = item["packet"]["candidate"]
            verdict = (valid.get(item["id"]) or {}).get("decision") or {}
            outcome = item["outcomes"].get("paper_baseline") or item["outcomes"].get("paper")
            writer.writerow(
                {
                    "as_of": item["packet"]["as_of"],
                    **{
                        k: candidate[k] for k in ("symbol", "option_type", "strike", "candidate_id")
                    },
                    "historical_action": item["historical_action"],
                    "sol_action": verdict.get("action"),
                    "jev_ranked": item["jev_ranked"],
                    "outcome_ledger": outcome["ledger"] if outcome else "UNKNOWN",
                    "recorded_net_pnl": outcome["exit"]["realized_pnl"] if outcome else "",
                    "sol_reason": verdict.get("reason", ""),
                }
            )
    lines = [
        "# Sol 6.1 historical options replay — October 9, 2026",
        "",
        f"Coverage: {manifest['start']} through {manifest['end']} inclusive; "
        f"{report['completed']}/{manifest['packet_count']} valid Sol decisions.",
        "",
        "This is an isolated, frozen-packet, immediate-BUY selection experiment. "
        "It is not a complete counterfactual account backtest or a live-performance forecast.",
        "",
        f"There are {manifest['jev_ranked_packets']} packets with archived JEV evaluations. "
        "Earlier packets were Python-selected; no historical JEV result was invented. "
        "Luna originally returned 39 BUY, 21 PASS, 32 WATCH, one WAIT and four model errors. "
        "95 calls used gpt-5.6-luna and two used gpt-6-luna, all at high reasoning.",
        "",
        "Sol is exactly `gpt-6.1-sol`, also at high reasoning. Every packet has its own fresh "
        "app agent, without inherited conversation. It loads only its designated self-contained "
        "input, with instructions to use no further tools or trading actions. Original gates, "
        "quotes, costs and stop/target fields stay as logged. Outcomes and Luna's current verdict "
        "are separate from the input. Output validation never adjusts decisions to fit results.",
        "",
        "The currently saved compact review policy/schema was frozen for this experiment. "
        "Exact historical prompt versions and hidden model context were not archived; therefore "
        "this compares today's Sol under that frozen policy, not a byte-identical historical "
        "prompt swap. DAY-only and macro clauses apply only to supplied packet evidence. "
        "The archived 25% stop/30% target settings are preserved. The new October 8 net-R:R "
        "gate is not retroactively injected into earlier packets.",
        "",
        "## Results on the common DAY-control outcome set",
        "",
        "All methods below use the same recorded control fill and exit for each eligible review. "
        "Trading P&L already includes modeled execution costs. No cost is deducted twice.",
        "",
        "| Immediate-entry filter | Closed trades | Wins / losses | Net trading P&L | "
        "Closed-trade drawdown | Green-lock skips |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for method, label in (
        ("python_control", "Python control"),
        ("historical_luna", "Historical Luna BUYs"),
        ("sol61", "Sol 6.1 BUYs"),
    ):
        for green in (False, True):
            result = report["comparisons"].get(
                f"control_only:{method}" + (":green" if green else "")
            )
            if not result:
                continue
            name = label + (" + daily green lock" if green else "")
            lines.append(
                f"| {name} | {result['trades']} | {result['wins']} / {result['losses']} | "
                f"${result['net_pnl_dollars']:.2f} | "
                f"${result['closed_trade_drawdown_dollars']:.2f} | "
                f"{result['green_lock_skipped']} |"
            )
    lines += [
        "",
        "## JEV-era common control subset",
        "",
        "23 closed control outcomes have archived JEV evaluations. With the green filter:",
        "",
        "| Entry filter | Trades | Net trading P&L |",
        "|---|---:|---:|",
    ]
    for method, label in (
        ("python_control", "Python/JEV-era control"),
        ("historical_luna", "Historical Luna BUYs"),
        ("sol61", "Sol 6.1 BUYs"),
    ):
        subset = report["comparisons"].get(f"jev_control_only:{method}:green")
        if subset:
            lines.append(f"| {label} | {subset['trades']} | ${subset['net_pnl_dollars']:.2f} |")
    lines += [
        "",
        "## Coverage and interpretation",
        "",
        f"35/97 reviews have closed DAY-control outcomes; 44/97 have an outcome in either ledger. "
        f"Sol chose BUY on {report['sol_buy_without_recorded_outcome']} reviews without a recorded "
        "outcome. Those have no invented P&L. Nine primary-only outcomes form a secondary "
        "sensitivity analysis in `results.json`, using primary exits where no control exists; "
        "it is not the main common-exit comparison. A JEV-era-only control subset is also saved.",
        "",
        "There are no log files for September 14–15. Zero-candidate scans do not need model "
        "replay; only actual, uncached model handoffs are included. A contract reviewed repeatedly "
        "retains separate timestamps; outcome joins use the actual entry ID from that exact run.",
        "",
        "WATCH/WAIT means no immediate entry in the tables. A changed watch could wake differently "
        "and produce unlogged later opportunities, which are not simulated. Sol's different cash, "
        "loss budget, exposure, PASS cache, discovery, execution latency and watch state would "
        "also change future eligibility. Historical account gates reflect the original account. "
        "These selection results do not assert that all selected trades could coexist in an "
        "independent account under the normal risk limits.",
        "The shortlist-quote audit (`quote_coverage.json`) found no later same-day quote for "
        "15 of the 53 unscored reviews. Other reviews have at most 16 later shortlist samples, "
        "rather than complete original two-minute monitoring or minute-bar exit paths. "
        "These sparse samples cannot establish which stop/target happened first.",
        "",
        "The green sensitivity processes actual closed-trade timestamps in order, using net "
        "realized cents. The lock starts only above zero, is sticky for that Eastern day, and "
        "resets next day. An exit at the same timestamp precedes an entry. Positions already "
        "open remain open until their recorded normal exit. It changes only which recorded "
        "trades are retained; it does not rescan or recalculate a counterfactual risk budget.",
        "",
        "13 of the 35 control exits include historically assumed TP fills. Their existing "
        "paper assumptions are carried forward, not certified as executable fills. Drawdown "
        "above uses realized closed-trade P&L only and excludes intervening unrealized drawdown. "
        "One model run per packet does not measure decision variability or establish statistical "
        "significance. The period differs from the earlier 39.8% green replay, which included "
        "September 8; percentages are not conflated with that older result.",
        "",
        "## Isolation, cost and reproducibility",
        "",
        "The initial CLI pilot rejected this exact model for ChatGPT-account authentication. "
        "No replacement model was used and no further CLI calls were made. Requested reviews "
        "ran through isolated app agents instead. Per-call token/dollar charges are unavailable "
        "on that path; measured AI expense and economic profit are therefore unknown. Standard "
        "API prices are not treated as a measured Codex charge. Official model reference: "
        "[GPT-6.1 Sol](https://developers.openai.com/api/docs/models/gpt-6.1-sol).",
        "",
        f"Frozen source SHA-256 checks unchanged: **{report['source_hashes_unchanged']}**. "
        "The active route, live-execution flag, scheduled tasks and production ledgers were not "
        "changed by this research. Independent artifacts are confined to this research folder "
        "and the replay utility/tests.",
        "",
        "Regenerate the offline analysis without model calls: "
        "`.venv/Scripts/python.exe research/options/sol61_replay.py`. "
        "Inspect `decisions.csv` for every action/reason, `app_decisions/` for raw results, "
        "`inputs/` for the blinded inputs, `manifest.json` for source hashes, and `results.json` "
        "for machine-readable subgroup results. Six focused offline replay tests passed; "
        "Ruff passed. Production trading code was not modified.",
    ]
    if report["completed"] == manifest["packet_count"]:
        groups = report["comparisons"]
        sol = groups["control_only:sol61:green"]["net_pnl_dollars"]
        control = groups["control_only:python_control:green"]["net_pnl_dollars"]
        lines[4:4] = [
            f"Sol + daily green lock: **${sol:.2f}**, versus **${control:.2f}** for the "
            f"control + lock, a **${sol - control:.2f}** difference before unmeasured AI cost. "
            "This small matched-sample edge does not establish that adding Sol pays for itself.",
            "",
        ]
    (output / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--start", default="2026-09-09")
    parser.add_argument("--end", default="2026-10-08")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    output = root / "research/options/sol61_replay_20261009"
    output.mkdir(exist_ok=True)
    (output / "decisions").mkdir(exist_ok=True)
    if (output / "dataset.json").exists():
        items = json.loads((output / "dataset.json").read_text())
        manifest = json.loads((output / "manifest.json").read_text())
        if (args.start, args.end) != (manifest["start"], manifest["end"]):
            raise SystemExit("Date range differs from frozen research dataset")
    else:
        items, manifest = collect(root, args.start, args.end)
        write_json(output / "manifest.json", manifest)
        write_json(output / "dataset.json", items)
    policies = {}
    policy = (root / "prompts/DECISION_AGENT_AGENTS.md").read_text(encoding="utf-8")
    for watch in (False, True):
        prompt_name = "COMPACT_WATCH_DECISION.md" if watch else "COMPACT_DECISION.md"
        schema_name = (
            "watch_decision.transport.schema.json" if watch else "paper_decision.schema.json"
        )
        instructions = (root / "prompts" / prompt_name).read_text(encoding="utf-8")
        schema = json.loads((root / "prompts" / schema_name).read_text())
        policies[watch] = (policy, instructions, schema)
        policy_path = output / f"policy_{watch}.json"
        if not policy_path.exists():
            write_json(
                policy_path, {"policy": policy, "instructions": instructions, "schema": schema}
            )
    if args.execute:
        failed_pilot = output / "decisions" / (items[0]["id"] + ".json")
        if failed_pilot.exists() and "not supported" in failed_pilot.read_text():
            raise SystemExit(
                "CLI model access failed; no additional CLI calls. "
                "Analyze the isolated app-agent results without --execute."
            )
        executable = shutil.which("codex.cmd") or shutil.which("codex")
        if not executable:
            raise SystemExit("Codex CLI unavailable")
        subset = items[: args.limit] if args.limit else items
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [
                pool.submit(replay_one, item, output, policies, executable) for item in subset
            ]
            for n, future in enumerate(as_completed(futures), 1):
                result = future.result()
                print(
                    json.dumps(
                        {
                            "progress": n,
                            "total": len(subset),
                            "status": result["status"],
                            "id": result["packet_hash"][:10],
                            "action": (result["decision"] or {}).get("action"),
                            "seconds": result["duration_seconds"],
                            "usage": result["usage"],
                            "error": result["error"],
                            "cli_errors": result["cli_errors"],
                        }
                    ),
                    flush=True,
                )
    decisions = validated_app_decisions(output, items)
    if not decisions:
        decisions = [json.loads(p.read_text()) for p in (output / "decisions").glob("*.json")]
    report = summarize(items, decisions)
    report["source_hashes_unchanged"] = all(
        hashlib.sha256((root / p).read_bytes()).hexdigest() == value
        for p, value in manifest["sources"].items()
    )
    input_checks = []
    for item in items:
        watch = "watch_observations" in item["packet"]
        policy = json.loads((output / f"policy_{watch}.json").read_text())
        expected = model_prompt(item["packet"], policy["policy"], policy["instructions"])
        expected += "\n\nOutput schema:\n" + json.dumps(policy["schema"])
        path = output / "inputs" / (item["id"] + ".txt")
        input_checks.append(path.exists() and path.read_text(encoding="utf-8") == expected)
    report["all_model_inputs_match_frozen_blinded_packets"] = all(input_checks)
    protected_path = output / "protected_hashes.json"
    if protected_path.exists():
        protected = json.loads(protected_path.read_text())
        report["protected_production_files_unchanged"] = all(
            hashlib.sha256((root / name).read_bytes()).hexdigest() == value
            for name, value in protected.items()
        )
    write_json(output / "results.json", report)
    write_report(output, items, manifest, report, decisions)
    print(
        json.dumps(
            {"manifest": manifest | {"sources": "see manifest.json"}, "results": report}, indent=2
        )
    )


if __name__ == "__main__":
    main()
