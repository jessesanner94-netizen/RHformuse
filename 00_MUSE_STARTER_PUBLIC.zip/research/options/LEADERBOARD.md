# SPY/QQQ long-option research leaderboard — 2026-10-01

Paper only, snapshot through 19:58 UTC. No positive economic profit established.
These are independent option-paper ledgers, not TradingView ETF-share returns.

[account details redacted]
| ---: | --- | ---: | ---: | ---: | ---: | --- |
| 1 | Python-qualified DAY control | 26 | -$14.60 | $354.40 | $138.85 | Least-negative reference, not a profitable winner |
| 2 | Luna-selected primary | 19 | -$141.90 | $227.10 | $168.75 | Underperforming; not promoted |
| 3 | Unfilled | — | — | — | — | No third evidenced candidate |

Expectancy: control -$0.56, primary -$7.47 per trade. Returns: -3.96% and
-38.46%; profit factors 0.963 and 0.580. No open paper positions.

Of 57 candidate-pair observations, 24 have completed control exits: 14 actual
both-ledger executions totaled -$52.40 in each ledger; ten control-only
PASS/WATCH rows totaled +$18.00 control. Completed-row totals are model
-$52.40 and control -$34.40, difference -$18.00. These are not 24 two-sided
trades. Independent capacity/risk/timing paths confound causal conclusions.

Ask entries/bid exits include estimated trading costs. Six primary assumed
target exits (+$156.40) and seven control (+$196.30) are trade-through
assumptions, not confirmed executable queue fills. AI/data costs are missing.
All historical actual fills reviewed were DAY, despite the generated summary's
generic reference to SWING. No unselected-contract historical quote paths were
acquired, no option candidate promoted, and no scheduler/core-policy changed.

Sources: state/evaluation/{METRICS.json,PAIRS.jsonl,SUMMARY.md} and independent
state/paper and state/paper_baseline ledgers. September 19 studies remain in
EXPERIMENT_LOG.md. See AUDIT_2026-10-01.md for the current matching audit.
