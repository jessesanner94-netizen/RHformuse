# Read-only entry-delta analysis for Batch O-003 in EXPERIMENT_LOG.md.
# Run: pwsh -NoProfile -File research/options/audit_delta30.ps1
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$exitByLedger = @{ primary = @{}; control = @{} }
$eventPaths = @{
    primary = 'state/paper/EVENTS.jsonl'
    control = 'state/paper_baseline/EVENTS.jsonl'
}
foreach ($ledger in @('primary', 'control')) {
    foreach ($line in (Get-Content (Join-Path $projectRoot $eventPaths[$ledger]))) {
        $event = $line | ConvertFrom-Json -DateKind String
        if ($event.event -eq 'PAPER_EXIT') { $exitByLedger[$ledger][$event.paper_id] = $event }
    }
}

$rows = [System.Collections.Generic.List[object]]::new()
foreach ($logFile in (Get-ChildItem (Join-Path $projectRoot 'state/logs/2026-09-*.jsonl'))) {
    foreach ($line in (Get-Content -LiteralPath $logFile.FullName)) {
        $record = $line | ConvertFrom-Json -DateKind String
        foreach ($ledger in @('primary', 'control')) {
            $decision = if ($ledger -eq 'primary') { $record.result.paper_decision } else { $record.result.baseline_decision }
            if (-not $decision -or $decision.opened -ne $true -or $decision.event.event -ne 'PAPER_ENTRY') { continue }
            $entry = $decision.event
            $position = $decision.position
            if (-not $position -or $position.paper_id -ne $entry.paper_id -or $position.contract_identifier -ne $entry.contract_identifier) {
                throw "Entry/position mismatch: $ledger $($entry.paper_id)"
            }
            if ($entry.symbol -notin @('SPY', 'QQQ') -or $entry.trade_style -ne 'DAY') {
                throw "Unexpected entry universe/style: $ledger $($entry.paper_id)"
            }
            $delta = [double]$position.entry_greeks.abs_delta
            if ($delta -lt 0.20 -or $delta -gt 0.80) { throw "Invalid DAY delta: $ledger $($entry.paper_id): $delta" }
            $exit = $exitByLedger[$ledger][$entry.paper_id]
            if (-not $exit) { throw "Missing exit: $ledger $($entry.paper_id)" }
            $rows.Add([pscustomobject]@{
                ledger = $ledger
                paper_id = $entry.paper_id
                date = ([datetimeoffset]::Parse([string]$entry.timestamp)).ToString('yyyy-MM-dd')
                symbol = $entry.symbol
                option_type = $entry.option_type
                premium_dollars = [math]::Round(100 * [double]$entry.fill_price, 2)
                abs_delta = [math]::Round($delta, 6)
                group = if ($delta -ge 0.30) { 'AT_LEAST_030' } else { 'BELOW_030' }
                realized_pnl = [double]$exit.realized_pnl
                assumed_tp = $exit.exit_reason -match 'ASSUMED|USER_APPROVED'
            })
        }
    }
}

foreach ($ledger in @('primary', 'control')) {
    $expected = $exitByLedger[$ledger].Count
    $actual = @($rows | Where-Object ledger -eq $ledger).Count
    if ($actual -ne $expected) { throw "Missing or duplicate entries: $ledger expected $expected found $actual" }
}

$rows | Sort-Object ledger, date, paper_id |
    Format-Table ledger, date, symbol, option_type, premium_dollars, abs_delta, group, realized_pnl, assumed_tp -AutoSize

foreach ($ledger in @('primary', 'control')) {
    foreach ($groupName in @('AT_LEAST_030', 'BELOW_030')) {
        $group = @($rows | Where-Object { $_.ledger -eq $ledger -and $_.group -eq $groupName })
        $premium = $group | Measure-Object premium_dollars -Minimum -Maximum -Average
        $pnl = ($group | Measure-Object realized_pnl -Sum).Sum
        [pscustomobject]@{
            ledger = $ledger
            delta_group = $groupName
            trades = $group.Count
            net_pnl = [math]::Round($pnl, 2)
            net_per_trade = if ($group.Count) { [math]::Round($pnl / $group.Count, 2) } else { $null }
            min_premium = if ($group.Count) { $premium.Minimum } else { $null }
            avg_premium = if ($group.Count) { [math]::Round($premium.Average, 2) } else { $null }
            max_premium = if ($group.Count) { $premium.Maximum } else { $null }
            assumed_tp_trades = @($group | Where-Object assumed_tp).Count
        } | Format-List
    }
}

$config = @{}
foreach ($line in (Get-Content (Join-Path $projectRoot 'CONFIG.md'))) {
    if ($line -match '^([A-Z][A-Z0-9_]+):\s*([0-9.]+)\s*$') { $config[$Matches[1]] = [double]$Matches[2] }
}
foreach ($ledger in @('primary', 'control')) {
    $portfolioPath = if ($ledger -eq 'primary') { 'state/paper/PORTFOLIO.json' } else { 'state/paper_baseline/PORTFOLIO.json' }
    $portfolio = Get-Content (Join-Path $projectRoot $portfolioPath) -Raw | ConvertFrom-Json
    $dailyBudget = [math]::Min($config.MAX_DAILY_LOSS_DOLLARS, $portfolio.equity * $config.MAX_DAILY_LOSS_PERCENT / 100)
    $premiumCeiling = ($dailyBudget - $config.ENTRY_EXIT_COST_BUFFER_DOLLARS) / ($config.STOP_LOSS_PERCENT / 100)
    [pscustomobject]@{
        ledger = $ledger
        current_flat_equity = $portfolio.equity
        next_flat_day_planned_loss_budget = [math]::Round($dailyBudget, 2)
        next_flat_day_premium_ceiling_before_tick_rounding = [math]::Round($premiumCeiling, 2)
    } | Format-List
}
