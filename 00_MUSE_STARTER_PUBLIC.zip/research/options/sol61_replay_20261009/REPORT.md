# Sol 6.1 historical options replay — October 9, 2026

Coverage: 2026-09-09 through 2026-10-08 inclusive; 97/97 valid Sol decisions.

Sol + daily green lock: **$191.70**, versus **$187.10** for the control + lock, a **$4.60** difference before unmeasured AI cost. This small matched-sample edge does not establish that adding Sol pays for itself.

This is an isolated, frozen-packet, immediate-BUY selection experiment. It is not a complete counterfactual account backtest or a live-performance forecast.

There are 69 packets with archived JEV evaluations. Earlier packets were Python-selected; no historical JEV result was invented. Luna originally returned 39 BUY, 21 PASS, 32 WATCH, one WAIT and four model errors. 95 calls used gpt-5.6-luna and two used gpt-6-luna, all at high reasoning.

Sol is exactly `gpt-6.1-sol`, also at high reasoning. Every packet has its own fresh app agent, without inherited conversation. It loads only its designated self-contained input, with instructions to use no further tools or trading actions. Original gates, quotes, costs and stop/target fields stay as logged. Outcomes and Luna's current verdict are separate from the input. Output validation never adjusts decisions to fit results.

The currently saved compact review policy/schema was frozen for this experiment. Exact historical prompt versions and hidden model context were not archived; therefore this compares today's Sol under that frozen policy, not a byte-identical historical prompt swap. DAY-only and macro clauses apply only to supplied packet evidence. The archived 25% stop/30% target settings are preserved. The new October 8 net-R:R gate is not retroactively injected into earlier packets.

## Results on the common DAY-control outcome set

All methods below use the same recorded control fill and exit for each eligible review. Trading P&L already includes modeled execution costs. No cost is deducted twice.

| Immediate-entry filter | Closed trades | Wins / losses | Net trading P&L | Closed-trade drawdown | Green-lock skips |
|---|---:|---:|---:|---:|---:|
| Python control | 35 | 20 / 15 | $110.50 | $138.10 | 0 |
| Python control + daily green lock | 19 | 13 / 6 | $187.10 | $76.20 | 16 |
| Historical Luna BUYs | 20 | 12 / 8 | $58.00 | $110.30 | 0 |
| Historical Luna BUYs + daily green lock | 14 | 10 / 4 | $134.60 | $76.20 | 6 |
| Sol 6.1 BUYs | 23 | 14 / 9 | $140.70 | $110.30 | 0 |
| Sol 6.1 BUYs + daily green lock | 13 | 10 / 3 | $191.70 | $76.20 | 10 |

## JEV-era common control subset

23 closed control outcomes have archived JEV evaluations. With the green filter:

| Entry filter | Trades | Net trading P&L |
|---|---:|---:|
| Python/JEV-era control | 13 | $62.70 |
| Historical Luna BUYs | 9 | $67.10 |
| Sol 6.1 BUYs | 10 | $83.00 |

## Coverage and interpretation

35/97 reviews have closed DAY-control outcomes; 44/97 have an outcome in either ledger. Sol chose BUY on 23 reviews without a recorded outcome. Those have no invented P&L. Nine primary-only outcomes form a secondary sensitivity analysis in `results.json`, using primary exits where no control exists; it is not the main common-exit comparison. A JEV-era-only control subset is also saved.

There are no log files for September 14–15. Zero-candidate scans do not need model replay; only actual, uncached model handoffs are included. A contract reviewed repeatedly retains separate timestamps; outcome joins use the actual entry ID from that exact run.

WATCH/WAIT means no immediate entry in the tables. A changed watch could wake differently and produce unlogged later opportunities, which are not simulated. Sol's different cash, loss budget, exposure, PASS cache, discovery, execution latency and watch state would also change future eligibility. Historical account gates reflect the original account. These selection results do not assert that all selected trades could coexist in an independent account under the normal risk limits.
The shortlist-quote audit (`quote_coverage.json`) found no later same-day quote for 15 of the 53 unscored reviews. Other reviews have at most 16 later shortlist samples, rather than complete original two-minute monitoring or minute-bar exit paths. These sparse samples cannot establish which stop/target happened first.

The green sensitivity processes actual closed-trade timestamps in order, using net realized cents. The lock starts only above zero, is sticky for that Eastern day, and resets next day. An exit at the same timestamp precedes an entry. Positions already open remain open until their recorded normal exit. It changes only which recorded trades are retained; it does not rescan or recalculate a counterfactual risk budget.

13 of the 35 control exits include historically assumed TP fills. Their existing paper assumptions are carried forward, not certified as executable fills. Drawdown above uses realized closed-trade P&L only and excludes intervening unrealized drawdown. One model run per packet does not measure decision variability or establish statistical significance. The period differs from the earlier 39.8% green replay, which included September 8; percentages are not conflated with that older result.

## Isolation, cost and reproducibility

The initial CLI pilot rejected this exact model for ChatGPT-account authentication. No replacement model was used and no further CLI calls were made. Requested reviews ran through isolated app agents instead. Per-call token/dollar charges are unavailable on that path; measured AI expense and economic profit are therefore unknown. Standard API prices are not treated as a measured Codex charge. Official model reference: [GPT-6.1 Sol](https://developers.openai.com/api/docs/models/gpt-6.1-sol).

Frozen source SHA-256 checks unchanged: **True**. The active route, live-execution flag, scheduled tasks and production ledgers were not changed by this research. Independent artifacts are confined to this research folder and the replay utility/tests.

Regenerate the offline analysis without model calls: `.venv/Scripts/python.exe research/options/sol61_replay.py`. Inspect `decisions.csv` for every action/reason, `app_decisions/` for raw results, `inputs/` for the blinded inputs, `manifest.json` for source hashes, and `results.json` for machine-readable subgroup results. Six focused offline replay tests passed; Ruff passed. Production trading code was not modified.
