"""Point-in-time regime observations. Labels have no trading authority."""

from __future__ import annotations

from datetime import datetime, timedelta

from research.options_lab.event_tape import timestamp, validate
from tools.market_calendar import EASTERN, session_hours

POLICY = {
    "version": "observational-regime-v1",
    "mode": "LABEL_ONLY",
    "source": "yahoo",
    "venue": "CONSOLIDATED_UNVERIFIED",
    "lookback_returns": 20,
    "bar_seconds": 60,
    "max_bar_age_seconds": 120,
    "trend_efficiency_min": 0.55,
    "chop_efficiency_max": 0.30,
    "high_mean_true_range_bps": 10.0,
    "thresholds_validated": False,
    "scheduled_events_are_regime_inputs": False,
}


def classify(rows, symbol: str, as_of: datetime) -> dict:
    """Use the most recent 21 consecutive, completed, available session bars.

    Efficiency = absolute close displacement / sum of absolute close changes.
    Volatility = mean true range / previous close, in basis points, over 20 bars.
    Structure and volatility are separate axes: a volatile trend remains a trend.
    No retrospective whole-day label or unavailable candle revision is consumed.
    """
    result = {
        "as_of": as_of.isoformat(),
        "symbol": symbol,
        "policy_version": POLICY["version"],
        "status": "UNKNOWN",
        "structure": "UNKNOWN",
        "volatility": "UNKNOWN",
        "regime": "UNKNOWN",
        "direction": "UNKNOWN",
        "trading_effect": "NONE",
        "reason": "insufficient_completed_bars",
        "metrics": {},
    }
    if as_of.tzinfo is None:
        raise ValueError("classification time needs timezone")
    hours = session_hours(as_of.astimezone(EASTERN).date())
    if hours is None or not hours[0] <= as_of <= hours[1]:
        return {**result, "reason": "outside_regular_session"}
    bars = {}
    gaps = {}
    try:
        for row in rows:
            if (
                row.get("symbol") != symbol
                or row.get("source") != POLICY["source"]
                or row.get("venue") != POLICY["venue"]
            ):
                continue
            # Evidence with a later receipt or availability time is invisible.
            if any(timestamp(row[k]) > as_of for k in ("event_at", "received_at", "available_at")):
                continue
            if row.get("kind") not in {"bar", "gap"}:
                continue
            validate(row)
            payload = row["payload"]
            if row["kind"] == "gap":
                key = payload["gap_key"]
                if key not in gaps or timestamp(row["available_at"]) > timestamp(
                    gaps[key]["available_at"]
                ):
                    gaps[key] = row
                continue
            start, end = timestamp(payload["start_at"]), timestamp(payload["end_at"])
            if not hours[0] <= start < end <= min(hours[1], as_of):
                continue
            if end - start != timedelta(seconds=POLICY["bar_seconds"]):
                raise ValueError("requires one-minute bars")
            if start in bars and bars[start]["payload"] != payload:
                raise ValueError("ambiguous candle revision")
            bars[start] = row
    except (KeyError, ValueError, TypeError, OverflowError):
        return {**result, "reason": "invalid_or_conflicting_bar_evidence"}
    selected = [bars[k] for k in sorted(bars)][-(POLICY["lookback_returns"] + 1) :]
    if len(selected) <= POLICY["lookback_returns"]:
        return result
    ends = [timestamp(r["payload"]["end_at"]) for r in selected]
    if (as_of - ends[-1]).total_seconds() > POLICY["max_bar_age_seconds"]:
        return {**result, "reason": "stale_completed_bars"}
    if any(
        timestamp(r["payload"]["start_at"]) != prior
        for prior, r in zip(ends, selected[1:], strict=False)
    ):
        return {**result, "reason": "missing_minute_in_lookback"}
    # A recovered transport gap is acceptable only with actual candle coverage.
    if any(
        r["payload"].get("end_at") is None and timestamp(r["payload"]["start_at"]) <= as_of
        for r in gaps.values()
    ):
        return {**result, "reason": "open_feed_gap"}
    closes = [float(r["payload"]["close"]) for r in selected]
    changes = [b - a for a, b in zip(closes, closes[1:], strict=False)]
    path = sum(abs(v) for v in changes)
    efficiency = abs(closes[-1] - closes[0]) / path if path else 0.0
    true_ranges = [
        max(
            float(r["payload"]["high"]) - float(r["payload"]["low"]),
            abs(float(r["payload"]["high"]) - prior),
            abs(float(r["payload"]["low"]) - prior),
        )
        / prior
        * 10000
        for prior, r in zip(closes, selected[1:], strict=False)
    ]
    mean_range = sum(true_ranges) / len(true_ranges)
    structure = (
        "TREND"
        if efficiency >= POLICY["trend_efficiency_min"]
        else "CHOPPY"
        if efficiency <= POLICY["chop_efficiency_max"]
        else "MIXED"
    )
    volatility = "HIGH_VOLATILITY" if mean_range >= POLICY["high_mean_true_range_bps"] else "NORMAL"
    return {
        **result,
        "status": "OK",
        "reason": "completed_available_consecutive_session_bars",
        "structure": structure,
        "volatility": volatility,
        "regime": volatility if volatility == "HIGH_VOLATILITY" else structure,
        "direction": "UP"
        if closes[-1] > closes[0]
        else "DOWN"
        if closes[-1] < closes[0]
        else "FLAT",
        "window_start": selected[0]["payload"]["start_at"],
        "window_end": selected[-1]["payload"]["end_at"],
        "latest_available_at": max((r["available_at"] for r in selected), key=timestamp),
        "metrics": {
            "bars": len(selected),
            "efficiency": round(efficiency, 6),
            "mean_true_range_bps": round(mean_range, 6),
        },
    }
