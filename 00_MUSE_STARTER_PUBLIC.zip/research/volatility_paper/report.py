"""Descriptive forward results; no invented counterfactual trades or historical labels."""

from __future__ import annotations

import json
from collections import defaultdict

from research.options_lab.event_tape import timestamp
from tools.config import load_config
from tools.options_lab import ROOT, _write
from tools.options_strategy import ledger_directory


def records(path):
    if not path.exists():
        return []
    # Ignore an incomplete final append while another process is writing.
    lines = path.read_text().splitlines(keepends=True)
    return [json.loads(line) for line in lines if line.endswith("\n") and line.strip()]


def stats(trades):
    total = peak = drawdown = 0.0
    for trade in trades:
        total += trade["net_pnl"]
        peak = max(peak, total)
        drawdown = max(drawdown, peak - total)
    return {
        "trade_count": len(trades),
        "net_pnl": round(total, 2),
        "expectancy": round(total / len(trades), 2) if trades else None,
        "win_rate": sum(t["net_pnl"] > 0 for t in trades) / len(trades) if trades else None,
        "closed_trade_drawdown_dollars": round(drawdown, 2),
    }


def grouped(trades):
    result = {"overall": stats(trades)}
    for axis in ("regime", "structure", "volatility"):
        groups = defaultdict(list)
        for trade in trades:
            groups[trade["label"].get(axis, "UNKNOWN")].append(trade)
        result["by_entry_" + axis] = {label: stats(items) for label, items in groups.items()}
    return result


def live_reference(since, label_at):
    """Read existing live fill events only, with actual entry-time available labels."""
    config = load_config(ROOT / "CONFIG.md")
    path = ledger_directory(ROOT, config, "live") / "EVENTS.jsonl"
    pending, trades = {}, []
    for event in records(path):
        kind = event.get("event")
        if kind not in {"LIVE_ENTRY_FILLED", "LIVE_EXIT_FILLED"}:
            continue
        at = event.get("filled_at", event["timestamp"])
        symbol = event["symbol"]
        if kind == "LIVE_ENTRY_FILLED":
            pending[symbol] = event
        else:
            entry = pending.pop(symbol, None)
            if entry and timestamp(entry.get("filled_at", entry["timestamp"])) >= timestamp(since):
                entry_at = timestamp(entry.get("filled_at", entry["timestamp"]))
                trades.append(
                    {
                        "symbol": symbol,
                        "entry_at": entry_at.isoformat(),
                        "exit_at": at,
                        "net_pnl": float(event["realized_pnl"]),
                        "gross_pnl": event.get("gross_realized_pnl"),
                        "label": label_at(symbol, entry_at),
                    }
                )
    trades.sort(key=lambda t: timestamp(t["exit_at"]))
    return {
        "status": "OK" if path.exists() else "UNAVAILABLE",
        "source": str(path),
        **grouped(trades),
        "trades": trades,
    }


def metrics(directory, event_path, summary, *, label_at=None, since=None):
    labels = {row["paper_id"]: row["label"] for row in records(directory / "TRADE_REGIMES.jsonl")}
    trades = [
        {
            "paper_id": e["paper_id"],
            "symbol": e["symbol"],
            "exit_at": e["timestamp"],
            "net_pnl": float(e["realized_pnl"]),
            "exit_reason": e["exit_reason"],
            "label": labels.get(e["paper_id"], {"regime": "UNKNOWN"}),
        }
        for e in records(event_path)
        if e.get("event") == "PAPER_EXIT"
    ]
    trades.sort(key=lambda t: timestamp(t["exit_at"]))
    reference = {"status": "UNAVAILABLE"}
    if label_at and since:
        try:
            reference = live_reference(since, label_at)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            reference = {"status": "UNAVAILABLE", "error_type": type(exc).__name__}
    result = {
        "mode": "OBSERVATIONAL_FORWARD_COMPARISON",
        "paper": grouped(trades),
        "paper_account": summary,
        "paper_trades": trades,
        "unchanged_live_reference": reference,
        "incremental_ai_data_cost": None,
        "economic_profit": None,
        "limitations": [
            "Entry-time labels only; no whole-day hindsight or scheduled-event regime inputs.",
            "Small samples are descriptive and do not validate thresholds or an edge.",
            "Regime drawdown is closed-trade P&L; account drawdown includes sampled marks.",
            "Independent cash, quotes, discovery and live fills prevent causal paired inference.",
            "Live reference includes only positions entered after this experiment was created.",
            "Absent entry labels remain UNKNOWN; outcomes are never used to infer regimes.",
        ],
    }
    _write(directory / "METRICS.json", result)
    lines = [
        "# Second paper bot — live baseline, regime labels only",
        "",
        "Regimes do not change entries, size or exits. Net P&L includes modeled execution costs.",
        "",
        "| Entry regime | Trades | Net P&L | Expectancy | Win rate | Closed-trade drawdown |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for label, item in result["paper"]["by_entry_regime"].items():
        win = item["win_rate"]
        lines.append(
            f"| {label} | {item['trade_count']} | ${item['net_pnl']:.2f} | "
            f"${item['expectancy']:.2f} | {win:.1%} | "
            f"${item['closed_trade_drawdown_dollars']:.2f} |"
        )
    if not trades:
        lines.append("| No closed trades yet | 0 | $0.00 | — | — | $0.00 |")
    lines.extend(["", *result["limitations"]])
    (directory / "REPORT.md").write_text("\n".join(lines) + "\n")
    return result
