"""Second paper bot: frozen live baseline with observational regime labels."""
