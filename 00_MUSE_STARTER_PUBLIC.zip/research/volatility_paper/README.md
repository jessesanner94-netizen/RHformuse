# Second paper bot: live baseline with regime observations

Requested October 31, 2026. The user chose **label regimes first; preserve identical
entry rules**. This bot has one independent $369 simulated account. Its configuration,
positions, events, opportunity evidence, research budget, caches, owner lock and service
are separate from the live bot and the existing experimental paper bot. The existing
`research/options_lab/CURRENT.json` continues to identify the first paper bot.

The baseline freezes the current parsed live CONFIG and production Python source.
Only the existing lab's execution safety overrides differ: live execution/entries and
unattended live authority are false, paper mode is true, old comparison ledgers are
disabled, and final calendar checks read the separately refreshed local calendar.
The manifest records zero strategy-setting changes. Subsequent source changes block
entries pending a new frozen version; original protective exits keep running.

The original discovery, 5M/15M technical qualification, JEV ranking of at most three
contracts, exact contract/Greek/liquidity gates, event/calendar restrictions, fresh
quotes, cash checks, daily planned-loss budget, realized green lock and DAY deadlines
remain binding. One contract, 25% stop, 30% target, three entries/day, and the smaller
of $45 or 12.5% of start-of-day equity remain unchanged. The original paper engine
models ask entries/bid exits with $1.05 per side and retains the configured assumed
historical TP trade-through rule. This is simulated execution, not a forecast of
actual live fills. Gaps/outages can cause losses beyond the stop or daily allowance.

The first paper bot's RSI/book ranking, extra news/supply-demand vetoes, depth exits,
and next-session expiration exception are absent. No scaling, runner, trailing stop,
chop filter, volatility veto or reversal strategy is enabled. No live order adapter
or notification sender is called. No Codex/Luna decision calls are added. Ordinary
bounded JEV research remains enabled in this bot's independent budget; its requests
and unmeasured dollar costs are reported separately, not hidden as zero cost.

## Regime definition

`regime.classify(rows, symbol, as_of)` is a pure, offline-testable function using
21 consecutive completed one-minute regular-session bars (20 close changes).
Every event, receipt and availability timestamp must be at/before `as_of`; previous
sessions, uncompleted bars and later revisions cannot create a historical label.
The recorder reuses the existing Yahoo read-only OHLCV adapter, with provenance
`CONSOLIDATED_UNVERIFIED`. Collector and label failures cannot change a trade.

Structure uses efficiency: absolute close displacement divided by total absolute
close changes. At least 0.55 is TREND, at most 0.30 is CHOPPY, otherwise MIXED.
Volatility is a separate axis: mean true range divided by previous close over the
20 changes, in basis points. At least 10 bps is HIGH_VOLATILITY, otherwise NORMAL.
These initial heuristic thresholds are **unvalidated labels**, not optimized gates
or evidence of improved returns. A high-volatility trend retains both labels.
First-session warmup, fewer than 21 bars, missing minutes, conflicting/malformed
evidence, an open feed outage or a latest candle older than 120 seconds yields UNKNOWN.
With immediate bar delivery, the first possible session label is 09:51 Eastern.
Labels update intraday; no final whole-day label is backdated to earlier trades.

Scheduled economic events remain distinct opportunity evidence. Their original
entry blackouts still apply; event dates never enter the regime classifier.

## Operation and evaluation

The separate unit is `options-volatility-paper.service`. Capture begins 09:25 Eastern
on regular sessions from November 2. Original entry admission begins 09:50; opportunity
cycles align to five-minute boundaries plus 15 seconds. Held-contract monitoring
targets ten seconds; optional history checks run separately each minute. Outside
sessions it waits without market/model requests, retaining exits for any held position.
The calendar handles holidays, early closes and the November DST change.

```bash
.venv/bin/python -m research.volatility_paper.bot status --experiment \
  research/options_lab/experiments/volatility_labels_20261031
```

The experiment's `forward/STATUS.json`, `METRICS.json` and `REPORT.md` contain account
equity/drawdown and net P&L, expectancy, win rate and trade count by entry-time regime,
structure and volatility. `TRADE_REGIMES.jsonl` attaches labels without rewriting the
trading ledger. `REGIMES.jsonl` records timestamped context; `SESSION_TAPE.sqlite3`
preserves raw observations. Missing entry labels remain UNKNOWN. Regime-group drawdown
uses chronological closed P&L; overall account drawdown includes sampled open marks.

An unchanged live reference is read from local live fill events for positions entered
after this experiment's creation. It uses only bars available at each live entry time.
Different capital, discovery timing, cash locks and actual fills prevent interpreting
the comparison as a controlled paired test. The bot does not reallocate live cash,
import prior outcomes into its account, or reset the first paper account. Forward
sample size and data gaps must be reviewed before proposing any trading changes.
