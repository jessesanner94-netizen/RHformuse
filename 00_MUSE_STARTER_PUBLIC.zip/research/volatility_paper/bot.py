"""Independent live-baseline paper bot; regime labels never alter decisions.

Only read-only market adapters and simulated paper accounting are invoked. No live
executor, notification adapter, scaling, runner or first-paper-bot control is used.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import time
from datetime import UTC, date, datetime, timedelta
from functools import partial
from pathlib import Path

from research.options_lab.forward import ForwardExperiment
from research.options_lab.forward_feeds import ForwardFeeds
from research.volatility_paper.regime import POLICY, classify
from tools.decision_context import build_decision_packet
from tools.economic_calendar import economic_context, load_calendar
from tools.jev_pipeline import evaluate_candidate
from tools.market_calendar import EASTERN, entry_allowed, session_hours
from tools.market_intelligence import collect_market_intelligence
from tools.options_lab import ROOT, _hash, _write, init_experiment, load_experiment
from tools.options_strategy import entry_locked
from tools.paper_runner import apply_paper_decision
from tools.paper_trading import _append_event, _exclusive_lock, paper_summary
from tools.scheduled_cycle import (
    _discovery_premium_ceiling,
    _merge_option_discoveries,
    _paper_entry_capacity_reached,
    _route_compact_decision_impl,
    event_account,
)
from tools.vibe_snapshot import fetch_vibe_snapshot
from tools.watchlist_discovery import run_watchlist_option_discovery

HERE = Path(__file__).resolve().parent
DEPENDENCIES = (
    "research/options_lab/forward.py",
    "research/options_lab/forward_feeds.py",
    "research/options_lab/event_tape.py",
)


def research_hashes():
    paths = [*HERE.glob("*.py"), *(ROOT / p for p in DEPENDENCIES)]
    return {str(p.relative_to(ROOT)): _hash(p) for p in sorted(paths)}


def prepare(name: str, start: date) -> Path:
    experiment = init_experiment(name)
    directory = experiment / "forward"
    account = directory / "accounts" / "paper"
    account.mkdir(parents=True)
    shutil.copy2(experiment / "CONFIG.md", account / "CONFIG.md")
    metadata = {
        "schema_version": 1,
        "mode": "LIVE_BASELINE_PAPER_LABEL_ONLY",
        "start_date": start.isoformat(),
        "created_at": datetime.now(UTC).isoformat(),
        "accounts": ["paper"],
        "policy": POLICY,
        "starting_cash_source": "PAPER_STARTING_CASH",
        "features": {
            "regimes": "LABEL_ONLY",
            "strategy_changes": [],
            "scaling": False,
            "runners": False,
            "notifications": False,
        },
        "config_sha256": _hash(experiment / "CONFIG.md"),
        "research_code_sha256": research_hashes(),
        "orders_placed": 0,
    }
    for relative in metadata["research_code_sha256"]:
        target = experiment / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    _write(directory / "EXPERIMENT.json", metadata)
    manifest = json.loads((experiment / "MANIFEST.json").read_text())
    manifest.update(
        status="BASELINE_LABEL_PAPER_PREPARED",
        mode=metadata["mode"],
        forward_metadata_sha256=_hash(directory / "EXPERIMENT.json"),
    )
    _write(experiment / "MANIFEST.json", manifest)
    return experiment


class BaselinePaperBot(ForwardExperiment):
    """Reuse paper ledger, locks, quote management and history from the tested adapter.

    Override every research admission/exit hook: the original first paper bot's
    RSI, book ranking, depth/news exits and next-session expiry are absent here.
    """

    def guards(self):
        try:
            _, manifest = load_experiment(self.experiment)
            if self.metadata["mode"] != "LIVE_BASELINE_PAPER_LABEL_ONLY":
                raise ValueError("requires baseline label-only experiment")
            if self.policy != POLICY or research_hashes() != self.metadata["research_code_sha256"]:
                raise ValueError("research identity changed; prepare a new version")
            if manifest.get("strategy_setting_changes"):
                raise ValueError("baseline strategy settings must be identical")
            if manifest["forward_metadata_sha256"] != _hash(self.directory / "EXPERIMENT.json"):
                raise ValueError("frozen metadata changed")
            if _hash(self.roots["paper"] / "CONFIG.md") != self.metadata["config_sha256"]:
                raise ValueError("paper account config changed")
            for relative, digest in self.metadata["research_code_sha256"].items():
                if _hash(self.experiment / "source" / relative) != digest:
                    raise ValueError("archived research changed")
            return []
        except (OSError, ValueError, KeyError, TypeError) as exc:
            return [str(exc)]

    def review(self, *args, **kwargs):
        return {"status": "ALLOW", "news": {"status": "DISABLED"}, "zones": {"status": "DISABLED"}}

    def depth_review(self, *args, **kwargs):
        return {"status": "DISABLED", "action": "HOLD"}

    def regime(self, symbol, now):
        try:
            return classify(
                self.tape.observations(symbol, as_of=now, kinds=["bar", "gap"]), symbol, now
            )
        except Exception as exc:
            return {
                "as_of": now.isoformat(),
                "symbol": symbol,
                "status": "UNKNOWN",
                "regime": "UNKNOWN",
                "structure": "UNKNOWN",
                "volatility": "UNKNOWN",
                "reason": "regime_read_failure:" + type(exc).__name__,
                "trading_effect": "NONE",
            }

    async def market_context(self):
        now = self.clock()
        result = {
            "as_of": now.isoformat(),
            "mode": "LABEL_ONLY",
            "trading_effect": "NONE",
            "symbols": {s: self.regime(s, now) for s in self.config.watchlist_symbols()},
        }
        _append_event(self.directory / "REGIMES.jsonl", result)
        _write(self.directory / "MARKET_CONTEXT.json", result)
        self.context = result
        return {"status": "OK", "as_of": now.isoformat()}

    async def opportunities(self):
        now = self.clock()
        if errors := self.guards():
            return {"status": "BLOCKED", "reasons": errors}
        if now.astimezone(EASTERN).date() < date.fromisoformat(self.metadata["start_date"]):
            return {"status": "SKIPPED", "reason": "before_start_date"}
        # Existing positions are protected before any optional entry research.
        monitor = (await self.monitor())["paper"]["monitor"]
        if monitor.get("attention"):
            return {"status": "BLOCKED", "reason": "position_data_unavailable"}
        state = self.state("paper", now)
        account = {"portfolio": paper_summary(state), "open_positions": state["open_positions"]}
        if (
            entry_locked(state)
            or _paper_entry_capacity_reached(account, self.config)
            or state["day"]["new_positions"] >= self.config.get("MAX_NEW_POSITIONS_PER_DAY")
        ):
            return {"status": "SKIPPED", "reason": "paper_account_entry_risk_or_green_lock"}
        calendar = load_calendar(now, self.directory / "shared")
        _write(self.roots["paper"] / "state" / "economic_calendar.json", calendar)
        if not entry_allowed(now, self.config, "DAY"):
            return {"status": "SKIPPED", "reason": "original_session_or_calendar_gate"}
        macro = economic_context(now, self.config, project_root=self.roots["paper"])
        if not macro["entry_allowed"]:
            return {"status": "SKIPPED", "reason": macro["reason"]}
        discovery = await run_watchlist_option_discovery(
            self.config,
            state_path=self.directory / "shared" / "watchlist_seen.json",
            premium_ceiling=_discovery_premium_ceiling(
                event_account({}, account, self.config), self.config
            ),
            now=now,
            commit=True,
        )
        normalized = _merge_option_discoveries({}, discovery, config=self.config, now=self.clock())
        discovery.update(
            {k: normalized[k] for k in ("status", "wake_luna", "qualified_candidates")}
        )
        if not discovery["qualified_candidates"]:
            result = {
                "status": "SKIPPED",
                "reason": "zero_qualified_candidates",
                "as_of": self.clock().isoformat(),
                "discovery": discovery,
                "orders_placed": 0,
            }
            _append_event(self.directory / "OPPORTUNITIES.jsonl", result)
            return result
        technical_cache, jev_cache = {}, {}

        def technical(symbol, **kwargs):
            if symbol not in technical_cache:
                technical_cache[symbol] = fetch_vibe_snapshot(symbol, project_root=ROOT)
            return technical_cache[symbol]

        def jev(packet, config, **kwargs):
            key = packet["candidate"]["candidate_id"]
            if key not in jev_cache:
                if len(jev_cache) >= 3:
                    return {"status": "UNAVAILABLE", "reason": "three_contract_research_cap"}
                jev_cache[key] = evaluate_candidate(
                    packet,
                    config,
                    project_root=self.directory / "shared",
                    now=self.clock(),
                    book_summary=kwargs.get("book_summary"),
                    calls_remaining=0,
                )
            return jev_cache[key]

        books = {"status": "DISABLED", "summaries": {}}
        if self.config.get("ENABLE_LEVEL2") is True:
            from tools.orderbook import collect_orderbooks

            try:
                books = await asyncio.wait_for(
                    collect_orderbooks(
                        list(self.config.watchlist_symbols()),
                        self.directory / "shared" / "orderbook.sqlite3",
                    ),
                    20,
                )
            except Exception:
                books = {"status": "UNAVAILABLE", "summaries": {}}
        intelligence = collect_market_intelligence(
            self.config,
            runtime_dir=self.directory / "shared" / "runtime",
            commit=True,
        )
        event = {
            "option_discovery": discovery,
            "paper_portfolio": account,
            "market_intelligence": intelligence,
            "orderbooks": books,
        }
        routing = await _route_compact_decision_impl(
            event,
            config=self.config,
            project_root=self.roots["paper"],
            execute_models=True,
            packet_builder=partial(
                build_decision_packet,
                technical_fetcher=technical,
                uw_fetcher=lambda *args: {"status": "DISABLED"},
            ),
            jev_evaluator=jev,
        )
        routing.pop("_jev_pending", None)
        final_quotes, entry_labels = [], {}

        async def quotes(requests):
            if self.guards():
                return {"option_quotes": [], "status": "CONFIGURATION_CHANGED"}
            refresh = await asyncio.wait_for(self.quotes(requests), 8)
            if self.guards():
                return {"option_quotes": [], "status": "CONFIGURATION_CHANGED"}
            at = self.clock()
            for symbol in self.config.watchlist_symbols():
                entry_labels[symbol] = self.regime(symbol, at)
            final_quotes.append({"available_at": at.isoformat(), "refresh": refresh})
            return refresh

        entry = await apply_paper_decision(
            routing, event, self.config, project_root=self.roots["paper"], quote_fetcher=quotes
        )
        if entry.get("opened"):
            position = entry["position"]
            _append_event(
                self.directory / "TRADE_REGIMES.jsonl",
                {
                    "paper_id": position["paper_id"],
                    "entry_at": position["entry_at"],
                    "symbol": position["symbol"],
                    "label": entry_labels.get(position["symbol"], {"regime": "UNKNOWN"}),
                },
            )
        evidence = {
            "as_of": self.clock().isoformat(),
            "source": "FORWARD_OBSERVATIONS",
            "discovery": discovery,
            "technical": technical_cache,
            "jev": jev_cache,
            "orderbooks": books,
            "economic_calendar": calendar,
            "scheduled_events": macro,
            "final_quotes": final_quotes,
            "entry_regimes": entry_labels,
            "routing": routing,
            "entry": entry,
            "orders_placed": 0,
            "codex_calls": 0,
        }
        _append_event(self.directory / "OPPORTUNITIES.jsonl", evidence)
        return {"status": "OK", "as_of": evidence["as_of"], "jev_contracts": len(jev_cache)}

    def report(self):
        from research.volatility_paper.report import metrics

        now = self.clock()
        result = {
            "as_of": now.isoformat(),
            "mode": self.metadata["mode"],
            "start_date": self.metadata["start_date"],
            "health": self.health,
            "entry_blockers": self.guards(),
            "account": paper_summary(self.state("paper", now)),
            "regime_policy": POLICY,
            "features": self.metadata["features"],
            "orders_placed": 0,
            "incremental_ai_data_cost": None,
            "economic_profit": None,
            "limitations": [
                "Unvalidated observational labels; no strategy improvement claimed.",
                "Simulated ask/bid fills with configured costs; gaps can exceed stops.",
                "Independent paper cash and data timing can differ from live fills.",
            ],
        }
        _write(self.directory / "STATUS.json", result)
        metrics(
            self.directory,
            self.paths("paper")["event_log_path"],
            result["account"],
            label_at=self.regime,
            since=self.metadata["created_at"],
        )
        return result

    async def run(self):
        feeds = ForwardFeeds(self.tape, list(self.config.watchlist_symbols()))

        def active():
            now = self.clock()
            local = now.astimezone(EASTERN)
            hours = session_hours(local.date())
            return (
                local.date() >= date.fromisoformat(self.metadata["start_date"])
                and hours
                and hours[0] - timedelta(minutes=5) <= now <= hours[1] + timedelta(minutes=10)
            )

        async def loop(name, interval, action, *, worker=False):
            while True:
                started = time.monotonic()
                try:
                    held = name in {"monitor", "history"} and bool(
                        self.state("paper", self.clock())["open_positions"]
                    )
                    if name == "report" or active() or held:
                        value = (
                            await asyncio.to_thread(lambda: asyncio.run(action()))
                            if worker
                            else await action()
                        )
                        if isinstance(value, dict) and name != "monitor":
                            self.health[name] = {**value, "as_of": self.clock().isoformat()}
                    else:
                        self.health[name] = {"status": "WAITING_FOR_SESSION"}
                except Exception as exc:
                    self.health[name] = {
                        "status": "ERROR",
                        "error_type": type(exc).__name__,
                        "as_of": self.clock().isoformat(),
                    }
                    _append_event(
                        self.directory / "ERRORS.jsonl", {"task": name, **self.health[name]}
                    )
                self.health.setdefault(name, {})["cycle_seconds"] = round(
                    time.monotonic() - started, 3
                )
                delay = (
                    300 - ((self.clock().timestamp() - 15) % 300)
                    if name == "opportunities"
                    else max(1, interval - (time.monotonic() - started))
                )
                await asyncio.sleep(delay)

        async def report_action():
            await asyncio.to_thread(self.report)
            return {"status": "OK"}

        with _exclusive_lock(self.directory / "OWNER"):
            await asyncio.gather(
                loop("monitor", 10, self.monitor),
                loop("bars", 30, feeds.poll_context),
                loop("context", 60, self.market_context),
                loop("history", 60, self.refresh_history),
                loop("opportunities", 300, self.opportunities, worker=True),
                loop("report", 60, report_action),
            )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("prepare")
    init.add_argument("--name", required=True)
    init.add_argument("--start-date", type=date.fromisoformat, required=True)
    for mode in ("run", "status"):
        sub.add_parser(mode).add_argument("--experiment", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        print(prepare(args.name, args.start_date))
    else:
        bot = BaselinePaperBot(args.experiment)
        if args.command == "run":
            asyncio.run(bot.run())
        else:
            print(json.dumps(bot.report(), indent=2))


if __name__ == "__main__":
    main()
