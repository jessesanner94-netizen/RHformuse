# Execution Rules

## Current mode

October 9 readiness preparation: the existing positions launcher has a gated live
resident branch targeting 10-second checks, 20-second quote/snapshot age and an
8-second timeout per broker request. This does not change registered tasks, start
the live loop, or authorize orders. `LIVE_EXECUTION_ENABLED: false` and
`LIVE_NEW_ENTRIES_ENABLED: false` remain binding. The live loop defaults to
read-only; executing mode requires its CLI switch plus the live configuration.
New no-Luna entries additionally require the healthy executing loop's owner lock
and heartbeat. After broker review, revalidate input age and unchanged config
before placement. Retain references across timeout/cancellation/crash ambiguity.
Single-contract fill evidence is reconciled even if the order state says partial
or cancelled; contradictory/fractional quantities require attention. An unfilled
entry past its hold deadline produces a manual-cancellation alert, never an
automatic cancellation. Unattended OAuth failure requests explicit reauthorization
instead of launching a browser. Broker-held stop/TP behavior and actual fills
remain unverified. See `docs/LIVE_READINESS_2026-10-09.md`.

October 9 paper monitor amendment: `PAPER_FAST_MONITOR_ENABLED: true` routes the
existing positions task to a resident, paper-only Python loop targeting 10-second
held-option checks. It checks mode each tick and stops if live is enabled or
paper/fast monitoring is disabled. It has no entry or live order authority.
Quote requests contain held option IDs only; no research/model call is added.
Primary paper exits in either monitor enforce the configured 20-second maximum
quote age. Background minute-bar TP evidence uses the existing assumed-fill
rules; fresh-bid stops do not wait for history or notifications. All account
updates use the existing locked paper ledger. The two-minute Windows trigger
is a process restart opportunity, not the quote cadence. Duplicate processes
are fenced by a singleton lock. Live behavior/settings remain unchanged.

October 9, 2026: the active options paper route is deterministic. Python's
qualified direction and JEV's selected contract proceed without a Luna/Codex
model decision when `OPTIONS_LUNA_VETO_ENABLED: false`. The primary ledger uses
the realized-P&L daily green lock; it blocks only later entries after the first
strictly positive realized daily total, while retaining ordinary exits and all
existing daily-loss/risk controls. This is paper-only evidence collection; it
does not enable live trading.

October 9 cutover: code supports the same deterministic entry route and realized
green lock in the live executor, tested only with synthetic broker operations.
`LIVE_EXECUTION_ENABLED` remains false; no real order is part of verification.
Fresh broker checks, exact Robinhood order review, account/cash/risk checks,
fresh quote/Greeks/liquidity checks and session restrictions still bind that code.
A completed old model decision cannot enter the no-Luna executor: require a fresh
qualified deterministic packet. Entry economics use the actual two-decimal order
limit; recheck actual-fill economics when a confirmed fill is reconciled.

Daily locks are durable and sticky: after a completed exit first brings cumulative
realized daily modeled net P&L strictly above $0, block new entries, never
force-close already-open positions. Exactly zero/unrealized gains do not latch;
later losses do not release it. Reset at Eastern date rollover, with ordinary
calendar/session gates still binding. A final blocked entry increments the
ledger's skipped-entry count; a scan suppressed before discovery is logged as a
skipped opportunity cycle, not counted as a qualified entry attempt.
Historical comparators are retained and disabled. Independent epoch paths and
labels are documented in `docs/OPTIONS_DETERMINISTIC_CUTOVER.md`.

October 8 paper additions: reject cost-adjusted net reward-to-risk below the
configured inclusive 1.00 minimum before JEV/Luna and recheck the fresh entry ask
for primary, DAY control and `daily_green_lock`. Existing exits stay unchanged.
The green-lock comparator uses only fresh Luna BUY decisions and its own paper
cash/exposure/risk state; once realized daily P&L first becomes positive, reject
later entries with `daily_green_lock_active` while continuing protective exits.
It has no live order authority and is disabled whenever live mode is enabled.
See `docs/PAPER_QUALITY_GATES.md` for shared-decision comparison semantics.

September 24 winner trial override (authorized September 23): enrolled new primary
DAY paper positions do not use assumed historical TP-limit fills. They use fresh
option bids, with the target as a checkpoint and the continuation/trailing rules
in STRATEGY/RISK. The enrollment and parameters persist with each position;
new entries after the trial date return to normal fixed-target management.
The independent baseline continues its existing fixed-target/assumed-fill policy.
No live or crypto execution behavior changes. All trial exits retain ordinary
paper event accounting and notifications.

Paper TP amendment approved 2026-09-16: with PAPER_ASSUME_TP_TRADE_THROUGH enabled,
a completed, noninterpolated Robinhood one-minute option bar strictly above the
cent-rounded-up TP limit triggers an assumed fill at that limit, including normal
estimated costs. Bars must start after entry and end before the holding deadline.
If that bar or an earlier eligible bar also crosses the stop, historical TP fill
ordering is unresolved and normal current-bid exit handling remains authoritative.
Missing historical data does not create a fill. Ledger/events and notifications label
these ASSUMED_LIMIT_TAKE_PROFIT; cash is released when processed, not backdated.
The same paper management function applies to primary and control ledgers. Live
order behavior is unchanged; broker-held live TP implementation is still pending.

Live execution is disabled and paper trading is enabled as of 2026-08-29. Paper entries use the
refreshed ask and paper exits use the refreshed bid; neither action sends an order to Robinhood.
Returning to live execution requires another explicit user instruction and a fresh broker/state
reconciliation.

## Execution authority

The user-requested ETH path (2026-09-20) is paper-only and contains no real order adapter.
After a Luna BUY, refetch the market snapshot, recheck completed-candle direction, quote age,
spread, calendar/session, cash, daily loss and position count, reject an ask move over 0.25%,
and reject changed risk settings. Only then atomically record a simulated buy with fees/slippage.
Paper stops/targets/deadlines run in a separate minute task with no Luna or JEV dependency.

**Robinhood MCP is the only live order execution authority in Version 1.**

Vibe, Unusual Whales, social tools, sub-agents, and other research systems may inform decisions but may not place orders.

## Live-order sequence

Immediately before a live order:

1. Confirm `LIVE_EXECUTION_ENABLED: true`.
2. Pull fresh Robinhood account value/buying power.
3. Pull fresh Robinhood positions/open orders.
4. Pull fresh underlying quote.
5. Pull fresh option chain/contract quote.
6. Confirm contract, strike, expiration, type, bid/ask, and quantity.
7. Run all hard risk checks.
8. Run Robinhood order review/pre-trade review if available.
9. Compare reviewed order with intended order.
10. Under the user's standing unattended authorization, Python may place without a per-order human
    prompt only if the automated review contains no blocking/failed checks and every hard gate passes.
11. Confirm order/fill status.
12. Update project memory/journal.

## Unattended order handling

- Entry orders are one-contract buy-to-open limit orders at the newly refreshed ask, good for day.
- `LIVE_ORDER_CONFIRMATION_MODE: STANDING_UNATTENDED_AUTHORIZATION` records the user's explicit
  instruction to continue after a clean automated review without a per-order human prompt.
- Do not chase, cancel, replace, or reprice an unfilled entry automatically. It may fill at its limit
  or expire at the end of the session.
- Exits are one-contract sell-to-close market orders after a fresh reconciliation and Robinhood
  review. This prioritizes exiting risk over obtaining a particular limit price.
- No code path may call automatic cancellation. A cancellation remains an exceptional manual action.
- A submitted order and its client reference/order ID must be persisted before the next cycle can
  submit anything else, preventing duplicate entries or exits.
- With multiple positions, track each position and each pending order independently. A pending
  entry blocks additional entries, but must not block protective exits on other contracts. Multiple
  required exits may be submitted in one cycle, each separately reviewed and persisted. A pending
  exit prevents a duplicate exit on that same contract.

## Source-of-truth conflict

If Robinhood live state conflicts with project memory, treat Robinhood as current account truth, stop new execution until the mismatch is reconciled, then update memory.

## Initial options scope

Use single-leg long options in Version 1 unless multi-leg execution and risk handling are explicitly verified and approved.

## Style and late-entry boundary

All discovery paths use the same entry-style and session-time normalization, including the fixed
watchlist. The NYSE regular-session calendar supplies holidays and early closes. Entry cutoffs and
DAY exit deadlines move with the actual underlying-session close; on a 13:00 close, DAY entries
end at 12:30 and DAY positions exit from 12:45. The program does not depend on later option-only
closing minutes. Final paper fills recheck fresh volume/OI, spread, Greeks, time, ticker exposure,
cash and prospective stop-risk budget. This does not change the configured strategy signals.

The exact contract must pass the deterministic Greek/DTE gate for the chosen `DAY` or `SWING`
style. New day entries stop 30 minutes before the regular close. New swing entries and discovery may
continue until 10 minutes before the close. After the day cutoff, the model cannot relabel a
day-only contract as a swing; `SWING` must be present in the candidate's current eligible-style set.

## Stale data / ambiguity

Never execute from stale cached quotes or Vibe/UW/social prices. If contract identity, quantity, order type, or price intent is ambiguous, do not place the order.

## Duplicate order protection

Inspect open/recent orders before placement to prevent accidental duplicate entries.

## Exit management

Exit/hold/reduce decisions must reference the original position thesis in `state/POSITIONS.md`, not just current P&L.

The hard stop, take-profit, and time exit are deterministic Python controls. GPT may recommend an
earlier thesis/news exit but may not widen, disable, or delay the hard stop. Every exit still uses a
fresh broker reconciliation and automated Robinhood order review.

## Economic calendar (2026-09-16 user-requested implementation)

Before discovery, model entry decisions, and final paper/live entry checks, Python
requires a usable economic calendar and rejects new entries during configured
blackouts. Fed scheduled decisions use 14:00 America/New_York, including DST.
Free Fed/BEA calendars and the official BLS monthly list rendered through Jina
cover FOMC, CPI, PPI, payrolls, JOLTS, ECI, GDP and PCE. Successful snapshots refresh
hourly; failures retry after five minutes and block new entries. Missing data is
not interpreted as a quiet calendar. Existing exits do not depend on this gate.

The model receives recent/upcoming events separately from corporate earnings.
These are scheduled times, not actual results or a bullish/bearish recommendation.
Coverage is not exhaustive: unscheduled news, all Fed speeches, claims, ISM and
retail sales are not covered. BLS coverage is the current month. A swing hold beyond
that coverage still requires event review. No automatic event liquidation was added.


## September 22 authorized DAY-only options policy

DAY_ONLY_OPTIONS replaces mixed DAY/SWING selection for all new options entries and
watches. Intraday5M/15M direction governs DAY qualification; daily/4H context cannot
activate an extra countertrend veto. Existing intraday direction, data, Greek,
liquidity, risk and event gates remain. No new swing entries. Search nearest allowed
expirations without a reserved swing slot. Keep the configured30minute entry cutoff
and15minute pre-close exit, adjusted to the NYSE session calendar. No overnight
options holds are intentionally opened. Existing positions retain monitoring.
Crypto overnight spot paper trading is unchanged. JEV ranking and Luna decisions
remain required as configured; this does not enable live execution.
