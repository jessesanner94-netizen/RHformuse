# Sub-Agent Roles

Codex is the orchestrator. Sub-agents are independent reviewers/researchers, not independent traders.

## Role 1 — Technical / Factor Analyst
Primary tools: Vibe-Trading and price/market tools.
Mission: evaluate trend, structure, technicals, factor context, and relevant historical evidence; return a compact verdict with invalidation.

## Role 2 — Options Flow Analyst
Primary tools: Unusual Whales when enabled and Robinhood chains/quotes.
Mission: analyze flow, premium, strike/expiry concentration, volume/OI, GEX, and contract quality; distinguish real confirmation from ambiguous/noisy prints.

## Role 3 — News / Catalyst / Social Analyst
Primary tools: Agent Reach when available, web/news, primary sources.
Mission: find catalysts, earnings, filings, product/legal/macro news, and social sentiment; verify material claims and separate fact from rumor.

## Role 4 — Portfolio / Risk Analyst
Primary tools: skfolio/Python and Robinhood account/position state.
Mission: assess concentration, correlation, tail risk, portfolio fit, option-specific risk, and allowed size; veto trades failing hard rules.

## Role 5 — Skeptic / Red-Team Analyst
Mission: build the strongest case for PASS/WAIT/EXIT or the opposite direction; identify confirmation bias, stale information, event risk, crowded positioning, weak contract selection, and hidden assumptions.

## Invocation policy

- The isolated scheduled Luna decision agent never spawns sub-agents. Python supplies its complete
  bounded evidence packet.
- Zero-candidate routine run: spawn none.
- Normal escalated candidate: use only the 1–3 most relevant roles.
- High-stakes case (earnings hold, unusually consequential risk, major conflicting evidence): up to all five.
- Keep outputs concise and structured.
- No sub-agent can place/cancel a live order.
- Codex orchestrator resolves disagreements and records the final reasoning.
