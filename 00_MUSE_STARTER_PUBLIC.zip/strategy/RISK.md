# Risk Policy

Risk controls override opportunity quality.

October 9 live readiness preparation adds fail-closed operational entry interlocks:
new entries require the explicit entry switch and a healthy executing resident
monitor owned by a live process, with a heartbeat no older than 20 seconds.
Held-option quotes and snapshots are limited to 20 seconds old / 2 seconds future
skew. Individual fast-monitor broker requests time out after 8 seconds; 429s honor
at least 30 seconds and Retry-After. Neither entry locks nor a missing JEV/model
budget prevents deterministic exits. An uncertain submission is retained for
reconciliation, never blindly repeated. Broker execution timestamps, when supplied,
keep prior-day recovered fills out of today's P&L/green lock. Missing execution
times use reconciliation time, explicitly documented in the readiness report.
No broker-held stop has been added: PC/API/network failures still interrupt software
protection. Actual order behavior remains unverified; live execution is disabled.

October 9, 2026: the active primary paper strategy and offline live-ready executor
use the same realized-only
daily green lock previously tested in the independent comparator. Once realized
daily P&L after costs first exceeds zero, later entries are prohibited for that
ledger until the next Eastern trading day. Its normal prospective daily-loss
budget, hard loss limits, cash checks, and entry limits remain binding.

The daily loss limit remains the smaller of $45 and 12.5% of start-of-day equity.
Planned stop risk plus the existing $2.10 round-trip reserve and outstanding
position stop risk must fit the remaining allowance. Stops remain 25%, targets
30%, one contract, three new entries/day, with the usual session deadline.
The inclusive 1.00 post-cost gate binds paper and live-ready entries both before
JEV and on the final quote. With $1.05 modeled per side it first passes at $84
premium: $23.10 reward / $23.10 risk. It never adjusts exits to make a trade fit.

For the new epoch, completed live fills retain gross broker-fill P&L separately;
the lock uses gross P&L less the entry and exit modeled costs captured at entry.
Account equity/buying power remain broker truth for risk checks. A price-improved
entry may fall below 1.00 if actual-fill-based exits shrink the dollar payoff;
log the recomputed ratio and ATTENTION, without inventing an immediate forced
exit. Software stop/target execution remains subject to gaps and polling.

October 8 user-authorized paper admission: `MIN_NET_REWARD_TO_RISK: 1.00` is
inclusive, calculated after both modeled execution sides with existing ledger
cent accounting at the configured premium triggers. It binds all option paper
entry routes before review and again at fill. This is not a guaranteed exit loss
cap and does not replace the prospective daily planned-loss/cash checks.

The independent `daily_green_lock` comparator latches its entry prohibition on
strictly positive cumulative realized daily P&L after closed-trade costs. No
unrealized trigger, profit quota, force-close or same-day unlock after losses.
Rollover resets its own lock; normal session/holiday entry gates still apply.
Other ledgers' state cannot trigger its lock. See `docs/PAPER_QUALITY_GATES.md`.

## September 24 paper winner trial

For new primary DAY paper entries on the configured trial date only, the 30%
target is a checkpoint. An intact fresh intraday continuation assessment permits
holding with a monotonic trailing trigger: maximum of the original stop,
entry premium plus 10%, and highest observed bid less 10%. The original 25% loss
trigger never widens. These software triggers are not guaranteed fill prices.
Mandatory pre-close exit, one-contract sizing, daily entry/loss limits and cost
accounting remain binding. Missing continuation evidence does not authorize
extending a winner. There is no new model dependency for protective exits.

## Independent ETH/BTC paper experiment — 2026-09-20

The requested spot experiment starts with $369 simulated cash in its own ledger. Conservative
initial research parameters are $50 maximum notional, one position, three entries per Eastern
day, 2.5% stop, 5% target, and four-hour maximum holding time, further bounded by the next equity
open. Planned stop loss plus estimated round-trip fee/slippage must fit its $5 daily loss budget;
public-venue fees are assumed 0.25% per side and slippage 5 bps per side. Robinhood-priced
paper entries use the greater of this fee floor and a fresh Robinhood fee estimate; exits
retain at least the entry fee rate and increase it if the fresh rate is higher. Public-venue
paper performance is not a Robinhood fill or fee forecast.
Paper buys use fresh ask plus slippage and sells fresh bid minus slippage; fees are deducted.
Python performs exits independently of the 20-call Luna budget. Outages or sleep cannot produce
historical guaranteed fills; the next fresh quote determines the simulated exit price.

No averaging down, second crypto position, leverage, shorting, futures, or actual crypto orders.
ETH and BTC share one account and the existing limits; adding BTC does not double capital or risk.
Crypto's stop-after-net-green is local to that paper day; options' risk state is unchanged.
The two ledgers are separate experimental accounts, not a pooled portfolio or evidence that
the same real $369 can fund both. Shared live capital would require a separate verified design.

## Hard principles

- Never risk capital merely to hit a revenue/subscription target.
- Never increase risk to “make back” a prior loss.
- Never bypass hard account/daily/position limits.
- Never place a new live trade with unresolved required risk settings.
- Premium paid is not the only risk consideration; expiration, IV, liquidity, correlation, event risk, and concentration matter.

## Portfolio risk

Use Robinhood live state + skfolio/Python when appropriate to evaluate current exposure, correlated positions, concentration, volatility, drawdown state, portfolio risk budget, and tail-risk measures.

On 2026-08-27 the user removed the simultaneous-position count limit and combined-premium cap. On
2026-09-02 the user raised the current paper experiment's per-contract ceiling to $250. Allow at
most three new positions per Eastern trading day, one contract per position. Each new contract must
cost $50–$250 and fit fresh buying power. The old 41%-of-account position restriction is removed
(percentage ceiling 100%); the $250 per-position dollar ceiling remains.
All available cash may be deployed across positions, with no separate dollar cap on combined
premium. This increases total capital at risk; it is permission, not a target to spend all cash.
Daily-loss limits, no averaging down, event/contract gates, broker review, and existing-position
management remain unchanged. Missing or malformed limits never mean unlimited: only the two
explicit optional caps accept `UNLIMITED`.

Only one open option position per underlying ticker: while any option on a ticker is held,
exclude all of its other strikes, expirations, calls, and puts from new entries. Recheck this
against reconciled positions before submission as well as before the opportunity model call.
This does not suppress monitoring or exits on any existing position.

skfolio is a portfolio math component, not the entire options risk engine.

## Option-specific risk

Before opening, check bid/ask spread, volume/open interest, DTE, fresh Greeks, IV/event risk, max
premium loss, expected holding period, underlying liquidity, and earnings/catalyst timing. Missing or
invalid Greeks fail the entry gate closed.

Greek gates are trade-style aware. A day contract may be 2–45 calendar DTE with absolute delta
0.20–0.80, theta no more than 65% of option midpoint per day, and gamma-driven delta change no more
than 0.35 for a 1% underlying move. A swing contract must be 7–45 DTE with absolute delta 0.25–0.75,
theta no more than 12% of midpoint per day, and normalized gamma no more than 0.25. Calls require
positive delta; puts require negative delta; long-option gamma/vega must be nonnegative, theta must
be nonpositive, and IV must be positive. Vega, rho, IV, and normalized metrics remain visible to the
reviewer even when they are not assigned an untested standalone cutoff.

## Earnings risk

Any intentional earnings hold requires the event-risk workflow in `EARNINGS_NEWS_SOCIAL.md`. If approved, apply `EARNINGS_RISK_MULTIPLIER` to reduce normal position risk.

## Daily risk state

User-approved repair, 2026-09-05: before an entry, reserve its prospective loss to the 25% stop,
plus the configured round-trip cost buffer. This must fit the smaller daily dollar/percentage
limit after today's equity losses and remaining stop exposure on open positions. Gains do not
expand the day's planned-risk allowance. Mark open-position risk from its current bid to its stop,
plus its estimated exit costs. Missing/invalid budget settings fail closed. The optional unlimited
position/premium caps do not disable this prospective daily-risk rule.

Paper daily P&L is current equity minus start-of-day equity. Yesterday's open-position loss is
not counted again today. Paper results charge configured estimated fees and adverse slippage
separately from ask-entry/bid-exit prices. The buffer is a planning allowance; gaps, outages and
execution differences can still produce losses exceeding it.

`state/DAILY_STATE.md` must track realized/unrealized P&L, daily loss-limit status, trade count, open risk, and compute/data spend. When a hard limit is reached, new risk is prohibited.

## Fail-safe

If calculated risk disagrees between tools or cannot be reconciled, choose the more conservative interpretation or do not trade.

## Software-managed exit risk

October 9 paper-only amendment (explicitly authorized): held-option checks target
10 seconds, with a maximum 20-second quote age and at most 2 seconds of clock
skew into the future. Stale/failed quotes cannot create a paper exit. Realized
green/daily-loss entry locks never stop position monitoring. Stops remain 25%,
targets 30%, and calendar-aware deadlines and modeled costs remain unchanged.
This polling target cannot guarantee execution or survive PC/network outages.
The paragraph below describes the unchanged, disabled live executor's cadence.

Version 1 uses deterministic Python polling every two minutes for the approved 25% stop, 30% profit
target, and holding deadline. These are trigger thresholds, not guaranteed execution prices. The
program submits a reviewed market sell-to-close after the live bid crosses a threshold, so gaps,
wide spreads, fast markets, Robinhood/API outages, PC sleep, power loss, or network failure can
produce a loss larger than 25%. No GPT call is required for a hard exit, and GPT cannot loosen it.


## September 22 authorized DAY-only options policy

DAY_ONLY_OPTIONS replaces mixed DAY/SWING selection for all new options entries and
watches. Intraday5M/15M direction governs DAY qualification; daily/4H context cannot
activate an extra countertrend veto. Existing intraday direction, data, Greek,
liquidity, risk and event gates remain. No new swing entries. Search nearest allowed
expirations without a reserved swing slot. Keep the configured30minute entry cutoff
and15minute pre-close exit, adjusted to the NYSE session calendar. No overnight
options holds are intentionally opened. Existing positions retain monitoring.
Crypto overnight spot paper trading is unchanged. JEV ranking and Luna decisions
remain required as configured; this does not enable live execution.
