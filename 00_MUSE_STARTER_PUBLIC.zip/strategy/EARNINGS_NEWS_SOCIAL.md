# Earnings, News, Catalysts, and Social Sentiment

## Earnings calendar is mandatory

For every new option candidate and every open option position, determine whether earnings or another major known event is expected during the intended holding window or before expiration. Record the event/date in the position thesis.

## Intentional earnings hold

Before intentionally holding an option through earnings, explicitly evaluate:

- exact earnings date/time, verified reliably
- contract expiration / DTE
- IV and expected IV crush
- market-implied move
- agent's expected move and thesis
- Greeks when available
- strike/contract liquidity
- UW flow/GEX/premium context when enabled
- current P&L and remaining premium at risk
- whether the catalyst is priced in
- post-release scenarios
- portfolio concentration/correlation
- reduced earnings-event position size

Then record one explicit decision: `HOLD THROUGH EARNINGS`, `REDUCE BEFORE EARNINGS`, or `EXIT BEFORE EARNINGS`.

If the review cannot be completed, do not intentionally hold through earnings.

## Risk reduction

If holding through earnings, apply `EARNINGS_RISK_MULTIPLIER` from `CONFIG.md`. If unresolved, an intentional live earnings hold is prohibited.

## News as an opportunity source

The agent should not only research scanner-produced symbols. Current news/catalyst discovery can itself produce a candidate, which must still pass all liquidity, technical/context, contract, risk, event, and portfolio-fit gates.

## Social sentiment

Use X/Twitter, Reddit, and other social sources for emerging catalysts, sentiment shifts, crowd narrative, unusual attention, and candidate discovery. Do not trade solely because a post is viral.

## Rumor handling

Label unverified information as rumor/unconfirmed. Increase skepticism and reduce/no risk until verified. Do not present social consensus as fact.
