# Strategy — Version 1

## October 9 live preparation — activation still prohibited

The prepared live positions launcher uses a resident 10-second deterministic
monitor, independent of discovery, JEV and judgment models. New no-Luna entries
also require `LIVE_NEW_ENTRIES_ENABLED: true`, a fresh healthy executing monitor
heartbeat, and its resident owner lock. This operational interlock adds no signal
or exit tuning. Both live execution and new entries remain disabled. Paper and
historical ledgers are preserved. See `docs/LIVE_READINESS_2026-10-09.md` for the
verification boundary and the approval plan; simulated checks do not certify fills.

## October 9 deterministic-options route — user authorized

October 9 monitoring amendment: user approved a separate paper-only resident
Python loop targeting one held-contract quote check every 10 seconds. No JEV,
Luna, entry discovery, or live order action occurs in this loop. The ordinary
five-minute opportunity cycle and all stop/target/green-lock settings remain.
See `docs/PAPER_FAST_MONITOR.md` for freshness, timeout and outage semantics.

The active SPY/QQQ DAY paper-options route is `Python qualification -> JEV contract
ranking -> deterministic hard gates -> paper entry`. The same flow is implemented
for offline live-executor tests; live execution remains disabled.
`OPTIONS_LUNA_VETO_ENABLED:
false` removes every Luna/Codex veto, WATCH, PASS, and model-call dependency from
new options entries and qualitative position handling. It does not loosen
direction, event, liquidity, economics, timing, final quote, or risk gates.

`OPTIONS_DAILY_GREEN_LOCK_ENABLED: true` makes the primary strategy's own ledger
stop opening later positions after cumulative realized daily P&L first becomes
strictly positive. Existing positions retain their ordinary stop/target/deadline
exits. The regular daily planned-loss and entry-limit protections remain active.
The strategy epoch `python_jev_green_lock_20261009` starts an independent paper
account at the configured $369 under `state/options/<epoch>/paper/`; its live
state location is `state/options/<epoch>/live/` and initializes only in a future
live run. Earlier primary/live history is preserved. There is no historical
replay import or combined return. Epoch evaluation files live beside these modes.
The historical DAY-control and isolated green-lock comparator ledgers are disabled
to prevent duplicate positions; their old records remain evidence only.

The no-Luna route never reads or writes Luna PASS/BUY caches or WATCH state,
reserves Luna calls, or sleeps for an exhausted Luna budget. JEV ranks up to three
Python-qualified contracts without score vetoes. Missing/invalid JEV rankings
fail closed, including a partially ranked shortlist; there is no Python-only
fallback in this route. Protective exits remain deterministic and independent
of JEV and entry-configuration availability. Full semantics and verification:
`docs/OPTIONS_DETERMINISTIC_CUTOVER.md`. Dated rules below are historical where
superseded by this section; crypto is unchanged.

## October 8 paper quality improvements — user authorized

For SPY/QQQ paper options, Python requires net target reward / net stopped-out
risk >= `MIN_NET_REWARD_TO_RISK` (initially 1.00), after the existing modeled
entry/exit costs. Reject nonpositive reward or invalid/zero risk before JEV/Luna
and recheck the refreshed fill. This binds primary and the DAY control. Stops,
targets, JEV's rank-only role and Luna's primary final judgment stay unchanged.

`PAPER_DAILY_GREEN_LOCK_ENABLED` adds the independent `daily_green_lock` paper
comparator. It follows fresh BUYs from the shared primary JEV/Luna funnel and
its own risk/account gates. Once its cumulative realized daily P&L first exceeds
zero after costs, block later entries that Eastern day; continue normal exits.
No live authority, extra model calls, forced trades or copied historical results.
Exact semantics and shared-funnel limitations: `docs/PAPER_QUALITY_GATES.md`.

## September 24 primary paper winner-continuation trial

Authorized September 23: new primary DAY paper positions opened September 24 use
the existing 30% target as a continuation checkpoint. Python checks fresh completed
5-minute direction and current-session structure against the position's call/put
direction. Neither may oppose it and at least one must support it; 15-minute
evidence is context. This is a mechanical proxy for the original directional thesis,
not an interpretation of every free-text thesis/invalidation clause.
After a supported checkpoint, trail 10% below the highest observed option bid,
with at least a 10%-above-entry trigger floor. The floor can only rise. Exit on
lost/unavailable continuation evidence, a trailing trigger, original stop, or the
existing calendar-aware time deadline. JEV has no exit authority. After Python
commits a checkpoint hold, one optional JEV assessment is logged per position,
with a four-second timeout, no retry, and the shared JEV budget. Its low score,
failure or unavailability cannot change the exit/hold decision. No Luna call is
needed. Order-book observations are supporting context only;
resting bids/offers do not establish executed selling, absorption, or exhaustion.
Baseline, crypto, entry gates, and daily risk limits stay unchanged. This dated
trial supersedes the automatic fixed-target exit only for enrolled positions.

## Objective

### Paper-only ETH/BTC expansion — requested 2026-09-20

The equity universe remains SPY/QQQ. Outside NYSE regular hours, a separate ETH-USD/BTC-USD long-only
spot paper experiment uses Coinbase candles/depth with public Binance.US as research backup.
The user restored external data on 2026-09-20. Paper prices prefer Robinhood, with explicitly
approved public exchange fallbacks. Sources stay labeled and open positions retain their
pricing venue; external depth never establishes Robinhood execution liquidity.
It has no brokerage order adapter. Python requires consecutive completed 5-minute candles,
completed 15-minute aggregation, closes above their respective 20-bar SMA with positive
three-bar returns, at least 0.5 relative volume on the completed 5-minute bar, fresh quotes,
acceptable spread, usable macro calendar, and the independent paper risk budget. This is a
clearly labeled unvalidated continuation hypothesis, not an established edge. Missing crypto
news/social remains unavailable and is disclosed to Luna, never fabricated as neutral support.

JEV filtering and options WATCH are now enabled in paper, as requested. Active JEV failure blocks
crypto escalation outside its dated comparison; options use ranking-only routing below.
A successful high score still cannot override Python risk checks. Luna
retains the final BUY/PASS/WATCH judgment. ETH/BTC share one bounded price WATCH; options retain up to
three exact-contract watches. WATCH only authorizes monitoring and later re-evaluation, not entry.
Live execution remains disabled and this expansion does not authorize live crypto, futures,
leverage, shorts, or any attempt to bypass jurisdiction/account restrictions.

Revised comparison authorized 2026-09-21: use the final-review-worthiness question and blind
Luna to JEV outputs during the dated CONFIG windows. Two morning samples (one per coin) and
four overnight samples (one per time window, two per coin) remain subject to Python gates,
JEV's false-breakout ceiling, cooldown and shared budget. All trial changes expire September 22
at 09:30 Eastern. This is a prospective diagnostic sample, not randomized profitability validation.

September 21 options ranking authorization supersedes the expired options comparison:
JEV ranks up to three Python-qualified, cache/exposure/watch-eligible SPY/QQQ paper
candidates; the first READY watch has priority, then setup quality, entry timing, and
escalation score determine order. Low scores and unavailable JEV cannot veto review;
use deterministic Python order if any rank in the selection pool is unavailable. Send at most one
candidate per scan to Luna, without JEV scores/verdict. All Python, budget, watch,
and final fill checks remain required. No change to crypto or live routing.
Paper options JEV evidence includes premium stops/targets; its review question does
not require ambiguity. A premium stop differs from chart-based thesis invalidation.

Seek positive expectancy in liquid U.S. equity/ETF options using confluence across price/technical structure, factor/fundamental context where relevant, catalysts/news, options-flow information when available, social sentiment as a discovery/secondary signal, contract quality/liquidity, and portfolio/risk fit.

The active options strategy is DAY-only; historical swing policy below is inactive.

## Initial instrument scope

Version 1 focuses on **single-leg long calls and long puts** unless later explicitly expanded. This keeps risk bounded to premium paid while broader option-order support and multi-leg risk handling are validated.

## Current simplified paper experiment — approved 2026-08-29

Implementation repair approved 2026-09-05: the bounded chain search now includes the nearest two
permitted expirations and the nearest available SWING-eligible expiration, where available. It
preserves call/put and DAY/SWING coverage rather than letting repeated contracts fill the shortlist.
The effective premium budget is applied before qualitative research. This is a search/eligibility
repair, not a new entry strategy or a validated profitability improvement.

A separate forward DAY control buys the same Python-qualified, newly model-reviewed contract
without Luna's BUY/PASS/WAIT veto. It uses the same post-decision quote, ask/bid fill policy, costs,
hard risk gates and DAY exits, in an independent paper ledger. It does not enter SWING positions,
reuse cached model decisions, add model calls, or feed decisions back into the primary strategy.
Comparison is conditional on the shared discovery funnel; matched completed DAY observations are
reported separately from total primary-account results. Neither activity nor win rate alone is
evidence of positive expectancy. Further strategy simplification remains a later user decision.

The active discovery universe is SPY and QQQ only. This is a paper-trading evaluation, not evidence
that either symbol or the current rules have positive expectancy. Python resolves a bounded set of
liquid contracts, applies the existing contract/Greek/risk/event/timing gates, and sends one compact
candidate to Luna/high for BUY/PASS/exceptional WAIT judgment. The packet contains exact contract
price, spread, volume, open interest, Greeks/IV, underlying liquidity, consecutive 5M/15M/4H/1D
indicator summaries, opening-range/VWAP context, compressed news/social, account state, and exits.
Raw bars, posts, feeds, rejected chains, and repository context are excluded.

Unusual Whales is disabled. Missing flow is labeled disabled and is never treated as confirmation.
The earlier flow-led-reversal path therefore cannot qualify a candidate. A replacement signal and
one explicit entry setup remain subjects for testing and require later approval before activation.

## Opportunity sources

Candidates may come from the deterministic scanner, Vibe, breaking news, earnings/catalyst calendar, social/X/Reddit discovery, Unusual Whales flow, or current watchlists/positions.

The scanner is not the only source of new ideas; news/social/event discovery may generate a candidate that then must pass the same gates.

The current model-free discovery order is:

1. Resolve only the configured SPY and QQQ watchlist through Robinhood.
2. Diversify by underlying symbol so repeated contracts cannot crowd out market breadth.
   Exclude the entire options chain of every currently held ticker from NEW-opportunity model
   review, regardless of call/put, strike, or expiry. Python skips these before per-candidate
   research/model-budget reservation and advances to another ticker. Recompute from reconciled
   positions each cycle, so the restriction ends after the position closes. This does not block
   existing-position monitoring or genuine thesis/event-driven exit review.
3. Resolve exact contracts and fresh quotes/Greeks through Robinhood.
4. Apply underlying liquidity, premium, spread, option volume/OI, DTE, and style-aware Greek gates.
5. Rank a bounded shortlist in Python using contract quality and direction-adjusted technical
   support. Technical indicators must use consecutive bars; do not treat an evenly downsampled
   intraday series as the requested timeframe. Reject unresolved risk/event gates and technical
   conflicts before a model call. Advance to the next distinct symbol/direction without spending a
   call when a candidate fails.
6. Send at most one direction-aligned, trade-ready contract with compact
   multi-timeframe/flow/news/social/risk summaries to the isolated Luna/high final decision agent.

The scheduled decision agent receives no raw feeds, rejected contracts, repository context,
browser, MCP tools, or automatic Sol escalation. `WAIT` requires one exact cached price trigger;
otherwise it must choose `BUY` or `PASS`.

Broad movers and paid-flow discovery are inactive in this experiment. Contract volume and open
interest remain separate tradability gates sourced from Robinhood.

## Required confluence

No single signal automatically creates a trade. Evaluate:

1. Underlying setup quality
2. Catalyst/news quality
3. Options-flow confirmation or contradiction
4. Contract liquidity and spread
5. Style-appropriate delta, gamma, theta, vega, and volatility/IV context
6. Risk/reward and invalidation clarity
7. Portfolio fit / correlated exposure
8. Event and earnings risk
9. Social sentiment quality, when relevant

For DAY decisions, consecutive 5-minute/15-minute bars and current-session opening-range structure
are primary technical evidence; 4-hour/daily trends are context. For SWING decisions, 4-hour/daily
structure remains primary. Strong options flow is meaningful evidence but may reflect hedges,
spreads, rolls, opening, or closing activity, so it may not be the sole justification for a trade.

Exact score weights and thresholds must be tested rather than invented.

### Entry-timing guard — user-approved narrow adjustment, 2026-08-27

For a DAY contract opposing the daily trend label OR the sign of today's daily price change,
require both 5M and 15M trends to support the contract and a fresh level confirmation. The latest
completed regular-session 5M candle must test opening-range high or session VWAP and close below
that level with a bearish body (put), or test opening-range low or session VWAP and close above
with a bullish body (call). Its close must be from today and no more than ten minutes old. Missing
daily context or missing/stale required confirmation fails closed before a Luna call. Historical
session-wide sweep flags alone never satisfy this additional gate, even with strong flow or a
positive day score. Include bar-based session VWAP and distance from session extremes in the packet
so Luna can assess remaining room instead of extrapolating a completed pullback. This is a tested
mechanical safeguard, not a validated edge or a promise to avoid losses. Trend-following DAY and
SWING eligibility, the universe, sizing, and exit policy are otherwise unchanged.

## Decision outcomes

`BUY`, `WAIT`, `PASS`, `EXIT`, `REDUCE`, or `HOLD`.

`NO TRADE` is a successful outcome when evidence is weak.

## Thesis requirement

Before opening a position, record why the underlying should move, direction, expected horizon, catalysts, confirming evidence, invalidation, contract rationale, event exposure, exit logic, and risk amount.

## Strategy changes

Do not change the strategy because of a single win/loss. Proposed changes require a hypothesis, evidence, testing where possible, and user approval before modifying core rules.

## September 22 crypto paper admission update

User authorized CRYPTO_JEV_ABOVE_AVERAGE: compare setup_quality with the prior
same-coin/model/question-version mean, strictly greater, no extra margin. This
supersedes fixed crypto JEV thresholds and dated sampling; valid zero-history
results bootstrap to Luna. Missing/invalid JEV or unreadable history blocks.
Python qualification, cooldown, WATCH, daily budget and final fill checks remain.
Luna is blind to JEV scores/verdict. Options ranking is unchanged. See CONFIG.md.

## September 22 crypto paper admission update

User authorized CRYPTO_JEV_ABOVE_AVERAGE: compare setup_quality with the prior
same-coin/model/question-version mean, strictly greater, no extra margin. This
supersedes fixed crypto JEV thresholds and dated sampling; valid zero-history
results bootstrap to Luna. Missing/invalid JEV or unreadable history blocks.
Python qualification, cooldown, WATCH, daily budget and final fill checks remain.
Luna is blind to JEV scores/verdict. Options ranking is unchanged. See CONFIG.md.


## September 22 authorized DAY-only options policy

DAY_ONLY_OPTIONS replaces mixed DAY/SWING selection for all new options entries and
watches. Intraday5M/15M direction governs DAY qualification; daily/4H context cannot
activate an extra countertrend veto. Existing intraday direction, data, Greek,
liquidity, risk and event gates remain. No new swing entries. Search nearest allowed
expirations without a reserved swing slot. Keep the configured30minute entry cutoff
and15minute pre-close exit, adjusted to the NYSE session calendar. No overnight
options holds are intentionally opened. Existing positions retain monitoring.
Crypto overnight spot paper trading is unchanged. JEV ranking and Luna decisions
remain required as configured; this does not enable live execution.
