# Trading Universe

## Version 1

Primary focus:
- liquid U.S.-listed equities with listed options
- liquid U.S.-listed ETFs with listed options

Initial trade structure:
- long calls
- long puts

## Exclusions by default

Do not trade contracts failing configured liquidity/spread requirements, symbols with unreliable/stale data, positions whose required event/risk data cannot be verified, unsupported products, or instruments prohibited by account restrictions.

## Discovery

`WATCHLIST_ONLY` is currently enabled with `WATCHLIST_SYMBOLS: SPY,QQQ`. No mover, news-only,
social-only, or paid-flow symbol may expand that entry universe while the flag remains enabled.
News and social evidence may still inform Luna's decision about those two symbols.
