# AI / Data Cost Policy

October 9 fast paper monitoring uses zero JEV/Luna/Codex decision calls. While
flat it reads the local ledger only. While invested it batches held-option quote
requests, targets 10-second checks, and bounds optional TP historical requests
to one background job per minute. An API 429 pauses fast quote requests for at
least 30 seconds and honors a longer Retry-After. No numeric Robinhood MCP rate
limit is asserted. Telemetry reports actual intervals and failures separately
from the target. Execution fee/slippage assumptions are unchanged.

October 9, 2026: normal SPY/QQQ options entries no longer spend a Luna/Codex
decision call. Python qualification, JEV ranking, and deterministic final gates
remain; the primary green-lock route records the same modeled execution
costs as before. Historical comparison ledgers are inactive and must not create
new duplicate paper entries.

The shared `paper_side_cost` calculation is reused for live-ready admission and
new-epoch realized lock accounting: configured $0.05 fee + $1.00 slippage per
contract per side, $2.10 round trip. These are planning assumptions, not asserted
Robinhood charges; do not subtract the planned-risk buffer a second time.
Actual live fill prices and gross P&L stay separate from modeled net P&L.
No Luna budget/cache/WATCH dependency remains in options entries or position
judgment, including the launcher/reset budget checks. The shared crypto budget
and its policy remain unchanged. Epoch telemetry prevents pooling old results.

October 8 paper quality gate reuses `paper_side_cost`, charging the same modeled
fee/slippage on each execution side. Do not double-charge the separate planned-risk
buffer. The daily-green-lock comparator shares primary JEV/Luna decisions and
post-decision quotes, with independent deterministic accounting/exits; it adds no
model calls. It is a realized-only risk experiment, never a profit quota or a
reason to force entries. Details: `docs/PAPER_QUALITY_GATES.md`.

## September 24 winner trial exception

User authorized optional JEV involvement without an exit bottleneck. After Python
has committed a primary paper winner checkpoint hold, record at most one JEV
continuation assessment per position. Reserve one request from the existing shared
JEV limits, use a four-second timeout and zero retries, and never consume a Luna
call for this assessment. Missing budget, failed data/API, or negative assessment
cannot prevent holding or alter a protective exit. Ordinary monitoring remains
deterministic; continuation judgments are separate from entry-score history.

The trading system must be economically viable.

## Core metrics

The 2026-09-05 forward paper evaluation records a daily rejection funnel and matched DAY outcomes
under `state/evaluation/`. Paper P&L includes configured estimated execution costs. Attributable
AI/data expense can be recorded using the existing cost tracker with the evaluation's
`state/evaluation/COSTS.jsonl` ledger. Until costs are recorded, economic profit is unavailable;
reported CLI tokens must not be presented as a measured dollar or subscription charge. No extra
model is called for the control ledger, metrics, hard exits or routine position monitoring.

`ECONOMIC_PROFIT = REALIZED_NET_TRADING_PNL - INCREMENTAL_AI_DATA_COST`

`AI_DATA_EFFICIENCY = REALIZED_NET_TRADING_PNL / INCREMENTAL_AI_DATA_COST`

Incremental AI/data cost includes attributable Codex credits/plan expense, Unusual Whales, and other paid data/API services. Track estimated/realized trading fees and slippage where measurable.

Also track profit per trade, per deep-reasoning escalation, per candidate analyzed, and incremental P&L attributable to specific paid data when measurable.

## Compute discipline

1. Manage open positions first.
2. Run cheap deterministic scan.
3. Zero qualified candidates -> stop new-opportunity reasoning.
4. Candidate -> compact tool-based analysis.
5. Strong candidate -> deeper reasoning.
6. Spawn sub-agents only when expected decision value justifies compute.
7. Avoid repeatedly fetching/reasoning over unchanged information.
   Never spend a new-opportunity Luna call on a ticker already held. Exclude its whole options
   chain in Python before per-candidate research, cached BUY reuse, and model-budget reservation;
   continue to other tickers. Necessary position-management reviews remain a separate route.
8. Keep journals structured and concise.
9. Scheduled decisions use one compact isolated Luna call only after Python has compressed the
   evidence. Never repeat model research already performed by Python.
   Python must reject opposing available UW flow and unresolved hard risk/event checks before
   reserving that model call. Technical-direction conflicts are rejected unless a DAY candidate
   meets the bounded `FLOW_LED_REVERSAL` exception: strong tagged direction-supportive UW flow plus
   non-opposing current-session intraday structure.
   Countertrend DAY entries must also pass the fresh level-confirmation / dual-intraday-timeframe
   timing gate in STRATEGY.md before any model reservation or cached BUY reuse. A new confirmed
   candle is a material cache change; an old session-wide sweep is not.
   When UW is disabled, make no UW discovery or per-candidate flow calls and disable the
   flow-led-reversal exception; technically aligned watchlist candidates may still reach Luna.
10. Enforce the configured daily model-call ceiling before launching Codex and cache unchanged
    `PASS`/`WAIT` decisions. Reuse an unchanged, still-valid `BUY` for a fail-closed broker retry
    without spending another model call.
11. Unless the explicitly enabled JEV research exception below applies, once the daily ceiling is reached, scheduled opportunity cycles sleep silently until the next
    Eastern trading day and the recurring Windows opportunity task is disabled. A separate hidden
    weekday reset re-enables it before market open. Skip news, flow, contract discovery, and model
    reasoning during that sleep; keep deterministic position monitoring active.

### User-requested JEV research exception (2026-09-20)

With `ENABLE_JEV: true`, Python collection and bounded JEV research continue after the
daily Luna ceiling; the opportunity launcher does not disable its task for that ceiling.
Luna reservations still fail closed at the configured daily limit. No JEV score authorizes
orders or bypasses deterministic gates. Separate durable JEV attempt limits apply, including
retries. Disabling JEV restores the prior sleep behavior. No existing scheduled task is
registered or enabled by this code change.

### Paper expansion approved 2026-09-20

The user raised the shared daily Luna allowance to 20 for SPY/QQQ options and ETH spot paper
testing. At the user's subsequent instruction, the budget window now starts at 09:30 Eastern
every day, including weekends and holidays, with DST handled by America/New_York. Overnight
ETH uses the previous window's remaining calls until 09:30; the earlier seven-call admission
restriction is removed. ETH does not open during the NYSE regular session. There is no midnight
or market-close budget reset. Equity and crypto paper P&L/risk days remain independent.
The admission check and global cap use one locked counter; changing 13 to 20 never resets usage.
Qualitative position reviews count toward the same total; no special unlimited model exception.
Python stops, targets, deadlines, and position monitoring need no model reservation and continue
after all 20 are used. Crypto runs its own minute monitor and five-minute opportunity task while
the computer is awake, logged in, and connected. No task wakes the computer for crypto.
Subscription cost is an evaluation metric, never a profit quota or a reason to force a trade.

## No quota-driven trading

A target such as “make enough to pay for UW” is an accounting benchmark, **not a trading objective**. Never lower setup quality, trade more, or size larger because a bill is due.

## Unusual Whales attribution test

During the UW trial:
1. Timestamp the **pre-UW** action/conviction.
2. Record it before querying UW.
3. Query UW.
4. Record the **post-UW** action/conviction and what changed.
5. Compare to a no-UW shadow decision where practical.

Renew UW only if evidence suggests its incremental decision value justifies its cost and risk-adjusted results.

## Upgrade rule

Recommend increased Codex/data spend only when the existing workflow is capacity-constrained and incremental compute/data has plausible, measured economic value.

## Options ranking authorization — September 21, 2026

Paper options JEV ranks at most three eligible Python candidates per scan; at most
one candidate reaches Luna. Ranking does not reserve extra Luna calls or override
cached decisions, watches, risk checks, or the shared 20-call daily ceiling.
Low scores or unavailable JEV do not block this options-only review path.

## September 22 crypto paper admission update

User authorized CRYPTO_JEV_ABOVE_AVERAGE: compare setup_quality with the prior
same-coin/model/question-version mean, strictly greater, no extra margin. This
supersedes fixed crypto JEV thresholds and dated sampling; valid zero-history
results bootstrap to Luna. Missing/invalid JEV or unreadable history blocks.
Python qualification, cooldown, WATCH, daily budget and final fill checks remain.
Luna is blind to JEV scores/verdict. Options ranking is unchanged. See CONFIG.md.
