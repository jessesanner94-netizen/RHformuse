# Data Sources and Tool Responsibilities

## ETH paper-only market data — 2026-09-20

Coinbase Exchange public ETH-USD ticker, aggregated Level II book, and completed 5-minute candles
feed the independent crypto simulation. Quotes are Coinbase prices, never labeled Robinhood
execution truth. Python rejects invalid, stale, crossed, incomplete or gapped inputs. Receipt-time
book timestamps are distinguished from exchange timestamps. Displayed depth is not executed flow.
The separate Robinhood Crypto Trading API requires separate credentials; linked Agentic crypto
account existence does not prove `is_api_tradable`. No such eligibility is currently established.

## Robinhood MCP — live truth / execution

Use for account value, buying power, positions, orders, chains, live contract/underlying quotes, order review, and execution.

## Vibe-Trading — research / quant

Use available Vibe tools/skills for market screening, technicals, factors, fundamentals, filings, news where available, backtests, and quantitative context. When Vibe provides `list_skills` / `load_skill` or equivalent, actually use them where relevant.

Vibe is not live execution truth.

## Unusual Whales — options intelligence

When enabled, use for options flow, unusual activity, net premium, GEX/exposure data, dark-pool context, and options volume/OI context. Directional summaries must use trade-side/directional tags when available rather than assuming all calls are bullish and all puts are bearish. Do not treat one large print or BUY/SELL label as proof of directional intent; seek convergent evidence.

It is disabled for the current SPY/QQQ paper experiment. Python must label it `DISABLED`, make no
UW requests, and must not replace it with invented neutral or supportive flow.

## skfolio + Python — deterministic portfolio math

Use for allocation/risk budgeting, correlation/covariance, concentration, optimization, and tail-risk style calculations. Do not delegate deterministic math to prose reasoning when code can calculate it reliably.

## Agent Reach / web / news — discovery and sentiment

When available, use Agent Reach or equivalent tooling for X/Twitter, Reddit, RSS, web discovery, and broader social/news scanning. Social sources are noisy; use them to discover/measure sentiment, then verify material claims before trading.

For scheduled compact decisions, Python fetches and reduces these sources to bounded sentiment and
catalyst fields. The isolated decision model receives no raw posts/articles and has no browsing or
social tools.

## Source priority

For live execution facts, Robinhood wins. For material corporate/event facts, prefer company IR/filings/exchange/authoritative sources, then high-quality news, with social as a lead rather than authority.
