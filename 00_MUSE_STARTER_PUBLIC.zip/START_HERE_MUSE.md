# Public-safe Muse handoff

Read AGENTS.md, TODO.txt and the strategy files. This is a research/paper-trading-only snapshot. Live execution is disabled. Trade histories are retained in state/HISTORICAL_TRADES.csv and research outputs; separate account observations can overlap and must not be added as independent trades. Account state, identifiers, balances, raw journals, original live configuration, opaque files, and unreviewed databases were excluded or redacted. Historical paths are bounded by the data included. Original files have been redacted and are not byte-identical; provenance hashes in older reports may not match.

See PUBLIC_SANITIZATION_REPORT.json for excluded/modified paths and limitations. No broker credentials or live order authority are included. Use the saved historical data for backtesting; fresh paper trading requires an authorized market-data connection. Rebuild dependencies from pyproject.toml. Do not execute live orders.
