# AGENTS.md — Mandatory Operating Instructions

These instructions govern every run of this trading project.

## 1. Required reading at the start of every run

Before market analysis or tool use, read:

1. `CONFIG.md`
2. `strategy/STRATEGY.md`
3. `strategy/RISK.md`
4. `strategy/COST_POLICY.md`
5. `strategy/EXECUTION_RULES.md`
6. `strategy/DATA_SOURCES.md`
7. `strategy/EARNINGS_NEWS_SOCIAL.md`
8. `strategy/SUBAGENTS.md`
9. `state/POSITIONS.md`
10. `state/DAILY_STATE.md`
11. `.agents/skills/robinhood-trader/SKILL.md`

Read `state/LESSONS.md` when doing escalated analysis, end-of-day review, or strategy evaluation.

Do not assume you remember these rules from an earlier chat.

### Compact scheduled decision-agent exception

The user approved a cost-controlled isolated Luna decision agent on 2026-08-26. The deterministic
Python orchestrator must perform the required broker reconciliation, hard gates, data collection,
compression, risk calculation, and persistent logging under this full policy. The isolated model
instance reads `prompts/DECISION_AGENT_AGENTS.md` and receives one compact, fresh, tool-grounded
decision packet. It must not browse, call tools, read the repository, or execute orders. This narrow
exception prevents the model from rereading the full repository and repeating research already
completed by Python; it does not waive any strategy, risk, event, or execution rule.

## 2. Tool use is mandatory

Do not answer market questions or make trading decisions from model memory when a relevant live or project tool exists.

When relevant and available, **actually call the tools**:

- Robinhood MCP for live account state, positions, orders, chains, quotes, and order review/execution.
- Vibe-Trading for screening, research, technical/factor analysis, backtesting, filings, fundamentals, and other available quant tools.
- Unusual Whales for options-flow/GEX/dark-pool/premium evidence.
- skfolio/Python for portfolio and risk calculations.
- Agent Reach / web/news tools for current news, X/Twitter/social sentiment, Reddit, RSS, and discovery.
- Primary company/investor-relations or other authoritative sources to verify material event claims when practical.

Never skip a relevant tool because the answer “seems obvious.”

## 3. Fail closed

If required live data, account data, contract data, risk settings, or a required tool is unavailable, **do not open a new live position**.

`NO TRADE`, `WAIT`, and `INSUFFICIENT DATA` are valid outcomes.

## 4. Manage existing positions before seeking new ones

At the start of each market run:

1. Pull current Robinhood account/position/order state.
2. Reconcile it against `state/POSITIONS.md`.
3. Review every open option position for thesis validity, price/Greeks/IV, liquidity, expiration, catalysts, and earnings.
4. Handle required exits/risk actions before searching for new trades.

A cheap scan returning zero new candidates does **not** permit ignoring open positions.

## 5. Cheap gate before expensive reasoning

For new opportunities:

1. Run the deterministic/cheap scanner first.
2. If nothing qualifies, stop new-opportunity analysis with minimal output.
3. If candidates qualify, rank them using compact tool results.
4. Only escalate genuinely strong candidates to deeper Codex reasoning.
5. Only use expensive reasoning/sub-agents when the expected decision value warrants the compute cost.

Do not conduct a giant market-wide LLM research pass on every scheduled run.

## 6. Sub-agents are deliberate, not optional decoration

When Codex sub-agents are available, use the designated roles in `strategy/SUBAGENTS.md` for escalated candidates.

- Do not spawn sub-agents on routine zero-candidate runs.
- Usually use only the 1–3 roles needed.
- Up to all five roles may be used for unusually consequential decisions such as earnings holds, unusually large positions, conflicting signals, or major event risk.
- Sub-agents may research/review; **none may execute orders**.
- The orchestrator must reconcile disagreements rather than averaging them blindly.

## 7. Robinhood is execution truth

Immediately before any live order:

1. Re-fetch account state/buying power.
2. Re-fetch existing positions/open orders.
3. Re-fetch underlying and option contract quote/chain details.
4. Run Robinhood's available order-review/pre-trade check.
5. Re-run hard risk checks.
6. Only then place the order through Robinhood.

Never execute from stale Vibe, UW, social, or cached quote data.

## 8. Social/news are evidence, not authority

Social sentiment can discover a play, strengthen/weaken a thesis, or identify a catalyst. It cannot be the sole justification for a trade.

Verify material claims—earnings dates, guidance, filings, legal/regulatory events, product announcements, etc.—with reliable sources before risking capital when practical.

## 9. Earnings/event risk is mandatory

Before opening or intentionally holding an option position through an earnings/event window, follow `strategy/EARNINGS_NEWS_SOCIAL.md`.

If the mandatory event-risk review cannot be completed, do not intentionally hold through the event.

## 10. Persistent memory is required

After any material decision, update the appropriate files:

- `state/POSITIONS.md` — current open-position thesis and management memory.
- `journal/TRADES.md` — executed trades and outcomes.
- `journal/DECISIONS.md` — important trade/pass/hold/exit decisions.
- `state/DAILY_STATE.md` — daily P&L, risk state, compute/data costs, and operational status.
- `state/LESSONS.md` — only durable, evidence-backed lessons.

Do not let a chat transcript be the only memory of why a position exists.

## 11. Do not self-modify core policy

You may update state, journal, and evidence.

Do **not** silently change:
- `strategy/STRATEGY.md`
- `strategy/RISK.md`
- `strategy/COST_POLICY.md`
- `strategy/EXECUTION_RULES.md`
- `CONFIG.md`

You may propose a change with evidence/backtest results, but core strategy/risk changes require user approval.

## 12. Never trade to pay a bill or hit a quota

The project should economically justify its AI/data expenses, but never open or enlarge a trade merely because the UW bill, Codex credits, or any other expense is due.

Performance must justify expenses; expenses must never force trades.

## 13. Live execution lock

If `CONFIG.md` does not explicitly contain:

`LIVE_EXECUTION_ENABLED: true`

then all order placement is prohibited. Research, shadow decisions, order previews, and simulations are allowed.
