# Small-Account Policy Proposal

Status: **APPROVED by the user on 2026-08-23.** Live execution remains separately disabled.

[account details redacted]

## Position and daily risk

- Maximum open positions: 1
- Maximum contracts per position: 1
- Maximum new positions per day: 1
- Maximum entry debit / premium at risk: $150
- Maximum portfolio premium at risk: $150
- Maximum planned daily loss: $45 or 12.5% of start-of-day equity, whichever is lower
- No averaging down and no adding to a losing option
- No position may be opened merely to recover a loss or meet an expense/profit target

A $150 long option can still lose the full $150. The planned 25% stop is an exit instruction, not a
$37.50 maximum-loss guarantee; gaps, spreads, halts, or a failure to fill can produce a larger loss.

## Contract gate

- Long calls and long puts only; one contract
- No 0DTE
- 7–45 calendar days to expiration
- Bid/ask spread no greater than 10% of the mark
- Option volume at least 100
- Option open interest at least 500
- Underlying average daily dollar volume at least $50 million
- No intentional earnings hold during initial live testing
- No new entry before 9:50 a.m. ET or during the final 30 minutes of regular trading

## Exit policy

- Immediately after a confirmed entry fill, review and submit one GTC sell-to-close stop-market
  order at 25% below the fill price when Robinhood permits it.
- Full take-profit review at 30% above the fill price. With one contract there is no scale-out.
- Trailing exit disabled initially; revisit when the account can support multiple contracts.
- Day trade: exit no later than 15 minutes before the regular close.
- Swing trade: record an explicit hold deadline before entry; never carry through earnings during
  initial live testing.
- Thesis invalidation, changed event risk, stale data, missing protection, or broker/state mismatch
  wakes Codex and blocks new risk.

Robinhood does not provide a true options bracket order. One contract therefore cannot have a
simultaneous broker-native stop-loss and take-profit order. The protective stop gets priority; the
take-profit path requires monitoring, cancellation/review of the stop, and a separate exit order.

## Monitoring cadence

- Python/Robinhood MCP account and position reconciliation: every 2 minutes while a position is open
- Python quote/exit-trigger check: every 2 minutes while a position is open
- Model-free position-symbol news hash check: every 5 minutes; Luna runs only for a new item
- Deterministic new-opportunity scan: every 10 minutes, 9:50 a.m.–3:30 p.m. ET
- Luna/low is an ephemeral event triager, not a persistent agent; Sol/xhigh is invoked only after
  Luna escalation or a position/risk trigger
- No new conditions: no Codex invocation and no model-token usage

## Execution boundary

The initial live workflow retains Robinhood order review and explicit user confirmation. Enabling
fully unattended placement would require a separately approved change to core execution policy and
is not part of this proposal.
