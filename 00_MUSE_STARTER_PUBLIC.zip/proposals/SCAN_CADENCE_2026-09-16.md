# Implemented scan cadence change — 2026-09-16

User authorized only more frequent opportunity scans, retaining Luna/high.

- CONFIG opportunity cadence: five minutes.
- Installer and installed Opportunities task: five-minute repetition starting at
  09:30:15, giving a 15-second allowance after candle boundaries. Provider latency
  and actual task runtime can still delay data or scans; this is not a bar-arrival trigger.
- Updated only the existing task's triggers, preserving its actions and settings.
- Read-back verified Ready, PT5M, start boundary 09:30:15.
- Position monitoring remains two minutes; model budget remains 13/day.
- No manual trading cycle, model call or notification test was launched.
- Existing budget exhaustion still stops opportunity scanning for the day. Five-minute
  scans do not promise a model decision on every candle or continued scans after exhaustion.
- Free-flow research was informational; no provider or trading signal was added.

Python's bounded watchlist discovery retains call/put and style coverage, applies
liquidity/Greek/premium gates, ranks contract quality, and then requires technical
direction support before Luna. It does not send every contract for model comparison.
