# Approved paper-trading repairs — 2026-09-05

Status: implemented and verified offline. The user approved the four repairs and sizing correction,
retained Luna, and deferred selecting a simpler entry strategy. This record supersedes the earlier
read-only review for this repair scope.

## What prevented trades

The August 31–September 4 review found 193 opportunity cycles and no opportunity model calls.
On Friday, all 54 Python candidate rejections had preferred style `NONE`: the SPY/QQQ watchlist
path omitted the entry-eligibility normalization used by the broad discovery path. Luna never
received those candidates. Earlier days also showed tradability-qualified contracts being removed
by the premium filter. Expiration selection favored approximately 16 DTE instead of searching the
nearer permitted expirations first.

Additional defects included a blanket paper-position discovery block, despite policy allowing
one position per underlying; daily P&L that counted prior-day unrealized losses again; and fixed
weekday/16:00 clock handling without exchange holidays or early closes.

## Implemented scope

1. **Repair the Python-to-Luna handoff.** Watchlist candidates now pass through the same time-aware
   DAY/SWING eligibility normalization as broad candidates. Empty eligible lists report zero
   qualified candidates. Technical evidence is reused per underlying within a packet-building
   pass, and freshness comparisons use the time after data collection completes.
2. **Search affordable contracts.** Discovery searches the nearest two permitted expirations plus
   the nearest permitted SWING window, within the existing three-expiration bound. It preserves
   call/put and style diversity in the shortlist and filters against the account's current entry
   budget. Existing DTE, delta, theta, spread, volume, open-interest, and underlying-quality gates
   remain active; this does not assert that a cheaper or more expensive contract is inherently
   better.
3. **Repair paper operation and accounting.** An existing SPY position no longer blocks discovery
   of QQQ when cash, daily limits, and planned risk permit it. The final ledger lock independently
   rejects another position in the same underlying. Final quotes recheck freshness, spread,
   volume/open interest, Greeks, and risk before entry. Daily P&L is equity minus start-of-day
   equity, and a flat account's daily reset is persisted. Shared exchange-calendar logic handles
   holidays and early closes for entries and DAY exits. Existing two-minute position polling
   continues to manage stops, targets, and deadlines.
4. **Make inactivity and results measurable.** Each scheduled cycle records the contract funnel,
   premium rejections, Python reasons, cache suppression, model use, and primary paper entries in
   `state/evaluation/METRICS.json` and `SUMMARY.md`. A separate DAY control can buy a newly
   Python-qualified, model-reviewed DAY candidate after BUY/PASS/WAIT, using the same post-decision
   quote and final risk checks. It uses no additional model call. Its cash, trade counts, and risk
   live in `state/paper_baseline/`; it cannot place broker orders or count as a primary Luna trade.

The control is conditional on the primary discovery funnel and has independent available cash.
It is not an independently sampled strategy. Cached verdicts, unreviewed candidates, and model
SWING buys do not produce a DAY-control observation. `PAIRS.jsonl` links the ledgers, and the report
compares completed matched DAY observations. Overall primary results can also include SWING trades.
Main-account PASS/WAIT remain no-entry decisions.

## Sizing and costs

The $250 configured premium ceiling remains an outer bound. Each entry also reserves its planned
25% stop loss and a $2.10 round-trip cost allowance against the remaining daily loss budget.
Existing positions reserve the additional loss from their current bid to their stop, plus exit
costs. Today's losses reduce the budget; today's gains do not enlarge it. Available cash and other
position limits continue to apply.

[account details redacted]
or open-position risk, the effective premium ceiling is:

`($45 - $2.10) / 25% = $171.60`

That means a $250 premium cannot pass the planned-loss check. The ceiling shrinks with losses or
other positions. Actual valid quote increments can make the available contract price lower.
The software stop is a trigger, not a guaranteed fill; gaps and polling delays can exceed planned
[account details redacted]

Paper fills retain ask entry/bid exit. Configured deductions are **$0.05 fee plus $1.00 slippage per
contract per side**. These are explicit experiment assumptions, not verified Robinhood charges.
Closed-trade P&L deducts both sides. Reports include expectancy, win rate, profit factor, and
drawdown at observed marks. AI/data costs remain explicitly unrecorded until supplied through
the existing cost tracker to `state/evaluation/COSTS.jsonl`; unknown costs are not reported as zero.

## Validation

- Complete project suite: **247 passed** in the final run. Original pre-repair suite: 229 passed.
- `ruff check tools tests`: passed. The broader `ruff check .` reports **559 existing issues**,
  all under the unchanged imported `integrations/tradingview-analysis-mcp` tree.
- New integration coverage exercises actual watchlist resolution/normalization, Python gating,
  packet construction, a stubbed model boundary, fresh-quote paper entry, monitoring, exit,
  costs, and matched-result reporting. BUY opens at the ask and a later target hit closes at the
  bid; PASS/WAIT leave the primary ledger flat. Quotes and model outputs are synthetic fixtures.
- Additional regression coverage checks affordable two-underlying capacity, same-underlying
  duplicates, changing loss budgets, overnight daily P&L, missing/wide/stale final quotes,
  expiration diversity, invalid costs, holidays, and early-close deadlines.
- Calendar dependency `pandas-market-calendars` is installed and locked. Tests cover Labor Day
  September 7 and the November 27 / December 24, 2026 early closes. Regular underlying-session
  hours are used conservatively, including a 12:30 DAY-entry cutoff and 12:45 DAY-exit deadline
  on 13:00-close days. See the [official NYSE calendar announcement](https://ir.theice.com/press/news-details/2025/NYSE-Group-Announces-2026-2027-and-2028-Holiday-and-Early-Closings-Calendar/).
- Offline tests used isolated temporary ledgers. The production paper portfolio remains $369
  cash/equity, zero open positions, and zero closed trades. No scheduled cycle, model call,
  broker order/review/cancellation, notification, or task modification was initiated for this
  repair. A read-only scheduler check showed all three existing tasks `Ready`.

## Operational interpretation

Luna/high, SPY/QQQ, paper mode, the live-execution lock, one-contract quantity, three new positions
per day, the 25% stop, and the 30% target are retained. New reports and control ledgers will populate
when the already configured tasks next execute during an eligible market session; they are not
historical backfills. Original implementation files were saved under
`.codex-test-tmp/repair-originals-20260905/` before editing.

Offline success verifies the repaired software path, not current market-data availability,
future fills, profitability, or daily returns. The current strategy still uses technical
confluence and Luna's judgment. It has not established a consistent profitable edge, and 3%
daily compounding is not an evidenced expectation. A simpler strategy remains a later experiment.
