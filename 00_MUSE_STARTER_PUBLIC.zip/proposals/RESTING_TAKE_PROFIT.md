# Resting take-profit requirement — 2026-09-16

UPDATE: The user subsequently approved automatic primary/control paper TP booking
on historical trade-through. See strategy/EXECUTION_RULES.md for the implemented
completed-minute-bar rules. Earlier evidence-only statements below are superseded.
Fifteen paper-trading/runner tests passed after this change.

User requires broker-held take-profit limits before live operation. Robinhood MCP's
place_option_order supports single-leg sell/close limit orders with GFD/GTC.
No live order was placed and live execution remains disabled.

Live readiness remains blocked on implementation and validation of: broker-valid
price increments; order creation after confirmed entry; idempotency; fill and partial
fill reconciliation; cancellation acknowledgement and fill-race handling before
stop/time exits; restart recovery; expiry/renewal. The existing prohibition on
automatic cancellation needs an explicit narrowly scoped approval before enabling
cancel-and-exit behavior. A pending TP must not suppress protective exit management.

Paper monitoring now requests historical option bars and records take_profit_evidence
on each position. Noninterpolated bars beginning after entry whose highs meet the
target are POSSIBLE_LIMIT_FILL_NOT_CONFIRMED. Entry-straddling bars are excluded.
Historical prices are not historical bid/ask depth or queue information; no retroactive
fill or P&L rewrite is performed. Primary paper exits retain their current bid rules.
History failures are recorded as unavailable; normal quote management remains in place.
This adds read-only data requests, no model calls. Offline/runtime validation is pending.
