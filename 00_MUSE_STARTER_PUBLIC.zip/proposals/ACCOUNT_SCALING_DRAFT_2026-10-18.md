# Account scaling — discussion draft, October 18, 2026

[account details redacted]

## Evidence boundary

The recorded September 8–October 8 fixed-record green-lock replay earned $147 on $369 (39.8374%), keeping 20 trades and skipping 16. Original control net P&L was $70.40 on 36 trades (19.08%). Sources: docs/OPTIONS_GREEN_REPLAY_2026-10-09.json and docs/OPTIONS_DETERMINISTIC_CUTOVER.md.

The replay retains historical exits and assumed paper target fills, does not recompute cash-dependent candidate selection or position sizing, and does not reproduce every gate in the October 9 strategy epoch. It is not prospective live performance or a forecast of recurring monthly returns. AI/data dollar costs are not established by this result.

Computed from its daily totals, replay daily-close maximum drawdown is 14.76%; original control is 24.40%. These omit intraday/open-position drawdown. Replay ended at $516; original at $439.40. The current epoch needs separate evaluation.

## Design

Preserve entry signals, JEV ranking, 25% stop, 30% target, daily green lock, three new positions/day, session exits, one position per ticker, and no averaging down. Scale quantity only after approval and implementation verification. Keep SPY/QQQ exposure in one shared risk pool; do not credit diversification between them for sizing.

Use start-of-day broker equity for daily budgets. No intraday profit-based increases. For sizing, use the lower of start-of-day and current reconciled equity, with a separate approved dollar ceiling for each rollout stage. Review upward promotions weekly; reduce available risk immediately when equity falls. Deposits increase capital, not evidence of trading skill, and do not automatically authorize a promotion.

Illustrative candidate limits, not optimized or approved:

| Equity example | Planned risk per new trade | Daily planned-loss budget | Premium per position | Total open premium cap |
|---|---:|---:|---:|---:|
| Below $1,000 | Existing rules | Existing rules | Existing rules | Existing rules |
| $1,000 | 4% / $40 | 6% / $60 | 15% / $150 | 25% / $250 |
| $2,500 | 4% / $100 | 6% / $150 | 15% / $375 | 25% / $625 |
| $5,000 | 3% / $150 | 5% / $250 | 12% / $600 | 20% / $1,000 |
| $10,000 | 2% / $200 | 4% / $400 | 8% / $800 | 15% / $1,500 |

These are milestone examples; band boundaries and promotion/demotion mechanics require testing before specification. Percentages remain moderately aggressive, particularly in smaller accounts. Five sequential full 6% planned-loss days compound to a 26.61% decline before overruns. Planned limits cannot guarantee realized losses.

## Quantity calculation

Let P be full dollar premium per contract (option ask times multiplier), C be conservative round-trip costs per contract, T the trade planned-loss cap, D the remaining daily planned-loss allowance after losses/open risk/pending-entry reservations, M the per-position premium cap, A the remaining aggregate premium allowance including pending orders, and B available cash after existing commitments.

Quantity = minimum of floor(min(T,D)/(0.25*P+C)), floor(M/P), floor(A/P), floor(B/(P+entry_cost)), and the currently approved rollout quantity ceiling. Use nonnegative allowances; zero quantity means pass. Recheck actual cent-rounded stop/target economics, quote size, quantity-dependent slippage and final broker state. No risk offset from presumed SPY/QQQ hedging.

With illustrative P=$150 and C=$2.10, one contract has $39.60 planned loss and $42.90 target net reward. Two have $79.20 planned loss, $300 premium and $85.80 target net reward. At $1,000 the candidate limits allow one, not two; at $2,500 two can fit if remaining daily risk, premium exposure, cash and rollout ceiling also permit. Three entries/day is an opportunity ceiling, not permission to spend three full risk allocations.

The $2.10 is the existing modeled per-contract round-trip reserve, not a verified broker fee or guaranteed execution cost. All costs must scale with quantity and modeled slippage should be checked against observed fills.

## Promotion and protection

First observe Linux market-hours execution at current size. Before an initial increase, provisional review floor: at least 20 trading sessions AND 30 closed live trades under the unchanged current strategy; this triggers review, not statistical certification. Require positive net expectancy after measured costs, acceptable mark-to-market drawdown, reconciled fills, and no unresolved order/monitor incidents. If evidence is insufficient, remain at current size regardless of equity.

Enable a maximum two-contract rollout first. Later quantity ceilings increase one step per approved review, only when calculated risk permits. Never buy extra contracts to reach a target allocation; never choose a worse contract simply because it is cheaper. Preserve the original contract-quality gates.

Test a drawdown overlay separately: half normal new-entry sizing at 8% account drawdown and pause new entries for review at 12%, measured on cash-flow-adjusted mark-to-market equity from its high-water mark. Existing protective exits continue. These provisional thresholds are not evidence-derived and would have interacted materially with the replay's 14.76% daily-close drawdown; do not claim the overlay preserves its return. Cash transfers must not create false drawdown or recovery. Restoring size requires review, not a single profitable day.

## Required work before activation

1. Isolated chronological sizing simulation from original entry/exit events, with cash, overlapping positions, pending commitments, daily loss/green locks and changing equity. Fixed-record quantity sensitivity is diagnostic only; changed selection requires rerunning the available discovery evidence. Identify missing data explicitly.
2. Compare current rules with the candidate percentages and nearby alternatives, reporting returns, mark-to-market drawdown where available, longest loss runs, skipped setups, capital exposure, and performance concentration. Reserve forward data for validation; do not optimize on the 20 kept trades.
3. Stress wider spreads, per-contract slippage, 35%/50% stop overruns and complete premium loss during outages. Full-premium exposure remains distinct from planned stop loss. No exponential growth forecast from the historical month.
4. Implement/test multi-contract partial fills, per-contract costs, exact quantities, partial exits, duplicate-order recovery, cash/reservations and green-lock accounting in isolation. Existing single-contract execution assumptions require audit before changing the quantity setting.
5. Verify broker permissions/account restrictions and fresh execution capacity at activation. Obtain explicit user approval for exact policy and code changes, then a bounded rollout. No automatic activation at an equity milestone.

External execution-risk reference: SEC Investor Bulletin, Stop, Stop-Limit, and Trailing Stop Orders (updated August 18, 2026): https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-15 . Its general explanation that stop triggers do not guarantee execution prices is relevant; our bot uses its own software trigger, not a broker-held stop.
