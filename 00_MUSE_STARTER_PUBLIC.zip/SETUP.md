# TradingView MCP Setup

Last validated: 2026-08-29 22:15 ET

## Scope and status

Both requested MCPs are installed and validated:

- `tradesdontlie/tradingview-mcp` controls TradingView Desktop and passed the original 15-point end-to-end validation.
- `atilaahmettaner/tradingview-mcp` supplies headless market-data, technical-analysis, strategy-comparison, and walk-forward tools. A fresh Luna session discovered it and completed real SPY backtests.

The two MCPs intentionally have distinct Codex names: `tradingview` for the Desktop/Pine controller and `tradingview_analysis` for the headless research server.

This integration is for local research and backtesting. Live Robinhood execution remains disabled by `CONFIG.md`; this setup did not place, review, or alter any broker order.

## Computer audit

| Component | Detected version / state | Path or detail |
|---|---|---|
| Windows | Pro, DisplayVersion 25H2, build 26200.9168, x64 | The registry's legacy `ProductName` value says `Windows 10 Pro`; build/display version are recorded separately. |
| TradingView Desktop | 3.4.0 / file build 3.4.0.8149 | Microsoft Store/MSIX: `C:\Program Files\WindowsApps\TradingView.Desktop_3.4.0.8149_x64__n534cwy3pjxzj\TradingView.exe` |
| TradingView runtime | Electron 41.7.1, Chrome 146.0.7680.216 | Reported by CDP after launch |
| Git | 2.49.0.windows.1 | `C:\Program Files\Git\cmd\git.exe` |
| Node.js | 24.14.0 | `C:\Program Files\nodejs\node.exe` |
| npm | 11.9.0 | `C:\Program Files\nodejs\npm.cmd` |
| Python | 3.14.3 | `C:\Python314\python.exe` |
| Managed Python for analysis MCP | 3.13.14 | `C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-analysis-mcp\.venv\Scripts\python.exe` |
| Python launcher | 3.14.3 | `C:\Windows\py.exe` |
| uv | 0.12.1 | `C:\Users\jesse\AppData\Roaming\Python\Python314\Scripts\uv.exe` |
| Codex Desktop-bundled CLI | 0.150.0-alpha.8 | `C:\Users\jesse\AppData\Local\OpenAI\Codex\bin\a5c9108151f176e9\codex.exe` |
| Standalone PATH Codex CLI | 0.149.0 | `C:\Users\jesse\AppData\Roaming\npm\codex.cmd` |
| Codex config | Present | `C:\Users\jesse\.codex\config.toml` |

The Codex config already contained the project's existing MCPs and uses `gpt-5.6-sol` with `xhigh` reasoning by default. No existing MCP entry was overwritten.

## Installed repository

- Repository: `https://github.com/tradesdontlie/tradingview-mcp`
- Local path: `C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-mcp`
- Branch: `main`
- Validated commit: `c05b8f5755ed8e64ea242de88ddbf46aa24d56a4`
- Package version: `tradingview-mcp@1.0.0`
- Installed with: `npm install`
- Resolved direct packages: `@modelcontextprotocol/sdk@1.27.1`, `chrome-remote-interface@0.33.3`, `eslint@9.39.4`

`npm install` reported 7 dependency advisories: 1 low, 2 moderate, and 4 high. No automatic `npm audit fix` was run because it could change the dependency graph beyond the repository's lockfile intent.

## Installed analysis/backtesting repository

- Repository: `https://github.com/atilaahmettaner/tradingview-mcp`
- Local path: `C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-analysis-mcp`
- Branch: `main`
- Validated commit: `a7e22e1314597faba05305ea294ac15e2525f1b2`
- Package version: `tradingview-mcp-server==0.8.1`
- Python: 3.13.14 in the repository-local `.venv`
- Key resolved packages: `mcp==1.29.0`, `pandas==2.3.1`, `tradingview-screener==3.0.0`, `tradingview-ta==3.3.0`
- Installed with: `uv sync --python 3.13 --frozen --dev`

The package does not support Python 3.14. `uv` installed its managed Python 3.13 runtime without changing the existing system Python 3.14 installation. The virtual environment is warmed, so Codex starts the executable directly instead of running `uvx` and resolving packages on every MCP launch.

## Codex MCP configuration

The following entry was added to `C:\Users\jesse\.codex\config.toml`:

```toml
[mcp_servers.tradingview]
command = 'C:\Program Files\nodejs\node.exe'
args = ['C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-mcp\src\server.js']

[mcp_servers.tradingview_analysis]
command = 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-analysis-mcp\.venv\Scripts\tradingview-mcp.exe'
```

Verify it with:

```powershell
$env:CODEX_HOME = 'C:\Users\jesse\.codex'
& 'C:\Users\jesse\AppData\Local\OpenAI\Codex\bin\a5c9108151f176e9\codex.exe' mcp get tradingview
```

A newly started Codex session loads the entry. The server exposes 84 MCP tools. Standalone Codex runs should use automatic review when calling MCP tools; `--sandbox read-only` by itself gives MCP calls a never-approve policy. A validated low-cost smoke used Luna with `--approve-for-me` and successfully called `tv_health_check`.

The `tradingview_analysis` server exposes the repository's 37 read-only research tools. A fresh isolated Luna/low session loaded only this MCP and successfully called `compare_strategies` and `walk_forward_backtest_strategy`. The current Codex task must be restarted before newly added MCP tools appear in its own tool inventory.

## TradingView launch method

TradingView was launched with the repository's current Windows/MSIX-aware launcher:

```powershell
Set-Location 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-mcp'
node.exe src\cli\index.js launch
```

The launcher stops existing `TradingView.exe` processes by default, auto-detects the installed package, and starts it with `--remote-debugging-port=9222`. On this computer the direct `WindowsApps` executable bound CDP successfully, so the `%LOCALAPPDATA%\tradingview-mcp\` copy fallback was not needed.

Expected local endpoint:

```text
http://127.0.0.1:9222
```

Verify CDP and the current chart:

```powershell
Set-Location 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-mcp'
node.exe src\cli\index.js status
```

## Complete validation results

1. **Codex tool visibility:** pass. `codex mcp list` shows `tradingview`, the MCP handshake listed 84 tools, and a fresh `gpt-5.6-luna`/low Codex run discovered and called `tv_health_check`.
2. **`tv_health_check`:** pass with `success: true`, `cdp_connected: true`, and `api_available: true`.
3. **TradingView detected/connected:** pass. TradingView 3.4.0 was launched directly from its MSIX package and CDP responded on 9222.
4. **Current chart:** pass. `CME_MINI:MES1!`, 1-minute candles, chart type `1`.
5. **Pine Editor access:** pass. `ui_open_panel` opened the editor and Monaco became available after its initial load.
6. **Read existing Pine source:** pass. The open editor contained a 7-line, 185-character Pine v6 indicator named `My script`.
7. **Harmless reversible edit:** pass. A temporary comment marker was appended without saving the script to TradingView cloud.
8. **Compile modified script:** pass. `pine_smart_compile` returned no errors and did not add a new study.
9. **Read compiler result:** pass. `pine_get_errors` returned `error_count: 0`.
10. **Intentional syntax error:** pass. The temporary line `this is not valid pine` produced a compiler diagnostic at line 8, column 9: `"not" cannot be used as a variable or function name.`
11. **Repair compile:** pass. The original source was restored and compiled with zero errors.
12. **Strategy Tester information:** pass. The loaded strategy was `ORB + Ichimoku + Wickless — v10S Entry-Type Controls FIXED`; 19 metrics were returned, including 19 total trades, raw net profit `15`, profit factor `1.028436018957346`, and max drawdown `212.5`.
13. **Individual strategy trades:** pass. The internal API reported 38 orders; bounded reads returned individual entry/exit orders with side, type, price, quantity, and time index.
14. **Equity/performance:** performance summary passed. The MCP accessed the equity endpoint, but TradingView did not expose a per-bar strategy equity series (`data_points: 0`). It did expose 20 buy-and-hold baseline points and the full summary P&L metrics above.
15. **Restore original script:** pass. Exact equality was verified against the in-memory original: 7 lines, 185 characters, temporary marker absent, clean compile. The bottom panel was collapsed again afterward.

These Strategy Tester numbers describe the chart state present during setup; they are not evidence that the strategy has robust or positive out-of-sample expectancy.

## Analysis MCP validation and first research loop

1. **Repository/runtime:** pass. The isolated Python 3.13 environment starts successfully and the repository remains clean.
2. **Unit suite:** pass. `227 passed, 8 deselected` in 13.66 seconds; the deselected tests are the opt-in real-network stress suite.
3. **Codex visibility:** pass. `codex mcp list` shows `tradingview_analysis` enabled, and a fresh isolated `gpt-5.6-luna`/low session called its tools successfully.
4. **Nine-strategy SPY comparison:** pass. On 501 daily Yahoo Finance candles from 2024-08-29 through 2026-08-28, the initial ranking was Donchian +18.88%, Bollinger +14.47%, EMA Cross +14.13%, Supertrend +13.01%, RSI +11.95%, RSI Pullback +3.14%, Triple EMA 0.00%, MACD -0.50%, and Keltner Breakout -3.95%.
5. **Overfit rejection:** pass. Donchian ranked first in-sample but produced zero out-of-sample trades and was labeled `OVERFITTED`; it was not promoted.
6. **Bounded candidate selection:** pass. Luna walk-forward-tested the remaining six eligible strategies with three 70/30 folds, 0.1% commission, and 0.05% slippage per side. Bollinger was the only candidate meeting the demonstration screen of positive OOS return, at least three OOS trades, and robustness at least 0.5: robustness 0.74 (`MODERATE`), OOS return +5.74%, three OOS trades.
7. **Pine generation/compile:** pass. The matching long-only 20-period, 2-standard-deviation Bollinger rules were written to `research\tradingview\strategies\TVR-0001_bollinger_wf_demo.txt`. Offline static analysis and TradingView's server compiler returned zero diagnostics.
8. **TradingView Desktop run:** pass. The Pine strategy was added to `AMEX:SPY` on the daily chart without saving or publishing the script. Strategy Tester reported 11 completed trades, nine winners, two losers, 81.82% profitable, +$1,369.15 (+13.69%) total P&L on $10,000, profit factor 3.21, $1,375.20 (13.00%) maximum drawdown, and $336.39 commission.
9. **Cross-engine trade agreement:** pass. The headless engine and Pine used the same 11 signal trades; recent entry/exit dates and prices matched exactly. The headless engine reported +14.47%, while TradingView reported +13.69%, primarily because the headless engine compounds fractional capital and TradingView buys whole SPY shares with residual cash.
10. **Risk-metric discrepancy found:** the headless engine reported only 3.69% closed-trade equity drawdown, while TradingView's mark-to-market Strategy Tester reported 13.00%. Headless drawdown is not acceptable as the sole risk gate until it is upgraded to bar-by-bar mark-to-market accounting.

This is proof that the research-to-Pine handoff works, not proof of a deployable edge. Three OOS trades is an inadequate sample, and the two-year strategy underperformed SPY buy-and-hold (+37.79% in the headless data).

## Reproduction commands

```powershell
Set-Location 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic'
git.exe clone --branch main --single-branch https://github.com/tradesdontlie/tradingview-mcp.git integrations\tradingview-mcp

Set-Location 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-mcp'
npm.cmd install

$env:CODEX_HOME = 'C:\Users\jesse\.codex'
& 'C:\Users\jesse\AppData\Local\OpenAI\Codex\bin\a5c9108151f176e9\codex.exe' mcp add tradingview -- 'C:\Program Files\nodejs\node.exe' 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-mcp\src\server.js'

node.exe src\cli\index.js launch
node.exe src\cli\index.js status
node.exe src\cli\index.js ui panel pine-editor open
node.exe src\cli\index.js pine get
node.exe src\cli\index.js data strategy
node.exe src\cli\index.js data trades --max 10
node.exe src\cli\index.js data equity

Set-Location 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic'
gh.exe repo clone atilaahmettaner/tradingview-mcp integrations\tradingview-analysis-mcp

Set-Location 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-analysis-mcp'
uv.exe python install 3.13
uv.exe sync --python 3.13 --frozen --dev
.\.venv\Scripts\python.exe -m pytest -q

$env:CODEX_HOME = 'C:\Users\jesse\.codex'
& 'C:\Users\jesse\AppData\Local\OpenAI\Codex\bin\a5c9108151f176e9\codex.exe' mcp add tradingview_analysis -- 'C:\Users\jesse\OneDrive\Documents\ChatGPT\Robinhood Agentic\integrations\tradingview-analysis-mcp\.venv\Scripts\tradingview-mcp.exe'
& 'C:\Users\jesse\AppData\Local\OpenAI\Codex\bin\a5c9108151f176e9\codex.exe' mcp get tradingview_analysis
```

Do not run `npm link` unless a global `tv` command is specifically wanted; all validation used the repository-local CLI.

## Test and troubleshooting notes

- `npm run lint`: 0 errors and 4 upstream unused-variable warnings.
- `npm run test:unit` with outbound access: 123/125 tests passed. Direct server-side Pine compile tests passed.
- The two failing CLI wrapper tests receive the correct compile result but Node 24 on Windows aborts the short-lived subprocess during fetch teardown with libuv assertion `!(handle->flags & UV_HANDLE_CLOSING)` and exit code `0xC0000409`. The long-lived MCP server and actual editor compile path worked repeatedly.
- The source-audit test also contains an upstream Windows path bug: it uses `new URL(...).pathname`, leaving `%20` encoded and constructing `C:\C:\...` when the repository path contains spaces. This is a test-path issue, not an MCP runtime path issue.
- The first `pine_get_source` call immediately after opening the Pine Editor can race Monaco initialization. Wait briefly and retry after `tv_ui_state` reports the editor open.
- If CDP is unavailable, run `node.exe src\cli\index.js launch` again. The launcher uses `127.0.0.1`, avoiding an IPv6 `localhost` mismatch.
- If a Windows Store build cannot bind CDP directly, `tv_launch` automatically copies the installed package version to `%LOCALAPPDATA%\tradingview-mcp\` and launches the copy. Do not change `WindowsApps` ACLs.
- MCP calls from a standalone Codex run need an approval path. Use `--approve-for-me` for the bounded workflow; a plain `--sandbox read-only` run blocks even read-only MCP calls.
- A freshly started Codex task is required to load configuration changes made after the current task started.
- The analysis MCP currently requires Python `<3.14`; pin Python 3.13 on this machine.
- With `uv` 0.12.1, `uv sync --locked` detected that the upstream lock metadata would need normalization. `uv sync --frozen` installed the checked-in lock exactly and did not rewrite it.
- The analysis MCP's Sharpe and drawdown calculations are trade-level abstractions. Treat its outputs as a fast ranking gate, then validate finalists with Pine/TradingView mark-to-market results.
- Multiple strategies on one TradingView chart can confuse the generic strategy-report reader. Select `Codex Bollinger WF Demo` in the Strategy Tester menu before reading the visible report; direct entity `aFPGcM` exposed 22 entry/exit orders during this run.
- The repository is unofficial and uses undocumented TradingView internals. TradingView updates can break it. Its README warns that automated collection/non-display use may conflict with TradingView terms; keep this environment limited to authorized personal research and do not redistribute market data.
